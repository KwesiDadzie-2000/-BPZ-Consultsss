# BPZ Consult ERP — System Audit, November 2026

Scope: the latest snapshot in the repository (`audit-and-debug-accounting-system (10).zip`,
committed 17 Nov 2026), reviewed against the five failures reported from the live
workspace. The project structure, design and template were kept as they are; every
change is a targeted correction. Regression tests: `src/tests/auditFixes.test.ts`.

## 1. How the audit was run

| Check | Result before | Result after |
| --- | --- | --- |
| `tsc --noEmit`, `eslint src` | clean | clean |
| Unit suites (3 files) | 82 / 82 | 82 / 82 (+ 8 new audit tests) |
| API regression suite (real PostgreSQL) | **35 / 36** | 36 / 36 |
| 24-sector workflow suite | 760 / 760 | 760 / 760 |
| Concurrency / abuse stress suite (100,000 lines) | 25 / 25 | 25 / 25 |
| Backup → restore verification | verified | verified |
| End-to-end reproduction of the reported flows over HTTP | see §2 | see §2 |

The key observation: **the server was already sound; almost every defect lived in
the browser layer, which has no automated tests.** 900+ server-side checks passed
while users were being refused with wrong or missing explanations.

## 2. The reported failures

The screenshots were taken on the 6 Nov build. The newest snapshot had already
attempted fixes, so each one was re-verified instead of trusted.

| # | Reported message | Root cause | Status |
| --- | --- | --- | --- |
| 1 | "Amounts must have no more than two decimal places." (Loan Amortisation) | Raw annuity floats were posted. Fixed upstream for amortising loans, **but** interest-only, bullet and 0%-rate facilities still could not post any instalment before maturity (zero-value leg refused), and a 0% loan computed `0/0 = NaN`. | Fixed and proven for six facility shapes, every instalment, pay and accrue. |
| 2 | "maker "bpz_consults" is not a known user account." | The browser's user directory did not contain a newly onboarded entity administrator. | Verified fixed end-to-end: CLI-005 created, `bpz_consults` signs in and posts. |
| 3 | "Opening balances … debits and credits do not agree" | The desk guessed a Dr/Cr cause for what was actually failure #2. | Desk now shows the exact control; draft is normalised on load. |
| 4 | "Posting refused for JE-2026-11-0001: the period may be closed, the accounts may be invalid, or the document already exists." | Three compounding faults: seven refusal paths returned `false` with **no notice**; the desk read the reason from a React prop, which still held the previous render's value; and the Dr/Cr selects could display one account while holding another. | All three fixed. The same document posts successfully end-to-end. |
| 5 | "Amount (GBP)" confirmed as "₵15,000.00" | "₵" was a hard-coded literal beside amounts in 28 desks (302 places). | Symbols now follow the entity's functional currency. |

## 3. Defects found by the audit (not reported)

**Integrity**

1. **Unbalanced documents were silently rewritten.** `normalizeJournalAmounts`
   runs on every journal and "re-balanced" any difference: Dr 100 / Cr 90 became
   Dr 100 / Cr 100 and was accepted. It now settles only genuine rounding residue
   (at most half a pesewa per line); a real imbalance is refused.
2. **Direct postings reused numbers reserved by pending approvals**, so the later
   approval collided permanently and could never post.
3. **Zero-value legs sank whole documents** in any desk (payroll with a nil
   deduction, an exempt sale, an interest-only instalment). They are now dropped
   at the workspace boundary before validation.

**"Nothing failed silently" was not true**

4. About 35 handler exits returned `'failed'`/`false` with no reason — closed
   period, insufficient treasury funds, over-payment, missing stock item,
   duplicate payroll run, debit/credit-note status. Each now states its cause
   with the figures involved.
5. Five more desks (GL editor, FX revaluation, CIT provision, reversals,
   year-end close) displayed guessed reasons. They now show the real one.
6. A definitive server rejection was worded as a connection problem ("may have
   been committed … reload"). Rejections and connection failures are now distinct.
7. A duplicate document number was reported as an "idempotency key" error.
8. System notices had no time, so an old refusal looked like a current failure on
   every page visited afterwards (visible in the screenshots). They are now
   time-stamped.

**Operations**

9. **Backup verification refused the system's own backups** under the default
   directory (`./backups/x` is normalised to `backups/x`, which failed a string
   prefix test) — this was the failing API regression test. The same test would
   have accepted a sibling directory such as `./backups-other`. Containment is
   now decided on resolved paths.
10. The loan desk counted instalments as `lines / 3`, wrong for any document that
    does not have exactly three lines.

## 4. Criticism — what remains weak

These are judgements about the design. They were **not** changed, because doing so
would alter the system rather than correct it.

- **The browser is the accounting engine.** Journals are assembled in React and
  the server validates them. That is why the server suites were green while the
  product was failing. The posting rules should live in one server-side service
  per document type, with the UI submitting business intent (e.g. "pay
  instalment 3"), not finished journal lines.
- **No UI tests.** There is no component or browser test. Every reported failure
  would have been caught by one test that opens a desk and posts. This is the
  single highest-value addition.
- **Optimistic success.** A desk announces "posted" before the server confirms; a
  later rejection arrives as a separate notice after the success message.
- **Document numbers are generated in the browser** from the lines it has loaded.
  Two users posting to one entity at the same moment draw the same number; the
  second is refused and must retry. Numbers should come from a server sequence.
- **`App.tsx` is ~2,400 lines** holding every handler for 40+ desks, and
  `PayrollSection.tsx` is ~1,550. This concentration is what allowed 35 silent
  exits to accumulate unnoticed.
- **The whole ledger is shipped to the browser.** At 100,000 lines the
  group-consolidation load is 36 MB. Reports need server-side aggregation and
  paging before real volumes.
- **Ghana statutory figures in non-GHS entities.** PAYE bands, SSNIT limits and
  similar thresholds are GHS by law and remain shown in cedis. Payroll amounts
  are posted in the entity's functional currency without translation, so a
  non-GHS entity running Ghana payroll needs an explicit FX step that does not
  exist yet.
- **Mixed-entity screens.** The approvals queue lists requests from several
  entities but labels amounts with the active entity's symbol.
- **Opening-balance drafts are stored in the browser only** — a draft started on
  one device is invisible on another and to a second preparer.
- **Bullet facilities are modelled exactly like interest-only** (interest paid
  each period). A true bullet with capitalised interest is not supported.
- **First-run owner activation is open to the first visitor** unless
  `BPZ_SETUP_TOKEN` is set. On any publicly reachable host, set it.
- **Demonstration data is the default.** A fresh database is seeded with sample
  entities unless `BPZ_BOOTSTRAP_MODE=production`.
- **Hardening gaps.** The Content-Security-Policy allows `unsafe-inline` and
  `unsafe-eval`; Next.js 16 deprecates the `middleware` file convention in favour
  of `proxy` (the build prints this warning); `npm audit` reports 13 moderate
  advisories, in build tooling.
- **Build warning — backup service.** Turbopack reports that the dynamic
  filesystem access in `src/lib/backupService.ts` (reading the backup directory
  from an environment variable) causes the whole project to be traced into the
  server output. It does not fail the build, but it inflates deployments; the
  backup worker belongs in a separate script or behind a statically analysable
  path.
- **Naming.** `formatGHS` formats a bare number in any currency; the name
  invites exactly the mislabelling fixed here.

## 5. Not verified

No browser is available in the build environment, so the screens were not driven
by an automated browser. The browser-side changes were verified by type-checking,
linting, unit tests of the underlying logic, and by server-rendering the modified
desks for GBP, GHS and USD entities. A manual pass through the five reported
screens on the deployed workspace is still advisable.
