# BPZ Consult — production operations runbook

This supplements (and does not replace) `DEPLOYMENT_GUIDE.md` and the original assessments.

## Required production settings

Copy `.env.example` to the server and set real values. In particular:

- `BPZ_SETUP_TOKEN`: at least 24 random characters, used only for first-run owner activation.
- `BPZ_ENFORCE_MFA_OWNER=true` and `BPZ_ENFORCE_MFA_CHECKERS=true`.
- `BPZ_BACKUP_SCHEDULE_ENABLED=true`, `BPZ_BACKUP_INTERVAL_HOURS=24`.
- `BPZ_REQUIRE_OFFSITE_BACKUP=true` and valid S3 credentials (`S3_BUCKET`, `S3_REGION`, `S3_ENDPOINT`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, `S3_PREFIX`).
- `BPZ_ALERT_WEBHOOK_URL` if backup/operational failures should alert the on-call channel.
- `BPZ_TRUST_PROXY=true` only behind the reverse proxy that sets `X-Forwarded-For`.

Do not use demo seed passwords or a demo database in production. First-run owner activation generates a pending TOTP enrolment when MFA is enforced; the owner must verify the authenticator code before entering the workspace.

## Backups and disaster recovery

The scheduler runs hourly checks and creates one consistent PostgreSQL snapshot every `BPZ_BACKUP_INTERVAL_HOURS` (default 24h). A database advisory lock prevents duplicate workers across app instances. Local files are retained for `BPZ_BACKUP_KEEP` snapshots. If S3 is configured, each file is uploaded encrypted (`AES256`) to the configured bucket/prefix.

`BPZ_REQUIRE_OFFSITE_BACKUP=true` makes missing/failed off-site storage an error, not a silent success. `backup_status` and `ops_events` record attempts, failures, file hashes and off-site URIs. Owner-only endpoints:

- `GET /api/backups` — backup status and local/off-site inventory.
- `POST /api/backups` — create and upload a snapshot now.
- `PUT /api/backups` with `{ "file": "/var/backups/bpz/file.json.gz" }` — parse/verify a file without restoring anything.
- `GET /api/ops/health` — DB latency, backup freshness and recent operational events.

Test a real restore before live client use, and again after every upgrade:

```bash
npx tsx scripts/verify-recovery.mts
```

This creates a disposable `bpz_recovery_test` database, restores the snapshot, compares every table row count with the source, and drops the disposable database. It never truncates the source. For a manual restore during a maintenance window:

```bash
npx tsx scripts/restore.ts /var/backups/bpz/bpz-backup-YYYY.json.gz --dry-run
npx tsx scripts/restore.ts /var/backups/bpz/bpz-backup-YYYY.json.gz --force
```

The restore script requires all backup tables to exist, writes in one transaction, resets identity sequences, and restores bytea attachments correctly. Live sessions and login-lockout counters are intentionally excluded from backups; all users must sign in again after recovery.

## Monitoring and alerts

Point an external uptime monitor (Better Stack, UptimeRobot, Pingdom, or your own collector) at `GET /api/health` over HTTPS. It returns 200 only when the database is reachable. The owner-only `/api/ops/health` endpoint additionally reports backup staleness and recent errors. Backup failures also emit an optional `BPZ_ALERT_WEBHOOK_URL` JSON alert. No SMTP or monitoring secret is stored in source control.

## Cluster and proxy notes

Login lockout and the mail/IP throttle use PostgreSQL transactions and advisory locks, so they work across multiple app instances. Rate limiting is a soft abuse control, not a replacement for reverse-proxy limits. Keep `BPZ_TRUST_PROXY=true` only when `X-Forwarded-For` comes from your trusted proxy; otherwise clients could spoof their source IP.

## Pre-go-live checklist

1. One month parallel run for two or three real clients, reconciling trial balance, bank, AR/AP, stock, VAT/WHT and payroll to the pesewa.
2. Ghana-qualified accountant sign-off on VAT, NHIL+GETFund, PAYE, WHT, SSNIT and sector rates.
3. MFA enrolled and required for owner and all checker/reviewer accounts; every demo credential rotated.
4. Independent security review, production backup restore verification, and an actual off-server restore drill.
5. CI green (`.github/workflows/ci.yml`): typegen, TypeScript, ESLint, unit, API, all 24 sectors, stress, actual recovery and production build.
