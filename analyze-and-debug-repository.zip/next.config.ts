import type { NextConfig } from "next";

/**
 * Baseline HTTP hardening (OWASP ASVS V14 / ISO 27001 A.8.9). Frame-ancestor
 * restrictions are deliberately NOT set so the workspace can be embedded in a
 * hosted preview; set `Content-Security-Policy: frame-ancestors` at the edge
 * for production deployments.
 */
// Content-Security-Policy: scripts are same-origin (Next's hydration payload is
// inline, so 'unsafe-inline' is required unless a nonce pipeline is added).
// frame-ancestors is opt-in through BPZ_CSP_FRAME_ANCESTORS so a hosted preview
// can embed the workspace, while a real deployment locks it down.
const frameAncestors = process.env.BPZ_CSP_FRAME_ANCESTORS?.trim();
const contentSecurityPolicy = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self' data:",
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  ...(frameAncestors ? [`frame-ancestors ${frameAncestors}`] : []),
].join("; ");

const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=()" },
  { key: "X-DNS-Prefetch-Control", value: "off" },
  // Ignored by browsers over plain HTTP; enforces HTTPS once served over TLS.
  { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" },
  { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
  { key: "Content-Security-Policy", value: contentSecurityPolicy },
];

const nextConfig: NextConfig = {
  poweredByHeader: false,
  async headers() {
    return [
      { source: "/(.*)", headers: securityHeaders },
      // Workspace/auth JSON must never be served from a shared cache.
      { source: "/api/(.*)", headers: [{ key: "Cache-Control", value: "no-store, max-age=0, must-revalidate" }] },
    ];
  },
};

export default nextConfig;
