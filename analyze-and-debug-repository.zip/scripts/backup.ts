import "dotenv/config";
import { pool } from "@/db";
import { ensureSchema } from "@/db/bootstrap";
import { createBackup } from "@/lib/backupService";

/** Create a logical snapshot and upload off-site when S3 is configured. */
async function main() {
  await ensureSchema();
  const result = await createBackup();
  console.log(`Backup written: ${result.file} (${result.tableCount} tables, ${result.rowCount} rows, sha256 ${result.sha256}).`);
  console.log(`Off-site: ${result.offsite}${result.offsiteUri ? ` · ${result.offsiteUri}` : ""}`);
  await pool.end();
}

main().catch(async (error) => {
  console.error("Backup failed:", error instanceof Error ? error.message : error);
  await pool.end().catch(() => undefined);
  process.exit(1);
});
