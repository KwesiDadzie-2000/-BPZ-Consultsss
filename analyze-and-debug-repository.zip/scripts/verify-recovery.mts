import "dotenv/config";
import { execFileSync } from "node:child_process";
import { Pool } from "pg";
import { pool } from "@/db";
import { createBackup, readBackupFile } from "@/lib/backupService";

/**
 * Proves disaster recovery, not just that a gzip can be opened:
 *   1. snapshot the source database;
 *   2. create a disposable bpz_recovery_test database;
 *   3. restore the snapshot there with the production restore script;
 *   4. compare every restored table's row count with the source;
 *   5. drop the disposable database.
 * The source books are never truncated or edited. Off-site S3 upload is optional;
 * if it is not configured, the script explicitly reports the local-only fallback.
 */
const targetUrl = process.env.BPZ_RECOVERY_DATABASE_URL || "postgresql://postgres:postgres@127.0.0.1:5432/bpz_recovery_test";
const parsed = new URL(targetUrl);
if (!["localhost", "127.0.0.1"].includes(parsed.hostname) || parsed.pathname !== "/bpz_recovery_test") {
  throw new Error("Refusing recovery verification except on a local bpz_recovery_test database.");
}
const admin = new Pool({ connectionString: new URL("postgres", targetUrl).toString() });

async function main() {
  process.env.BPZ_BACKUP_DIR = process.env.BPZ_BACKUP_DIR || "/tmp/bpz-recovery-verification";
  const backup = await createBackup();
  console.log(`Snapshot: ${backup.file} · ${backup.tableCount} tables · ${backup.rowCount} rows · offsite ${backup.offsite}`);
  // Compare against the exact bytes restored, not a newer source snapshot taken
  // after the backup's own audit event was written.
  const source = { payload: await readBackupFile(backup.file) };

  await admin.query("drop database if exists bpz_recovery_test");
  await admin.query("create database bpz_recovery_test");
  const env = { ...process.env, DATABASE_URL: targetUrl };
  execFileSync("npx", ["tsx", "-e", 'import { ensureSchema } from "./src/db/bootstrap"; void (async () => { await ensureSchema(); })();'], { env, stdio: "inherit" });
  execFileSync("npx", ["tsx", "scripts/restore.ts", backup.file, "--force"], { env, stdio: "inherit" });

  const restored = new Pool({ connectionString: targetUrl });
  const tables = Object.keys(source.payload.tables);
  const mismatches: string[] = [];
  for (const table of tables) {
    const result = await restored.query<{ n: number }>(`select count(*)::int as n from "${table.replaceAll('"', '""')}"`);
    const expected = source.payload.tables[table].length;
    if (result.rows[0]?.n !== expected) mismatches.push(`${table}: expected ${expected}, restored ${result.rows[0]?.n}`);
  }
  await restored.end();
  if (mismatches.length) throw new Error(`Restore verification failed: ${mismatches.join("; ")}`);
  const restoredRows = Object.values(source.payload.tables).reduce((n, rows) => n + rows.length, 0);
  console.log(`RECOVERY VERIFIED: ${tables.length} tables and ${restoredRows} rows restored exactly.`);
}

main()
  .catch((error) => { console.error(error instanceof Error ? error.message : error); process.exitCode = 1; })
  .finally(async () => {
    await admin.query("drop database if exists bpz_recovery_test").catch(() => undefined);
    await admin.end();
    await pool.end();
  });
