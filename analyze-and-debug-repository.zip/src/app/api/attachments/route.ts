import { randomUUID } from "node:crypto";
import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { attachments, auditLog, clients } from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope } from "@/lib/auth";
import type { ClientEntity, UserAccount } from "@/types/accounting";

export const dynamic = "force-dynamic";

const MAX_BYTES = 4 * 1024 * 1024;
const MAX_BODY = 8 * 1024 * 1024;
const MIME_ALLOW = /^(application\/pdf|image\/(png|jpeg|webp)|text\/(csv|plain)|application\/vnd\.openxmlformats-officedocument\.(spreadsheetml\.sheet|wordprocessingml\.document)|application\/vnd\.ms-excel)$/;

/** Tenant + role authorisation. Auditors may read evidence but never change it. */
async function authorise(req: Request, clientId: number, write: boolean): Promise<{ user: UserAccount } | Response> {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
  if (user.status !== "active") return authJson(req, { ok: false, error: "This account is restricted." }, { status: 403 });
  const entity = (await db.select().from(clients).where(eq(clients.id, clientId)).limit(1))[0];
  if (!entity) return authJson(req, { ok: false, error: "Client workspace not found." }, { status: 404 });
  const firmWide = hasFirmWideScope(user);
  if (!firmWide && user.clientId !== (entity as unknown as ClientEntity).id) {
    return authJson(req, { ok: false, error: "You do not have access to that entity." }, { status: 403 });
  }
  if (write && user.role === "auditor") {
    return authJson(req, { ok: false, error: "Auditors have read-only access to supporting documents." }, { status: 403 });
  }
  return { user };
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const clientId = Number(url.searchParams.get("clientId"));
  if (!Number.isInteger(clientId) || clientId <= 0) return authJson(req, { ok: false, error: "A valid clientId is required." }, { status: 400 });
  const auth = await authorise(req, clientId, false);
  if (auth instanceof Response) return auth;

  const id = url.searchParams.get("id");
  if (id) {
    const row = (await db.select().from(attachments).where(and(eq(attachments.id, id), eq(attachments.clientId, clientId))).limit(1))[0];
    if (!row) return authJson(req, { ok: false, error: "Attachment not found." }, { status: 404 });
    return new Response(new Uint8Array(row.bytes), {
      status: 200,
      headers: {
        "content-type": row.mime,
        "content-disposition": `inline; filename="${row.name.replace(/["\\\r\n]/g, "_")}"`,
        "cache-control": "no-store",
        "x-content-type-options": "nosniff",
      },
    });
  }

  const docId = url.searchParams.get("docId");
  const rows = await db.select({
    id: attachments.id, docId: attachments.docId, docNo: attachments.docNo, name: attachments.name,
    mime: attachments.mime, size: attachments.size, addedBy: attachments.addedBy, addedAt: attachments.addedAt,
  }).from(attachments)
    .where(docId ? and(eq(attachments.clientId, clientId), eq(attachments.docId, docId)) : eq(attachments.clientId, clientId))
    .orderBy(asc(attachments.addedAt));
  return authJson(req, { ok: true, attachments: rows.map((r) => ({ ...r, addedAt: r.addedAt instanceof Date ? r.addedAt.toISOString() : String(r.addedAt) })) });
}

export async function POST(req: Request) {
  const url = new URL(req.url);
  const clientId = Number(url.searchParams.get("clientId"));
  if (!Number.isInteger(clientId) || clientId <= 0) return authJson(req, { ok: false, error: "A valid clientId is required." }, { status: 400 });
  const auth = await authorise(req, clientId, true);
  if (auth instanceof Response) return auth;

  let body: { docId?: unknown; docNo?: unknown; name?: unknown; mime?: unknown; dataBase64?: unknown };
  try {
    const raw = await req.text();
    if (raw.length > MAX_BODY) return authJson(req, { ok: false, error: "The file is too large (limit 4 MB)." }, { status: 413 });
    body = JSON.parse(raw);
  } catch {
    return authJson(req, { ok: false, error: "Invalid request body." }, { status: 400 });
  }
  const docId = String(body.docId ?? "").trim();
  const docNo = String(body.docNo ?? "").trim().slice(0, 80);
  const name = String(body.name ?? "").trim().slice(0, 160);
  const mime = String(body.mime ?? "").trim().toLowerCase();
  if (!docId || !docNo || !name) return authJson(req, { ok: false, error: "Document and file name are required." }, { status: 400 });
  if (!MIME_ALLOW.test(mime)) return authJson(req, { ok: false, error: "That file type is not accepted as accounting evidence (PDF, image, CSV, XLSX, DOCX or TXT)." }, { status: 415 });
  let bytes: Buffer;
  try {
    bytes = Buffer.from(String(body.dataBase64 ?? ""), "base64");
  } catch {
    return authJson(req, { ok: false, error: "The file could not be decoded." }, { status: 400 });
  }
  if (!bytes.length) return authJson(req, { ok: false, error: "The file is empty." }, { status: 400 });
  if (bytes.length > MAX_BYTES) return authJson(req, { ok: false, error: "The file is too large (limit 4 MB)." }, { status: 413 });

  try {
    const [row] = await db.insert(attachments).values({
      id: randomUUID(), clientId, docId, docNo, name, mime, size: bytes.length, bytes, addedBy: auth.user.username,
    }).returning({ id: attachments.id, addedAt: attachments.addedAt });
    await db.insert(auditLog).values({
      id: randomUUID(), timestamp: new Date().toISOString(), userId: auth.user.username, username: auth.user.username,
      action: "ATTACHMENT_ADDED", target: `${docNo}:${name}`, details: `${bytes.length} bytes · ${mime}`, clientId,
    });
    return authJson(req, { ok: true, id: row.id, addedAt: row.addedAt instanceof Date ? row.addedAt.toISOString() : String(row.addedAt) }, { status: 201 });
  } catch (error) {
    console.error("attachment upload failed", error);
    return authJson(req, { ok: false, error: "The document could not be stored." }, { status: 503 });
  }
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const clientId = Number(url.searchParams.get("clientId"));
  const id = String(url.searchParams.get("id") ?? "");
  if (!Number.isInteger(clientId) || clientId <= 0 || !id) return authJson(req, { ok: false, error: "clientId and id are required." }, { status: 400 });
  const auth = await authorise(req, clientId, true);
  if (auth instanceof Response) return auth;

  const row = (await db.select().from(attachments).where(and(eq(attachments.id, id), eq(attachments.clientId, clientId))).limit(1))[0];
  if (!row) return authJson(req, { ok: false, error: "Attachment not found." }, { status: 404 });
  const mayDelete = auth.user.role === "owner" || auth.user.role === "partner" || auth.user.role === "manager" || row.addedBy === auth.user.username;
  if (!mayDelete) return authJson(req, { ok: false, error: "Only the uploader, a manager or the Firm Owner may remove evidence." }, { status: 403 });

  await db.delete(attachments).where(and(eq(attachments.id, id), eq(attachments.clientId, clientId)));
  await db.insert(auditLog).values({
    id: randomUUID(), timestamp: new Date().toISOString(), userId: auth.user.username, username: auth.user.username,
    action: "ATTACHMENT_REMOVED", target: `${row.docNo}:${row.name}`, details: "Supporting document removed", clientId,
  });
  return authJson(req, { ok: true });
}
