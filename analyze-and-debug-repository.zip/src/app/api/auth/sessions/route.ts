import { and, desc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { sessions } from "@/db/schema";
import { authJson, getSessionUser, readSessionToken } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * The signed-in person's own devices.
 *
 * A forgotten laptop or a shared phone must be revocable without a support ticket
 * and without signing the user out of the device they are holding. Tokens are
 * never returned — only a short fingerprint, so the list itself cannot be used
 * to hijack a session.
 */
export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
    const current = readSessionToken(req);
    const rows = await db.select().from(sessions).where(eq(sessions.userId, user.username)).orderBy(desc(sessions.createdAt));
    const now = Date.now();
    return authJson(req, {
      ok: true,
      sessions: rows.map((row) => ({
        fingerprint: row.token.slice(0, 10),
        current: Boolean(current && row.token === current),
        createdAt: row.createdAt instanceof Date ? row.createdAt.toISOString() : String(row.createdAt),
        lastSeenAt: row.lastSeenAt ? new Date(row.lastSeenAt).toISOString() : null,
        expiresAt: new Date(row.expiresAt).toISOString(),
        expired: row.expiresAt < now,
      })),
    });
  } catch (error) {
    console.error("session list failed", error);
    return authJson(req, { ok: false, error: "Active sessions could not be read." }, { status: 503 });
  }
}

/** Revokes every OTHER device for the signed-in account (this one stays signed in). */
export async function DELETE(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
    const current = readSessionToken(req);
    if (!current) return authJson(req, { ok: false, error: "No current session token." }, { status: 400 });
    const removed = await db.delete(sessions)
      .where(and(eq(sessions.userId, user.username), ne(sessions.token, current)))
      .returning({ token: sessions.token });
    return authJson(req, { ok: true, revoked: removed.length });
  } catch (error) {
    console.error("session revocation failed", error);
    return authJson(req, { ok: false, error: "Other devices could not be signed out." }, { status: 503 });
  }
}
