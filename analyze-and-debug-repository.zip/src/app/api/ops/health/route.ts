import { desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { opsEvents } from "@/db/schema";
import { authJson, requireOwner } from "@/lib/auth";
import { getBackupStatus } from "@/lib/backupService";

export const dynamic = "force-dynamic";

/** Owner-only operational health: DB latency, backup freshness and recent alerts. */
export async function GET(req: Request) {
  const owner = await requireOwner(req);
  if (!owner) return authJson(req, { ok: false, error: "Owner access required." }, { status: 403 });
  const started = performance.now();
  let database: "ok" | "error" = "ok";
  let databaseError: string | undefined;
  try {
    await db.execute(sql`select now()`);
  } catch (error) {
    database = "error";
    databaseError = error instanceof Error ? error.message : "Database unavailable";
  }
  const latencyMs = Math.round(performance.now() - started);
  const backup = await getBackupStatus();
  const backupAgeHours = backup.lastSuccessAt ? (Date.now() - Date.parse(backup.lastSuccessAt)) / 3_600_000 : null;
  const staleHours = Number(process.env.BPZ_BACKUP_STALE_HOURS || 26);
  const backupStale = backupAgeHours === null || backupAgeHours > staleHours;
  const events = await db.select().from(opsEvents).orderBy(desc(opsEvents.at)).limit(25);
  return authJson(req, {
    ok: database === "ok",
    database,
    databaseError,
    latencyMs,
    backup: { ...backup, ageHours: backupAgeHours, stale: backupStale, staleAfterHours: staleHours },
    events: events.map((event) => ({ ...event, at: event.at instanceof Date ? event.at.toISOString() : String(event.at) })),
    checkedAt: new Date().toISOString(),
  });
}
