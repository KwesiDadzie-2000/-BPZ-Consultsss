import { useEffect, useRef, useState } from 'react';
import type { UserAccount } from '../types/accounting';
import { apiFetch, broadcastSessionChange, clearSessionStore, setSession } from '../utils/session';
import { Lock, User, ShieldAlert, KeyRound, Building2 } from 'lucide-react';
import { isLocalReview } from '../preview/config';
import { INITIAL_USERS } from '../data/accountingSeed';

/** Workspace the sign-in is bound to (from a client's `?workspace=CODE` link). */
export interface WorkspaceRef {
  id: number;
  code: string;
  name: string;
}

import type { ClientEntity } from '../types/accounting';

interface LoginScreenProps {
  /** Called with the signed-in user; `workspace` is present when the link named one, `client` is the user's bound entity. */
  onLogin: (user: UserAccount, workspace?: WorkspaceRef | null, client?: ClientEntity | null) => void;
  /** Explains why the user was returned to sign-in (e.g. an expired session). */
  notice?: string | null;
  /** Client workspace code taken from the sign-in link, if any. */
  workspaceCode?: string | null;
}

/**
 * Sign-in form.
 *
 * Sign-in only ever happens here. Lockout is enforced by the SERVER per account
 * (5 failed attempts → 5 minutes), not by a counter kept in browser storage: a
 * browser-wide counter locked every account on the machine when one person
 * mistyped, which is why clients were told their password was wrong.
 */
export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, notice, workspaceCode }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  // First-run owner activation (fresh database, no operator-supplied password).
  const [setup, setSetup] = useState<{ available: boolean; tokenRequired: boolean; owner: string | null } | null>(null);
  const [showSignIn, setShowSignIn] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [setupToken, setSetupToken] = useState('');
  const [mfaRequired, setMfaRequired] = useState(false);
  const [otp, setOtp] = useState('');
  const [enrollment, setEnrollment] = useState<{ secret: string; otpauthUri: string } | null>(null);
  const passwordRef = useRef<HTMLInputElement | null>(null);

  // Browsers sometimes autofill a SAVED password (typically the owner's, which was
  // used minutes earlier on the same machine) into this form. Clear it on mount and
  // again shortly after, so a client never submits someone else's credential.
  useEffect(() => {
    const timer = window.setTimeout(() => {
      if (passwordRef.current) passwordRef.current.value = '';
      setPassword('');
    }, 400);
    return () => window.clearTimeout(timer);
  }, [workspaceCode]);

  useEffect(() => {
    if (isLocalReview()) return;
    let cancelled = false;
    apiFetch('/api/auth/setup')
      .then((r) => r.json())
      .then((b) => { if (!cancelled && b?.ok) setSetup({ available: Boolean(b.activationAvailable), tokenRequired: Boolean(b.tokenRequired), owner: b.ownerUsername ?? null }); })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);

  const activate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (newPassword !== confirmPassword) { setError('The two passwords do not match.'); return; }
    setBusy(true);
    try {
      const res = await apiFetch('/api/auth/setup', { method: 'POST', body: JSON.stringify({ password: newPassword, confirm: confirmPassword, setupToken }) });
      const body = await res.json().catch(() => null);
      if (!res.ok || !body?.ok) {
        setError(body?.error || 'Activation failed.');
        if (res.status === 409) setSetup((s) => (s ? { ...s, available: false } : s));
        return;
      }
      setSession(String(body.token || ''), body.user);
      broadcastSessionChange(true);
      if (body.mfaEnroll) {
        // Do not enter the workspace until the required second factor is proven.
        setEnrollment(body.mfaEnroll);
        setMfaRequired(true);
        setUsername(setup?.owner || 'owner');
        setPassword(newPassword);
        setError('Add the account to your authenticator app, then enter its 6-digit code below.');
        return;
      }
      onLogin(body.user as UserAccount, null);
    } catch {
      setError('Could not reach the activation service. Try again.');
    } finally {
      setBusy(false);
    }
  };
  const activating = Boolean(setup?.available) && !showSignIn && !enrollment;

  const tryLogin = async (uInput: string, pInput: string) => {
    setError(null);
    setBusy(true);
    try {
      const res = await apiFetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ usernameOrEmail: uInput.trim(), password: pInput, workspace: workspaceCode ?? undefined, otp: mfaRequired ? otp.trim() : undefined }),
      });
      const body = await res.json().catch(() => null);
      if (body?.mfaRequired) {
        // Password accepted; the account needs its second factor. Keep the
        // password in the form so the user only types the 6-digit code. An
        // unenrolled account receives a short-lived enrolment-only grant here.
        if (body.enrollToken) setSession(String(body.enrollToken), null);
        if (body.secret && body.otpauthUri) setEnrollment({ secret: String(body.secret), otpauthUri: String(body.otpauthUri) });
        setMfaRequired(true);
        setOtp('');
        setError(body?.error || 'Enter the 6-digit code from your authenticator app.');
        return;
      }
      if (!res.ok || !body?.ok) {
        setPassword('');
        setMfaRequired(false);
        setError(
          body?.error ||
            (res.status >= 500
              ? 'The sign-in service is temporarily unavailable. Please try again in a moment.'
              : 'Invalid username, email, or password.')
        );
        return;
      }
      const found = body.user as UserAccount;
      setMfaRequired(false);
      setEnrollment(null);
      setOtp('');
      // Store the token first (mirrored in sessionStorage + localStorage), then
      // hand the user to the workspace. The server has also set an HttpOnly cookie.
      setSession(String(body.token || ''), found);
      broadcastSessionChange(true);
      onLogin(
        found,
        (body.workspace as WorkspaceRef | undefined) ?? null,
        (body.client as ClientEntity | undefined) ?? null
      );
    } catch {
      setError('Could not reach the sign-in service. Try again.');
    } finally {
      setBusy(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void tryLogin(username, password);
  };

  return (
    <div className="min-h-screen bg-[#f0f6fc] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-6">
          <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#f5b719] font-black text-[#082f4f] text-lg shadow-md">
            BPZ
          </span>
          <h1 className="mt-3 text-xl font-black text-[#082f4f]">BPZ Consult</h1>
          <p className="text-xs text-[#355875] font-semibold mt-0.5">Sign in to your workspace</p>
        </div>

        <div className="rounded-2xl border border-sky-200 bg-white p-6 shadow-sm space-y-4">
          {workspaceCode && !activating && (
            <div className="rounded-lg border border-sky-300 bg-sky-50 px-3 py-2 text-[11px] font-semibold text-[#0a4a6e] flex items-start gap-2">
              <Building2 className="h-4 w-4 mt-0.5 text-[#082f4f] shrink-0" />
              <span>
                <strong>Client workspace sign-in · {workspaceCode}.</strong> Use the username and password issued to you for this workspace only. Passwords are case-sensitive.
              </span>
            </div>
          )}

          <div className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-[11px] font-bold text-amber-900 flex items-start gap-2">
            <ShieldAlert className="h-4 w-4 mt-0.5 text-amber-700 shrink-0" />
            <span>{isLocalReview() ? 'Local review workspace. Sample data is saved only in this browser. No production authentication or database is connected.' : 'Secure sign-in: credentials are verified on the server (scrypt-hashed, per-user salt).'}</span>
          </div>

          {notice && !error && (
            <div className="rounded-lg border border-sky-300 bg-sky-50 px-3 py-2 text-[11px] font-bold text-[#0a4a6e]">{notice}</div>
          )}

          {error && (
            <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-800">{error}</div>
          )}

          {activating && (
            <form onSubmit={activate} className="space-y-3" aria-labelledby="activation-title">
              <div className="rounded-lg border border-sky-300 bg-sky-50 px-3 py-2 text-[11px] font-semibold text-[#0a4a6e]">
                <div id="activation-title" className="flex items-center gap-1.5 font-black uppercase tracking-wider"><KeyRound className="h-3.5 w-3.5" />First-run activation</div>
                This workspace has not been activated. Set the password for the owner account <strong>{setup?.owner}</strong>. This one-time step is audit-logged and then permanently closed.
              </div>
              {setup?.tokenRequired && (
                <div>
                  <label htmlFor="setup-token" className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">Setup token</label>
                  <input id="setup-token" type="password" value={setupToken} onChange={(e) => setSetupToken(e.target.value)} required autoComplete="off" className="w-full rounded-lg border border-sky-300 bg-white px-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]" />
                </div>
              )}
              <div>
                <label htmlFor="setup-password" className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">New owner password</label>
                <input id="setup-password" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength={10} autoComplete="new-password" aria-describedby="setup-password-hint" className="w-full rounded-lg border border-sky-300 bg-white px-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]" />
                <p id="setup-password-hint" className="mt-1 text-[10.5px] text-[#355875]">At least 10 characters with upper and lower case, a digit and a symbol.</p>
              </div>
              <div>
                <label htmlFor="setup-confirm" className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">Confirm password</label>
                <input id="setup-confirm" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required minLength={10} autoComplete="new-password" className="w-full rounded-lg border border-sky-300 bg-white px-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]" />
              </div>
              <button type="submit" disabled={busy} className="w-full rounded-lg bg-[#082f4f] py-2.5 text-sm font-bold text-white hover:bg-[#0c3f68] transition disabled:opacity-60">{busy ? 'Activating…' : 'Activate workspace & sign in'}</button>
              <button type="button" onClick={() => setShowSignIn(true)} className="w-full text-[11px] font-bold text-[#355875] underline">I already have credentials — sign in</button>
            </form>
          )}

          {enrollment && (
            <div className="rounded-lg border border-emerald-300 bg-emerald-50 px-3 py-3 text-[11px] font-semibold text-emerald-950 space-y-2">
              <p className="font-black">Required: enroll multi-factor authentication</p>
              <p>Scan this setup key in your authenticator app, then submit the 6-digit code below. Your owner account will not be accessible without it.</p>
              <div className="rounded border border-emerald-300 bg-white p-2 font-mono text-sm font-black tracking-widest break-all select-all">{enrollment.secret}</div>
              <a href={enrollment.otpauthUri} className="inline-block font-bold text-[#006f98] underline">Open in authenticator (mobile)</a>
            </div>
          )}

          {activating ? null : isLocalReview() ? <button type="button" onClick={() => onLogin({ ...INITIAL_USERS[0], password: undefined }, null)} className="w-full rounded-lg bg-[#082f4f] py-2.5 text-sm font-bold text-white hover:bg-[#0c3f68] transition">Open review workspace</button> : <form onSubmit={handleSubmit} className="space-y-3" autoComplete="off">
            <div>
              <label htmlFor="login-username" className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">Username or email</label>
              <div className="relative">
                <User className="absolute left-2.5 top-2 h-4 w-4 text-sky-400" />
                <input
                  type="text"
                  id="login-username"
                  name="bpz-login-user"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Username or email"
                  className="w-full rounded-lg border border-sky-300 bg-white pl-8 pr-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]"
                  required
                  autoComplete="username"
                  autoCapitalize="none"
                  spellCheck={false}
                />
              </div>
            </div>

            <div>
              <label htmlFor="login-password" className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-2.5 top-2 h-4 w-4 text-sky-400" />
                <input
                  ref={passwordRef}
                  type="password"
                  id="login-password"
                  name="bpz-login-passcode"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full rounded-lg border border-sky-300 bg-white pl-8 pr-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]"
                  required
                  autoComplete="new-password"
                />
              </div>
            </div>

            {mfaRequired && (
              <div>
                <label htmlFor="login-otp" className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">Authenticator code</label>
                <input
                  id="login-otp"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  pattern="[0-9]{6}"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  placeholder="6-digit code"
                  autoFocus
                  className="w-full rounded-lg border border-sky-300 bg-white px-3 py-2 text-center font-mono text-lg tracking-[0.4em] font-bold text-[#082f4f] outline-none focus:border-[#082f4f]"
                  required
                />
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-lg bg-[#082f4f] py-2.5 text-sm font-bold text-white hover:bg-[#0c3f68] transition disabled:opacity-60"
            >
              {busy ? 'Signing in…' : mfaRequired ? 'Verify & Sign In' : 'Sign In'}
            </button>
          </form>}

          <p className="text-[10.5px] text-[#355875] text-center">
            {isLocalReview() ? 'The original BPZ template is retained. Do not enter real client information in this preview.' : 'Sessions stay active for 8 hours and renew automatically while you work. After 5 failed attempts on an account, that account is locked for 5 minutes. Forgotten password? Ask your firm owner to reset it.'}
          </p>
        </div>
      </div>
    </div>
  );
};

/** Revokes the server session, clears every local copy, and tells other tabs. */
export const clearSession = () => {
  apiFetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
  clearSessionStore();
  broadcastSessionChange(false);
};
