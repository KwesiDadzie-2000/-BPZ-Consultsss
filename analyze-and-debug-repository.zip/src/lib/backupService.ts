import { createHash } from "node:crypto";
import { mkdir, readdir, readFile, stat, writeFile } from "node:fs/promises";
import { basename, join } from "node:path";
import { gzipSync } from "node:zlib";
import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { db, pool } from "@/db";
import { systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { recordOpsEvent } from "@/lib/monitoring";

export interface BackupStatus {
  lastAttemptAt?: string;
  lastSuccessAt?: string;
  lastError?: string;
  file?: string;
  offsite?: "uploaded" | "local-only" | "not-configured" | "failed";
  offsiteUri?: string;
  tableCount?: number;
  rowCount?: number;
  sha256?: string;
}

export interface BackupPayload {
  app: "bpz-consult-erp";
  version: 1;
  createdAt: string;
  tables: Record<string, Record<string, unknown>[]>;
}

const TRANSIENT_AUTH_TABLES = new Set(["bpz_sessions", "bpz_login_attempts"]);
const BACKUP_LOCK = 4_027_339;

/** Repeatable-read snapshot: every table belongs to one consistent point in time. */
export async function snapshotDatabase(): Promise<{ payload: BackupPayload; tableCount: number; rowCount: number }> {
  const connection = await pool.connect();
  const tables: Record<string, Record<string, unknown>[]> = {};
  let rowCount = 0;
  try {
    await connection.query("begin transaction isolation level repeatable read read only");
    const result = await connection.query<{ table_name: string }>(
      `select table_name from information_schema.tables where table_schema = 'public' and table_type = 'BASE TABLE' order by table_name`,
    );
    for (const { table_name } of result.rows) {
      if (TRANSIENT_AUTH_TABLES.has(table_name)) continue;
      const quoted = `"${table_name.replaceAll('"', '""')}"`;
      const rows = await connection.query(`select * from ${quoted}`);
      tables[table_name] = rows.rows as Record<string, unknown>[];
      rowCount += rows.rowCount ?? rows.rows.length;
    }
    await connection.query("commit");
  } catch (error) {
    await connection.query("rollback").catch(() => undefined);
    throw error;
  } finally {
    connection.release();
  }
  return {
    payload: { app: "bpz-consult-erp", version: 1, createdAt: new Date().toISOString(), tables },
    tableCount: Object.keys(tables).length,
    rowCount,
  };
}

export async function getBackupStatus(): Promise<BackupStatus> {
  const row = (await db.select({ value: systemSettings.value }).from(systemSettings)
    .where(eq(systemSettings.key, "backup_status")).limit(1))[0];
  return (row?.value ?? {}) as BackupStatus;
}

async function setBackupStatus(status: BackupStatus): Promise<void> {
  await db.insert(systemSettings).values({ key: "backup_status", value: status }).onConflictDoUpdate({
    target: systemSettings.key,
    set: { value: status, updatedAt: new Date() },
  });
}

function s3Configured(): boolean {
  return Boolean(process.env.S3_BUCKET && process.env.S3_ACCESS_KEY_ID && process.env.S3_SECRET_ACCESS_KEY);
}

async function uploadOffsite(file: string, bytes: Buffer): Promise<string> {
  const bucket = process.env.S3_BUCKET!;
  const prefix = (process.env.S3_PREFIX || "bpz/").replace(/^\/+|\/+$/g, "");
  const key = `${prefix ? `${prefix}/` : ""}${basename(file)}`;
  const client = new S3Client({
    region: process.env.S3_REGION || "auto",
    endpoint: process.env.S3_ENDPOINT || undefined,
    forcePathStyle: process.env.S3_FORCE_PATH_STYLE === "true",
    credentials: {
      accessKeyId: process.env.S3_ACCESS_KEY_ID!,
      secretAccessKey: process.env.S3_SECRET_ACCESS_KEY!,
    },
  });
  await client.send(new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: bytes,
    ContentType: "application/gzip",
    ServerSideEncryption: "AES256",
  }));
  return `s3://${bucket}/${key}`;
}

export async function createBackup(): Promise<{
  file: string;
  tableCount: number;
  rowCount: number;
  sha256: string;
  offsite: BackupStatus["offsite"];
  offsiteUri?: string;
}> {
  // Provision monitoring/rate-limit tables before logging the snapshot itself.
  const { ensureSchema } = await import("@/db/bootstrap");
  await ensureSchema();
  const dir = process.env.BPZ_BACKUP_DIR || "./backups";
  const keep = Math.max(1, Number(process.env.BPZ_BACKUP_KEEP || 14));
  const { payload, tableCount, rowCount } = await snapshotDatabase();
  const bytes = gzipSync(Buffer.from(JSON.stringify(payload), "utf8"));
  await mkdir(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const file = join(dir, `bpz-backup-${stamp}.json.gz`);
  await writeFile(file, bytes);
  const sha256 = createHash("sha256").update(bytes).digest("hex");

  let offsite: BackupStatus["offsite"] = s3Configured() ? "uploaded" : "not-configured";
  let offsiteUri: string | undefined;
  let lastError: string | undefined;
  if (s3Configured()) {
    try {
      offsiteUri = await uploadOffsite(file, bytes);
    } catch (error) {
      offsite = "failed";
      lastError = error instanceof Error ? error.message : "Off-site upload failed";
      await recordOpsEvent("error", "backup.offsite.failed", { message: lastError, file });
    }
  } else {
    offsite = "local-only";
  }
  if (process.env.BPZ_REQUIRE_OFFSITE_BACKUP === "true" && offsite !== "uploaded") {
    const message = offsite === "failed" ? lastError! : "S3 off-site backup is required but not configured.";
    await setBackupStatus({ lastAttemptAt: new Date().toISOString(), lastError: message, file, offsite, tableCount, rowCount, sha256 });
    await recordOpsEvent("error", "backup.failed", { message, file });
    throw new Error(message);
  }

  // Prune only after the local file and any required off-site copy are durable.
  const files = (await readdir(dir)).filter((f) => f.startsWith("bpz-backup-") && f.endsWith(".json.gz")).sort();
  const stale = files.slice(0, Math.max(0, files.length - keep));
  const { rm } = await import("node:fs/promises");
  for (const old of stale) await rm(join(dir, old), { force: true });

  await setBackupStatus({
    lastAttemptAt: new Date().toISOString(), lastSuccessAt: new Date().toISOString(),
    lastError, file, offsite, offsiteUri, tableCount, rowCount, sha256,
  });
  await recordOpsEvent(offsite === "failed" ? "warn" : "info", "backup.completed", {
    file, tableCount, rowCount, offsite, offsiteUri,
  });
  return { file, tableCount, rowCount, sha256, offsite, offsiteUri };
}

export async function listLocalBackups() {
  const dir = process.env.BPZ_BACKUP_DIR || "./backups";
  try {
    const names = (await readdir(dir)).filter((f) => f.startsWith("bpz-backup-") && f.endsWith(".json.gz")).sort().reverse();
    return await Promise.all(names.map(async (name) => {
      const info = await stat(join(dir, name));
      return { name, bytes: info.size, modifiedAt: info.mtime.toISOString() };
    }));
  } catch {
    return [];
  }
}

let schedulerStarted = false;

/** Start the idempotent daily worker. A DB try-lock prevents duplicate instances. */
export function ensureBackupScheduler(): void {
  if (schedulerStarted || process.env.BPZ_BACKUP_SCHEDULE_ENABLED !== "true") return;
  schedulerStarted = true;
  const tick = async () => {
    const client = await pool.connect();
    try {
      const lock = await client.query<{ acquired: boolean }>(`select pg_try_advisory_lock(${BACKUP_LOCK}) as acquired`);
      if (!lock.rows[0]?.acquired) return;
      const status = await getBackupStatus();
      const intervalMs = Math.max(1, Number(process.env.BPZ_BACKUP_INTERVAL_HOURS || 24)) * 60 * 60 * 1000;
      const last = status.lastSuccessAt ? Date.parse(status.lastSuccessAt) : 0;
      if (Date.now() - last < intervalMs) return;
      await createBackup();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Scheduled backup failed";
      console.error("[backup] scheduled run failed", message);
      await recordOpsEvent("error", "backup.failed", { message, scheduled: true });
      await setBackupStatus({ ...(await getBackupStatus()), lastAttemptAt: new Date().toISOString(), lastError: message });
    } finally {
      try { await client.query(`select pg_advisory_unlock(${BACKUP_LOCK})`); } catch { /* connection close releases it */ }
      client.release();
    }
  };
  void tick();
  const timer = setInterval(() => { void tick(); }, 60 * 60 * 1000);
  timer.unref();
}

/** Read a local backup for verification without changing any data. */
export async function readBackupFile(file: string): Promise<BackupPayload> {
  const raw = await readFile(file);
  const { gunzipSync } = await import("node:zlib");
  return JSON.parse(file.endsWith(".gz") ? gunzipSync(raw).toString("utf8") : raw.toString("utf8")) as BackupPayload;
}

/** Optional operator restore of an off-site object into a local file. */
export async function downloadOffsiteBackup(uri: string, destination: string): Promise<void> {
  const match = /^s3:\/\/([^/]+)\/(.+)$/.exec(uri);
  if (!match) throw new Error("An s3://bucket/key URI is required.");
  const client = new S3Client({
    region: process.env.S3_REGION || "auto",
    endpoint: process.env.S3_ENDPOINT || undefined,
    forcePathStyle: process.env.S3_FORCE_PATH_STYLE === "true",
    credentials: { accessKeyId: process.env.S3_ACCESS_KEY_ID!, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY! },
  });
  const result = await client.send(new GetObjectCommand({ Bucket: match[1], Key: match[2] }));
  if (!result.Body) throw new Error("The off-site backup object was empty.");
  await writeFile(destination, Buffer.from(await result.Body.transformToByteArray()));
}
