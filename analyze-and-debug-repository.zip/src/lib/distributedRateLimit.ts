import { sql } from "drizzle-orm";
import { db } from "@/db";
import { acquireRateLimit, type RateLimitResult } from "@/lib/rateLimit";

/**
 * PostgreSQL-backed token bucket. The row is updated under a transaction-scoped
 * advisory lock, so concurrent requests on one instance OR many instances share
 * the same budget. If the DB is briefly unavailable, the in-memory limiter is a
 * deliberate availability fallback; the hard login lockout is independent.
 */
export async function acquireDistributedRateLimit(
  key: string,
  limit: number,
  refillPerSecond: number,
): Promise<RateLimitResult> {
  const safeKey = key.slice(0, 200);
  try {
    return await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${safeKey}))`);
      const now = Date.now();
      const existing = await tx.execute<{ tokens: number | string; updated_at: string | number; locked_until: string | number }>(
        sql`select tokens, updated_at, locked_until from bpz_rate_limits where key = ${safeKey} for update`,
      );
      const previous = existing.rows[0];
      let tokens = limit;
      if (previous) {
        const elapsed = Math.max(0, (now - Number(previous.updated_at)) / 1000);
        tokens = Math.min(limit, Number(previous.tokens) + elapsed * refillPerSecond);
      }
      const lockedUntil = Number(previous?.locked_until ?? 0);
      if (lockedUntil > now) {
        return { allowed: false, retryAfterSeconds: Math.max(1, Math.ceil((lockedUntil - now) / 1000)) };
      }
      if (tokens < 1) {
        const retryAfterSeconds = Math.max(1, Math.ceil((1 - tokens) / (refillPerSecond || 1)));
        const lockUntil = now + retryAfterSeconds * 1000;
        await tx.execute(sql`update bpz_rate_limits set tokens = ${tokens}, updated_at = ${now}, locked_until = ${lockUntil} where key = ${safeKey}`);
        return { allowed: false, retryAfterSeconds };
      }
      const nextTokens = tokens - 1;
      await tx.execute(sql`
        insert into bpz_rate_limits (key, tokens, updated_at, locked_until)
        values (${safeKey}, ${nextTokens}, ${now}, 0)
        on conflict (key) do update set tokens = ${nextTokens}, updated_at = ${now}, locked_until = 0
      `);
      return { allowed: true, retryAfterSeconds: 0 };
    });
  } catch (error) {
    console.warn("[rate-limit] distributed bucket unavailable; using local fallback", error instanceof Error ? error.message : error);
    return acquireRateLimit(safeKey, limit, refillPerSecond);
  }
}
