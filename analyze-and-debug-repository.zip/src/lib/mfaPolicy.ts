/**
 * MFA policy. Production deployments should set both flags to true in .env.
 * Demo mode intentionally leaves them off so the supplied review accounts work.
 */
export function mfaRequiredFor(user: { role: string; canCheck?: boolean }): boolean {
  const ownerRequired = process.env.BPZ_ENFORCE_MFA_OWNER === "true" && user.role === "owner";
  const checkerRequired = process.env.BPZ_ENFORCE_MFA_CHECKERS === "true" && Boolean(user.canCheck);
  return ownerRequired || checkerRequired;
}
