import { randomUUID } from "node:crypto";
import { db } from "@/db";
import { opsEvents } from "@/db/schema";

/** Structured operational event log; failures must never break a request. */
export async function recordOpsEvent(
  level: "info" | "warn" | "error",
  event: string,
  detail: Record<string, unknown> = {},
): Promise<void> {
  try {
    await db.insert(opsEvents).values({
      id: randomUUID(), level, event, detail, at: new Date(),
    });
  } catch (error) {
    console.error("[ops] event write failed", error);
  }
  if (level === "error") await sendOpsAlert(event, detail);
}

/** Optional outbound alert webhook (Slack/Teams/Better Stack/custom collector). */
export async function sendOpsAlert(event: string, detail: Record<string, unknown>): Promise<void> {
  const url = process.env.BPZ_ALERT_WEBHOOK_URL;
  if (!url) return;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        text: `BPZ Consult alert: ${event}`,
        event,
        detail,
        at: new Date().toISOString(),
      }),
      signal: controller.signal,
    });
    clearTimeout(timer);
  } catch (error) {
    console.error("[ops] alert webhook failed", error);
  }
}
