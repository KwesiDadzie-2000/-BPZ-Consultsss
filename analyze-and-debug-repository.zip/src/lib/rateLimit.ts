/**
 * Shared in-process rate limiter for high-abuse endpoints (mail/SMTP relay,
 * sign-in, heavy POSTs). In-memory sliding-window token bucket per identifier.
 *
 * It is deliberately simple and fails closed on memory pressure: when the map is
 * full it drops the oldest bucket and allows the request rather than risk a 500
 * on every request. This is the soft, per-IP throttle that stops SMTP relay
 * abuse and credential-stuffing floods before they reach the expensive handlers;
 * the DB-backed login lockout (5 failed attempts → 5 min) remains the hard control.
 */
interface Bucket {
  tokens: number;
  updatedAt: number;
  max: number;
  refillPerSec: number;
}

const buckets = new Map<string, Bucket>();
const MAX_BUCKETS = 10_000;
const SWEEP_INTERVAL_MS = 60_000;
let lastSweep = Date.now();

function sweep(now: number): void {
  if (now - lastSweep < SWEEP_INTERVAL_MS) return;
  lastSweep = now;
  for (const [key, b] of buckets) {
    const age = now - b.updatedAt;
    if (age > 60_000) buckets.delete(key);
    else b.tokens = Math.min(b.max, b.tokens + (age / 1000) * b.refillPerSec);
  }
}

export interface RateLimitResult {
  allowed: boolean;
  retryAfterSeconds: number;
}

/** Sliding-window token bucket per key. A failed acquire never throws. */
export function acquireRateLimit(key: string, limit: number, refillPerSecond: number): RateLimitResult {
  const now = Date.now();
  sweep(now);
  let bucket = buckets.get(key);
  if (!bucket) {
    if (buckets.size >= MAX_BUCKETS) {
      const oldest = buckets.keys().next().value;
      if (oldest !== undefined) buckets.delete(oldest);
      return { allowed: true, retryAfterSeconds: 0 };
    }
    bucket = { tokens: limit, updatedAt: now, max: limit, refillPerSec: refillPerSecond };
    buckets.set(key, bucket);
  }
  const elapsedSec = (now - bucket.updatedAt) / 1000;
  bucket.tokens = Math.min(bucket.max, bucket.tokens + elapsedSec * bucket.refillPerSec);
  bucket.updatedAt = now;
  if (bucket.tokens >= 1) {
    bucket.tokens -= 1;
    return { allowed: true, retryAfterSeconds: 0 };
  }
  const retryAfterSeconds = Math.ceil((1 - bucket.tokens) / (bucket.refillPerSec || 1));
  return { allowed: false, retryAfterSeconds };
}

/** Best-effort client IP (first X-Forwarded-For hop or "unknown"). */
export function rateLimitKey(req: Request, salt: string): string {
  const fwd = req.headers.get("x-forwarded-for");
  const ip = fwd ? fwd.split(",")[0].trim() || "unknown" : "unknown";
  return `${salt}:${ip}`;
}

/** Enforce a rate limit. Returns a 429 Response when throttled, otherwise null. */
export function rateLimitResponse(req: Request, salt: string, limit: number, refillPerSecond: number): Response | null {
  const result = acquireRateLimit(rateLimitKey(req, salt), limit, refillPerSecond);
  if (result.allowed) return null;
  return new Response(
    JSON.stringify({ ok: false, error: `Too many requests. Try again in ${result.retryAfterSeconds}s.` }),
    {
      status: 429,
      headers: {
        "content-type": "application/json",
        "cache-control": "no-store",
        "retry-after": String(result.retryAfterSeconds),
      },
    },
  );
}

/** Test helper: clear all buckets. */
export function __resetRateLimits(): void {
  buckets.clear();
  lastSweep = Date.now();
}
