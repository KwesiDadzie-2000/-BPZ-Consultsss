import { NextResponse, type NextRequest } from "next/server";

/**
 * Cross-site request forgery guard.
 *
 * The session rides in an HttpOnly cookie, which the browser attaches to any
 * request — including one triggered by a hostile page. SameSite=Lax already
 * blocks most of this, but a preview embedded in a cross-site frame is issued
 * SameSite=None, so the cookie alone is not enough. Any state-changing API call
 * whose Origin does not belong to this host is refused before it reaches a route
 * handler; safe methods (GET/HEAD/OPTIONS) are untouched.
 */
const MUTATING = new Set(["POST", "PUT", "PATCH", "DELETE"]);

export function middleware(req: NextRequest) {
  if (!MUTATING.has(req.method)) return NextResponse.next();
  const origin = req.headers.get("origin");
  // No Origin header: a same-origin navigation or a non-browser client that
  // cannot read this cookie jar. Nothing to compare, so continue.
  if (!origin) return NextResponse.next();

  const site = (req.headers.get("sec-fetch-site") || "").toLowerCase();
  if (site === "same-origin" || site === "same-site" || site === "none") return NextResponse.next();

  const allowedHosts = new Set(
    [req.headers.get("host"), req.headers.get("x-forwarded-host")]
      .filter((h): h is string => Boolean(h))
      .map((h) => h.toLowerCase()),
  );
  try {
    if (allowedHosts.has(new URL(origin).host.toLowerCase())) return NextResponse.next();
  } catch {
    /* malformed Origin falls through to the refusal below */
  }
  return NextResponse.json(
    { ok: false, error: "Cross-site request refused. Sign in through this workspace and retry." },
    { status: 403, headers: { "cache-control": "no-store" } },
  );
}

export const config = { matcher: "/api/:path*" };
