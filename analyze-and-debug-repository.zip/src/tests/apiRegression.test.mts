import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import type { ACDOCALine } from '../types/accounting';

// This destructive fixture is deliberately restricted to a disposable local DB.
const url = process.env.BPZ_TEST_DATABASE_URL;
if (!url) throw new Error('Set BPZ_TEST_DATABASE_URL to the disposable local bpz_review_test database.');
const parsed = new URL(url);
if (!['localhost', '127.0.0.1'].includes(parsed.hostname) || parsed.pathname !== '/bpz_review_test') {
  throw new Error('Refusing to run against anything except a local bpz_review_test database.');
}
process.env.DATABASE_URL = url;
process.env.BPZ_SEED_PASSWORD_OWNER = `Review-${randomUUID()}!`;
process.env.BPZ_SEED_PASSWORD_DEMO = `Review-${randomUUID()}!`;

const { pool } = await import('../db');
await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
const login = await import('../app/api/auth/login/route');
const session = await import('../app/api/auth/session/route');
const logout = await import('../app/api/auth/logout/route');
const journal = await import('../app/api/journal/route');
const state = await import('../app/api/state/route');
const bootstrap = await import('../app/api/bootstrap/route');

type Handler = (request: Request) => Promise<Response>;
const call = (handler: Handler, method: string, body?: unknown, token?: string) => handler(new Request('http://localhost/api/test', {
  method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  ...(body === undefined ? {} : { body: JSON.stringify(body) }),
}));
let passed = 0;
let failed = 0;
async function check(title: string, action: () => Promise<void>) {
  try { await action(); passed++; console.log(`PASS ${title}`); }
  catch (error) { failed++; console.error(`FAIL ${title}`, error); }
}
const base: ACDOCALine = {
  id: '', docNo: '', period: '2026-10', date: '2026-10-29', module: 'FI', docType: 'JE',
  accountNo: '100000', accountName: 'Bank', debit: 100, credit: 0, currency: 'GHS',
  description: 'Isolated integration test', createdBy: 'owner', clientId: 2,
};
const pair = (docNo: string, overrides: Partial<ACDOCALine> = {}): ACDOCALine[] => [
  { ...base, ...overrides, docNo, id: `${docNo}-a` },
  { ...base, ...overrides, docNo, id: `${docNo}-b`, accountNo: '400000', debit: 0, credit: overrides.debit || 100 },
];
const auth = await call(login.POST, 'POST', { usernameOrEmail: 'owner', password: process.env.BPZ_SEED_PASSWORD_OWNER });
assert.equal(auth.status, 200, JSON.stringify(await auth.clone().json()));
const { token: owner } = await auth.json();
const demoResponse = await call(login.POST, 'POST', { usernameOrEmail: 'demo', password: process.env.BPZ_SEED_PASSWORD_DEMO });
const { token: demo } = await demoResponse.json();
const workspace = async (token = owner) => {
  const response = await call(bootstrap.GET, 'GET', undefined, token);
  assert.equal(response.status, 200);
  return (await response.json()).state;
};
const original = pair('INTEGRATION-001');

await check('configured server login creates a secure cookie', async () => {
  assert.match(auth.headers.get('set-cookie')!, /HttpOnly/);
  const response = await call(session.GET, 'GET', undefined, owner);
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.user.password, undefined); assert.equal(body.user.passwordHash, undefined);
});
await check('public legacy seed credentials no longer authenticate', async () => {
  assert.equal((await call(login.POST, 'POST', { usernameOrEmail: 'owner', password: 'BpzOwner2026!' })).status, 401);
});
await check('unauthenticated journal writes are rejected', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: original })).status, 401);
});
await check('balanced owner journal posts', async () => {
  const response = await call(journal.POST, 'POST', { lines: original }, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
});
await check('journal replay is idempotent', async () => {
  const response = await call(journal.POST, 'POST', { lines: original }, owner);
  assert.equal(response.status, 200); assert.equal((await response.json()).idempotent, true);
});
await check('same document with changed amounts is refused', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: original.map((line) => ({ ...line, debit: line.debit * 2, credit: line.credit * 2 })) }, owner)).status, 409);
});
await check('posting date and accounting period must agree', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: pair('INTEGRATION-DATE', { period: '2026-09' }) }, owner)).status, 409);
});
await check('maker cannot forge an authorised checker approval', async () => {
  const lines = pair('INTEGRATION-SPOOF', { createdBy: 'demo', checkedBy: 'checker_kofi', debit: 90000 });
  assert.equal((await call(journal.POST, 'POST', { lines }, demo)).status, 403);
});
await check('authenticated independent checker can post on behalf of maker', async () => {
  const lines = pair('INTEGRATION-APPROVED', { createdBy: 'demo', checkedBy: 'owner', debit: 90000 });
  const response = await call(journal.POST, 'POST', { lines }, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
});
await check('cross-tenant posting is blocked', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: pair('INTEGRATION-TENANT', { createdBy: 'demo', clientId: 3 }) }, demo)).status, 403);
});
await check('unchanged full-state sync succeeds', async () => {
  const response = await call(state.PUT, 'PUT', await workspace(), owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
});
await check('sync cannot modify posted journal amounts', async () => {
  const snapshot = await workspace();
  snapshot.journalLines = snapshot.journalLines.map((line: ACDOCALine) => line.docNo === 'INTEGRATION-001' ? { ...line, debit: line.debit * 2, credit: line.credit * 2 } : line);
  assert.equal((await call(state.PUT, 'PUT', snapshot, owner)).status, 409);
  const persisted = (await workspace()).journalLines.find((line: ACDOCALine) => line.id === original[0].id);
  assert.equal(persisted.debit, 100);
});
await check('omitting journals from sync cannot delete them', async () => {
  const snapshot = await workspace(); const count = snapshot.journalLines.length;
  snapshot.journalLines = [];
  const response = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
  assert.equal((await workspace()).journalLines.length, count);
});
await check('direct PATCH cannot rewrite accounting history', async () => {
  assert.equal((await call(journal.PATCH, 'PATCH', { clientId: 2, docNo: original[0].docNo, lines: original }, owner)).status, 409);
});
await check('direct DELETE cannot erase accounting history', async () => {
  assert.equal((await call(journal.DELETE, 'DELETE', { clientId: 2, docNo: original[0].docNo }, owner)).status, 409);
});
await check('staff cannot change period locks through state sync', async () => {
  const snapshot = await workspace(demo); snapshot.closedPeriods.push({ clientId: 2, period: '2026-11' });
  const response = await call(state.PUT, 'PUT', snapshot, demo);
  assert.ok(response.status === 403 || response.status === 409, JSON.stringify(await response.json()));
});
await check('null state payload returns a controlled 400', async () => {
  assert.equal((await call(state.PUT, 'PUT', null, owner)).status, 400);
});
await check('an authenticated reviewer can persist a rejection decision', async () => {
  const snapshot = await workspace();
  const request = snapshot.approvalRequests.find((row: { status: string }) => row.status === 'pending');
  assert.ok(request);
  request.status = 'rejected'; request.reviewedBy = 'owner'; request.rejectionReason = 'Review regression';
  const response = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
  const stored = (await workspace()).approvalRequests.find((row: { id: string }) => row.id === request.id);
  assert.equal(stored.status, 'rejected'); assert.equal(stored.reviewedBy, 'owner');
});
await check('invalid journal payload returns a controlled 400', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: [null] }, owner)).status, 400);
});
await check('concurrent journal and stale state sync retain both documents', async () => {
  const snapshot = await workspace(); snapshot.journalLines.push(...pair('INTEGRATION-CONCURRENT-SYNC'));
  const responses = await Promise.all([
    call(state.PUT, 'PUT', snapshot, owner),
    call(journal.POST, 'POST', { lines: pair('INTEGRATION-CONCURRENT-POST') }, owner),
  ]);
  for (const response of responses) assert.equal(response.status, 200, JSON.stringify(await response.json()));
  const posted = (await workspace()).journalLines;
  assert.equal(posted.filter((line: ACDOCALine) => line.docNo.startsWith('INTEGRATION-CONCURRENT')).length, 4);
});
await check('an unversioned browser snapshot is rejected without touching the books', async () => {
  const snapshot = await workspace();
  delete snapshot.stateRevision;
  assert.equal((await call(state.PUT, 'PUT', snapshot, owner)).status, 428);
});
await check('a second tab with a stale revision cannot overwrite the first tab', async () => {
  const first = await workspace();
  const second = await workspace();
  const ok = await call(state.PUT, 'PUT', first, owner);
  assert.equal(ok.status, 200, JSON.stringify(await ok.json()));
  second.salesInvoices[0].paidAmount = second.salesInvoices[0].totalReceivable;
  const stale = await call(state.PUT, 'PUT', second, owner);
  assert.equal(stale.status, 409);
  assert.match(JSON.stringify(await stale.json()), /revision/);
});
await check('a forged customer receipt cannot mark an invoice as paid', async () => {
  const snapshot = await workspace();
  const inv = snapshot.salesInvoices.find((i: { status: string }) => i.status === 'Open');
  assert.ok(inv);
  const original = inv.paidAmount;
  inv.paidAmount = inv.totalReceivable;
  inv.status = 'Paid';
  const response = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(response.status, 409, JSON.stringify(await response.clone().json()));
  assert.match(JSON.stringify(await response.json()), /posted settlement journals/);
  assert.equal((await workspace()).salesInvoices.find((i: { id: string }) => i.id === inv.id).paidAmount, original);
});
await check('a forged supplier settlement cannot mark a PO Paid', async () => {
  const snapshot = await workspace();
  const po = snapshot.purchaseOrders.find((p: { status: string }) => p.status === 'Invoiced');
  assert.ok(po);
  const original = po.paidAmount;
  po.paidAmount = po.totalAmount;
  po.status = 'Paid';
  const response = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(response.status, 409, JSON.stringify(await response.clone().json()));
  assert.equal((await workspace()).purchaseOrders.find((p: { id: string }) => p.id === po.id).paidAmount, original);
});
await check('inventories cannot be inflated or stock movements erased by browser sync', async () => {
  const snapshot = await workspace();
  assert.ok(snapshot.stockItems.length && snapshot.stockMovements.length);
  const id = snapshot.stockItems[0].id;
  const original = snapshot.stockItems[0].quantityOnHand;
  snapshot.stockItems[0].quantityOnHand = original + 500;
  assert.equal((await call(state.PUT, 'PUT', snapshot, owner)).status, 409);
  const erased = await workspace();
  erased.stockMovements = [];
  assert.equal((await call(state.PUT, 'PUT', erased, owner)).status, 409);
  assert.equal((await workspace()).stockItems.find((i: { id: string }) => i.id === id).quantityOnHand, original);
});
await check('a checker cannot approve a journal that was never posted', async () => {
  const makerSnapshot = await workspace(demo);
  const docNo = 'UNPOSTED-APPROVAL-CONTROL';
  const pending = {
    id: randomUUID(), clientId: 2, clientCode: 'CLI-001', clientName: 'Gold Coast Mines Ltd',
    docNo, docType: 'JE', amount: 100, requestedBy: 'John Boateng (demo)',
    requestedAt: new Date().toISOString(), description: 'Unposted journal approval test',
    reasonForApproval: 'Independent checker test', status: 'pending',
    payload: { lines: pair(docNo, { createdBy: 'demo' }) },
  };
  makerSnapshot.approvalRequests.push(pending);
  const queued = await call(state.PUT, 'PUT', makerSnapshot, demo);
  assert.equal(queued.status, 200, JSON.stringify(await queued.clone().json()));
  const checkerSnapshot = await workspace();
  const found = checkerSnapshot.approvalRequests.find((r: { id: string }) => r.id === pending.id);
  assert.ok(found);
  found.status = 'approved'; found.reviewedBy = 'owner';
  const response = await call(state.PUT, 'PUT', checkerSnapshot, owner);
  assert.equal(response.status, 409, JSON.stringify(await response.clone().json()));
  assert.match(JSON.stringify(await response.json()), /no posted journal/);
  assert.equal((await workspace()).approvalRequests.find((r: { id: string }) => r.id === pending.id).status, 'pending');
});
await check('a sales-only client cannot read payroll/treasury or delete those registers in a sync', async () => {
  await pool.query('UPDATE users SET permissions = $1 WHERE username = $2', [JSON.stringify({
    canPostJournals: true, canRunPayroll: false, allowedModules: ['sales'],
  }), 'demo']);
  const scoped = await workspace(demo);
  assert.ok(!scoped.bankAccounts.length && !scoped.employees.length && !scoped.payrollRecords.length);
  assert.ok(scoped.stockItems.length, 'sales may see stock available for sale');
  const bankCount = Number((await pool.query('select count(*) as n from bank_accounts where client_id=2')).rows[0].n);
  const employeeCount = Number((await pool.query('select count(*) as n from employees where client_id=2')).rows[0].n);
  const response = await call(state.PUT, 'PUT', scoped, demo);
  assert.equal(response.status, 200, JSON.stringify(await response.clone().json()));
  assert.equal(Number((await pool.query('select count(*) as n from bank_accounts where client_id=2')).rows[0].n), bankCount);
  assert.equal(Number((await pool.query('select count(*) as n from employees where client_id=2')).rows[0].n), employeeCount);
  const forged = await workspace(demo);
  forged.bankAccounts.push({ id: 9999, clientId: 2, code: 'EVIL', name: 'Forged', bankName: 'X', accountNo: '1', currency: 'GHS', balance: 1 });
  assert.equal((await call(state.PUT, 'PUT', forged, demo)).status, 403);
});
await check('a foreign-currency journal is refused until translated', async () => {
  const usd = pair('INTEGRATION-FX-UNTRANSLATED').map((line) => ({ ...line, currency: 'USD' }));
  const response = await call(journal.POST, 'POST', { lines: usd }, owner);
  assert.equal(response.status, 409, JSON.stringify(await response.clone().json()));
  assert.match(JSON.stringify(await response.json()), /reports in GHS/);
  // The same document translated into the functional currency posts normally.
  const ghs = pair('INTEGRATION-FX-TRANSLATED').map((line) => ({ ...line, currency: 'GHS' }));
  assert.equal((await call(journal.POST, 'POST', { lines: ghs }, owner)).status, 200);
});
await check('supporting evidence is stored server-side, tenant-scoped and audited', async () => {
  const attachments = await import('../app/api/attachments/route');
  const request = (method: string, qs: string, body: unknown, token: string) => new Request(`http://localhost/api/attachments${qs}`, {
    method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const png = Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex').toString('base64');
  const upload = await attachments.POST(request('POST', '?clientId=2', {
    docId: 'INTEGRATION-001', docNo: 'INTEGRATION-001', name: 'delivery-note.png', mime: 'image/png', dataBase64: png,
  }, owner));
  assert.equal(upload.status, 201, JSON.stringify(await upload.clone().json()));
  const { id } = await upload.json();

  // The owner's upload is visible to a reviewer in a different browser session.
  const list = await attachments.GET(request('GET', '?clientId=2&docId=INTEGRATION-001', undefined, owner));
  const listed = await list.json();
  assert.equal(list.status, 200);
  assert.ok(listed.attachments.some((a: { id: string; name: string }) => a.id === id && a.name === 'delivery-note.png'));

  // The bytes come back intact, with a download-safe content type.
  const download = await attachments.GET(request('GET', `?clientId=2&id=${id}`, undefined, owner));
  assert.equal(download.status, 200);
  assert.equal(download.headers.get('content-type'), 'image/png');
  assert.ok((await download.arrayBuffer()).byteLength > 8);

  // Another tenant cannot read it, and a mismatched entity id cannot reach it.
  assert.equal((await attachments.GET(request('GET', `?clientId=3&id=${id}`, undefined, demo))).status, 403);
  assert.equal((await attachments.GET(request('GET', `?clientId=3&docId=INTEGRATION-001`, undefined, demo))).status, 403);

  // Executables are refused as evidence.
  const bad = await attachments.POST(request('POST', '?clientId=2', {
    docId: 'INTEGRATION-001', docNo: 'INTEGRATION-001', name: 'payload.exe', mime: 'application/x-msdownload', dataBase64: png,
  }, owner));
  assert.equal(bad.status, 415);

  // Auditors may read evidence but never delete it.
  await pool.query("UPDATE users SET role='auditor' WHERE username='demo'");
  const auditRead = await attachments.GET(request('GET', '?clientId=2&docId=INTEGRATION-001', undefined, demo));
  assert.equal(auditRead.status, 200);
  const auditDelete = await attachments.DELETE(request('DELETE', `?clientId=2&id=${id}`, undefined, demo));
  assert.equal(auditDelete.status, 403);
  await pool.query("UPDATE users SET role='accountant' WHERE username='demo'");

  // The uploader/owner can remove it, and the removal is audited.
  assert.equal((await attachments.DELETE(request('DELETE', `?clientId=2&id=${id}`, undefined, owner))).status, 200);
  const after = await attachments.GET(request('GET', '?clientId=2&docId=INTEGRATION-001', undefined, owner));
  assert.ok(!(await after.json()).attachments.some((a: { id: string }) => a.id === id));
});
await check('distributed rate limiting is shared and exact under parallel requests', async () => {
  const { acquireDistributedRateLimit } = await import('../lib/distributedRateLimit');
  const key = `regression-${Date.now()}`;
  const results = await Promise.all(Array.from({ length: 12 }, () => acquireDistributedRateLimit(key, 3, 0)));
  assert.equal(results.filter((r) => r.allowed).length, 3, 'exactly three requests should acquire the shared bucket');
  assert.ok(results.some((r) => !r.allowed && r.retryAfterSeconds > 0));
});
await check('owner backup creation and read-only verification work, clients are refused', async () => {
  const backups = await import('../app/api/backups/route');
  const request = (method: string, body: unknown, token: string) => new Request('http://localhost/api/backups', {
    method, headers: { 'content-type': 'application/json', Authorization: `Bearer ${token}` },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const created = await backups.POST(request('POST', undefined, owner));
  assert.equal(created.status, 201, JSON.stringify(await created.clone().json()));
  const result = await created.json();
  assert.ok(result.file && result.tableCount > 0 && result.rowCount > 0);
  const verification = await backups.PUT(request('PUT', { file: result.file }, owner));
  assert.equal(verification.status, 200, JSON.stringify(await verification.clone().json()));
  assert.equal((await verification.json()).restored, false);
  const refused = await backups.POST(request('POST', undefined, demo));
  assert.equal(refused.status, 403);
});
await check('off-site S3 upload and restore work through the real S3 client', async () => {
  const http = await import('node:http');
  const { createBackup, downloadOffsiteBackup, readBackupFile } = await import('../lib/backupService');
  const { readFile } = await import('node:fs/promises');
  let captured = Buffer.alloc(0);
  let requestPath = '';
  const server = http.createServer((req, res) => {
    if (req.method === 'PUT') {
      requestPath = req.url || '';
      const chunks: Buffer[] = [];
      req.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
      req.on('end', () => { captured = Buffer.concat(chunks); res.writeHead(200); res.end(); });
    } else {
      res.writeHead(200, { 'content-type': 'application/gzip', 'content-length': String(captured.length) });
      res.end(captured);
    }
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  const address = server.address();
  if (!address || typeof address !== 'object') throw new Error('S3 stub did not bind');
  const previous = { ...process.env };
  try {
    process.env.S3_BUCKET = 'bpz-test-backups';
    process.env.S3_REGION = 'us-east-1';
    process.env.S3_ENDPOINT = `http://127.0.0.1:${address.port}`;
    process.env.S3_FORCE_PATH_STYLE = 'true';
    process.env.S3_ACCESS_KEY_ID = 'test';
    process.env.S3_SECRET_ACCESS_KEY = 'test';
    process.env.S3_PREFIX = 'bpz/';
    process.env.BPZ_REQUIRE_OFFSITE_BACKUP = 'true';
    process.env.BPZ_BACKUP_DIR = '/tmp/bpz-offsite-backup';
    const result = await createBackup();
    assert.equal(result.offsite, 'uploaded');
    assert.ok(requestPath.includes('/bpz-test-backups/bpz/'));
    assert.equal(captured[0], 0x1f);
    assert.equal(captured[1], 0x8b);
    await downloadOffsiteBackup(result.offsiteUri!, '/tmp/bpz-offsite-restored.json.gz');
    const restored = await readFile('/tmp/bpz-offsite-restored.json.gz');
    assert.ok(restored.equals(captured));
    const payload = await readBackupFile('/tmp/bpz-offsite-restored.json.gz');
    assert.equal(payload.app, 'bpz-consult-erp');
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    for (const key of ['S3_BUCKET','S3_REGION','S3_ENDPOINT','S3_FORCE_PATH_STYLE','S3_ACCESS_KEY_ID','S3_SECRET_ACCESS_KEY','S3_PREFIX','BPZ_REQUIRE_OFFSITE_BACKUP','BPZ_BACKUP_DIR']) {
      if (previous[key] === undefined) delete process.env[key]; else process.env[key] = previous[key];
    }
  }
});
await check('enforced owner MFA uses pending enrolment and then requires TOTP', async () => {
  const mfa = await import('../app/api/auth/mfa/route');
  const loginRoute = await import('../app/api/auth/login/route');
  const { totpAt } = await import('../lib/totp');
  process.env.BPZ_ENFORCE_MFA_OWNER = 'true';
  try {
    const begin = await mfa.POST(new Request('http://localhost/api/auth/mfa', {
      method: 'POST', headers: { 'content-type': 'application/json', Authorization: `Bearer ${owner}` }, body: JSON.stringify({ action: 'begin' }),
    }));
    const enrollment = await begin.json();
    assert.ok(enrollment.secret);
    const confirm = await mfa.POST(new Request('http://localhost/api/auth/mfa', {
      method: 'POST', headers: { 'content-type': 'application/json', Authorization: `Bearer ${owner}` }, body: JSON.stringify({ action: 'confirm', code: totpAt(enrollment.secret, Date.now()) }),
    }));
    assert.equal(confirm.status, 200, JSON.stringify(await confirm.clone().json()));
    const blocked = await loginRoute.POST(new Request('http://localhost/api/auth/login', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ usernameOrEmail: 'owner', password: process.env.BPZ_SEED_PASSWORD_OWNER }),
    }));
    assert.equal(blocked.status, 401);
    assert.equal((await blocked.json()).mfaRequired, true);
    const accepted = await loginRoute.POST(new Request('http://localhost/api/auth/login', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ usernameOrEmail: 'owner', password: process.env.BPZ_SEED_PASSWORD_OWNER, otp: totpAt(enrollment.secret, Date.now()) }),
    }));
    assert.equal(accepted.status, 200, JSON.stringify(await accepted.clone().json()));
  } finally {
    delete process.env.BPZ_ENFORCE_MFA_OWNER;
    await pool.query("update users set mfa_enabled = false, mfa_secret = null, mfa_pending_secret = null where username = 'owner'");
  }
});
await check('an unenrolled checker can enrol with a limited grant, never a workspace session', async () => {
  const mfa = await import('../app/api/auth/mfa/route');
  const loginRoute = await import('../app/api/auth/login/route');
  const { totpAt } = await import('../lib/totp');
  const checkerPassword = `Checker-${randomUUID()}!`;
  await pool.query("update users set password_hash = null, password_salt = null where username = 'checker_kofi'");
  const { hashPassword, newSalt } = await import('../lib/password');
  const checkerSalt = newSalt();
  await pool.query("update users set password_hash = $1, password_salt = $2 where username = 'checker_kofi'", [await hashPassword(checkerPassword, checkerSalt), checkerSalt]);
  process.env.BPZ_ENFORCE_MFA_CHECKERS = 'true';
  try {
    const blocked = await loginRoute.POST(new Request('http://localhost/api/auth/login', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ usernameOrEmail: 'checker_kofi', password: checkerPassword }),
    }));
    assert.equal(blocked.status, 401, JSON.stringify(await blocked.clone().json()));
    const challenge = await blocked.json();
    assert.ok(challenge.enrollToken && challenge.secret, 'a 15-minute enrolment grant must be issued');
    const journalResponse = await journal.POST(new Request('http://localhost/api/journal', {
      method: 'POST', headers: { 'content-type': 'application/json', Authorization: `Bearer ${challenge.enrollToken}` }, body: JSON.stringify({ lines: pair('MFA-GRANT-CANNOT-POST') }),
    }));
    assert.equal(journalResponse.status, 401, 'the enrolment grant must not act as a session');
    const confirmed = await mfa.POST(new Request('http://localhost/api/auth/mfa', {
      method: 'POST', headers: { 'content-type': 'application/json', Authorization: `Bearer ${challenge.enrollToken}` },
      body: JSON.stringify({ action: 'confirm', code: totpAt(challenge.secret, Date.now()) }),
    }));
    assert.equal(confirmed.status, 200, JSON.stringify(await confirmed.clone().json()));
    const accepted = await loginRoute.POST(new Request('http://localhost/api/auth/login', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ usernameOrEmail: 'checker_kofi', password: checkerPassword, otp: totpAt(challenge.secret, Date.now()) }),
    }));
    assert.equal(accepted.status, 200, JSON.stringify(await accepted.clone().json()));
  } finally {
    delete process.env.BPZ_ENFORCE_MFA_CHECKERS;
    await pool.query("update users set mfa_enabled = false, mfa_secret = null, mfa_pending_secret = null where username = 'checker_kofi'");
    await pool.query("delete from bpz_mfa_enrollments where user_id = 'checker_kofi'");
  }
});
await check('withdrawn journal permission is enforced server-side', async () => {
  await pool.query('UPDATE users SET permissions = $1 WHERE username = $2', [JSON.stringify({ canPostJournals: false, allowedModules: ['sales'] }), 'demo']);
  assert.equal((await call(journal.POST, 'POST', { lines: pair('INTEGRATION-RESTRICTED', { createdBy: 'demo' }) }, demo)).status, 403);
});
await check('logout revokes the server session', async () => {
  assert.equal((await call(logout.POST, 'POST', {}, owner)).status, 200);
  assert.equal((await call(session.GET, 'GET', undefined, owner)).status, 401);
});

await pool.end();
console.log(`\nAPI regressions: ${passed} passed, ${failed} failed.`);
if (failed) process.exitCode = 1;