/**
 * Regression tests for the November 2026 system audit (docs/AUDIT_2026_11_FINDINGS.md).
 * Each test reproduces a defect that was confirmed against the running system.
 *
 *   npx tsx --test src/tests/auditFixes.test.ts
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import type { ACDOCALine } from '../types/accounting';
import {
  buildDebtServiceAccrualJournal,
  buildDebtServicePaymentJournal,
  generateAmortisationSchedule,
  normalizeJournalAmounts,
  type LoanFacility,
} from '../utils/loans';
import { validateJournalLines } from '../lib/journalValidation';
import { activeCurrencyCode, ccy, formatMoney, setActiveCurrency } from '../utils/currency';
import { nextDocNo } from '../utils/ids';
import { normaliseOpeningSchedule, openingScheduleTotals } from '../utils/openingBalances';

const context = {
  allowedClientIds: [1],
  closedPeriodKeys: new Set<string>(),
  coaAccountNos: new Set(['100000', '202000', '250000', '300000', '700000']),
};

const line = (id: string, accountNo: string, debit: number, credit: number): ACDOCALine => ({
  id,
  docNo: 'JE-2026-11-0001',
  period: '2026-11',
  date: '2026-11-06',
  module: 'FI',
  docType: 'JE',
  accountNo,
  accountName: accountNo,
  costCenter: 'CC-ADM',
  debit,
  credit,
  currency: 'GHS',
  description: 'audit regression',
  createdBy: 'owner',
  clientId: 1,
});

const facility = (overrides: Partial<LoanFacility>): LoanFacility => ({
  id: 'FAC-1',
  code: 'LN-TEST',
  facilityName: 'Test facility',
  lender: 'Test Bank',
  principal: 500000,
  annualRatePct: 22,
  termMonths: 24,
  frequency: 'monthly',
  facilityType: 'amortising',
  arrangementFee: 0,
  startDate: '2026-01-28',
  status: 'Active',
  ...overrides,
});

const everyInstalmentPosts = (loan: LoanFacility) => {
  const rows = generateAmortisationSchedule(loan);
  assert.ok(rows.length > 0, 'a schedule is produced');
  for (const row of rows) {
    for (const value of [row.openingBalance, row.interestExpense, row.principalPayment, row.totalPayment, row.closingBalance]) {
      assert.ok(Number.isFinite(value), `instalment ${row.periodNum} is finite`);
      assert.ok(Math.abs(value * 100 - Math.round(value * 100)) < 1e-6, `instalment ${row.periodNum} is exact to two decimals`);
    }
    for (const build of [buildDebtServicePaymentJournal, buildDebtServiceAccrualJournal]) {
      const journal = normalizeJournalAmounts(build({
        facility: loan, row, clientId: 1, currency: 'GHS', date: row.date, username: 'owner', canCheck: true,
        treasuryAccountNo: '100000', treasuryAccountName: 'Cash at Bank',
      }));
      assert.equal(validateJournalLines(journal, context), null, `${loan.facilityType} instalment ${row.periodNum} passes the posting controls`);
    }
  }
  return rows;
};

test('reported: the Ecobank 21.5% / 60-month schedule posts without the two-decimal refusal', () => {
  const rows = everyInstalmentPosts(facility({ principal: 1200000, annualRatePct: 21.5, termMonths: 60 }));
  assert.equal(rows.length, 60);
  assert.equal(rows[0].interestExpense, 21500);
  assert.equal(rows[rows.length - 1].closingBalance, 0);
});

test('interest-only and bullet instalments post (no zero-value principal line)', () => {
  for (const facilityType of ['interest_only', 'bullet'] as const) {
    const rows = everyInstalmentPosts(facility({ facilityType }));
    const first = buildDebtServicePaymentJournal({
      facility: facility({ facilityType }), row: rows[0], clientId: 1, currency: 'GHS', date: rows[0].date, username: 'owner',
      treasuryAccountNo: '100000', treasuryAccountName: 'Cash at Bank',
    });
    assert.equal(first.length, 2, 'only the interest and treasury legs are raised before maturity');
    assert.ok(first.every((l) => l.debit > 0 || l.credit > 0));
    assert.equal(rows[rows.length - 1].closingBalance, 0);
  }
});

test('a 0% facility amortises straight-line instead of collapsing into a balloon', () => {
  const rows = everyInstalmentPosts(facility({ principal: 120000, annualRatePct: 0, termMonths: 12 }));
  assert.equal(rows.length, 12);
  assert.ok(rows.every((row) => row.interestExpense === 0));
  assert.ok(rows.every((row) => row.principalPayment === 10000), 'equal principal every month');
  assert.equal(rows[11].closingBalance, 0);
});

test('normalizeJournalAmounts settles rounding residue but never balances a real difference', () => {
  // Genuine sub-pesewa residue from a computed schedule is settled.
  const residue = normalizeJournalAmounts([line('a', '700000', 100.004, 0), line('b', '100000', 0, 100)]);
  assert.equal(validateJournalLines(residue, context), null);

  // A document that is actually out of balance must be REFUSED, not rewritten.
  const wrong = normalizeJournalAmounts([line('a', '100000', 100, 0), line('b', '300000', 0, 90)]);
  assert.deepEqual(wrong.map((l) => [l.debit, l.credit]), [[100, 0], [0, 90]], 'amounts are left exactly as entered');
  assert.match(validateJournalLines(wrong, context) ?? '', /not balanced/);

  const oneCedi = normalizeJournalAmounts([line('a', '100000', 5000, 0), line('b', '300000', 0, 4999)]);
  assert.match(validateJournalLines(oneCedi, context) ?? '', /not balanced/);
});

test('the reported manual journal (Dr 100000 / Cr 300000, 10,000 on 2026-11-06) is a valid document', () => {
  assert.equal(validateJournalLines([line('a', '100000', 10000, 0), line('b', '300000', 0, 10000)], context), null);
});

test('amount symbols follow the active entity currency, not a hard-coded cedi sign', () => {
  setActiveCurrency('GBP');
  assert.equal(ccy(), '£');
  assert.equal(activeCurrencyCode(), 'GBP');
  assert.equal(formatMoney(15000, 'GBP'), '£15,000.00');
  setActiveCurrency('USD');
  assert.equal(ccy(), '$');
  setActiveCurrency('not-a-currency');
  assert.equal(ccy(), '$', 'an invalid code never replaces the active currency');
  setActiveCurrency('CHF');
  assert.equal(ccy(), 'CHF', 'currencies without a symbol show their ISO code, trimmed');
  setActiveCurrency('GHS');
  assert.equal(ccy(), '\u20b5');
});

test('document numbering skips numbers reserved by pending approval requests', () => {
  const posted = ['JE-2026-11-0001'];
  const reservedByApprovals = ['JE-2026-11-0002'];
  assert.equal(nextDocNo('JE-2026-11', [...posted, ...reservedByApprovals]), 'JE-2026-11-0003');
});

test('a legacy opening-balance draft is normalised before it can reach posting', () => {
  const draft = normaliseOpeningSchedule({
    '100000': { dr: 50000.004, cr: 0 },
    '300000': { dr: 10, cr: 50000 },
    '130000': { dr: Number.NaN, cr: -5 },
  });
  assert.deepEqual(draft['100000'], { dr: 50000, cr: 0 });
  assert.deepEqual(draft['300000'], { dr: 0, cr: 50000 }, 'one normal side per account');
  assert.deepEqual(draft['130000'], { dr: 0, cr: 0 });
  assert.equal(openingScheduleTotals(draft).balanced, true);
});
