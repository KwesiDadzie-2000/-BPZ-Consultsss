/**
 * Supporting-document attachments (evidence for a posted document).
 *
 * Evidence is now held on the FIRM'S SERVER, scoped to the client entity, so the
 * reviewer, the auditor and the client all see the same file and clearing a
 * browser cache cannot destroy it. Previously the bytes lived only in this
 * browser's IndexedDB: the owner could never open a client's evidence, an auditor
 * in another browser saw an empty panel, and "clear site data" silently deleted
 * audit evidence.
 *
 * Limits are enforced twice — in this client (so the user gets an instant reason)
 * and on the server (so a crafted request cannot bypass them).
 */
import { apiFetch } from './session';

export interface AttachmentMeta {
  id: string;
  clientId: number;
  docId: string;
  docNo: string;
  name: string;
  mime: string;
  size: number;
  addedAt: string;
  addedBy: string;
}

export const ATTACHMENT_LIMITS = {
  maxFileBytes: 4 * 1024 * 1024,
  maxFilesPerDocument: 8,
  acceptedExtensions: ['pdf', 'png', 'jpg', 'jpeg', 'webp', 'csv', 'xlsx', 'docx', 'txt'],
} as const;

export class AttachmentError extends Error {}

const MIME_BY_EXTENSION: Record<string, string> = {
  pdf: 'application/pdf',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  webp: 'image/webp',
  csv: 'text/csv',
  txt: 'text/plain',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
};

const extensionOf = (name: string) => name.split('.').pop()?.toLowerCase() ?? '';

export function validateAttachment(file: File, existingCount: number): string | null {
  const ext = extensionOf(file.name);
  if (!(ATTACHMENT_LIMITS.acceptedExtensions as readonly string[]).includes(ext)) {
    return `That file type is not accepted. Allowed: ${ATTACHMENT_LIMITS.acceptedExtensions.join(', ')}.`;
  }
  if (file.size <= 0) return 'The selected file is empty.';
  if (file.size > ATTACHMENT_LIMITS.maxFileBytes) {
    return `The file is ${formatBytes(file.size)}; the limit is ${formatBytes(ATTACHMENT_LIMITS.maxFileBytes)}.`;
  }
  if (existingCount >= ATTACHMENT_LIMITS.maxFilesPerDocument) {
    return `This document already has ${existingCount} attachments (limit ${ATTACHMENT_LIMITS.maxFilesPerDocument}). Remove one first.`;
  }
  return null;
}

const readBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new AttachmentError('The file could not be read from this device.'));
    reader.onload = () => {
      const result = String(reader.result ?? '');
      resolve(result.includes(',') ? result.slice(result.indexOf(',') + 1) : result);
    };
    reader.readAsDataURL(file);
  });

export async function addAttachment(input: {
  file: File;
  clientId: number;
  docId: string;
  docNo: string;
  addedBy: string;
}): Promise<AttachmentMeta> {
  const existing = await listAttachments(input.clientId, input.docId);
  const problem = validateAttachment(input.file, existing.length);
  if (problem) throw new AttachmentError(problem);

  const mime = input.file.type || MIME_BY_EXTENSION[extensionOf(input.file.name)] || 'application/octet-stream';
  const dataBase64 = await readBase64(input.file);
  const res = await apiFetch(`/api/attachments?clientId=${input.clientId}`, {
    method: 'POST',
    body: JSON.stringify({
      docId: input.docId, docNo: input.docNo, name: input.file.name, mime, dataBase64,
    }),
  });
  const body = await res.json().catch(() => null);
  if (!res.ok || !body?.ok) {
    throw new AttachmentError(body?.error || `The document could not be stored (HTTP ${res.status}).`);
  }
  return {
    id: body.id as string, clientId: input.clientId, docId: input.docId, docNo: input.docNo,
    name: input.file.name, mime, size: input.file.size, addedAt: String(body.addedAt ?? new Date().toISOString()),
    addedBy: input.addedBy,
  };
}

export async function listAttachments(clientId: number, docId?: string): Promise<AttachmentMeta[]> {
  const query = docId ? `&docId=${encodeURIComponent(docId)}` : '';
  const res = await apiFetch(`/api/attachments?clientId=${clientId}${query}`);
  const body = await res.json().catch(() => null);
  if (!res.ok || !body?.ok) throw new AttachmentError(body?.error || 'The supporting documents could not be read.');
  return (body.attachments as AttachmentMeta[]) ?? [];
}

export async function deleteAttachment(id: string, clientId?: number): Promise<void> {
  if (!clientId) throw new AttachmentError('The client entity is required to remove evidence.');
  const res = await apiFetch(`/api/attachments?clientId=${clientId}&id=${encodeURIComponent(id)}`, { method: 'DELETE' });
  const body = await res.json().catch(() => null);
  if (!res.ok || !body?.ok) throw new AttachmentError(body?.error || 'The attachment could not be removed.');
}

/** Opens a stored file in a new tab (server-side download, tenant-scoped). */
export async function openAttachment(id: string, clientId?: number): Promise<void> {
  if (!clientId) throw new AttachmentError('The client entity is required to open evidence.');
  const res = await apiFetch(`/api/attachments?clientId=${clientId}&id=${encodeURIComponent(id)}`);
  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw new AttachmentError(body?.error || 'The file could not be opened.');
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  globalThis.open?.(url, '_blank', 'noopener,noreferrer');
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

export const formatBytes = (bytes: number): string => {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 KB';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
};
