/**
 * The exact reason the workspace refused the posting that was JUST attempted.
 *
 * Posting handlers are synchronous: a desk calls one, gets `false`/`'failed'`
 * back, and must tell the user why. The desks used to guess ("the period may be
 * closed or the document already exists"), which sent users after the wrong
 * cause. The workspace records every refusal here as it raises the System
 * Notice, and a desk reads it in the same event handler.
 *
 * The reason is time-boxed: only a refusal raised within the last moments (i.e.
 * by this very action) is returned, so an old notice is never reported as the
 * cause of a new failure.
 */
let lastRefusal: { message: string; at: number } | null = null;

export function setLastPostingRefusal(message: string | null): void {
  lastRefusal = message ? { message, at: Date.now() } : null;
}

/** The refusal raised by the action that just ran, or null when there is none. */
export function lastPostingRefusal(maxAgeMs = 2000): string | null {
  if (!lastRefusal) return null;
  return Date.now() - lastRefusal.at <= maxAgeMs ? lastRefusal.message : null;
}

/** The precise refusal when one was just raised; otherwise the desk's own fallback. */
export function refusalReason(fallback: string): string {
  return lastPostingRefusal() ?? fallback;
}
