import { authJson, getSessionUser, requireOwner } from "@/lib/auth";
import { createBackup, getBackupStatus, listLocalBackups, readBackupFile } from "@/lib/backupService";
import { acquireDistributedRateLimit } from "@/lib/distributedRateLimit";
import { recordOpsEvent } from "@/lib/monitoring";
import { basename } from "node:path";

export const dynamic = "force-dynamic";

/** Owner-only backup status and local/off-site snapshot inventory. */
export async function GET(req: Request) {
  const owner = await requireOwner(req);
  if (!owner) return authJson(req, { ok: false, error: "Owner access required." }, { status: 403 });
  const status = await getBackupStatus();
  const files = await listLocalBackups();
  return authJson(req, { ok: true, status, files, offsiteConfigured: Boolean(process.env.S3_BUCKET) });
}

/** Create a backup now, and upload it off-site when S3 is configured. */
export async function POST(req: Request) {
  const owner = await requireOwner(req);
  if (!owner) return authJson(req, { ok: false, error: "Owner access required." }, { status: 403 });
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || owner.username;
  const limit = await acquireDistributedRateLimit(`backup:${ip}`, 4, 1 / 60);
  if (!limit.allowed) return authJson(req, { ok: false, error: `Backup already running too often. Retry in ${limit.retryAfterSeconds}s.` }, { status: 429 });
  try {
    const result = await createBackup();
    await recordOpsEvent("info", "backup.manual", { file: result.file, actor: owner.username, offsite: result.offsite });
    return authJson(req, { ok: true, ...result, fileName: basename(result.file) }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Backup failed";
    return authJson(req, { ok: false, error: message }, { status: 503 });
  }
}

/** Parse and validate a snapshot without truncating or writing to any table. */
export async function PUT(req: Request) {
  const owner = await requireOwner(req);
  if (!owner) return authJson(req, { ok: false, error: "Owner access required." }, { status: 403 });
  let file = "";
  try {
    const body = await req.json() as { file?: unknown };
    file = String(body.file ?? "");
  } catch {
    return authJson(req, { ok: false, error: "A backup file path is required." }, { status: 400 });
  }
  const allowedRoot = (process.env.BPZ_BACKUP_DIR || "./backups").replace(/\/$/, "");
  if (!file.startsWith(allowedRoot) || file.includes("..")) {
    return authJson(req, { ok: false, error: "Only files in the configured backup directory can be verified." }, { status: 400 });
  }
  try {
    const payload = await readBackupFile(file);
    if (payload.app !== "bpz-consult-erp" || !payload.tables || !Object.keys(payload.tables).length) {
      return authJson(req, { ok: false, error: "This is not a valid BPZ backup." }, { status: 400 });
    }
    const rowCount = Object.values(payload.tables).reduce((n, rows) => n + rows.length, 0);
    return authJson(req, { ok: true, verified: true, createdAt: payload.createdAt, tableCount: Object.keys(payload.tables).length, rowCount, restored: false });
  } catch (error) {
    return authJson(req, { ok: false, error: error instanceof Error ? error.message : "Verification failed" }, { status: 400 });
  }
}
