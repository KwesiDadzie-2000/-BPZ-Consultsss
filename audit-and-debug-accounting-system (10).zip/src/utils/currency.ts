/**
 * Currency presentation and parsing helpers shared by every posting desk.
 *
 * A Ghana practice keeps books in several currencies (GHS functional, USD/GBP/EUR
 * transactions). Hard-coding "₵" or the entity's functional currency into a
 * posting form is wrong: the operator must choose the DOCUMENT currency, and the
 * amount label must follow that choice. These helpers centralise the formatting
 * and the option-string parsing so no desk can silently mislabel or truncate.
 */

const SYMBOLS: Record<string, string> = {
  GHS: "\u20b5",
  USD: "$",
  GBP: "\u00a3",
  EUR: "\u20ac",
  NGN: "\u20a6",
  ZAR: "R",
  KES: "KSh",
  XOF: "CFA ",
  XAF: "FCFA ",
  CNY: "\u00a5",
  JPY: "\u00a5",
  CHF: "CHF ",
  CAD: "C$",
  AUD: "A$",
  SAR: "SR ",
  AED: "AED ",
};

/** ISO 4217 currencies the workspace offers alongside the entity's functional currency. */
export const POSTABLE_CURRENCIES = ["GHS", "USD", "GBP", "EUR", "NGN", "ZAR", "XOF", "CNY", "CHF", "CAD"] as const;

export function currencySymbol(code: string | undefined | null): string {
  const iso = String(code ?? "").toUpperCase();
  return SYMBOLS[iso] ?? `${iso} `;
}

/** ₵1,234.50 / $1,234.50 — two decimals, symbol of the DOCUMENT currency. */
export function formatMoney(value: number, currency: string | undefined | null): string {
  const n = Number.isFinite(value) ? value : 0;
  return `${currencySymbol(currency)}${n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/**
 * The journal selects are rendered as `"<accountNo> · <name>"`. An account name
 * may itself contain the separator (e.g. "Mobile Money — MTN / Vodafone · AirtelTigo"),
 * so splitting on the first separator truncated the name and posted a wrong caption.
 */
export function parseAccountOption(value: string): { accountNo: string; accountName: string } {
  const idx = value.indexOf(" \u00b7 ");
  if (idx === -1) return { accountNo: value.trim(), accountName: value.trim() };
  return {
    accountNo: value.slice(0, idx).trim(),
    accountName: value.slice(idx + 3).trim(),
  };
}

export function formatAccountOption(accountNo: string, name: string): string {
  return `${accountNo} \u00b7 ${name}`;
}

/**
 * IAS 21 translation at the posting boundary.
 *
 * The general ledger holds ONE currency per entity (its functional currency).
 * A document raised in another currency must be translated with an explicit
 * rate before it reaches the ledger; storing 1,000 USD next to 1,000 GHS in the
 * same account makes the trial balance, the statements and the control accounts
 * add unlike amounts together. The original currency and amount are preserved in
 * the narration so the transaction remains auditable.
 */
export interface TranslatableLine {
  debit: number;
  credit: number;
  currency: string;
  description: string;
}

export function translateToFunctional<T extends TranslatableLine>(
  lines: readonly T[],
  functionalCurrency: string,
  documentCurrency: string,
  exchangeRate?: number,
): { lines: T[]; error?: string } {
  const functional = String(functionalCurrency).toUpperCase();
  const document = String(documentCurrency || functional).toUpperCase();
  if (document === functional) return { lines: [...lines] };
  const rate = Number(exchangeRate);
  if (!Number.isFinite(rate) || rate <= 0) {
    return {
      lines: [],
      error: `This entity reports in ${functional}, so a ${document} document needs an explicit exchange rate (${functional} per 1 ${document}) before it can post.`,
    };
  }
  const round = (n: number) => Math.round((Number.isFinite(n) ? n : 0) * 100) / 100;
  const translated = lines.map((line) => {
    const fcy = `${document} ${(line.debit || line.credit).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} @ ${rate}`;
    return {
      ...line,
      debit: round(line.debit * rate),
      credit: round(line.credit * rate),
      currency: functional,
      description: `${line.description} · translated ${fcy}`,
    };
  });
  // Both sides scale by the same rate, but 2dp rounding can leave a pesewa or two.
  const debitMinor = translated.reduce((n, l) => n + Math.round(l.debit * 100), 0);
  const creditMinor = translated.reduce((n, l) => n + Math.round(l.credit * 100), 0);
  const residue = debitMinor - creditMinor;
  if (residue !== 0 && translated.length) {
    const largest = translated.reduce((best, l) => (l.debit + l.credit > best.debit + best.credit ? l : best), translated[0]);
    if (residue > 0) largest.credit = round(largest.credit + residue / 100);
    else largest.debit = round(largest.debit - residue / 100);
  }
  return { lines: translated };
}
