# System Audit & Remediation Report — Control Accounts, IFRS Engine, Client Access & Stress Testing

This report documents the comprehensive audit and engineering upgrades performed across all modules on both the Firm Owner and Client sides. The original assessment files (`SYSTEM_AUDIT_2026.md`, `SYSTEM_REVIEW.md`) are preserved untouched.

---

## 1. Authentication, Workspace Links & Module Access Controls

| # | Finding | Root Cause | Resolution |
|---|---------|-----------|------------|
| 1 | Login password rejected / locked out | Owner activation had completed on first boot while failed attempts incremented the login counter. | Owner credential reset via `reset-password.ts` with scrypt hashing, lockout rows cleared, and `reset-password.ts` / `/api/users` updated to clear `bpz_login_attempts` upon password reset. Added show/hide password toggle and credential generator across Login, Client Creation, and User Administration. |
| 2 | Client link opening owner workspace | Browser session cookie/storage was restored before checking `?workspace=CODE`. | Opening `/?workspace=CODE` ends any active session first, binds sign-in to that workspace code on the server (`POST /api/auth/login` returns 403 for foreign workspaces and 404 for unknown codes), and purges cross-user `localStorage` cache via `adoptUser()`. |
| 3 | Client module restriction enforcement | Module ticks were checked only in the UI. | Enforced `maySeeSection` and `permissions.allowedModules` across the sidebar, dashboard quick launchers, Reports Hub tabs, and server APIs (`/api/desk`, `/api/workbooks`, `/api/trade`, `/api/journal`). Owner-only administration (`clients_management`, `user_permissions`, `group_consolidation`, `enterprise_sso`, `tax_settings`, `global_tax`, `soc_dr`, `realtime_integrations`, `advisory`) is permanently blocked for non-owners. |
| 4 | Multi-instance login lockout | Attempt counter lived in process memory. | Migrated failed sign-in attempt tracking to PostgreSQL (`bpz_login_attempts`) with atomic upsert increment so lockouts hold across all server instances. |

---

## 2. Control Accounts & Subledger-to-GL Reconciliation

A dedicated **Control Accounts & Subledger Reconciliation** subsystem (`src/utils/controlAccounts.ts`, `src/components/ControlAccountsDesk.tsx`) was implemented:

- **21 Monitored Control Accounts** across Treasury (`100000`–`104000`), Trade Receivables (`110000`), Trade Payables (`200000`), Accrued Expenses (`202000`), Prepayments (`116000`), Inventories (`120000` Raw Materials, `121000` Finished Goods, `122000` WIP, `123000` Spares), Fixed Assets (`130000` Cost, `139000` Accumulated Depreciation), Payroll (`205000`, `206000`, `206100`, `207000`), and VAT/WHT (`125000`, `209000`, `220000`).
- **Direct Manual Posting Guard**: Locked control accounts display `CONTROL` badges in the Chart of Accounts and block unapproved manual journal entries (`ManualJournalSection`) by staff accountants, while requiring an explicit Owner/Controller reconciliation override confirmation for administrative adjustments.
- **Server-Side Working Balance Authority (`/api/state`)**: Rejects state syncs (HTTP 409) where bank balances, invoice/PO settlements, or inventory valuations diverge from posted General Ledger entries.
- **Automatic Treasury Sync**: Journals posted through `handleAddJournalLines` automatically update matching bank/cash working balances and roll back atomically if the server rejects the posting.

---

## 3. Comprehensive IFRS / IAS & Borrowings Computation Engines

Replaced static mock state in `ComprehensiveStandardsDesk.tsx` and `LoansAmortisationDesk.tsx` with server-persisted, entity-scoped computation engines (`entity_workbooks` kinds `ifrs_desk` and `loan_facilities`):

- **IFRS 15 (Contracts with Customers)**: Cost-to-cost POC calculation (`actualCost / estimatedCost`), posting net incremental adjustments into **Unbilled Contract Assets (`118100`)** (fixing the prior `141000` Investment Property account mapping) or **Contract Liabilities (`225000`)**.
- **IFRS 16 (Leases)**: Present value of lease payments at incremental borrowing rate (`computeLease`), initial ROU asset & lease liability recognition (`150000` / `230000`), current vs non-current split, monthly ROU depreciation (`610000` / `159000`), effective interest (`710000`), and bank balance update.
- **IAS 36 (Impairment of Assets & CGUs)**: Multi-year DCF Value-in-Use + terminal value calculator compared against FVLCD, posting impairment losses (`Dr 690000 / Cr 139000`).
- **IAS 37 (Provisions & Contingencies)**: Probability threshold evaluation (`> 50%` recognised at discounted PV), initial recognition (`Dr Expense/PPE / Cr 270000`), and annual finance-cost unwinding (`Dr 720000 / Cr 270000`).
- **IFRS 9 (Expected Credit Loss)**: Live staging of open customer invoices (`receivablesAgeing`) into Stages 1–3, posting net incremental adjustments against booked `GL 119000`.
- **IFRS 5 (Non-Current Assets Held for Sale)**: Reclassifies live active Fixed Assets to `180000` at `min(NBV, FVLCD)`, clears accumulated depreciation (`139000`), records transfer impairment (`690000`), and ceases depreciation in the Fixed Asset Register.
- **Loans & Borrowings (IAS 23 / IFRS 9)**: Persisted amortising, interest-only, and bullet schedules with true calendar dates (`addMonths`), arrangement fees, drawdown posting, and instalment payment posting synced with Treasury.
- **Group Consolidation Summary (`GET /api/bootstrap?summary=consolidation`)**: Server-side SQL aggregation per entity/account/currency so opening Consolidation never downloads raw multi-tenant journal lines.

---

## 4. Verification & Stress-Test Results

- `npx next typegen`: **Pass**
- `tsc --noEmit`: **Pass (0 errors)**
- `npm run build`: **Pass**
- `extensions.test.ts` + `reviewRegressions.test.ts`: **53 / 53 passed**
- `sectorTransactions.test.ts`: **47 / 47 passed**
- `apiRegression.test.mts`: **22 / 22 passed**
- `scripts/sector-workflow-test.mts` (all 24 Ghana sectors): **760 / 760 passed**
- `scripts/stress-test.mts` (100,000 journal lines, 20 entities, concurrency 40): **25 / 25 passed** (p50 post latency 11 ms, 128 docs/s, delta sync 20 ms, 0 unbalanced documents, 0 negative stock)
- End-to-End Control Account, IFRS, Module Restriction & Lockout Suite: **All passed**
