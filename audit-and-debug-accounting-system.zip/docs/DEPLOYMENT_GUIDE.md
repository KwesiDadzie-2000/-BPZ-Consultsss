# BPZ Consult ERP — exact deployment steps (Ubuntu 24.04 VPS)

This is the tested deployment path: one Ubuntu server running Next.js, PostgreSQL and Caddy. The backend is **the same Next.js process** (`/api/*`) plus PostgreSQL; do not upload this as a static website.

**Important:** the GitHub URL `KwesiDadzie-2000/-BPZ-Consultsss` contains ZIP snapshots, not the revised source in this workspace. Export/download **this workspace** (including `src/app/api/clients`, `src/db/productionSeed.ts`, `scripts/`, `package-lock.json` and `.env.example`) and deploy THAT export. Do not deploy a ZIP from the old repo. Never copy this workspace's `.env` or its preview database to the server.

Replace only these examples with your own details: `SERVER_IP`, `erp.your-domain.com`, `owner@your-domain.com`.

## 1. Prepare DNS and server

- Rent one Ubuntu 24.04 VPS with **2 vCPU / 4 GB RAM**.
- Create DNS **A** record: `erp.your-domain.com` → `SERVER_IP`.
- SSH in: `ssh ubuntu@SERVER_IP` (or the login provided by your VPS).

## 2. Install Node, PostgreSQL, Caddy and firewall (on VPS)

```bash
sudo apt update
sudo apt install -y postgresql postgresql-client caddy ufw curl
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
node -v
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable
```

**Do not expose PostgreSQL (5432) or Next.js (3000)** on the public firewall.

## 3. Upload THIS workspace's source

On your computer: use this platform's **Export/Download Project** action, unpack it to a folder `bpz-erp` with `package.json` directly inside, then create a source-only archive:

```bash
tar --exclude=node_modules --exclude=.next --exclude=.env --exclude=backups -czf bpz-release.tgz -C bpz-erp .
scp bpz-release.tgz ubuntu@SERVER_IP:/tmp/
```

On the VPS:

```bash
sudo useradd --system --create-home --shell /usr/sbin/nologin bpz
sudo install -d -o bpz -g bpz -m 750 /opt/bpz-erp
sudo tar -xzf /tmp/bpz-release.tgz -C /opt/bpz-erp
sudo chown -R bpz:bpz /opt/bpz-erp
ls /opt/bpz-erp/src/db/productionSeed.ts /opt/bpz-erp/src/app/api/clients/route.ts
```

If those files are absent, you have the **old ZIP**, not this updated source. Stop.

## 4. Create an isolated production database

Run these on the VPS. The generated password is stored only in this shell and the `.env` file created in step 5:

```bash
DB_PASS="$(openssl rand -hex 24)"
sudo -u postgres psql -v ON_ERROR_STOP=1 -c "CREATE USER bpz_app WITH PASSWORD '$DB_PASS';"
sudo -u postgres psql -v ON_ERROR_STOP=1 -c 'CREATE DATABASE bpz_prod OWNER bpz_app;'
psql "postgresql://bpz_app:$DB_PASS@127.0.0.1:5432/bpz_prod" -c 'select 1;'
```

Use a **new empty database**. Do not connect this deployment to the sandbox preview DB or a demo DB.

## 5. Create production environment and activation secret

Run on the VPS (set the two values marked `CHANGE` first):

```bash
DOMAIN=erp.your-domain.com                   # CHANGE
OWNER_EMAIL=owner@your-domain.com           # CHANGE
SETUP_TOKEN="$(openssl rand -hex 32)"
sudo tee /opt/bpz-erp/.env >/dev/null <<EOF
DATABASE_URL=postgresql://bpz_app:${DB_PASS}@127.0.0.1:5432/bpz_prod
BPZ_BOOTSTRAP_MODE=production
BPZ_OWNER_EMAIL=${OWNER_EMAIL}
BPZ_SETUP_TOKEN=${SETUP_TOKEN}
BPZ_BACKUP_DIR=/opt/bpz-erp/backups
BPZ_BACKUP_KEEP=14
EOF
sudo chown bpz:bpz /opt/bpz-erp/.env
sudo chmod 600 /opt/bpz-erp/.env
```

Put `SETUP_TOKEN` in your password manager now; you'll enter it once at step 9. Never put it in Git, a chat message, or the client invitation. `BPZ_BOOTSTRAP_MODE=production` is essential: without it an empty database seeds **demo books**. Production mode starts with **1 owner + 1 firm workspace + a blank chart of accounts (205 master accounts)** and zero demo clients/transactions.

## 6. Install, check and build (on VPS)

```bash
sudo -u bpz sh -c 'cd /opt/bpz-erp && npm ci && npx next typegen && npm exec tsc -- --noEmit --pretty false && npm run build && npm audit --omit=dev'
```

The `npm audit --omit=dev` line should show **0 production advisories**. If build or audit fails, stop before starting the site.

## 7. Run as a restartable background service

```bash
sudo tee /etc/systemd/system/bpz.service >/dev/null <<'EOF'
[Unit]
Description=BPZ Consult ERP
After=network-online.target postgresql.service
Wants=network-online.target

[Service]
User=bpz
Group=bpz
WorkingDirectory=/opt/bpz-erp
Environment=NODE_ENV=production
ExecStart=/usr/bin/npm run start -- -H 127.0.0.1 -p 3000
Restart=always
RestartSec=5
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable --now bpz
sudo systemctl status bpz --no-pager
curl -fsS http://127.0.0.1:3000/api/health
```

## 8. Enable HTTPS on your domain

DNS from step 1 must resolve first. On the VPS:

```bash
sudo tee /etc/caddy/Caddyfile >/dev/null <<EOF
${DOMAIN} {
    reverse_proxy 127.0.0.1:3000
    header Content-Security-Policy "frame-ancestors 'none'"
}
EOF
sudo systemctl reload caddy
curl -fsS "https://${DOMAIN}/api/health"
```

Caddy obtains and renews the HTTPS certificate automatically. Do not use the sandbox preview URL as your production URL.

## 9. Activate the owner and check the clean database

Before activating:

```bash
sudo -u postgres psql -d bpz_prod -c 'select (select count(*) from users) as users, (select count(*) from clients) as clients, (select count(*) from journal_lines) as journal_lines;'
```

Expected: **users=1, clients=1, journal_lines=0**. If not, stop: the wrong DB or bootstrap mode was used.

Open `https://erp.your-domain.com`. The first-run screen asks for the **setup token** from step 5 and a **new owner password**. Username is `owner`. The sandbox-preview password does **not** carry over. Activation works once; store the new password in your password manager.

## 10. Configure sending mail (before sending real quotations)

Obtain SMTP host, port, username, password, and sender address from your organisation's mail provider, then append them to `/opt/bpz-erp/.env`:

```text
SMTP_HOST=smtp.yourprovider.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=sender@your-domain.com
SMTP_PASS=your-provider-app-password
SMTP_FROM=sender@your-domain.com
```

```bash
sudo chmod 600 /opt/bpz-erp/.env
sudo systemctl restart bpz
```

Send one **test quotation** in Inventory & Store. `MAIL_SENT` in the audit means SMTP delivered it. `MAIL_QUEUED` means SMTP is missing/failed and the operator's mail app was opened instead — it is **not** proof of delivery.

## 11. Schedule backups and copy them off-server

```bash
sudo install -d -o bpz -g bpz -m 700 /opt/bpz-erp/backups
sudo -u bpz sh -c 'cd /opt/bpz-erp && npx tsx scripts/backup.ts'
sudo crontab -u bpz -e
```

Add this single line to the **bpz** user's crontab:

```cron
0 2 * * * cd /opt/bpz-erp && /usr/bin/npx tsx scripts/backup.ts >> /opt/bpz-erp/backups/backup.log 2>&1
```

Verify: `ls -lh /opt/bpz-erp/backups/`. Keep a **second copy off the VPS** (private S3/B2 bucket or managed backup service); a backup on the same VPS is not disaster recovery. Run a restore drill against a **separate empty PostgreSQL database** every quarter; never test restore on `bpz_prod`. The scripts have a tested `--dry-run` mode and restore identity sequences correctly.

## 12. Create a live client and run one parallel close

1. Owner signs in → **Clients & CRM → Client Workspaces** → **New Client Workspace**.
2. Enter **real** legal name, registration number, sector and services; use the generated unique administrator password; submit. This creates client + admin **together on the server**. Copy the one-time credential receipt before closing it. Existing passwords are never re-shown.
3. Switch to that client workspace → **Company Profile & Backup**: fill real legal details, TIN, VAT number, fiscal year start, address and bank details. Empty profiles deliberately contain **no fabricated tax IDs or bank accounts**.
4. Confirm **Chart of Accounts** → **Opening Balances** from the signed prior-period trial balance → **Banking** accounts → customers/suppliers → inventory/assets/employees.
5. Enter the same transactions in BPZ and the existing system for **one full month**. Reconcile trial balance, P&L, balance sheet, bank, AR/AP ageing, inventory, VAT/WHT and payroll; investigate every difference.
6. Only after agreement: **Month-End Close → Financial Statements & IFRS → IFRS Schedules → Compliance Review**. Do not issue a statement while any `DO NOT ISSUE` control is open. Lock the period, then designate BPZ as the book of record.

## 13. Health, updates and password reset

```bash
curl -fsS "https://${DOMAIN}/api/health"   # database + app healthy
sudo journalctl -u bpz -n 100 --no-pager      # app/API logs
sudo systemctl status bpz caddy postgresql --no-pager
```

For each update: **take a backup**, upload the newer exported workspace (excluding `.env`), then run `sudo -u bpz sh -c 'cd /opt/bpz-erp && npm ci && npm run build'` and `sudo systemctl restart bpz`. Never replace the `.env` when updating.

If the owner password is lost, on the VPS run `sudo -u bpz sh -c "cd /opt/bpz-erp && npx tsx src/db/reset-password.ts owner '<NEW-STRONG-PASSWORD>'"`; this revokes old sessions. Use User Access to rotate other staff accounts.

**Go-live gate:** a clean production DB, HTTPS, owner activation, one successful client login, SMTP test, off-server backup with restore drill, and one balanced parallel close are all required before treating this as the authoritative client ledger. Source-code checks alone do not constitute a statutory or security certification.

## 14. Capacity, tuning and pre-go-live load test

**Database pool.** Each app process opens at most `BPZ_DB_POOL_MAX` (default 20) PostgreSQL connections, fails fast after `BPZ_DB_CONNECT_TIMEOUT_MS`, cancels any statement running longer than `BPZ_DB_STATEMENT_TIMEOUT_MS` and terminates sessions left idle inside a transaction after `BPZ_DB_IDLE_TX_TIMEOUT_MS`. Keep `processes × BPZ_DB_POOL_MAX` below PostgreSQL `max_connections` (default 100) minus ~10 for admin/backup.

**Measured capacity** (single app process, local PostgreSQL, 400,000 journal lines across 50 entities):

| Operation | Result |
| --- | --- |
| Post a journal | p50 11 ms · p95 19 ms (flat from 100k → 400k lines) |
| 400 concurrent posts (40 parallel) | 400/400 accepted exactly once · ~126 docs/s |
| Client or owner sign-in (one entity's journal) | 75–113 ms · ~3 MB |
| Workspace sync (browser sends only new documents) | p50 11–15 ms |
| Group Consolidation (every entity's journal) | ~4.7 s · 145 MB — opened on demand only |

**Before go-live, run the load test once on the production server against a throwaway database (never `bpz_prod`):**

```bash
sudo -u postgres psql -c 'CREATE DATABASE bpz_stress_test OWNER bpz_app;'
sudo -u bpz sh -c 'cd /opt/bpz-erp && BPZ_STRESS_DATABASE_URL=postgresql://bpz_app:<DB_PASS>@127.0.0.1:5432/bpz_stress_test STRESS_CLIENTS=20 STRESS_DOCS=2500 npx tsx scripts/stress-test.mts'
sudo -u postgres psql -c 'DROP DATABASE bpz_stress_test;'
```

Expect `Stress test: 25 passed, 0 failed`. The cross-sector accounting test (`scripts/sector-workflow-test.mts`, database `bpz_sector_test`) should report `760 passed, 0 failed`.
