# Project Costing, Debt Service, Exports and Print — Implementation Record

## Repository comparison

Repository: `KwesiDadzie-2000/-BPZ-Consultsss`, branch `main`, commit `22745423437d01daa6e56eedea46fc02d09bf435`.

All 15 ZIP snapshots were searched, including the embedded `upstream-original/source` in `review-and-fix-repository.zip`. Searches covered project costing, project cost, job costing, project accounting, costing, project routes and the original sidebar. No standalone Project Costing component/route was found in the available repository snapshots. The original navigation contains cost-centre reporting, production/WIP and IFRS contract accounting, but no `project_costing` entry. It would therefore be inaccurate to claim an exact original component was recovered.

Project Costing has instead been restored as a dedicated **Accounting & Finance → Project Costing & WIP** desk, using the existing BPZ visual template and accounting infrastructure.

## Implemented workflow

### Project Costing

- Entity-scoped, versioned project register (`entity_workbooks`, kind `project_costing`).
- Unique project code/cost centre, customer, manager, dates, contract revenue and direct/overhead budgets.
- Actual costs, released cost, WIP and recognised revenue derived from posted journals tagged by project cost centre/reference.
- Open purchase commitments from unposted POs; received/invoiced orders are not double-counted as commitments.
- `/api/projects`: source-evidenced allocation of posted expense to WIP and controlled WIP release to cost of sales.
- Server checks tenant/module/posting authority, closed periods, maker limits, source unallocated balance, project WIP, cents precision and UUID retry idempotency.
- Project completion blocked in the UI while WIP or open commitments remain.
- Portfolio, budget and cost-ledger Excel exports; selected project printing.

### Debt service

- Shared cents-precise loan schedule for amortising, interest-only and bullet facilities; monthly/quarterly frequency.
- Final instalment absorbs accumulated monthly rounding; bullet loans accrue interest before cash maturity.
- **Create accrual** is separate from **Pay at Payment Desk**.
- `/api/debt` calculates the accrual from the saved facility schedule: Dr interest expense and/or principal liability, Cr `213000` accrued debt-service payable. It never moves cash.
- Payment Desk lists per-accrual open items. Settlement is Dr `213000` / Cr selected treasury account, with payment authority, funds, period and maker-checker controls.
- Partial payments reduce only the referenced accrual. Direct journal API calls cannot bypass payment authority or create free debt-payable credits.
- Selected loan terms, full schedule and open payables export to XLSX; print targets the selected schedule.

### Exports and print

- Genuine XLSX writer with numeric money cells, frozen headers, filters, print titles and multiple sheets.
- Excel actions added to loan, project, prepayment, capital-allowance, IFRS schedule, IFRS 16 lease and generic report desks. CSV remains available on several existing reports.
- No component `window.print()` calls remain. Print uses an isolated frame containing the selected root only.
- Default module print targets `#active-module-content`; schedule/document buttons target the selected schedule, payslip, invoice or credential slip.
- Print clone preserves selected/input values as text and removes navigation, forms, buttons, alerts, floating controls and scripts. It waits for styles/fonts before printing.

## Verification

- Finance/project/XLSX/accounting unit suite: 60 passed.
- Disposable-database E2E: client restrictions, stale snapshot protection, per-invoice settlement, workbook isolation, debt accrual/partial payment/unauthorized payment, project allocation/replay/over-allocation/WIP release passed.
- API regressions: 22 passed.
- 24-sector workflow: 760 passed.
- Stress (100,000 journal lines, 20 entities, concurrency 40): 25 passed; 400/400 posts accepted exactly once; no unbalanced documents or negative stock.
- Browser verification (`scripts/verify-ui.mjs`): passed. Loan XLSX contained terms, schedule and open-payable sheets; project XLSX contained portfolio, budget and cost-ledger sheets. Both print frames excluded navigation/forms and contained only the selected working paper. Payment Desk debt register rendered; zero browser errors. Temporary draft registers created by the test were deleted.
- Backup/restore: passed between disposable databases (47 tables, matching user/journal/workbook counts, next chart identity preserved). Preview database was not used as a restore target.

## Hosting verdict and conditions

This is suitable for a **supervised pilot**, not an unconditional replacement for an established accounting system. The application cannot supply an independent security review, Ghana-qualified accountant sign-off, executed client loan/tax evidence, or a real parallel-run reconciliation.

Before unsupervised live client books:

1. Complete a full-month parallel run and reconcile bank, AR/AP, inventory/WIP, payroll, VAT/WHT and loan balances to source evidence.
2. Obtain independent security review and accountant approval of configured rates, account mappings and statement layouts.
3. Enable MFA/IdP, production secret management, HTTPS edge controls, monitored off-server backups and a evidenced restore drill.
4. Review remaining dependency advisories (ExcelJS transitive UUID advisory concerns buffer APIs not used by this exporter; do not assume an audit label is a penetration-test result).
5. Confirm loan day-count/EIR/fee treatment, IFRS classification judgments and sector-specific measurement rules for each client. Sector guidance and generic calculators are not regulated bank/insurer core systems.
6. Continue migrating legacy browser snapshot writes to per-record APIs. The new debt/project movements are server-authoritative; the legacy state endpoint remains a compatibility surface with guards, not the final architecture.
