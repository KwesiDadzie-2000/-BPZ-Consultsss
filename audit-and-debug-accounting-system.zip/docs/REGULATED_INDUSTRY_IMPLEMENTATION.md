# Regulated Industry Implementation — Native Kernels and Remaining Gates

## Implemented

A new **Industry Measurement & Regulatory** desk is available under Overview and in the module list of relevant sector profiles. Access is controlled by the `sector_regulation` module and management-accounts service. Runs are entity-scoped, versioned workbooks with source/effective-date evidence and independent maker-checker approval.

| Industry | Native calculation | Accounting integration |
|---|---|---|
| Mining | Approved price-band royalty on payable quantity × reference price × FX; separate GSL statutory base/rate | Approved run posts royalty/GSL expense and sector-levy payable atomically |
| Downstream/upstream petroleum | Official pricing-window per-litre levy schedule; contractual cost-recovery cap and cumulative profit-oil tiers | Approved levy run posts expense/levy payable; fiscal split is a contract working paper |
| Insurance | IFRS 17 GMM probability-weighted discounted fulfilment cash flows, risk adjustment, initial/subsequent CSM, onerous loss, coverage-unit release; eligible PAA LRC | Subsequent GMM service/finance/onerous movements post only when opening GL liability bridges to measured closing liability; initial recognition remains a working paper pending cash/receivable reconciliation |
| Banks/microfinance/fintech | Exposure-level discounted PD×LGD×EAD with stage horizon/default checks; input-basis CAR/liquidity/reserve working papers | ECL allowance true-up posts through existing ledger controls; prudential ratios do not auto-post |
| Pension funds | Custody asset/liability reconciliation; contribution unit issue and benefit unit redemption at transaction NAV | Working paper pending trustee/custodian and member-register reconciliation |
| Agriculture/fisheries | IAS 41 quantity × (fair value − costs to sell), carrying-value movement and harvest transfer | Approved valuation/harvest journal; bearer plants excluded |
| Large manufacturing | Single-level MRP: gross requirement + safety stock − on hand − scheduled receipts, rounded to lot multiple | Planned-order working paper; purchasing/receipt remains through P2P and inventory |

Every server posting recomputes from approved inputs under the shared ledger lock, binds the independent approver as checker, validates chart/period/maker controls, and is replay-safe. Insurance/PAA and petroleum inputs have explicit eligibility/completeness gates. Gold-band examples are not legal defaults: the operator must enter the approved instrument's bands and evidence.

## Sources consulted

- IFRS Foundation, IFRS 17 overview: https://www.ifrs.org/issued-standards/list-of-standards/ifrs-17-insurance-contracts/
- Graphic Online, 16 March 2026, L.I. 2517 stakeholder report (gold sliding scale and exceptions): https://www.graphic.com.gh/news/general-news/ghana-news-stakeholders-raise-concerns-over-new-minerals-royalty-govt-says-its-fair-equitable.html
- WTS Global, Ghana royalty regime analysis (lithium bands and GSL amendment): https://wts-global.com/publishing-article/ghana-new-royalty-regime-for-mining-industry~publishing-article
- Bank of Ghana MPC press release, 20 May 2026 (uniform domestic-currency reserve ratio effective 4 June 2026): https://www.bog.gov.gh/wp-content/uploads/2026/05/MPC-Press-Release-May-2026-.pdf

Secondary reports differ on some gold thresholds. The application therefore does **not** silently encode an ambiguous gold table; it requires the entity's approved instrument/band schedule. NPA pump floors are not treated as levy rates.

## Verification

- Regulated calculation suite: 10 tests (royalty bands/expiry, petroleum split, GMM/PAA, liability bridge, ECL, pension units, IAS 41, MRP).
- Combined accounting/finance/regulated unit suite: 70 passed.
- Regulated E2E: preview → save → submit → independent approval → atomic royalty/GSL posting → replay; unapproved and cross-sector requests refused.
- Existing API: 22 passed; 24-sector workflow: 760 passed; stress: 25 passed, 400/400 concurrent posts exactly once.

## What this does NOT yet certify

The original caution cannot honestly be removed merely because kernels exist. These remain specialist/operational gates:

1. **Insurance:** policy administration, contract boundary/grouping automation, VFA, reinsurance held, acquisition cash-flow allocation, OCI disaggregation, actuarial model governance and NIC solvency returns.
2. **Banks/microfinance/fintech:** customer/deposit accounts, payment rails, loan servicing, regulatory capital adjustments/RWA engine, LCR/NSFR definitions, large-exposure limits, AML/KYC and BoG return certification.
3. **Pension funds:** member records, benefit calculations, trustee/custodian feeds, contribution compliance and NPRA returns.
4. **Mining/oil:** concession/stability agreements, assay/lifting custody chains, official price-index feeds, petroleum-agreement tax/PPT computations and regulator portal integration.
5. **Agriculture:** independent market valuations, biological quantity controls, bearer-plant separation and harvest custody evidence.
6. **Large manufacturers:** multi-level BOM explosion, capacity/shop-floor scheduling, lot/serial traceability and supplier planning integration.
7. MFA/IdP, independent security review, production backup/restore monitoring, current-law sign-off and a full parallel run remain required.

**Verdict:** these industries can now use the system for controlled, evidence-backed sector measurement and selected accounting postings in a supervised implementation. It is not yet a complete regulated core operating platform or a certified regulatory filing system for every institution in those sectors.
