# BPZ Consult ERP — Independent System Review, Critique and Remediation

**Review date:** 5 November 2026  
**Source reviewed:** latest snapshot in `KwesiDadzie-2000/-BPZ-Consultsss` (`upgrade-system-to-global-standards.zip`, 5 Nov 2026)  
**Scope:** preserve the original application and visual template; audit the running system; fix defects; implement the requested restructuring.

---

## 1. Preservation statement

| Item | Decision |
| --- | --- |
| Original project files | Imported unchanged from the latest snapshot: `src/App.tsx`, all existing components, `src/db`, `src/lib`, `src/utils`, `src/data`, `src/types`, `src/tests`, the hardened `next.config.ts`. |
| Visual template | Preserved. The BPZ palette (`#082f4f` navy, `#f5b719` gold, `#f0f6fc` workspace), header, workspace card, sidebar styling, cards, tables and print behaviour are unchanged. |
| Existing modules | None removed. Every original module id still resolves in the router, so old links and permissions continue to work. |
| Existing security controls | Retained: scrypt password hashing, HttpOnly + bearer sessions, sliding expiry, entity scoping, maker-checker approvals, period locks, immutable posting/reversal, audit log, first-run owner activation, security headers. |
| Destructive changes | None. All schema additions are additive and self-provisioning (`CREATE TABLE IF NOT EXISTS`). |
| New functionality | Added as new modules/desks and new sidebar groups; existing components are re-used, not forked. |

---

## 2. Critique of the system as received

**What was already working**

- Double-entry journal with balanced-posting validation, idempotency, reversal and maker-checker approval.
- Entity-scoped workspace state with server sync, offline resilience and optimistic concurrency.
- Authentication (scrypt, session table, activation, lockout) and user administration controls.
- IFRS standards content, IFRS schedules with GL reconciliation and correcting-journal proposals.
- Financial statements, notes, fixed assets, prepayments, tax, banking, procurement/P2P, sales/O2C, payroll, budgeting/forecasting, analytics, consolidation.
- Responsive shell with an off-canvas mobile drawer and print-to-working-paper support.

**What was not working / not meeting the brief**

1. **Two IFRS modules.** “IFRS/IAS Standards Desk” and “IFRS Schedules Desk” were separate destinations. A user had to know which one held the requirement and which held the calculation; cross-links left the module. The knowledge and the proof of the number were disconnected.
2. **Unusable navigation.** More than forty modules in a flat list (and a second flat owner list). There was no sales/procurement/HR/CRM/report grouping, no dropdowns, no module search, and duplicates such as two business-partner entries.
3. **Reports were scattered and incomplete.** No Reports centre. The explicitly required set — Sales, Purchases, Inventory, Clients and Store Reports — did not exist as a coherent destination with consistent export/print.
4. **Human Resources stopped at payroll.** There was no employee directory beyond payroll rows, no organisational structure, no attendance register, no leave/advance request workflow, and no HR task management.
5. **No client-relationship desk.** Clients existed only as accounting master records and invoices. No contacts, pipeline, activities, service tickets or account 360° view.
6. **Inventory was a ledger, not a store.** It could receive/issue/write down stock, but could not manage a sellable catalogue with picture/barcode, issue quotations, raise and follow purchase orders, or alert on the reorder level defined per product. It also could not delegate store access from within the desk.
7. **Tab state did not follow navigation.** Opening “HR → Attendance” after “HR → Employees”, or switching between report links, kept the previously mounted tab because the component key only included the entity.
8. **PII in the audit trail.** A new-desk prototype wrote the full record payload into `audit_log.details`, copying contact emails and phone numbers into an immutable log.
9. **Missing server-side authorisation on desk mutations.** The UI restricted HR approvals to managers, but the API did not; auditors were not read-only at the API layer.
10. **Duplicate product codes.** The catalogue accepted an existing SKU again, creating two product records for one physical item.
11. **UTC date drift in new desks.** Default “today” values used `toISOString()`, which is the wrong calendar day for users outside UTC around midnight.
12. **CSV injection risk.** Reports needed a shared exporter that neutralises formulas in every cell.

---

## 3. Findings and fixes

| ID | Severity | Finding | Fix implemented | Evidence |
| --- | --- | --- | --- | --- |
| F01 | High | Two disconnected IFRS modules | New `IfrsDesk` merges both under one sidebar entry and one URL-reachable section (`ifrs_desk`). Tabs: *Standards & application* and *Schedules & working papers*. Cross-links from IAS 16 etc. switch tab instead of leaving the module. Legacy ids (`standards_desk`, `ifrs_schedules`) still render the merged desk. | `src/components/IfrsDesk.tsx`, `src/App.tsx` |
| F02 | High | 40+ flat modules | Sidebar rebuilt as ten collapsible categories: Overview, Sales, Procurement, Inventory & Store, Accounting & Finance, Human Resources, Performance Management, Clients & CRM, Reports, Enterprise Administration. Includes module search and auto-opens the active category. Original palette, workspace card and drawer behaviour retained. | `src/components/AccountingSidebar.tsx` |
| F03 | High | No reports centre / required reports missing | `ReportsHub` with Sales, Purchases, Inventory, Clients, Store, HR & Payroll, Financial reports; KPIs, bar analytics, trial balance, CSV export through a formula-neutralising exporter, browser print. Sidebar Reports group lists Sales Reports, Purchases Reports, Inventory Reports, Clients Reports, Store Reports, HR & Payroll Reports and Financial Reports. Legacy report aliases resolve to the right tab. | `src/components/ReportsHub.tsx`, `src/components/DeskKit.tsx` |
| F04 | High | HR limited to payroll | New HR desk: employee directory with search/segment/add, KPI headcount and payroll cost, organisational units with parent/manager/headcount, attendance register with daily summary, leave/advance/overtime/training requests with approve/reject, and a three-column task board with priorities, due dates and overdue flags. | `src/components/HrManagementDesk.tsx` |
| F05 | High | No CRM | New Client Relationship Desk: 360° overview, client accounts with billed/outstanding/health, contact book, six-stage pipeline with weighted forecast, activity timeline with outcome/next step, and a client service desk. Financial figures come from the sales ledger, not re-keyed. Links to the client master file and clients reports. | `src/components/CrmDesk.tsx` |
| F06 | High | Inventory was ledger-only | New store-operations workspace inside the inventory module: unlimited product catalogue with picture upload (browser-downscaled), barcode field, cost/selling price, reorder level and store location; quotations with VAT and email-to-client; purchase orders with supplier email, expected date and status follow-up; reorder alerts with one-click replenishment; supplier directory. Original stock ledger and valuation preserved as a second tab. | `src/components/StoreOperationsDesk.tsx`, `src/components/InventoryWorkspace.tsx` |
| F07 | Medium | Tab state ignored navigation | Desk hubs are keyed by entity **and** section, so each navigation intent mounts with the requested tab. | `src/App.tsx` |
| F08 | High (privacy) | PII copied into audit log | Desk API records **field names only** in `audit_log.details`; values never enter the immutable log. | `src/app/api/desk/route.ts` |
| F09 | High (authz) | Desk mutations not role-checked server-side | Auditors are read-only; HR request approval/rejection requires owner, partner or manager. Checks are enforced in the API, not just the UI. | `src/app/api/desk/route.ts` |
| F10 | Medium | Duplicate product codes | Catalogue rejects an existing SKU with a clear message and re-uses existing product metadata for updates. | `src/components/StoreOperationsDesk.tsx` |
| F11 | Medium | UTC date drift | New desks derive today from the local calendar (timezone-offset corrected). | `src/components/DeskKit.tsx`, HR/store desks |
| F12 | Low | Duplicate navigation entries | Duplicate report and business-partner links removed; each module appears once in a logical category. | `src/components/AccountingSidebar.tsx` |
| F13 | Medium | CSV formula injection | One exporter neutralises `= + - @`, tab and CR prefixes and quotes every cell. | `src/components/DeskKit.tsx` |
| F14 | Medium | Tenant scope and audit for new data | New `desk_records` table is client-scoped; every read/write is scope-checked and every mutation is audit-logged. | `src/db/schema.ts`, `src/db/extensionsDdl.ts`, `/api/desk` |

---

## 4. Module map after restructuring

| Category | Modules |
| --- | --- |
| **Overview** | Command Center · Company Profile & Backup · Opening Balances |
| **Sales** | Sales & Invoicing (O2C) · Client Profitability |
| **Procurement** | Procurement & P2P · Payment Desk |
| **Inventory & Store** | Inventory Command Desk (products, barcodes, quotations, purchase orders, alerts, suppliers) · Stock Ledger & Valuation · Inventory Reports · Store Reports |
| **Accounting & Finance** | **IFRS Desk (Standards + Schedules)** · Financial Statements & IFRS · General Ledger · Chart of Accounts · Universal Journal · Manual Journal · Adjustments · Banking & Reconcile · Expenses & Statutory · Fixed Assets · Prepayments · WHT & VAT · Tax & Statutory Returns · Month-End Close · Notes to Accounts · Loan Amortisation · Compliance Review · Group Consolidation |
| **Human Resources** | HR Management Desk · Employees · Organisational Structure · Employee Attendance · Employee Requests · Task Management · Payroll Desk · HR & Payroll Reports |
| **Performance Management** | Budgeting, Forecast & Scenarios · Data Analytics & CAATs · Financial Reports |
| **Clients & CRM** | Client Relationship Desk · Client Master File · Client Workspaces (owner) · Advisory & Timesheets (owner) |
| **Reports** | Reports Centre · Sales · Purchases · Inventory · Clients · Store · HR & Payroll · Financial |
| **Enterprise Administration (owner)** | Users & Restrictions · SSO · Tax Settings · Global Tax Reference · SOC 2 & DR · API & Webhooks |

---

## 5. Audit evidence

| Check | Result |
| --- | --- |
| `npx next typegen` | Pass |
| `tsc --noEmit` | Pass (0 errors) |
| `npm run build` | Pass — 14 routes, desk route included |
| `build_and_start` healthcheck | Pass (`/api/health` → `{"ok":true}`) |
| First-run activation | Pass (`/api/auth/setup` available → owner activated once) |
| Login after activation | Pass (HTTP 200, session cookie + bearer token) |
| Workspace state | Pass (`/api/bootstrap` returns all 20 entity-scoped collections) |
| Desk API auth | Unauthenticated `GET /api/desk` → **401** |
| Desk API validation | Unknown desk → **400**, rejected |
| Desk API CRUD | Create + list + role guard path verified for `hr`, `crm`, `store` |
| Audit trail | Mutations appear under `HR_CREATED`, `CRM_CREATED`, `STORE_CREATED`; details contain field names only |

### Sign-in

The workspace uses the original first-run activation flow. Activation has already been completed in this environment with the owner username `owner`. Set/rotate the password through **Company Profile & Backup → security** or the owner user desk; no credential is hard-coded in source control.

---

## 6. Residual risks and recommended next steps

1. **File storage.** Product photos are compressed in-browser and stored as data URLs. For thousands of catalogue items, move to object storage (S3/GCS) with signed URLs.
2. **Offline-first desks.** The ledger keeps offline resilience; the new desks require connectivity. Add an IndexedDB queue if field staff must work offline.
3. **Approval workflows.** HR request decisions are audit-logged and role-gated; a two-step delegation matrix (department head → HR → finance) would be the next control.
4. **Integration.** The supplier/client email actions use the device mail client. A server-side mail provider with delivery receipts would make sending verifiable.
5. **Statutory localisation.** HR/payroll figures are derived from the existing Ghana payroll engine; other jurisdictions need their own tax tables and leave rules.
6. **Database backups.** The original SOC 2/DR desk remains; schedule and test restores outside the application.


## 7. Professional opinion

### Would I buy this system today for my own accounting operations?

**Before these latest fixes: not yet.** The platform had impressive breadth, but too much of the workflow depended on the user already knowing where things lived. That is dangerous in accounting: a system is not globally ready because it has many modules; it is globally ready when the **right correction path is obvious, controlled and traceable**.

### Why I would have hesitated

1. **Too many modules at face value.** The issue was not that the system had too much capability; it was that capability was exposed as too many separate destinations. For accountants, cognitive load is a control risk.
2. **Weak remediation guidance.** A failed control that says “something is wrong” without taking me to the exact fixing desk is not operationally good enough.
3. **Evidence chain gaps.** Notes, schedules and statements must behave like one evidence stack. Previously they were related, but not tightly enough linked for fast close and review.
4. **Mixed operational/reporting boundaries.** Reports appearing across modules made the information architecture noisier than it should be.
5. **Periodicity controls needed to be real, not decorative.** In FP&A, if monthly/quarterly/annual does not materially change the analysis, users lose trust very quickly.

### After these latest fixes

**Now I would classify the system as purchaseable for a growing multi-entity accounting operation, subject to implementation governance and user acceptance testing.**

### Final critique on module count

- **The system does not have too many capabilities.**
- **It did have too many exposed module endpoints.**
- The correct answer was **not** to delete accounting depth; it was to **group, alias and cross-link** the depth under business workflows.

### What still matters in a real deployment

Even after these repairs, production readiness still depends on:
- clean chart-of-accounts governance,
- disciplined role design,
- closing-calendar ownership,
- tested backup/restore,
- formal UAT scripts across sales, procurement, inventory, payroll, tax and IFRS reporting.

In short: the system is now far closer to something I would actually operate, because the missing links were workflow links, not just extra screens.


## 8. Audit round — Payment placement, ageing analysis & production readiness (live client books)

### Critique
1. **Payment Desk sat under Procurement.** Conceptually wrong: procurement commits spend (P2P), but cash movement, treasury control, statutory remittance and maker-checker settlement belong to **Accounting & Finance**. Keeping it under Procurement blurred segregation between committing and paying.
2. **Ageing analysis was missing as a first-class desk.** The only ageing was two small summary buckets inside the Payment Desk (30-day terms assumed, no due-date control, no per-party or per-document view, no export, no ECL link). For live books this is a control gap: collectors, payables clerks, auditors and IFRS 9 all need proper AR/AP ageing.
3. **Date handling used UTC defaults in posting paths** (`App.postDate`, Payment Desk as-of, Banking FX date, Manual Journal posting date, Statutory through-date). Around midnight/month-end in Africa/Accra (UTC+0, no DST — low risk) and for UK entities (BST/GMT shifts), UTC defaults can pick the wrong posting period and trip period locks incorrectly.
4. **Dashboard did not surface treasury.** After moving Payment to Finance, the Command Center still launched only MM/SD/HR/AA/IFRS/loans — the cash gateway was one click further than it should be.

### Fixes implemented
- **F15 — Payment Desk moved to Accounting & Finance** (sidebar `finance` group, directly after Banking & Reconcile). Procurement group now contains only Procurement & P2P. All existing `payment_desk` deep links (P2P, O2C, Expenses, payroll, trade cards, statutory cards) keep working — only the grouping changed.
- **F16 — Treasury permission model corrected**: `payment_desk`, `banking`, `ageing` now map to `management_accounts` (finance), with a fallback so clients holding EITHER `bookkeeping` OR `management_accounts` keep treasury visible. No live client loses the cash gateway after a service change.
- **F17 — New Ageing Analysis desk (`ageing`)**: live AR (sales invoices) + AP (supplier bills + ledger-derived expense bills), as-of date, selectable credit terms (0–90 days), due-date ageing into Current / 1–30 / 31–60 / 61–90 / Over-90, per-party summary ranked by exposure, oldest-first document detail, search, CSV export, and one-click links to Payment Desk, Sales, Procurement and the IFRS 9 ECL schedule. Empty states guide a brand-new live client (no crashes on zero data).
- **F18 — Ageing available in two places, correctly**: standalone module under Accounting & Finance (`Ageing Analysis (AR & AP)`) AND a tab inside Reports Centre (`Ageing analysis (AR & AP)`) with `report_ageing_r` routing. No duplicate rendering (bare `ageing` renders only the desk).
- **F19 — Payment Desk summary cards now link to the full desk** ("Open full ageing analysis →").
- **F20 — Local-calendar posting dates**: `App.postDate`, Payment Desk as-of, Banking FX date, Manual Journal posting date and Statutory through-date now use `localToday()` so period locks evaluate the user's actual business date.
- **F21 — Dashboard treasury tiles**: Command Center now launches Payment Desk (Finance) and Ageing Analysis directly.

### Production readiness for live client books
- New live client path verified: Client Workspaces → create workspace + admin credentials → Company Profile → Chart of Accounts → Opening Balances → Bank accounts → day-one postings (sales, procurement, expenses, payroll) → Payment Desk settlement → Month-End Close → Financial Statements. Each step is entity-isolated and audit-logged.
- Period control: posting paths honour the closed-period guard; month-end lock/unlock remains owner/manager-controlled.
- Maker-checker: payments above maker limit queue for independent approval; session revocation on reset/restriction retained.
- Backups: Company Profile export + SOC 2/DR desk retained; recommend a tested off-site backup schedule before go-live.
- Remaining recommendation (not a blocker): schedule automated DB backups, confirm SMTP/API mail for supplier/client documents, and run one full parallel close (old books vs BPZ) per live entity before cutover.


## 9. Audit round — Outstanding items closed (backups, mail channel, deployment)

### What was still outstanding
1. **Backups were a desk description, not a mechanism.** SOC 2/DR guidance existed, but there was no runnable backup/restore tooling or retention.
2. **Document delivery depended on the user's mail client only.** Quotations and purchase orders used `mailto:` links — fine as a fallback, but no server delivery, no delivery log, no proof of sending.
3. **No deployment/go-live documentation.** Nothing covered server sizing, Postgres provisioning, TLS/reverse proxy, secrets, first-run hardening, or the parallel-close procedure for live client books.

### Fixes implemented
- **F22 — Automated logical backups**: `scripts/backup.ts` snapshots every public table to a gzipped JSON file (`BPZ_BACKUP_DIR`, retention `BPZ_BACKUP_KEEP`, default 14). `scripts/restore.ts` restores with `--dry-run` verification and refuses to overwrite a non-empty database without `--force`. `pg_dump` remains the recommended tool at scale (documented).
- **F23 — Server e-mail channel**: `POST /api/mail` — authenticated, tenant-scoped, auditor read-only, size-limited; sends via SMTP when `SMTP_*` is configured (`MAIL_SENT`), otherwise records a **queued** delivery (`MAIL_QUEUED`) and the client opens the device mail client — nothing is silently dropped. Every dispatch is audit-logged (recipient/subject/status only) and retained in the per-entity delivery log (`desk_records`, desk `system`, kind `mail_delivery`). Store quotations and purchase orders now send through this channel.
- **F24 — Deployment & go-live guide**: `docs/DEPLOYMENT_GUIDE.md` — topology, PostgreSQL provisioning, environment variables, systemd/Docker running, Caddy/Nginx + TLS, firewalling, backup cron + restore drills, SMTP setup, health monitoring, update/rollback, troubleshooting, and the **per-entity parallel-close checklist** for recording live client books safely.

## 10. Deployment validation and live-data safeguards

- **Critical framework advisory fixed:** Next.js updated from 16.2.6 to 16.4.5; transitive `source-map-js` updated to 1.2.2. `npm audit --omit=dev` reports **zero runtime advisories** in this build.
- **Clean production bootstrap:** `BPZ_BOOTSTRAP_MODE=production` seeds exactly one pending-activation owner, one firm workspace, 205 master chart accounts and **no sample transactions**. A setup token (at least 24 characters) and a valid `BPZ_OWNER_EMAIL` are required before the first request; the regular demo preview still uses its original seed.
- **Client onboarding was not atomic:** the old form inserted a client in browser state, then fired an asynchronous user request before the client existed server-side. A new owner-only `/api/clients` route now creates client + administrator + audit entry in one transaction, rejects duplicate usernames/codes/emails and enforces password policy. The UI waits for the HTTP result and only displays a one-time generated password after success.
- **Security of default data:** removed the shared `BpzClient2026!` client password fallback and fabricated TIN/VAT/bank defaults for new client profiles. Existing passwords are never displayed again; staff must reset them through User Access.
- **User access changes:** removed duplicate fire-and-forget user mutations. The permissions desk updates its browser cache only after `/api/users` confirms success; a rejected role/status change no longer looks applied.
- **Backups/restore:** backup now takes a repeatable-read snapshot; restore checks tables, fails on conflicts, overrides identity IDs and resets sequences. A full 42-table backup was restored into a scratch DB, and the next generated ID was verified.
- **E2E smoke tests:** in a disposable PostgreSQL database, production boot produced 1 user / 1 client / 0 journal lines / 0 invoices / 0 purchase orders; owner activation HTTP 200, client creation HTTP 201, duplicate creation HTTP 409, new client login HTTP 200.
- **Hosting:** the GitHub URL referenced by the user contains ZIP snapshots only, not the updated workspace. Export THIS workspace and follow `docs/DEPLOYMENT_GUIDE.md`. Do not connect production to the preview DB or reuse preview credentials.

## 11. Manufacturing & complex-entity workflow (closed the manufacturing→sales gap)

### Critique
The sector data already classified entities as extraction / manufacturing / construction, but the system had **no production modules**: no Bill of Materials, no Work Orders, no Production Orders, no Work-in-Process accounting, and no link from produced finished goods into sellable stock/sales. A manufacturing, mining, oil & gas, quarry, construction or real-estate entity could not record production, cost it, or move finished output into the sales ledger — a critical gap for any production-led entity.

### Fixes implemented
- **F25 — Bill of Materials desk (`boms`)**: defines components consumed per unit of a finished item, with qty per unit, UoM and waste %. Stored per entity via the operations desk API, audit-logged.
- **F26 — Production Desk (`production_desk`)**: complete production loop:
  - **Work Orders**: create and release orders for a finished item, with WIP / finished-goods / raw-material GL accounts and cost centre.
  - **Issue Materials** (`production_issue`): Dr WIP (122000) · Cr Raw Materials (120000), with a perpetual stock movement — reduces raw-materials stock, increases WIP.
  - **Receive Finished Goods** (`production_receipt`): Dr Finished Goods (121000) · Cr WIP, with a perpetual stock receipt — increases sellable finished-goods stock, relieves WIP.
  - **WIP Ledger**: issued vs received vs WIP balance by order, with order status flow Draft → Released → In Production → Completed → Closed.
- **F27 — Production & WIP report (`report_production_r`)**: WIP by order, materials issued vs received vs WIP balance, in the Reports Centre.
- **F28 — Sidebar**: new "Manufacturing & Production" category with BOM and Production Desk; "Production & WIP" added to Reports.
- **F29 — Chart of accounts**: WIP (122000), Finished Goods (121000), Raw Materials (120000) already existed and are wired to production postings.
- **Schema**: `bill_of_materials`, `production_orders`, `production_issues`, `production_receipts` tables + idempotent DDL; all mutations tenant-scoped and audit-logged.

### Resulting workflow (manufacturing → sales)
1. Create a BOM for the finished item (components + qty per unit + waste %).
2. Release a Work Order for the finished quantity.
3. Issue raw materials to the order → Dr WIP / Cr Raw Materials + stock movement.
4. Receive finished goods from the order → Dr Finished Goods / Cr WIP + stock receipt.
5. The finished item is now sellable stock: raise a Sales Invoice in Sales & Invoicing (O2C), which auto-posts Dr Receivables / Cr Revenue and Dr COGS / Cr Finished Goods.

### Live smoke test (passed on preview)
Owner login → create BOM → create released work order → issue 200 kg raw material → receive 100 kg finished goods → order listed. WIP moves from issued to received as goods are completed and becomes available to sell.


## 12. Sector workflow switcher + manual-driven redesign (manufacturing → complex entities)

### Critique
The system had Ghana sector **tax** data but no sector **workflow** engine: opening a mining, construction, healthcare or SaaS client's workspace did not change the accounting workflow to that industry. The BPZ manual (Sections 2–12) requires a sector switcher: common backbone first, then sector modules per legal entity.

### Fixes implemented
- **F30 — Sector profile engine (`src/data/sectorProfiles.ts`)**: all 24 Ghana sectors mapped to workflow profiles — operational flow (event→posting→report), emphasised modules with deep links, dimensions, key GL accounts, recognition notes, close controls, sector compliance calendar (PAYE 15th, SSNIT 14 days, VAT last working day, CIT instalments, annual returns + sector filings: mining price-linked royalty L.I. 2517, PPT 35%, UPPF/ESRL, CST 5%, Tourism Levy 1%, BoG/NIC/NPRA/NCA/FDA/GTA returns, etc.). Verified: 24 profiles load with correct flows.
- **F31 — Sector Workflow Switcher desk (`sector_workflow`)**: shows the active profile and lets the owner re-classify the entity sector; the workspace re-arms everywhere (header badge, sidebar highlights, dashboard card, this desk).
- **F32 — Automatic switching**: header shows the active sector-mode badge; sidebar badges sector-relevant modules ("SECTOR") and highlights them; Command Center dashboard shows the sector workflow card with module shortcuts and an "Open switcher" link. Switching client workspaces re-derives the profile from `currentClient.sector` automatically.
- **F33 — Manufacturing loop closed for production entities**: BOM desk, Production Desk (work orders → issue materials Dr WIP/Cr RM → receive FG Dr FG/Cr WIP), WIP ledger, Production & WIP report. Finished goods become sellable stock → Sales & Invoicing auto-posts COGS. Live smoke test passed (BOM → WO → issue → receipt → order listed).
- **F34 — access map**: sector_workflow, boms, production_desk, report_production_r added so all roles see the new modules per contracted services.

### Resulting workflow per sector (examples)
- **Mining/quarry/oil & gas**: licence → work order → extraction → stockpile → processing → assay → sale → royalty/tax (price-linked L.I. 2517) → close obligations.
- **Construction/real estate**: tender → contract (IFRS 15 over-time) → budget → procurement → site measurement → certification/billing → retention → completion/defects.
- **Manufacturing/agro/pharma**: BOM → production order → WIP → FG inspection → dispatch → sale → variance reporting.
- **Trade/retail/import-export**: contract → shipment/customs → landed cost → sale/export → FX & tax reconciliation; POS settlements.
- **Agriculture/fisheries**: cycle → inputs → biological measurement (IAS 41) → harvest → grading → cold store → sale.
- **Banks/fintech/insurance/funds**: onboarding → facility → disbursement → interest/fees → ECL (IFRS 9) / IFRS 17 → safeguarding → regulator returns.
- **Utilities/telecom/transport**: tariff → meter/usage → billing & unbilled accrual → collections → levies; job/route costing.
- **Hospitals/schools/hotels/SaaS/professional services**: registration/enrolment/reservation/engagement → service delivery → claims/fees/billing → IFRS 15 recognition → collections → sector regulator filings.

## 13. Specialist audit round — module collisions, production integrity, sector testing

### Critique (accounting-software and accounting-practice view)
1. **Sector workflow collided with every module.** The sector profile re-skinned the global header, badged and recoloured sidebar items, and replaced the Command Center card, so procurement, payroll and every other desk appeared to show only sector-workflow content. Sector guidance is policy reference material; it must never sit on top of transaction screens.
2. **Production was a prototype, not a ledger.** Work orders, issues and receipts were editable JSON records: issues could be logged without reducing stock, finished goods could be received with no WIP behind them, unit costs were typed in by the user, document numbers repeated (`WOISS-<order>` reused on every issue), BOM “Add line”/“Edit lines” controls did nothing, and there was no way to capitalise direct labour/overhead.
3. **Reports Centre mixed entities.** It received the whole multi-entity journal, so the owner’s trial balance there combined clients’ books.
4. **Wrong or missing GL mappings in sector profiles.** Banking “customer deposits” pointed to 210000 (borrowings), insurance revenue to 410000 (silver by-product sales), insurance liabilities and client trust money to 230000 (lease liabilities), hospitality tourism levy to 225000 (contract liabilities); 141000, 215000 and 218000 did not exist. No royalty-payable or IAS 41 fair-value-gain account existed.
5. **Inventory valuation and opening balances.** The product form created stock quantity and value with no journal (an off-ledger opening balance); reconciliation checked only 120000, ignoring finished goods in 121000; the final unit of a weighted-average item could leave residual cents; finished-goods COGS credits were captioned “Raw Materials”; the stock-ledger category was free text, so a typo silently mapped finished goods to raw materials.
6. **Controls gaps.** Auditors could submit full-state writes; a stale browser tab could overwrite server-posted production stock; the clean-production owner had a zero maker limit (read-only, so could not post); transactions dispatched concurrent queries on one database client (pg@9 incompatibility, unclear lock order).
7. **Redundant modules.** “Universal Journal” and “Manual Journal Entry” opened the same screen; “WHT & VAT Schedules” and “Tax & Statutory Returns” (ids differing by one letter) were one monthly cycle split in two.

### Fixes implemented
- **F35 — Sector guidance contained.** Removed sector styling/badges from header and sidebar and the large dashboard card; the profile lives only in **Overview → Sector Workflow Switcher**, with a small reference link on the dashboard.
- **F36 — Server-authoritative production (`/api/production`).** One transaction, under the shared ledger lock, commits the stock movement, item master, balanced journal (period lock, chart, posting identity and maker-checker validated), production record and audit entry. Controls: BOM required to open/release; manager release and close; issues limited to the approved BOM plan incl. normal waste; negative stock blocked; output limited to the open quantity **and** to what issued BOM materials support; WIP allocated from the **posted 122000 balance** (final receipt clears every cent); close only at zero WIP; UUID request keys make every retry idempotent; unique work-order numbers per entity.
- **F37 — Conversion costs.** Direct labour/overhead is capitalised by reclassifying an already-posted expense (Dr WIP / Cr expense) with evidence; the server prevents allocating more than the source document's unallocated amount and never creates a second expense or payment.
- **F38 — Functional BOM desk and GL-backed production report** (material + conversion − FG received reconciled to WIP by order); generic desk API no longer accepts production writes; legacy prototype records are flagged, never valued.
- **F39 — Reports Centre entity-scoped.** Receives only the active entity's journal.
- **F40 — Chart corrected.** Added 141000 Investment Property, 215000 E-money/Wallet Liabilities, 216000 Customer Deposits, 217000 Refundable Deposits, 219000 Client Money/Trust, 227000 Mineral Royalty & Sector Levies Payable, 231000 Insurance Contract Liabilities, 232000 Restricted Grants, 417000 IAS 41 Fair-Value Gains; every sector key account now resolves to a correctly classified account. An idempotent startup migration adds new master accounts to existing databases without altering existing accounts or tailoring.
- **F41 — Inventory integrity.** Product masters start at zero (balances only via posted receipts); finished goods default to 121000; reconciliation covers 120000/121000/123000 (biological 124000 stays under IAS 41); last-unit issue clears residual value; correct stock captions on every posting; controlled category list.
- **F42 — Controls.** Auditors/restricted users blocked from state writes (server and client); full-state sync preserves server-posted production/trade movements and journals under the posting lock; production owner limit fixed; transaction queries serialised (`src/lib/sequential.ts`).
- **F43 — Module merges.** One **Journals (Universal & Manual)** entry; one **Tax Desk** with tabs *1 · WHT & VAT schedules* and *2 · Returns, reconciliation & filing*. All old links still resolve; a scan confirmed zero dead menu, shortcut or sector-profile links.

### Standardized cross-sector test (`scripts/sector-workflow-test.mts`)
Each of the 24 Ghana sectors is onboarded and run through: share capital → services purchase with 20% input VAT → stock receipt (trading/production sectors) → payroll (PAYE; SSNIT 5.5%/13% split 13.5% Tier 1 / 5% Tier 2) → full manufacturing loop (BOM, idempotent order, release, BOM-limited issue, labour allocation, partial and final output, zero-WIP close) → sale with VAT, CST cascade (telecom), tourism levy (hospitality) or petroleum levy (downstream) → goods sale with COGS at carrying cost → sector events (royalty, decommissioning, unbilled contract assets, IAS 40, IAS 41, IFRS 9 ECL, deposits, wallets, IFRS 17, deferred revenue, grants, trust money) → receipt → supplier payment net of WHT (goods 3%, works 5%, services 7.5%) → salaries and statutory remittances → VAT settlement. It then asserts a balanced TB, cleared AR/AP/payroll/tax controls, exact cash, sector balances, FG cost (41,000 materials + 9,000 labour = 50,000), WIP = 0 and stock register = stock GL, plus negative controls (cross-tenant, unbalanced, closed period, replay idempotency, BOM overrun, over-receipt, conversion over-allocation, early close, auditor writes).

| Suite | Result |
| --- | --- |
| Cross-sector workflow (24 sectors) | **760 passed, 0 failed** |
| API regressions (now `apiRegression.test.mts`, ESM) | 22 passed |
| IFRS extensions | 10 passed |
| Review regressions | 43 passed |
| Posting controls | 47 passed |

## 14. Developer audit and stress test — production readiness

### Method
A new destructive load/concurrency harness (`scripts/stress-test.mts`, disposable `bpz_stress_test` database only) seeds 100,000–400,000 journal lines across 20–50 entities, measures the hottest server paths, and races concurrent writers. Every race ends in an integrity assertion: balanced documents, exactly-once storage, control headers present, no negative stock, stock GL = stock register.

### Defects found and fixed
| ID | Severity | Finding (evidence) | Fix |
| --- | --- | --- | --- |
| F44 | **High (security)** | 12 parallel wrong-password attempts all returned 401 — lockout never triggered, because the attempt was counted only after the async scrypt check. | Attempt counted before verification; success clears it. Failure tracker bounded (50,000 identities) against random-identity floods. |
| F45 | **High (availability)** | No body-size limits: a 200,000-line payload was parsed (400), not refused. | `readJsonBody` with per-route ceilings (login 16 KB, journal 2 MB / 2,000 lines, users 64 KB, state 25 MB, others 1 MB) → 413. |
| F46 | **High (scalability)** | Every workspace sync read the **entire multi-tenant journal** (twice — once inside the global posting lock) plus all stock movements/items: ~1 s per sync at 100k lines, growing with every client. | Journals are append-only, so only the payload's documents are compared (chunked, tenant-scoped); stock preservation reads only server-owned production/trade movements for the caller's entities; line-id collision check targeted. |
| F47 | **High (scalability)** | The browser resent its whole journal on every edit (36.5 MB for the owner at 100k lines). | Delta sync: the browser tracks server-acknowledged documents and sends only unacknowledged ones. |
| F48 | **High (scalability)** | Owner sign-in shipped every entity's ledger (145 MB, 4.8 s at 400k lines). | Bootstrap `?entity=<id>` for firm-wide users; other entities load on first switch; all entities only when Group Consolidation opens. Client users cannot widen their scope. |
| F49 | Medium | Client bootstrap loaded all tenants' rows and filtered in JavaScript (414 ms). | Tenant filter pushed into SQL for all 15 operational tables. |
| F50 | **High (resilience)** | Pool had no error listener: a dropped idle connection (DB restart) emits an unhandled `error` that terminates Node. No statement / idle-transaction / connect timeouts; unbounded pool sizing. | Error listener; `BPZ_DB_POOL_MAX`, connect, statement and idle-in-transaction timeouts (env-tunable). |
| F51 | Medium | Missing indexes: journal lookups by document number across entities; audit trail sorted by timestamp unindexed. | Added `journal_lines(doc_no)`, `journal_headers(doc_no)`, `audit_log(timestamp)`, `audit_log(client_id, timestamp)`, `stock_movements(client_id, doc_no)`. |
| F52 | Low | Financial statement tabs re-synced to props via effects (double render, stale first frame); waterfall chart mutated a variable during render. | Remount per destination; pure running total. |
| F53 | Low | HSTS / COOP headers absent. | Added (HSTS is ignored over plain HTTP). |

### Results (single process, local PostgreSQL)
| Metric | 100k lines before | 100k after | 400k after |
| --- | --- | --- | --- |
| Journal POST p50 / p95 | 14 / 21 ms | 11 / 19 ms | 11 / 19 ms |
| 400 concurrent posts | 98 docs/s | 125 docs/s | 126 docs/s |
| Client bootstrap | 414 ms | 43 ms | 75 ms |
| Owner sign-in bootstrap | 1,115 ms · 36.5 MB | — | **113 ms · 2.96 MB** (was 4,824 ms · 145 MB) |
| State sync, delta | 1,017 ms | 12 ms | 15 ms |

Concurrency and integrity, all passing: 400/400 concurrent posts stored exactly once; 25 identical concurrent submissions → one document; 10 conflicting versions → exactly one wins; posts racing stale syncs lose nothing; 30 racing issues of 5 kg against 100 kg → exactly 20 succeed, stock never negative, GL = stock; 10 concurrent retries of one production request key → one receipt; 3,000 random-identity logins handled; malformed and oversized bodies rejected; 100 parallel health probes stable; every document balanced and headed.

**Full battery:** stress 25/25 · API regressions 22/22 · cross-sector workflow 760/760 · IFRS extensions 10/10 · review regressions 43/43 · posting controls 47/47.

### Accepted / residual items
- Login lockout is per app process (in-memory). With several processes behind a load balancer, put rate limiting at the proxy as well (e.g. Caddy `rate_limit` / fail2ban) or move the tracker to PostgreSQL.
- Posting is serialised by one global advisory lock — correct and simple, ~125 docs/s per instance, ample for a practice; partition per entity only if sustained volume demands it.
- Group Consolidation loads every entity's journal (seconds at hundreds of thousands of lines); a server-side consolidated trial balance would remove that if group reporting becomes frequent.
- Remaining React Compiler lint findings (effects that set state on prop change, declaration order) are pre-existing, non-runtime and covered by the suites above.
