import type { NextConfig } from "next";

/**
 * Baseline HTTP hardening (OWASP ASVS V14 / ISO 27001 A.8.9). Frame-ancestor
 * restrictions are deliberately NOT set so the workspace can be embedded in a
 * hosted preview; set `Content-Security-Policy: frame-ancestors` at the edge
 * for production deployments.
 */
const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=()" },
  { key: "X-DNS-Prefetch-Control", value: "off" },
  // Ignored by browsers over plain HTTP; enforces HTTPS once served over TLS.
  { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" },
  { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
];

const nextConfig: NextConfig = {
  poweredByHeader: false,
  async headers() {
    return [
      { source: "/(.*)", headers: securityHeaders },
      // Workspace/auth JSON must never be served from a shared cache.
      { source: "/api/(.*)", headers: [{ key: "Cache-Control", value: "no-store, max-age=0, must-revalidate" }] },
    ];
  },
};

export default nextConfig;
