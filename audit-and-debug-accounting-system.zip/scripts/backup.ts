import "dotenv/config";
import { mkdir, readdir, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { gzipSync } from "node:zlib";
import { pool } from "@/db";

/**
 * Logical database backup for BPZ Consult ERP.
 *
 *   npx tsx scripts/backup.ts
 *
 * Writes a gzipped JSON snapshot of every public table to BPZ_BACKUP_DIR
 * (default ./backups) and prunes to the newest BPZ_BACKUP_KEEP files
 * (default 14). Schedule it nightly (cron / Task Scheduler / systemd timer)
 * and copy the directory off-server. For very large databases prefer
 * `pg_dump` — see docs/DEPLOYMENT_GUIDE.md.
 */
async function main() {
  const dir = process.env.BPZ_BACKUP_DIR || "./backups";
  const keep = Math.max(1, Number(process.env.BPZ_BACKUP_KEEP || 14));

  // One repeatable-read snapshot keeps every table mutually consistent while
  // users continue posting. Independent pool.query calls did not guarantee this.
  const connection = await pool.connect();
  const tables: Record<string, unknown[]> = {};
  let rowCount = 0;
  try {
    await connection.query("begin transaction isolation level repeatable read read only");
    const tablesRes = await connection.query<{ table_name: string }>(
      `select table_name from information_schema.tables where table_schema = 'public' and table_type = 'BASE TABLE' order by table_name`
    );
    for (const { table_name } of tablesRes.rows) {
      const quoted = `"${table_name.replaceAll('"', '""')}"`;
      const rows = await connection.query(`select * from ${quoted}`);
      tables[table_name] = rows.rows;
      rowCount += rows.rows.length;
    }
    await connection.query("commit");
  } catch (error) {
    await connection.query("rollback").catch(() => undefined);
    throw error;
  } finally {
    connection.release();
  }

  const payload = {
    app: "bpz-consult-erp",
    createdAt: new Date().toISOString(),
    tables,
  };

  await mkdir(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const file = join(dir, `bpz-backup-${stamp}.json.gz`);
  await writeFile(file, gzipSync(Buffer.from(JSON.stringify(payload), "utf8")));

  // Retention: keep the newest N snapshots.
  const files = (await readdir(dir)).filter((f) => f.startsWith("bpz-backup-") && f.endsWith(".json.gz")).sort();
  const stale = files.slice(0, Math.max(0, files.length - keep));
  for (const f of stale) await rm(join(dir, f), { force: true });

  console.log(`Backup written: ${file} (${Object.keys(tables).length} tables, ${rowCount} rows, pruned ${stale.length}).`);
  await pool.end();
}

main().catch(async (e) => {
  console.error("Backup failed:", e);
  await pool.end().catch(() => undefined);
  process.exit(1);
});
