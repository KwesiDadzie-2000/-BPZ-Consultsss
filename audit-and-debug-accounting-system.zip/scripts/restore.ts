import "dotenv/config";
import { readFile } from "node:fs/promises";
import { gunzipSync } from "node:zlib";
import { pool } from "@/db";

/**
 * Restore a backup written by scripts/backup.ts.
 *
 *   npx tsx scripts/restore.ts <backup.json.gz> [--dry-run] [--force]
 *
 * Safety:
 *  - refuses to write if the database already contains users, unless --force;
 *  - --dry-run only parses the file and reports table/row counts;
 *  - restore truncates all public tables (CASCADE) then reinserts rows, so
 *    run it against a maintenance window with the app stopped.
 */
async function main() {
  const [file, ...flags] = process.argv.slice(2);
  if (!file) {
    console.error("Usage: npx tsx scripts/restore.ts <backup.json.gz> [--dry-run] [--force]");
    process.exit(2);
  }
  const dryRun = flags.includes("--dry-run");
  const force = flags.includes("--force");

  const raw = await readFile(file);
  const text = file.endsWith(".gz") ? gunzipSync(raw).toString("utf8") : raw.toString("utf8");
  const payload = JSON.parse(text) as { app?: string; createdAt?: string; tables: Record<string, Record<string, unknown>[]> };
  if (payload.app !== "bpz-consult-erp" || !payload.tables) {
    console.error("Not a BPZ Consult backup file.");
    process.exit(2);
  }
  const names = Object.keys(payload.tables);
  if (!names.length || names.some((n) => !/^[a-z_][a-z0-9_]*$/.test(n) || !Array.isArray(payload.tables[n]))) {
    throw new Error("Backup contains invalid or missing table data.");
  }
  const counts = names.map((n) => `${n}:${payload.tables[n].length}`).join(" ");
  console.log(`Backup ${payload.createdAt ?? ""} — ${names.length} tables — ${counts}`);

  if (dryRun) {
    console.log("Dry run only; nothing written.");
    await pool.end();
    return;
  }

  const existing = await pool.query<{ n: number }>(`select count(*)::int as n from users`);
  if (Number(existing.rows[0]?.n ?? 0) > 0 && !force) {
    console.error("Refusing to restore into a database that already has users. Stop the app, then re-run with --force.");
    await pool.end();
    process.exit(1);
  }

  const client = await pool.connect();
  try {
    await client.query("begin");
    const existingTables = await client.query<{ table_name: string }>(
      "select table_name from information_schema.tables where table_schema = 'public' and table_type = 'BASE TABLE'"
    );
    const present = new Set(existingTables.rows.map((r) => r.table_name));
    const missing = names.filter((n) => !present.has(n));
    if (missing.length) throw new Error(`Target database lacks backup tables: ${missing.join(', ')}. Provision the schema first.`);
    const identities = await client.query<{ table_name: string; column_name: string }>(
      "select table_name, column_name from information_schema.columns where table_schema = 'public' and is_identity = 'YES'"
    );
    const identityByTable = new Map<string, string[]>();
    for (const { table_name, column_name } of identities.rows) {
      identityByTable.set(table_name, [...(identityByTable.get(table_name) ?? []), column_name]);
    }
    const quoted = names.map((n) => `"${n}"`).join(", ");
    await client.query(`truncate table ${quoted} restart identity cascade`);
    for (const name of names) {
      const rows = payload.tables[name];
      for (const row of rows) {
        const cols = Object.keys(row);
        if (!cols.length) continue;
        const values = cols.map((c) => {
          const v = row[c];
          if (v === null || v === undefined) return null;
          if (v instanceof Date) return v;
          if (typeof v === "object") return JSON.stringify(v);
          return v;
        });
        await client.query(
          `insert into "${name}" (${cols.map((c) => `"${c}"`).join(", ")}) ${identityByTable.has(name) ? "overriding system value" : ""} values (${cols.map((_, i) => `$${i + 1}`).join(", ")})`,
          values
        );
      }
      // Keep identity sequences above restored IDs so the next insert cannot
      // collide with a restored chart or disclosure-note row.
      for (const column of identityByTable.get(name) ?? []) {
        const result = await client.query<{ max: number | null }>(`select max("${column}")::int as max from "${name}"`);
        const max = result.rows[0]?.max;
        await client.query("select setval(pg_get_serial_sequence($1, $2), $3::bigint, $4::boolean)",
          [`public.${name}`, column, max ?? 1, max != null]);
      }
    }
    await client.query("commit");
  } catch (e) {
    await client.query("rollback").catch(() => undefined);
    throw e;
  } finally {
    client.release();
  }

  console.log("Restore complete. Restart the application and sign in.");
  await pool.end();
}

main().catch(async (e) => {
  console.error("Restore failed:", e);
  await pool.end().catch(() => undefined);
  process.exit(1);
});
