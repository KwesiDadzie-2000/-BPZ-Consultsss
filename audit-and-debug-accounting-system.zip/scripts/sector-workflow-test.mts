/**
 * Standardized cross-sector accounting workflow test (destructive; disposable DB only).
 *
 *   BPZ_SECTOR_TEST_DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/bpz_sector_test \
 *     npx tsx scripts/sector-workflow-test.mts
 *
 * Every Ghana sector profile is run through the common accounting backbone and its
 * sector-specific events, then reconciled. Amounts are illustrative GHS figures
 * using the 2026 VAT structure (15% + 2.5% NHIL + 2.5% GETFund = 20% on one base),
 * SSNIT 5.5% employee / 13% employer (13.5% Tier 1, 5% Tier 2) and resident WHT
 * (goods 3%, works 5%, services 7.5%). PAYE is a fixed illustrative amount — the
 * test checks accounting flow, not the PAYE band computation.
 */
import { randomUUID } from 'node:crypto';

const url = process.env.BPZ_SECTOR_TEST_DATABASE_URL;
if (!url) throw new Error('Set BPZ_SECTOR_TEST_DATABASE_URL to a disposable local bpz_sector_test database.');
const parsed = new URL(url);
if (!['localhost', '127.0.0.1'].includes(parsed.hostname) || parsed.pathname !== '/bpz_sector_test') {
  throw new Error('Refusing to run anywhere except a local bpz_sector_test database.');
}
process.env.DATABASE_URL = url;
process.env.BPZ_BOOTSTRAP_MODE = 'production';
process.env.BPZ_OWNER_EMAIL = 'owner@example.invalid';
process.env.BPZ_SETUP_TOKEN = randomUUID() + randomUUID();
delete process.env.BPZ_SEED_PASSWORD_OWNER;

const { pool } = await import('@/db');
await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
const setup = await import('@/app/api/auth/setup/route');
const loginRoute = await import('@/app/api/auth/login/route');
const clientsRoute = await import('@/app/api/clients/route');
const journalRoute = await import('@/app/api/journal/route');
const productionRoute = await import('@/app/api/production/route');
const bootstrapRoute = await import('@/app/api/bootstrap/route');
const stateRoute = await import('@/app/api/state/route');
const usersRoute = await import('@/app/api/users/route');
const { GHANA_ECONOMY_SECTORS } = await import('@/data/ghanaSectors');
const { applyIssue, applyReceipt, reconcileInventory } = await import('@/utils/trading');
type ACDOCALine = import('@/types/accounting').ACDOCALine;
type StockItem = import('@/types/accounting').StockItem;

type Handler = (req: Request) => Promise<Response>;
async function call(handler: Handler, method: string, path: string, body?: unknown, token?: string) {
  const res = await handler(new Request(`http://localhost${path}`, {
    method, headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  }));
  return { status: res.status, body: await res.json().catch(() => null) as any };
}

let passed = 0; let failed = 0;
const failures: string[] = [];
function check(title: string, ok: boolean, detail = '') {
  if (ok) passed++; else { failed++; failures.push(`${title}${detail ? ` — ${detail}` : ''}`); }
}

const DATE = '2026-11-05';
const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

// ---- owner activation (production bootstrap) -------------------------------------------------
const ownerPassword = `Owner-${randomUUID().slice(0, 8)}-Aa1!`;
const act = await call(setup.POST, 'POST', '/api/auth/setup', { password: ownerPassword, confirm: ownerPassword, setupToken: process.env.BPZ_SETUP_TOKEN });
check('production owner activation', act.status === 200 && !!act.body?.token, JSON.stringify(act.body));
const owner = act.body.token as string;

const accountNames = new Map<string, string>(
  (await pool.query<{ account_no: string; name: string }>('select account_no, name from chart_accounts where client_id is null')).rows.map((r) => [r.account_no, r.name]),
);
check('master chart provisioned (≥ 214 accounts)', accountNames.size >= 214, String(accountNames.size));

let docSeq = 0;
async function post(clientId: number, label: string, legs: [string, number, number, string?][], token = owner, maker = 'owner') {
  docSeq++;
  const docNo = `T-${clientId}-${docSeq}`;
  const lines: ACDOCALine[] = legs.map(([accountNo, debit, credit, cc]) => ({
    id: randomUUID(), docNo, period: DATE.slice(0, 7), date: DATE, module: 'FI', docType: 'JE', accountNo,
    accountName: accountNames.get(accountNo) ?? accountNo, debit: r2(debit), credit: r2(credit), currency: 'GHS',
    description: label, createdBy: maker, clientId, costCenter: cc ?? 'CC-OPS',
  }));
  const res = await call(journalRoute.POST, 'POST', '/api/journal', { lines }, token);
  return { ...res, docNo, lines };
}

async function balance(clientId: number, accountNo: string) {
  const r = await pool.query<{ b: string }>('select coalesce(sum(debit - credit), 0) as b from journal_lines where client_id = $1 and account_no = $2', [clientId, accountNo]);
  return r2(Number(r.rows[0].b));
}

async function stockRow(clientId: number, itemCode: string): Promise<StockItem> {
  const r = (await pool.query('select * from stock_items where client_id = $1 and item_code = $2', [clientId, itemCode])).rows[0];
  return { id: r.id, clientId: r.client_id, itemCode: r.item_code, description: r.description, category: r.category, uom: r.uom,
    quantityOnHand: r.quantity_on_hand, unitCost: r.unit_cost, totalValue: r.total_value, glAccount: r.gl_account ?? undefined,
    costMethod: r.cost_method ?? 'weighted_average' };
}
async function saveStock(item: StockItem, move: { type: string; qty: number; unitCost: number; value: number; docNo: string }) {
  await pool.query('update stock_items set quantity_on_hand=$1, unit_cost=$2, total_value=$3 where id=$4', [item.quantityOnHand, item.unitCost, item.totalValue, item.id]);
  await pool.query('insert into stock_movements (id, client_id, date, item_code, description, type, quantity, unit_cost, total_value, uom, doc_no) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)',
    [randomUUID(), item.clientId, DATE, item.itemCode, item.description, move.type, move.qty, move.unitCost, move.value, item.uom, move.docNo]);
}
async function createItem(clientId: number, itemCode: string, category: string, glAccount: string, uom = 'kg') {
  await pool.query('insert into stock_items (id, client_id, item_code, description, category, uom, quantity_on_hand, unit_cost, total_value, gl_account, cost_method) values ($1,$2,$3,$4,$5,$6,0,0,0,$7,$8)',
    [randomUUID(), clientId, itemCode, `${itemCode} test item`, category, uom, glAccount, 'weighted_average']);
}

// ---- scenario definitions --------------------------------------------------------------------
interface Scenario {
  revenueAccount: string; vat: boolean; cst?: boolean; tourism?: boolean; saleLevy?: number;
  whtRate: number; stock?: 'trading' | 'production'; extra?: [string, [string, number, number][]][];
  expect?: Record<string, number>;
}
const S: Record<string, Scenario> = {
  mining_metals: { revenueAccount: '400000', vat: true, whtRate: 0.075, stock: 'production',
    extra: [['Mineral royalty accrual (illustrative; L.I. 2517 price-linked)', [['507000', 10000, 0], ['227000', 0, 10000]]],
      ['Rehabilitation obligation capitalised (IAS 37/IAS 16)', [['130000', 25000, 0], ['270000', 0, 25000]]]],
    expect: { '227000': -10000, '270000': -25000 } },
  oil_gas_upstream: { revenueAccount: '400000', vat: true, whtRate: 0.075,
    extra: [['Partner cash call received (funding, not revenue)', [['100000', 50000, 0], ['202000', 0, 50000]]],
      ['Decommissioning provision (IAS 37)', [['130000', 30000, 0], ['270000', 0, 30000]]]],
    expect: { '202000': -50000, '270000': -30000 } },
  oil_gas_downstream: { revenueAccount: '400000', vat: true, whtRate: 0.03, stock: 'trading', saleLevy: 5000, expect: { '227000': -5000 } },
  renewable_energy: { revenueAccount: '400000', vat: true, whtRate: 0.075,
    extra: [['Unbilled energy revenue accrual', [['118100', 15000, 0], ['400000', 0, 15000]]]], expect: { '118100': 15000 } },
  commercial_agric: { revenueAccount: '400000', vat: false, whtRate: 0.03,
    extra: [['IAS 41 fair-value gain on biological assets', [['124000', 20000, 0], ['417000', 0, 20000]]]], expect: { '124000': 20000, '417000': -20000 } },
  agro_processing: { revenueAccount: '400000', vat: true, whtRate: 0.03, stock: 'production' },
  fisheries_aquaculture: { revenueAccount: '400000', vat: true, whtRate: 0.03, stock: 'production' },
  manufacturing_fmcg: { revenueAccount: '400000', vat: true, whtRate: 0.03, stock: 'production' },
  heavy_industry_steel: { revenueAccount: '400000', vat: true, whtRate: 0.03, stock: 'production' },
  pharmaceuticals_manufacturing: { revenueAccount: '400000', vat: true, whtRate: 0.03, stock: 'production' },
  construction_infrastructure: { revenueAccount: '400000', vat: true, whtRate: 0.05,
    extra: [['IFRS 15 over-time revenue — unbilled contract asset', [['118100', 40000, 0], ['400000', 0, 40000]]]], expect: { '118100': 40000 } },
  real_estate_development: { revenueAccount: '411000', vat: true, whtRate: 0.075,
    extra: [['Refundable tenant deposit received', [['100000', 12000, 0], ['217000', 0, 12000]]],
      ['Investment property acquired (IAS 40)', [['141000', 150000, 0], ['100000', 0, 150000]]]],
    expect: { '217000': -12000, '141000': 150000 } },
  wholesale_retail_supermarket: { revenueAccount: '400000', vat: true, whtRate: 0.03, stock: 'trading' },
  import_export_trade: { revenueAccount: '400000', vat: true, whtRate: 0.03, stock: 'trading' },
  banking_finance: { revenueAccount: '412000', vat: false, whtRate: 0.075,
    extra: [['Customer deposit received (liability)', [['100000', 300000, 0], ['216000', 0, 300000]]],
      ['Loan disbursed', [['110000', 200000, 0], ['100000', 0, 200000]]],
      ['Lifetime ECL allowance (IFRS 9)', [['680000', 4000, 0], ['119000', 0, 4000]]],
      ['Interest accrued on deposits', [['694000', 1500, 0], ['216000', 0, 1500]]]],
    expect: { '216000': -301500, '119000': -4000, '110000': 200000 } },
  fintech_mobile_money: { revenueAccount: '414000', vat: true, whtRate: 0.075,
    extra: [['Wallet funded (safeguarded liability)', [['100000', 80000, 0], ['215000', 0, 80000]]],
      ['Transaction fee earned from wallet', [['215000', 1200, 0], ['414000', 0, 1200]]]],
    expect: { '215000': -78800 } },
  insurance_pensions: { revenueAccount: '415000', vat: false, whtRate: 0.075,
    extra: [['Premium received in advance (LRC)', [['100000', 60000, 0], ['231000', 0, 60000]]],
      ['Insurance revenue earned (IFRS 17)', [['231000', 20000, 0], ['415000', 0, 20000]]]],
    expect: { '231000': -40000 } },
  telecommunications: { revenueAccount: '400000', vat: true, cst: true, whtRate: 0.075 },
  software_it_bpo: { revenueAccount: '400000', vat: true, whtRate: 0.075,
    extra: [['Annual subscription billed in advance', [['100000', 36000, 0], ['225000', 0, 36000]]],
      ['One month of subscription earned', [['225000', 3000, 0], ['400000', 0, 3000]]]],
    expect: { '225000': -33000 } },
  hospitality_hotels: { revenueAccount: '400000', vat: true, tourism: true, whtRate: 0.075,
    extra: [['Booking deposit received', [['100000', 10000, 0], ['225000', 0, 10000]]],
      ['Guest stay delivered — deposit earned', [['225000', 10000, 0], ['400000', 0, 10000]]]],
    expect: { '225000': 0 } },
  healthcare_clinics: { revenueAccount: '400000', vat: false, whtRate: 0.075,
    extra: [['ECL on rejected/aged NHIS claims', [['680000', 3000, 0], ['119000', 0, 3000]]]], expect: { '119000': -3000 } },
  education_training: { revenueAccount: '400000', vat: false, whtRate: 0.075,
    extra: [['Restricted research grant received', [['100000', 50000, 0], ['232000', 0, 50000]]],
      ['Term fees received in advance', [['100000', 40000, 0], ['225000', 0, 40000]]],
      ['Half of term delivered — fees earned', [['225000', 20000, 0], ['400000', 0, 20000]]]],
    expect: { '232000': -50000, '225000': -20000 } },
  professional_legal_advisory: { revenueAccount: '401000', vat: true, whtRate: 0.075,
    extra: [['Client money held in trust (not revenue)', [['100000', 25000, 0], ['219000', 0, 25000]]]], expect: { '219000': -25000 } },
  transport_logistics_shipping: { revenueAccount: '400000', vat: true, whtRate: 0.075,
    extra: [['Booking advance received', [['100000', 15000, 0], ['225000', 0, 15000]]],
      ['Carriage completed — advance earned', [['225000', 15000, 0], ['400000', 0, 15000]]],
      ['Fuel charged to job', [['623000', 8000, 0], ['100000', 0, 8000]]]],
    expect: { '225000': 0 } },
};

// ---- run every sector ------------------------------------------------------------------------
let clientNo = 0;
const adminTokens: { clientId: number; token: string }[] = [];
for (const sector of GHANA_ECONOMY_SECTORS) {
  const sc = S[sector.code];
  check(`scenario defined for ${sector.code}`, !!sc);
  if (!sc) continue;
  clientNo++;
  const code = `TS-${String(clientNo).padStart(2, '0')}`;
  const adminPassword = `Client-${randomUUID().slice(0, 8)}-Aa1!`;
  const created = await call(clientsRoute.POST, 'POST', '/api/clients', {
    client: { code, name: `${sector.name.slice(0, 60)} Test Ltd`, sector: sector.name, currency: 'GHS', jurisdiction: 'GH', regNumber: `REG-${code}`,
      assignedServices: ['bookkeeping', 'payroll', 'tax_compliance', 'management_accounts', 'ifrs_reporting'] },
    admin: { username: `admin_${code.toLowerCase().replace('-', '')}`, name: 'Client Finance Manager', email: `${code.toLowerCase()}@example.invalid`, password: adminPassword, role: 'manager', makerLimit: 20000 },
  }, owner);
  check(`${sector.code}: client onboarded atomically`, created.status === 201, JSON.stringify(created.body));
  if (created.status !== 201) continue;
  const clientId = created.body.client.id as number;
  const login = await call(loginRoute.POST, 'POST', '/api/auth/login', { usernameOrEmail: `admin_${code.toLowerCase().replace('-', '')}`, password: adminPassword });
  if (login.body?.token) adminTokens.push({ clientId, token: login.body.token });

  const ok = (r: { status: number; body: any }, title: string) => check(`${sector.code}: ${title}`, r.status === 200 && r.body?.ok, `${r.status} ${JSON.stringify(r.body)}`);
  let cash = 0; let ar = 0; let ap = 0; let inputVat = 0; let outputVat = 0; let wht = 0; let revenue = 0;

  // 1. Share capital.
  ok(await post(clientId, 'Share capital subscribed', [['100000', 500000, 0], ['300000', 0, 500000]]), 'share capital');
  cash += 500000;

  // 2. P2P: services purchase with recoverable input VAT.
  const svcNet = 100000; const svcVat = 20000;
  ok(await post(clientId, 'Supplier invoice — contracted services', [['621000', svcNet, 0], ['125000', svcVat, 0], ['200000', 0, svcNet + svcVat]]), 'P2P service invoice with input VAT');
  ap += svcNet + svcVat; inputVat += svcVat; wht += svcNet * sc.whtRate;

  // 3. Stock purchase (trading / production).
  let rmCode = ''; let fgCode = '';
  if (sc.stock) {
    rmCode = `${sc.stock === 'trading' ? 'GD' : 'RM'}-${clientNo}`;
    await createItem(clientId, rmCode, sc.stock === 'trading' ? 'General' : 'Raw Materials', '120000');
    const qty = 1000; const unit = 50; const net = qty * unit; const vat = net * 0.2;
    const grn = await post(clientId, `Goods received ${rmCode}`, [['120000', net, 0], ['125000', vat, 0], ['200000', 0, net + vat]]);
    ok(grn, 'goods received into stock with input VAT');
    const rec = applyReceipt(await stockRow(clientId, rmCode), qty, unit);
    await saveStock(rec.item, { type: 'Receipt', qty, unitCost: unit, value: net, docNo: grn.docNo });
    ap += net + vat; inputVat += vat; wht += net * 0.03;
  }

  // 4. Payroll with PAYE and SSNIT (5.5% employee, 13% employer → 13.5% Tier 1 / 5% Tier 2).
  const gross = 50000; const empSsnit = gross * 0.055; const erSsnit = gross * 0.13; const paye = 8000;
  const net = gross - empSsnit - paye; const tier1 = gross * 0.135; const tier2 = gross * 0.05;
  const payroll = await post(clientId, 'Monthly payroll accrual', [['510000', gross, 0], ['511000', erSsnit, 0],
    ['205000', 0, net], ['207000', 0, paye], ['206000', 0, tier1], ['206100', 0, tier2]]);
  ok(payroll, 'payroll accrual with PAYE, SSNIT Tier 1 and Tier 2');
  check(`${sector.code}: SSNIT 18.5% splits exactly into Tier 1 + Tier 2`, r2(empSsnit + erSsnit) === r2(tier1 + tier2));

  // 5. Manufacturing loop (BOM → order → release → issue → conversion → output → close).
  if (sc.stock === 'production') {
    fgCode = `FG-${clientNo}`;
    await createItem(clientId, fgCode, 'Finished Goods', '121000', 'unit');
    const prod = (action: string, payload: Record<string, unknown>, requestKey?: string) =>
      call(productionRoute.POST, 'POST', '/api/production', { clientId, action, payload, requestKey }, owner);
    ok(await prod('save_bom', { parentItemCode: fgCode, componentItemCode: rmCode, qtyPerUnit: 2, wastePct: 5 }), 'BOM saved');
    const orderKey = randomUUID();
    const order = await prod('create_order', { itemCode: fgCode, qty: 400, startDate: DATE, costCenter: 'CC-PROD' }, orderKey);
    ok(order, 'work order drafted');
    const orderId = order.body?.order?.id as string;
    const retry = await prod('create_order', { itemCode: fgCode, qty: 400, startDate: DATE, costCenter: 'CC-PROD' }, orderKey);
    check(`${sector.code}: work-order retry is idempotent`, retry.status === 200 && retry.body?.idempotent === true);
    const early = await prod('receive_output', { orderId, qty: 10, date: DATE }, randomUUID());
    check(`${sector.code}: output before release/issue refused`, early.status === 409);
    ok(await prod('release_order', { orderId }), 'work order released');
    ok(await prod('issue_material', { orderId, itemCode: rmCode, qty: 820, date: DATE }, randomUUID()), 'materials issued to WIP');
    const over = await prod('issue_material', { orderId, itemCode: rmCode, qty: 30, date: DATE }, randomUUID());
    check(`${sector.code}: issue beyond BOM plan (840) refused`, over.status === 409, JSON.stringify(over.body));
    const tooMuch = await prod('receive_output', { orderId, qty: 411, date: DATE }, randomUUID());
    check(`${sector.code}: output beyond order refused`, tooMuch.status === 409);
    ok(await prod('record_conversion', { orderId, sourceDocNo: payroll.docNo, accountNo: '510000', amount: 9000,
      reason: 'Direct production labour on this batch per timesheets', date: DATE }, randomUUID()), 'direct labour allocated to WIP');
    const overAlloc = await prod('record_conversion', { orderId, sourceDocNo: payroll.docNo, accountNo: '510000', amount: 45000,
      reason: 'Attempt to over-allocate the same payroll document', date: DATE }, randomUUID());
    check(`${sector.code}: conversion over-allocation of source refused`, overAlloc.status === 409);
    const earlyClose = await prod('close_order', { orderId });
    check(`${sector.code}: close with open WIP refused`, earlyClose.status === 409);
    ok(await prod('receive_output', { orderId, qty: 200, date: DATE }, randomUUID()), 'partial finished output received');
    ok(await prod('receive_output', { orderId, qty: 200, date: DATE }, randomUUID()), 'final finished output received');
    ok(await prod('close_order', { orderId }), 'work order closed at zero WIP');
    check(`${sector.code}: WIP 122000 cleared to zero`, (await balance(clientId, '122000')) === 0, String(await balance(clientId, '122000')));
    const fg = await stockRow(clientId, fgCode);
    check(`${sector.code}: FG valued at materials 41,000 + labour 9,000 = 50,000`, r2(fg.totalValue) === 50000 && fg.quantityOnHand === 400, JSON.stringify(fg));
    check(`${sector.code}: FG GL 121000 equals FG stock value`, (await balance(clientId, '121000')) === r2(fg.totalValue));
  }

  // 6. O2C: sale with VAT (and CST / tourism levy / petroleum levy where relevant).
  const saleNet = 200000;
  const cst = sc.cst ? saleNet * 0.05 : 0;
  const vat = sc.vat ? (saleNet + cst) * 0.2 : 0; // CST cascades into the VAT base (Act 1151 s.15.3).
  const tourism = sc.tourism ? saleNet * 0.01 : 0; // Tourism levy: no VAT-base cascade.
  const levy = sc.saleLevy ?? 0;
  const saleLegs: [string, number, number][] = [['110000', saleNet + cst + vat + tourism + levy, 0], [sc.revenueAccount, 0, saleNet]];
  if (vat) saleLegs.push(['220000', 0, vat]);
  if (cst) saleLegs.push(['223000', 0, cst]);
  if (tourism) saleLegs.push(['224000', 0, tourism]);
  if (levy) saleLegs.push(['227000', 0, levy]);
  ok(await post(clientId, 'Customer invoice', saleLegs), 'O2C invoice with taxes & levies');
  ar += saleNet + cst + vat + tourism + levy; outputVat += vat; revenue += saleNet;

  // 7. Sale of stocked goods at carrying cost.
  if (sc.stock) {
    const itemCode = sc.stock === 'production' ? fgCode : rmCode;
    const qty = 150; const price = 180; const sNet = qty * price; const sVat = sNet * 0.2;
    const issue = applyIssue(await stockRow(clientId, itemCode), qty, [], 'weighted_average');
    check(`${sector.code}: stock issue for sale allowed`, !issue.error, issue.error);
    const stockAccount = sc.stock === 'production' ? '121000' : '120000';
    const sale = await post(clientId, `Goods sale ${itemCode}`, [['110000', sNet + sVat, 0], ['400000', 0, sNet], ['220000', 0, sVat],
      ['504000', issue.cost, 0], [stockAccount, 0, issue.cost]]);
    ok(sale, 'goods sale with COGS at carrying cost');
    await saveStock(issue.item, { type: 'Issue', qty, unitCost: issue.unitCost, value: issue.cost, docNo: sale.docNo });
    ar += sNet + sVat; outputVat += sVat; revenue += sNet;
    const expectedCogs = sc.stock === 'production' ? 150 * 125 : 150 * 50;
    check(`${sector.code}: COGS at carrying cost (${expectedCogs})`, r2(issue.cost) === expectedCogs, String(issue.cost));
  }

  // 8. Sector-specific events.
  for (const [label, legs] of sc.extra ?? []) {
    ok(await post(clientId, label, legs), label);
    for (const [acct, dr, cr] of legs) if (acct === '100000') cash += dr - cr;
    for (const [acct, , cr] of legs) if (acct === sc.revenueAccount || acct === '400000') revenue += 0 * cr;
  }

  // 9. Customer receipt in full.
  ok(await post(clientId, 'Customer receipt', [['100000', ar, 0], ['110000', 0, ar]]), 'customer receipt allocated');
  cash += ar;

  // 10. Supplier payment with income WHT deducted.
  wht = r2(wht);
  ok(await post(clientId, 'Supplier payment net of WHT', [['200000', ap, 0], ['209000', 0, wht], ['100000', 0, ap - wht]]), 'supplier payment with WHT');
  cash -= ap - wht;

  // 11. Salaries and statutory remittances (PAYE, SSNIT, WHT).
  ok(await post(clientId, 'Net salaries paid', [['205000', net, 0], ['100000', 0, net]]), 'net salaries paid');
  ok(await post(clientId, 'PAYE, SSNIT and WHT remitted', [['207000', paye, 0], ['206000', tier1, 0], ['206100', tier2, 0], ['209000', wht, 0], ['100000', 0, paye + tier1 + tier2 + wht]]), 'statutory remittances');
  cash -= net + paye + tier1 + tier2 + wht;

  // 12. Monthly VAT settlement (output less input).
  if (outputVat > 0 || inputVat > 0) {
    const due = r2(outputVat - inputVat);
    const legs: [string, number, number][] = [];
    if (outputVat > 0) legs.push(['220000', outputVat, 0]);
    legs.push(['125000', 0, inputVat]);
    if (due > 0) legs.push(['100000', 0, due]);
    if (due < 0) legs.push(['115000', -due, 0]); // excess input credit carried as a receivable
    ok(await post(clientId, 'VAT return settled', legs), 'VAT return settled');
    if (due > 0) cash -= due;
  }

  // ---- reconciliation checks ----
  const tb = (await pool.query<{ d: string; c: string }>('select coalesce(sum(debit),0) d, coalesce(sum(credit),0) c from journal_lines where client_id=$1', [clientId])).rows[0];
  check(`${sector.code}: trial balance balances`, r2(Number(tb.d)) === r2(Number(tb.c)), `${tb.d} vs ${tb.c}`);
  for (const control of ['110000', '200000', '205000', '206000', '206100', '207000', '209000', '220000', '125000']) {
    if (control === '110000' && sc.expect?.['110000'] !== undefined) continue;
    check(`${sector.code}: control ${control} cleared`, (await balance(clientId, control)) === 0, String(await balance(clientId, control)));
  }
  check(`${sector.code}: cash equals expected movement`, (await balance(clientId, '100000')) === r2(cash), `${await balance(clientId, '100000')} vs ${r2(cash)}`);
  for (const [acct, amount] of Object.entries(sc.expect ?? {})) {
    check(`${sector.code}: ${acct} = ${amount}`, (await balance(clientId, acct)) === amount, String(await balance(clientId, acct)));
  }
  if (sc.stock) {
    const items = (await pool.query('select * from stock_items where client_id=$1', [clientId])).rows.map((r) => ({
      id: r.id, clientId: r.client_id, itemCode: r.item_code, description: r.description, category: r.category, uom: r.uom,
      quantityOnHand: r.quantity_on_hand, unitCost: r.unit_cost, totalValue: r.total_value, glAccount: r.gl_account ?? undefined,
    })) as StockItem[];
    const glLines = (await pool.query('select account_no, debit, credit, client_id from journal_lines where client_id=$1', [clientId])).rows.map((r) => ({
      accountNo: r.account_no, debit: r.debit, credit: r.credit, clientId: r.client_id })) as ACDOCALine[];
    const rec = reconcileInventory(items, glLines, clientId);
    check(`${sector.code}: stock register reconciles to stock GL`, rec.reconciled, JSON.stringify(rec));
  }
}

// ---- cross-cutting control tests -------------------------------------------------------------
const first = adminTokens[0]; const second = adminTokens[1];
if (first && second) {
  const cross = await post(second.clientId, 'Cross-tenant attempt', [['100000', 100, 0], ['300000', 0, 100]], first.token, `admin_ts01`);
  check('client admin cannot post into another entity', cross.status === 403, `${cross.status}`);
}
const unbalanced = await post(2, 'Unbalanced', [['100000', 100, 0], ['300000', 0, 90]]);
check('unbalanced journal refused', unbalanced.status === 409);
const replay = await post(2, 'Replay base', [['100000', 10, 0], ['300000', 0, 10]]);
const again = await call(journalRoute.POST, 'POST', '/api/journal', { lines: replay.lines }, owner);
check('identical journal replay is idempotent', again.status === 200 && again.body?.idempotent === true);
await pool.query("insert into closed_periods (client_id, period, closed_at, closed_by) values (2, '2026-10', now()::text, 'owner')");
const closedLines = replay.lines.map((l) => ({ ...l, id: randomUUID(), docNo: 'T-CLOSED-1', date: '2026-10-15', period: '2026-10' }));
const closed = await call(journalRoute.POST, 'POST', '/api/journal', { lines: closedLines }, owner);
check('posting into a closed period refused', closed.status === 409);

const auditorPw = `Audit-${randomUUID().slice(0, 8)}-Aa1!`;
const mk = await call(usersRoute.PUT, 'PUT', '/api/users', { user: { username: 'auditor_one', name: 'External Auditor', email: 'auditor@example.invalid', role: 'auditor', status: 'active', makerLimit: 0, canCheck: false, clientId: 2, password: auditorPw } }, owner);
check('owner can create an auditor', mk.status === 200, JSON.stringify(mk.body));
const al = await call(loginRoute.POST, 'POST', '/api/auth/login', { usernameOrEmail: 'auditor_one', password: auditorPw });
const auditorState = await call(stateRoute.PUT, 'PUT', '/api/state', {}, al.body?.token);
check('auditor cannot write workspace state', auditorState.status === 403, String(auditorState.status));
const auditorProd = await call(productionRoute.POST, 'POST', '/api/production', { clientId: 2, action: 'save_bom', payload: {} }, al.body?.token);
check('auditor cannot change production', auditorProd.status === 403, String(auditorProd.status));

const boot = await call(bootstrapRoute.GET, 'GET', '/api/bootstrap', undefined, owner);
check('owner bootstrap loads every test entity', boot.status === 200 && boot.body?.state?.clients?.length === clientNo + 1, String(boot.body?.state?.clients?.length));

console.log(`\nSector workflow test: ${passed} passed, ${failed} failed across ${clientNo} sectors.`);
for (const f of failures) console.log(`FAIL ${f}`);
await pool.end();
process.exit(failed ? 1 : 0);
