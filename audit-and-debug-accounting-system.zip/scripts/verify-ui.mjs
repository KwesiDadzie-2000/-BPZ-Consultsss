import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
import ExcelJS from 'exceljs';

const base = process.env.PREVIEW_URL || 'http://127.0.0.1:3000';
const password = process.env.BPZ_UI_PASSWORD;
if (!password) throw new Error('Set BPZ_UI_PASSWORD for the test owner; never commit credentials.');
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ acceptDownloads: true, viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
const errors = []; const cleanup = []; let token = ''; let clientId = 0;
page.on('pageerror', (e) => errors.push(e.message));
await page.addInitScript(() => { window.print = () => { document.body.setAttribute('data-printed', 'yes'); }; });
async function api(path, method = 'GET', body) {
  const res = await fetch(base + path, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}) });
  return { status: res.status, body: await res.json().catch(() => null) };
}
async function ensureDraft(kind, key, createUi) {
  const existing = await api(`/api/workbooks?clientId=${clientId}&kind=${kind}`);
  if (existing.body?.workbooks?.some((w) => w.key === key)) return false;
  await createUi(); cleanup.push({ kind, key }); return true;
}
async function verifyPrint(buttonName, requiredText, forbiddenText) {
  await page.getByRole('button', { name: buttonName, exact: true }).click();
  const frame = page.frameLocator('iframe[title="Print working paper"]');
  await frame.locator('body[data-printed="yes"]').waitFor({ timeout: 12000 });
  const text = (await frame.locator('body').textContent()) || '';
  if (!text.includes(requiredText)) throw new Error(`Print missing selected content: ${requiredText}; frame=${text.slice(0, 700)}`);
  for (const forbidden of forbiddenText) if (text.includes(forbidden)) throw new Error(`Print leaked surrounding workspace: ${forbidden}`);
  await page.waitForTimeout(300);
  await page.evaluate(() => document.querySelectorAll('iframe[title="Print working paper"]').forEach((frame) => frame.remove()));
}
try {
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.getByLabel('Username or email').fill('owner');
  await page.getByLabel('Password', { exact: true }).fill(password);
  const loginResponse = page.waitForResponse((r) => r.url().endsWith('/api/auth/login') && r.request().method() === 'POST');
  await page.getByRole('button', { name: 'Sign In', exact: true }).click();
  const login = await (await loginResponse).json(); if (!login.ok) throw new Error(login.error || 'UI login failed'); token = login.token;
  await page.getByText('Command Center', { exact: false }).first().waitFor({ timeout: 30000 });
  clientId = Number(await page.locator('select[aria-label="Active accounting workspace"]').inputValue());
  const financeGroup = page.getByRole('button', { name: /Accounting & Finance/ });
  if (await page.getByRole('button', { name: /Project Costing & WIP/ }).count() === 0) await financeGroup.click();
  await page.getByRole('button', { name: /Loan Amortisation Schedules/ }).click();
  await page.getByRole('heading', { name: 'Loan Amortisation & Debt Service' }).waitFor();
  await ensureDraft('loan_facilities', 'register', async () => {
    await page.getByRole('button', { name: 'New borrowing facility' }).click();
    await page.getByLabel('Facility name', { exact: true }).fill('UI verification facility');
    await page.getByLabel('Lender', { exact: true }).fill('Verification Bank');
    await page.getByLabel(/Principal \(/).fill('100000');
    await page.getByLabel('Nominal annual rate %').fill('12');
    await page.getByLabel('Term (months)').fill('12');
    await page.getByLabel('Start date').fill('2026-01-01');
    await page.getByRole('button', { name: 'Save facility & generate schedule' }).click();
    await page.getByRole('heading', { name: /Amortisation schedule — UI verification facility/ }).waitFor({ timeout: 15000 });
  });
  await page.getByRole('heading', { name: /Amortisation schedule/ }).waitFor();
  const loanDownload = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export Excel (.xlsx)' }).click();
  const loanFile = await loanDownload; await loanFile.saveAs('/tmp/bpz-loan-ui.xlsx');
  const wb = new ExcelJS.Workbook(); await wb.xlsx.readFile('/tmp/bpz-loan-ui.xlsx');
  if (!wb.worksheets.some((s) => s.name.includes('schedule')) || wb.worksheets.length < 2) throw new Error('Loan XLSX sheets missing');
  await verifyPrint('Print this schedule', 'Total interest', ['Command Center', 'New borrowing facility', 'Enterprise Administration']);
  await page.getByRole('button', { name: /Project Costing & WIP/ }).click();
  await page.getByRole('heading', { name: 'Project Costing & Work in Progress' }).waitFor();
  const projectCode = `PRJ-UI-${Date.now().toString(36).toUpperCase()}`;
  await ensureDraft('project_costing', 'register', async () => {
    await page.getByRole('button', { name: 'New project', exact: true }).click();
    await page.getByLabel('Unique project code').fill(projectCode);
    await page.getByLabel('Project name', { exact: true }).fill('UI verification project');
    await page.getByLabel('Customer', { exact: true }).fill('Verification Customer');
    await page.getByLabel('Project manager').fill('Verification Manager');
    await page.getByLabel('Start date', { exact: true }).fill('2026-01-01');
    await page.getByLabel('End date', { exact: true }).fill('2026-12-31');
    await page.getByLabel(/Contract revenue/).fill('50000');
    await page.getByLabel(/Direct cost budget/).fill('25000');
    await page.getByLabel(/Overhead budget/).fill('5000');
    await page.getByRole('button', { name: 'Save project', exact: true }).click();
    await page.getByRole('heading', { name: new RegExp(projectCode) }).waitFor({ timeout: 15000 });
  });
  const projectDownload = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export Excel (.xlsx)' }).click();
  await (await projectDownload).saveAs('/tmp/bpz-project-ui.xlsx');
  const projectWb = new ExcelJS.Workbook(); await projectWb.xlsx.readFile('/tmp/bpz-project-ui.xlsx');
  if (!projectWb.getWorksheet('Project portfolio')) throw new Error('Project portfolio XLSX missing');
  await verifyPrint('Print this schedule', 'Budget versus actual', ['Command Center', 'New project', 'Enterprise Administration']);
  await page.screenshot({ path: '/tmp/bpz-project-costing.png', fullPage: true });
  await page.getByRole('button', { name: /Payment Desk/ }).first().click();
  await page.getByRole('heading', { name: 'Accrued debt service awaiting payment' }).waitFor();
  if (errors.length) throw new Error(`Browser errors: ${errors.join('; ')}`);
  console.log(JSON.stringify({ ok: true, loanSheets: wb.worksheets.map((s) => s.name), projectSheets: projectWb.worksheets.map((s) => s.name), printScoped: true, paymentDeskDebtRegister: true, browserErrors: errors }));
} finally {
  // Delete only draft registers created by this verification run.
  for (const item of cleanup) {
    const current = await api(`/api/workbooks?clientId=${clientId}&kind=${item.kind}`);
    const row = current.body?.workbooks?.find((w) => w.key === item.key);
    if (row && row.status === 'draft') await api(`/api/workbooks?clientId=${clientId}&kind=${item.kind}&key=${encodeURIComponent(item.key)}`, 'DELETE');
  }
  await browser.close();
}
