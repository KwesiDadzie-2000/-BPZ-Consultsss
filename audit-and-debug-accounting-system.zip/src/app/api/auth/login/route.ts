import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import { clients, loginAttempts, users } from "@/db/schema";
import { eq, lt, or, sql } from "drizzle-orm";
import { authJson, createSession, pruneExpiredSessions, sanitizeUser, SESSION_TTL_MS } from "@/lib/auth";
import { hashPassword, needsRehash, newSalt, verifyPassword } from "@/lib/password";
import { BODY_LIMITS, RequestBodyError, readJsonBody } from "@/lib/http";

export const dynamic = "force-dynamic";

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MS = 5 * 60 * 1000;

type LoginBody = { usernameOrEmail?: unknown; password?: unknown; workspace?: unknown };

/**
 * Sign-in.
 *
 * `workspace` is the client code from the sign-in link (`/?workspace=CODE`). When
 * it is supplied the account MUST belong to that workspace (or be the firm owner),
 * so a client can never open another entity's books — and a client link can never
 * drop a client straight into the owner's workspace.
 */
export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    console.error("database provisioning failed", e);
    return authJson(req, { ok: false, error: "The workspace database is unavailable. Please try again in a moment." }, { status: 503 });
  }
  try {
    let body: LoginBody | null = null;
    try {
      body = await readJsonBody<LoginBody>(req, BODY_LIMITS.login);
    } catch (error) {
      const status = error instanceof RequestBodyError ? error.status : 400;
      return authJson(req, { ok: false, error: "Invalid request body." }, { status });
    }
    const identifier = String(body?.usernameOrEmail || "").trim().toLowerCase();
    const password = String(body?.password || "");
    const workspaceCode = String(body?.workspace || "").trim().toUpperCase();
    if (!identifier || !password) {
      return authJson(req, { ok: false, error: "Username and password are required." }, { status: 400 });
    }

    // Atomic per-account attempt increment in PostgreSQL so lockout holds across
    // multiple app instances and parallel credential-stuffing requests.
    const now = Date.now();
    const attemptRes = await db.execute<{ count: number; until: number }>(sql`
      INSERT INTO bpz_login_attempts (identifier, count, until, updated_at)
      VALUES (${identifier}, 1, 0, ${now})
      ON CONFLICT (identifier) DO UPDATE SET
        count = CASE
          WHEN bpz_login_attempts.until > 0 AND bpz_login_attempts.until <= ${now} THEN 1
          ELSE bpz_login_attempts.count + 1
        END,
        until = CASE
          WHEN bpz_login_attempts.until > 0 AND bpz_login_attempts.until <= ${now} THEN 0
          WHEN bpz_login_attempts.until > ${now} THEN bpz_login_attempts.until
          WHEN bpz_login_attempts.count + 1 >= ${MAX_FAILED_ATTEMPTS} THEN ${now + LOCKOUT_MS}
          ELSE 0
        END,
        updated_at = ${now}
      RETURNING count, until
    `);
    const lockRow = attemptRes.rows[0];
    const lockUntil = Number(lockRow?.until ?? 0);
    const lockCount = Number(lockRow?.count ?? 1);
    if (lockUntil > now && lockCount > MAX_FAILED_ATTEMPTS) {
      return authJson(
        req,
        { ok: false, error: "Too many failed attempts. Wait 5 minutes before trying again.", retryAfterSeconds: Math.ceil((lockUntil - now) / 1000) },
        { status: 429 }
      );
    }

    const found = await db
      .select()
      .from(users)
      .where(or(sql`lower(${users.username}) = ${identifier}`, sql`lower(${users.email}) = ${identifier}`))
      .limit(1);
    const user = found[0];

    if (!user || !user.passwordHash || !user.passwordSalt || !(await verifyPassword(password, user.passwordSalt, user.passwordHash))) {
      if (Math.random() < 0.01) {
        void db.delete(loginAttempts).where(lt(loginAttempts.updatedAt, now - 24 * 60 * 60 * 1000)).catch(() => {});
      }
      return authJson(req, { ok: false, error: "Invalid username, email, or password." }, { status: 401 });
    }

    if (user.status === "restricted" || user.status === "suspended") {
      return authJson(
        req,
        { ok: false, error: `Account restricted by administrator.${user.restrictionReason ? ` Reason: "${user.restrictionReason}"` : ""}` },
        { status: 403 }
      );
    }

    // Workspace binding (checked only after the password, so it reveals nothing to a guesser).
    let workspace: { id: number; code: string; name: string } | null = null;
    if (workspaceCode) {
      const ws = (await db.select().from(clients).where(sql`upper(${clients.code}) = ${workspaceCode}`).limit(1))[0];
      if (!ws) {
        return authJson(req, { ok: false, error: "That workspace link is not recognised. Check the link your firm sent you." }, { status: 404 });
      }
      if (user.role !== "owner" && user.clientId !== ws.id) {
        return authJson(
          req,
          { ok: false, error: `This account does not belong to the ${ws.code} workspace. Sign in through your own firm's link.` },
          { status: 403 }
        );
      }
      workspace = { id: ws.id, code: ws.code, name: ws.name };
    }

    await db.delete(loginAttempts).where(eq(loginAttempts.identifier, identifier));

    // Transparent credential upgrade: legacy SHA-256 hashes are re-hashed with scrypt
    // on a successful login, so nobody is locked out by the migration.
    if (needsRehash(user.passwordHash)) {
      const salt = newSalt();
      await db
        .update(users)
        .set({ passwordSalt: salt, passwordHash: await hashPassword(password, salt) })
        .where(eq(users.id, user.id));
    }

    const token = await createSession(user.id);
    // Housekeeping — never allowed to fail the sign-in itself.
    void pruneExpiredSessions();

    return authJson(
      req,
      { ok: true, user: sanitizeUser(user), token, expiresInSeconds: SESSION_TTL_MS / 1000, workspace },
      { token }
    );
  } catch (e) {
    console.error("login error", e);
    return authJson(req, { ok: false, error: "Login failed." }, { status: 500 });
  }
}
