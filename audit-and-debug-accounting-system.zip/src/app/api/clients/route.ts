import { randomUUID } from "node:crypto";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { auditLog, clients, users } from "@/db/schema";
import { authJson, requireOwner, sanitizeUser } from "@/lib/auth";
import { hashPassword, newSalt, passwordPolicyError } from "@/lib/password";
import { sanitizeAllowedModules } from "@/utils/moduleCatalog";

export const dynamic = "force-dynamic";

const ALLOWED_SERVICES = new Set([
  "bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting", "advisory",
]);
const CODE_RE = /^[A-Z0-9-]{2,20}$/;
const USERNAME_RE = /^[a-z0-9._-]{3,40}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const LOCK_KEY = 4_027_334;

/**
 * Owner-only, atomic client onboarding. The workspace and its first administrator
 * are inserted in ONE transaction, so the UI cannot display a newly-created
 * client whose login does not exist (the previous fire-and-forget user PUT race).
 */
export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (error) {
    console.error("client onboarding bootstrap failed", error);
    return authJson(req, { ok: false, error: "Database unavailable." }, { status: 503 });
  }
  const owner = await requireOwner(req);
  if (!owner) return authJson(req, { ok: false, error: "Owner access required." }, { status: 403 });
  if (owner.status !== "active") return authJson(req, { ok: false, error: "This account is restricted." }, { status: 403 });

  let payload: { client?: Record<string, unknown>; admin?: Record<string, unknown> } | null;
  try {
    const raw = await req.text();
    if (raw.length > 20_000) return authJson(req, { ok: false, error: "Request too large." }, { status: 413 });
    payload = JSON.parse(raw);
  } catch {
    return authJson(req, { ok: false, error: "Invalid request body." }, { status: 400 });
  }
  const c = payload?.client ?? {};
  const a = payload?.admin ?? {};
  const code = String(c.code ?? "").trim().toUpperCase();
  const name = String(c.name ?? "").trim();
  const regNumber = String(c.regNumber ?? "").trim();
  const sector = String(c.sector ?? "").trim();
  const currency = String(c.currency ?? "GHS").trim().toUpperCase();
  const jurisdiction = String(c.jurisdiction ?? "GH").trim().toUpperCase();
  const assignedServices = c.assignedServices;
  const username = String(a.username ?? "").trim().toLowerCase();
  const email = String(a.email ?? "").trim().toLowerCase();
  const fullName = String(a.name ?? "").trim();
  const role = String(a.role ?? "");
  const password = String(a.password ?? "");
  const makerLimit = Number(a.makerLimit ?? 0);
  const rawPerms = a.permissions && typeof a.permissions === "object" ? (a.permissions as Record<string, unknown>) : {};
  const allowedModules = sanitizeAllowedModules(a.allowedModules ?? rawPerms.allowedModules);

  if (!CODE_RE.test(code)) return authJson(req, { ok: false, error: "Client code must be 2–20 uppercase letters, digits or dashes." }, { status: 400 });
  if (name.length < 2 || name.length > 160) return authJson(req, { ok: false, error: "Enter the client's registered legal name." }, { status: 400 });
  if (!regNumber || regNumber.length > 80) return authJson(req, { ok: false, error: "A valid registration reference is required." }, { status: 400 });
  if (!sector || sector.length > 160) return authJson(req, { ok: false, error: "Select a sector." }, { status: 400 });
  if (!/^[A-Z]{3}$/.test(currency) || !/^[A-Z]{2}$/.test(jurisdiction)) {
    return authJson(req, { ok: false, error: "Currency or jurisdiction is invalid." }, { status: 400 });
  }
  if (!Array.isArray(assignedServices) || !assignedServices.length || assignedServices.some((s) => typeof s !== "string" || !ALLOWED_SERVICES.has(s))) {
    return authJson(req, { ok: false, error: "Choose one or more valid contracted services." }, { status: 400 });
  }
  if (!USERNAME_RE.test(username) || !EMAIL_RE.test(email) || !fullName || fullName.length > 160) {
    return authJson(req, { ok: false, error: "Administrator name, username or email is invalid." }, { status: 400 });
  }
  if (role !== "manager" && role !== "accountant") {
    return authJson(req, { ok: false, error: "Administrator role must be manager or accountant." }, { status: 400 });
  }
  if (!Number.isFinite(makerLimit) || makerLimit < 0 || makerLimit > 1_000_000_000) {
    return authJson(req, { ok: false, error: "Maker limit is invalid." }, { status: 400 });
  }
  const policyError = passwordPolicyError(password);
  if (policyError) return authJson(req, { ok: false, error: policyError }, { status: 400 });

  try {
    const result = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(${LOCK_KEY})`);
      const codeExists = await tx.select({ id: clients.id }).from(clients).where(sql`upper(${clients.code}) = ${code}`).limit(1);
      if (codeExists.length) return { error: "That client code is already in use." } as const;
      const userExists = await tx.select({ username: users.username }).from(users)
        .where(sql`lower(${users.username}) = ${username} or lower(${users.email}) = ${email}`).limit(1);
      if (userExists.length) return { error: "That administrator username or email is already in use." } as const;

      const ids = await tx.select({ nextId: sql<number>`coalesce(max(${clients.id}), 0)::int + 1` }).from(clients);
      const id = Number(ids[0]?.nextId ?? 2);
      const origin = new URL(req.url).origin;
      const client = {
        id,
        code,
        name,
        sector,
        currency,
        jurisdiction,
        regNumber,
        isParent: false,
        assignedServices: assignedServices as string[],
        adminUsername: username,
        adminEmail: email,
        loginUrl: `${origin}/?workspace=${encodeURIComponent(code)}`,
      };
      await tx.insert(clients).values(client);
      const salt = newSalt();
      const [administrator] = await tx.insert(users).values({
        id: username,
        username,
        email,
        name: fullName,
        role,
        makerLimit,
        canCheck: role === "manager",
        clientId: id,
        passwordHash: await hashPassword(password, salt),
        passwordSalt: salt,
        status: "active",
        permissions: {
          canPostJournals: rawPerms.canPostJournals !== false,
          canApprovePayments: typeof rawPerms.canApprovePayments === "boolean" ? rawPerms.canApprovePayments : role === "manager",
          canRunPayroll: typeof rawPerms.canRunPayroll === "boolean"
            ? rawPerms.canRunPayroll
            : (assignedServices as string[]).includes("payroll") && (!allowedModules || allowedModules.includes("payroll")),
          canClosePeriod: rawPerms.canClosePeriod === true,
          canModifyCOA: rawPerms.canModifyCOA === true,
          ...(allowedModules ? { allowedModules } : {}),
        },
      }).returning();
      await tx.insert(auditLog).values({
        id: randomUUID(),
        timestamp: new Date().toISOString(),
        userId: owner.username,
        username: owner.username,
        action: "CLIENT_ONBOARDED",
        target: code,
        details: `Workspace and ${role} account ${username} created. No initial balances.`,
        clientId: id,
      });
      return { client, administrator: sanitizeUser(administrator) } as const;
    });
    if ("error" in result) return authJson(req, { ok: false, error: result.error }, { status: 409 });
    return authJson(req, { ok: true, ...result }, { status: 201 });
  } catch (error) {
    console.error("client onboarding failed", error);
    return authJson(req, { ok: false, error: "The workspace could not be created. No client or credentials were saved." }, { status: 503 });
  }
}
