import { randomUUID } from 'node:crypto';
import { and, eq, sql } from 'drizzle-orm';
import { db } from '@/db';
import { ensureDatabaseReady } from '@/db/bootstrap';
import { clients, entityWorkbooks, journalHeaders } from '@/db/schema';
import { getSessionUser, hasFirmWideScope } from '@/lib/auth';
import { maySeeSection } from '@/utils/access';
import { readJsonBody } from '@/lib/http';
import { postEntityJournal } from '@/lib/entityPosting';
import { debtAccrualDoc, debtReference, DEBT_PAYABLE_ACCOUNT, generateLoanSchedule, type LoanFacility } from '@/utils/loanSchedule';
import type { ACDOCALine, ClientEntity } from '@/types/accounting';
export const dynamic = 'force-dynamic';

/** Accrue only. Settlement is exclusively a Payment Desk operation (Dr 213000 / Cr bank). */
export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return Response.json({ ok: false, error: 'Sign in first.' }, { status: 401 });
    const body = await readJsonBody<{ clientId?: unknown; facilityId?: unknown; periodNum?: unknown; action?: unknown }>(req, 16384);
    const clientId = Number(body.clientId);
    if (!Number.isInteger(clientId) || clientId <= 0) return Response.json({ ok: false, error: 'Valid entity required.' }, { status: 400 });
    if (!hasFirmWideScope(user) && user.clientId !== clientId) return Response.json({ ok: false, error: 'Entity not assigned.' }, { status: 403 });
    if (user.status !== 'active' || user.role === 'auditor' || user.permissions?.canPostJournals === false) return Response.json({ ok: false, error: 'No posting authority.' }, { status: 403 });
    if (body.action !== 'accrue') return Response.json({ ok: false, error: 'Only accrual is allowed here. Settle due debt at the Payment Desk.' }, { status: 400 });
    const periodNum = Number(body.periodNum);
    if (!Number.isInteger(periodNum) || periodNum < 1) return Response.json({ ok: false, error: 'Valid instalment required.' }, { status: 400 });
    const entity = (await db.select().from(clients).where(eq(clients.id, clientId)).limit(1))[0];
    if (!entity) return Response.json({ ok: false, error: 'Entity not found.' }, { status: 404 });
    if (!maySeeSection(user, entity as ClientEntity, 'loans_desk')) return Response.json({ ok: false, error: 'Loan module not enabled.' }, { status: 403 });
    const result = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(4027332)`);
      const workbook = (await tx.select().from(entityWorkbooks).where(eq(entityWorkbooks.id, `${clientId}:loan_facilities:register`)).limit(1))[0];
      const facilities = (workbook?.payload as { facilities?: LoanFacility[] })?.facilities ?? [];
      const loan = facilities.find((f) => f.id === body.facilityId);
      if (!loan) throw new Error('Save the borrowing facility before accruing debt service.');
      const row = generateLoanSchedule(loan).find((r) => r.periodNum === periodNum);
      if (!row) throw new Error('Instalment is not in the saved facility schedule.');
      if (row.interestExpense + row.principalPayment <= 0) return { ok: true, idempotent: true, message: 'No interest or principal falls due in this period.' };
      const docNo = debtAccrualDoc(loan.code, periodNum);
      const existing = (await tx.select().from(journalHeaders).where(and(eq(journalHeaders.clientId, clientId), eq(journalHeaders.docNo, docNo))).limit(1))[0];
      if (existing) return { ok: true, idempotent: true, docNo };
      const base = { clientId, docNo, date: row.date, period: row.date.slice(0, 7), module: 'FI' as const, docType: 'STAT' as const,
        currency: entity.currency, createdBy: user.username, costCenter: 'CC-ADM', reference: debtReference(loan.code, periodNum) };
      const lines: ACDOCALine[] = [];
      if (row.interestExpense > 0) lines.push({ ...base, id: randomUUID(), accountNo: '700000', accountName: 'Finance Costs — Loan Interest', debit: row.interestExpense, credit: 0, description: `${docNo}: interest ${loan.code} M${periodNum}` });
      if (row.principalPayment > 0) lines.push({ ...base, id: randomUUID(), accountNo: '250000', accountName: 'Commercial Borrowings', debit: row.principalPayment, credit: 0, description: `${docNo}: principal transferred to due debt ${loan.code} M${periodNum}` });
      lines.push({ ...base, id: randomUUID(), accountNo: DEBT_PAYABLE_ACCOUNT, accountName: 'Accrued Interest & Debt Service Payable', debit: 0, credit: Math.round((row.interestExpense + row.principalPayment) * 100) / 100, description: `${docNo}: payable to ${loan.lender}; settle at Payment Desk` });
      await postEntityJournal(tx, user, entity, lines, 'DEBT_SERVICE_ACCRUED');
      return { ok: true, docNo, payable: lines[lines.length - 1].credit, idempotent: false };
    });
    return Response.json(result, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Accrual failed.';
    const controlled = /closed|maker|permission|not in|not found|Save the|Instalment|Principal|interest rate|term|already|No interest|entity|account|balanced|decimal/i.test(message);
    if (!controlled) console.error('debt accrual failed', error);
    return Response.json({ ok: false, error: controlled ? message : 'Accrual was not committed. Retry or contact support.' }, { status: controlled ? 409 : 503 });
  }
}
