import { ensureDatabaseReady } from "@/db/bootstrap";
import { sequential } from '@/lib/sequential';
import { BODY_LIMITS, RequestBodyError, readJsonBody } from "@/lib/http";
import { db } from "@/db";
import { auditLog, chartAccounts, closedPeriods, clients, journalHeaders, journalLines, postingEvents, users } from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope } from "@/lib/auth";
import { sameJournalLines, validateJournalLines, validateMakerChecker, validatePostingIdentity } from "@/lib/journalValidation";
import { accountPostabilityFor, postingUserDirectory, sessionPostingRecord, validateControlAccountAuthority } from "@/lib/postingControls";
import { buildJournalHeader, buildPostingEvent, journalContentHash, postingIdempotencyKey } from "@/lib/journalPosting";
import { inArray, sql } from "drizzle-orm";
import type { ACDOCALine } from "@/types/accounting";

export const dynamic = "force-dynamic";

/**
 * Server-side posting service: validates the document (tenant ownership, open
 * period, chart-of-accounts existence, double entry in minor units, idempotent
 * document number) and inserts it with an audit-trail entry in one transaction.
 */
export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch {
    return Response.json({ ok: false, error: "The accounting database is temporarily unavailable." }, { status: 503 });
  }
  try {
    return await handleJournalPost(req);
  } catch (error) {
    const reference = crypto.randomUUID();
    const cause = error instanceof Error ? error.cause : undefined;
    const codeValue = error && typeof error === "object" && "code" in error
      ? (error as { code?: unknown }).code
      : cause && typeof cause === "object" && "code" in cause
        ? (cause as { code?: unknown }).code
        : undefined;
    const code = typeof codeValue === "string" ? codeValue : undefined;
    console.error(`[journal-post:${reference}] ${error instanceof Error ? error.name : "UnknownError"}${code ? ` code=${code}` : ""}`);
    return Response.json({ ok: false, error: `The journal was not posted. Retry; if it continues, share reference ${reference}.`, reference }, { status: 500 });
  }
}

interface JournalPostGroup {
  clientId: number;
  docNo: string;
  lines: ACDOCALine[];
}

async function handleJournalPost(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });

  let lines: ACDOCALine[];
  let requestIdempotencyKey: string | undefined;
  try {
    const body = await readJsonBody<{ lines?: ACDOCALine[]; idempotencyKey?: unknown }>(req, BODY_LIMITS.journal);
    lines = body?.lines as ACDOCALine[];
    requestIdempotencyKey = typeof body?.idempotencyKey === "string" ? body.idempotencyKey.trim() : undefined;
  } catch (error) {
    const status = error instanceof RequestBodyError ? error.status : 400;
    return Response.json({ ok: false, error: error instanceof RequestBodyError ? error.message : "Invalid payload." }, { status });
  }
  if (Array.isArray(lines) && lines.length > 2000) {
    return Response.json({ ok: false, error: "A single posting request is limited to 2,000 journal lines." }, { status: 413 });
  }
  if (!Array.isArray(lines) || !lines.length) return Response.json({ ok: false, error: "No journal lines provided." }, { status: 400 });
  if (lines.some((line) => !line || typeof line.id !== "string" || !line.id.trim() || typeof line.docNo !== "string" || !line.docNo.trim())) {
    return Response.json({ ok: false, error: "Every journal line needs a unique id and document number." }, { status: 400 });
  }
  if (new Set(lines.map((line) => line.id)).size !== lines.length) {
    return Response.json({ ok: false, error: "Duplicate journal line ids in the posting request." }, { status: 400 });
  }

  if (user.status !== "active" || user.role === "auditor") {
    return authJson(req, { ok: false, error: "Your account does not have permission to post journals." }, { status: 403 });
  }
  const POSTING_MODULES = [
    "universal_journal", "manual_journal", "adjustments", "opening_balance",
    "expenses", "assets", "prepayments", "payroll", "procurement", "sales",
    "payment_desk", "banking", "inventory", "ifrs_desk", "loans_desk",
    "tax_schedule", "month_end", "project_costing",
  ];
  if (user.role !== "owner" && Array.isArray(user.permissions?.allowedModules)) {
    const allowedSet = new Set(user.permissions.allowedModules);
    if (!POSTING_MODULES.some((m) => allowedSet.has(m))) {
      return authJson(req, { ok: false, error: "No posting module is enabled for your user account." }, { status: 403 });
    }
  }
  // Debt cash settlement must use the Payment Desk authority. Accruals are
  // created by /api/debt; corrections use immutable reversals, not free credits.
  const controlError = validateControlAccountAuthority(lines.filter(Boolean), user.role);
  if (controlError) return authJson(req, { ok: false, error: controlError }, { status: 403 });
  if (lines.some((l) => l && l.module === 'PC')) {
    return authJson(req, { ok: false, error: 'Project cost movements must use the Project Costing desk.' }, { status: 403 });
  }
  const debtLines = lines.filter((l) => l && l.accountNo === '213000');
  if (debtLines.some((l) => !['PAY', 'REV'].includes(l.docType))) {
    return authJson(req, { ok: false, error: 'Create debt-service payables through Loan Amortisation; correct them by reversal.' }, { status: 403 });
  }
  if (debtLines.some((l) => l.docType === 'PAY') && user.role !== 'owner' &&
    (user.permissions?.canApprovePayments === false || (Array.isArray(user.permissions?.allowedModules) && !user.permissions.allowedModules.includes('payment_desk')))) {
    return authJson(req, { ok: false, error: 'Debt payments require Payment Desk access and payment authority.' }, { status: 403 });
  }
  const myClientId = user.clientId ?? null;
  const allClients = await db.select().from(clients);
  const allowedClientIds = hasFirmWideScope(user) ? allClients.map((client) => client.id) : myClientId === null ? [] : [myClientId];
  if (lines.some((line) => !allowedClientIds.includes(line.clientId))) {
    return authJson(req, { ok: false, error: "Transaction belongs to a different client." }, { status: 403 });
  }

  const groupsByKey = new Map<string, JournalPostGroup>();
  for (const line of lines) {
    const key = `${line.clientId}\u0000${line.docNo}`;
    const group = groupsByKey.get(key) ?? { clientId: line.clientId, docNo: line.docNo, lines: [] };
    group.lines.push(line);
    groupsByKey.set(key, group);
  }
  const groups = [...groupsByKey.values()];
  const documentNumbers = [...new Set(groups.map((group) => group.docNo))];
  const idempotencyKeys = groups.map((group) => postingIdempotencyKey(group.clientId, group.docNo, requestIdempotencyKey));
  const [previouslyStored, previousHeaders, previousEvents] = await Promise.all([
    db.select().from(journalLines).where(inArray(journalLines.docNo, documentNumbers)),
    db.select().from(journalHeaders).where(inArray(journalHeaders.docNo, documentNumbers)),
    db.select().from(postingEvents).where(inArray(postingEvents.idempotencyKey, idempotencyKeys)),
  ]);
  const newGroups: JournalPostGroup[] = [];
  for (const group of groups) {
    const requestHash = journalContentHash(group.lines);
    const eventKey = postingIdempotencyKey(group.clientId, group.docNo, requestIdempotencyKey);
    const event = previousEvents.find((row) => row.clientId === group.clientId && row.idempotencyKey === eventKey);
    if (event) {
      if (event.requestHash !== requestHash) {
        return Response.json({ ok: false, error: `Idempotency key for ${group.docNo} was already used with different content.` }, { status: 409 });
      }
      continue;
    }
    const header = previousHeaders.find((row) => row.clientId === group.clientId && row.docNo === group.docNo);
    if (header && header.contentHash !== requestHash) {
      return Response.json({ ok: false, error: `Document ${group.docNo} already exists with different content.` }, { status: 409 });
    }
    const existing = previouslyStored.filter((row) => row.clientId === group.clientId && row.docNo === group.docNo);
    if (existing.length && !sameJournalLines(existing, group.lines)) {
      return Response.json({ ok: false, error: `Document ${group.docNo} already exists with different content.` }, { status: 409 });
    }
    if (!existing.length && !header) newGroups.push(group);
  }
  if (!newGroups.length) return Response.json({ ok: true, idempotent: true, lines });

  const [coa, closed, userRows] = await Promise.all([db.select().from(chartAccounts), db.select().from(closedPeriods), db.select().from(users)]);
  const closedKeys = new Set(closed.filter((period) => allowedClientIds.includes(period.clientId)).map((period) => `${period.clientId}:${period.period}`));
  const coaNos = new Set(coa.filter((account) => account.clientId === null || allowedClientIds.includes(account.clientId)).map((account) => account.accountNo));
  const freshLines = newGroups.flatMap((group) => group.lines);
  const directory = postingUserDirectory(userRows);
  const identityError = validatePostingIdentity(freshLines, { session: sessionPostingRecord(user), users: directory });
  if (identityError) return authJson(req, { ok: false, error: identityError }, { status: 403 });
  const validationError = validateJournalLines(freshLines, { allowedClientIds, closedPeriodKeys: closedKeys, coaAccountNos: coaNos, isAccountPostable: accountPostabilityFor(coa) });
  if (validationError) return Response.json({ ok: false, error: validationError }, { status: 409 });
  const makerCheckerError = validateMakerChecker(freshLines, { username: user.username, makerLimit: user.makerLimit, users: directory });
  if (makerCheckerError) return Response.json({ ok: false, error: makerCheckerError }, { status: 409 });

  let transactionError: string | null = null;
  let savedLines: ACDOCALine[] = [];
  let idempotent = false;
  await db.transaction(async (tx) => {
    // The same lock is used by full-state sync; re-read after acquiring it so
    // concurrent retries cannot double-insert a document.
    await tx.execute(sql`select pg_advisory_xact_lock(4027332)`);
    const [latest, latestHeaders, latestEvents] = await sequential([
      tx.select().from(journalLines).where(inArray(journalLines.docNo, documentNumbers)),
      tx.select().from(journalHeaders).where(inArray(journalHeaders.docNo, documentNumbers)),
      tx.select().from(postingEvents).where(inArray(postingEvents.idempotencyKey, idempotencyKeys)),
    ]);
    const pending: JournalPostGroup[] = [];
    for (const group of groups) {
      const requestHash = journalContentHash(group.lines);
      const eventKey = postingIdempotencyKey(group.clientId, group.docNo, requestIdempotencyKey);
      const event = latestEvents.find((row) => row.clientId === group.clientId && row.idempotencyKey === eventKey);
      if (event) {
        if (event.requestHash !== requestHash) transactionError = `Idempotency key for ${group.docNo} was already used with different content.`;
        if (transactionError) return;
        continue;
      }
      const header = latestHeaders.find((row) => row.clientId === group.clientId && row.docNo === group.docNo);
      if (header) {
        if (header.contentHash !== requestHash) transactionError = `Document ${group.docNo} already exists with different content.`;
        if (transactionError) return;
        continue;
      }
      const existing = latest.filter((row) => row.clientId === group.clientId && row.docNo === group.docNo);
      if (!existing.length) {
        pending.push(group);
      } else if (!sameJournalLines(existing, group.lines)) {
        transactionError = `Document ${group.docNo} already exists with different content.`;
        return;
      }
    }
    if (!pending.length) {
      idempotent = true;
      savedLines = lines;
      return;
    }

    const pendingLines = pending.flatMap((group) => group.lines);
    const [latestCoa, latestClosed, latestUsers] = await sequential([tx.select().from(chartAccounts), tx.select().from(closedPeriods), tx.select().from(users)]);
    const latestClosedKeys = new Set(latestClosed.filter((period) => allowedClientIds.includes(period.clientId)).map((period) => `${period.clientId}:${period.period}`));
    const latestCoaNos = new Set(latestCoa.filter((account) => account.clientId === null || allowedClientIds.includes(account.clientId)).map((account) => account.accountNo));
    const latestDirectory = postingUserDirectory(latestUsers);
    transactionError = validatePostingIdentity(pendingLines, { session: sessionPostingRecord(user), users: latestDirectory });
    if (transactionError) return;
    transactionError = validateJournalLines(pendingLines, { allowedClientIds, closedPeriodKeys: latestClosedKeys, coaAccountNos: latestCoaNos, isAccountPostable: accountPostabilityFor(latestCoa) });
    if (transactionError) return;
    transactionError = validateMakerChecker(pendingLines, { username: user.username, makerLimit: user.makerLimit, users: latestDirectory });
    if (transactionError) return;

    const existingIds = await tx.select({ id: journalLines.id }).from(journalLines).where(inArray(journalLines.id, pendingLines.map((line) => line.id)));
    if (existingIds.length) {
      transactionError = `Journal line id ${existingIds[0].id} has already been used.`;
      return;
    }
    await tx.insert(journalLines).values(pendingLines.map((line) => ({
      id: line.id, docNo: line.docNo, period: line.period, date: line.date, module: line.module, docType: line.docType,
      accountNo: line.accountNo, accountName: line.accountName, costCenter: line.costCenter ?? null,
      debit: line.debit, credit: line.credit, currency: line.currency, description: line.description,
      createdBy: line.createdBy, checkedBy: line.checkedBy ?? null, isReversed: line.isReversed ?? false,
      reference: line.reference ?? null, clientId: line.clientId,
    })));
    await tx.insert(journalHeaders).values(pending.map((group) => buildJournalHeader(group.lines))).onConflictDoNothing();
    await tx.insert(postingEvents).values(pending.map((group) => buildPostingEvent(group.lines, user.username, requestIdempotencyKey))).onConflictDoNothing();
    await tx.insert(auditLog).values(pending.map((group) => {
      const debits = group.lines.reduce((total, line) => total + Math.round(line.debit * 100), 0) / 100;
      return {
        id: crypto.randomUUID(), timestamp: new Date().toISOString(), userId: user.username, username: user.username,
        action: "POST_JOURNAL", target: group.docNo, details: `${group.lines.length} line(s), debits ${debits.toFixed(2)}`,
        clientId: group.clientId,
      };
    }));
    savedLines = lines;
  });

  if (transactionError) return Response.json({ ok: false, error: transactionError }, { status: 409 });
  return Response.json({ ok: true, idempotent, lines: savedLines });
}

// Posted documents are accounting evidence. Corrections use append-only reversals.
async function refusePostedMutation(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return authJson(req, { ok: false, error: 'Unauthorized' }, { status: 401 });
    return Response.json({ ok: false, error: 'Posted documents are immutable. Reverse the original and post a correcting journal.' }, { status: 409 });
  } catch {
    return Response.json({ ok: false, error: 'The accounting database is temporarily unavailable.' }, { status: 503 });
  }
}

export const PATCH = refusePostedMutation;
export const DELETE = refusePostedMutation;
