import { randomUUID } from "node:crypto";
import { readJsonBody } from "@/lib/http";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { auditLog, deskRecords } from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * Document delivery channel (quotations, purchase orders, client mail).
 *
 * Production behaviour:
 *  - If SMTP is configured (SMTP_HOST + SMTP_FROM, optional SMTP_USER/PASS/
 *    PORT/SECURE), mail is sent through the organisation's own mail server and
 *    the response status is "sent".
 *  - If SMTP is NOT configured, the message is never dropped: it is written to
 *    the delivery log as "queued" with status "queued", and the client falls
 *    back to the device mail client. Nothing fails silently either way.
 *
 * Controls: authenticated, tenant-scoped (a user bound to one entity cannot
 * send for another), auditors read-only, size-limited, and every dispatch is
 * written to the audit trail (recipient/subject/status — never the body
 * beyond a short reference, to avoid storing personal data unnecessarily).
 */

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const MAX_SUBJECT = 200;
const MAX_BODY = 20_000;

function json(body: unknown, status = 200) {
  return Response.json(body, { status, headers: { "cache-control": "no-store" } });
}

function smtpConfigured(): boolean {
  return Boolean(process.env.SMTP_HOST && process.env.SMTP_FROM);
}

async function sendViaSmtp(to: string, subject: string, text: string): Promise<void> {
  const nodemailer = (await import("nodemailer")).default;
  const port = Number(process.env.SMTP_PORT || 587);
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure: process.env.SMTP_SECURE === "true" || port === 465,
    auth: process.env.SMTP_USER
      ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS || "" }
      : undefined,
  });
  await transporter.sendMail({ from: process.env.SMTP_FROM, to, subject, text });
}

export async function POST(req: Request) {
  let body: { clientId?: unknown; to?: unknown; subject?: unknown; body?: unknown; ref?: unknown } | null = null;
  try {
    body = await readJsonBody<any>(req, 1_048_576);
  } catch {
    return json({ ok: false, error: "Invalid request body." }, 400);
  }

  const clientId = Number(body?.clientId);
  const to = String(body?.to ?? "").trim();
  const subject = String(body?.subject ?? "").trim().slice(0, MAX_SUBJECT);
  const text = String(body?.body ?? "").slice(0, MAX_BODY);
  const ref = String(body?.ref ?? "").trim().slice(0, 80);

  if (!Number.isInteger(clientId) || clientId <= 0) return json({ ok: false, error: "A valid client entity is required." }, 400);
  if (!EMAIL_RE.test(to)) return json({ ok: false, error: "A valid recipient e-mail address is required." }, 400);
  if (!subject) return json({ ok: false, error: "A subject is required." }, 400);
  if (!text.trim()) return json({ ok: false, error: "A message body is required." }, 400);

  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
    if (user.status === "restricted" || user.status === "suspended") {
      return json({ ok: false, error: "This account is restricted." }, 403);
    }
    if (user.role === "auditor") {
      return json({ ok: false, error: "Auditors have read-only access and cannot send mail." }, 403);
    }
    const firmWide = hasFirmWideScope(user);
    if (!firmWide && user.clientId !== clientId) {
      return json({ ok: false, error: "You do not have access to that entity." }, 403);
    }

    const id = randomUUID();
    let status: "sent" | "queued" = "queued";
    let detail = "SMTP not configured — queued for mail-client fallback";

    if (smtpConfigured()) {
      try {
        await sendViaSmtp(to, subject, text);
        status = "sent";
        detail = "Delivered via configured SMTP server";
      } catch (error) {
        console.error("SMTP send failed", error);
        // Fall back to queued rather than failing the user's workflow.
        detail = "SMTP delivery failed — queued for mail-client fallback";
      }
    }

    const now = new Date();
    await db.insert(deskRecords).values({
      id,
      clientId,
      desk: "system",
      kind: "mail_delivery",
      payload: { to, subject, status, ref: ref || undefined, at: now.toISOString() },
      createdBy: user.username,
      updatedBy: user.username,
    });
    await db.insert(auditLog).values({
      id: randomUUID(),
      timestamp: now.toISOString(),
      userId: user.username,
      username: user.username,
      action: status === "sent" ? "MAIL_SENT" : "MAIL_QUEUED",
      target: ref || subject,
      details: `to: ${to} · ${detail}`.slice(0, 300),
      clientId,
    });

    return json({ ok: true, status, deliveryId: id, detail });
  } catch (error) {
    console.error("mail POST failed", error);
    return json({ ok: false, error: "The message could not be dispatched." }, 503);
  }
}
