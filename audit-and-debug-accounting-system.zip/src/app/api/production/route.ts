import { randomUUID } from 'node:crypto';
import { sequential } from '@/lib/sequential';
import { and, eq, lte, sql } from 'drizzle-orm';
import { db } from '@/db';
import { ensureDatabaseReady } from '@/db/bootstrap';
import {
  auditLog, billOfMaterials, chartAccounts, clients, closedPeriods, deskRecords,
  journalHeaders, journalLines, postingEvents, productionIssues, productionOrders,
  productionReceipts, stockItems, stockMovements, users,
} from '@/db/schema';
import type { Tx } from '@/db/seedData';
import { getSessionUser, hasFirmWideScope } from '@/lib/auth';
import { validateJournalLines, validateMakerChecker, validatePostingIdentity, isValidIsoDate } from '@/lib/journalValidation';
import { buildJournalHeader, buildPostingEvent } from '@/lib/journalPosting';
import { accountPostabilityFor, postingUserDirectory, sessionPostingRecord } from '@/lib/postingControls';
import { finishedReceiptCost, plannedComponentQty, productionMoney, productionQty, receiveFinishedItem } from '@/lib/productionRules';
import { applyIssue } from '@/utils/trading';
import { maySeeSection } from '@/utils/access';
import type { ACDOCALine, ClientEntity, StockItem, StockMovement, UserAccount } from '@/types/accounting';

export const dynamic = 'force-dynamic';

const LOCK = 4027332; // Same global ledger/stock lock as /api/journal and /api/state.
const MAX_BODY = 20_000;
const ID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const ITEM_RE = /^[A-Z0-9._/-]{2,60}$/;

class ProductionError extends Error {
  constructor(message: string, readonly status = 409) { super(message); }
}
function ensure(condition: unknown, message: string, status = 409): asserts condition {
  if (!condition) throw new ProductionError(message, status);
}
function number(v: unknown, label: string, max = 1_000_000_000): number {
  const n = Number(v);
  ensure(v !== null && v !== undefined && v !== '' && Number.isFinite(n) && n > 0 && n <= max, `${label} must be a positive, finite number no greater than ${max}.`, 400);
  return n;
}
function key(v: unknown): string {
  ensure(typeof v === 'string' && ID_RE.test(v), 'A UUID request key is required for safe retries.', 400);
  return v;
}
function code(v: unknown): string {
  const c = String(v ?? '').trim().toUpperCase();
  ensure(ITEM_RE.test(c), 'An existing item code (2–60 letters, digits or ._- /) is required.', 400);
  return c;
}
function itemOf(row: typeof stockItems.$inferSelect): StockItem {
  return { ...row, reorderLevel: row.reorderLevel ?? undefined, location: row.location ?? undefined,
    glAccount: row.glAccount ?? undefined, costMethod: (row.costMethod ?? 'weighted_average') as StockItem['costMethod'],
    netRealisableValue: row.netRealisableValue ?? undefined };
}
function journalLine(base: { clientId: number; docNo: string; date: string; currency: string; maker: string; costCenter: string; reference: string },
  accountNo: string, accountName: string, debit: number, credit: number, description: string): ACDOCALine {
  return { id: randomUUID(), clientId: base.clientId, docNo: base.docNo, date: base.date, period: base.date.slice(0, 7),
    module: 'PP', docType: 'WO', currency: base.currency, accountNo, accountName, debit, credit,
    description, costCenter: base.costCenter, reference: base.reference, createdBy: base.maker };
}
function dateOf(v: unknown): string {
  ensure(isValidIsoDate(v), 'A valid posting date (YYYY-MM-DD) is required.', 400);
  return v;
}

async function authorise(req: Request, clientId: number) {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  ensure(user, 'Sign in to access this entity.', 401);
  ensure(user.status === 'active', 'Your account is restricted.', 403);
  ensure(hasFirmWideScope(user) || user.clientId === clientId, 'This entity is not assigned to your account.', 403);
  const entity = (await db.select().from(clients).where(eq(clients.id, clientId)).limit(1))[0];
  ensure(entity, 'Client workspace not found.', 404);
  const scopedEntity = { ...entity, assignedServices: Array.isArray(entity.assignedServices) ? entity.assignedServices as string[] : undefined } as ClientEntity;
  ensure(maySeeSection(user, scopedEntity, 'production_desk'), 'The production service is not assigned to this entity.', 403);
  return { user, entity };
}

async function postJournal(tx: Tx, user: UserAccount, entity: typeof clients.$inferSelect, lines: ACDOCALine[]) {
  const docNo = lines[0]?.docNo;
  ensure(docNo, 'No production document to post.', 400);
  const existing = await tx.select({ id: journalHeaders.id }).from(journalHeaders)
    .where(and(eq(journalHeaders.clientId, entity.id), eq(journalHeaders.docNo, docNo))).limit(1);
  ensure(!existing.length, `Document ${docNo} was already posted. Refresh before trying again.`);
  const [coa, periods, userRows] = await sequential([
    tx.select().from(chartAccounts), tx.select().from(closedPeriods).where(eq(closedPeriods.clientId, entity.id)), tx.select().from(users),
  ]);
  const directory = postingUserDirectory(userRows);
  const error = validateJournalLines(lines, {
    allowedClientIds: [entity.id],
    closedPeriodKeys: new Set(periods.map((p) => `${p.clientId}:${p.period}`)),
    coaAccountNos: new Set(coa.filter((a) => a.clientId === null || a.clientId === entity.id).map((a) => a.accountNo)),
    isAccountPostable: accountPostabilityFor(coa),
  }) || validatePostingIdentity(lines, { session: sessionPostingRecord(user), users: directory })
    || validateMakerChecker(lines, { username: user.username, makerLimit: user.makerLimit, users: directory });
  ensure(!error, error ?? 'Journal rejected by posting controls.');
  await tx.insert(journalLines).values(lines);
  await tx.insert(journalHeaders).values(buildJournalHeader(lines));
  await tx.insert(postingEvents).values(buildPostingEvent(lines, user.username));
}

function wipFromLines(lines: { debit: number; credit: number }[]): number {
  return productionMoney(lines.reduce((total, line) => total + line.debit - line.credit, 0));
}

export async function GET(req: Request) {
  try {
    const clientId = Number(new URL(req.url).searchParams.get('clientId'));
    ensure(Number.isInteger(clientId) && clientId > 0, 'A valid clientId is required.', 400);
    await authorise(req, clientId);
    const [boms, orders, issues, receipts, legacyRows, wipLines] = await Promise.all([
      db.select().from(billOfMaterials).where(eq(billOfMaterials.clientId, clientId)),
      db.select().from(productionOrders).where(eq(productionOrders.clientId, clientId)),
      db.select().from(productionIssues).where(eq(productionIssues.clientId, clientId)),
      db.select().from(productionReceipts).where(eq(productionReceipts.clientId, clientId)),
      db.select({ id: deskRecords.id }).from(deskRecords).where(and(eq(deskRecords.clientId, clientId), eq(deskRecords.desk, 'production'))),
      db.select({ reference: journalLines.reference, debit: journalLines.debit, credit: journalLines.credit })
        .from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.accountNo, '122000'))),
    ]);
    const wipByOrder = Object.fromEntries(orders.map((o) => [o.id, wipFromLines(wipLines.filter((l) => l.reference === o.docNo))]));
    return Response.json({ ok: true, boms, orders, issues, receipts, wipByOrder, legacyCount: legacyRows.length },
      { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    if (error instanceof ProductionError) return Response.json({ ok: false, error: error.message }, { status: error.status });
    console.error('production GET failed', error);
    return Response.json({ ok: false, error: 'Production data is temporarily unavailable.' }, { status: 503 });
  }
}

export async function POST(req: Request) {
  try {
    const text = await req.text();
    ensure(text.length <= MAX_BODY, 'Request exceeds the 20 KB limit.', 413);
    let body: { clientId?: unknown; action?: unknown; payload?: Record<string, unknown>; requestKey?: unknown };
    try { body = JSON.parse(text); } catch { throw new ProductionError('Invalid JSON request.', 400); }
    ensure(body && typeof body === 'object' && !Array.isArray(body), 'A request object is required.', 400);
    const clientId = Number(body.clientId);
    ensure(Number.isInteger(clientId) && clientId > 0, 'A valid clientId is required.', 400);
    const { user, entity } = await authorise(req, clientId);
    ensure(user.role !== 'auditor', 'Auditors can review production but cannot change it.', 403);
    const action = String(body.action ?? '');
    ensure(['save_bom', 'remove_bom', 'create_order', 'release_order', 'issue_material', 'record_conversion', 'receive_output', 'close_order'].includes(action),
      'Unknown production action.', 400);
    const p = body.payload && typeof body.payload === 'object' && !Array.isArray(body.payload) ? body.payload : {};
    const result = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(${LOCK})`);
      const now = new Date().toISOString();
      const audit = async (target: string, detail: string) => {
        await tx.insert(auditLog).values({ id: randomUUID(), timestamp: now, userId: user.username, username: user.username,
          action: `PRODUCTION_${action.toUpperCase()}`, target, details: detail, clientId });
      };
      const orderFor = async () => {
        const id = String(p.orderId ?? '');
        ensure(ID_RE.test(id), 'Select a valid production order.', 400);
        const order = (await tx.select().from(productionOrders)
          .where(and(eq(productionOrders.id, id), eq(productionOrders.clientId, clientId))).limit(1))[0];
        ensure(order, 'This production order does not belong to this entity.', 404);
        return order;
      };
      const stockFor = async (itemCode: string) => {
        const row = (await tx.select().from(stockItems)
          .where(and(eq(stockItems.clientId, clientId), eq(stockItems.itemCode, itemCode))).limit(1))[0];
        ensure(row, `Item ${itemCode} is not in this entity's stock master. Add it in Inventory first.`, 404);
        return row;
      };
      const coaName = async (accountNo: string) => {
        const accounts = await tx.select().from(chartAccounts)
          .where(and(eq(chartAccounts.accountNo, accountNo), sql`${chartAccounts.clientId} is null or ${chartAccounts.clientId} = ${clientId}`));
        const selected = accounts.find((a) => a.clientId === clientId) ?? accounts.find((a) => a.clientId === null);
        ensure(selected?.active, `Account ${accountNo} is missing or inactive for this entity.`, 409);
        return selected.name;
      };
      if (action === 'save_bom' || action === 'remove_bom') {
        const parentCode = code(p.parentItemCode);
        const componentCode = code(p.componentItemCode);
        ensure(parentCode !== componentCode, 'A finished item cannot be its own component.', 400);
        const active = await tx.select().from(productionOrders)
          .where(and(eq(productionOrders.clientId, clientId), eq(productionOrders.itemCode, parentCode)));
        ensure(!active.some((o) => o.status === 'Released' || o.status === 'In Production'),
          'A released work order uses this BOM. Complete or close it before changing components.');
        const existing = (await tx.select().from(billOfMaterials)
          .where(and(eq(billOfMaterials.clientId, clientId), eq(billOfMaterials.parentItemCode, parentCode),
            eq(billOfMaterials.componentItemCode, componentCode))).limit(1))[0];
        if (action === 'remove_bom') {
          ensure(existing, 'BOM component not found.', 404);
          await tx.delete(billOfMaterials).where(eq(billOfMaterials.id, existing.id));
          await audit(parentCode, `Removed component ${componentCode}.`);
          return { ok: true };
        }
        const parent = await stockFor(parentCode);
        const component = await stockFor(componentCode);
        ensure(parent.category.toLowerCase().includes('finished'), `${parentCode} must be classified as Finished Goods.`, 409);
        ensure(!component.category.toLowerCase().includes('finished'), `${componentCode} must be a raw material or consumable.`, 409);
        const perUnit = number(p.qtyPerUnit, 'BOM quantity', 1_000_000);
        const wastePct = Number(p.wastePct ?? 0);
        ensure(Number.isFinite(wastePct) && wastePct >= 0 && wastePct <= 100, 'Normal waste must be between 0 and 100%.', 400);
        ensure(productionQty(perUnit) === perUnit, 'Quantities can have at most three decimal places.', 400);
        const fields = { qtyPerUnit: perUnit, wastePct, uom: component.uom, active: true };
        if (existing) await tx.update(billOfMaterials).set(fields).where(eq(billOfMaterials.id, existing.id));
        else await tx.insert(billOfMaterials).values({ id: randomUUID(), clientId, parentItemCode: parentCode,
          componentItemCode: componentCode, ...fields });
        await audit(parentCode, `${existing ? 'Updated' : 'Added'} ${componentCode}, ${perUnit} ${component.uom} per unit; normal waste ${wastePct}%.`);
        return { ok: true };
      }
      if (action === 'create_order') {
        const requestKey = key(body.requestKey);
        const itemCode = code(p.itemCode);
        const qty = number(p.qty, 'Order output quantity', 1_000_000);
        ensure(productionQty(qty) === qty, 'Order quantity can have at most three decimal places.', 400);
        const startDate = dateOf(p.startDate);
        const costCenter = String(p.costCenter ?? '').trim().slice(0, 60);
        ensure(costCenter.length >= 2, 'Enter a production site or cost centre.', 400);
        const previous = (await tx.select().from(productionOrders)
          .where(and(eq(productionOrders.id, requestKey), eq(productionOrders.clientId, clientId))).limit(1))[0];
        if (previous) {
          ensure(previous.itemCode === itemCode && previous.qty === qty && previous.startDate === startDate && previous.costCenter === costCenter,
            'This request key was already used for a different order.');
          return { ok: true, idempotent: true, order: previous };
        }
        const finished = await stockFor(itemCode);
        ensure(finished.category.toLowerCase().includes('finished'), 'Select a finished-goods item, not a raw material.');
        ensure(finished.glAccount === '121000' || ((!finished.glAccount || finished.glAccount === '120000') && finished.quantityOnHand === 0 && finished.totalValue === 0),
          'Finished goods with a balance must be assigned to GL 121000 before production.');
        const boms = await tx.select().from(billOfMaterials)
          .where(and(eq(billOfMaterials.clientId, clientId), eq(billOfMaterials.parentItemCode, itemCode), eq(billOfMaterials.active, true)));
        ensure(boms.length > 0, `Create a BOM for ${itemCode} before opening a work order.`);
        const glWipAccountName = await coaName('122000');
        const glFinishedGoodsAccountName = await coaName('121000');
        const glRawMaterialAccountName = await coaName('120000');
        const docNo = `WO-${startDate.replaceAll('-', '')}-${randomUUID().slice(0, 8).toUpperCase()}`;
        const [order] = await tx.insert(productionOrders).values({ id: requestKey, clientId, docNo, itemCode,
          itemDescription: finished.description, qty, uom: finished.uom, status: 'Draft', startDate,
          costCenter, costCenterName: costCenter, glWipAccount: '122000', glWipAccountName,
          glFinishedGoodsAccount: '121000', glFinishedGoodsAccountName, glRawMaterialAccount: '120000', glRawMaterialAccountName,
          totalMaterialCost: 0, totalConversionCost: 0, totalCost: 0, createdBy: user.username, createdAt: now,
        }).returning();
        if (finished.glAccount !== '121000') await tx.update(stockItems).set({ glAccount: '121000' }).where(eq(stockItems.id, finished.id));
        await audit(docNo, `Draft for ${qty} ${finished.uom} of ${itemCode}; no journal posted.`);
        return { ok: true, order };
      }
      if (action === 'release_order') {
        const order = await orderFor();
        ensure(order.status === 'Draft', 'Only a draft order can be released.');
        ensure(['owner', 'partner', 'manager'].includes(user.role), 'A manager or owner must release a production order.', 403);
        const components = await tx.select().from(billOfMaterials).where(and(eq(billOfMaterials.clientId, clientId),
          eq(billOfMaterials.parentItemCode, order.itemCode), eq(billOfMaterials.active, true)));
        ensure(components.length > 0, 'Complete the BOM before releasing the order.');
        const [updated] = await tx.update(productionOrders).set({ status: 'Released' }).where(eq(productionOrders.id, order.id)).returning();
        await audit(order.docNo, 'Released for material issues (manager control).');
        return { ok: true, order: updated };
      }
      if (action === 'close_order') {
        const order = await orderFor();
        ensure(order.status === 'Completed', 'Only a completed order can be closed.');
        ensure(['owner', 'partner', 'manager'].includes(user.role), 'A manager or owner must close the order.', 403);
        const wip = await tx.select({ debit: journalLines.debit, credit: journalLines.credit }).from(journalLines)
          .where(and(eq(journalLines.clientId, clientId), eq(journalLines.reference, order.docNo), eq(journalLines.accountNo, '122000')));
        ensure(Math.abs(wipFromLines(wip)) < 0.01, 'The order has an unallocated WIP balance. Reconcile before closing.');
        const [updated] = await tx.update(productionOrders).set({ status: 'Closed' }).where(eq(productionOrders.id, order.id)).returning();
        await audit(order.docNo, 'Closed after zero-WIP reconciliation.');
        return { ok: true, order: updated };
      }
      if (action === 'issue_material') {
        const requestKey = key(body.requestKey);
        const order = await orderFor();
        const materialCode = code(p.itemCode);
        const qty = number(p.qty, 'Material issue quantity', 1_000_000);
        const date = dateOf(p.date);
        ensure(productionQty(qty) === qty, 'Material quantity can have at most three decimal places.', 400);
        const previous = (await tx.select().from(productionIssues)
          .where(and(eq(productionIssues.id, requestKey), eq(productionIssues.clientId, clientId))).limit(1))[0];
        if (previous) {
          ensure(previous.productionOrderId === order.id && previous.itemCode === materialCode && previous.qty === qty && previous.issuedAt === date,
            'This request key was already used for a different material issue.');
          return { ok: true, idempotent: true, issue: previous };
        }
        ensure(order.status === 'Released' || order.status === 'In Production', 'Release the order before issuing materials.');
        ensure(date >= order.startDate, 'Material issues cannot predate the work order start date.');
        const bom = (await tx.select().from(billOfMaterials).where(and(eq(billOfMaterials.clientId, clientId),
          eq(billOfMaterials.parentItemCode, order.itemCode), eq(billOfMaterials.componentItemCode, materialCode), eq(billOfMaterials.active, true))).limit(1))[0];
        ensure(bom, `${materialCode} is not in this work order's approved BOM.`);
        const issued = await tx.select({ qty: productionIssues.qty }).from(productionIssues)
          .where(and(eq(productionIssues.clientId, clientId), eq(productionIssues.productionOrderId, order.id), eq(productionIssues.itemCode, materialCode)));
        const used = productionQty(issued.reduce((n, r) => n + r.qty, 0));
        const planned = plannedComponentQty(order.qty, bom.qtyPerUnit, bom.wastePct);
        ensure(productionQty(used + qty) <= planned, `${materialCode}: ${used} already issued; the BOM permits ${planned} ${bom.uom}. Revise the BOM in a new work order for an overrun.`);
        const row = await stockFor(materialCode);
        ensure(!row.category.toLowerCase().includes('finished'), 'Finished goods cannot be issued as a raw-material component.');
        const sourceAccount = row.glAccount || '120000';
        const sourceAccountName = await coaName(sourceAccount);
        const history = await tx.select().from(stockMovements).where(and(eq(stockMovements.clientId, clientId), eq(stockMovements.itemCode, materialCode)));
        const issuedStock = applyIssue(itemOf(row), qty, history as StockMovement[], (row.costMethod || 'weighted_average') as StockItem['costMethod']);
        ensure(!issuedStock.error, issuedStock.error ?? 'Stock issue refused.');
        const cost = issuedStock.cost;
        ensure(cost > 0, 'The material has no recorded carrying value. Receive/price it before issuing.');
        const docNo = `PROD-ISS-${requestKey}`;
        const base = { clientId, docNo, date, currency: entity.currency, maker: user.username, costCenter: order.costCenter, reference: order.docNo };
        const lines = [journalLine(base, '122000', await coaName('122000'), cost, 0, `WIP material issue ${materialCode} to ${order.docNo}`),
          journalLine(base, sourceAccount, sourceAccountName, 0, cost, `Stock released ${materialCode} to ${order.docNo}`)];
        await postJournal(tx, user, entity, lines);
        const movementId = randomUUID();
        await tx.update(stockItems).set({ quantityOnHand: issuedStock.item.quantityOnHand,
          totalValue: issuedStock.item.totalValue, unitCost: issuedStock.item.unitCost }).where(eq(stockItems.id, row.id));
        await tx.insert(stockMovements).values({ id: movementId, clientId, date, itemCode: materialCode, description: row.description,
          type: 'Issue', quantity: qty, unitCost: issuedStock.unitCost, totalValue: cost, uom: row.uom,
          docNo, reference: order.docNo, note: 'Production material issue' });
        const [issue] = await tx.insert(productionIssues).values({ id: requestKey, clientId, productionOrderId: order.id,
          itemCode: materialCode, itemDescription: row.description, qty, uom: row.uom, unitCost: issuedStock.unitCost,
          totalCost: cost, issuedAt: date, issuedBy: user.username, stockMovementId: movementId }).returning();
        await tx.update(productionOrders).set({ status: 'In Production', totalMaterialCost: productionMoney(order.totalMaterialCost + cost),
          totalCost: productionMoney(order.totalCost + cost) }).where(eq(productionOrders.id, order.id));
        await audit(order.docNo, `${qty} ${row.uom} ${materialCode} to WIP; ${cost.toFixed(2)} ${entity.currency}; journal ${docNo}.`);
        return { ok: true, issue, docNo };
      }
      if (action === 'record_conversion') {
        const requestKey = key(body.requestKey);
        const order = await orderFor();
        ensure(order.status === 'In Production', 'Issue materials before allocating conversion costs.');
        ensure(['owner', 'partner', 'manager'].includes(user.role), 'A manager must review direct labour/overhead allocations.', 403);
        const amount = number(p.amount, 'Conversion cost', 1_000_000_000);
        ensure(productionMoney(amount) === amount, 'Conversion cost must have no more than two decimal places.', 400);
        const date = dateOf(p.date);
        ensure(date >= order.startDate, 'Conversion costs cannot predate the work order.');
        const expenseAccount = code(p.accountNo);
        const sourceDocNo = String(p.sourceDocNo ?? '').trim();
        ensure(/^[A-Za-z0-9._/-]{3,100}$/.test(sourceDocNo), 'Enter the posted labour/overhead document number (3–100 safe characters).', 400);
        const reason = String(p.reason ?? '').trim().slice(0, 180);
        ensure(reason.length >= 12, 'Explain the direct production cost and why it qualifies for WIP (at least 12 characters).', 400);
        const sourceAccount = (await tx.select().from(chartAccounts)
          .where(and(eq(chartAccounts.accountNo, expenseAccount), sql`${chartAccounts.clientId} is null or ${chartAccounts.clientId} = ${clientId}`)))[0];
        ensure(sourceAccount?.active && sourceAccount.type === 'Expense', 'Select an active, expense-classified account for already-posted direct costs.');
        const docNo = `PROD-CNV-${requestKey}`;
        const priorDoc = (await tx.select().from(journalHeaders)
          .where(and(eq(journalHeaders.clientId, clientId), eq(journalHeaders.docNo, docNo))).limit(1))[0];
        if (priorDoc) {
          const prior = await tx.select().from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.docNo, docNo)));
          ensure(prior.some((l) => l.accountNo === expenseAccount && l.credit === amount && l.reference === order.docNo && l.description.startsWith(`WO conversion [${sourceDocNo}]`)),
            'This request key was already used for a different conversion allocation.');
          return { ok: true, idempotent: true, docNo };
        }
        const sourceLines = await tx.select().from(journalLines).where(and(eq(journalLines.clientId, clientId),
          eq(journalLines.docNo, sourceDocNo), eq(journalLines.accountNo, expenseAccount)));
        ensure(sourceLines.length > 0 && sourceLines.every((l) => l.currency === entity.currency && l.date <= date),
          'The source expense must be posted in this entity/currency no later than the allocation date.');
        const sourceBalance = productionMoney(sourceLines.reduce((n, l) => n + l.debit - l.credit, 0));
        const conversions = await tx.select({ description: journalLines.description, credit: journalLines.credit }).from(journalLines)
          .where(and(eq(journalLines.clientId, clientId), eq(journalLines.module, 'PP'), eq(journalLines.accountNo, expenseAccount)));
        const alreadyAllocated = productionMoney(conversions
          .filter((l) => l.description.startsWith(`WO conversion [${sourceDocNo}] `))
          .reduce((n, l) => n + l.credit, 0));
        ensure(sourceBalance - alreadyAllocated >= amount - 0.001,
          `Only ${productionMoney(sourceBalance - alreadyAllocated).toFixed(2)} of source ${sourceDocNo} remains unallocated to work orders.`);
        const description = `WO conversion [${sourceDocNo}] ${reason}`.slice(0, 240);
        const base = { clientId, docNo, date, currency: entity.currency, maker: user.username, costCenter: order.costCenter, reference: order.docNo };
        const lines = [journalLine(base, '122000', await coaName('122000'), amount, 0, description),
          journalLine(base, expenseAccount, sourceAccount.name, 0, amount, description)];
        await postJournal(tx, user, entity, lines);
        await tx.update(productionOrders).set({ totalConversionCost: productionMoney(order.totalConversionCost + amount),
          totalCost: productionMoney(order.totalCost + amount) }).where(eq(productionOrders.id, order.id));
        await audit(order.docNo, `Direct conversion cost ${amount.toFixed(2)} allocated from posted ${sourceDocNo} (${expenseAccount}); journal ${docNo}.`);
        return { ok: true, docNo };
      }
      if (action === 'receive_output') {
        const requestKey = key(body.requestKey);
        const order = await orderFor();
        const qty = number(p.qty, 'Finished output quantity', 1_000_000);
        const date = dateOf(p.date);
        ensure(productionQty(qty) === qty, 'Output quantity can have at most three decimal places.', 400);
        const previous = (await tx.select().from(productionReceipts)
          .where(and(eq(productionReceipts.id, requestKey), eq(productionReceipts.clientId, clientId))).limit(1))[0];
        if (previous) {
          ensure(previous.productionOrderId === order.id && previous.qty === qty && previous.receivedAt === date,
            'This request key was already used for a different output receipt.');
          return { ok: true, idempotent: true, receipt: previous };
        }
        ensure(order.status === 'In Production', 'Issue materials before receiving output; WIP must exist.');
        ensure(date >= order.startDate, 'Finished output cannot predate the work order start date.');
        const priorReceipts = await tx.select({ qty: productionReceipts.qty }).from(productionReceipts)
          .where(and(eq(productionReceipts.clientId, clientId), eq(productionReceipts.productionOrderId, order.id)));
        const alreadyReceived = productionQty(priorReceipts.reduce((n, r) => n + r.qty, 0));
        const remaining = productionQty(order.qty - alreadyReceived);
        ensure(qty <= remaining + 0.0001, `Only ${remaining} ${order.uom} remain on this work order.`);
        const [components, materialIssues] = await sequential([
          tx.select().from(billOfMaterials).where(and(eq(billOfMaterials.clientId, clientId),
            eq(billOfMaterials.parentItemCode, order.itemCode), eq(billOfMaterials.active, true))),
          tx.select().from(productionIssues).where(and(eq(productionIssues.clientId, clientId),
            eq(productionIssues.productionOrderId, order.id))),
        ]);
        ensure(components.length > 0, 'This order has no approved BOM. Review the work order before receiving output.');
        for (const component of components) {
          const issuedQty = productionQty(materialIssues.filter((i) => i.itemCode === component.componentItemCode)
            .reduce((n, i) => n + i.qty, 0));
          const minimum = productionQty((alreadyReceived + qty) * component.qtyPerUnit);
          ensure(issuedQty + 0.0001 >= minimum,
            `${component.componentItemCode}: ${issuedQty} ${component.uom} issued supports less than ${alreadyReceived + qty} ${order.uom} output (minimum ${minimum}). Issue approved BOM materials first.`);
        }
        const wipLines = await tx.select({ date: journalLines.date, debit: journalLines.debit, credit: journalLines.credit })
          .from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.reference, order.docNo),
            eq(journalLines.accountNo, '122000'), lte(journalLines.date, date)));
        const wip = wipFromLines(wipLines);
        const cost = finishedReceiptCost(wip, qty, remaining);
        const finished = await stockFor(order.itemCode);
        ensure(finished.category.toLowerCase().includes('finished') && finished.glAccount === '121000',
          'The output item must be Finished Goods assigned to GL 121000.');
        const nextItem = receiveFinishedItem(itemOf(finished), qty, cost);
        const docNo = `PROD-FG-${requestKey}`;
        const base = { clientId, docNo, date, currency: entity.currency, maker: user.username, costCenter: order.costCenter, reference: order.docNo };
        const lines = [journalLine(base, '121000', await coaName('121000'), cost, 0, `Finished goods ${order.itemCode} from ${order.docNo}`),
          journalLine(base, '122000', await coaName('122000'), 0, cost, `WIP relieved to finished goods ${order.docNo}`)];
        await postJournal(tx, user, entity, lines);
        const movementId = randomUUID();
        await tx.update(stockItems).set({ quantityOnHand: nextItem.quantityOnHand, totalValue: nextItem.totalValue,
          unitCost: nextItem.unitCost }).where(eq(stockItems.id, finished.id));
        await tx.insert(stockMovements).values({ id: movementId, clientId, date, itemCode: finished.itemCode, description: finished.description,
          type: 'Receipt', quantity: qty, unitCost: productionMoney(cost / qty), totalValue: cost, uom: finished.uom,
          docNo, reference: order.docNo, note: 'Production finished-goods receipt' });
        const [receipt] = await tx.insert(productionReceipts).values({ id: requestKey, clientId, productionOrderId: order.id,
          itemCode: finished.itemCode, itemDescription: finished.description, qty, uom: finished.uom, unitCost: productionMoney(cost / qty),
          totalCost: cost, receivedAt: date, receivedBy: user.username, stockMovementId: movementId }).returning();
        const completed = remaining - qty <= 0.0001;
        await tx.update(productionOrders).set({ status: completed ? 'Completed' : 'In Production',
          endDate: completed ? date : null, totalCost: productionMoney(order.totalCost) }).where(eq(productionOrders.id, order.id));
        await audit(order.docNo, `${qty} ${finished.uom} ${finished.itemCode} from WIP; ${cost.toFixed(2)} ${entity.currency}; journal ${docNo}.`);
        return { ok: true, receipt, docNo, completed };
      }
      throw new ProductionError('Unsupported production action.', 400);
    });
    return Response.json(result, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    if (error instanceof ProductionError) return Response.json({ ok: false, error: error.message }, { status: error.status });
    const reference = randomUUID();
    console.error(`[production:${reference}]`, error);
    return Response.json({ ok: false, error: `Production action failed without posting. Support reference: ${reference}.` }, { status: 503 });
  }
}
