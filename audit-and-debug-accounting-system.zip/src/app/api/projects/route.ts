import { randomUUID } from 'node:crypto';
import { and, eq, sql } from 'drizzle-orm';
import { db } from '@/db';
import { ensureDatabaseReady } from '@/db/bootstrap';
import { chartAccounts, clients, entityWorkbooks, journalHeaders, journalLines } from '@/db/schema';
import { getSessionUser, hasFirmWideScope } from '@/lib/auth';
import { maySeeSection } from '@/utils/access';
import { readJsonBody } from '@/lib/http';
import { postEntityJournal } from '@/lib/entityPosting';
import { isValidIsoDate } from '@/lib/journalValidation';
import { journalContentHash } from '@/lib/journalPosting';
import { normaliseProjects } from '@/utils/projectCosting';
import type { ACDOCALine, ClientEntity } from '@/types/accounting';
export const dynamic = 'force-dynamic';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const cents = (n: number) => Math.round(n * 100);

/** Controlled project cost allocation and WIP release. No free-text journal amounts. */
export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return Response.json({ ok: false, error: 'Sign in first.' }, { status: 401 });
    const body = await readJsonBody<{ clientId?: unknown; projectId?: unknown; action?: unknown; amount?: unknown; date?: unknown; sourceDocNo?: unknown; accountNo?: unknown; reason?: unknown; requestKey?: unknown }>(req, 16384);
    const clientId = Number(body.clientId);
    if (!Number.isInteger(clientId) || clientId <= 0) return Response.json({ ok: false, error: 'Valid entity required.' }, { status: 400 });
    if (!hasFirmWideScope(user) && user.clientId !== clientId) return Response.json({ ok: false, error: 'Entity not assigned.' }, { status: 403 });
    if (user.status !== 'active' || user.role === 'auditor' || user.permissions?.canPostJournals === false) return Response.json({ ok: false, error: 'No posting authority.' }, { status: 403 });
    const amount = Number(body.amount), date = String(body.date || ''), reason = String(body.reason || '').trim().slice(0, 220), requestKey = String(body.requestKey || '');
    if (!Number.isFinite(amount) || amount <= 0 || amount > 1e9 || Math.abs(cents(amount) - amount * 100) > 1e-5 || !isValidIsoDate(date) || reason.length < 10 || !UUID.test(requestKey)) {
      return Response.json({ ok: false, error: 'Positive cents-precise amount, valid date, UUID request key and a reason of at least 10 characters are required.' }, { status: 400 });
    }
    if (!['allocate', 'release_wip'].includes(String(body.action))) return Response.json({ ok: false, error: 'Unknown project action.' }, { status: 400 });
    const entity = (await db.select().from(clients).where(eq(clients.id, clientId)).limit(1))[0];
    if (!entity) return Response.json({ ok: false, error: 'Entity not found.' }, { status: 404 });
    if (!maySeeSection(user, entity as ClientEntity, 'project_costing')) return Response.json({ ok: false, error: 'Project costing is not enabled.' }, { status: 403 });
    const result = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(4027332)`);
      const workbook = (await tx.select().from(entityWorkbooks).where(eq(entityWorkbooks.id, `${clientId}:project_costing:register`)).limit(1))[0];
      const project = normaliseProjects(workbook?.payload).find((p) => p.id === body.projectId);
      if (!project) throw new Error('Save the project before posting costs.');
      if (project.status !== 'Active') throw new Error('Reopen the project before posting new costs.');
      const action = String(body.action), docNo = `PRJ-${action === 'allocate' ? 'COST' : 'REL'}-${requestKey}`;
      const value = cents(amount) / 100;
      let debit: string, credit: string, sourceDocNo = '';
      if (action === 'allocate') {
        sourceDocNo = String(body.sourceDocNo || '').trim(); credit = String(body.accountNo || '').trim(); debit = '122000';
        if (!/^[A-Za-z0-9._/-]{3,100}$/.test(sourceDocNo) || !/^\d{4,8}$/.test(credit)) throw new Error('Select a posted source expense document and account.');
        const source = await tx.select().from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.docNo, sourceDocNo), eq(journalLines.accountNo, credit)));
        const account = (await tx.select().from(chartAccounts).where(and(eq(chartAccounts.accountNo, credit), sql`${chartAccounts.clientId} is null or ${chartAccounts.clientId} = ${clientId}`)))[0];
        if (!source.length || account?.type !== 'Expense' || source.some((l) => l.currency !== entity.currency || l.date > date)) throw new Error('Source must be an active expense posted in this entity/currency no later than the allocation date.');
        const sourceBalance = source.reduce((s, l) => s + cents(l.debit) - cents(l.credit), 0);
        const previous = await tx.select().from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.accountNo, credit), eq(journalLines.module, 'PC')));
        const allocated = previous.filter((l) => l.description.includes(`[${sourceDocNo}]`)).reduce((s, l) => s + cents(l.credit) - cents(l.debit), 0);
        if (cents(amount) > sourceBalance - allocated) throw new Error('Allocation exceeds the unallocated balance of the posted source expense.');
      } else {
        debit = '504000'; credit = '122000';
        const wip = await tx.select().from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.accountNo, '122000'), eq(journalLines.costCenter, project.costCenter)));
        if (cents(amount) > wip.reduce((s, l) => s + cents(l.debit) - cents(l.credit), 0)) throw new Error('Release exceeds the project WIP balance.');
      }
      const coa = await tx.select().from(chartAccounts);
      const name = (no: string) => coa.find((a) => a.accountNo === no && a.clientId === clientId)?.name || coa.find((a) => a.accountNo === no && a.clientId === null)?.name || no;
      const base = { clientId, docNo, date, period: date.slice(0, 7), module: 'PC' as const, docType: 'JE' as const, currency: entity.currency,
        createdBy: user.username, costCenter: project.costCenter, reference: project.code };
      const description = action === 'allocate' ? `PROJECT-COST [${sourceDocNo}] ${project.code}: ${reason}` : `PROJECT-RELEASE ${project.code}: ${reason}`;
      const lines: ACDOCALine[] = [
        { ...base, id: randomUUID(), accountNo: debit, accountName: name(debit), debit: value, credit: 0, description },
        { ...base, id: randomUUID(), accountNo: credit, accountName: name(credit), debit: 0, credit: value, description },
      ];
      const old = (await tx.select().from(journalHeaders).where(and(eq(journalHeaders.clientId, clientId), eq(journalHeaders.docNo, docNo))).limit(1))[0];
      if (old) {
        if (old.contentHash !== journalContentHash(lines.map((l) => ({ ...l, id: '' })))) {
          // IDs are generated per retry; compare accounting content, not transport UUIDs.
          const prior = await tx.select().from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.docNo, docNo)));
          const fingerprint = (rows: { accountNo: string; debit: number; credit: number; date: string; costCenter?: string | null; description: string }[]) => JSON.stringify(rows.map((l) => [l.accountNo, cents(l.debit), cents(l.credit), l.date, l.costCenter ?? null, l.description]).sort());
          if (fingerprint(prior) !== fingerprint(lines)) throw new Error('Request key was already used for a different project movement.');
        }
        return { ok: true, idempotent: true, docNo };
      }
      await postEntityJournal(tx, user, entity, lines, action === 'allocate' ? 'PROJECT_COST_ALLOCATED' : 'PROJECT_WIP_RELEASED');
      return { ok: true, docNo, amount: value, idempotent: false };
    });
    return Response.json(result, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Project movement failed.';
    const controlled = /closed|maker|permission|exceeds|Source|Save the|project|Project|Select a|Request key|account|balanced|decimal|Reopen/i.test(message);
    if (!controlled) console.error('project posting failed', error);
    return Response.json({ ok: false, error: controlled ? message : 'Project movement was not committed. Retry with the same request key.' }, { status: controlled ? 409 : 503 });
  }
}
