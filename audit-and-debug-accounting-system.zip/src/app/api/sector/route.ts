import { randomUUID, createHash } from 'node:crypto';
import { and, eq, sql } from 'drizzle-orm';
import { db } from '@/db';
import { ensureDatabaseReady } from '@/db/bootstrap';
import { chartAccounts, clients, entityWorkbooks, journalHeaders } from '@/db/schema';
import { getSessionUser, hasFirmWideScope } from '@/lib/auth';
import { maySeeSection } from '@/utils/access';
import { readJsonBody } from '@/lib/http';
import { postEntityJournal } from '@/lib/entityPosting';
import { computeSector, type SectorInput, type SectorDomain } from '@/lib/regulated/engines';
import { sectorDomains } from '@/lib/regulated/access';
import type { ACDOCALine, ClientEntity } from '@/types/accounting';
export const dynamic='force-dynamic';
const DOMAINS=new Set(['mining','petroleum','insurance','financial','pension','agriculture','manufacturing']);
const KEY=/^[A-Za-z0-9._:-]{1,80}$/;
const hash=(v:unknown)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const reply=(body:unknown,status=200)=>Response.json(body,{status,headers:{'cache-control':'no-store'}});

export async function POST(req:Request){
 try{
  await ensureDatabaseReady(); const user=await getSessionUser(req);if(!user)return reply({ok:false,error:'Sign in first.'},401);
  const body=await readJsonBody<{action?:unknown;clientId?:unknown;key?:unknown;input?:SectorInput}>(req,1_000_000);
  const clientId=Number(body.clientId),key=String(body.key||''),action=String(body.action||'');
  if(!Number.isInteger(clientId)||clientId<=0||!KEY.test(key)||!['preview','post'].includes(action))return reply({ok:false,error:'Valid entity, measurement key and action are required.'},400);
  if(!hasFirmWideScope(user)&&user.clientId!==clientId)return reply({ok:false,error:'Entity not assigned.'},403);
  if(user.status!=='active'||user.role==='auditor'||user.permissions?.canPostJournals===false)return reply({ok:false,error:'No sector measurement authority.'},403);
  const entity=(await db.select().from(clients).where(eq(clients.id,clientId)).limit(1))[0];if(!entity)return reply({ok:false,error:'Entity not found.'},404);
  if(!maySeeSection(user,entity as ClientEntity,'sector_regulation'))return reply({ok:false,error:'Regulated-sector desk is not enabled.'},403);
  const id=`${clientId}:sector_measurement:${key}`;
  let input:SectorInput;
  if(action==='preview'){
   input=body.input as SectorInput;
   if(!input||!DOMAINS.has(input.domain))return reply({ok:false,error:'Unsupported measurement domain.'},400);
  }else{
   const wb=(await db.select().from(entityWorkbooks).where(and(eq(entityWorkbooks.id,id),eq(entityWorkbooks.clientId,clientId))).limit(1))[0];
   if(!wb||wb.status!=='approved'||!wb.approvedBy)return reply({ok:false,error:'Save, submit and independently approve this measurement before posting.'},409);
   input=(wb.payload as {input?:SectorInput})?.input as SectorInput;
   if(!input)return reply({ok:false,error:'Approved measurement inputs are missing.'},409);
  }
  if(!sectorDomains(entity.sector).includes(input.domain as SectorDomain))return reply({ok:false,error:'This calculation does not match the entity’s registered sector. Re-classify the entity through the owner workflow first.'},403);
  const measurement=computeSector(input);
  if(action==='preview')return reply({ok:true,measurement,inputHash:hash(input)});
  const committed = await db.transaction(async tx=>{
   await tx.execute(sql`select pg_advisory_xact_lock(4027332)`);
   // Lock and re-check approval under the posting lock.
   const wb=(await tx.select().from(entityWorkbooks).where(eq(entityWorkbooks.id,id)).for('update').limit(1))[0];
   if(!wb||wb.status!=='approved'||hash((wb.payload as {input:SectorInput}).input)!==hash(input))throw new Error('Approved measurement changed; recompute and reapprove.');
   if(['pension','manufacturing'].includes(input.domain))throw new Error('This domain produces a reviewed working paper only. Post through its mapped operational subledger after specialist review.');
   if(!measurement.legs.length)return {ok:true,idempotent:true,message:'No accounting movement is required.'};
   const docNo=`SEC-${input.domain.toUpperCase()}-${key}`.slice(0,100);
   const old=(await tx.select().from(journalHeaders).where(and(eq(journalHeaders.clientId,clientId),eq(journalHeaders.docNo,docNo))).limit(1))[0];
   if(old)return {ok:true,idempotent:true,docNo};
   const coa=await tx.select().from(chartAccounts);
   const base={clientId,docNo,date:input.asAt,period:input.asAt.slice(0,7),module:'FI' as const,docType:'STAT' as const,currency:entity.currency,createdBy:wb.preparedBy||user.username,checkedBy:wb.approvedBy&&wb.approvedBy!==wb.preparedBy?wb.approvedBy:undefined,costCenter:'CC-ADM',reference:`SECTOR:${key}`};
   const lines:ACDOCALine[]=measurement.legs.map(l=>({...base,id:randomUUID(),accountNo:l.accountNo,accountName:coa.find(a=>a.accountNo===l.accountNo&&a.clientId===clientId)?.name||coa.find(a=>a.accountNo===l.accountNo&&a.clientId===null)?.name||l.label,debit:l.debit,credit:l.credit,description:`${measurement.title} [${key}] ${l.label}; source ${input.source.reference}`.slice(0,240)}));
   await postEntityJournal(tx,user,entity,lines,'SECTOR_MEASUREMENT_POSTED');
   return {ok:true,docNo,measurement};
  });
  return reply(committed);
 }catch(error){const message=error instanceof Error?error.message:'Sector calculation failed.';const controlled=/must|requires|not|Not|changed|approve|Save|source|rule|band|scenario|PAA|Stage|Coverage|Costs|Contributions|Enter|Unsupported|closed|maker|permission|account|balance/i.test(message);if(!controlled)console.error('sector measurement failed',error);return reply({ok:false,error:controlled?message:'Measurement was not committed. Retry or contact support.'},controlled?409:503);}
}
