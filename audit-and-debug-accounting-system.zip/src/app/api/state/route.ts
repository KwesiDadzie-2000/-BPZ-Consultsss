import { immutableJournalConflict } from '@/lib/immutableJournal';
import { BODY_LIMITS, RequestBodyError, readJsonBody } from "@/lib/http";
import { sequential } from '@/lib/sequential';
import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import {
  approvalRequests,
  auditLog,
  bankAccounts,
  businessPartners,
  chartAccounts,
  closedPeriods,
  clients,
  companyProfiles,
  disclosureNotes,
  employees,
  journalHeaders,
  journalLines,
  postingEvents,
  payrollRecords,
  prepaymentRecords,
  prepaymentSchedules,
  purchaseOrders,
  salesInvoices,
  stockItems,
  stockMovements,
  fixedAssets,
  taxScheduleEntries,
  users,
} from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope } from "@/lib/auth";
import { validateJournalLines, validateMakerChecker, validatePostingIdentity } from "@/lib/journalValidation";
import { accountPostabilityFor, postingUserDirectory, sessionPostingRecord, validateControlAccountAuthority } from "@/lib/postingControls";
import { buildJournalHeader, buildPostingEvent } from "@/lib/journalPosting";
import { prepareBusinessPartnersForStorage } from "@/lib/businessPartnerSync";
import { missingSnapshotKeys, unchangedSnapshotRows } from "@/lib/stateSnapshotGuard";
import { maySeeSection } from "@/utils/access";
import { and, eq, inArray, sql } from "drizzle-orm";
import type {
  ACDOCALine,
  AccountMaster,
  ApprovalRequest,
  BankAccount,
  BusinessPartner,
  ClientEntity,
  DisclosureNote,
  EmployeeProfile,
  MonthlyPayrollRecord,
  PrepaymentRecord,
  PrepaymentScheduleLine,
  FixedAsset,
  PurchaseOrder,
  SalesInvoice,
  StockItem,
  StockMovement,
  TaxScheduleEntry,
} from "@/types/accounting";
import type { CompanyProfile } from "@/utils/persistentStorage";

export const dynamic = "force-dynamic";

/** Integer id list for a scoped IN (...) clause; ids come from the database. */
function intList(ids: readonly number[]): string {
  if (!ids.length || !ids.every((n) => Number.isSafeInteger(n))) throw new Error("Invalid client scope.");
  return ids.join(",");
}

/** Runs a lookup in parameter-safe chunks (PostgreSQL caps bind parameters at 65,535). */
async function chunked<T>(items: readonly string[], fetch: (chunk: string[]) => Promise<T[]>): Promise<T[]> {
  const out: T[] = [];
  for (let i = 0; i < items.length; i += 5000) out.push(...(await fetch(items.slice(i, i + 5000))));
  return out;
}

interface StatePayload {
  clients?: ClientEntity[];
  journalLines?: ACDOCALine[];
  bankAccounts?: BankAccount[];
  purchaseOrders?: PurchaseOrder[];
  salesInvoices?: SalesInvoice[];
  employees?: EmployeeProfile[];
  businessPartners?: BusinessPartner[];
  payrollRecords?: MonthlyPayrollRecord[];
  prepaymentRecords?: PrepaymentRecord[];
  prepaymentSchedules?: PrepaymentScheduleLine[];
  approvalRequests?: ApprovalRequest[];
  companyProfiles?: Record<number, CompanyProfile>;
  chartOfAccounts?: AccountMaster[];
  disclosureNotes?: DisclosureNote[];
  closedPeriods?: { clientId: number; period: string }[];
  /** Optional (older browsers may not send it); when present it is replaced tenant-scoped. */
  taxScheduleEntries?: TaxScheduleEntry[];
  /** Perpetual inventory + asset register (optional for older browsers). */
  stockItems?: StockItem[];
  stockMovements?: StockMovement[];
  fixedAssets?: FixedAsset[];
}

/**
 * Full-state sync. The server is authoritative: journal lines are validated
 * (tenant, open periods, COA existence, double entry) and the whole write is one
 * transaction. Firm-level masters (clients, COA, disclosures) are owner-writable
 * only; every operational row is tenant-filtered.
 */
export async function PUT(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    // Infrastructure fault → 503. Never 401: a 401 is what signs the user out.
    console.error("state sync: database unavailable", e);
    return authJson(req, { ok: false, error: "database-unavailable" }, { status: 503 });
  }
  try {
    return await handlePut(req);
  } catch (error) {
    const reference = crypto.randomUUID();
    const cause = error instanceof Error ? error.cause : undefined;
    const candidate = error && typeof error === "object" && "code" in error
      ? (error as { code?: unknown }).code
      : cause && typeof cause === "object" && "code" in cause
        ? (cause as { code?: unknown }).code
        : undefined;
    const code = typeof candidate === "string" ? candidate : undefined;
    console.error(`[state-sync:${reference}] ${error instanceof Error ? error.name : "UnknownError"}${code ? ` code=${code}` : ""}`);
    return Response.json({
      ok: false,
      error: `Workspace sync failed. No changes were saved. Retry the sync; if it continues, share reference ${reference}.`,
      reference,
    }, { status: 500 });
  }
}

async function handlePut(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
  if (user.status !== 'active' || user.role === 'auditor') {
    return authJson(req, { ok: false, error: 'This account has read-only access to workspace state.' }, { status: 403 });
  }

  let body: StatePayload;
  try {
    body = await readJsonBody(req, BODY_LIMITS.state);
  } catch (error) {
    if (error instanceof RequestBodyError && error.status === 413) return Response.json({ ok: false, error: error.message }, { status: 413 });
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }

  // Full-state sync contract: partial payloads are rejected so a sync can never
  // silently wipe datasets the caller did not include.
  const coreFields: (keyof StatePayload)[] = [
    "journalLines", "bankAccounts", "purchaseOrders", "salesInvoices", "employees",
    "businessPartners", "payrollRecords", "prepaymentRecords", "prepaymentSchedules",
    "approvalRequests", "closedPeriods", "companyProfiles",
  ];
  if (!body || typeof body !== "object" || coreFields.some((f) => body[f] === undefined)) {
    return Response.json({ ok: false, error: "Partial state sync rejected — send the full workspace state." }, { status: 400 });
  }

  if (!body || typeof body !== 'object' || Array.isArray(body)) return Response.json({ ok: false, error: 'Invalid workspace object.' }, { status: 400 });
  const arrayFields = coreFields.filter((field) => field !== 'companyProfiles');
  if (arrayFields.some((field) => !Array.isArray(body[field])) || !body.companyProfiles || typeof body.companyProfiles !== 'object' || Array.isArray(body.companyProfiles)) {
    return Response.json({ ok: false, error: 'Invalid workspace data types.' }, { status: 400 });
  }
  if (body.journalLines!.some((line) => !line || typeof line.docNo !== 'string' || !line.docNo.trim() || typeof line.id !== 'string')) return Response.json({ ok: false, error: 'Invalid journal identity.' }, { status: 400 });
  const isOwner = user.role === "owner";
  const firmWide = hasFirmWideScope(user);
  const myClientId = user.clientId ?? null;

  // Tenant filter: non-owners may only touch their own entity (or untagged legacy rows).
  const tenantOk = (clientId: number | undefined | null): boolean =>
    firmWide || (myClientId !== null && clientId === myClientId);

  const lines = body.journalLines ?? [];
  const banks = body.bankAccounts ?? [];
  const pos = body.purchaseOrders ?? [];
  const invoices = body.salesInvoices ?? [];
  const emps = body.employees ?? [];
  const partners = body.businessPartners ?? [];
  const partnerPreparation = prepareBusinessPartnersForStorage(partners, firmWide ? null : myClientId);
  if (!partnerPreparation.ok) {
    return Response.json({ ok: false, error: partnerPreparation.error }, { status: partnerPreparation.status });
  }
  const storedPartners = partnerPreparation.rows;
  const payroll = body.payrollRecords ?? [];
  const prepayments = body.prepaymentRecords ?? [];
  const prepaidSchedules = body.prepaymentSchedules ?? [];
  const approvals = body.approvalRequests ?? [];
  const closed = body.closedPeriods ?? [];
  const profiles = body.companyProfiles ?? {};
  const taxEntries = body.taxScheduleEntries;
  const stock = body.stockItems;
  const movements = body.stockMovements;
  const assets = body.fixedAssets;

  if (!firmWide) {
    const rows: (number | undefined | null)[] = [
      ...lines.map((l) => l.clientId),
      ...banks.map((b) => b.clientId),
      ...pos.map((p) => p.clientId),
      ...invoices.map((i) => i.clientId),
      ...emps.map((e) => e.clientId),
      ...partners.map((p) => p.clientId),
      ...payroll.map((r) => r.clientId),
      ...prepayments.map((p) => p.clientId),
      ...prepaidSchedules.map((s) => s.clientId),
      ...approvals.map((a) => a.clientId),
      ...closed.map((c) => c.clientId),
      ...(taxEntries ?? []).map((t) => t.clientId),
      ...(stock ?? []).map((i) => i.clientId),
      ...(movements ?? []).map((m) => m.clientId),
      ...(assets ?? []).map((a) => a.clientId),
    ];
    if (rows.some((id) => !tenantOk(id))) {
      return Response.json({ ok: false, error: "Cross-tenant write rejected." }, { status: 403 });
    }
    if (Object.keys(profiles).some((id) => Number(id) !== myClientId)) {
      return Response.json({ ok: false, error: "Cross-tenant profile write rejected." }, { status: 403 });
    }
  }

  // Journal validation (tenant, periods, COA, double entry).
  const [allClients, allCoa, allClosed, allApprovals, allUsers] = await Promise.all([
    db.select().from(clients),
    db.select().from(chartAccounts),
    db.select().from(closedPeriods),
    db.select().from(approvalRequests),
    db.select().from(users),
  ]);
  const userDirectory = postingUserDirectory(allUsers);
  const allowedClientIds = firmWide ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
  // Periods are frozen per entity — key by client so one entity's close never blocks another.
  const closedKeys = new Set(
    allClosed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`)
  );
  // COA scope: firm master plus the writable entities' custom accounts.
  const coaNos = new Set(allCoa.filter((a) => a.clientId === null || allowedClientIds.includes(a.clientId)).map((a) => a.accountNo));
  // Duplicate document check against the server copy: documents already posted
  // are re-sent unchanged by the full-state sync; a conflict (same document
  // number, different lines) is rejected.
  // Journals are append-only: a sync never deletes or rewrites a posted
  // document, so only the documents IN THIS PAYLOAD are compared. Scanning the
  // whole multi-tenant journal here made every sync cost O(all books).
  const payloadDocNos = [...new Set(lines.map((l) => l.docNo))];
  const serverLines = allowedClientIds.length ? await chunked(payloadDocNos, (chunk) => db.select().from(journalLines)
    .where(and(inArray(journalLines.clientId, allowedClientIds), inArray(journalLines.docNo, chunk)))) : [];
  const existingDocs = new Set(serverLines.map((l) => `${l.clientId}:${l.docNo}`));
  const docs = new Map<string, ACDOCALine[]>();
  for (const l of lines) {
    const key = `${l.clientId}:${l.docNo}`;
    if (!docs.has(key)) docs.set(key, []);
    docs.get(key)!.push(l);
  }
  const recentCash = { rows: allowedClientIds.length ? (await db.execute<{ bank_account_id: number }>(sql`select distinct bank_account_id from trade_cash_movements
    where created_at > now() - interval '30 seconds' and client_id in (${sql.raw(intList(allowedClientIds))})`)).rows : [] };
  // Treasury: a cash movement posted by the trade engine in the last 30 s may
  // not be in the browser copy yet — keep the server balance for that account.
  if (recentCash.rows.length) {
    const serverBanks = await db.select().from(bankAccounts);
    for (const r of recentCash.rows) {
      const server = serverBanks.find((b) => b.id === r.bank_account_id);
      const idx = banks.findIndex((b) => b.id === r.bank_account_id);
      if (server && idx >= 0) banks[idx] = { ...banks[idx], balance: server.balance };
    }
  }
  const warnings: string[] = [];
  const immutableError = immutableJournalConflict(serverLines, lines);
  if (immutableError) return Response.json({ ok: false, error: immutableError }, { status: 409 });

  // Journal validation applies to NEW documents only — re-sent documents are
  // already in the books, so closing one of their periods afterwards must not
  // block the workspace sync (which would make the period impossible to reopen).
  let freshKeys = new Set([...docs.keys()].filter((key) => !existingDocs.has(key)));
  const freshLines = lines.filter((l) => freshKeys.has(`${l.clientId}:${l.docNo}`));
  // An empty journal list is valid for the full-state sync (nothing to validate) —
  // "no lines" is only an error for single-document posting.
  // New documents arriving through the workspace sync face exactly the same
  // controls as single-document posting: identity binding (maker or named
  // checker must be the signed-in user), document integrity, and the maker's
  // own limit with an independent, authorised checker above it.
  const identityError = freshLines.length
    ? validatePostingIdentity(freshLines, { session: sessionPostingRecord(user), users: userDirectory })
    : null;
  if (identityError) return authJson(req, { ok: false, error: identityError }, { status: 403 });
  const journalError = freshLines.length
    ? validateJournalLines(freshLines, { allowedClientIds, closedPeriodKeys: closedKeys, coaAccountNos: coaNos, isAccountPostable: accountPostabilityFor(allCoa) })
    : null;
  if (journalError) return Response.json({ ok: false, error: journalError }, { status: 409 });
  const sodError = freshLines.length
    ? validateMakerChecker(freshLines, { username: user.username, makerLimit: user.makerLimit, users: userDirectory })
    : null;
  if (sodError) return Response.json({ ok: false, error: sodError }, { status: 409 });

  let transactionError: string | null = null;
  let transactionStatus: 403 | 409 = 409;
  await db.transaction(async (tx) => {
    // Serialize full-state replacements so concurrent browser tabs cannot interleave deletes and inserts.
    await tx.execute(sql`select pg_advisory_xact_lock(4027332)`);
    // Operational tables: tenant-scoped replace. The owner syncs the whole
    // workspace, so their replace clears the entire table first — legacy rows
    // outside the current client list must never survive to cause key collisions.
    const writableIds = firmWide ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
    const insertInBatches = async (table: any, rows: any[]) => {
      const batchSize = 250;
      for (let start = 0; start < rows.length; start += batchSize) {
        await tx.insert(table).values(rows.slice(start, start + batchSize));
      }
    };
    const replace = async (table: any, rows: any[], mapRow: (r: any) => Record<string, unknown>) => {
      if (isOwner) {
        await tx.delete(table);
      } else if (writableIds.length) {
        await tx.delete(table).where(inArray(table.clientId, writableIds));
      }
      if (rows.length) await insertInBatches(table, rows.map(mapRow));
    }; 

    // Recheck under the same lock as /api/journal. Missing browser records are
    // retained; neither posted lines nor their headers are ever replaced.
    const [latestCoa, latestClosed, latestUsers] = await sequential([
      tx.select().from(chartAccounts), tx.select().from(closedPeriods), tx.select().from(users),
    ]);
    const latestLines = allowedClientIds.length ? await chunked(payloadDocNos, (chunk) => tx.select().from(journalLines)
      .where(and(inArray(journalLines.clientId, allowedClientIds), inArray(journalLines.docNo, chunk)))) : [];
    // Production and trade stock movements are written on the server with their
    // journals. A stale browser tab must not overwrite them: under the shared
    // posting lock, carry forward any the payload omits and adopt the server row.
    if (movements && stock && allowedClientIds.length) {
      const scope = sql.raw(intList(allowedClientIds));
      const serverOwned = await tx.execute<{ id: string; client_id: number; date: string; item_code: string; description: string; type: string;
        quantity: number; unit_cost: number; total_value: number; uom: string; reference: string | null; doc_no: string | null; note: string | null }>(sql`
        select m.* from stock_movements m where m.client_id in (${scope}) and (
          m.id in (select stock_movement_id from production_issues where client_id in (${scope})
                   union all select stock_movement_id from production_receipts where client_id in (${scope}))
          or exists (select 1 from trade_documents d where d.client_id = m.client_id and d.doc_no = m.doc_no))`);
      const supplied = new Set(movements.map((m) => m.id));
      const affected = new Set<string>();
      for (const m of serverOwned.rows) {
        if (supplied.has(m.id)) continue;
        movements.push({ id: m.id, clientId: m.client_id, date: m.date, itemCode: m.item_code, description: m.description,
          type: m.type as StockMovement['type'], quantity: Number(m.quantity), unitCost: Number(m.unit_cost), totalValue: Number(m.total_value),
          uom: m.uom, reference: m.reference ?? undefined, docNo: m.doc_no ?? undefined, note: m.note ?? undefined });
        affected.add(`${m.client_id}:${m.item_code}`);
      }
      if (affected.size) {
        const latestItems = await tx.select().from(stockItems).where(inArray(stockItems.clientId, allowedClientIds));
        for (const identifier of affected) {
          const row = latestItems.find((i) => `${i.clientId}:${i.itemCode}` === identifier);
          if (!row) { transactionError = `A posted production/trade movement has no item master (${identifier}). Sync refused.`; return; }
          const canonical: StockItem = { id: row.id, clientId: row.clientId, itemCode: row.itemCode,
            description: row.description, category: row.category, uom: row.uom, quantityOnHand: row.quantityOnHand,
            unitCost: row.unitCost, totalValue: row.totalValue, reorderLevel: row.reorderLevel ?? undefined,
            location: row.location ?? undefined, glAccount: row.glAccount ?? undefined,
            costMethod: (row.costMethod ?? 'weighted_average') as StockItem['costMethod'],
            netRealisableValue: row.netRealisableValue ?? undefined };
          const at = stock.findIndex((i) => `${i.clientId}:${i.itemCode}` === identifier);
          if (at === -1) stock.push(canonical); else stock[at] = canonical;
        }
      }
    }
    // A full browser snapshot is not a grant to edit every register. Compare the
    // incoming snapshot with live rows UNDER THE POSTING LOCK before replacing
    // anything; otherwise a sales-only client can change company bank details or
    // payroll through a direct PUT. Missing rows from a stale tab are conflicts,
    // not implicit delete requests (deletions need a separate audited API).
    const latestClients = await tx.select().from(clients);
    const liveIds = isOwner ? latestClients.map((c) => c.id) : writableIds;
    const scopedClients = latestClients.filter((c) => liveIds.includes(c.id));
    const [liveBanks, liveOrders, liveInvoices, liveEmployees, livePartners, livePayroll,
      livePrepayments, liveSchedules, liveApprovals, liveProfiles, liveAssets,
      liveTax, liveStock, liveMovements] = await sequential([
      tx.select().from(bankAccounts).where(inArray(bankAccounts.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(purchaseOrders).where(inArray(purchaseOrders.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(salesInvoices).where(inArray(salesInvoices.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(employees).where(inArray(employees.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(businessPartners).where(inArray(businessPartners.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(payrollRecords).where(inArray(payrollRecords.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(prepaymentRecords).where(inArray(prepaymentRecords.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(prepaymentSchedules).where(inArray(prepaymentSchedules.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(approvalRequests).where(inArray(approvalRequests.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(companyProfiles).where(inArray(companyProfiles.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(fixedAssets).where(inArray(fixedAssets.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(taxScheduleEntries).where(inArray(taxScheduleEntries.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(stockItems).where(inArray(stockItems.clientId, liveIds.length ? liveIds : [-1])),
      tx.select().from(stockMovements).where(inArray(stockMovements.clientId, liveIds.length ? liveIds : [-1])),
    ]);
    type SnapRow = Record<string, unknown>;
    const asRows = (input: readonly unknown[]): SnapRow[] => input as SnapRow[];
    const checkCollection = (
      name: string,
      incoming: readonly unknown[],
      stored: readonly unknown[],
      sections: string[],
      keyOf?: (row: SnapRow) => string,
    ) => {
      if (transactionError) return;
      const nextRows = asRows(incoming);
      const oldRows = asRows(stored);
      const missing = missingSnapshotKeys(nextRows, oldRows, keyOf);
      if (missing.length) {
        transactionError = `${name} changed since this tab loaded. Reload the workspace; a snapshot cannot delete existing records (${missing.length} omitted).`;
        return;
      }
      if (isOwner) return;
      for (const c of scopedClients) {
        if (sections.some((s) => maySeeSection(user, c as ClientEntity, s))) continue;
        const mine = (r: SnapRow) => Number(r.clientId) === c.id;
        if (!unchangedSnapshotRows(nextRows.filter(mine), oldRows.filter(mine), keyOf)) {
          transactionError = `You do not have permission to change ${name} for ${c.code}.`;
          transactionStatus = 403;
          return;
        }
      }
    };
    if (body.clients) checkCollection('client workspaces', body.clients.filter((c) => liveIds.includes(c.id)), scopedClients, []);
    checkCollection('treasury accounts', banks, liveBanks, ['banking', 'payment_desk']);
    checkCollection('purchase orders', pos, liveOrders, ['procurement', 'payment_desk']);
    checkCollection('sales invoices', invoices, liveInvoices, ['sales', 'payment_desk']);
    checkCollection('employees', emps, liveEmployees, ['payroll', 'hr_desk', 'hr_employees']);
    checkCollection('business partners', storedPartners, livePartners, ['business_partners_crm', 'crm_desk']);
    checkCollection('payroll records', payroll, livePayroll.map((r) => r.record), ['payroll']);
    checkCollection('prepayment records', prepayments, livePrepayments.map((r) => r.record), ['prepayments']);
    checkCollection('prepayment schedules', prepaidSchedules, liveSchedules.map((r) => r.line), ['prepayments']);
    checkCollection('approval requests', approvals, liveApprovals, ['procurement', 'sales', 'payment_desk', 'universal_journal', 'expenses', 'ifrs_desk']);
    checkCollection('legal profiles and settlement instructions', Object.values(profiles), liveProfiles, [] , (r) => String(r.clientId));
    if (taxEntries) checkCollection('tax schedules', taxEntries, liveTax, ['tax_schedule']);
    if (stock) checkCollection('stock items', stock, liveStock, ['inventory', 'inventory_ledger', 'procurement', 'sales', 'production_desk']);
    if (movements) checkCollection('stock movement history', movements, liveMovements, ['inventory_ledger', 'procurement', 'sales', 'production_desk']);
    if (assets) checkCollection('fixed asset register', assets, liveAssets, ['assets', 'ifrs_desk']);
    if (body.chartOfAccounts && !isOwner && !(user.role === 'manager' && user.permissions?.canModifyCOA === true && scopedClients.every((c) => maySeeSection(user, c as ClientEntity, 'coa_master')))) {
      const visibleChart = latestCoa.filter((a) => a.clientId === null || liveIds.includes(a.clientId));
      if (!unchangedSnapshotRows(asRows(body.chartOfAccounts), asRows(visibleChart), (r) => `${r.clientId ?? 'firm'}:${r.accountNo}`)) {
        transactionError = 'Only an authorised chart-of-accounts manager may change GL master data.';
        transactionStatus = 403;
      }
    }
    if (body.disclosureNotes && !isOwner) {
      const liveNotes = await tx.select().from(disclosureNotes);
      const comparable = liveNotes.map(({ id, ...row }) => row);
      if (!unchangedSnapshotRows(asRows(body.disclosureNotes), asRows(comparable), (r) => String(r.key))) {
        transactionError = 'Only the firm owner may edit disclosure-note templates.';
        transactionStatus = 403;
      }
    }
    if (transactionError) return;

    transactionError = immutableJournalConflict(latestLines, lines);
    if (transactionError) return;
    const latestKeys = new Set(latestLines.map((line) => `${line.clientId}:${line.docNo}`));
    freshKeys = new Set([...docs.keys()].filter((key) => !latestKeys.has(key)));
    const newLines = lines.filter((line) => freshKeys.has(`${line.clientId}:${line.docNo}`));
    const latestDirectory = postingUserDirectory(latestUsers);
    const controlError = validateControlAccountAuthority(newLines, user.role);
    if (controlError) { transactionError = controlError; transactionStatus = 403; return; }
    if (newLines.some((l) => l.module === 'PC')) {
      transactionError = 'Project cost allocations and WIP releases must use the Project Costing desk so source balances are validated.';
      transactionStatus = 403; return;
    }
    const freshDebt = newLines.filter((l) => l.accountNo === '213000');
    if (freshDebt.some((l) => !['PAY', 'REV'].includes(l.docType))) {
      transactionError = 'Debt-service payables must be accrued through Loan Amortisation; corrections use reversal.';
      transactionStatus = 403; return;
    }
    if (freshDebt.some((l) => l.docType === 'PAY') && !isOwner &&
      (user.permissions?.canApprovePayments === false || (Array.isArray(user.permissions?.allowedModules) && !user.permissions.allowedModules.includes('payment_desk')))) {
      transactionError = 'Debt settlement requires Payment Desk access and payment authority.';
      transactionStatus = 403; return;
    }
    if (newLines.length) {
      transactionError = validateJournalLines(newLines, {
        allowedClientIds, closedPeriodKeys: new Set(latestClosed.map((row) => `${row.clientId}:${row.period}`)),
        coaAccountNos: new Set(latestCoa.map((row) => row.accountNo)), isAccountPostable: accountPostabilityFor(latestCoa),
      }) || validatePostingIdentity(newLines, { session: sessionPostingRecord(user), users: latestDirectory })
        || validateMakerChecker(newLines, { username: user.username, makerLimit: user.makerLimit, users: latestDirectory });
      if (transactionError) return;
      const taken = await chunked(newLines.map((line) => line.id), (chunk) =>
        tx.select({ id: journalLines.id }).from(journalLines).where(inArray(journalLines.id, chunk)));
      if (taken.length) { transactionError = 'Journal line id already exists.'; return; }
    }

    // Server-side working-balance authority: bank balances, invoice/PO settlements,
    // and inventory valuation cannot drift from the posted general ledger.
    const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
    for (const p of pos) {
      const paid = p.paidAmount ?? 0;
      if (!Number.isFinite(p.qty) || p.qty <= 0 || !Number.isFinite(p.unitPrice) || p.unitPrice < 0 || !Number.isFinite(p.totalAmount) || p.totalAmount < 0 || !Number.isFinite(paid) || paid < -0.001 || paid > p.totalAmount + 0.01) {
        transactionError = `Purchase order ${p.poNo} has invalid quantities or settlement amounts.`; return;
      }
      if (p.status === 'Paid' && paid + 0.009 < p.totalAmount) {
        transactionError = `Purchase order ${p.poNo} cannot be marked Paid while an unpaid balance remains.`; return;
      }
    }
    for (const inv of invoices) {
      if (!Number.isFinite(inv.totalReceivable) || inv.totalReceivable < 0 || !Number.isFinite(inv.paidAmount) || inv.paidAmount < -0.001 || inv.paidAmount > inv.totalReceivable + 0.01) {
        transactionError = `Sales invoice ${inv.invNo} has invalid receivable or settlement amounts.`; return;
      }
      if (inv.status === 'Paid' && inv.paidAmount + 0.009 < inv.totalReceivable) {
        transactionError = `Sales invoice ${inv.invNo} cannot be marked Paid while an unpaid balance remains.`; return;
      }
    }
    if (stock) {
      for (const item of stock) {
        if (!Number.isFinite(item.quantityOnHand) || item.quantityOnHand < -0.0001 || !Number.isFinite(item.totalValue) || item.totalValue < -0.01) {
          transactionError = `Inventory item ${item.itemCode} cannot have negative quantity or carrying value.`; return;
        }
      }
    }

    if (writableIds.length) {
      const [prevBanks, prevPOs, prevInvoices, prevStock] = await sequential([
        tx.select().from(bankAccounts).where(inArray(bankAccounts.clientId, writableIds)),
        tx.select().from(purchaseOrders).where(inArray(purchaseOrders.clientId, writableIds)),
        tx.select().from(salesInvoices).where(inArray(salesInvoices.clientId, writableIds)),
        stock ? tx.select().from(stockItems).where(inArray(stockItems.clientId, writableIds)) : Promise.resolve([]),
      ]);

      const banksChanged =
        prevBanks.length !== banks.length ||
        banks.some((b) => {
          const prev = prevBanks.find((p) => p.id === b.id);
          return !prev || prev.clientId !== (b.clientId ?? 0) || Math.abs(prev.balance - b.balance) > 0.009 || (prev.glAccount ?? '100000') !== (b.glAccount ?? '100000') || prev.currency !== b.currency;
        });
      const posChanged = pos.some((p) => Math.abs((p.paidAmount ?? 0) - (prevPOs.find((old) => old.id === p.id)?.paidAmount ?? 0)) >= 0.01);
      const invsChanged = invoices.some((i) => Math.abs(i.paidAmount - (prevInvoices.find((old) => old.id === i.id)?.paidAmount ?? 0)) >= 0.01);
      // Per-document settlement is essential. Two invoices can exchange 100 in
      // paidAmount without changing the AR total, bypassing aggregate checks.
      // Each increase must be evidenced by a posted payment referencing that
      // SAME document. Decreases require an explicit reversing allocation API.
      if (posChanged || invsChanged) {
        for (const po of pos) {
          const prior = prevPOs.find((old) => old.id === po.id);
          const oldPaid = prior?.paidAmount ?? 0;
          const nextPaid = po.paidAmount ?? 0;
          if (Math.abs(nextPaid - oldPaid) < 0.01) continue;
          if (nextPaid < oldPaid - 0.01) {
            transactionError = `Purchase order ${po.poNo}: a payment cannot be removed by a browser snapshot. Reverse it through an audited settlement workflow.`;
            return;
          }
          const dbMatch = await tx.execute<{ settled: number }>(sql`
            select coalesce(sum(debit - credit), 0) as settled from journal_lines
            where client_id = ${po.clientId} and account_no = '200000' and doc_type = 'PAY'
              and (position(${po.poNo} in description) > 0 or reference = ${po.poNo})
          `);
          const pending = newLines.filter((l) => l.clientId === po.clientId && l.accountNo === '200000' && l.docType === 'PAY' && (l.reference === po.poNo || l.description.includes(po.poNo)))
            .reduce((s, l) => s + l.debit - l.credit, 0);
          if (nextPaid > Number(dbMatch.rows[0]?.settled ?? 0) + pending + 0.02) {
            transactionError = `Purchase order ${po.poNo} has no matching posted supplier-payment journal for its settlement.`;
            return;
          }
        }
        for (const inv of invoices) {
          const prior = prevInvoices.find((old) => old.id === inv.id);
          const oldPaid = prior?.paidAmount ?? 0;
          if (Math.abs(inv.paidAmount - oldPaid) < 0.01) continue;
          if (inv.paidAmount < oldPaid - 0.01) {
            transactionError = `Sales invoice ${inv.invNo}: a receipt cannot be removed by a browser snapshot. Reverse it through an audited settlement workflow.`;
            return;
          }
          const dbMatch = await tx.execute<{ settled: number }>(sql`
            select coalesce(sum(credit - debit), 0) as settled from journal_lines
            where client_id = ${inv.clientId} and account_no = '110000' and doc_type = 'PAY'
              and (position(${inv.invNo} in description) > 0 or reference = ${inv.invNo})
          `);
          const pending = newLines.filter((l) => l.clientId === inv.clientId && l.accountNo === '110000' && l.docType === 'PAY' && (l.reference === inv.invNo || l.description.includes(inv.invNo)))
            .reduce((s, l) => s + l.credit - l.debit, 0);
          if (inv.paidAmount > Number(dbMatch.rows[0]?.settled ?? 0) + pending + 0.02) {
            transactionError = `Sales invoice ${inv.invNo} has no matching posted customer-receipt journal for its settlement.`;
            return;
          }
        }
      }
      const stockChanged = Boolean(stock && writableIds.some((cid) => {
        const pVal = prevStock.filter((i) => i.clientId === cid).reduce((s, i) => s + i.totalValue, 0);
        const nVal = stock.filter((i) => i.clientId === cid).reduce((s, i) => s + i.totalValue, 0);
        return Math.abs(nVal - pVal) > 0.01;
      }));

      if (banksChanged || posChanged || invsChanged || stockChanged) {
        const scopeRaw = sql.raw(intList(writableIds));
        const glAgg = await tx.execute<{ client_id: number; account_no: string; currency: string; dr: number; cr: number; cnt: number }>(sql`
          select client_id, account_no, currency, coalesce(sum(debit), 0) as dr, coalesce(sum(credit), 0) as cr, count(*)::int as cnt
          from journal_lines
          where client_id in (${scopeRaw})
          group by client_id, account_no, currency
        `);

        const glBefore = new Map<string, { dr: number; cr: number }>();
        const lineCountBefore = new Map<number, number>();
        for (const row of glAgg.rows) {
          glBefore.set(`${row.client_id}:${row.account_no}:${row.currency}`, { dr: Number(row.dr), cr: Number(row.cr) });
          lineCountBefore.set(row.client_id, (lineCountBefore.get(row.client_id) ?? 0) + Number(row.cnt));
        }
        const glAfter = new Map<string, { dr: number; cr: number }>();
        for (const [k, v] of glBefore) glAfter.set(k, { ...v });
        const lineCountAfter = new Map<number, number>(lineCountBefore);
        for (const l of newLines) {
          const k = `${l.clientId}:${l.accountNo}:${l.currency}`;
          const cur = glAfter.get(k) ?? { dr: 0, cr: 0 };
          cur.dr += l.debit;
          cur.cr += l.credit;
          glAfter.set(k, cur);
          lineCountAfter.set(l.clientId, (lineCountAfter.get(l.clientId) ?? 0) + 1);
        }

        const sumAccountDr = (map: Map<string, { dr: number; cr: number }>, cid: number, acc: string) => {
          let total = 0;
          for (const [k, v] of map) if (k.startsWith(`${cid}:${acc}:`)) total += v.dr;
          return r2(total);
        };
        const sumAccountCr = (map: Map<string, { dr: number; cr: number }>, cid: number, acc: string) => {
          let total = 0;
          for (const [k, v] of map) if (k.startsWith(`${cid}:${acc}:`)) total += v.cr;
          return r2(total);
        };
        const sumAccountNet = (map: Map<string, { dr: number; cr: number }>, cid: number, acc: string) => {
          let total = 0;
          for (const [k, v] of map) if (k.startsWith(`${cid}:${acc}:`)) total += v.dr - v.cr;
          return r2(total);
        };

        for (const cid of writableIds) {
          const entityLinesAfter = lineCountAfter.get(cid) ?? 0;

          if (posChanged) {
            const pPoPaid = r2(prevPOs.filter((p) => p.clientId === cid).reduce((s, p) => s + (p.paidAmount ?? 0), 0));
            const nPoPaid = r2(pos.filter((p) => (p.clientId ?? 0) === cid).reduce((s, p) => s + (p.paidAmount ?? 0), 0));
            const deltaPoPaid = r2(nPoPaid - pPoPaid);
            if (deltaPoPaid > 0.01) {
              const deltaApDr = r2(sumAccountDr(glAfter, cid, '200000') - sumAccountDr(glBefore, cid, '200000'));
              if (deltaApDr + 0.02 < deltaPoPaid) {
                transactionError = 'Purchase order settlement must match a posted payment journal in the general ledger.';
                return;
              }
            }
          }

          if (invsChanged) {
            const pInvPaid = r2(prevInvoices.filter((i) => i.clientId === cid).reduce((s, i) => s + i.paidAmount, 0));
            const nInvPaid = r2(invoices.filter((i) => (i.clientId ?? 0) === cid).reduce((s, i) => s + i.paidAmount, 0));
            const deltaInvPaid = r2(nInvPaid - pInvPaid);
            if (deltaInvPaid > 0.01) {
              const deltaArCr = r2(sumAccountCr(glAfter, cid, '110000') - sumAccountCr(glBefore, cid, '110000'));
              if (deltaArCr + 0.02 < deltaInvPaid) {
                transactionError = 'Sales invoice settlement must match a posted receipt journal in the general ledger.';
                return;
              }
            }
          }

          if (banksChanged) {
            // Aggregate GL balances cannot identify which of two bank accounts
            // sharing one control account actually moved. Do not accept a
            // browser-supplied transfer between them without a bank-specific
            // server transaction and supporting statement evidence.
            for (const next of banks.filter((b) => b.clientId === cid)) {
              const prior = prevBanks.find((b) => b.id === next.id && b.clientId === cid);
              if (!prior || Math.abs(next.balance - prior.balance) < 0.01) continue;
              const siblings = banks.filter((b) => b.clientId === cid && (b.glAccount || '100000') === (next.glAccount || '100000') && b.currency === next.currency);
              if (siblings.length > 1) {
                transactionError = `Bank ${next.code} shares GL ${next.glAccount || '100000'} with another bank. Individual movements require a bank-specific server posting, not an aggregate snapshot.`;
                return;
              }
            }
            const bankKeys = new Set<string>();
            for (const b of prevBanks) if (b.clientId === cid) bankKeys.add(`${b.glAccount || '100000'}:${b.currency}`);
            for (const b of banks) if ((b.clientId ?? 0) === cid) bankKeys.add(`${b.glAccount || '100000'}:${b.currency}`);
            for (const bk of bankKeys) {
              const [glAcc, ccy] = bk.split(':');
              const pSum = r2(prevBanks.filter((b) => b.clientId === cid && (b.glAccount || '100000') === glAcc && b.currency === ccy).reduce((s, b) => s + b.balance, 0));
              const nSum = r2(banks.filter((b) => (b.clientId ?? 0) === cid && (b.glAccount || '100000') === glAcc && b.currency === ccy).reduce((s, b) => s + b.balance, 0));
              const deltaBank = r2(nSum - pSum);
              if (Math.abs(deltaBank) > 0.01) {
                const bEntry = glBefore.get(`${cid}:${glAcc}:${ccy}`) ?? { dr: 0, cr: 0 };
                const aEntry = glAfter.get(`${cid}:${glAcc}:${ccy}`) ?? { dr: 0, cr: 0 };
                const prevGlNet = r2(bEntry.dr - bEntry.cr);
                const nextGlNet = r2(aEntry.dr - aEntry.cr);
                const deltaGl = r2(nextGlNet - prevGlNet);
                const matchesMovement = Math.abs(deltaBank - deltaGl) <= 0.02;
                const matchesReconciledGl = Math.abs(nSum - nextGlNet) <= 0.02;
                const matchesEmptyReset = Math.abs(nSum) < 0.01 && entityLinesAfter === 0;
                if (!matchesMovement && !matchesReconciledGl && !matchesEmptyReset) {
                  transactionError = `Bank working balance change for ${glAcc} (${ccy}) does not match posted cash/bank journal lines.`;
                  return;
                }
              }
            }
          }

          if (stockChanged && stock) {
            const pStockVal = r2(prevStock.filter((i) => i.clientId === cid).reduce((s, i) => s + i.totalValue, 0));
            const nStockVal = r2(stock.filter((i) => i.clientId === cid).reduce((s, i) => s + i.totalValue, 0));
            const deltaStock = r2(nStockVal - pStockVal);
            if (Math.abs(deltaStock) > 0.01) {
              const invAccs = new Set<string>(['120000', '121000', '123000', '124000']);
              for (const i of prevStock) if (i.clientId === cid && i.glAccount) invAccs.add(i.glAccount);
              for (const i of stock) if (i.clientId === cid && i.glAccount) invAccs.add(i.glAccount);
              let prevStockGl = 0;
              let nextStockGl = 0;
              for (const acc of invAccs) {
                prevStockGl = r2(prevStockGl + sumAccountNet(glBefore, cid, acc));
                nextStockGl = r2(nextStockGl + sumAccountNet(glAfter, cid, acc));
              }
              const deltaStockGl = r2(nextStockGl - prevStockGl);
              const matchesMovement = Math.abs(deltaStock - deltaStockGl) <= 0.05;
              const matchesReconciledGl = Math.abs(nStockVal - nextStockGl) <= 0.05;
              const matchesEmptyReset = Math.abs(nStockVal) < 0.01 && entityLinesAfter === 0;
              if (!matchesMovement && !matchesReconciledGl && !matchesEmptyReset) {
                transactionError = 'Inventory valuation change does not match posted inventory journal lines.';
                return;
              }
            }
          }
        }
      }
    }
    const previousPeriods = latestClosed.filter((row) => allowedClientIds.includes(row.clientId)).map((row) => `${row.clientId}:${row.period}`).sort();
    const nextPeriods = closed.map((row) => `${row.clientId}:${row.period}`).sort();
    if (JSON.stringify(previousPeriods) !== JSON.stringify(nextPeriods) && !isOwner &&
      (user.permissions?.canClosePeriod !== true || !scopedClients.every((c) => maySeeSection(user, c as ClientEntity, 'month_end')))) {
      transactionError = 'You do not have permission to close or reopen accounting periods.'; return;
    }
    for (const request of approvals) {
      const old = allApprovals.find((row) => row.id === request.id);
      if (!old && request.status !== 'pending') { transactionError = 'New approval requests must be pending.'; return; }
      if (old && old.status !== request.status) {
        if (old.status !== 'pending' || !(isOwner || user.canCheck) || request.reviewedBy !== user.username || request.payload?.lines?.some((line) => line.createdBy === user.username)) {
          transactionError = 'Approval decisions require an independent authenticated checker.'; return;
        }
      }
    }
    if (newLines.length) {
      await insertInBatches(journalLines, newLines.map((line) => ({ ...line, costCenter: line.costCenter ?? null, checkedBy: line.checkedBy ?? null, reference: line.reference ?? null })));
      const newDocuments = [...freshKeys].map((key) => docs.get(key)!);
      await insertInBatches(journalHeaders, newDocuments.map((document) => buildJournalHeader(document)));
      for (const document of newDocuments) await tx.insert(postingEvents).values(buildPostingEvent(document, user.username)).onConflictDoNothing();
    }
    await replace(bankAccounts, banks, (b) => ({ 
      id: b.id, clientId: b.clientId ?? 0, code: b.code, name: b.name, bankName: b.bankName, accountNo: b.accountNo,
      currency: b.currency, balance: b.balance, kind: b.kind ?? null, glAccount: b.glAccount ?? null,
    }));
    await replace(purchaseOrders, pos, (p) => ({
      id: p.id, clientId: p.clientId ?? 0, poNo: p.poNo, vendorName: p.vendorName, itemType: p.itemType,
      itemDescription: p.itemDescription, qty: p.qty, unitPrice: p.unitPrice, vatRecoverable: p.vatRecoverable,
      totalAmount: p.totalAmount, paidAmount: p.paidAmount ?? 0, status: p.status, date: p.date,
      currency: p.currency ?? null, vatTreatment: p.vatTreatment ?? null, netAmount: p.netAmount ?? null,
      quotationRef: p.quotationRef ?? null, glAccount: p.glAccount, glAccountName: p.glAccountName,
      costCenter: p.costCenter, costCenterName: p.costCenterName,
    }));
    await replace(salesInvoices, invoices, (i) => ({
      id: i.id, clientId: i.clientId ?? 0, invNo: i.invNo, customerName: i.customerName, revenueStream: i.revenueStream,
      netRevenue: i.netRevenue, vatOutput: i.vatOutput, cstAmount: i.cstAmount ?? null,
      tourismLevyAmount: i.tourismLevyAmount ?? null, vatWithheldByCustomer: i.vatWithheldByCustomer ?? null,
      totalReceivable: i.totalReceivable, paidAmount: i.paidAmount, status: i.status, date: i.date,
    }));
    await replace(employees, emps, (e) => ({
      id: e.id, clientId: e.clientId ?? null, bpNo: e.bpNo, name: e.name, role: e.role, department: e.department,
      costCenter: e.costCenter ?? null, jurisdiction: e.jurisdiction, basicSalary: e.basicSalary, allowances: e.allowances, ssnitNumber: e.ssnitNumber,
      tin: e.tin, status: e.status, isResident: e.isResident ?? true, exemptTier1: e.exemptTier1 ?? false,
      exemptTier2: e.exemptTier2 ?? false, ssnitExempt: e.ssnitExempt ?? false,
      ssnitExemptionReason: e.ssnitExemptionReason ?? null, taxRelief: e.taxRelief ?? 0, reliefType: e.reliefType ?? null,
      deductions: e.deductions ?? null,
    }));
    await replace(businessPartners, storedPartners, (p) => ({
      id: p.id, sourceId: p.sourceId, clientId: p.clientId ?? null, code: p.code, name: p.name, type: p.type, tin: p.tin, email: p.email,
      phone: p.phone, address: p.address, currency: p.currency, isVatWithholdingAgent: p.isVatWithholdingAgent,
      vatWithholdingRate: p.vatWithholdingRate ?? null, isCstApplicable: p.isCstApplicable,
      isTourismLevyApplicable: p.isTourismLevyApplicable, isVatRegistered: p.isVatRegistered ?? null,
    }));
    await replace(payrollRecords, payroll, (r) => ({ id: r.id, clientId: r.clientId ?? 0, record: r }));
    await replace(prepaymentRecords, prepayments, (p) => ({ id: p.id, clientId: p.clientId ?? 0, record: p }));
    await replace(prepaymentSchedules, prepaidSchedules, (s) => ({ id: s.id, prepaymentId: s.prepaymentId, clientId: s.clientId ?? 0, line: s }));
    await replace(approvalRequests, approvals, (a) => ({
      id: a.id, clientId: a.clientId, clientCode: a.clientCode, clientName: a.clientName, docNo: a.docNo,
      docType: a.docType, amount: a.amount, requestedBy: a.requestedBy, requestedAt: a.requestedAt,
      description: a.description, reasonForApproval: a.reasonForApproval, status: a.status,
      reviewedBy: a.reviewedBy ?? null, reviewedAt: a.reviewedAt ?? null, rejectionReason: a.rejectionReason ?? null,
      payload: a.payload ?? null,
    }));
    await replace(closedPeriods, closed.map((c) => ({ ...c, closedAt: new Date().toISOString(), closedBy: user.username })), (c) => ({
      clientId: c.clientId, period: c.period, closedAt: c.closedAt, closedBy: c.closedBy,
    }));
    // Statutory schedule edits/additions (WHT & VAT) — only when the browser sent them.
    if (taxEntries) {
      await replace(taxScheduleEntries, taxEntries, (t) => ({
        id: t.id, clientId: t.clientId, kind: t.kind, source: t.source, sourceKey: t.sourceKey ?? null,
        period: t.period, date: t.date, docNo: t.docNo, partyName: t.partyName, partyTin: t.partyTin ?? "",
        nature: t.nature ?? "", grossAmount: t.grossAmount ?? 0, rate: t.rate ?? 0, taxAmount: t.taxAmount ?? 0,
        levyAmount: t.levyAmount ?? 0, reference: t.reference ?? "", status: t.status ?? "", note: t.note ?? null,
        createdBy: t.createdBy, updatedAt: t.updatedAt,
      }));
    }

    // Perpetual inventory: item master + movement history, tenant-scoped.
    if (stock) {
      await replace(stockItems, stock, (i) => ({
        id: i.id, clientId: i.clientId, itemCode: i.itemCode, description: i.description, category: i.category,
        uom: i.uom, quantityOnHand: i.quantityOnHand, unitCost: i.unitCost, totalValue: i.totalValue,
        reorderLevel: i.reorderLevel ?? null, location: i.location ?? null, glAccount: i.glAccount ?? null,
        costMethod: i.costMethod ?? "weighted_average", netRealisableValue: i.netRealisableValue ?? null,
      }));
    }
    if (movements) {
      await replace(stockMovements, movements, (m) => ({
        id: m.id, clientId: m.clientId, date: m.date, itemCode: m.itemCode, description: m.description,
        type: m.type, quantity: m.quantity, unitCost: m.unitCost, totalValue: m.totalValue, uom: m.uom,
        reference: m.reference ?? null, docNo: m.docNo ?? null, note: m.note ?? null,
      }));
    }
    // Fixed asset register with tax base (capital allowances / IAS 12).
    if (assets) {
      await replace(fixedAssets, assets, (a) => ({
        id: a.id, clientId: a.clientId ?? 0, assetTag: a.assetTag, name: a.name, classCode: a.classCode,
        cost: a.cost, accumDep: a.accumDep, usefulLife: a.usefulLife,
        depreciationRate: a.depreciationRate ?? null, depreciationMethod: a.depreciationMethod ?? null,
        capitalAllowanceClass: a.capitalAllowanceClass ?? null, capitalAllowanceRate: a.capitalAllowanceRate ?? null,
        accumCapitalAllowance: a.accumCapitalAllowance ?? 0, location: a.location ?? "",
        acquired: a.acquired ?? null, disposedDate: a.disposedDate ?? null, disposalProceeds: a.disposalProceeds ?? null,
      }));
    }

    // Legal names, tax identifiers and invoice settlement instructions are
    // owner-controlled master data. Client accounts may read, never replace.
    const profileRows = isOwner ? Object.values(profiles) : [];
    for (const p of profileRows) {
      await tx.insert(companyProfiles).values({
        clientId: p.clientId, legalName: p.legalName, tradingName: p.tradingName, tin: p.tin, vatRegNo: p.vatRegNo,
        address: p.address, phone: p.phone, email: p.email, website: p.website, fiscalYearStart: p.fiscalYearStart,
        bankPaymentDetails: p.bankPaymentDetails,
      }).onConflictDoUpdate({
        target: companyProfiles.clientId,
        set: {
          legalName: p.legalName, tradingName: p.tradingName, tin: p.tin, vatRegNo: p.vatRegNo, address: p.address,
          phone: p.phone, email: p.email, website: p.website, fiscalYearStart: p.fiscalYearStart,
          bankPaymentDetails: p.bankPaymentDetails,
        },
      });
    }

    // Firm-level masters: owner-only.
    if (isOwner) {
      if (body.clients) {
        for (const c of body.clients) {
          await tx.insert(clients).values({
            id: c.id, code: c.code, name: c.name, sector: c.sector, currency: c.currency, jurisdiction: c.jurisdiction,
            regNumber: c.regNumber, isParent: c.isParent ?? false, assignedServices: c.assignedServices ?? null,
            adminUsername: c.adminUsername ?? null, adminEmail: c.adminEmail ?? null, loginUrl: c.loginUrl ?? null,
          }).onConflictDoUpdate({
            target: clients.id,
            set: {
              code: c.code, name: c.name, sector: c.sector, currency: c.currency, jurisdiction: c.jurisdiction,
              regNumber: c.regNumber, isParent: c.isParent ?? false, assignedServices: c.assignedServices ?? null,
              adminUsername: c.adminUsername ?? null, adminEmail: c.adminEmail ?? null, loginUrl: c.loginUrl ?? null,
            },
          });
        }
      }
      if (body.disclosureNotes) {
        await tx.delete(disclosureNotes);
        if (body.disclosureNotes.length) {
          await tx.insert(disclosureNotes).values(
            body.disclosureNotes.map((n) => ({
              key: n.key, noteNumber: n.noteNumber, title: n.title, standardRef: n.standardRef, applicable: n.applicable,
              notApplicableReason: n.notApplicableReason ?? null, body: n.body, tables: n.tables ?? null,
              editableOverride: n.editableOverride ?? null,
            }))
          );
        }
      }
    }

    // Chart of accounts: the owner maintains the whole chart (firm master plus every
    // entity's customs); non-owners maintain only their own entity's custom accounts.
    if (body.chartOfAccounts) {
      if (isOwner) {
        await tx.delete(chartAccounts);
        if (body.chartOfAccounts.length) {
          await tx.insert(chartAccounts).values(
            body.chartOfAccounts.map((a) => ({
              accountNo: a.accountNo, name: a.name, type: a.type, category: a.category,
              active: a.active, isCustom: a.isCustom ?? false, clientId: a.clientId ?? null,
            }))
          );
        }
      } else if (myClientId !== null && user.role === "manager" && user.permissions?.canModifyCOA === true &&
        scopedClients.some((c) => c.id === myClientId && maySeeSection(user, c as ClientEntity, 'coa_master'))) {
        // An explicit manager permission AND the contracted chart module are
        // required. Staff syncs leave the chart untouched.
        await tx.delete(chartAccounts).where(eq(chartAccounts.clientId, myClientId));
        const own = body.chartOfAccounts.filter((a) => a.clientId === myClientId);
        if (own.length) {
          await tx.insert(chartAccounts).values(
            own.map((a) => ({
              accountNo: a.accountNo, name: a.name, type: a.type, category: a.category,
              active: a.active, isCustom: a.isCustom ?? false, clientId: myClientId,
            }))
          );
        }
      }
    }

    // Audit trail: one entry per newly posted journal document.
    const now = new Date().toISOString();
    // Period freezes and reopens are audit events — the ledger can change hands
    // but the control history must be reviewable.
    const prevClosed = new Set(allClosed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`));
    const nextClosed = new Set(closed.map((c) => `${c.clientId}:${c.period}`));
    for (const key of nextClosed) {
      if (prevClosed.has(key)) continue;
      const [cid, p] = key.split(":");
      await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: "CLOSE_PERIOD", target: `${cid}:${p}`, details: `Period ${p} frozen for client ${cid}`, clientId: Number(cid) });
    }
    for (const key of prevClosed) {
      if (nextClosed.has(key)) continue;
      const [cid, p] = key.split(":");
      await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: "REOPEN_PERIOD", target: `${cid}:${p}`, details: `Period ${p} reopened for client ${cid}`, clientId: Number(cid) });
    }
    // Approval resolutions (pending → approved/rejected) are audit events too.
    const prevApprovalStatus = new Map(allApprovals.filter((a) => allowedClientIds.includes(a.clientId)).map((a) => [a.id, a.status]));
    for (const a of approvals) {
      const prev = prevApprovalStatus.get(a.id);
      if (prev && prev !== a.status) {
        await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: `APPROVAL_${a.status.toUpperCase()}`, target: a.docNo, details: `${a.clientCode} request by ${a.requestedBy} ${a.status}${a.rejectionReason ? ` — ${a.rejectionReason}` : ""}`, clientId: a.clientId });
      }
    }
    for (const key of freshKeys) {
      const docLines = docs.get(key)!;
      const dr = docLines.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
      await tx.insert(auditLog).values({
        id: crypto.randomUUID(),
        timestamp: now,
        userId: user.username,
        username: user.username,
        action: "POST_JOURNAL",
        target: key.split(":")[1],
        details: `${docLines.length} line(s), debits ${dr.toFixed(2)}`,
        clientId: Number(key.split(":")[0]),
      });
    }
  });

  if (transactionError) return Response.json({ ok: false, error: transactionError }, { status: transactionStatus });
  return Response.json({ ok: true, warnings });
}
