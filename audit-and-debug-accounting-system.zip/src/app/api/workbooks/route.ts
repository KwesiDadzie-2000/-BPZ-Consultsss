import { randomUUID } from "node:crypto";
import { readJsonBody } from "@/lib/http";
import { and, eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import { auditLog, clients, entityWorkbooks } from "@/db/schema";
import { getSessionUser, hasFirmWideScope } from "@/lib/auth";
import { maySeeSection } from "@/utils/access";
import type { ClientEntity, UserAccount } from "@/types/accounting";

export const dynamic = "force-dynamic";

/**
 * Entity workbooks API — budgets, forecasts, scenarios, KPI targets, cash-flow
 * plans and IFRS schedule inputs.
 *
 * Controls (ISA 315 / COSO "control activities"):
 *  - Authenticated session required; tenant scope enforced server-side.
 *  - Auditors are read-only.
 *  - Optimistic concurrency: every write must quote the version it edited.
 *  - Maker-checker: the approver must be independent of preparer and submitter.
 *  - Approved workbooks are immutable; changes require a new revision key.
 *  - Every mutation is written to the audit trail.
 */
const KINDS_LIST = [
  "budget", "forecast", "scenario", "kpi_targets", "ifrs_inputs", "ifrs_desk", "loan_facilities", "project_costing", "sector_measurement", "cashflow_plan",
] as const;
const KINDS = new Set<string>(KINDS_LIST);
function sectionForKind(kind: string | null | undefined): string {
  if (kind === "ifrs_inputs" || kind === "ifrs_desk") return "ifrs_desk";
  if (kind === "loan_facilities") return "loans_desk";
  if (kind === "project_costing") return "project_costing";
  if (kind === "sector_measurement") return "sector_regulation";
  return "performance";
}
const KEY_RE = /^[A-Za-z0-9._:-]{1,80}$/;
const MAX_PAYLOAD_BYTES = 1_000_000;

type Row = typeof entityWorkbooks.$inferSelect;

function reply(body: unknown, status = 200): Response {
  return Response.json(body, { status, headers: { "cache-control": "no-store, max-age=0, must-revalidate" } });
}

function mayAccess(user: UserAccount, clientId: number): boolean {
  return hasFirmWideScope(user) || user.clientId === clientId;
}

function mayEdit(user: UserAccount): boolean {
  return user.role !== "auditor" && (user.status ?? "active") === "active";
}

function mayApprove(user: UserAccount): boolean {
  return mayEdit(user) && (user.role === "owner" || user.role === "partner" || user.canCheck === true);
}

function serialize(row: Row) {
  return {
    id: row.id,
    clientId: row.clientId,
    kind: row.kind,
    key: row.key,
    title: row.title,
    payload: row.payload,
    status: row.status,
    version: row.version,
    preparedBy: row.preparedBy,
    submittedBy: row.submittedBy,
    approvedBy: row.approvedBy,
    approvedAt: row.approvedAt,
    reviewComment: row.reviewComment,
    updatedAt: row.updatedAt instanceof Date ? row.updatedAt.toISOString() : String(row.updatedAt),
  };
}

async function writeAudit(user: UserAccount, action: string, target: string, details: string, clientId: number) {
  try {
    await db.insert(auditLog).values({
      id: randomUUID(),
      timestamp: new Date().toISOString(),
      userId: user.username,
      username: user.username,
      action,
      target,
      details: details.slice(0, 1000),
      clientId,
    });
  } catch (error) {
    console.error("workbook audit write failed", error);
  }
}

async function authorise(req: Request, clientIdRaw: unknown, kind?: string | null): Promise<{ user: UserAccount; clientId: number; entity: ClientEntity } | Response> {
  try {
    await ensureDatabaseReady();
  } catch {
    return reply({ ok: false, error: "The workspace database is unavailable." }, 503);
  }
  const user = await getSessionUser(req);
  if (!user) return reply({ ok: false, error: "Your session has expired. Sign in again." }, 401);
  if (user.status === "restricted" || user.status === "suspended") {
    return reply({ ok: false, error: "This account is restricted." }, 403);
  }
  const clientId = Number(clientIdRaw);
  if (!Number.isInteger(clientId) || clientId <= 0) return reply({ ok: false, error: "A valid entity is required." }, 400);
  if (!mayAccess(user, clientId)) return reply({ ok: false, error: "You do not have access to this entity." }, 403);
  const exists = await db.select().from(clients).where(eq(clients.id, clientId)).limit(1);
  if (!exists[0]) return reply({ ok: false, error: "Entity not found." }, 404);
  const scopedEntity = {
    ...exists[0],
    assignedServices: Array.isArray(exists[0].assignedServices) ? (exists[0].assignedServices as string[]) : undefined,
  } as ClientEntity;
  const requiredSection = sectionForKind(kind);
  if (kind && !maySeeSection(user, scopedEntity, requiredSection)) {
    return reply({ ok: false, error: "You do not have permission to access this module." }, 403);
  }
  if (!kind && !KINDS_LIST.some((k) => maySeeSection(user, scopedEntity, sectionForKind(k)))) {
    return reply({ ok: false, error: "No workbooks are enabled for this account." }, 403);
  }
  return { user, clientId, entity: scopedEntity };
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const kind = url.searchParams.get("kind");
  if (kind && !KINDS.has(kind)) return reply({ ok: false, error: "Unknown workbook kind." }, 400);
  const auth = await authorise(req, url.searchParams.get("clientId"), kind);
  if (auth instanceof Response) return auth;
  const rows = await db
    .select()
    .from(entityWorkbooks)
    .where(kind ? and(eq(entityWorkbooks.clientId, auth.clientId), eq(entityWorkbooks.kind, kind)) : eq(entityWorkbooks.clientId, auth.clientId));
  // Without ?kind a client must not see another module's workbook, including
  // IFRS assumptions, staff forecasts or borrowing schedules.
  const visible = rows.filter((r) => maySeeSection(auth.user, auth.entity, sectionForKind(r.kind)));
  visible.sort((a, b) => a.kind.localeCompare(b.kind) || a.key.localeCompare(b.key));
  return reply({ ok: true, workbooks: visible.map(serialize) });
}

export async function PUT(req: Request) {
  let body: { clientId?: unknown; kind?: unknown; key?: unknown; title?: unknown; payload?: unknown; expectedVersion?: unknown };
  try {
    body = await readJsonBody<any>(req, 1_048_576);
  } catch {
    return reply({ ok: false, error: "Invalid request body." }, 400);
  }
  const kind = String(body.kind ?? "");
  if (!KINDS.has(kind)) return reply({ ok: false, error: "Unknown workbook kind." }, 400);
  const auth = await authorise(req, body?.clientId, kind);
  if (auth instanceof Response) return auth;
  const { user, clientId } = auth;
  if (!mayEdit(user)) return reply({ ok: false, error: "Your role is read-only for planning and schedule workbooks." }, 403);
  const key = String(body.key ?? "");
  const title = String(body.title ?? "").slice(0, 160);
  if (!KINDS.has(kind)) return reply({ ok: false, error: "Unknown workbook kind." }, 400);
  if (!KEY_RE.test(key)) return reply({ ok: false, error: "Workbook key must be 1–80 letters, digits, dot, colon, dash or underscore." }, 400);
  if (body.payload === null || typeof body.payload !== "object") return reply({ ok: false, error: "Workbook payload must be an object." }, 400);
  const size = JSON.stringify(body.payload).length;
  if (size > MAX_PAYLOAD_BYTES) return reply({ ok: false, error: "Workbook is too large (limit 1 MB)." }, 413);
  const expectedVersion = Number(body.expectedVersion ?? 0);
  const id = `${clientId}:${kind}:${key}`;

  const result = await db.transaction(async (tx) => {
    const current = (await tx.select().from(entityWorkbooks).where(eq(entityWorkbooks.id, id)).for("update").limit(1))[0];
    if (current) {
      if (current.version !== expectedVersion) return { status: 409, body: { ok: false, error: "This workbook was changed by someone else. Reload to see the latest version.", current: serialize(current) } };
      if (current.status === "approved") return { status: 409, body: { ok: false, error: "Approved workbooks are locked. Create a revision to make changes." } };
      if (current.status === "submitted") return { status: 409, body: { ok: false, error: "Submitted workbooks are locked while under review. Withdraw it first." } };
      const updated = await tx
        .update(entityWorkbooks)
        .set({ title: title || current.title, payload: body.payload as object, version: current.version + 1, status: "draft", preparedBy: user.username, reviewComment: current.status === "rejected" ? current.reviewComment : null, updatedAt: new Date() })
        .where(eq(entityWorkbooks.id, id))
        .returning();
      return { status: 200, body: { ok: true, workbook: serialize(updated[0]) } };
    }
    if (expectedVersion !== 0) return { status: 409, body: { ok: false, error: "This workbook no longer exists. Reload and try again." } };
    const inserted = await tx
      .insert(entityWorkbooks)
      .values({ id, clientId, kind, key, title, payload: body.payload as object, status: "draft", version: 1, preparedBy: user.username })
      .returning();
    return { status: 201, body: { ok: true, workbook: serialize(inserted[0]) } };
  });
  if (result.status < 300) await writeAudit(user, "WORKBOOK_SAVED", id, `${kind} · ${key} · ${title || "untitled"} · ${size} bytes`, clientId);
  return reply(result.body, result.status);
}

export async function POST(req: Request) {
  let body: { clientId?: unknown; kind?: unknown; key?: unknown; action?: unknown; version?: unknown; comment?: unknown };
  try {
    body = await readJsonBody<any>(req, 1_048_576);
  } catch {
    return reply({ ok: false, error: "Invalid request body." }, 400);
  }
  const kind = String(body.kind ?? "");
  if (!KINDS.has(kind)) return reply({ ok: false, error: "Unknown workbook kind." }, 400);
  const auth = await authorise(req, body?.clientId, kind);
  if (auth instanceof Response) return auth;
  const { user, clientId } = auth;
  const action = String(body.action ?? "");
  const id = `${clientId}:${String(body.kind ?? "")}:${String(body.key ?? "")}`;
  const version = Number(body.version ?? -1);
  const comment = String(body.comment ?? "").trim().slice(0, 500);
  if (!["submit", "approve", "reject", "withdraw"].includes(action)) return reply({ ok: false, error: "Unknown workflow action." }, 400);
  if (!mayEdit(user)) return reply({ ok: false, error: "Your role is read-only." }, 403);

  const result = await db.transaction(async (tx) => {
    const row = (await tx.select().from(entityWorkbooks).where(eq(entityWorkbooks.id, id)).for("update").limit(1))[0];
    if (!row) return { status: 404, body: { ok: false, error: "Workbook not found." } };
    if (row.version !== version) return { status: 409, body: { ok: false, error: "This workbook changed. Reload before acting on it.", current: serialize(row) } };
    const independent = user.username !== row.preparedBy && user.username !== row.submittedBy;
    let patch: Partial<typeof entityWorkbooks.$inferInsert> = {};
    if (action === "submit") {
      if (row.status !== "draft" && row.status !== "rejected") return { status: 409, body: { ok: false, error: `Only draft or rejected workbooks can be submitted (current: ${row.status}).` } };
      patch = { status: "submitted", submittedBy: user.username, reviewComment: comment || null };
    } else if (action === "withdraw") {
      if (row.status !== "submitted") return { status: 409, body: { ok: false, error: "Only submitted workbooks can be withdrawn." } };
      if (user.username !== row.submittedBy && !mayApprove(user)) return { status: 403, body: { ok: false, error: "Only the submitter or a reviewer can withdraw this workbook." } };
      patch = { status: "draft", submittedBy: null };
    } else {
      if (row.status !== "submitted") return { status: 409, body: { ok: false, error: "Only submitted workbooks can be reviewed." } };
      if (!mayApprove(user)) return { status: 403, body: { ok: false, error: "You are not authorised to review workbooks (checker rights required)." } };
      if (!independent) return { status: 403, body: { ok: false, error: "Segregation of duties: the reviewer must be independent of the preparer and submitter." } };
      if (action === "reject" && !comment) return { status: 400, body: { ok: false, error: "A rejection reason is required." } };
      patch = action === "approve"
        ? { status: "approved", approvedBy: user.username, approvedAt: new Date().toISOString(), reviewComment: comment || null }
        : { status: "rejected", reviewComment: comment };
    }
    const updated = await tx.update(entityWorkbooks).set({ ...patch, version: row.version + 1, updatedAt: new Date() }).where(eq(entityWorkbooks.id, id)).returning();
    return { status: 200, body: { ok: true, workbook: serialize(updated[0]) } };
  });
  if (result.status === 200) await writeAudit(user, `WORKBOOK_${action.toUpperCase()}`, id, comment || action, clientId);
  return reply(result.body, result.status);
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const auth = await authorise(req, url.searchParams.get("clientId"), url.searchParams.get("kind"));
  if (auth instanceof Response) return auth;
  const { user, clientId } = auth;
  if (!mayEdit(user)) return reply({ ok: false, error: "Your role is read-only." }, 403);
  const id = `${clientId}:${url.searchParams.get("kind") ?? ""}:${url.searchParams.get("key") ?? ""}`;
  const row = (await db.select().from(entityWorkbooks).where(eq(entityWorkbooks.id, id)).limit(1))[0];
  if (!row) return reply({ ok: false, error: "Workbook not found." }, 404);
  if (row.status !== "draft" && row.status !== "rejected") return reply({ ok: false, error: "Only draft or rejected workbooks can be deleted; approved records are retained for audit." }, 409);
  await db.delete(entityWorkbooks).where(eq(entityWorkbooks.id, id));
  await writeAudit(user, "WORKBOOK_DELETED", id, `${row.kind} · ${row.key} · v${row.version}`, clientId);
  return reply({ ok: true });
}
