import React from 'react';
import { dashboardModel } from '../utils/dashboardModel';
import { maySeeSection } from '../utils/access';
import { ClientEntity, ACDOCALine, UserAccount } from '../types/accounting';
import { Card, Stat, ModuleTag, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { ArrowUpRight, ShoppingCart, Tag, Users, Truck, Layers, Calculator, CreditCard, Hourglass } from 'lucide-react';

interface AccountingDashboardProps {
  currentClient: ClientEntity;
  currentUser?: UserAccount;
  lines: ACDOCALine[];
  onNavigate: (section: string) => void;
}

export const AccountingDashboard: React.FC<AccountingDashboardProps> = ({
  currentClient,
  currentUser,
  lines,
  onNavigate,
}) => {
  const { entityLines: clientLines, excludedLines, isBalanced, cashBank, bankBalance,
    cashOnHand, receivables, payables, revenue, expenses, netIncome, vat, recent } = dashboardModel(lines, currentClient);
  const symbol = currentClient.currency === 'GHS' ? '\u20b5' : `${currentClient.currency} `;
  const canOpen = (section: string) => !currentUser || maySeeSection(currentUser, currentClient, section);

  const launchers = [
    { section: 'procurement', title: 'Procurement & P2P (MM)', sub: 'Requisition → PO → GRN → 3-way matched invoice → payment', Icon: ShoppingCart, bg: 'bg-[#006f98]' },
    { section: 'sales', title: 'Sales & Invoicing · O2C (SD)', sub: 'IFRS 15 billing, output VAT', Icon: Tag, bg: 'bg-[#087a55]' },
    { section: 'payroll', title: 'Payroll Desk (HR)', sub: 'PAYE bands, SSNIT Tier 1 & 2', Icon: Users, bg: 'bg-[#6d3fb3]' },
    { section: 'assets', title: 'Fixed Assets (AA)', sub: 'IAS 16 schedule & depreciation', Icon: Truck, bg: 'bg-[#8a5d00]' },
    { section: 'ifrs_desk', title: 'IFRS / IAS Standards Desk', sub: 'Contracts (IFRS 15), Leases (IFRS 16), Impairments', Icon: Layers, bg: 'bg-[#006f98]' },
    { section: 'loans_desk', title: 'Loan Amortisation Desk', sub: 'Borrowings, annuity debt schedules & interest', Icon: Calculator, bg: 'bg-[#855b00]' },
    { section: 'payment_desk', title: 'Payment Desk (Finance)', sub: 'Treasury gateway — pay suppliers, receive customers, remit statutory', Icon: CreditCard, bg: 'bg-[#082f4f]' },
    { section: 'ageing', title: 'Ageing Analysis (AR & AP)', sub: 'Overdue control, collections & ECL input', Icon: Hourglass, bg: 'bg-[#315f91]' },
  ].filter((l) => canOpen(l.section));

  const closeTasks = [
    { label: 'Reconcile control accounts', section: 'control_accounts' },
    { label: 'Reconcile the bank', section: 'banking' },
    { label: 'Review AR / AP ageing', section: 'ageing' },
    { label: 'Review IFRS controls', section: 'compliance_review' },
    { label: 'Close the period', section: 'month_end' },
  ].filter((t) => canOpen(t.section));

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`Command Center · ${currentClient.code}`}
        title={currentClient.name}
        desc={`Balances from ${currentClient.code}'s posted ${currentClient.currency} journal.${excludedLines ? ` ${excludedLines} foreign-currency lines excluded until translated.` : ' Only this entity is shown.'}`}
      >
        <div className="flex gap-2">
          {canOpen('universal_journal') && (
            <button
              onClick={() => onNavigate('universal_journal')}
              className="rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
            >
              Post Journal Entry
            </button>
          )}
          {canOpen('report_financial_r') && (
            <button
              onClick={() => onNavigate('report_financial_r')}
              className="rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition"
            >
              Financial Reports
            </button>
          )}
        </div>
      </PageHeader>

      {/* Key Financial Indicators */}
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Cash & Bank" value={`${symbol}${formatGHS(cashBank)}`} sub={`Bank ${symbol}${formatGHS(bankBalance)} · Cash on hand ${symbol}${formatGHS(cashOnHand)}`} />
        <Stat label="Accounts Receivable" value={`${symbol}${formatGHS(receivables)}`} sub="Customer open balances" />
        <Stat label="Accounts Payable" value={`${symbol}${formatGHS(payables)}`} sub="Supplier open balances" />
        <Stat label="Revenue (all journal periods)" value={`${symbol}${formatGHS(revenue)}`} tone="text-emerald-700" sub="All sales & contract income" />
        <Stat label="Operating Expenses" value={`${symbol}${formatGHS(expenses)}`} tone="text-rose-700" sub="All expense accounts" />
        <Stat label="Net Income" value={`${symbol}${formatGHS(netIncome)}`} tone={netIncome < 0 ? "text-rose-700" : "text-emerald-700"} sub="Revenue − expenses" />
        <Stat label="VAT Ledger Position" value={`${symbol}${formatGHS(vat)}`} tone="text-[#006f98]" sub="Unverified account position" />
        <Stat label="Universal Journal" value={isBalanced ? "Balanced (0.00)" : "Out of Balance"} tone={isBalanced ? "text-emerald-700" : "text-rose-700"} sub={`${clientLines.length} active journal lines`} />
      </div>

      {/* Operations Quick Launchers & Sector Focus */}
      {(launchers.length > 0 || closeTasks.length > 0 || canOpen('sector_workflow')) && (
        <div className="grid gap-4 xl:grid-cols-2">
          <Card title="Operational Accounting Desks" sub="Live posting cycles permitted for your workspace">
            {launchers.length === 0 ? (
              <p className="text-xs text-[#355875] py-4">
                Use the navigation menu on the left to open the modules assigned to your account.
              </p>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {launchers.map(({ section, title, sub, Icon, bg }) => (
                  <button
                    key={section}
                    onClick={() => onNavigate(section)}
                    className="flex items-start gap-3 rounded-lg border border-sky-200 bg-sky-50/50 p-3 text-left hover:bg-sky-100/60 transition"
                  >
                    <div className={`rounded-md ${bg} p-2 text-white`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-[#082f4f]">{title}</div>
                      <div className="text-[11px] text-[#2d4f6d]">{sub}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </Card>

          {(closeTasks.length > 0 || canOpen('sector_workflow')) && (
            <Card title="Close & exceptions" sub="Check outstanding items before reporting">
              {closeTasks.length > 0 && (
                <div className="grid gap-2 sm:grid-cols-2">
                  {closeTasks.map(({ label, section }) => (
                    <button key={section} type="button" onClick={() => onNavigate(section)} className="rounded-lg border border-sky-200 bg-sky-50/50 px-3 py-2 text-left text-xs font-bold text-[#082f4f] hover:bg-sky-100">
                      {label} →
                    </button>
                  ))}
                </div>
              )}
              {canOpen('sector_workflow') && (
                <button type="button" onClick={() => onNavigate('sector_workflow')} className="mt-3 text-[11px] font-semibold text-[#355875] underline underline-offset-2 hover:text-[#082f4f]">
                  Sector policy and workflow reference
                </button>
              )}
            </Card>
          )}
        </div>
      )}

      {/* Recent Universal Journal Activity */}
      <Card
        title="Recent Journal Activity (ACDOCA)"
        sub="Latest ledger postings in this workspace"
        action={
          canOpen('universal_journal') ? (
            <button
              onClick={() => onNavigate('universal_journal')}
              className="flex items-center gap-1 text-xs font-bold text-[#006f98] hover:underline"
            >
              <span>Open Universal Journal</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          ) : undefined
        }
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/60">
                <th className={thCls}>Doc No</th>
                <th className={thCls}>Period</th>
                <th className={thCls}>Module</th>
                <th className={thCls}>Account</th>
                <th className={thCls}>Description</th>
                <th className={thCls + " text-right"}>Debit</th>
                <th className={thCls + " text-right"}>Credit</th>
              </tr>
            </thead>
            <tbody>
              {recent.length === 0 && <tr><td colSpan={7} className="px-3 py-10 text-center text-[#355875]">No journal entries yet. Post an opening balance or your first journal to get started.</td></tr>}
              {recent.map((line) => (
                <tr key={line.id} className={rowCls}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{line.docNo}</td>
                  <td className="px-3 py-2 font-mono text-[#2d4f6d]">{line.period}<span className="block text-[10px]">{line.currency}</span></td>
                  <td className="px-3 py-2"><ModuleTag m={line.module} /></td>
                  <td className="px-3 py-2">
                    <span className="font-mono font-bold text-[#0a253e]">{line.accountNo}</span>
                    <div className="text-[11px] text-[#355875] truncate max-w-[140px]">{line.accountName}</div>
                  </td>
                  <td className="px-3 py-2 text-[#2d4f6d] truncate max-w-[200px]">{line.description}</td>
                  <td className={numCls + " font-bold text-[#8a5d00]"}>
                    {line.debit > 0 ? formatGHS(line.debit) : '—'}
                  </td>
                  <td className={numCls + " font-bold text-[#087a55]"}>
                    {line.credit > 0 ? formatGHS(line.credit) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
