'use client';

/**
 * Supporting-document panel.
 *
 * Evidence is attached to the document it supports (sales invoice, goods
 * receipt, supplier invoice, payment voucher, journal) and can be reopened or
 * removed later. Upload failures are explained in place — no silent no-ops.
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { AlertTriangle, CheckCircle2, Download, Paperclip, Trash2, Upload } from 'lucide-react';
import {
  ATTACHMENT_LIMITS,
  addAttachment,
  deleteAttachment,
  formatBytes,
  listAttachments,
  openAttachment,
  type AttachmentMeta,
} from '@/utils/attachments';

export function AttachmentsPanel({
  clientId,
  docId,
  docNo,
  addedBy,
  canDelete = true,
}: {
  clientId: number;
  docId: string;
  docNo: string;
  addedBy: string;
  canDelete?: boolean;
}) {
  const [items, setItems] = useState<AttachmentMeta[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const inputRef = useRef<HTMLInputElement>(null);

  const refresh = useCallback(async () => {
    try {
      setItems(await listAttachments(clientId, docId));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'The attachments could not be read.');
    } finally {
      setLoading(false);
    }
  }, [clientId, docId]);

  useEffect(() => {
    let active = true;
    listAttachments(clientId, docId)
      .then((rows) => { if (active) { setItems(rows); setError(null); } })
      .catch((e) => { if (active) setError(e instanceof Error ? e.message : 'The attachments could not be read.'); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [clientId, docId]);

  const upload = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await addAttachment({ file, clientId, docId, docNo, addedBy });
      await refresh();
      setNotice(`${file.name} attached to ${docNo}.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'The attachment could not be saved.');
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  };

  const remove = async (id: string, name: string) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await deleteAttachment(id);
      await refresh();
      setNotice(`${name} removed.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'The attachment could not be removed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div data-print-hide className="space-y-2">
      <div className="flex flex-wrap items-center justify-between gap-2 rounded border border-sky-200 bg-sky-50/60 px-3 py-2">
        <div>
          <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[#082f4f]">
            <Paperclip className="h-3.5 w-3.5" /> Supporting documents ({items.length}/{ATTACHMENT_LIMITS.maxFilesPerDocument})
          </div>
          <p className="mt-0.5 text-[10.5px] text-[#2d4f6d]">
            Signed delivery notes, invoices, timesheets and acceptance certificates. Max {ATTACHMENT_LIMITS.maxFileBytes / (1024 * 1024)} MB per file ·
            PDF, image, CSV, XLSX, DOCX · stored against this document on this device.
          </p>
        </div>
        <div>
          <input
            ref={inputRef}
            id={`attachments-${docId}`}
            type="file"
            className="sr-only"
            accept={ATTACHMENT_LIMITS.acceptedExtensions.map((e) => `.${e}`).join(',')}
            onChange={(e) => void upload(e.target.files?.[0])}
            disabled={busy}
          />
          <label
            htmlFor={`attachments-${docId}`}
            aria-disabled={busy || items.length >= ATTACHMENT_LIMITS.maxFilesPerDocument}
            className={`inline-flex cursor-pointer items-center gap-1.5 rounded border border-sky-300 bg-white px-3 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50 ${busy || items.length >= ATTACHMENT_LIMITS.maxFilesPerDocument ? 'pointer-events-none opacity-50' : ''}`}
          >
            <Upload className="h-3.5 w-3.5" /> {busy ? 'Working…' : 'Attach evidence'}
          </label>
        </div>
      </div>

      {error && (
        <p role="alert" className="flex items-start gap-1.5 rounded border border-rose-300 bg-rose-50 px-3 py-2 text-[11px] font-semibold text-rose-900">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {error}
        </p>
      )}
      {notice && (
        <p role="status" className="flex items-start gap-1.5 rounded border border-emerald-300 bg-emerald-50 px-3 py-2 text-[11px] font-semibold text-emerald-900">
          <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {notice}
        </p>
      )}

      {loading ? (
        <p className="text-[11px] text-[#355875]">Reading attached evidence…</p>
      ) : items.length === 0 ? (
        <p className="rounded border border-dashed border-sky-300 bg-white px-3 py-4 text-center text-[11px] text-[#355875]">
          No evidence attached yet. Attach the signed document that supports this transaction.
        </p>
      ) : (
        <ul className="divide-y divide-sky-100 rounded border border-sky-200 bg-white">
          {items.map((a) => (
            <li key={a.id} className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 text-[11px]">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 font-semibold text-[#0a253e]">
                  <Paperclip className="h-3 w-3 text-[#006f98]" />
                  <span className="truncate">{a.name}</span>
                </div>
                <div className="text-[10px] text-[#355875]">
                  {formatBytes(a.size)} · attached {new Date(a.addedAt).toLocaleDateString('en-GB')} by {a.addedBy}
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => {
                    void openAttachment(a.id).catch((e: unknown) =>
                      setError(e instanceof Error ? e.message : 'The attachment could not be opened.'),
                    );
                  }}
                  className="rounded border border-sky-300 bg-white px-2 py-1 font-bold text-[#082f4f] hover:bg-sky-50"
                >
                  <Download className="mr-1 inline h-3 w-3" /> Open
                </button>
                {canDelete && (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void remove(a.id, a.name)}
                    className="rounded border border-rose-300 bg-rose-50 px-2 py-1 font-bold text-rose-800 hover:bg-rose-100 disabled:opacity-50"
                  >
                    <Trash2 className="mr-1 inline h-3 w-3" /> Remove
                  </button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
