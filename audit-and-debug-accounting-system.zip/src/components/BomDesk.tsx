"use client";

import { useState } from "react";
import { AlertTriangle, ArrowRight, ListChecks, Trash2 } from "lucide-react";
import type { ClientEntity, StockItem, UserAccount } from "@/types/accounting";
import { useProduction } from "@/lib/productionClient";
import { plannedComponentQty } from "@/lib/productionRules";
import { Alert, EmptyState, Field, inputCls } from "./DeskKit";
import { Badge, Card, PageHeader, numCls, rowCls, tdCls, thCls } from "./ui";

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  stockItems: StockItem[];
  onNavigate: (section: string) => void;
}

/** One entity's approved materials recipe. This desk does not post journals. */
export function BomDesk({ currentClient, currentUser, stockItems, onNavigate }: Props) {
  const production = useProduction(currentClient.id);
  const readOnly = currentUser.role === "auditor" || currentUser.status !== "active";
  const [draft, setDraft] = useState({ parentItemCode: "", componentItemCode: "", qtyPerUnit: "", wastePct: "0" });
  const [planQty, setPlanQty] = useState(1);
  const [message, setMessage] = useState("");
  const finished = stockItems.filter((item) => item.category.toLowerCase().includes("finished"));
  const components = stockItems.filter((item) => !item.category.toLowerCase().includes("finished"));
  const existing = production.boms.find((b) => b.parentItemCode === draft.parentItemCode && b.componentItemCode === draft.componentItemCode);

  async function save() {
    const result = await production.run("save_bom", {
      parentItemCode: draft.parentItemCode, componentItemCode: draft.componentItemCode,
      qtyPerUnit: Number(draft.qtyPerUnit), wastePct: Number(draft.wastePct),
    });
    if (result.ok) {
      setMessage(`${existing ? "Updated" : "Added"} ${draft.componentItemCode} for ${draft.parentItemCode}.`);
      setDraft({ parentItemCode: draft.parentItemCode, componentItemCode: "", qtyPerUnit: "", wastePct: "0" });
    }
  }

  async function remove(parentItemCode: string, componentItemCode: string) {
    if (!window.confirm(`Remove ${componentItemCode} from the ${parentItemCode} BOM?`)) return;
    const result = await production.run("remove_bom", { parentItemCode, componentItemCode });
    if (result.ok) setMessage(`${componentItemCode} removed; the audit trail keeps the change.`);
  }

  return (
    <div className="space-y-4" data-desk="boms">
      <PageHeader
        kicker={`${currentClient.code} · Production master data`}
        title="Bill of Materials"
        desc="Specify the measured inputs per unit of finished output. Released work orders lock their BOM until completed; BOM changes never rewrite historical production postings."
      >
        <button type="button" onClick={() => onNavigate("inventory")} className="rounded-lg border border-sky-300 bg-white px-3 py-1.5 text-xs font-bold text-[#082f4f]">Item master →</button>
        <button type="button" onClick={() => onNavigate("production_desk")} className="flex items-center gap-1 rounded-lg bg-[#082f4f] px-3 py-1.5 text-xs font-bold text-white">Work orders <ArrowRight className="h-3 w-3" /></button>
      </PageHeader>
      {production.error && <Alert>{production.error}</Alert>}
      {message && <Alert tone="success">{message}</Alert>}
      {production.legacyCount > 0 && (
        <Alert tone="info"><AlertTriangle className="mr-1 inline h-3 w-3" />{production.legacyCount} legacy prototype production record(s) are retained separately. They never posted stock or journals; review the old records before relying on any historical production valuation. Only new controlled work orders affect the books.</Alert>
      )}
      <div className="grid gap-4 lg:grid-cols-[340px_1fr]">
        <Card title={existing ? "Update component quantity" : "Add component"} sub="One line per component per finished item; quantities up to three decimals.">
          {finished.length === 0 && <Alert tone="info">Add a stock item classified as “Finished Goods” in Inventory before defining a BOM.</Alert>}
          {components.length === 0 && <Alert tone="info">Add the raw materials to Inventory first. Opening quantities must be journal-backed.</Alert>}
          <div className="space-y-3">
            <Field label="Finished item">
              <select className={inputCls} value={draft.parentItemCode} onChange={(e) => setDraft({ ...draft, parentItemCode: e.target.value, componentItemCode: "", qtyPerUnit: "" })}>
                <option value="">Choose output…</option>
                {finished.map((item) => <option key={item.id} value={item.itemCode}>{item.itemCode} · {item.description}</option>)}
              </select>
            </Field>
            <Field label="Raw material / component">
              <select className={inputCls} value={draft.componentItemCode} onChange={(e) => {
                const b = production.boms.find((r) => r.parentItemCode === draft.parentItemCode && r.componentItemCode === e.target.value);
                setDraft({ ...draft, componentItemCode: e.target.value, qtyPerUnit: b ? String(b.qtyPerUnit) : "", wastePct: b ? String(b.wastePct) : "0" });
              }}>
                <option value="">Choose input…</option>
                {components.map((item) => <option key={item.id} value={item.itemCode}>{item.itemCode} · {item.description} ({item.uom})</option>)}
              </select>
            </Field>
            <div className="grid grid-cols-2 gap-2">
              <Field label="Qty per output unit"><input type="number" min="0.001" step="0.001" className={inputCls} value={draft.qtyPerUnit} onChange={(e) => setDraft({ ...draft, qtyPerUnit: e.target.value })} /></Field>
              <Field label="Normal waste %"><input type="number" min="0" max="100" step="0.01" className={inputCls} value={draft.wastePct} onChange={(e) => setDraft({ ...draft, wastePct: e.target.value })} /></Field>
            </div>
            <button type="button" disabled={readOnly || production.busy || !draft.parentItemCode || !draft.componentItemCode || !(Number(draft.qtyPerUnit) > 0)} onClick={() => void save()}
              className="w-full rounded-lg bg-[#082f4f] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">
              {production.busy ? "Saving…" : existing ? "Update BOM line" : "Add BOM line"}
            </button>
            <p className="text-[11px] text-[#355875]">Only a manager can release work orders. A released order cannot have its component quantities changed mid-run.</p>
          </div>
        </Card>
        <Card title="Approved material plan" sub="Plan = order quantity × component per unit × (1 + normal waste %). Normal waste is a planning allowance, not permission for unexplained losses." action={
          <label className="text-xs font-semibold text-[#355875]">Plan for <input type="number" min="0.001" step="0.001" className="ml-1 w-24 rounded border border-sky-300 bg-white p-1 text-right font-mono" value={planQty} onChange={(e) => setPlanQty(Math.max(0.001, Number(e.target.value) || 1))} /> output units</label>
        }>
          {production.loading ? <p className="text-xs text-[#355875]">Loading materials…</p> : production.boms.length === 0 ? (
            <EmptyState title="No materials plan yet" detail="Choose a finished item and add its component inputs. A work order cannot release without a BOM." />
          ) : (
            <div className="overflow-x-auto rounded-lg border border-sky-200">
              <table className="min-w-[660px] w-full">
                <thead><tr><th className={thCls}>Finished item</th><th className={thCls}>Component</th><th className={thCls}>Per unit</th><th className={thCls}>Waste</th><th className={thCls}>Plan required</th><th className={thCls}>On hand</th><th className={thCls}>Action</th></tr></thead>
                <tbody>{production.boms.map((b) => {
                  const component = components.find((item) => item.itemCode === b.componentItemCode);
                  const required = plannedComponentQty(planQty, b.qtyPerUnit, b.wastePct);
                  return (
                    <tr key={b.id} className={rowCls}>
                      <td className={tdCls}>{b.parentItemCode}</td>
                      <td className={tdCls}>{b.componentItemCode}<span className="block text-[10px] text-[#355875]">{component?.description ?? "Missing item master"}</span></td>
                      <td className={numCls}>{b.qtyPerUnit} {b.uom}</td>
                      <td className={numCls}>{b.wastePct}%</td>
                      <td className={numCls}>{required} {b.uom}</td>
                      <td className={numCls}><span className={component && component.quantityOnHand < required ? "text-rose-700 font-bold" : ""}>{component?.quantityOnHand ?? "—"}</span></td>
                      <td className={tdCls}><button type="button" disabled={readOnly || production.busy} onClick={() => void remove(b.parentItemCode, b.componentItemCode)} aria-label={`Remove ${b.componentItemCode}`} className="rounded border border-rose-200 p-1 text-rose-700 disabled:opacity-40"><Trash2 className="h-3 w-3" /></button></td>
                    </tr>
                  );
                })}</tbody>
              </table>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
