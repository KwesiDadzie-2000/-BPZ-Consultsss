import React, { useState } from 'react';
import { ClientEntity, AccountMaster, ACDOCALine, UserAccount } from '../types/accounting';
import type { CompanyProfile } from '../utils/persistentStorage';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { Plus, Search, FileSpreadsheet, Pencil, Trash2, Printer, Power, Undo2, X, Check, AlertCircle } from 'lucide-react';
import { printReport, downloadCsv } from '../utils/printReport';
import { toPrintEntity } from '../utils/printEntity';
import { chartEditDenialReason, mayEditChartOfAccounts } from '../utils/access';
import { getControlAccountDef } from '../utils/controlAccounts';

export type AccountScope = 'entity' | 'firm';

interface ChartOfAccountsSectionProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  accounts: AccountMaster[];
  lines: ACDOCALine[];
  profile?: CompanyProfile;
  onAddAccount: (acc: AccountMaster) => void;
  /** Edit an account; `scope` decides whether the change tailors this entity only or the firm master (owner). */
  onUpdateAccount: (acc: AccountMaster, scope: AccountScope) => { ok: boolean; error?: string };
  /** Remove an entity-owned row (custom account or tailoring). Master accounts cannot be removed. */
  onDeleteAccount: (accountNo: string) => { ok: boolean; error?: string };
}

type AccType = AccountMaster['type'];
const TYPES: AccType[] = ['Asset', 'Liability', 'Equity', 'Income', 'Expense'];
const defaultCategory: Record<AccType, string> = { Asset: 'Current Assets', Liability: 'Current Liabilities', Equity: 'Capital & Reserves', Income: 'Revenue', Expense: 'Operating Expenses' };

export const ChartOfAccountsSection: React.FC<ChartOfAccountsSectionProps> = ({
  currentClient,
  currentUser,
  accounts,
  lines,
  profile,
  onAddAccount,
  onUpdateAccount,
  onDeleteAccount,
}) => {
  const [filterType, setFilterType] = useState<string>('ALL');
  const [search, setSearch] = useState('');
  const [showInactive, setShowInactive] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [toast, setToast] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);
  const flash = (tone: 'ok' | 'err', text: string) => { setToast({ tone, text }); setTimeout(() => setToast(null), 6000); };

  // New account form
  const [accNo, setAccNo] = useState('');
  const [accName, setAccName] = useState('');
  const [accType, setAccType] = useState<AccType>('Asset');
  const [accCategory, setAccCategory] = useState('Current Assets');
  const [addError, setAddError] = useState<string | null>(null);

  // Edit form
  const [editing, setEditing] = useState<null | { original: AccountMaster; name: string; type: AccType; category: string; active: boolean; scope: AccountScope }>(null);
  const [editError, setEditError] = useState<string | null>(null);

  const isOwner = currentUser.role === 'owner';
  // Only the Firm Owner and the entity's own owner/manager may maintain account
  // names; staff roles keep full read and posting access.
  const canModify = mayEditChartOfAccounts(currentUser);
  const clientLines = lines.filter((l) => l.clientId === currentClient.id);

  // Live balances per account from the Universal Journal, signed in the account's normal direction.
  const typeOf = (no: string): AccType => accounts.find((a) => a.accountNo === no)?.type ?? (no.startsWith('1') ? 'Asset' : no.startsWith('2') ? 'Liability' : no.startsWith('3') ? 'Equity' : no.startsWith('4') ? 'Income' : 'Expense');
  const balances: Record<string, number> = {};
  const postings: Record<string, number> = {};
  clientLines.forEach((l) => {
    const drNormal = typeOf(l.accountNo) === 'Asset' || typeOf(l.accountNo) === 'Expense';
    balances[l.accountNo] = (balances[l.accountNo] || 0) + (drNormal ? l.debit - l.credit : l.credit - l.debit);
    postings[l.accountNo] = (postings[l.accountNo] || 0) + 1;
  });

  const filtered = accounts.filter((a) => {
    const matchType = filterType === 'ALL' || a.type === filterType;
    const q = search.toLowerCase();
    const matchSearch = a.accountNo.includes(search) || a.name.toLowerCase().includes(q) || a.category.toLowerCase().includes(q);
    return matchType && matchSearch && (showInactive || a.active);
  }).sort((a, b) => a.accountNo.localeCompare(b.accountNo));

  const ownedHere = (a: AccountMaster) => a.clientId === currentClient.id;
  const isTailoring = (a: AccountMaster) => ownedHere(a) && !a.isCustom;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const no = accNo.trim();
    if (!no || !accName.trim()) return;
    if (!/^\d{4,8}$/.test(no)) { setAddError('Account numbers are 4–8 digits (e.g. 650000).'); return; }
    if (accounts.some((a) => a.accountNo === no)) { setAddError(`Account ${no} already exists in this chart — edit it instead.`); return; }
    onAddAccount({ accountNo: no, name: accName.trim(), type: accType, category: accCategory.trim() || defaultCategory[accType], active: true, isCustom: true });
    flash('ok', `Account ${no} · ${accName.trim()} added to ${currentClient.code}'s chart.`);
    setShowModal(false); setAccNo(''); setAccName(''); setAddError(null);
  };

  const openEdit = (a: AccountMaster) => {
    if (!canModify) { flash('err', chartEditDenialReason(currentUser)); return; }
    setEditError(null);
    setEditing({ original: a, name: a.name, type: a.type, category: a.category, active: a.active, scope: 'entity' });
  };

  const saveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing) return;
    if (!editing.name.trim()) { setEditError('Enter the account title.'); return; }
    const res = onUpdateAccount({ ...editing.original, name: editing.name.trim(), type: editing.type, category: editing.category.trim() || defaultCategory[editing.type], active: editing.active }, editing.scope);
    if (!res.ok) { setEditError(res.error || 'The change was refused.'); return; }
    flash('ok', `Account ${editing.original.accountNo} updated${editing.scope === 'entity' && editing.original.clientId == null ? ` for ${currentClient.code} only` : editing.scope === 'firm' ? ' on the firm master chart (all entities)' : ''}.`);
    setEditing(null);
  };

  const toggleActive = (a: AccountMaster) => {
    if (!canModify) { flash('err', chartEditDenialReason(currentUser)); return; }
    const res = onUpdateAccount({ ...a, active: !a.active }, 'entity');
    flash(res.ok ? 'ok' : 'err', res.ok ? `Account ${a.accountNo} ${a.active ? 'deactivated' : 'reactivated'} for ${currentClient.code}.` : res.error || 'Refused.');
  };

  const remove = (a: AccountMaster) => {
    if (!canModify) return;
    const tailoring = isTailoring(a);
    if (!confirm(tailoring ? `Remove ${currentClient.code}'s tailoring of ${a.accountNo} and restore the firm master version?` : `Delete custom account ${a.accountNo} · ${a.name}? Only accounts without postings can be deleted.`)) return;
    const res = onDeleteAccount(a.accountNo);
    flash(res.ok ? 'ok' : 'err', res.ok ? (tailoring ? `Firm master version of ${a.accountNo} restored.` : `Account ${a.accountNo} deleted.`) : res.error || 'Refused.');
  };

  const handleExportCsv = () => {
    downloadCsv(`${currentClient.code}_Chart_of_Accounts.csv`, [
      ['AccountNo', 'AccountName', 'Classification', 'Category', 'ActiveStatus', 'Scope', 'Postings', 'CurrentBalance'],
      ...accounts.map((a) => [a.accountNo, a.name, a.type, a.category, a.active ? 'Active' : 'Inactive', a.clientId == null ? 'Firm master' : a.isCustom ? `${currentClient.code} custom` : `${currentClient.code} tailored`, postings[a.accountNo] || 0, balances[a.accountNo] || 0]),
    ]);
  };

  const handlePrint = () => {
    printReport({
      kicker: 'Chart of accounts', title: `Chart of Accounts — ${currentClient.name}`,
      subtitle: `${filtered.length} account(s)${filterType !== 'ALL' ? ` · ${filterType}` : ''}${search ? ` · search "${search}"` : ''} · live balances from the universal journal`,
      entity: toPrintEntity(currentClient, profile), periodLabel: `As at ${new Date().toISOString().slice(0, 10)}`, preparedBy: `${currentUser.name} (${currentUser.username})`,
      sections: TYPES.filter((t) => filtered.some((a) => a.type === t)).map((t) => ({
        title: t,
        columns: [{ key: 'no', label: 'Account', width: '12%' }, { key: 'name', label: 'Account title' }, { key: 'category', label: 'Category', width: '22%' }, { key: 'scope', label: 'Scope', width: '12%' }, { key: 'status', label: 'Status', width: '9%' }, { key: 'balance', label: 'Balance', align: 'right', width: '16%' }],
        rows: filtered.filter((a) => a.type === t).map((a) => ({ no: a.accountNo, name: a.name, category: a.category, scope: a.clientId == null ? 'Firm master' : a.isCustom ? 'Custom' : 'Tailored', status: a.active ? 'Active' : 'Inactive', balance: (balances[a.accountNo] || 0) === 0 ? '0.00' : `${formatGHS(Math.abs(balances[a.accountNo]))} ${(balances[a.accountNo] > 0) === (t === 'Asset' || t === 'Expense') ? 'Dr' : 'Cr'}` })),
      })),
    });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`COA · General Ledger Master · ${currentClient.code}`}
        title="Chart of Accounts Master"
        desc={isOwner
          ? 'Standard IFRS chart of accounts with real-time balances from the Universal Journal. As the firm owner you can tailor any account for this client (rename, re-categorise, deactivate) without affecting other entities, or change the firm master for all entities.'
          : 'Standard IFRS chart of accounts with real-time balances from the Universal Journal. Add customized nominal accounts tailored to your business operations, rename them or deactivate accounts you do not use.'}
      >
        <div className="flex flex-wrap gap-2">
          <button onClick={handleExportCsv} className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs">
            <FileSpreadsheet className="h-4 w-4 text-emerald-700" /><span>Export COA (CSV)</span>
          </button>
          <button onClick={handlePrint} className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs">
            <Printer className="h-4 w-4" /><span>Print chart</span>
          </button>
          {canModify ? (
            <button onClick={() => { setAddError(null); setShowModal(true); }} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs">
              <Plus className="h-4 w-4" /><span>Add GL Account</span>
            </button>
          ) : (
            <span className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-[11px] font-bold text-[#855b00]">Read-only · {chartEditDenialReason(currentUser)}</span>
          )}
        </div>
      </PageHeader>

      {toast && (
        <div role="status" className={`rounded-lg border p-3 text-xs font-bold flex items-center gap-2 ${toast.tone === 'ok' ? 'border-emerald-300 bg-emerald-50 text-emerald-900' : 'border-rose-300 bg-rose-50 text-rose-900'}`}>
          {toast.tone === 'ok' ? <Check className="h-4 w-4 shrink-0" /> : <AlertCircle className="h-4 w-4 shrink-0" />}<span>{toast.text}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-white p-3 rounded-xl border border-sky-200 shadow-xs">
        <div className="flex flex-wrap items-center gap-1">
          {['ALL', ...TYPES].map((t) => (
            <button key={t} onClick={() => setFilterType(t)} className={`px-3 py-1.5 rounded-lg font-bold transition ${filterType === t ? 'bg-[#082f4f] text-white shadow-xs' : 'bg-sky-50 text-[#355875] hover:bg-sky-100'}`}>
              {t === 'ALL' ? 'All Accounts' : t}
            </button>
          ))}
          <label className="ml-2 flex items-center gap-1.5 font-semibold text-[#355875]"><input type="checkbox" checked={showInactive} onChange={(e) => setShowInactive(e.target.checked)} /> Show inactive</label>
        </div>
        <div className="relative">
          <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-sky-400" />
          <input type="text" placeholder="Search account no or name..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-56 sm:w-64 rounded-lg border border-sky-300 bg-white pl-8 pr-3 py-1.5 text-xs text-[#082f4f] outline-none focus:border-[#082f4f]" />
        </div>
      </div>

      {/* Accounts Master Table */}
      <Card title={`Nominal Ledger Accounts (${filtered.length} Accounts)`} sub={`Mapped to financial statements and universal journals · ${accounts.filter(ownedHere).length} account(s) owned or tailored by ${currentClient.code}`}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[860px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Account No</th>
                <th className={thCls}>GL Account Name</th>
                <th className={thCls}>Classification</th>
                <th className={thCls}>Category Group</th>
                <th className={thCls + " text-right"}>Live Ledger Balance (₵)</th>
                <th className={thCls}>Status</th>
                {canModify && <th className={thCls + ' text-center'}>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {filtered.map((a) => {
                const bal = balances[a.accountNo] || 0;
                const drNormal = a.type === 'Asset' || a.type === 'Expense';
                const used = (postings[a.accountNo] || 0) > 0;
                return (
                  <tr key={`${a.accountNo}-${a.clientId ?? 'm'}`} className={rowCls + (a.active ? '' : ' opacity-60')}>
                    <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{a.accountNo}</td>
                    <td className="px-3 py-2 font-bold text-[#082f4f]">
                      {a.name}
                      {(() => {
                        const ctl = getControlAccountDef(a.accountNo);
                        return ctl ? (
                          <span
                            className="ml-1.5 rounded border border-sky-300 bg-sky-100 text-[#082f4f] px-1.5 py-0.2 text-[9.5px] font-mono font-bold"
                            title={`Subledger Control Account: ${ctl.subledgerLabel}`}
                          >
                            CONTROL · {ctl.subledgerFamily.toUpperCase()}
                          </span>
                        ) : null;
                      })()}
                      {a.isCustom && <span className="ml-1.5 rounded bg-amber-100 text-[#855b00] px-1.5 py-0.2 text-[9.5px] font-mono">Custom</span>}
                      {isTailoring(a) && <span className="ml-1.5 rounded bg-purple-100 text-[#6d3fb3] px-1.5 py-0.2 text-[9.5px] font-mono" title="Tailored for this entity — the firm master version is unchanged">Tailored · {currentClient.code}</span>}
                    </td>
                    <td className="px-3 py-2">
                      <span className={`rounded px-2 py-0.5 text-[10.5px] font-bold ${a.type === 'Asset' ? 'bg-sky-100 text-[#006f98]' : a.type === 'Liability' ? 'bg-amber-100 text-[#855b00]' : a.type === 'Equity' ? 'bg-purple-100 text-[#6d3fb3]' : a.type === 'Income' ? 'bg-emerald-100 text-[#087a55]' : 'bg-rose-100 text-[#b42318]'}`}>{a.type}</span>
                    </td>
                    <td className="px-3 py-2 text-[#355875]">{a.category}</td>
                    <td className={numCls + " font-mono font-bold text-[#082f4f]"}>
                      {bal !== 0 ? formatGHS(Math.abs(bal)) : '0.00'}
                      {bal !== 0 && <span className="ml-1 text-[10px] text-[#355875]">{(bal > 0) === drNormal ? 'Dr' : 'Cr'}</span>}
                      {used && <span className="block text-[9.5px] font-normal text-[#355875]">{postings[a.accountNo]} posting(s)</span>}
                    </td>
                    <td className="px-3 py-2">
                      <span className={`rounded px-2 py-0.5 text-[10.5px] font-bold ${a.active ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'}`}>{a.active ? 'Active' : 'Inactive'}</span>
                    </td>
                    {canModify && (
                      <td className="px-2 py-1.5">
                        <div className="flex items-center justify-center gap-1">
                          <button title="Edit account" onClick={() => openEdit(a)} className="rounded border border-sky-300 bg-white p-1 text-[#082f4f] hover:bg-sky-50"><Pencil className="h-3.5 w-3.5" /></button>
                          <button title={a.active ? 'Deactivate for this entity' : 'Reactivate'} onClick={() => toggleActive(a)} className={`rounded border bg-white p-1 ${a.active ? 'border-amber-300 text-[#855b00] hover:bg-amber-50' : 'border-emerald-300 text-emerald-700 hover:bg-emerald-50'}`}><Power className="h-3.5 w-3.5" /></button>
                          {ownedHere(a) && (isTailoring(a)
                            ? <button title="Restore firm master version" onClick={() => remove(a)} className="rounded border border-purple-300 bg-white p-1 text-[#6d3fb3] hover:bg-purple-50"><Undo2 className="h-3.5 w-3.5" /></button>
                            : <button title={used ? 'Cannot delete — account has postings (deactivate instead)' : 'Delete custom account'} disabled={used} onClick={() => remove(a)} className="rounded border border-rose-300 bg-white p-1 text-rose-700 hover:bg-rose-50 disabled:opacity-30"><Trash2 className="h-3.5 w-3.5" /></button>)}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* New GL Account Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleCreate} className="w-full max-w-md rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Create New GL Account</h3>
            <div className="space-y-3">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Account Number</label>
                <input type="text" placeholder="e.g. 502000, 650000" value={accNo} onChange={(e) => setAccNo(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono font-bold text-[#082f4f]" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Account Title / Description</label>
                <input type="text" placeholder="e.g. Machinery Maintenance Expenses" value={accName} onChange={(e) => setAccName(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]" required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Account Type</label>
                  <select value={accType} onChange={(e) => { const t = e.target.value as AccType; setAccType(t); setAccCategory(defaultCategory[t]); }} className="w-full rounded border border-sky-300 px-2 py-2 outline-none font-bold text-[#082f4f]">
                    {TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Subcategory</label>
                  <input type="text" value={accCategory} onChange={(e) => setAccCategory(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-2 outline-none text-[#082f4f]" required />
                </div>
              </div>
              <p className="text-[11px] text-[#2d4f6d]">The account is created for <b>{currentClient.code}</b> only and is immediately available for posting in every desk.</p>
            </div>
            {addError && <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 p-2.5 font-bold text-rose-900">{addError}</div>}
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setShowModal(false)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 font-bold text-white">Save Account</button>
            </div>
          </form>
        </div>
      )}

      {/* Edit / tailor account modal */}
      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={saveEdit} className="w-full max-w-lg rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs">
            <div className="flex items-start justify-between gap-3 border-b border-sky-100 pb-2">
              <div>
                <h3 className="text-base font-bold text-[#082f4f]">Edit account <span className="font-mono text-[#855b00]">{editing.original.accountNo}</span></h3>
                <p className="text-[11px] text-[#2d4f6d]">{editing.original.clientId == null ? 'Firm master account shared by all entities.' : editing.original.isCustom ? `Custom account owned by ${currentClient.code}.` : `Tailored for ${currentClient.code}; the firm master version is unchanged.`}</p>
              </div>
              <button type="button" onClick={() => setEditing(null)} className="rounded border border-sky-200 p-1 text-[#355875] hover:bg-sky-50"><X className="h-4 w-4" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Account Title / Description</label>
                <input type="text" value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]" required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Account Type</label>
                  <select value={editing.type} onChange={(e) => setEditing({ ...editing, type: e.target.value as AccType })} className="w-full rounded border border-sky-300 px-2 py-2 outline-none font-bold text-[#082f4f]">
                    {TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                  {(postings[editing.original.accountNo] || 0) > 0 && editing.type !== editing.original.type && <p className="mt-1 text-[10.5px] text-amber-800">This account has postings — changing its type reclassifies them in every report.</p>}
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Subcategory</label>
                  <input type="text" value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })} className="w-full rounded border border-sky-300 px-3 py-2 outline-none text-[#082f4f]" required />
                </div>
              </div>
              <label className="flex items-center gap-2 font-bold text-[#0a253e]"><input type="checkbox" checked={editing.active} onChange={(e) => setEditing({ ...editing, active: e.target.checked })} /> Active (available for posting)</label>
              {isOwner && editing.original.clientId == null && (
                <fieldset className="rounded-lg border border-sky-200 p-3 space-y-2">
                  <legend className="px-1 font-bold text-[#355875]">Apply change to</legend>
                  <label className="flex items-start gap-2"><input type="radio" name="scope" checked={editing.scope === 'entity'} onChange={() => setEditing({ ...editing, scope: 'entity' })} /><span><b>This entity only ({currentClient.code})</b> — tailors the account for this client&apos;s suitability; other entities keep the firm master version.</span></label>
                  <label className="flex items-start gap-2"><input type="radio" name="scope" checked={editing.scope === 'firm'} onChange={() => setEditing({ ...editing, scope: 'firm' })} /><span><b>Firm master (all entities)</b> — changes the shared account everywhere it is not already tailored.</span></label>
                </fieldset>
              )}
              {!isOwner && editing.original.clientId == null && <p className="text-[11px] text-[#2d4f6d]">Your change applies to <b>{currentClient.code}</b> only; the firm master chart is maintained by the Firm Owner.</p>}
            </div>
            {editError && <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 p-2.5 font-bold text-rose-900">{editError}</div>}
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setEditing(null)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 font-bold text-white">Save changes</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
