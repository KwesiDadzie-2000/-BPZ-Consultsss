'use client';

/**
 * IFRS compliance review and system readiness.
 *
 * Two jobs in one desk:
 *   1. fish out what is wrong in the books right now — control checks computed
 *      from the live journal (unbalanced documents, one-sided entries, unknown
 *      accounts, missing comparatives, unprovided tax, cash-flow residuals);
 *   2. say plainly what is still missing before these books can stand next to a
 *      global-standard accounting system, with the standard that requires it
 *      and the remediation that closes it.
 *
 * The whole review prints as an audit working paper.
 */

import { useMemo, useState } from 'react';
import { localToday } from '@/utils/periods';
import { Printer, ShieldAlert, CheckCircle2, AlertTriangle, FileWarning, ArrowRight } from 'lucide-react';
import type { AccountMaster, ACDOCALine, ClientEntity, UserAccount } from '@/types/accounting';
import { buildIfrsPack, type ControlCheck, type GapItem } from '@/utils/ifrsPack';
import { printReport, type PrintSection } from '@/utils/printReport';
import { toPrintEntity } from '@/utils/printEntity';
import { persistentStorage } from '@/utils/persistentStorage';

type Filter = 'all' | 'critical' | 'warning' | 'pass';
type GapFilter = 'all' | 'High' | 'Medium' | 'Low';

/** What a complete, globally comparable accounting system still needs. */
const ROADMAP: Array<{ area: string; standard: string; priority: 'Now' | 'Next' | 'Later'; detail: string }> = [
  {
    area: 'Automated bank reconciliation',
    standard: 'IFRS 9 / internal control',
    priority: 'Now',
    detail: 'Import bank statements (MT940 / CSV) and match them against the cash ledger automatically, with an exception queue. Manual reconciliation is the single largest source of undetected error in a growing ledger.',
  },
  {
    area: 'Expected credit loss engine',
    standard: 'IFRS 9.5.5',
    priority: 'Now',
    detail: 'A lifetime ECL provision matrix on trade receivables, recalculated monthly from ageing with forward-looking overlays, posted automatically as an adjusting journal.',
  },
  {
    area: 'Fixed asset register automation',
    standard: 'IAS 16.73',
    priority: 'Now',
    detail: 'Component-level registers with automatic depreciation runs, revaluation and disposal gain/loss calculation, reconciled to the general ledger each period.',
  },
  {
    area: 'Lease register and IFRS 16 measurement',
    standard: 'IFRS 16.26',
    priority: 'Now',
    detail: 'Lease contracts with payment schedules, incremental borrowing rates, and scheduled right-of-use amortisation and interest postings.',
  },
  {
    area: 'Period lock and audit trail',
    standard: 'SOX / ISA 240',
    priority: 'Now',
    detail: 'Immutable, attributed change history for every posted document (who, when, what, before/after), enforced period locking after the month-end close, and export of the audit trail with the accounts.',
  },
  {
    area: 'Multi-currency and IAS 21 revaluation',
    standard: 'IAS 21',
    priority: 'Next',
    detail: 'Transaction-date rates, closing-rate revaluation of monetary items, and translation of foreign operations into the presentation currency with the movement taken to OCI.',
  },
  {
    area: 'Budgeting, forecasting and variance analysis',
    standard: 'Management reporting',
    priority: 'Next',
    detail: 'Budget versions by cost centre, rolling forecasts and variance analysis with commentary — the layer that turns a ledger into a decision system.',
  },
  {
    area: 'Group consolidation and intragroup elimination',
    standard: 'IFRS 10 / IFRS 3',
    priority: 'Next',
    detail: 'Automated elimination of intragroup balances and transactions, goodwill and non-controlling interest measurement, and a consolidation journal with a full audit trail.',
  },
  {
    area: 'Tax provision and deferred tax engine',
    standard: 'IAS 12',
    priority: 'Next',
    detail: 'Temporary-difference tracking, deferred tax recognition on losses and accelerated capital allowances, and the effective tax rate reconciliation required by IAS 12.81.',
  },
  {
    area: 'Digital filing — iXBRL tagging',
    standard: 'ESEF / IFRS Taxonomy',
    priority: 'Later',
    detail: 'Map every statement caption to an IFRS taxonomy element so the statutory pack can be exported as Inline XBRL for regulator filing.',
  },
  {
    area: 'Role-based approvals and segregation of duties',
    standard: 'SOX 404 / ICFR',
    priority: 'Now',
    detail: 'Maker–checker on every journal above a threshold, delegated authority matrices, and approval evidence retained with the document.',
  },
  {
    area: 'Statutory registers and filings calendar',
    standard: 'Companies Act / GRA',
    priority: 'Next',
    detail: 'Share register, director register, statutory returns calendar with deadlines and penalties, and one-click generation of the returns from the ledger.',
  },
  {
    area: 'Data retention, backup and disaster recovery',
    standard: 'ISA 230 / GDPR',
    priority: 'Later',
    detail: 'Point-in-time recovery, tested restores, retention schedules for accounting records (typically 6–10 years) and personal-data controls over payroll records.',
  },
  {
    area: 'Open API and third-party integration',
    standard: 'Interoperability',
    priority: 'Later',
    detail: 'Versioned REST/webhook API for payroll, POS, e-commerce and banking connectors, so the ledger is the single source of truth.',
  },
];

export function ComplianceReviewDesk({
  currentClient,
  currentUser,
  lines,
  accounts,
  onNavigate,
}: {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  onNavigate?: (section: string) => void;
}) {
  const [checkFilter, setCheckFilter] = useState<Filter>('all');
  const today = localToday();
  const [gapFilter, setGapFilter] = useState<GapFilter>('all');

  const pack = useMemo(
    () =>
      buildIfrsPack({
        lines: lines.filter((l) => l.clientId === currentClient.id),
        accounts,
        from: fiscalYearStart(currentClient.id),
        through: today,
        currency: currentClient.currency,
        entityName: currentClient.name,
        entityCode: currentClient.code,
        jurisdiction: currentClient.jurisdiction,
        regNumber: currentClient.regNumber,
        sector: currentClient.sector,
      }),
    [lines, accounts, currentClient],
  );

  const remediationLinks: Record<string, { section: string; label: string }> = {
    'Automated bank reconciliation': { section: 'banking', label: 'Open Banking & Reconcile' },
    'Expected credit loss engine': { section: 'ifrs_schedules', label: 'Open IFRS ECL schedules' },
    'Fixed asset register automation': { section: 'assets', label: 'Open Fixed Assets Register' },
    'Lease register and IFRS 16 measurement': { section: 'ifrs_schedules', label: 'Open IFRS lease schedules' },
    'Period lock and audit trail': { section: 'month_end', label: 'Open Month-End Close' },
    'Budgeting, forecasting and variance analysis': { section: 'performance', label: 'Open Performance Management' },
    'Tax provision and deferred tax engine': { section: 'ifrs_schedules', label: 'Open IAS 12 schedules' },
    'Role-based approvals and segregation of duties': { section: 'user_permissions', label: 'Open User Access' },
    'Statutory registers and filings calendar': { section: 'tax_schedule', label: 'Open Tax & Statutory Returns' },
  };

  const checks = pack.checks;
  const gaps = pack.gaps;
  const critical = checks.filter((c) => c.severity === 'critical');
  const warnings = checks.filter((c) => c.severity === 'warning');
  const clear = checks.filter((c) => c.severity === 'pass');
  const highGaps = gaps.filter((g) => g.severity === 'High' && g.status !== 'Implemented');
  const score = checks.length ? Math.round((clear.length / checks.length) * 100) : 0;

  const visibleChecks: ControlCheck[] = checks.filter((c) => checkFilter === 'all' || c.severity === checkFilter);
  const visibleGaps: GapItem[] = gaps.filter((g) => gapFilter === 'all' || g.severity === gapFilter);

  const print = () => {
    const entity = toPrintEntity(currentClient, persistentStorage.getCompanyProfiles()[currentClient.id]);
    const sections: PrintSection[] = [
      {
        title: '1 · Control checks against the posted ledger',
        columns: [
          { key: 'status', label: 'Status', width: '10%' },
          { key: 'title', label: 'Check', width: '30%' },
          { key: 'standard', label: 'Standard', width: '13%' },
          { key: 'detail', label: 'Finding' },
          { key: 'action', label: 'Action required' },
        ],
        rows: checks.map((c) => ({
          status: c.severity === 'pass' ? 'Clear' : c.severity === 'critical' ? 'CRITICAL' : 'Review',
          title: c.title,
          standard: c.standard,
          detail: c.detail,
          action: c.action,
        })),
        note: `${clear.length} of ${checks.length} checks clear.`,
      },
      {
        title: '2 · IFRS gap register',
        columns: [
          { key: 'standard', label: 'Standard', width: '12%' },
          { key: 'area', label: 'Area', width: '18%' },
          { key: 'severity', label: 'Severity', width: '10%' },
          { key: 'status', label: 'Status', width: '11%' },
          { key: 'why', label: 'Why it matters' },
          { key: 'remedy', label: 'Remediation' },
        ],
        rows: gaps.map((g) => ({ ...g })),
      },
      {
        title: '3 · Roadmap to a globally comparable accounting system',
        columns: [
          { key: 'priority', label: 'Priority', width: '10%' },
          { key: 'area', label: 'Capability', width: '22%' },
          { key: 'standard', label: 'Standard', width: '16%' },
          { key: 'detail', label: 'What to build' },
        ],
        rows: ROADMAP.map((r) => ({ ...r })),
      },
      {
        title: '4 · IAS 1.10 completeness of the financial statements',
        columns: [
          { key: 'requirement', label: 'Requirement', width: '30%' },
          { key: 'standard', label: 'Standard', width: '14%' },
          { key: 'status', label: 'Status', width: '12%' },
          { key: 'detail', label: 'Basis' },
        ],
        rows: pack.checklist.map((c) => ({ ...c })),
      },
    ];
    printReport({
      title: 'IFRS compliance review and system readiness',
      kicker: 'Audit working paper · control checks · gap register · remediation roadmap',
      subtitle: `${currentClient.name} — review performed ${today}`,
      entity,
      periodLabel: `Books through ${today}`,
      preparedBy: `${currentUser.name} (${currentUser.username})`,
      stats: [
        { label: 'Controls clear', value: `${clear.length}/${checks.length}` },
        { label: 'Critical findings', value: critical.length },
        { label: 'Open IFRS gaps', value: gaps.filter((g) => g.status === 'Gap').length },
        { label: 'Readiness score', value: `${score}%` },
      ],
      sections,
      footerNote: 'This review is derived from the ledger held in the system. It is a working paper for management and the external auditor.',
    });
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-4 rounded-lg border border-sky-200 bg-white p-5">
        <div>
          <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#855b00]">IFRS · Internal control · Completeness</div>
          <h2 className="mt-1 text-2xl font-black tracking-tight text-[#082f4f]">Compliance review &amp; system readiness</h2>
          <p className="mt-1.5 max-w-[76ch] text-[11.5px] leading-relaxed text-[#2d4f6d]">
            Live control checks computed from {currentClient.name}’s posted journal, the IFRS gap register that stands between these
            books and a set of statements an international auditor would sign without qualification, and the roadmap of the
            capabilities a globally comparable accounting system must still have.
          </p>
        </div>
        <button
          onClick={print}
          className="flex items-center gap-2 rounded bg-[#082f4f] px-4 py-2 text-xs font-bold text-white transition hover:bg-[#0c3f68] active:translate-y-px"
        >
          <Printer className="h-3.5 w-3.5" /> Print review
        </button>
      </div>

      {/* Score strip */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-lg border border-sky-200 bg-white p-4">
          <div className="text-[10px] font-bold uppercase tracking-wider text-[#2d4f6d]">Readiness score</div>
          <div className="mt-1 flex items-end gap-2">
            <span className="font-mono text-3xl font-extrabold tabular-nums text-[#082f4f]">{score}%</span>
            <span className="mb-1 text-[10px] text-[#355875]">of controls clear</span>
          </div>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded bg-sky-100">
            <div className="h-full rounded bg-[#082f4f] transition-all" style={{ width: `${score}%` }} />
          </div>
        </div>
        <div className="rounded-lg border border-rose-200 bg-rose-50 p-4">
          <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-rose-800">
            <FileWarning className="h-3.5 w-3.5" /> Critical findings
          </div>
          <div className="mt-1 font-mono text-3xl font-extrabold tabular-nums text-rose-900">{critical.length}</div>
          <div className="mt-1 text-[10.5px] text-rose-800">{critical.length ? critical[0].title : 'Nothing blocks issue of the statements.'}</div>
        </div>
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
          <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-[#8a5d00]">
            <AlertTriangle className="h-3.5 w-3.5" /> Items to review
          </div>
          <div className="mt-1 font-mono text-3xl font-extrabold tabular-nums text-[#7a4c00]">{warnings.length}</div>
          <div className="mt-1 text-[10.5px] text-[#7a4c00]">Measurements and disclosures that management must confirm.</div>
        </div>
        <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4">
          <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-emerald-800">
            <CheckCircle2 className="h-3.5 w-3.5" /> High-priority gaps
          </div>
          <div className="mt-1 font-mono text-3xl font-extrabold tabular-nums text-emerald-900">{highGaps.length}</div>
          <div className="mt-1 text-[10.5px] text-emerald-800">Standards with material requirements still unmet.</div>
        </div>
      </div>

      {/* Control checks */}
      <section className="rounded-lg border border-sky-200 bg-white">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-sky-100 bg-[#f7fbff] px-4 py-3">
          <div>
            <h3 className="text-sm font-bold text-[#0a253e]">Control checks — computed from the posted journal</h3>
            <p className="mt-0.5 text-xs text-[#2d4f6d]">These run every time the desk is opened, so a bug in the books cannot hide.</p>
          </div>
          <div className="flex gap-1.5">
            {(['all', 'critical', 'warning', 'pass'] as Filter[]).map((f) => (
              <button
                key={f}
                onClick={() => setCheckFilter(f)}
                className={`rounded px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-wider transition ${
                  checkFilter === f ? 'bg-[#082f4f] text-white' : 'border border-sky-200 bg-white text-[#163653] hover:bg-sky-50'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </header>
        <div className="divide-y divide-sky-100">
          {visibleChecks.map((c) => (
            <div key={c.id} className="flex flex-wrap items-start gap-3 px-4 py-3">
              <span
                className={`mt-0.5 rounded px-2 py-0.5 text-[9.5px] font-bold uppercase tracking-wider ${
                  c.severity === 'pass' ? 'bg-emerald-100 text-emerald-800' : c.severity === 'critical' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-[#8a5d00]'
                }`}
              >
                {c.severity === 'pass' ? 'Clear' : c.severity === 'critical' ? 'Critical' : 'Review'}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-baseline gap-2">
                  <h4 className="text-[12.5px] font-bold text-[#0a253e]">{c.title}</h4>
                  <span className="font-mono text-[9.5px] font-bold uppercase tracking-wider text-[#855b00]">{c.standard}</span>
                  <span className="rounded bg-sky-100 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-[#355875]">{c.area}</span>
                </div>
                <p className="mt-1 text-[11px] text-[#2d4f6d]">{c.detail}</p>
                <p className="mt-0.5 flex items-start gap-1 text-[11px] italic text-[#355875]">
                  <ArrowRight className="mt-0.5 h-3 w-3 shrink-0" /> {c.action}
                </p>
              </div>
            </div>
          ))}
          {visibleChecks.length === 0 && (
            <div className="px-4 py-8 text-center text-xs italic text-[#355875]">No checks in this category.</div>
          )}
        </div>
      </section>

      {/* Gap register */}
      <section className="rounded-lg border border-sky-200 bg-white">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-sky-100 bg-[#f7fbff] px-4 py-3">
          <div>
            <h3 className="text-sm font-bold text-[#0a253e]">IFRS gap register — what is missing</h3>
            <p className="mt-0.5 text-xs text-[#2d4f6d]">Each entry names the standard, why it matters and the work that closes it.</p>
          </div>
          <div className="flex gap-1.5">
            {(['all', 'High', 'Medium', 'Low'] as GapFilter[]).map((f) => (
              <button
                key={f}
                onClick={() => setGapFilter(f)}
                className={`rounded px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-wider transition ${
                  gapFilter === f ? 'bg-[#082f4f] text-white' : 'border border-sky-200 bg-white text-[#163653] hover:bg-sky-50'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </header>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className="px-3 py-2 text-[9.5px] font-bold uppercase tracking-[0.12em] text-[#355875]">Standard</th>
                <th className="px-3 py-2 text-[9.5px] font-bold uppercase tracking-[0.12em] text-[#355875]">Area</th>
                <th className="px-3 py-2 text-[9.5px] font-bold uppercase tracking-[0.12em] text-[#355875]">Severity</th>
                <th className="px-3 py-2 text-[9.5px] font-bold uppercase tracking-[0.12em] text-[#355875]">Status</th>
                <th className="px-3 py-2 text-[9.5px] font-bold uppercase tracking-[0.12em] text-[#355875]">Why it matters</th>
                <th className="px-3 py-2 text-[9.5px] font-bold uppercase tracking-[0.12em] text-[#355875]">Remediation</th>
              </tr>
            </thead>
            <tbody>
              {visibleGaps.map((g) => (
                <tr key={`${g.standard}-${g.area}`} className="border-b border-sky-100 align-top hover:bg-sky-50/50">
                  <td className="px-3 py-2 font-mono text-[10.5px] font-bold text-[#082f4f]">{g.standard}</td>
                  <td className="px-3 py-2 text-[11px] font-semibold text-[#0a253e]">{g.area}</td>
                  <td className="px-3 py-2">
                    <span
                      className={`rounded px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider ${
                        g.severity === 'High' ? 'bg-rose-100 text-rose-800' : g.severity === 'Medium' ? 'bg-amber-100 text-[#8a5d00]' : 'bg-sky-100 text-[#355875]'
                      }`}
                    >
                      {g.severity}
                    </span>
                  </td>
                  <td className="px-3 py-2">
                    <span
                      className={`rounded px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider ${
                        g.status === 'Implemented' ? 'bg-emerald-100 text-emerald-800' : g.status === 'Partial' ? 'bg-amber-100 text-[#8a5d00]' : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {g.status}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-[10.5px] leading-relaxed text-[#2d4f6d]">{g.why}</td>
                  <td className="px-3 py-2 text-[10.5px] leading-relaxed text-[#355875]">{g.remedy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Roadmap */}
      <section className="rounded-lg border border-sky-200 bg-white">
        <header className="border-b border-[#c9bfac] px-4 py-3">
          <div className="flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 text-[#a8341f]" />
            <h3 className="text-sm font-bold text-[#0e3b2e]">Advisory — what it takes to compete with global-standard accounting systems</h3>
          </div>
          <p className="mt-1 text-[11px] leading-relaxed text-[#4b4638]">
            The financial statements in this system are already IAS 1-compliant. What separates a competent ledger from a system an
            international group would standardise on is the machinery around the ledger: automated matching, measurement engines,
            controls, and machine-readable filing. Listed in the order the practice should build them.
          </p>
        </header>
        <div className="grid gap-3 p-4 md:grid-cols-2">
          {ROADMAP.map((r) => (
            <article key={r.area} className="rounded border border-[#e0d5c2] bg-white p-3.5">
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={`rounded px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-[0.12em] ${
                    r.priority === 'Now' ? 'bg-rose-100 text-rose-800' : r.priority === 'Next' ? 'bg-amber-100 text-[#7a4c00]' : 'bg-sky-100 text-[#2d4f6d]'
                  }`}
                >
                  {r.priority}
                </span>
                <h4 className="text-[12px] font-bold text-[#221f1a]">{r.area}</h4>
                <span className="ml-auto font-mono text-[9px] font-bold uppercase tracking-[0.12em] text-[#a8341f]">{r.standard}</span>
              </div>
              <p className="mt-1.5 text-[10.5px] leading-relaxed text-[#4b4638]">{r.detail}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}

/** First day of the entity's fiscal year in the current calendar year. */
function fiscalYearStart(clientId: number): string {
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const profiles = persistentStorage.getCompanyProfiles();
  const fy = profiles[clientId]?.fiscalYearStart || 'January';
  const idx = Math.max(0, MONTHS.indexOf(fy));
  const year = new Date().getFullYear();
  return `${year}-${String(idx + 1).padStart(2, '0')}-01`;
}
