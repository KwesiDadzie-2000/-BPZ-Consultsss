import React, { useMemo, useState } from 'react';
import type {
  ACDOCALine,
  AccountMaster,
  BankAccount,
  ClientEntity,
  FixedAsset,
  SalesInvoice,
  UserAccount,
} from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import {
  Calculator,
  Plus,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  Save,
  Trash2,
} from 'lucide-react';
import { currentYear, nextDocNo, uniqueId } from '../utils/ids';
import { contractPositionMovement } from '../utils/contractPosition';
import { ScheduleActions } from './ScheduleActions';
import { localToday } from '../utils/periods';
import { persistentStorage } from '../utils/persistentStorage';
import { useWorkbooks } from '@/lib/workbookClient';
import {
  addMonths,
  computeLease,
  leaseLiabilityAt,
  receivablesAgeing,
  r2,
} from '../utils/ifrsSchedules';

interface ComprehensiveStandardsDeskProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines?: ACDOCALine[];
  accounts?: AccountMaster[];
  assets?: FixedAsset[];
  invoices?: SalesInvoice[];
  bankAccounts?: BankAccount[];
  onAddJournalLines: (
    lines: ACDOCALine[],
    docCurrency?: string,
    expectedClientId?: number,
    onRejected?: () => void,
    options?: { syncBankFromGl?: boolean },
  ) => boolean | void;
  onSaveAssets?: (next: FixedAsset[]) => void;
  onBankBalanceChange?: (bankId: number, delta: number) => void;
  onApprovalSubmitted?: () => void;
  onNavigateSection?: (section: string) => void;
}

export type StandardTab =
  | 'overview'
  | 'ifrs15_contracts'
  | 'ifrs16_leases'
  | 'ias36_impairment'
  | 'ias37_provisions'
  | 'ifrs9_instruments'
  | 'ifrs5_hfs';

interface Ifrs15Contract {
  id: string;
  code: string;
  customer: string;
  description: string;
  contractValue: number;
  totalEstimatedCost: number;
  actualCostIncurred: number;
  billedToDate: number;
}

interface Ifrs16LeaseRecord {
  id: string;
  code: string;
  lessor: string;
  description: string;
  commencement: string;
  termMonths: number;
  monthlyPayment: number;
  discountRate: number;
  initialDirectCosts: number;
  timing: 'advance' | 'arrears';
}

interface Ias36CguTest {
  id: string;
  cguName: string;
  carryingAmount: number;
  cashFlows: number[];
  terminalGrowthPct: number;
  discountRatePct: number;
  fairValueLessCosts: number;
}

interface Ias37ProvisionRecord {
  id: string;
  code: string;
  title: string;
  category: string;
  bestEstimate: number;
  probability: number;
  discountRate: number;
  yearsToSettlement: number;
  currentCarrying: number;
}

interface IfrsDeskWorkbookPayload {
  contracts: Ifrs15Contract[];
  leases: Ifrs16LeaseRecord[];
  cguTests: Ias36CguTest[];
  provisions: Ias37ProvisionRecord[];
  eclRates: number[];
  eclTermsDays: number;
}

const DEFAULT_PAYLOAD: IfrsDeskWorkbookPayload = {
  contracts: [],
  leases: [],
  cguTests: [],
  provisions: [],
  eclRates: [1, 3, 8, 20, 50],
  eclTermsDays: 30,
};

function normaliseWorkbook(raw: unknown): IfrsDeskWorkbookPayload {
  const o = (raw && typeof raw === 'object' ? raw : {}) as Partial<IfrsDeskWorkbookPayload>;
  return {
    contracts: Array.isArray(o.contracts) ? o.contracts : [],
    leases: Array.isArray(o.leases) ? o.leases : [],
    cguTests: Array.isArray(o.cguTests) ? o.cguTests : [],
    provisions: Array.isArray(o.provisions) ? o.provisions : [],
    eclRates: Array.isArray(o.eclRates) && o.eclRates.length === 5 ? o.eclRates.map(Number) : [1, 3, 8, 20, 50],
    eclTermsDays: Number.isFinite(Number(o.eclTermsDays)) ? Number(o.eclTermsDays) : 30,
  };
}

function computeDcfValueInUse(cashFlows: number[], discountRatePct: number, terminalGrowthPct: number): number {
  const r = discountRatePct / 100;
  const g = terminalGrowthPct / 100;
  if (r <= 0) return r2(cashFlows.reduce((s, c) => s + c, 0));
  let pv = 0;
  for (let t = 0; t < cashFlows.length; t += 1) {
    pv += cashFlows[t] / Math.pow(1 + r, t + 1);
  }
  const lastCf = cashFlows[cashFlows.length - 1] ?? 0;
  if (lastCf > 0 && r > g + 0.005) {
    const terminalVal = (lastCf * (1 + g)) / (r - g);
    pv += terminalVal / Math.pow(1 + r, cashFlows.length);
  }
  return r2(Math.max(0, pv));
}

export const ComprehensiveStandardsDesk: React.FC<ComprehensiveStandardsDeskProps> = ({
  currentClient,
  currentUser,
  lines = [],
  accounts = [],
  assets = [],
  invoices = [],
  bankAccounts = [],
  onAddJournalLines,
  onSaveAssets,
  onBankBalanceChange,
  onApprovalSubmitted,
  onNavigateSection,
}) => {
  const [activeTab, setActiveTab] = useState<StandardTab>('overview');
  const [postingDate, setPostingDate] = useState<string>(() => localToday());
  const [feedback, setFeedback] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);

  const wb = useWorkbooks<IfrsDeskWorkbookPayload>(currentClient.id, 'ifrs_desk');
  const savedWb = wb.items.find((w) => w.key === 'standards_register');
  const [localDraft, setLocalDraft] = useState<IfrsDeskWorkbookPayload | null>(null);
  const data = localDraft ?? (savedWb ? normaliseWorkbook(savedWb.payload) : DEFAULT_PAYLOAD);

  const readOnly =
    currentUser.role === 'auditor' ||
    currentUser.status === 'restricted' ||
    currentUser.status === 'suspended' ||
    currentUser.permissions?.canPostJournals === false;

  const clientLines = useMemo(
    () => lines.filter((l) => l.clientId === currentClient.id),
    [lines, currentClient.id]
  );

  const symbol = currentClient.currency === 'GHS' ? '₵' : `${currentClient.currency} `;

  const notify = (tone: 'ok' | 'err', text: string) => {
    setFeedback({ tone, text });
    setTimeout(() => setFeedback(null), 6500);
  };

  const persistRegister = async (next: IfrsDeskWorkbookPayload, okMsg?: string) => {
    setLocalDraft(next);
    const res = await wb.save(
      'standards_register',
      `${currentClient.code} IFRS/IAS Register`,
      next,
      savedWb?.version ?? 0
    );
    if (res.ok) {
      setLocalDraft(null);
      if (okMsg) notify('ok', okMsg);
    } else {
      notify('err', res.error ?? 'Could not save IFRS register to the server.');
    }
  };

  /** Posts balanced IFRS journal lines or queues them for checker approval if above maker limit. */
  const submitIfrsJournal = (
    docNo: string,
    title: string,
    journalLines: ACDOCALine[],
    onCommitted?: () => void,
    bankDelta?: { bankId: number; delta: number },
  ): boolean => {
    if (readOnly) {
      notify('err', 'Your account is read-only or restricted from posting journals.');
      return false;
    }
    if (clientLines.some((l) => l.docNo === docNo)) {
      notify('err', `Document ${docNo} is already posted in the ledger.`);
      return false;
    }
    const totalDebit = r2(journalLines.reduce((s, l) => s + l.debit, 0));
    if (totalDebit <= 0) {
      notify('err', 'Computed adjustment amount is zero — nothing to post.');
      return false;
    }
    const cleanLines = journalLines.map((l) => ({ ...l, checkedBy: undefined }));
    if (currentUser.makerLimit > 0 && totalDebit > currentUser.makerLimit) {
      persistentStorage.addApprovalRequest({
        id: uniqueId('APP-IFRS'),
        clientId: currentClient.id,
        clientCode: currentClient.code,
        clientName: currentClient.name,
        docNo,
        docType: 'JE',
        amount: totalDebit,
        requestedBy: `${currentUser.name} (${currentUser.username})`,
        requestedAt: new Date().toISOString(),
        description: title,
        reasonForApproval: `IFRS adjustment ${symbol}${formatGHS(totalDebit)} exceeds maker limit ${symbol}${formatGHS(currentUser.makerLimit)}.`,
        status: 'pending',
        payload: {
          lines: cleanLines,
          ...(bankDelta
            ? {
                settlement: {
                  kind: 'expense' as const,
                  clientId: currentClient.id,
                  settleAmount: totalDebit,
                  cashDelta: bankDelta.delta,
                  bankId: bankDelta.bankId,
                },
              }
            : {}),
        },
      });
      onApprovalSubmitted?.();
      notify(
        'ok',
        `${docNo} (${symbol}${formatGHS(totalDebit)}) exceeds your maker limit and was routed to the Approvals Queue for independent checker sign-off.`
      );
      return true;
    }

    const posted = onAddJournalLines(
      cleanLines,
      currentClient.currency,
      currentClient.id,
      bankDelta && onBankBalanceChange ? () => onBankBalanceChange(bankDelta.bankId, -bankDelta.delta) : undefined,
      bankDelta ? { syncBankFromGl: false } : undefined,
    );
    if (posted === false) {
      notify('err', `Posting ${docNo} was refused (check period lock, chart of accounts, or duplicate document).`);
      return false;
    }
    if (bankDelta && onBankBalanceChange) {
      onBankBalanceChange(bankDelta.bankId, bankDelta.delta);
    }
    onCommitted?.();
    return true;
  };

  // =========================================================================
  // 1. IFRS 15 — CONTRACTS WITH CUSTOMERS (OVER-TIME POC)
  // =========================================================================
  const [newCust, setNewCust] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newVal, setNewVal] = useState(0);
  const [newEstCost, setNewEstCost] = useState(0);
  const [newActualCost, setNewActualCost] = useState(0);
  const [newBilled, setNewBilled] = useState(0);

  const handleAddContract = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCust.trim() || !newDesc.trim() || newVal <= 0 || newEstCost <= 0) {
      notify('err', 'Customer, description, positive contract price, and estimated cost are required.');
      return;
    }
    const created: Ifrs15Contract = {
      id: uniqueId('CNT'),
      code: nextDocNo(`CNT-${currentYear()}`, data.contracts.map((c) => c.code), 3),
      customer: newCust.trim(),
      description: newDesc.trim(),
      contractValue: r2(newVal),
      totalEstimatedCost: r2(newEstCost),
      actualCostIncurred: r2(Math.max(0, newActualCost)),
      billedToDate: r2(Math.max(0, newBilled)),
    };
    await persistRegister(
      { ...data, contracts: [...data.contracts, created] },
      `Contract ${created.code} saved for ${currentClient.code}.`
    );
    setNewCust('');
    setNewDesc('');
    setNewVal(0);
    setNewEstCost(0);
    setNewActualCost(0);
    setNewBilled(0);
  };

  const handleUpdateContractProgress = async (id: string, actualCostIncurred: number, billedToDate: number) => {
    const nextContracts = data.contracts.map((c) =>
      c.id === id ? { ...c, actualCostIncurred: r2(Math.max(0, actualCostIncurred)), billedToDate: r2(Math.max(0, billedToDate)) } : c
    );
    await persistRegister({ ...data, contracts: nextContracts }, 'Contract cost & billing progress updated.');
  };

  const handleRecogniseContractPOC = (cnt: Ifrs15Contract) => {
    const poc = Math.min(1, cnt.totalEstimatedCost > 0 ? cnt.actualCostIncurred / cnt.totalEstimatedCost : 0);
    const revenueEarned = r2(cnt.contractValue * poc);
    const targetNet = r2(revenueEarned - cnt.billedToDate); // > 0 => Unbilled Contract Asset (118100), < 0 => Contract Liability (225000)

    // Compare against any net contract position already posted for this contract
    const alreadyAsset = r2(
      clientLines
        .filter((l) => l.reference === cnt.code && l.accountNo === '118100')
        .reduce((s, l) => s + l.debit - l.credit, 0)
    );
    const alreadyLiab = r2(
      clientLines
        .filter((l) => l.reference === cnt.code && l.accountNo === '225000')
        .reduce((s, l) => s + l.credit - l.debit, 0)
    );
    const currentNet = r2(alreadyAsset - alreadyLiab);
    const adjustment = r2(targetNet - currentNet);
    let moves: ReturnType<typeof contractPositionMovement>;
    try {
      moves = contractPositionMovement(targetNet, alreadyAsset, alreadyLiab);
    } catch (error) {
      notify('err', error instanceof Error ? error.message : 'Contract balance is invalid.');
      return;
    }
    if (!moves.length) {
      notify('ok', `${cnt.code}: GL already reflects the asset and liability positions. Confirm input evidence before signing off.`);
      return;
    }
    const missing = moves.find((move) => !accounts.some((a) => a.accountNo === move.accountNo && a.active));
    if (missing) {
      notify('err', `Account ${missing.accountNo} is unavailable in this entity's active chart. No IFRS 15 journal was submitted.`);
      return;
    }
    const period = postingDate.slice(0, 7);
    const docNo = nextDocNo(`IFRS15-${cnt.code}-${period}`, clientLines.map((l) => l.docNo), 2);
    const journalLines: ACDOCALine[] = moves.map((move) => ({
      id: uniqueId('JL-IFRS15'),
      docNo,
      period,
      date: postingDate,
      module: 'SD',
      docType: 'JE',
      accountNo: move.accountNo,
      accountName: accounts.find((a) => a.accountNo === move.accountNo)?.name || move.accountNo,
      costCenter: 'CC-SLS',
      debit: move.debit,
      credit: move.credit,
      currency: currentClient.currency,
      description: `IFRS 15 cost-to-cost contract position adjustment for ${cnt.code} (${(poc * 100).toFixed(1)}% complete)`,
      createdBy: currentUser.username,
      reference: cnt.code,
      clientId: currentClient.id,
    }));

    submitIfrsJournal(docNo, `IFRS 15 contract position (${cnt.code})`, journalLines, () =>
      notify('ok', `${docNo} submitted for server posting. Verify the journal and supporting costs/invoices before relying on the ${symbol}${formatGHS(adjustment)} movement.`)
    );
  };

  // =========================================================================
  // 2. IFRS 16 — LEASES, ROU ASSETS & EFFECTIVE-INTEREST AMORTISATION
  // =========================================================================
  const [lseLessor, setLseLessor] = useState('');
  const [lseDesc, setLseDesc] = useState('');
  const [lseStart, setLseStart] = useState(() => localToday());
  const [lseTerm, setLseTerm] = useState(36);
  const [lsePayment, setLsePayment] = useState(0);
  const [lseRate, setLseRate] = useState(15);
  const [lseDirectCosts, setLseDirectCosts] = useState(0);
  const [lseTiming, setLseTiming] = useState<'advance' | 'arrears'>('arrears');

  const computedLeases = useMemo(
    () =>
      data.leases.map((l) => {
        const calc = computeLease({
          id: l.id,
          name: l.description,
          lessor: l.lessor,
          commencement: l.commencement,
          termMonths: l.termMonths,
          payment: l.monthlyPayment,
          frequency: 'monthly',
          timing: l.timing,
          ratePct: l.discountRate,
          initialDirectCosts: l.initialDirectCosts,
        });
        const carryingLiab = leaseLiabilityAt(calc, postingDate);
        const nonCurrentLiab = leaseLiabilityAt(calc, addMonths(postingDate, 12));
        const currentLiab = r2(Math.max(0, carryingLiab - nonCurrentLiab));
        const monthlyDep = r2(calc.rouCost / Math.max(1, l.termMonths));
        const monthlyInterest = r2((carryingLiab * (l.discountRate / 100)) / 12);
        const principalPaid = r2(Math.max(0, l.monthlyPayment - monthlyInterest));
        return {
          raw: l,
          calc,
          carryingLiab,
          currentLiab,
          nonCurrentLiab,
          monthlyDep,
          monthlyInterest,
          principalPaid,
        };
      }),
    [data.leases, postingDate]
  );

  const handleAddLease = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lseLessor.trim() || !lseDesc.trim() || lsePayment <= 0 || lseTerm < 1) {
      notify('err', 'Lessor, description, positive monthly payment, and term are required.');
      return;
    }
    const created: Ifrs16LeaseRecord = {
      id: uniqueId('LSE'),
      code: nextDocNo(`LSE-${currentYear()}`, data.leases.map((l) => l.code), 3),
      lessor: lseLessor.trim(),
      description: lseDesc.trim(),
      commencement: lseStart,
      termMonths: Math.round(lseTerm),
      monthlyPayment: r2(lsePayment),
      discountRate: r2(lseRate),
      initialDirectCosts: r2(Math.max(0, lseDirectCosts)),
      timing: lseTiming,
    };
    await persistRegister(
      { ...data, leases: [...data.leases, created] },
      `Lease ${created.code} registered with PV calculation.`
    );
    setLseLessor('');
    setLseDesc('');
    setLsePayment(0);
    setLseDirectCosts(0);
  };

  const handlePostLeaseInitial = (item: (typeof computedLeases)[0]) => {
    if (item.raw.timing !== 'arrears' || item.raw.initialDirectCosts > 0) {
      notify('err', 'Advance rentals and initial direct costs require separate cash and ROU asset entries. Automatic recognition is disabled for this lease; obtain a reviewed IFRS 16 schedule and post the complete journal.');
      return;
    }
    const docNo = `IFRS16-INIT-${item.raw.code}`;
    const period = item.raw.commencement.slice(0, 7);
    const pv = item.calc.initialLiability;
    const journalLines: ACDOCALine[] = [
      {
        id: `${uniqueId('JL-IFRS16')}-1`,
        docNo,
        period,
        date: item.raw.commencement,
        module: 'FI-AA',
        docType: 'JE',
        accountNo: '150000',
        accountName: 'Right-of-Use Assets (IFRS 16)',
        costCenter: 'CC-OPS',
        debit: pv,
        credit: 0,
        currency: currentClient.currency,
        description: `IFRS 16 initial ROU asset recognition — ${item.raw.code} (${item.raw.lessor})`,
        createdBy: currentUser.username,
        reference: item.raw.code,
        clientId: currentClient.id,
      },
      {
        id: `${uniqueId('JL-IFRS16')}-2`,
        docNo,
        period,
        date: item.raw.commencement,
        module: 'FI',
        docType: 'JE',
        accountNo: '230000',
        accountName: 'Lease Liabilities (IFRS 16 Principal)',
        costCenter: 'CC-ADM',
        debit: 0,
        credit: pv,
        currency: currentClient.currency,
        description: `IFRS 16 initial lease liability PV at ${item.raw.discountRate}% IBR — ${item.raw.code}`,
        createdBy: currentUser.username,
        reference: item.raw.code,
        clientId: currentClient.id,
      },
    ];
    submitIfrsJournal(docNo, `IFRS 16 Initial Recognition (${item.raw.code})`, journalLines, () =>
      notify('ok', `${docNo} submitted for server posting: ROU asset and lease liability ${symbol}${formatGHS(pv)}. Confirm it appears in the journal before the first payment.`)
    );
  };

  const handlePostLeaseMonthly = (item: (typeof computedLeases)[0]) => {
    if (item.raw.timing !== 'arrears' || item.raw.initialDirectCosts > 0) {
      notify('err', 'Automatic lease posting supports only arrears leases with no initial direct costs. For advance payments or direct costs, review the IFRS 16 schedule and post a separately checked journal.');
      return;
    }
    if (!clientLines.some((l) => l.docNo === `IFRS16-INIT-${item.raw.code}`)) {
      notify('err', 'Recognise the lease liability and right-of-use asset before posting an instalment.');
      return;
    }
    const period = postingDate.slice(0, 7);
    const scheduled = item.calc.rows.find((r) => r.date.slice(0, 7) === period);
    if (!scheduled || scheduled.payment <= 0) {
      notify('err', `No instalment is due in ${period} under the approved lease schedule.`);
      return;
    }
    if (scheduled.n > 1) {
      const previous = item.calc.rows[scheduled.n - 2];
      if (previous && !clientLines.some((l) => l.docNo === `IFRS16-${item.raw.code}-${previous.date.slice(0, 7)}`)) {
        notify('err', 'Post earlier lease instalments in sequence, or reconcile a manually settled payment first.');
        return;
      }
    }
    const docNo = `IFRS16-${item.raw.code}-${period}`;
    const bank = bankAccounts.find((b) => (b.clientId ?? currentClient.id) === currentClient.id &&
      (b.glAccount || '100000') === '100000' && b.currency === currentClient.currency);
    if (!bank || bank.balance + 0.009 < scheduled.payment) {
      notify('err', `Insufficient available ${currentClient.currency} operating bank balance for the scheduled ${symbol}${formatGHS(scheduled.payment)} instalment.`);
      return;
    }
    const priorDep = r2(clientLines.filter((l) => l.reference === item.raw.code && l.accountNo === '159000')
      .reduce((s, l) => s + l.credit - l.debit, 0));
    const dep = scheduled.n === item.calc.rows.length
      ? r2(Math.max(0, item.calc.rouCost - priorDep))
      : r2(Math.min(item.calc.rouCost - priorDep, item.calc.rouCost / item.raw.termMonths));
    const principal = r2(scheduled.payment - scheduled.interest);
    if (principal < 0 || dep < 0) {
      notify('err', 'Lease balances do not reconcile to the schedule; review prior postings before proceeding.');
      return;
    }
    const base = { docNo, period, date: scheduled.date, module: 'FI' as const, docType: 'PAY' as const,
      currency: currentClient.currency, createdBy: currentUser.username, clientId: currentClient.id,
      costCenter: 'CC-ADM', reference: item.raw.code };
    const journalLines: ACDOCALine[] = [
      { id: uniqueId('JL-IFRS16'), ...base, accountNo: '610000', accountName: 'Depreciation Expense — ROU', debit: dep, credit: 0, description: `ROU depreciation ${item.raw.code}` },
      { id: uniqueId('JL-IFRS16'), ...base, accountNo: '159000', accountName: 'Accumulated Depreciation — ROU', debit: 0, credit: dep, description: `ROU accumulated depreciation ${item.raw.code}` },
      { id: uniqueId('JL-IFRS16'), ...base, accountNo: '710000', accountName: 'Lease Finance Cost', debit: scheduled.interest, credit: 0, description: `Effective interest ${item.raw.code} instalment ${scheduled.n}` },
      { id: uniqueId('JL-IFRS16'), ...base, accountNo: '230000', accountName: 'Lease Liability', debit: principal, credit: 0, description: `Lease principal ${item.raw.code} instalment ${scheduled.n}` },
      { id: uniqueId('JL-IFRS16'), ...base, accountNo: bank.glAccount || '100000', accountName: bank.name, debit: 0, credit: scheduled.payment, description: `Lease payment ${item.raw.code} instalment ${scheduled.n}` },
    ].filter((l) => l.debit > 0 || l.credit > 0);
    submitIfrsJournal(docNo, `IFRS 16 lease instalment ${scheduled.n} (${item.raw.code})`, journalLines,
      () => notify('ok', `${docNo} submitted for server posting: interest ${symbol}${formatGHS(scheduled.interest)}, principal ${symbol}${formatGHS(principal)}. Verify bank statement and ledger before sign-off.`),
      { bankId: bank.id, delta: -scheduled.payment });
  };

  // =========================================================================
  // 3. IAS 36 — IMPAIRMENT OF NON-FINANCIAL ASSETS & DCF VIU CALCULATOR
  // =========================================================================
  const [cguName, setCguName] = useState('');
  const [cguCarrying, setCguCarrying] = useState(0);
  const [cguCfInput, setCguCfInput] = useState('120000, 130000, 140000, 145000, 150000');
  const [cguDiscount, setCguDiscount] = useState(16);
  const [cguGrowth, setCguGrowth] = useState(3);
  const [cguFvlcd, setCguFvlcd] = useState(0);

  const handleAddCgu = async (e: React.FormEvent) => {
    e.preventDefault();
    const flows = cguCfInput
      .split(',')
      .map((s) => Number(s.trim()))
      .filter((n) => Number.isFinite(n));
    if (!cguName.trim() || cguCarrying <= 0 || !flows.length) {
      notify('err', 'CGU name, positive carrying amount, and at least one projected cash flow are required.');
      return;
    }
    const created: Ias36CguTest = {
      id: uniqueId('CGU'),
      cguName: cguName.trim(),
      carryingAmount: r2(cguCarrying),
      cashFlows: flows,
      terminalGrowthPct: r2(cguGrowth),
      discountRatePct: r2(cguDiscount),
      fairValueLessCosts: r2(Math.max(0, cguFvlcd)),
    };
    await persistRegister(
      { ...data, cguTests: [...data.cguTests, created] },
      `IAS 36 CGU test "${created.cguName}" saved.`
    );
    setCguName('');
    setCguCarrying(0);
    setCguFvlcd(0);
  };

  const handlePostImpairment = (cgu: Ias36CguTest, impairmentLoss: number, recoverable: number) => {
    if (impairmentLoss <= 0) return;
    const period = postingDate.slice(0, 7);
    const docNo = nextDocNo(`IAS36-${period}`, clientLines.map((l) => l.docNo), 3);
    const journalLines: ACDOCALine[] = [
      {
        id: `${uniqueId('JL-IAS36')}-1`,
        docNo,
        period,
        date: postingDate,
        module: 'FI-AA',
        docType: 'JE',
        accountNo: '690000',
        accountName: 'Impairment Loss on Non-Financial Assets (IAS 36)',
        costCenter: 'CC-OPS',
        debit: impairmentLoss,
        credit: 0,
        currency: currentClient.currency,
        description: `IAS 36 impairment write-down on ${cgu.cguName} to recoverable amount ${symbol}${formatGHS(recoverable)}`,
        createdBy: currentUser.username,
        reference: cgu.id,
        clientId: currentClient.id,
      },
      {
        id: `${uniqueId('JL-IAS36')}-2`,
        docNo,
        period,
        date: postingDate,
        module: 'FI-AA',
        docType: 'JE',
        accountNo: '139000',
        accountName: 'Accumulated Depreciation & Impairment — PPE',
        costCenter: 'CC-OPS',
        debit: 0,
        credit: impairmentLoss,
        currency: currentClient.currency,
        description: `Accumulated impairment allowance — ${cgu.cguName}`,
        createdBy: currentUser.username,
        reference: cgu.id,
        clientId: currentClient.id,
      },
    ];
    submitIfrsJournal(docNo, `IAS 36 Impairment Loss (${cgu.cguName})`, journalLines, () =>
      notify('ok', `${docNo} posted: IAS 36 impairment loss of ${symbol}${formatGHS(impairmentLoss)} recognised.`)
    );
  };

  // =========================================================================
  // 4. IAS 37 — PROVISIONS & CONTINGENT LIABILITIES (DISCOUNTED PV)
  // =========================================================================
  const [prvTitle, setPrvTitle] = useState('');
  const [prvCategory, setPrvCategory] = useState('Environmental / Decommissioning');
  const [prvEstimate, setPrvEstimate] = useState(0);
  const [prvProb, setPrvProb] = useState(85);
  const [prvRate, setPrvRate] = useState(15);
  const [prvYears, setPrvYears] = useState(3);

  const handleAddProvision = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prvTitle.trim() || prvEstimate <= 0) {
      notify('err', 'Obligation title and positive best estimate are required.');
      return;
    }
    const pv =
      prvProb > 50
        ? r2(prvEstimate / Math.pow(1 + Math.max(0, prvRate) / 100, Math.max(0, prvYears)))
        : 0;
    const created: Ias37ProvisionRecord = {
      id: uniqueId('PRV'),
      code: nextDocNo(`PRV-${currentYear()}`, data.provisions.map((p) => p.code), 3),
      title: prvTitle.trim(),
      category: prvCategory,
      bestEstimate: r2(prvEstimate),
      probability: Math.min(100, Math.max(0, prvProb)),
      discountRate: Math.max(0, prvRate),
      yearsToSettlement: Math.max(0, prvYears),
      currentCarrying: pv,
    };
    await persistRegister(
      { ...data, provisions: [...data.provisions, created] },
      `IAS 37 item ${created.code} evaluated (${created.probability > 50 ? `Provision PV ${symbol}${formatGHS(pv)}` : 'Contingent Liability'}).`
    );
    setPrvTitle('');
    setPrvEstimate(0);
  };

  const handlePostProvisionInitial = (prv: Ias37ProvisionRecord) => {
    if (prv.probability <= 50 || prv.currentCarrying <= 0) return;
    const docNo = `IAS37-INIT-${prv.code}`;
    const period = postingDate.slice(0, 7);
    const debitAccount = /decommissioning|rehab|restoration/i.test(prv.category)
      ? { no: '130000', name: 'Property, Plant & Equipment (Decommissioning Capitalised)' }
      : { no: '620000', name: 'Operating & Legal Provision Expense (IAS 37)' };
    const journalLines: ACDOCALine[] = [
      {
        id: `${uniqueId('JL-IAS37')}-1`,
        docNo,
        period,
        date: postingDate,
        module: 'FI',
        docType: 'JE',
        accountNo: debitAccount.no,
        accountName: debitAccount.name,
        costCenter: 'CC-ADM',
        debit: prv.currentCarrying,
        credit: 0,
        currency: currentClient.currency,
        description: `IAS 37 initial provision recognition — ${prv.title} (${prv.code})`,
        createdBy: currentUser.username,
        reference: prv.code,
        clientId: currentClient.id,
      },
      {
        id: `${uniqueId('JL-IAS37')}-2`,
        docNo,
        period,
        date: postingDate,
        module: 'FI',
        docType: 'JE',
        accountNo: '270000',
        accountName: 'Provisions for Liabilities & Decommissioning (IAS 37)',
        costCenter: 'CC-ADM',
        debit: 0,
        credit: prv.currentCarrying,
        currency: currentClient.currency,
        description: `Present value provision recognised (${prv.code})`,
        createdBy: currentUser.username,
        reference: prv.code,
        clientId: currentClient.id,
      },
    ];
    submitIfrsJournal(docNo, `IAS 37 Provision Recognition (${prv.code})`, journalLines, () =>
      notify('ok', `${docNo} posted: Provision of ${symbol}${formatGHS(prv.currentCarrying)} recognised in GL 270000.`)
    );
  };

  const handlePostProvisionUnwinding = (prv: Ias37ProvisionRecord) => {
    const unwinding = r2(prv.currentCarrying * (prv.discountRate / 100));
    if (prv.probability <= 50 || unwinding <= 0) return;
    const period = postingDate.slice(0, 7);
    const docNo = nextDocNo(`IAS37-UNW-${prv.code}-${period}`, clientLines.map((l) => l.docNo), 2);
    const journalLines: ACDOCALine[] = [
      {
        id: `${uniqueId('JL-IAS37')}-1`,
        docNo,
        period,
        date: postingDate,
        module: 'FI',
        docType: 'JE',
        accountNo: '720000',
        accountName: 'Finance Cost — Unwinding of Provisions (IAS 37)',
        costCenter: 'CC-ADM',
        debit: unwinding,
        credit: 0,
        currency: currentClient.currency,
        description: `IAS 37 annual discount unwinding at ${prv.discountRate}% on ${prv.code}`,
        createdBy: currentUser.username,
        reference: prv.code,
        clientId: currentClient.id,
      },
      {
        id: `${uniqueId('JL-IAS37')}-2`,
        docNo,
        period,
        date: postingDate,
        module: 'FI',
        docType: 'JE',
        accountNo: '270000',
        accountName: 'Provisions for Liabilities & Decommissioning (IAS 37)',
        costCenter: 'CC-ADM',
        debit: 0,
        credit: unwinding,
        currency: currentClient.currency,
        description: `Provision accretion (${prv.code})`,
        createdBy: currentUser.username,
        reference: prv.code,
        clientId: currentClient.id,
      },
    ];
    submitIfrsJournal(docNo, `IAS 37 Discount Unwinding (${prv.code})`, journalLines, () => {
      const nextProvs = data.provisions.map((p) =>
        p.id === prv.id ? { ...p, currentCarrying: r2(p.currentCarrying + unwinding) } : p
      );
      void persistRegister({ ...data, provisions: nextProvs });
      notify('ok', `${docNo} posted: Finance cost ${symbol}${formatGHS(unwinding)} unwound; provision carrying value updated.`);
    });
  };

  // =========================================================================
  // 5. IFRS 9 — EXPECTED CREDIT LOSS (LIVE SUBLEDGER RECEIVABLES STAGING)
  // =========================================================================
  const eclComputation = useMemo(() => {
    const ageing = receivablesAgeing(invoices, currentClient.id, postingDate, data.eclTermsDays);
    const labels = [
      { bucket: 'Current (0–30 days)', stage: 1 },
      { bucket: '1–30 days past due', stage: 2 },
      { bucket: '31–60 days past due', stage: 2 },
      { bucket: '61–90 days past due', stage: 2 },
      { bucket: '90+ days (Credit-Impaired)', stage: 3 },
    ];
    const rows = labels.map((l, i) => {
      const exposure = ageing.buckets[i] ?? 0;
      const rate = data.eclRates[i] ?? 0;
      const allowance = r2((exposure * rate) / 100);
      return { ...l, idx: i, exposure, rate, allowance, net: r2(exposure - allowance) };
    });
    const requiredTotal = r2(rows.reduce((s, r) => s + r.allowance, 0));
    const bookedGl119 = r2(
      clientLines
        .filter((l) => l.accountNo === '119000')
        .reduce((s, l) => s + l.credit - l.debit, 0)
    );
    const delta = r2(requiredTotal - bookedGl119);
    return { rows, totalExposure: ageing.total, requiredTotal, bookedGl119, delta };
  }, [invoices, currentClient.id, postingDate, data.eclTermsDays, data.eclRates, clientLines]);

  const handlePostEclTrueUp = () => {
    const { delta, requiredTotal } = eclComputation;
    if (Math.abs(delta) < 0.01) {
      notify('ok', 'GL 119000 Allowance for Expected Credit Losses already agrees with the IFRS 9 matrix.');
      return;
    }
    const period = postingDate.slice(0, 7);
    const docNo = nextDocNo(`IFRS9-ECL-${period}`, clientLines.map((l) => l.docNo), 2);
    const journalLines: ACDOCALine[] =
      delta > 0
        ? [
            {
              id: `${uniqueId('JL-IFRS9')}-1`,
              docNo,
              period,
              date: postingDate,
              module: 'FI',
              docType: 'JE',
              accountNo: '680000',
              accountName: 'Impairment Loss on Financial Assets (ECL)',
              costCenter: 'CC-ADM',
              debit: delta,
              credit: 0,
              currency: currentClient.currency,
              description: `IFRS 9 ECL allowance increase to ${symbol}${formatGHS(requiredTotal)}`,
              createdBy: currentUser.username,
              clientId: currentClient.id,
            },
            {
              id: `${uniqueId('JL-IFRS9')}-2`,
              docNo,
              period,
              date: postingDate,
              module: 'FI',
              docType: 'JE',
              accountNo: '119000',
              accountName: 'Allowance for Expected Credit Losses',
              costCenter: 'CC-ADM',
              debit: 0,
              credit: delta,
              currency: currentClient.currency,
              description: `Lifetime ECL provision matrix adjustment (${period})`,
              createdBy: currentUser.username,
              clientId: currentClient.id,
            },
          ]
        : [
            {
              id: `${uniqueId('JL-IFRS9')}-1`,
              docNo,
              period,
              date: postingDate,
              module: 'FI',
              docType: 'JE',
              accountNo: '119000',
              accountName: 'Allowance for Expected Credit Losses',
              costCenter: 'CC-ADM',
              debit: Math.abs(delta),
              credit: 0,
              currency: currentClient.currency,
              description: `IFRS 9 ECL allowance release to ${symbol}${formatGHS(requiredTotal)}`,
              createdBy: currentUser.username,
              clientId: currentClient.id,
            },
            {
              id: `${uniqueId('JL-IFRS9')}-2`,
              docNo,
              period,
              date: postingDate,
              module: 'FI',
              docType: 'JE',
              accountNo: '680000',
              accountName: 'Impairment Loss on Financial Assets (ECL)',
              costCenter: 'CC-ADM',
              debit: 0,
              credit: Math.abs(delta),
              currency: currentClient.currency,
              description: `Reversal of excess ECL allowance (${period})`,
              createdBy: currentUser.username,
              clientId: currentClient.id,
            },
          ];

    submitIfrsJournal(docNo, `IFRS 9 ECL True-Up (${period})`, journalLines, () =>
      notify(
        'ok',
        `${docNo} posted: ECL allowance adjusted by ${delta > 0 ? '+' : ''}${symbol}${formatGHS(delta)} to match required ${symbol}${formatGHS(requiredTotal)}.`
      )
    );
  };

  // =========================================================================
  // 6. IFRS 5 — ASSETS HELD FOR SALE (LIVE FIXED ASSET REGISTER INTEGRATION)
  // =========================================================================
  const activeAssets = useMemo(
    () => assets.filter((a) => !a.disposedDate),
    [assets]
  );
  const [fvlcdByAsset, setFvlcdByAsset] = useState<Record<string, number>>({});

  const handleClassifyHeldForSale = (asset: FixedAsset) => {
    const nbv = r2(Math.max(0, asset.cost - asset.accumDep));
    const fvlcd = r2(Math.max(0, fvlcdByAsset[asset.id] ?? nbv));
    const hfsCarrying = r2(Math.min(nbv, fvlcd));
    const impairment = r2(Math.max(0, nbv - fvlcd));
    const period = postingDate.slice(0, 7);
    const docNo = nextDocNo(`IFRS5-${asset.assetTag}`, clientLines.map((l) => l.docNo), 2);

    const journalLines: ACDOCALine[] = [];
    if (hfsCarrying > 0) {
      journalLines.push({
        id: `${uniqueId('JL-IFRS5')}-1`,
        docNo,
        period,
        date: postingDate,
        module: 'FI-AA',
        docType: 'JE',
        accountNo: '180000',
        accountName: 'Non-Current Assets Held for Sale (IFRS 5)',
        costCenter: 'CC-OPS',
        debit: hfsCarrying,
        credit: 0,
        currency: currentClient.currency,
        description: `IFRS 5 transfer of ${asset.assetTag} (${asset.name}) at lower of NBV & FVLCD`,
        createdBy: currentUser.username,
        reference: asset.assetTag,
        clientId: currentClient.id,
      });
    }
    if (asset.accumDep > 0) {
      journalLines.push({
        id: `${uniqueId('JL-IFRS5')}-2`,
        docNo,
        period,
        date: postingDate,
        module: 'FI-AA',
        docType: 'JE',
        accountNo: '139000',
        accountName: 'Accumulated Depreciation & Impairment — PPE',
        costCenter: 'CC-OPS',
        debit: r2(asset.accumDep),
        credit: 0,
        currency: currentClient.currency,
        description: `Eliminate accumulated depreciation on transfer to HFS (${asset.assetTag})`,
        createdBy: currentUser.username,
        reference: asset.assetTag,
        clientId: currentClient.id,
      });
    }
    if (impairment > 0) {
      journalLines.push({
        id: `${uniqueId('JL-IFRS5')}-3`,
        docNo,
        period,
        date: postingDate,
        module: 'FI-AA',
        docType: 'JE',
        accountNo: '690000',
        accountName: 'Impairment Loss on Non-Financial Assets',
        costCenter: 'CC-OPS',
        debit: impairment,
        credit: 0,
        currency: currentClient.currency,
        description: `IFRS 5 initial write-down to FVLCD on ${asset.assetTag}`,
        createdBy: currentUser.username,
        reference: asset.assetTag,
        clientId: currentClient.id,
      });
    }
    journalLines.push({
      id: `${uniqueId('JL-IFRS5')}-4`,
      docNo,
      period,
      date: postingDate,
      module: 'FI-AA',
      docType: 'JE',
      accountNo: '130000',
      accountName: 'Property, Plant & Equipment (Cost)',
      costCenter: 'CC-OPS',
      debit: 0,
      credit: r2(asset.cost),
      currency: currentClient.currency,
      description: `Derecognise ${asset.assetTag} from PPE on IFRS 5 classification`,
      createdBy: currentUser.username,
      reference: asset.assetTag,
      clientId: currentClient.id,
    });

    submitIfrsJournal(docNo, `IFRS 5 Held-for-Sale Transfer (${asset.assetTag})`, journalLines, () => {
      if (onSaveAssets) {
        onSaveAssets(
          assets.map((a) =>
            a.id === asset.id
              ? { ...a, disposedDate: postingDate, disposalProceeds: hfsCarrying }
              : a
          )
        );
      }
      notify(
        'ok',
        `${docNo} posted: ${asset.assetTag} transferred to Held for Sale (GL 180000) at ${symbol}${formatGHS(hfsCarrying)}, accumulated depreciation cleared, and depreciation ceased.`
      );
    });
  };

  // Summary metrics
  const totalContractValue = r2(data.contracts.reduce((s, c) => s + c.contractValue, 0));
  const totalRouNbv = r2(
    computedLeases.reduce(
      (s, l) => s + Math.max(0, l.calc.rouCost - (l.calc.rouCost / Math.max(1, l.raw.termMonths))),
      0
    )
  );
  const totalProvisionsPv = r2(
    data.provisions.filter((p) => p.probability > 50).reduce((s, p) => s + p.currentCarrying, 0)
  );

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`IFRS & IAS COMPUTATION ENGINE · ${currentClient.code}`}
        title="Comprehensive IFRS / IAS Accounting Desk"
        desc="Live entity-scoped computations for IFRS 15 contracts, IFRS 16 leases, IAS 36 CGU DCF impairment, IAS 37 provisions, IFRS 9 ECL staging, and IFRS 5 held-for-sale transfers — persisted on the server and posted through maker-checker controls."
      >
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-xs font-bold text-[#082f4f]">
            <span>Measurement Date:</span>
            <input
              type="date"
              value={postingDate}
              onChange={(e) => setPostingDate(e.target.value)}
              className="font-mono outline-none"
            />
          </label>
          {onNavigateSection && (
            <button
              onClick={() => onNavigateSection('loans_desk')}
              className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
            >
              <Calculator className="h-4 w-4" />
              <span>Loan Amortisation Schedules</span>
            </button>
          )}
        </div>
      </PageHeader>

      {feedback && (
        <div
          role="status"
          className={`rounded-xl border p-4 text-xs font-bold flex items-center gap-2 shadow-xs ${
            feedback.tone === 'ok'
              ? 'border-emerald-300 bg-emerald-50 text-emerald-900'
              : 'border-rose-300 bg-rose-50 text-rose-900'
          }`}
        >
          {feedback.tone === 'ok' ? (
            <CheckCircle className="h-4 w-4 text-emerald-700 shrink-0" />
          ) : (
            <AlertCircle className="h-4 w-4 text-rose-700 shrink-0" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {wb.error && (
        <div className="rounded-xl border border-amber-300 bg-amber-50 p-3 text-xs font-semibold text-amber-900">
          {wb.error}
        </div>
      )}

      {/* Standards Tab Strip */}
      <div className="flex flex-wrap gap-1 rounded-xl border border-sky-200 bg-white p-1.5 shadow-xs">
        {[
          { id: 'overview' as const, label: 'Standards Overview' },
          { id: 'ifrs15_contracts' as const, label: `IFRS 15 Contracts (${data.contracts.length})` },
          { id: 'ifrs16_leases' as const, label: `IFRS 16 Leases (${data.leases.length})` },
          { id: 'ias36_impairment' as const, label: `IAS 36 Impairments (${data.cguTests.length})` },
          { id: 'ias37_provisions' as const, label: `IAS 37 Provisions (${data.provisions.length})` },
          { id: 'ifrs9_instruments' as const, label: 'IFRS 9 ECL Staging' },
          { id: 'ifrs5_hfs' as const, label: `IFRS 5 Held for Sale (${activeAssets.length})` },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition ${
              activeTab === t.id ? 'bg-[#082f4f] text-white shadow-xs' : 'text-[#2d4f6d] hover:bg-sky-50'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* TAB 0: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
            <Stat
              label="IFRS 15 Active Contracts"
              value={`${symbol}${formatGHS(totalContractValue)}`}
              sub={`${data.contracts.length} contract(s) in register`}
              tone="text-emerald-800"
            />
            <Stat
              label="IFRS 16 ROU Carrying Value"
              value={`${symbol}${formatGHS(totalRouNbv)}`}
              sub={`${data.leases.length} active lease(s)`}
              tone="text-[#082f4f]"
            />
            <Stat
              label="IAS 37 Provisions PV"
              value={`${symbol}${formatGHS(totalProvisionsPv)}`}
              sub={`${data.provisions.filter((p) => p.probability > 50).length} recognised obligation(s)`}
              tone="text-rose-800"
            />
            <Stat
              label="IFRS 9 Required ECL"
              value={`${symbol}${formatGHS(eclComputation.requiredTotal)}`}
              sub={`Booked GL 119000: ${symbol}${formatGHS(eclComputation.bookedGl119)}`}
              tone="text-[#855b00]"
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card title="Integrated Standards Engine" sub="Every calculation feeds the General Ledger and Statutory Statements">
              <ul className="list-disc pl-4 space-y-1.5 text-xs text-[#2d4f6d]">
                <li><strong>IFRS 15:</strong> Cost-to-cost POC revenue recognition into Unbilled Contract Assets (118100) and Contract Liabilities (225000).</li>
                <li><strong>IFRS 16:</strong> Annuity PV lease liability, ROU asset recognition, monthly depreciation, effective interest, and bank balance sync.</li>
                <li><strong>IAS 36:</strong> Multi-year DCF Value-in-Use + terminal value vs FVLCD impairment testing.</li>
                <li><strong>IAS 37:</strong> Probability threshold check, present value discounting, and annual finance-cost unwinding.</li>
                <li><strong>IFRS 9:</strong> Live staging of open customer invoices with net true-up against GL 119000.</li>
                <li><strong>IFRS 5:</strong> Reclassifies active Fixed Assets into Held for Sale (180000), clears accumulated depreciation, and stops depreciation.</li>
              </ul>
            </Card>

            <Card title="Cross-Module Borrowings & Financial Instruments" sub="IFRS 9 amortised cost schedules">
              <div className="space-y-3 text-xs text-[#2d4f6d]">
                <p>
                  Commercial term loans, effective interest rate (EIR) schedules, drawdowns, and principal/interest repayments are managed in the Loan Amortisation Desk and feed directly into IFRS 7 borrowings disclosures and Treasury.
                </p>
                {onNavigateSection && (
                  <button
                    onClick={() => onNavigateSection('loans_desk')}
                    className="w-full flex items-center justify-center gap-2 rounded-lg bg-[#082f4f] py-2.5 text-xs font-bold text-white hover:bg-[#0c3f68]"
                  >
                    <span>Open Loan Amortisation Schedules</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                )}
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* TAB 1: IFRS 15 CONTRACTS */}
      {activeTab === 'ifrs15_contracts' && (
        <div className="space-y-5">
          <Card
            title="IFRS 15 Contracts with Customers & Performance Obligations"
            sub="Cost-to-cost Percentage of Completion (POC) — posts net incremental Contract Asset (118100) or Contract Liability (225000)"
          >
            {data.contracts.length === 0 ? (
              <p className="text-xs text-[#355875] py-4">
                No long-term customer contracts registered for {currentClient.code} yet. Add one below to compute over-time POC revenue.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[920px] text-xs">
                  <thead>
                    <tr className="border-b border-sky-200 bg-sky-50/70">
                      <th className={thCls}>Contract</th>
                      <th className={thCls}>Customer</th>
                      <th className={thCls + ' text-right'}>Price</th>
                      <th className={thCls + ' text-right'}>Est. Cost</th>
                      <th className={thCls + ' text-right'}>Actual Cost (Editable)</th>
                      <th className={thCls + ' text-center'}>POC %</th>
                      <th className={thCls + ' text-right'}>Earned Revenue</th>
                      <th className={thCls + ' text-right'}>Billed (Editable)</th>
                      <th className={thCls + ' text-right'}>Net Asset/(Liab)</th>
                      <th className={thCls + ' text-center'}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.contracts.map((c) => {
                      const poc = Math.min(1, c.totalEstimatedCost > 0 ? c.actualCostIncurred / c.totalEstimatedCost : 0);
                      const pocRevenue = r2(c.contractValue * poc);
                      const netPosition = r2(pocRevenue - c.billedToDate);
                      const isAsset = netPosition >= 0;
                      return (
                        <tr key={c.id} className={rowCls}>
                          <td className="px-3 py-2 font-mono font-bold text-[#855b00]">
                            <div>{c.code}</div>
                            <div className="font-sans font-normal text-[10.5px] text-[#355875]">{c.description}</div>
                          </td>
                          <td className="px-3 py-2 font-bold text-[#082f4f]">{c.customer}</td>
                          <td className={numCls}>{formatGHS(c.contractValue)}</td>
                          <td className={numCls}>{formatGHS(c.totalEstimatedCost)}</td>
                          <td className="px-2 py-1.5 text-right">
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              defaultValue={c.actualCostIncurred}
                              onBlur={(e) => void handleUpdateContractProgress(c.id, Number(e.target.value), c.billedToDate)}
                              className="w-28 rounded border border-sky-300 px-2 py-1 text-right font-mono text-xs"
                            />
                          </td>
                          <td className="px-3 py-2 text-center font-bold font-mono text-[#006f98]">
                            {(poc * 100).toFixed(1)}%
                          </td>
                          <td className={numCls + ' font-bold text-emerald-800'}>{formatGHS(pocRevenue)}</td>
                          <td className="px-2 py-1.5 text-right">
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              defaultValue={c.billedToDate}
                              onBlur={(e) => void handleUpdateContractProgress(c.id, c.actualCostIncurred, Number(e.target.value))}
                              className="w-28 rounded border border-sky-300 px-2 py-1 text-right font-mono text-xs"
                            />
                          </td>
                          <td className={numCls + ` font-black ${isAsset ? 'text-emerald-800' : 'text-rose-800'}`}>
                            {isAsset
                              ? `+${symbol}${formatGHS(netPosition)} (Asset)`
                              : `-${symbol}${formatGHS(Math.abs(netPosition))} (Liab)`}
                          </td>
                          <td className="px-3 py-2 text-center">
                            <div className="flex items-center justify-center gap-1">
                              <button
                                type="button"
                                disabled={readOnly}
                                onClick={() => handleRecogniseContractPOC(c)}
                                className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] disabled:opacity-40"
                              >
                                Post POC
                              </button>
                              <button
                                type="button"
                                disabled={readOnly}
                                onClick={() =>
                                  void persistRegister(
                                    { ...data, contracts: data.contracts.filter((x) => x.id !== c.id) },
                                    `Removed ${c.code}.`
                                  )
                                }
                                className="rounded border border-rose-200 bg-rose-50 p-1 text-rose-700 disabled:opacity-40"
                                title="Remove contract"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <Card title="Register Long-Term Customer Contract" sub="Persisted per entity on the firm server">
            <form onSubmit={handleAddContract} className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Customer Name</label>
                <input type="text" value={newCust} onChange={(e) => setNewCust(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none" required />
              </div>
              <div className="md:col-span-3">
                <label className="block font-bold text-[#0a253e] mb-1">Performance Obligation Description</label>
                <input type="text" value={newDesc} onChange={(e) => setNewDesc(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Transaction Price ({symbol})</label>
                <input type="number" min="0.01" step="0.01" value={newVal || ''} onChange={(e) => setNewVal(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Total Estimated Cost ({symbol})</label>
                <input type="number" min="0.01" step="0.01" value={newEstCost || ''} onChange={(e) => setNewEstCost(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Actual Cost Incurred ({symbol})</label>
                <input type="number" min="0" step="0.01" value={newActualCost || ''} onChange={(e) => setNewActualCost(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Billed to Date ({symbol})</label>
                <input type="number" min="0" step="0.01" value={newBilled || ''} onChange={(e) => setNewBilled(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" />
              </div>
              <div className="md:col-span-4 flex justify-end">
                <button type="submit" disabled={readOnly} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] disabled:opacity-40">
                  <Plus className="h-4 w-4" />
                  <span>Save Contract</span>
                </button>
              </div>
            </form>
          </Card>
        </div>
      )}

      {/* TAB 2: IFRS 16 LEASES */}
      {activeTab === 'ifrs16_leases' && (
        <div className="space-y-5">
          <Card
            title="IFRS 16 Leases — Present Value, ROU Asset & Effective Interest"
            sub="Computes PV of lease payments at incremental borrowing rate, initial recognition, monthly depreciation, interest unwinding, and bank settlement"
            action={<ScheduleActions title={`IFRS 16 lease schedules — ${currentClient.code}`} subtitle={`${currentClient.name} · as at ${postingDate}`} targetId="ifrs16-lease-schedule" filename={`${currentClient.code}-IFRS16-leases.xlsx`} disabled={!computedLeases.length} sheets={[{ name: 'Lease summary', columns: ['Lease','Lessor','Commencement','Term months','Payment','Rate %','Initial liability','ROU cost','Carrying liability','Current','Non-current'], rows: computedLeases.map((l) => [l.raw.code,l.raw.lessor,l.raw.commencement,l.raw.termMonths,l.raw.monthlyPayment,l.raw.discountRate,l.calc.initialLiability,l.calc.rouCost,l.carryingLiab,l.currentLiab,l.nonCurrentLiab]), moneyColumns: [4,6,7,8,9,10] }, ...computedLeases.map((l) => ({ name: `${l.raw.code}-amortisation`, columns: ['Period','Date','Opening liability','Interest','Payment','Closing liability'], rows: l.calc.rows.map((r) => [r.n,r.date,r.opening,r.interest,r.payment,r.closing]), moneyColumns: [2,3,4,5] }))]} />}
          >
            <div id="ifrs16-lease-schedule">
            {computedLeases.length === 0 ? (
              <p className="text-xs text-[#355875] py-4">
                No leases registered for {currentClient.code}. Add a lease below to compute its ROU asset and amortisation schedule.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[980px] text-xs">
                  <thead>
                    <tr className="border-b border-sky-200 bg-sky-50/70">
                      <th className={thCls}>Lease</th>
                      <th className={thCls}>Lessor &amp; Asset</th>
                      <th className={thCls + ' text-right'}>Term / IBR</th>
                      <th className={thCls + ' text-right'}>Monthly Rent</th>
                      <th className={thCls + ' text-right'}>Initial ROU / PV</th>
                      <th className={thCls + ' text-right'}>Carrying Liab (Cur / Non-Cur)</th>
                      <th className={thCls + ' text-right'}>Monthly Dep / Int</th>
                      <th className={thCls + ' text-center'}>Postings</th>
                    </tr>
                  </thead>
                  <tbody>
                    {computedLeases.map((item) => {
                      const initPosted = clientLines.some((l) => l.docNo === `IFRS16-INIT-${item.raw.code}`);
                      return (
                        <tr key={item.raw.id} className={rowCls}>
                          <td className="px-3 py-2 font-mono font-bold text-[#855b00]">
                            <div>{item.raw.code}</div>
                            <div className="text-[10px] text-[#355875]">{item.raw.commencement}</div>
                          </td>
                          <td className="px-3 py-2">
                            <div className="font-bold text-[#082f4f]">{item.raw.description}</div>
                            <div className="text-[11px] text-[#355875]">{item.raw.lessor}</div>
                          </td>
                          <td className={numCls}>
                            {item.raw.termMonths}m @ {item.raw.discountRate}%
                          </td>
                          <td className={numCls + ' font-bold'}>{formatGHS(item.raw.monthlyPayment)}</td>
                          <td className={numCls + ' font-bold text-emerald-800'}>
                            {formatGHS(item.calc.rouCost)} / {formatGHS(item.calc.initialLiability)}
                          </td>
                          <td className={numCls}>
                            <div className="font-bold text-rose-800">{formatGHS(item.carryingLiab)}</div>
                            <div className="text-[10px] text-[#355875]">
                              Cur {formatGHS(item.currentLiab)} · NC {formatGHS(item.nonCurrentLiab)}
                            </div>
                          </td>
                          <td className={numCls}>
                            <div>Dep: {formatGHS(item.monthlyDep)}</div>
                            <div className="text-[10.5px] text-[#355875]">Int: {formatGHS(item.monthlyInterest)}</div>
                          </td>
                          <td className="px-3 py-2 text-center">
                            <div className="flex flex-wrap items-center justify-center gap-1">
                              {!initPosted && (
                                <button
                                  type="button"
                                  disabled={readOnly}
                                  onClick={() => handlePostLeaseInitial(item)}
                                  className="rounded border border-sky-300 bg-sky-50 px-2 py-1 text-[10.5px] font-bold text-[#082f4f] hover:bg-sky-100 disabled:opacity-40"
                                >
                                  Recognise PV
                                </button>
                              )}
                              <button
                                type="button"
                                disabled={readOnly}
                                onClick={() => handlePostLeaseMonthly(item)}
                                className="rounded bg-[#082f4f] px-2.5 py-1 text-[10.5px] font-bold text-white hover:bg-[#0c3f68] disabled:opacity-40"
                              >
                                Post {postingDate.slice(0, 7)}
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
            </div>
          </Card>

          <Card title="Register New IFRS 16 Lease" sub="Calculates present value at the incremental borrowing rate">
            <form onSubmit={handleAddLease} className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Lessor</label>
                <input type="text" value={lseLessor} onChange={(e) => setLseLessor(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5" required />
              </div>
              <div className="md:col-span-2">
                <label className="block font-bold text-[#0a253e] mb-1">Leased Asset Description</label>
                <input type="text" value={lseDesc} onChange={(e) => setLseDesc(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Commencement Date</label>
                <input type="date" value={lseStart} onChange={(e) => setLseStart(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Term (Months)</label>
                <input type="number" min="1" max="360" value={lseTerm} onChange={(e) => setLseTerm(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Monthly Payment ({symbol})</label>
                <input type="number" min="0.01" step="0.01" value={lsePayment || ''} onChange={(e) => setLsePayment(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Annual IBR Discount %</label>
                <input type="number" min="0" step="0.1" value={lseRate} onChange={(e) => setLseRate(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Payment Timing</label>
                <select value={lseTiming} onChange={(e) => setLseTiming(e.target.value as 'advance' | 'arrears')} className="w-full rounded border border-sky-300 px-2 py-1.5">
                  <option value="arrears">In arrears (end of month)</option>
                  <option value="advance">In advance (start of month)</option>
                </select>
              </div>
              <div className="md:col-span-4 flex justify-end">
                <button type="submit" disabled={readOnly} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] disabled:opacity-40">
                  <Plus className="h-4 w-4" />
                  <span>Add Lease to Schedule</span>
                </button>
              </div>
            </form>
          </Card>
        </div>
      )}

      {/* TAB 3: IAS 36 IMPAIRMENT */}
      {activeTab === 'ias36_impairment' && (
        <div className="space-y-5">
          <Card
            title="IAS 36 Impairment of Assets & Cash-Generating Units (DCF Engine)"
            sub="Computes Value in Use (discounted cash flows + terminal value), compares against FVLCD, and posts impairment loss (Dr 690000 / Cr 139000)"
          >
            {data.cguTests.length === 0 ? (
              <p className="text-xs text-[#355875] py-4">
                No CGU impairment tests recorded for {currentClient.code}. Create a DCF impairment test below.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[900px] text-xs">
                  <thead>
                    <tr className="border-b border-sky-200 bg-sky-50/70">
                      <th className={thCls}>CGU</th>
                      <th className={thCls + ' text-right'}>Carrying Value</th>
                      <th className={thCls + ' text-right'}>DCF Value in Use</th>
                      <th className={thCls + ' text-right'}>FVLCD</th>
                      <th className={thCls + ' text-right'}>Recoverable Amount</th>
                      <th className={thCls + ' text-right'}>Headroom / (Impairment)</th>
                      <th className={thCls + ' text-center'}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.cguTests.map((t) => {
                      const viu = computeDcfValueInUse(t.cashFlows, t.discountRatePct, t.terminalGrowthPct);
                      const recoverable = r2(Math.max(viu, t.fairValueLessCosts));
                      const diff = r2(recoverable - t.carryingAmount);
                      const impairment = diff < 0 ? Math.abs(diff) : 0;
                      return (
                        <tr key={t.id} className={rowCls}>
                          <td className="px-3 py-2">
                            <div className="font-bold text-[#082f4f]">{t.cguName}</div>
                            <div className="text-[10.5px] font-mono text-[#355875]">
                              WACC {t.discountRatePct}% · Terminal g {t.terminalGrowthPct}%
                            </div>
                          </td>
                          <td className={numCls}>{formatGHS(t.carryingAmount)}</td>
                          <td className={numCls}>{formatGHS(viu)}</td>
                          <td className={numCls}>{formatGHS(t.fairValueLessCosts)}</td>
                          <td className={numCls + ' font-bold text-[#006f98]'}>{formatGHS(recoverable)}</td>
                          <td className={numCls + ` font-black ${impairment === 0 ? 'text-emerald-800' : 'text-rose-800'}`}>
                            {impairment === 0
                              ? `+${symbol}${formatGHS(diff)}`
                              : `-${symbol}${formatGHS(impairment)}`}
                          </td>
                          <td className="px-3 py-2 text-center">
                            {impairment > 0 ? (
                              <button
                                type="button"
                                disabled={readOnly}
                                onClick={() => handlePostImpairment(t, impairment, recoverable)}
                                className="rounded bg-[#b42318] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-rose-800 disabled:opacity-40"
                              >
                                Post Impairment
                              </button>
                            ) : (
                              <span className="text-[11px] text-emerald-700 font-semibold">No Impairment</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <Card title="Run DCF Value-in-Use Impairment Test" sub="Enter projected annual cash flows (comma-separated) and pre-tax discount rate">
            <form onSubmit={handleAddCgu} className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">CGU / Asset Group Name</label>
                <input type="text" value={cguName} onChange={(e) => setCguName(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Carrying Amount ({symbol})</label>
                <input type="number" min="0.01" step="0.01" value={cguCarrying || ''} onChange={(e) => setCguCarrying(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Fair Value Less Costs of Disposal ({symbol})</label>
                <input type="number" min="0" step="0.01" value={cguFvlcd || ''} onChange={(e) => setCguFvlcd(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" />
              </div>
              <div className="md:col-span-2">
                <label className="block font-bold text-[#0a253e] mb-1">Projected Annual Cash Flows (Years 1–5, comma-separated)</label>
                <input type="text" value={cguCfInput} onChange={(e) => setCguCfInput(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" required />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Discount Rate %</label>
                  <input type="number" min="0.1" step="0.1" value={cguDiscount} onChange={(e) => setCguDiscount(Number(e.target.value))} className="w-full rounded border border-sky-300 px-2 py-1.5 font-mono" required />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Terminal Growth %</label>
                  <input type="number" min="0" step="0.1" value={cguGrowth} onChange={(e) => setCguGrowth(Number(e.target.value))} className="w-full rounded border border-sky-300 px-2 py-1.5 font-mono" required />
                </div>
              </div>
              <div className="md:col-span-3 flex justify-end">
                <button type="submit" disabled={readOnly} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] disabled:opacity-40">
                  <Plus className="h-4 w-4" />
                  <span>Compute &amp; Save CGU Test</span>
                </button>
              </div>
            </form>
          </Card>
        </div>
      )}

      {/* TAB 4: IAS 37 PROVISIONS */}
      {activeTab === 'ias37_provisions' && (
        <div className="space-y-5">
          <Card
            title="IAS 37 Provisions & Contingent Liabilities"
            sub="Evaluates probability (>50% recognised at discounted PV; 10–50% disclosed as contingent liability) and posts initial recognition & annual discount unwinding"
          >
            {data.provisions.length === 0 ? (
              <p className="text-xs text-[#355875] py-4">
                No provisions or contingent liabilities recorded for {currentClient.code}. Add an obligation below.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[940px] text-xs">
                  <thead>
                    <tr className="border-b border-sky-200 bg-sky-50/70">
                      <th className={thCls}>Code</th>
                      <th className={thCls}>Obligation</th>
                      <th className={thCls + ' text-center'}>Probability</th>
                      <th className={thCls + ' text-right'}>Best Estimate</th>
                      <th className={thCls + ' text-right'}>Carrying PV</th>
                      <th className={thCls + ' text-right'}>Annual Unwinding</th>
                      <th className={thCls}>IAS 37 Classification</th>
                      <th className={thCls + ' text-center'}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.provisions.map((p) => {
                      const recognised = p.probability > 50;
                      const unwinding = recognised ? r2(p.currentCarrying * (p.discountRate / 100)) : 0;
                      const initPosted = clientLines.some((l) => l.docNo === `IAS37-INIT-${p.code}`);
                      return (
                        <tr key={p.id} className={rowCls}>
                          <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{p.code}</td>
                          <td className="px-3 py-2">
                            <div className="font-bold text-[#082f4f]">{p.title}</div>
                            <div className="text-[10.5px] text-[#355875]">{p.category} · {p.yearsToSettlement}y @ {p.discountRate}%</div>
                          </td>
                          <td className="px-3 py-2 text-center font-mono font-bold">{p.probability}%</td>
                          <td className={numCls}>{formatGHS(p.bestEstimate)}</td>
                          <td className={numCls + ' font-bold text-[#082f4f]'}>
                            {recognised ? formatGHS(p.currentCarrying) : '0.00'}
                          </td>
                          <td className={numCls + ' text-rose-700 font-bold'}>
                            {unwinding > 0 ? formatGHS(unwinding) : '—'}
                          </td>
                          <td className="px-3 py-2 text-[11px]">
                            {recognised
                              ? 'Recognised Provision (IAS 37.14)'
                              : p.probability >= 10
                              ? 'Disclosed Contingent Liability (IAS 37.86)'
                              : 'Remote (No Disclosure)'}
                          </td>
                          <td className="px-3 py-2 text-center">
                            {recognised ? (
                              <div className="flex flex-wrap items-center justify-center gap-1">
                                {!initPosted && (
                                  <button
                                    type="button"
                                    disabled={readOnly}
                                    onClick={() => handlePostProvisionInitial(p)}
                                    className="rounded border border-sky-300 bg-sky-50 px-2 py-1 text-[10.5px] font-bold text-[#082f4f]"
                                  >
                                    Recognise PV
                                  </button>
                                )}
                                {unwinding > 0 && (
                                  <button
                                    type="button"
                                    disabled={readOnly}
                                    onClick={() => handlePostProvisionUnwinding(p)}
                                    className="rounded bg-[#082f4f] px-2.5 py-1 text-[10.5px] font-bold text-white"
                                  >
                                    Unwind Discount
                                  </button>
                                )}
                              </div>
                            ) : (
                              <span className="text-[11px] text-slate-500">Note Only</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <Card title="Evaluate New Obligation / Contingency (IAS 37)" sub="Automatically discounts probable outflows to present value">
            <form onSubmit={handleAddProvision} className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Obligation Title</label>
                <input type="text" value={prvTitle} onChange={(e) => setPrvTitle(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Category</label>
                <select value={prvCategory} onChange={(e) => setPrvCategory(e.target.value)} className="w-full rounded border border-sky-300 px-2 py-1.5">
                  <option value="Environmental / Decommissioning">Environmental / Decommissioning</option>
                  <option value="Legal / Regulatory Claim">Legal / Regulatory Claim</option>
                  <option value="Warranty & Onerous Contracts">Warranty &amp; Onerous Contracts</option>
                  <option value="Restructuring Obligation">Restructuring Obligation</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Best Estimate Outflow ({symbol})</label>
                <input type="number" min="0.01" step="0.01" value={prvEstimate || ''} onChange={(e) => setPrvEstimate(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Probability % (&gt;50% = Provision)</label>
                <input type="number" min="0" max="100" value={prvProb} onChange={(e) => setPrvProb(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Discount Rate % p.a.</label>
                <input type="number" min="0" step="0.1" value={prvRate} onChange={(e) => setPrvRate(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Years to Settlement</label>
                <input type="number" min="0" max="50" value={prvYears} onChange={(e) => setPrvYears(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono" required />
              </div>
              <div className="md:col-span-3 flex justify-end">
                <button type="submit" disabled={readOnly} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] disabled:opacity-40">
                  <Plus className="h-4 w-4" />
                  <span>Evaluate &amp; Save Obligation</span>
                </button>
              </div>
            </form>
          </Card>
        </div>
      )}

      {/* TAB 5: IFRS 9 ECL STAGING (LIVE RECEIVABLES) */}
      {activeTab === 'ifrs9_instruments' && (
        <div className="space-y-5">
          <Card
            title="IFRS 9 Financial Instruments — Live Expected Credit Loss (ECL) Matrix"
            sub={`Derived from ${currentClient.code}'s open customer invoices as at ${postingDate} · Booked GL 119000: ${symbol}${formatGHS(eclComputation.bookedGl119)} · Required: ${symbol}${formatGHS(eclComputation.requiredTotal)}`}
            action={
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={readOnly}
                  onClick={() => void persistRegister(data, 'ECL loss rates saved.')}
                  className="inline-flex items-center gap-1 rounded border border-sky-300 bg-white px-3 py-1.5 text-xs font-bold text-[#082f4f] hover:bg-sky-50"
                >
                  <Save className="h-3.5 w-3.5" /> Save Rates
                </button>
                <button
                  type="button"
                  disabled={readOnly || Math.abs(eclComputation.delta) < 0.01}
                  onClick={handlePostEclTrueUp}
                  className="rounded bg-[#082f4f] px-3 py-1.5 text-xs font-bold text-white hover:bg-[#0c3f68] disabled:opacity-40"
                >
                  Post ECL True-Up ({eclComputation.delta >= 0 ? '+' : ''}
                  {formatGHS(eclComputation.delta)})
                </button>
              </div>
            }
          >
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-sky-200 bg-sky-50/70">
                    <th className={thCls}>Ageing Bucket</th>
                    <th className={thCls + ' text-center'}>IFRS 9 Stage</th>
                    <th className={thCls + ' text-right'}>Open Receivables ({symbol})</th>
                    <th className={thCls + ' text-right'}>ECL Loss Rate %</th>
                    <th className={thCls + ' text-right'}>Required ECL ({symbol})</th>
                    <th className={thCls + ' text-right'}>Net Carrying ({symbol})</th>
                  </tr>
                </thead>
                <tbody>
                  {eclComputation.rows.map((m) => (
                    <tr key={m.bucket} className={rowCls}>
                      <td className="px-3 py-2 font-bold text-[#082f4f]">{m.bucket}</td>
                      <td className="px-3 py-2 text-center">
                        <span
                          className={`rounded px-2 py-0.5 font-mono text-[10.5px] font-bold ${
                            m.stage === 1
                              ? 'bg-emerald-100 text-emerald-800'
                              : m.stage === 2
                              ? 'bg-amber-100 text-[#855b00]'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          Stage {m.stage}
                        </span>
                      </td>
                      <td className={numCls}>{formatGHS(m.exposure)}</td>
                      <td className="px-3 py-1.5 text-right">
                        <input
                          type="number"
                          min="0"
                          max="100"
                          step="0.1"
                          value={m.rate}
                          onChange={(e) => {
                            const nextRates = [...data.eclRates];
                            nextRates[m.idx] = Math.min(100, Math.max(0, Number(e.target.value)));
                            setLocalDraft({ ...data, eclRates: nextRates });
                          }}
                          className="w-20 rounded border border-sky-300 px-2 py-1 text-right font-mono"
                        />
                      </td>
                      <td className={numCls + ' font-bold text-rose-800'}>{formatGHS(m.allowance)}</td>
                      <td className={numCls + ' font-bold text-emerald-800'}>{formatGHS(m.net)}</td>
                    </tr>
                  ))}
                  <tr className="bg-sky-100 font-bold border-t-2 border-sky-300">
                    <td colSpan={2} className="px-3 py-2.5 text-[#082f4f]">
                      Total Open Trade Receivables &amp; Lifetime ECL
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono">{formatGHS(eclComputation.totalExposure)}</td>
                    <td className="px-3 py-2.5 text-right font-mono">—</td>
                    <td className="px-3 py-2.5 text-right font-mono text-rose-800">
                      {formatGHS(eclComputation.requiredTotal)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-emerald-800">
                      {formatGHS(r2(eclComputation.totalExposure - eclComputation.requiredTotal))}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* TAB 6: IFRS 5 HELD FOR SALE (LIVE FIXED ASSETS) */}
      {activeTab === 'ifrs5_hfs' && (
        <div className="space-y-5">
          <Card
            title="IFRS 5 Held for Sale — Review-Only Valuation Preview"
            sub="Preview lower of carrying amount and fair value less costs to sell; automatic transfer is disabled until a distinct held-for-sale register state and reviewed classification workflow are implemented."
          >
            {activeAssets.length === 0 ? (
              <p className="text-xs text-[#355875] py-4">
                No active fixed assets in {currentClient.code}&rsquo;s Fixed Assets Register. Register assets in Fixed Assets first.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[920px] text-xs">
                  <thead>
                    <tr className="border-b border-sky-200 bg-sky-50/70">
                      <th className={thCls}>Asset Tag</th>
                      <th className={thCls}>Description</th>
                      <th className={thCls + ' text-right'}>Gross Cost</th>
                      <th className={thCls + ' text-right'}>Accum. Dep</th>
                      <th className={thCls + ' text-right'}>Carrying NBV</th>
                      <th className={thCls + ' text-right'}>Fair Value Less Costs ({symbol})</th>
                      <th className={thCls + ' text-right'}>Transfer Impairment</th>
                      <th className={thCls + ' text-center'}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {activeAssets.map((a) => {
                      const nbv = r2(Math.max(0, a.cost - a.accumDep));
                      const fvlcd = r2(Math.max(0, fvlcdByAsset[a.id] ?? nbv));
                      const impairment = r2(Math.max(0, nbv - fvlcd));
                      return (
                        <tr key={a.id} className={rowCls}>
                          <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{a.assetTag}</td>
                          <td className="px-3 py-2 font-bold text-[#082f4f]">{a.name}</td>
                          <td className={numCls}>{formatGHS(a.cost)}</td>
                          <td className={numCls}>{formatGHS(a.accumDep)}</td>
                          <td className={numCls + ' font-bold'}>{formatGHS(nbv)}</td>
                          <td className="px-3 py-1.5 text-right">
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              value={fvlcd}
                              onChange={(e) =>
                                setFvlcdByAsset((prev) => ({ ...prev, [a.id]: Number(e.target.value) }))
                              }
                              className="w-28 rounded border border-sky-300 px-2 py-1 text-right font-mono"
                            />
                          </td>
                          <td className={numCls + ' text-rose-800 font-bold'}>{formatGHS(impairment)}</td>
                          <td className="px-3 py-2 text-center">
                            <button
                              type="button"
                              disabled
                              title="Not available: a held-for-sale reclassification must not be recorded as an asset disposal. Use a reviewed journal and register evidence."
                              onClick={() => handleClassifyHeldForSale(a)}
                              className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] disabled:opacity-40"
                            >
                              Review required
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      )}
    </div>
  );
};
