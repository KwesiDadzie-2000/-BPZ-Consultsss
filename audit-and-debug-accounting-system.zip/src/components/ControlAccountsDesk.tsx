import React, { useMemo, useState } from 'react';
import type {
  ACDOCALine,
  AccountMaster,
  BankAccount,
  ClientEntity,
  FixedAsset,
  PrepaymentRecord,
  PrepaymentScheduleLine,
  PurchaseOrder,
  SalesInvoice,
  StockItem,
  UserAccount,
} from '../types/accounting';
import {
  reconcileControlAccounts,
  type ControlAccountReconciliationRow,
} from '../utils/controlAccounts';
import { useProduction } from '@/lib/productionClient';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import { ModulePrintButton } from './ModulePrintButton';
import { downloadCsv } from './DeskKit';
import {
  ShieldCheck,
  AlertTriangle,
  ArrowUpRight,
  FileSpreadsheet,
  RefreshCw,
  Lock,
} from 'lucide-react';

interface ControlAccountsDeskProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  bankAccounts: BankAccount[];
  salesInvoices: SalesInvoice[];
  purchaseOrders: PurchaseOrder[];
  stockItems: StockItem[];
  fixedAssets: FixedAsset[];
  prepaymentRecords: PrepaymentRecord[];
  prepaymentSchedules: PrepaymentScheduleLine[];
  onReconcileBankBalances?: (updated: BankAccount[]) => void;
  onNavigate: (section: string) => void;
}

export const ControlAccountsDesk: React.FC<ControlAccountsDeskProps> = ({
  currentClient,
  lines,
  accounts,
  bankAccounts,
  salesInvoices,
  purchaseOrders,
  stockItems,
  fixedAssets,
  prepaymentRecords,
  prepaymentSchedules,
  onReconcileBankBalances,
  onNavigate,
}) => {
  const [filter, setFilter] = useState<'all' | 'variance' | 'direct_je'>('all');
  const [selectedRow, setSelectedRow] = useState<ControlAccountReconciliationRow | null>(null);

  const prod = useProduction(currentClient.id);
  const openWipOrders = prod.orders.filter((o) => o.status !== 'Closed');
  const openWipValue = openWipOrders.reduce(
    (s, o) => s + (prod.wipByOrder[o.id] ?? 0),
    0
  );

  const rows = useMemo(
    () =>
      reconcileControlAccounts({
        clientId: currentClient.id,
        lines,
        accounts,
        bankAccounts,
        salesInvoices,
        purchaseOrders,
        stockItems,
        fixedAssets,
        prepaymentRecords,
        prepaymentSchedules,
        openWipFromOrders: prod.loading ? undefined : openWipValue,
        openWipOrderCount: openWipOrders.length,
      }),
    [
      currentClient.id,
      lines,
      accounts,
      bankAccounts,
      salesInvoices,
      purchaseOrders,
      stockItems,
      fixedAssets,
      prepaymentRecords,
      prepaymentSchedules,
      prod.loading,
      openWipValue,
      openWipOrders.length,
    ]
  );

  const visibleRows = useMemo(() => {
    if (filter === 'variance') return rows.filter((r) => Math.abs(r.variance) >= 0.01 || !r.independentlySupported);
    if (filter === 'direct_je') return rows.filter((r) => r.directManualLines.length > 0);
    return rows;
  }, [rows, filter]);

  const reconciledCount = rows.filter((r) => r.reconciled).length;
  const varianceCount = rows.filter((r) => Math.abs(r.variance) >= 0.01).length;
  const unevidencedCount = rows.filter((r) => !r.independentlySupported && Math.abs(r.variance) < 0.01).length;
  const totalAbsVariance = rows.reduce((s, r) => s + Math.abs(r.variance), 0);
  const directJeCount = rows.reduce((s, r) => s + r.directManualLines.length, 0);
  const hasTreasuryVariance = rows.some(
    (r) => r.def.subledgerFamily === 'treasury' && Math.abs(r.variance) >= 0.01
  );

  // A bank reconciliation must compare to an external bank statement and
  // document timing differences. Copying the GL balance into a browser register
  // is NOT evidence and must never be offered as a one-click cure.
  const handleSyncTreasury = () => onNavigate('banking');

  const handleExportCsv = () => {
    downloadCsv(`${currentClient.code}_control_accounts_reconciliation.csv`, [
      [
        'Account No',
        'Control Account',
        'Subledger Module',
        'Subledger Items',
        'GL Balance',
        'Subledger Balance',
        'Variance (GL - Subledger)',
        'Status',
        'Direct Manual Lines',
        'Diagnosis',
      ],
      ...rows.map((r) => [
        r.def.accountNo,
        r.accountName,
        r.def.subledgerLabel,
        r.subledgerItemCount,
        r.glBalance,
        r.subledgerBalance,
        r.variance,
        r.reconciled ? 'Register tie-out only' : Math.abs(r.variance) >= 0.01 ? 'Variance' : 'Needs independent evidence',
        r.directManualLines.length,
        r.diagnosis,
      ]),
    ]);
  };

  const symbol = currentClient.currency === 'GHS' ? '₵' : `${currentClient.currency} `;

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`CTL · SUBLEDGER-TO-GL CONTROL ACCOUNTS · ${currentClient.code}`}
        title="Control Accounts & Subledger Reconciliation"
        desc="Compares GL control accounts with available registers. A zero difference is only a preliminary tie-out: bank statements, supplier/customer confirmations, payroll and statutory returns still require independent review."
      >
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-1.5 text-xs font-bold text-[#082f4f] hover:bg-sky-50"
          >
            <FileSpreadsheet className="h-3.5 w-3.5" />
            <span>Export CSV</span>
          </button>
          <ModulePrintButton
            title={`Control Accounts Reconciliation — ${currentClient.name}`}
            subtitle={`${currentClient.code} · Subledger vs General Ledger Tie-Out`}
          />
        </div>
      </PageHeader>

      <div className="rounded-xl border border-amber-300 bg-amber-50 p-3 text-xs text-amber-950">
        <strong>Not an independent audit:</strong> payroll, tax, expense bills and WIP can be derived from the same journal; they cannot verify themselves. A register-to-GL match does not replace a bank statement, supplier/customer confirmation or regulator return. Do not clear differences by copying GL balances into registers.
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-5">
        <Stat
          label="Control Accounts Monitored"
          value={rows.length}
          sub="AR, AP, Stock, WIP, PPE, Prepayments, Cash, Tax"
        />
        <Stat
          label="Register-to-GL Tie-Out"
          value={`${reconciledCount} / ${rows.length}`}
          tone="text-emerald-700"
          sub="Subject to external evidence & reviewer sign-off"
        />
        <Stat
          label="Accounts with Variance"
          value={varianceCount}
          tone={varianceCount === 0 ? 'text-emerald-700' : 'text-rose-700'}
          sub={`Total variance: ${symbol}${formatGHS(totalAbsVariance)}`}
        />
        <Stat
          label="Independent Evidence Needed"
          value={unevidencedCount}
          tone="text-amber-800"
          sub="No separate subledger or third-party support"
        />
        <Stat
          label="Direct Manual Postings"
          value={directJeCount}
          tone={directJeCount === 0 ? 'text-emerald-700' : 'text-amber-800'}
          sub="JE lines bypassing subledger modules"
        />
      </div>

      {hasTreasuryVariance && onReconcileBankBalances && (
        <div className="rounded-xl border border-amber-300 bg-amber-50 p-4 text-xs text-amber-950 flex flex-wrap items-center justify-between gap-3">
          <div>
            <strong>Treasury variance:</strong> Investigate the external bank statement, uncleared deposits, bank fees and missing journals. Do not edit a balance merely to make it agree with the GL.
          </div>
          <button
            type="button"
            onClick={handleSyncTreasury}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68]"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Investigate in Banking</span>
          </button>
        </div>
      )}

      <Card
        title="Control Account Tie-Out Matrix"
        sub="Click any control account to inspect its reconciliation diagnosis or jump to the owning subledger desk"
        action={
          <div className="flex rounded-lg border border-sky-300 bg-white p-0.5 text-[11px] font-bold">
            <button
              type="button"
              onClick={() => setFilter('all')}
              className={`rounded-md px-2.5 py-1 ${filter === 'all' ? 'bg-[#082f4f] text-white' : 'text-[#082f4f] hover:bg-sky-50'}`}
            >
              All ({rows.length})
            </button>
            <button
              type="button"
              onClick={() => setFilter('variance')}
              className={`rounded-md px-2.5 py-1 ${filter === 'variance' ? 'bg-[#082f4f] text-white' : 'text-[#082f4f] hover:bg-sky-50'}`}
            >
              Exceptions ({varianceCount + unevidencedCount})
            </button>
            <button
              type="button"
              onClick={() => setFilter('direct_je')}
              className={`rounded-md px-2.5 py-1 ${filter === 'direct_je' ? 'bg-[#082f4f] text-white' : 'text-[#082f4f] hover:bg-sky-50'}`}
            >
              Direct JEs ({rows.filter((r) => r.directManualLines.length > 0).length})
            </button>
          </div>
        }
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[960px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>GL Code</th>
                <th className={thCls}>Control Account</th>
                <th className={thCls}>Owning Subledger</th>
                <th className={thCls + ' text-right'}>GL Balance</th>
                <th className={thCls + ' text-right'}>Subledger Balance</th>
                <th className={thCls + ' text-right'}>Variance</th>
                <th className={thCls + ' text-center'}>Status</th>
                <th className={thCls + ' text-center'}>Subledger Desk</th>
              </tr>
            </thead>
            <tbody>
              {visibleRows.map((r) => (
                <tr
                  key={r.def.accountNo}
                  onClick={() => setSelectedRow(r)}
                    className={`${rowCls} cursor-pointer ${Math.abs(r.variance) >= 0.01 ? 'bg-rose-50/40' : !r.independentlySupported ? 'bg-amber-50/40' : ''}`}
                >
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">
                    <div className="flex items-center gap-1">
                      <span>{r.def.accountNo}</span>
                      {r.def.lockDirectManualEntry && (
                        <span title="Protected Control Account — direct manual JE restricted">
                          <Lock className="h-3 w-3 text-[#355875]" />
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-3 py-2">
                    <div className="font-bold text-[#082f4f]">{r.accountName}</div>
                    {r.directManualLines.length > 0 && (
                      <div className="text-[10.5px] font-semibold text-amber-800">
                        ⚠ {r.directManualLines.length} direct manual JE line(s) ({symbol}
                        {formatGHS(r.directManualAmount)})
                      </div>
                    )}
                  </td>
                  <td className="px-3 py-2 text-[#2d4f6d]">
                    <div>{r.def.subledgerLabel}</div>
                    <div className="text-[10.5px] font-mono text-[#355875]">
                      {r.subledgerItemCount} active record(s)
                    </div>
                  </td>
                  <td className={numCls + ' font-mono font-bold text-[#082f4f]'}>
                    {symbol}
                    {formatGHS(r.glBalance)}
                  </td>
                  <td className={numCls + ' font-mono font-bold text-[#006f98]'}>
                    {symbol}
                    {formatGHS(r.subledgerBalance)}
                  </td>
                  <td
                    className={
                      numCls +
                       ` font-mono font-black ${Math.abs(r.variance) >= 0.01 ? 'text-rose-700' : r.reconciled ? 'text-emerald-700' : 'text-amber-800'}`
                    }
                  >
                    {Math.abs(r.variance) < 0.01
                      ? '0.00'
                      : `${r.variance > 0 ? '+' : '-'}${symbol}${formatGHS(Math.abs(r.variance))}`}
                  </td>
                  <td className="px-3 py-2 text-center">
                    {r.reconciled ? (
                      <span className="inline-flex items-center gap-1 rounded bg-emerald-100 border border-emerald-300 px-2 py-0.5 text-[10.5px] font-bold text-emerald-800">
                        <ShieldCheck className="h-3 w-3" />
                        Register ties out
                      </span>
                    ) : Math.abs(r.variance) >= 0.01 ? (
                      <span className="inline-flex items-center gap-1 rounded bg-rose-100 border border-rose-300 px-2 py-0.5 text-[10.5px] font-bold text-rose-800">
                        <AlertTriangle className="h-3 w-3" />
                        Variance
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded bg-amber-100 border border-amber-300 px-2 py-0.5 text-[10.5px] font-bold text-amber-900">
                        <AlertTriangle className="h-3 w-3" />
                        Needs evidence
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2 text-center" onClick={(e) => e.stopPropagation()}>
                    <button
                      type="button"
                      onClick={() => onNavigate(r.def.subledgerSection)}
                      className="inline-flex items-center gap-1 rounded border border-sky-300 bg-sky-50 px-2.5 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-100"
                    >
                      <span>Open Desk</span>
                      <ArrowUpRight className="h-3 w-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {selectedRow && (
        <Card
          title={`Control Account Diagnostic — ${selectedRow.def.accountNo} · ${selectedRow.accountName}`}
          sub={`Subledger: ${selectedRow.def.subledgerLabel}`}
          action={
            <button
              type="button"
              onClick={() => setSelectedRow(null)}
              className="text-xs font-bold text-[#355875] hover:underline"
            >
              Close
            </button>
          }
        >
          <div className="space-y-3 text-xs">
            <div
              className={`rounded-lg border p-3 font-semibold ${
                selectedRow.reconciled
                  ? 'border-emerald-300 bg-emerald-50 text-emerald-900'
                  : Math.abs(selectedRow.variance) >= 0.01
                    ? 'border-rose-300 bg-rose-50 text-rose-900'
                    : 'border-amber-300 bg-amber-50 text-amber-900'
              }`}
            >
              {selectedRow.diagnosis}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono">
              <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-3">
                <div className="text-[10.5px] uppercase text-[#355875]">General Ledger Balance</div>
                <div className="text-sm font-black text-[#082f4f] mt-0.5">
                  {symbol}
                  {formatGHS(selectedRow.glBalance)}
                </div>
              </div>
              <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-3">
                <div className="text-[10.5px] uppercase text-[#355875]">Subledger Register Balance</div>
                <div className="text-sm font-black text-[#006f98] mt-0.5">
                  {symbol}
                  {formatGHS(selectedRow.subledgerBalance)}
                </div>
              </div>
              <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-3">
                <div className="text-[10.5px] uppercase text-[#355875]">Unreconciled Variance</div>
                <div
                  className={`text-sm font-black mt-0.5 ${
                    selectedRow.reconciled ? 'text-emerald-700' : 'text-rose-700'
                  }`}
                >
                  {symbol}
                  {formatGHS(selectedRow.variance)}
                </div>
              </div>
            </div>
            {selectedRow.directManualLines.length > 0 && (
              <div>
                <div className="font-bold text-[#082f4f] mb-1.5">
                  Direct Manual Journal Entries on {selectedRow.def.accountNo} (outside subledger workflow):
                </div>
                <div className="overflow-x-auto rounded-lg border border-amber-200">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="bg-amber-50 border-b border-amber-200">
                        <th className={thCls}>Date</th>
                        <th className={thCls}>Doc No</th>
                        <th className={thCls}>Description</th>
                        <th className={thCls}>Maker</th>
                        <th className={thCls + ' text-right'}>Debit</th>
                        <th className={thCls + ' text-right'}>Credit</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedRow.directManualLines.map((l) => (
                        <tr key={l.id} className={rowCls}>
                          <td className="px-3 py-1.5 font-mono">{l.date}</td>
                          <td className="px-3 py-1.5 font-mono font-bold text-[#855b00]">{l.docNo}</td>
                          <td className="px-3 py-1.5">{l.description}</td>
                          <td className="px-3 py-1.5 font-mono">{l.createdBy}</td>
                          <td className={numCls}>{l.debit ? formatGHS(l.debit) : '—'}</td>
                          <td className={numCls}>{l.credit ? formatGHS(l.credit) : '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  );
};
