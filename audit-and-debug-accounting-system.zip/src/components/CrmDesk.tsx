"use client";

import { useMemo, useState } from "react";
import { Building2, HeartHandshake, Mail, Phone, Plus, Target, Ticket, Trash2, TrendingUp, UserRound } from "lucide-react";
import type { BusinessPartner, ClientEntity, PurchaseOrder, SalesInvoice, UserAccount } from "../types/accounting";
import { Badge, Card, PageHeader, Stat, formatGHS, numCls, rowCls, tdCls, thCls } from "./ui";
import { Alert, DeskTabs, EmptyState, Field, downloadCsv, inputCls, useDeskRecords, useMoney } from "./DeskKit";

interface Contact extends Record<string, unknown> { id: string; account: string; name: string; title: string; email: string; phone: string; role: string; }
interface Opportunity extends Record<string, unknown> { id: string; name: string; account: string; value: number; stage: string; probability: number; closeDate: string; owner: string; notes: string; }
interface Activity extends Record<string, unknown> { id: string; date: string; type: string; account: string; contact: string; summary: string; outcome: string; nextStep: string; }
interface TicketRecord extends Record<string, unknown> { id: string; subject: string; account: string; priority: string; status: string; owner: string; opened: string; detail: string; }

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  partners: BusinessPartner[];
  invoices: SalesInvoice[];
  orders: PurchaseOrder[];
  accounts: { accountNo: string; name: string }[];
  onNavigate?: (section: string) => void;
}

const TABS = [
  { id: "overview", label: "Overview" },
  { id: "accounts", label: "Client accounts" },
  { id: "contacts", label: "Contacts" },
  { id: "pipeline", label: "Pipeline & opportunities" },
  { id: "activities", label: "Activities" },
  { id: "tickets", label: "Service desk" },
];

const STAGES = ["Prospecting", "Qualification", "Proposal", "Negotiation", "Won", "Lost"];
const stageProbability: Record<string, number> = { Prospecting: 10, Qualification: 30, Proposal: 50, Negotiation: 70, Won: 100, Lost: 0 };

export function CrmDesk({ currentClient, currentUser, partners, invoices, orders, accounts, onNavigate }: Props) {
  const [tab, setTab] = useState("overview");
  const { fmt, today } = useMoney();
  const contacts = useDeskRecords<Contact>("crm", currentClient.id, "contact");
  const opportunities = useDeskRecords<Opportunity>("crm", currentClient.id, "opportunity");
  const activities = useDeskRecords<Activity>("crm", currentClient.id, "activity");
  const tickets = useDeskRecords<TicketRecord>("crm", currentClient.id, "ticket");

  const customers = useMemo(() => {
    const names = new Set(partners.filter((p) => p.type === "Customer").map((p) => p.name));
    invoices.forEach((i) => names.add(i.customerName));
    return Array.from(names).sort();
  }, [partners, invoices]);

  const revenueByCustomer = useMemo(() => {
    const map = new Map<string, { billed: number; paid: number; last?: string; count: number }>();
    invoices.forEach((i) => {
      const current = map.get(i.customerName) ?? { billed: 0, paid: 0, count: 0 };
      map.set(i.customerName, {
        billed: current.billed + (i.netRevenue || 0),
        paid: current.paid + (i.paidAmount || 0),
        last: !current.last || i.date > current.last ? i.date : current.last,
        count: current.count + 1,
      });
    });
    return map;
  }, [invoices]);

  const pipelineValue = opportunities.records.filter((o) => o.stage !== "Won" && o.stage !== "Lost").reduce((s, o) => s + Number(o.value || 0), 0);
  const weighted = opportunities.records.filter((o) => o.stage !== "Won" && o.stage !== "Lost").reduce((s, o) => s + Number(o.value || 0) * (Number(o.probability ?? stageProbability[o.stage] ?? 0) / 100), 0);
  const won = opportunities.records.filter((o) => o.stage === "Won").reduce((s, o) => s + Number(o.value || 0), 0);
  const openTickets = tickets.records.filter((t) => t.status !== "resolved" && t.status !== "closed");
  const outstanding = invoices.reduce((s, i) => s + Math.max(0, i.totalReceivable - i.paidAmount), 0);
  const customerNames = customers.length;

  return (
    <div>
      <PageHeader
        kicker={`${currentClient.code} · Client Relationship Management`}
        title="Client Relationship Desk"
        desc="A single desk for every client relationship: the 360° account view, contacts, sales pipeline, meetings and communications, and service tickets. Financial figures are pulled live from the sales ledger — nothing is re-keyed."
      >
        <Badge tone="ad">CRM</Badge>
        <Badge tone="slate">{customerNames} client accounts</Badge>
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label="Client accounts" value={customerNames} sub={`${partners.filter((p) => p.type === "Customer").length} on master file`} />
        <Stat label="Open pipeline" value={`GH₵ ${fmt(pipelineValue)}`} sub={`Weighted GH₵ ${fmt(weighted)}`} />
        <Stat label="Won value" value={`GH₵ ${fmt(won)}`} sub={`${opportunities.records.filter((o) => o.stage === "Won").length} deals`} />
        <Stat label="Receivables" value={`GH₵ ${fmt(outstanding)}`} sub="Unsettled client invoices" />
        <Stat label="Open tickets" value={openTickets.length} sub={`${tickets.records.length} logged`} />
      </div>

      <DeskTabs
        tabs={TABS.map((t) => ({
          ...t,
          badge: t.id === "contacts" ? contacts.records.length : t.id === "pipeline" ? opportunities.records.length : t.id === "activities" ? activities.records.length : t.id === "tickets" ? openTickets.length : 0,
        }))}
        active={tab}
        onChange={setTab}
      />

      {tab === "overview" && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card title="Client 360°" sub="Billed value, settled cash and outstanding balance by account" className="lg:col-span-2">
            {customers.length === 0 ? <EmptyState title="No client accounts yet" detail="Create customers in Sales, or add contacts and opportunities here." /> : (
              <div className="overflow-x-auto rounded-lg border border-sky-200">
                <table className="w-full min-w-[640px] border-collapse">
                  <thead><tr><th className={thCls}>Client</th><th className={thCls}>Contacts</th><th className={thCls}>Invoices</th><th className={thCls}>Billed</th><th className={thCls}>Outstanding</th><th className={thCls}>Health</th></tr></thead>
                  <tbody>
                    {customers.map((name) => {
                      const r = revenueByCustomer.get(name);
                      const balance = invoices.filter((i) => i.customerName === name).reduce((s, i) => s + Math.max(0, i.totalReceivable - i.paidAmount), 0);
                      const contactCount = contacts.records.filter((c) => c.account === name).length;
                      const hasOpp = opportunities.records.some((o) => o.account === name && o.stage !== "Lost");
                      const health = (r?.billed ?? 0) > 0 && balance <= 0 ? "green" : balance > 0 ? "amber" : "slate";
                      return (
                        <tr key={name} className={rowCls}>
                          <td className={tdCls}><div className="font-bold text-[#082f4f]">{name}</div><div className="text-[10.5px] text-[#355875]">{r?.last ? `Last invoice ${r.last}` : "No invoice yet"}</div></td>
                          <td className={tdCls}>{contactCount}</td>
                          <td className={numCls}>{r?.count ?? 0}</td>
                          <td className={numCls}>{fmt(r?.billed ?? 0)}</td>
                          <td className={numCls}>{fmt(balance)}</td>
                          <td className={tdCls}><Badge tone={health}>{balance > 0 ? "Follow-up" : hasOpp ? "Growing" : "Active"}</Badge></td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
          <Card title="Relationship signals" sub="Live indicators from the ledger and this desk">
            <ul className="space-y-2.5 text-xs">
              <Signal icon={Building2} label="Accounts with overdue balances" value={`${new Set(invoices.filter((i) => i.totalReceivable - i.paidAmount > 0).map((i) => i.customerName)).size}`} />
              <Signal icon={Target} label="Deals closing this month" value={`${opportunities.records.filter((o) => o.closeDate?.startsWith(today().slice(0, 7)) && o.stage !== "Won" && o.stage !== "Lost").length}`} />
              <Signal icon={HeartHandshake} label="Clients without a named contact" value={`${customers.filter((name) => !contacts.records.some((c) => c.account === name)).length}`} />
              <Signal icon={Ticket} label="High-priority tickets" value={`${openTickets.filter((t) => t.priority === "High" || t.priority === "Critical").length}`} />
              <Signal icon={TrendingUp} label="Purchase orders raised" value={`${orders.length}`} />
            </ul>
            <div className="mt-4 rounded-lg border border-sky-200 bg-sky-50/60 p-3 text-[11px] text-[#2d4f6d]">
              Tip: open an account in <strong>Client accounts</strong> to see its contacts, deals, activities and tickets side by side.
            </div>
            {onNavigate && (
              <div className="mt-2 grid gap-1.5">
                <button onClick={() => onNavigate("business_partners_crm")} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">Open the client master file →</button>
                <button onClick={() => onNavigate("report_clients_r")} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">Open clients reports →</button>
              </div>
            )}
          </Card>
        </div>
      )}

      {tab === "accounts" && <AccountsTab customers={customers} partners={partners} invoices={invoices} contacts={contacts.records} opportunities={opportunities.records} tickets={tickets.records} accounts={accounts} onNavigate={onNavigate} />}
      {tab === "contacts" && <ContactsTab desk={contacts} customers={customers} />}
      {tab === "pipeline" && <PipelineTab desk={opportunities} customers={customers} username={currentUser.username} />}
      {tab === "activities" && <ActivitiesTab desk={activities} customers={customers} contacts={contacts.records} />}
      {tab === "tickets" && <TicketsTab desk={tickets} customers={customers} username={currentUser.username} />}
    </div>
  );
}

function Signal({ icon: Icon, label, value }: { icon: typeof Building2; label: string; value: string }) {
  return (
    <li className="flex items-center justify-between gap-2 rounded-lg border border-sky-100 bg-white px-2.5 py-2">
      <span className="flex items-center gap-2 text-[#2d4f6d]"><Icon className="h-3.5 w-3.5 text-[#a51f58]" />{label}</span>
      <span className="font-mono text-sm font-bold text-[#082f4f]">{value}</span>
    </li>
  );
}

function AccountsTab({ customers, partners, invoices, contacts, opportunities, tickets, accounts, onNavigate }: {
  customers: string[];
  partners: BusinessPartner[];
  invoices: SalesInvoice[];
  contacts: Contact[];
  opportunities: Opportunity[];
  tickets: TicketRecord[];
  accounts: { accountNo: string; name: string }[];
  onNavigate?: (section: string) => void;
}) {
  const { fmt, today } = useMoney();
  const [selected, setSelected] = useState<string>(customers[0] ?? "");
  const active = customers.includes(selected) ? selected : customers[0] ?? "";
  const partner = partners.find((p) => p.name === active);
  const clientInvoices = invoices.filter((i) => i.customerName === active);
  const clientContacts = contacts.filter((c) => c.account === active);
  const clientOpps = opportunities.filter((o) => o.account === active);
  const clientTickets = tickets.filter((t) => t.account === active);
  const billed = clientInvoices.reduce((s, i) => s + i.netRevenue, 0);
  const outstanding = clientInvoices.reduce((s, i) => s + Math.max(0, i.totalReceivable - i.paidAmount), 0);

  return (
    <div className="grid gap-4 lg:grid-cols-[260px_1fr]">
      <Card title="Accounts" sub="Customers on the master file and sales ledger">
        <div className="max-h-[520px] space-y-1 overflow-y-auto">
          {customers.map((name) => {
            const bal = invoices.filter((i) => i.customerName === name).reduce((s, i) => s + Math.max(0, i.totalReceivable - i.paidAmount), 0);
            return (
              <button key={name} onClick={() => setSelected(name)} className={`w-full rounded-lg px-2.5 py-2 text-left text-xs font-semibold ${active === name ? "bg-[#082f4f] text-white" : "text-[#163653] hover:bg-sky-100"}`}>
                <span className="block truncate">{name}</span>
                <span className={`block font-mono text-[10px] ${active === name ? "text-amber-200" : bal > 0 ? "text-amber-700" : "text-[#355875]"}`}>{bal > 0 ? `GH₵ ${fmt(bal)} due` : "Settled"}</span>
              </button>
            );
          })}
        </div>
      </Card>
      <div className="space-y-4">
        <Card title={active || "Select an account"} sub={partner ? `${partner.code} · ${partner.email || "no email"} · ${partner.phone || "no phone"}` : "Account details from the sales ledger"} action={onNavigate ? <button onClick={() => onNavigate("business_partners_crm")} className="rounded-lg border border-sky-300 bg-white px-2 py-1 text-[10.5px] font-bold text-[#082f4f]">Client master file →</button> : undefined}>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Billed (net)" value={`GH₵ ${fmt(billed)}`} />
            <Stat label="Outstanding" value={`GH₵ ${fmt(outstanding)}`} tone={outstanding > 0 ? "text-[#b42318]" : "text-[#087a55]"} />
            <Stat label="Deals" value={clientOpps.length} />
            <Stat label="Open tickets" value={clientTickets.filter((t) => t.status !== "resolved" && t.status !== "closed").length} />
          </div>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <div className="rounded-lg border border-sky-200 p-3">
              <div className="mb-1 text-[10px] font-black uppercase tracking-wider text-[#355875]">Named contacts</div>
              {clientContacts.length === 0 ? <p className="text-[11px] text-[#355875]">No contacts captured.</p> : clientContacts.map((c) => (
                <div key={c.id} className="border-b border-sky-100 py-1 last:border-0"><div className="text-[11.5px] font-bold text-[#082f4f]">{c.name}</div><div className="text-[10.5px] text-[#355875]">{c.title || "Contact"} · {c.email || c.phone || "no channel"}</div></div>
              ))}
            </div>
            <div className="rounded-lg border border-sky-200 p-3">
              <div className="mb-1 text-[10px] font-black uppercase tracking-wider text-[#355875]">Open deals</div>
              {clientOpps.length === 0 ? <p className="text-[11px] text-[#355875]">No opportunities yet.</p> : clientOpps.map((o) => (
                <div key={o.id} className="flex items-center justify-between border-b border-sky-100 py-1 last:border-0"><span className="text-[11px] font-semibold text-[#082f4f]">{o.name}</span><Badge tone={o.stage === "Won" ? "green" : o.stage === "Lost" ? "red" : "amber"}>{o.stage}</Badge></div>
              ))}
            </div>
          </div>
        </Card>
        <Card title="Invoice history" sub={`Sales ledger · as at ${today()}`}>
          {clientInvoices.length === 0 ? <EmptyState title="No invoices for this account" detail="Raise an invoice in Sales & Invoicing, and it appears here automatically." /> : (
            <div className="overflow-x-auto rounded-lg border border-sky-200">
              <table className="w-full min-w-[560px] border-collapse">
                <thead><tr><th className={thCls}>Invoice</th><th className={thCls}>Date</th><th className={thCls}>Net</th><th className={thCls}>Total</th><th className={thCls}>Paid</th><th className={thCls}>Status</th></tr></thead>
                <tbody>{clientInvoices.map((i) => (
                  <tr key={i.id} className={rowCls}><td className={tdCls}>{i.invNo}</td><td className={tdCls}>{i.date}</td><td className={numCls}>{fmt(i.netRevenue)}</td><td className={numCls}>{fmt(i.totalReceivable)}</td><td className={numCls}>{fmt(i.paidAmount)}</td><td className={tdCls}><Badge tone={i.status === "Paid" ? "green" : i.paidAmount > 0 ? "amber" : "slate"}>{i.status}</Badge></td></tr>
                ))}</tbody>
              </table>
            </div>
          )}
        </Card>
        <Card title="GL accounts referenced" sub="Revenue and receivable accounts available to this entity">
          <div className="flex flex-wrap gap-1.5">{accounts.slice(0, 10).map((a) => <Badge key={a.accountNo} tone="fi">{a.accountNo} · {a.name}</Badge>)}</div>
        </Card>
      </div>
    </div>
  );
}

function ContactsTab({ desk, customers }: { desk: ReturnType<typeof useDeskRecords<Contact>>; customers: string[] }) {
  const [draft, setDraft] = useState({ account: "", name: "", title: "", email: "", phone: "", role: "Decision maker" });
  const [filter, setFilter] = useState("all");
  const add = async () => {
    if (!draft.name.trim()) return;
    const saved = await desk.save({ ...draft, name: draft.name.trim() });
    if (saved) setDraft({ ...draft, name: "", email: "", phone: "" });
  };
  const rows = desk.records.filter((c) => filter === "all" || c.account === filter);
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
      <Card title="Contact book" sub="Every named person linked to a client account, with the channel to reach them." action={
        <select className={`${inputCls} max-w-[180px]`} value={filter} onChange={(e) => setFilter(e.target.value)}><option value="all">All accounts</option>{customers.map((c) => <option key={c} value={c}>{c}</option>)}</select>
      }>
        {desk.error && <Alert>{desk.error}</Alert>}
        {rows.length === 0 ? <EmptyState title="No contacts captured" detail="Add decision makers and day-to-day contacts so no relationship depends on one person's inbox." /> : (
          <div className="overflow-x-auto rounded-lg border border-sky-200">
            <table className="w-full min-w-[600px] border-collapse">
              <thead><tr><th className={thCls}>Contact</th><th className={thCls}>Account</th><th className={thCls}>Role</th><th className={thCls}>Channel</th><th className={thCls}></th></tr></thead>
              <tbody>{rows.map((c) => (
                <tr key={c.id} className={rowCls}>
                  <td className={tdCls}><div className="font-bold text-[#082f4f]">{c.name}</div><div className="text-[10.5px] text-[#355875]">{c.title || "—"}</div></td>
                  <td className={tdCls}>{c.account || "Unassigned"}</td>
                  <td className={tdCls}><Badge tone="slate">{c.role || "Contact"}</Badge></td>
                  <td className={tdCls}><div className="flex flex-col gap-0.5 text-[10.5px]">{c.email && <span className="flex items-center gap-1"><Mail className="h-3 w-3" />{c.email}</span>}{c.phone && <span className="flex items-center gap-1"><Phone className="h-3 w-3" />{c.phone}</span>}</div></td>
                  <td className={tdCls}><button onClick={() => void desk.remove(c.id)} className="rounded border border-rose-200 p-1 text-rose-700" aria-label="Delete contact"><Trash2 className="h-3 w-3" /></button></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </Card>
      <Card title="Add a contact" sub="Linked to an existing client account where possible.">
        <div className="space-y-2">
          <Field label="Client account"><input list="crm-accounts" className={inputCls} value={draft.account} onChange={(e) => setDraft({ ...draft, account: e.target.value })} placeholder="Account name" /><datalist id="crm-accounts">{customers.map((c) => <option key={c} value={c} />)}</datalist></Field>
          <Field label="Full name *"><input className={inputCls} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></Field>
          <Field label="Job title"><input className={inputCls} value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} placeholder="Finance Manager" /></Field>
          <Field label="Email"><input type="email" className={inputCls} value={draft.email} onChange={(e) => setDraft({ ...draft, email: e.target.value })} /></Field>
          <Field label="Phone"><input className={inputCls} value={draft.phone} onChange={(e) => setDraft({ ...draft, phone: e.target.value })} /></Field>
          <Field label="Relationship role"><select className={inputCls} value={draft.role} onChange={(e) => setDraft({ ...draft, role: e.target.value })}>{["Decision maker", "Champion", "Finance", "Operations", "Procurement", "Other"].map((r) => <option key={r}>{r}</option>)}</select></Field>
          <button onClick={() => void add()} disabled={desk.saving || !draft.name.trim()} className="w-full rounded-lg bg-[#082f4f] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50">Save contact</button>
          <span className="block text-[10px] text-[#355875]">Personal data is stored per entity and every change is audit-logged.</span>
        </div>
      </Card>
    </div>
  );
}

function PipelineTab({ desk, customers, username }: { desk: ReturnType<typeof useDeskRecords<Opportunity>>; customers: string[]; username: string }) {
  const { fmt, today } = useMoney();
  const [draft, setDraft] = useState({ name: "", account: "", value: 0, stage: "Prospecting", probability: 10, closeDate: today(), owner: username, notes: "" });
  const add = async () => {
    if (!draft.name.trim()) return;
    const saved = await desk.save({ ...draft, probability: Number(draft.probability) || stageProbability[draft.stage] });
    if (saved) setDraft({ ...draft, name: "", account: "", value: 0, notes: "" });
  };
  return (
    <div className="space-y-4">
      <Card title="Pipeline board" sub="Qualify, propose, negotiate and close — each stage carries a default probability used for the weighted forecast." action={
        <button onClick={() => downloadCsv("crm-pipeline.csv", [["Opportunity", "Account", "Value", "Stage", "Probability", "Close date", "Owner"], ...desk.records.map((o) => [o.name, o.account, o.value, o.stage, o.probability, o.closeDate, o.owner])])} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f]">Export</button>
      }>
        {desk.error && <Alert>{desk.error}</Alert>}
        <div className="grid gap-2 overflow-x-auto md:grid-cols-3 xl:grid-cols-6">
          {STAGES.map((stage) => {
            const items = desk.records.filter((o) => o.stage === stage);
            return (
              <div key={stage} className="min-w-[160px] rounded-xl border border-sky-200 bg-sky-50/40 p-2">
                <div className="mb-2 flex items-center justify-between text-[10px] font-black uppercase tracking-wider text-[#355875]"><span>{stage}</span><span className="font-mono">{items.length}</span></div>
                <div className="space-y-1.5">
                  {items.map((o) => (
                    <div key={o.id} className="rounded-lg border border-sky-200 bg-white p-2">
                      <div className="text-[11px] font-bold text-[#082f4f]">{o.name}</div>
                      <div className="text-[10px] text-[#355875]">{o.account || "No account"}</div>
                      <div className="mt-1 font-mono text-[11px] font-bold text-[#087a55]">GH₵ {fmt(Number(o.value || 0))}</div>
                      <div className="mt-1 flex items-center justify-between">
                        <select value={o.stage} onChange={(e) => void desk.save({ ...o, stage: e.target.value, probability: stageProbability[e.target.value] })} className="rounded border border-sky-200 bg-white px-1 py-0.5 text-[9.5px] font-bold text-[#082f4f]">
                          {STAGES.map((s) => <option key={s} value={s}>{s}</option>)}
                        </select>
                        <button onClick={() => void desk.remove(o.id)} className="text-rose-700" aria-label="Delete opportunity"><Trash2 className="h-3 w-3" /></button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </Card>
      <Card title="New opportunity" sub="A deal is always linked to a client account.">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Opportunity *"><input className={inputCls} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="Q1 supply contract" /></Field>
          <Field label="Client account"><input list="crm-accounts-pipeline" className={inputCls} value={draft.account} onChange={(e) => setDraft({ ...draft, account: e.target.value })} /><datalist id="crm-accounts-pipeline">{customers.map((c) => <option key={c} value={c} />)}</datalist></Field>
          <Field label="Value (GHS)"><input type="number" className={inputCls} value={draft.value} onChange={(e) => setDraft({ ...draft, value: Number(e.target.value) })} /></Field>
          <Field label="Stage"><select className={inputCls} value={draft.stage} onChange={(e) => setDraft({ ...draft, stage: e.target.value, probability: stageProbability[e.target.value] })}>{STAGES.map((s) => <option key={s}>{s}</option>)}</select></Field>
          <Field label="Probability %"><input type="number" className={inputCls} value={draft.probability} onChange={(e) => setDraft({ ...draft, probability: Number(e.target.value) })} /></Field>
          <Field label="Expected close"><input type="date" className={inputCls} value={draft.closeDate} onChange={(e) => setDraft({ ...draft, closeDate: e.target.value })} /></Field>
          <Field label="Owner"><input className={inputCls} value={draft.owner} onChange={(e) => setDraft({ ...draft, owner: e.target.value })} /></Field>
          <div className="flex items-end"><button onClick={() => void add()} disabled={desk.saving || !draft.name.trim()} className="w-full rounded-lg bg-[#082f4f] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50">Add opportunity</button></div>
        </div>
      </Card>
    </div>
  );
}

function ActivitiesTab({ desk, customers, contacts }: { desk: ReturnType<typeof useDeskRecords<Activity>>; customers: string[]; contacts: Contact[] }) {
  const { today } = useMoney();
  const [draft, setDraft] = useState({ date: today(), type: "Call", account: "", contact: "", summary: "", outcome: "", nextStep: "" });
  const add = async () => {
    if (!draft.summary.trim()) return;
    const saved = await desk.save({ ...draft, summary: draft.summary.trim() });
    if (saved) setDraft({ ...draft, summary: "", outcome: "", nextStep: "" });
  };
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
      <Card title="Activity timeline" sub="Every call, meeting, email and site visit, newest first.">
        {desk.error && <Alert>{desk.error}</Alert>}
        {desk.records.length === 0 ? <EmptyState title="No activities yet" detail="Log the next client conversation so the relationship has a shared memory." /> : (
          <ol className="space-y-2">
            {[...desk.records].reverse().map((a) => (
              <li key={a.id} className="rounded-lg border border-sky-200 bg-white p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-[11px] font-bold text-[#082f4f]"><Badge tone="ad">{a.type}</Badge>{a.account || "Internal"}</div>
                  <div className="flex items-center gap-2"><span className="font-mono text-[10.5px] text-[#355875]">{a.date}</span><button onClick={() => void desk.remove(a.id)} className="text-rose-700" aria-label="Delete activity"><Trash2 className="h-3 w-3" /></button></div>
                </div>
                <p className="mt-1 text-[11.5px] text-[#0a253e]">{a.summary}</p>
                {a.contact && <p className="text-[10.5px] text-[#355875]">With {a.contact}</p>}
                {a.outcome && <p className="mt-1 text-[10.5px]"><span className="font-bold">Outcome:</span> {a.outcome}</p>}
                {a.nextStep && <p className="text-[10.5px] text-[#855b00]"><span className="font-bold">Next:</span> {a.nextStep}</p>}
              </li>
            ))}
          </ol>
        )}
      </Card>
      <Card title="Log an activity" sub="Capture the outcome and the next step.">
        <div className="space-y-2">
          <Field label="Date"><input type="date" className={inputCls} value={draft.date} onChange={(e) => setDraft({ ...draft, date: e.target.value })} /></Field>
          <Field label="Type"><select className={inputCls} value={draft.type} onChange={(e) => setDraft({ ...draft, type: e.target.value })}>{["Call", "Meeting", "Email", "Site visit", "Proposal", "Follow-up", "Complaint"].map((t) => <option key={t}>{t}</option>)}</select></Field>
          <Field label="Client account"><input list="crm-accounts-act" className={inputCls} value={draft.account} onChange={(e) => setDraft({ ...draft, account: e.target.value })} /><datalist id="crm-accounts-act">{customers.map((c) => <option key={c} value={c} />)}</datalist></Field>
          <Field label="Contact"><select className={inputCls} value={draft.contact} onChange={(e) => setDraft({ ...draft, contact: e.target.value })}><option value="">Not specified</option>{contacts.filter((c) => !draft.account || c.account === draft.account).map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}</select></Field>
          <Field label="Summary *"><textarea rows={2} className={inputCls} value={draft.summary} onChange={(e) => setDraft({ ...draft, summary: e.target.value })} /></Field>
          <Field label="Outcome"><input className={inputCls} value={draft.outcome} onChange={(e) => setDraft({ ...draft, outcome: e.target.value })} /></Field>
          <Field label="Next step"><input className={inputCls} value={draft.nextStep} onChange={(e) => setDraft({ ...draft, nextStep: e.target.value })} /></Field>
          <button onClick={() => void add()} disabled={desk.saving || !draft.summary.trim()} className="w-full rounded-lg bg-[#082f4f] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50">Log activity</button>
        </div>
      </Card>
    </div>
  );
}

function TicketsTab({ desk, customers, username }: { desk: ReturnType<typeof useDeskRecords<TicketRecord>>; customers: string[]; username: string }) {
  const { today } = useMoney();
  const [draft, setDraft] = useState({ subject: "", account: "", priority: "Medium", status: "open", owner: username, opened: today(), detail: "" });
  const add = async () => {
    if (!draft.subject.trim()) return;
    const saved = await desk.save({ ...draft, subject: draft.subject.trim() });
    if (saved) setDraft({ ...draft, subject: "", detail: "" });
  };
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
      <Card title="Client service desk" sub="Queries, complaints and after-sales requests, with priority and accountability.">
        {desk.error && <Alert>{desk.error}</Alert>}
        {desk.records.length === 0 ? <EmptyState title="No tickets logged" detail="Log a client query or complaint to track it through to resolution." /> : (
          <div className="overflow-x-auto rounded-lg border border-sky-200">
            <table className="w-full min-w-[700px] border-collapse">
              <thead><tr><th className={thCls}>Ticket</th><th className={thCls}>Client</th><th className={thCls}>Priority</th><th className={thCls}>Owner</th><th className={thCls}>Opened</th><th className={thCls}>Status</th><th className={thCls}></th></tr></thead>
              <tbody>{desk.records.map((t) => (
                <tr key={t.id} className={rowCls}>
                  <td className={tdCls}><div className="font-bold text-[#082f4f]">{t.subject}</div>{t.detail && <div className="max-w-[260px] truncate text-[10.5px] text-[#355875]">{t.detail}</div>}</td>
                  <td className={tdCls}>{t.account || "—"}</td>
                  <td className={tdCls}><Badge tone={t.priority === "Critical" || t.priority === "High" ? "red" : "slate"}>{t.priority}</Badge></td>
                  <td className={tdCls}>{t.owner}</td>
                  <td className={tdCls}>{t.opened}</td>
                  <td className={tdCls}>
                    <select value={t.status} onChange={(e) => void desk.save({ ...t, status: e.target.value, resolvedOn: e.target.value === "resolved" ? today() : "" })} className="rounded border border-sky-200 bg-white px-1 py-0.5 text-[10px] font-bold text-[#082f4f]">
                      {["open", "in progress", "resolved", "closed"].map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </td>
                  <td className={tdCls}><button onClick={() => void desk.remove(t.id)} className="text-rose-700" aria-label="Delete ticket"><Trash2 className="h-3 w-3" /></button></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </Card>
      <Card title="Log a ticket" sub="High-priority tickets appear on the CRM overview.">
        <div className="space-y-2">
          <Field label="Subject *"><input className={inputCls} value={draft.subject} onChange={(e) => setDraft({ ...draft, subject: e.target.value })} /></Field>
          <Field label="Client account"><input list="crm-accounts-ticket" className={inputCls} value={draft.account} onChange={(e) => setDraft({ ...draft, account: e.target.value })} /><datalist id="crm-accounts-ticket">{customers.map((c) => <option key={c} value={c} />)}</datalist></Field>
          <Field label="Priority"><select className={inputCls} value={draft.priority} onChange={(e) => setDraft({ ...draft, priority: e.target.value })}>{["Low", "Medium", "High", "Critical"].map((p) => <option key={p}>{p}</option>)}</select></Field>
          <Field label="Owner"><input className={inputCls} value={draft.owner} onChange={(e) => setDraft({ ...draft, owner: e.target.value })} /></Field>
          <Field label="Opened"><input type="date" className={inputCls} value={draft.opened} onChange={(e) => setDraft({ ...draft, opened: e.target.value })} /></Field>
          <Field label="Detail"><textarea rows={3} className={inputCls} value={draft.detail} onChange={(e) => setDraft({ ...draft, detail: e.target.value })} /></Field>
          <button onClick={() => void add()} disabled={desk.saving || !draft.subject.trim()} className="inline-flex w-full items-center justify-center gap-1 rounded-lg bg-[#1f6f8b] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50"><Plus className="h-3.5 w-3.5" /> Log ticket</button>
        </div>
      </Card>
    </div>
  );
}
