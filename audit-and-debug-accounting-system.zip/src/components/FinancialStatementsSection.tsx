'use client';

/**
 * Financial statements — one module, two authorities.
 *
 * The working-paper reports (trial balance, P&L, statement of financial
 * position, cash flows, changes in equity, cost centres) and the IFRS statutory
 * pack used to sit in two separate menu entries even though they read the same
 * journal, the same reporting entity and the same period. They are now one desk:
 * the management reports are the analysis layer, the IFRS pack is the statutory
 * document, and both print from here.
 */

import { useState } from 'react';
import { BookOpen, FileSpreadsheet, PieChart, ShieldAlert } from 'lucide-react';
import type { AccountMaster, ACDOCALine, ClientEntity, UserAccount } from '@/types/accounting';
import { FinancialReportsSection } from './FinancialReportsSection';
import { StatutoryStatementsDesk } from './StatutoryStatementsDesk';
import { ModulePrintButton } from './ModulePrintButton';

export type StatementsView = 'working' | 'statutory';

export function FinancialStatementsSection({
  currentClient,
  clients,
  currentUser,
  onSelectClient,
  lines,
  accounts,
  onOpenNotesToAccounts,
  onNavigate,
  defaultView = 'statutory',
  defaultStatutoryTab,
}: {
  currentClient: ClientEntity;
  clients: ClientEntity[];
  currentUser: UserAccount;
  onSelectClient: (client: ClientEntity) => void;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  onOpenNotesToAccounts: () => void;
  onNavigate: (section: string) => void;
  defaultView?: StatementsView;
  defaultStatutoryTab?: string;
}) {
  const [view, setView] = useState<StatementsView>(defaultView);
  // Remounted per destination by the parent (keyed by entity + section), so the initial view is authoritative.

  return (
    <div className="space-y-5">
      <section className="rounded-xl border border-sky-200 bg-white p-4 shadow-sm sm:p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#855b00]">
              IAS 1 · Financial reporting · {currentClient.code}
            </div>
            <h1 className="mt-1 text-xl font-black tracking-tight text-[#082f4f] sm:text-2xl">
              Financial statements &amp; IFRS reporting
            </h1>
            <p className="mt-1.5 max-w-[84ch] text-[11.5px] leading-relaxed text-[#2d4f6d]">
              One reporting entity, one period, one source: the posted journal. Work the management reports for analysis,
              then issue the statutory IFRS pack from the same figures. Every caption is traceable to a journal document.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <ModulePrintButton
              title={`Financial statements — ${currentClient.name}`}
              subtitle={`${currentClient.code} · working papers through ${new Date().toISOString().slice(0, 10)}`}
              label="Print working papers"
              targetId={view === 'working' ? 'financial-working-papers' : 'ifrs-statutory-pack'}
            />
            <button
              type="button"
              onClick={() => onNavigate('disclosures')}
              className="flex items-center gap-1.5 rounded border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50"
            >
              <BookOpen className="h-3.5 w-3.5" /> Notes to accounts
            </button>
            <button
              type="button"
              onClick={() => onNavigate('compliance_review')}
              className="flex items-center gap-1.5 rounded border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50"
            >
              <ShieldAlert className="h-3.5 w-3.5" /> Compliance review
            </button>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-1.5 border-t border-sky-100 pt-3">
          <button
            type="button"
            onClick={() => setView('working')}
            aria-pressed={view === 'working'}
            className={`flex items-center gap-2 rounded px-3 py-2 text-[11.5px] font-bold transition ${view === 'working' ? 'bg-[#082f4f] text-white shadow' : 'border border-sky-200 bg-white text-[#163653] hover:bg-sky-50'}`}
          >
            <PieChart className="h-3.5 w-3.5" /> Management reports
            <span className={`text-[9px] font-mono ${view === 'working' ? 'text-[#f5b719]' : 'text-[#855b00]'}`}>TB · P&amp;L · SFP · CF</span>
          </button>
          <button
            type="button"
            onClick={() => setView('statutory')}
            aria-pressed={view === 'statutory'}
            className={`flex items-center gap-2 rounded px-3 py-2 text-[11.5px] font-bold transition ${view === 'statutory' ? 'bg-[#082f4f] text-white shadow' : 'border border-sky-200 bg-white text-[#163653] hover:bg-sky-50'}`}
          >
            <FileSpreadsheet className="h-3.5 w-3.5" /> IFRS statutory pack
            <span className={`text-[9px] font-mono ${view === 'statutory' ? 'text-[#f5b719]' : 'text-[#855b00]'}`}>IAS 1.10</span>
          </button>
        </div>
      </section>

      {view === 'working' ? (
        <div id="financial-working-papers">
          <FinancialReportsSection
            key={`working-${currentClient.id}`}
            currentClient={currentClient}
            clients={clients}
            currentUser={currentUser}
            onSelectClient={onSelectClient}
            lines={lines}
            accounts={accounts}
            onOpenNotesToAccounts={onOpenNotesToAccounts}
          />
        </div>
      ) : (
        <div id="ifrs-statutory-pack">
          <StatutoryStatementsDesk
            key={`statutory-${currentClient.id}`}
            currentClient={currentClient}
            currentUser={currentUser}
            lines={lines}
            accounts={accounts}
            clients={clients}
            onSelectClient={onSelectClient}
            onNavigate={onNavigate}
            defaultTab={defaultStatutoryTab}
          />
        </div>
      )}
    </div>
  );
}
