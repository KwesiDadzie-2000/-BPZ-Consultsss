"use client";

import { useMemo, useState } from "react";
import { CalendarCheck, CheckCircle2, ClipboardList, Clock, Network, Plus, Trash2, UserCheck, Users } from "lucide-react";
import type { ClientEntity, EmployeeProfile, UserAccount } from "../types/accounting";
import { Badge, Card, PageHeader, Stat, formatGHS, numCls, rowCls, tdCls, thCls } from "./ui";
import { Alert, DeskTabs, EmptyState, Field, downloadCsv, inputCls, useDeskRecords, useMoney } from "./DeskKit";

const localDate = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };

interface Department extends Record<string, unknown> { id: string; name: string; code: string; manager: string; parent: string; location: string; purpose: string; }
interface Attendance extends Record<string, unknown> { id: string; date: string; employeeId: string; status: string; hours: number; note: string; }
interface HrRequest extends Record<string, unknown> { id: string; employeeId: string; type: string; from: string; to: string; amount: number; reason: string; status: string; decidedBy?: string; decisionNote?: string; }
interface HrTask extends Record<string, unknown> { id: string; title: string; assignee: string; department: string; priority: string; due: string; status: string; notes: string; }

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  employees: EmployeeProfile[];
  onAddEmployee: (employee: EmployeeProfile) => void;
  onNavigate?: (section: string) => void;
}

const TABS = [
  { id: "employees", label: "Employees" },
  { id: "structure", label: "Organisational structure" },
  { id: "attendance", label: "Attendance" },
  { id: "requests", label: "Requests" },
  { id: "tasks", label: "Task management" },
];

const statusTone = (status: string) =>
  status === "approved" || status === "present" || status === "done" ? "green" : status === "rejected" || status === "absent" ? "red" : status === "late" || status === "overdue" ? "amber" : "slate";

export function HrManagementDesk({ currentClient, currentUser, employees, onAddEmployee, onNavigate, initialTab = "employees" }: Props & { initialTab?: string }) {
  const [tab, setTab] = useState(initialTab);
  const { fmt, today } = useMoney();
  const departments = useDeskRecords<Department>("hr", currentClient.id, "department");
  const attendance = useDeskRecords<Attendance>("hr", currentClient.id, "attendance");
  const requests = useDeskRecords<HrRequest>("hr", currentClient.id, "request");
  const tasks = useDeskRecords<HrTask>("hr", currentClient.id, "task");

  const canApprove = currentUser.role === "owner" || currentUser.role === "partner" || currentUser.role === "manager";
  const activeStaff = employees.filter((e) => e.status === "active");
  const payrollCost = employees.reduce((s, e) => s + e.basicSalary + e.allowances, 0);
  const pendingRequests = requests.records.filter((r) => r.status === "pending");
  const openTasks = tasks.records.filter((t) => t.status !== "done");
  const todayAttendance = attendance.records.filter((a) => a.date === today());
  const presentToday = todayAttendance.filter((a) => a.status === "present" || a.status === "late" || a.status === "remote").length;

  return (
    <div>
      <PageHeader
        kicker={`${currentClient.code} · Human Capital`}
        title="Human Resources Management"
        desc="One employee record from hire to exit: directory and contracts, organisational structure, attendance, leave and other requests, and day-to-day task management — all entity-scoped and audit-logged."
      >
        <Badge tone="hr">HR DESK</Badge>
        <Badge tone="slate">{employees.length} employees</Badge>
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label="Headcount" value={employees.length} sub={`${activeStaff.length} active`} />
        <Stat label="Monthly payroll" value={`GH₵ ${fmt(payrollCost)}`} sub="Basic + allowances" />
        <Stat label="Present today" value={`${presentToday}/${Math.max(todayAttendance.length, 1)}`} sub="Logged attendance" />
        <Stat label="Pending requests" value={pendingRequests.length} sub="Awaiting decision" />
        <Stat label="Open tasks" value={openTasks.length} sub="Across the entity" />
      </div>

      <DeskTabs
        tabs={TABS.map((t) => ({
          ...t,
          badge:
            t.id === "employees" ? employees.length
              : t.id === "structure" ? departments.records.length
              : t.id === "attendance" ? attendance.records.length
              : t.id === "requests" ? pendingRequests.length
              : openTasks.length,
        }))}
        active={tab}
        onChange={setTab}
      />

      {tab === "employees" && <EmployeeDirectory employees={employees} onAddEmployee={onAddEmployee} onNavigate={onNavigate} />}
      {tab === "structure" && <OrgStructure desk={departments} employees={employees} />}
      {tab === "attendance" && <AttendanceDesk desk={attendance} employees={employees} />}
      {tab === "requests" && <RequestDesk desk={requests} employees={employees} canApprove={canApprove} username={currentUser.username} />}
      {tab === "tasks" && <TaskDesk desk={tasks} employees={employees} departments={departments.records} />}
    </div>
  );
}

function EmployeeDirectory({ employees, onAddEmployee, onNavigate }: { employees: EmployeeProfile[]; onAddEmployee: (e: EmployeeProfile) => void; onNavigate?: (s: string) => void }) {
  const { fmt } = useMoney();
  const [query, setQuery] = useState("");
  const [dept, setDept] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [draft, setDraft] = useState({ name: "", role: "", department: "", costCenter: "", basicSalary: 0, allowances: 0, ssnitNumber: "", tin: "", startDate: "" });
  const deptOptions = useMemo(() => Array.from(new Set(employees.map((e) => e.department))).sort(), [employees]);

  const rows = employees.filter((e) => {
    const matches = `${e.name} ${e.bpNo} ${e.role} ${e.department}`.toLowerCase().includes(query.toLowerCase());
    return matches && (dept === "all" || e.department === dept);
  });

  const submit = () => {
    if (!draft.name.trim() || !draft.role.trim()) return;
    const nextId = Math.max(0, ...employees.map((e) => e.id)) + 1;
    onAddEmployee({
      id: nextId,
      bpNo: `EMP-${String(nextId).padStart(4, "0")}`,
      name: draft.name.trim(),
      role: draft.role.trim(),
      department: draft.department.trim() || "Unassigned",
      costCenter: draft.costCenter.trim() || undefined,
      jurisdiction: "Ghana",
      basicSalary: Number(draft.basicSalary) || 0,
      allowances: Number(draft.allowances) || 0,
      ssnitNumber: draft.ssnitNumber.trim(),
      tin: draft.tin.trim(),
      status: "active",
    });
    setDraft({ name: "", role: "", department: "", costCenter: "", basicSalary: 0, allowances: 0, ssnitNumber: "", tin: "", startDate: "" });
    setShowForm(false);
  };

  return (
    <Card
      title="Employee directory"
      sub="Hire, search, segment and review every employee. Payroll computations use the same records, so there is no duplicate master data."
      action={
        <div className="flex items-center gap-2">
          {onNavigate && (
            <button onClick={() => onNavigate("payroll")} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">
              Run payroll
            </button>
          )}
          <button onClick={() => setShowForm((s) => !s)} className="inline-flex items-center gap-1 rounded-lg bg-[#082f4f] px-2.5 py-1.5 text-[11px] font-bold text-white hover:bg-[#0a3f68]">
            <Plus className="h-3.5 w-3.5" /> Add employee
          </button>
        </div>
      }
    >
      {showForm && (
        <div className="mb-4 rounded-xl border border-sky-200 bg-sky-50/50 p-3">
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            <Field label="Full name *"><input className={inputCls} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="e.g. Akosua Mensah" /></Field>
            <Field label="Job title *"><input className={inputCls} value={draft.role} onChange={(e) => setDraft({ ...draft, role: e.target.value })} placeholder="e.g. Warehouse Supervisor" /></Field>
            <Field label="Department"><input className={inputCls} value={draft.department} onChange={(e) => setDraft({ ...draft, department: e.target.value })} list="hr-departments" placeholder="Operations" /><datalist id="hr-departments">{deptOptions.map((d) => <option key={d} value={d} />)}</datalist></Field>
            <Field label="Cost centre"><input className={inputCls} value={draft.costCenter} onChange={(e) => setDraft({ ...draft, costCenter: e.target.value })} placeholder="CC-OPS" /></Field>
            <Field label="Basic salary (GHS)"><input type="number" className={inputCls} value={draft.basicSalary} onChange={(e) => setDraft({ ...draft, basicSalary: Number(e.target.value) })} /></Field>
            <Field label="Allowances (GHS)"><input type="number" className={inputCls} value={draft.allowances} onChange={(e) => setDraft({ ...draft, allowances: Number(e.target.value) })} /></Field>
            <Field label="SSNIT number"><input className={inputCls} value={draft.ssnitNumber} onChange={(e) => setDraft({ ...draft, ssnitNumber: e.target.value })} /></Field>
            <Field label="TIN"><input className={inputCls} value={draft.tin} onChange={(e) => setDraft({ ...draft, tin: e.target.value })} /></Field>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <button onClick={submit} disabled={!draft.name.trim() || !draft.role.trim()} className="rounded-lg bg-[#087a55] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50">Save employee</button>
            <button onClick={() => setShowForm(false)} className="rounded-lg border border-sky-300 bg-white px-3 py-1.5 text-[11px] font-bold text-[#082f4f]">Cancel</button>
            <span className="text-[10.5px] text-[#355875]">A BP number is issued automatically. Sensitive identifiers are never shown in lists.</span>
          </div>
        </div>
      )}

      <div className="mb-3 flex flex-wrap items-center gap-2">
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search name, BP no., role or department…" className={`${inputCls} max-w-sm`} />
        <select value={dept} onChange={(e) => setDept(e.target.value)} className={`${inputCls} max-w-[200px]`}>
          <option value="all">All departments</option>
          {deptOptions.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <button
          onClick={() => downloadCsv(`employees-${localDate()}.csv`, [
            ["BP No", "Name", "Role", "Department", "Cost centre", "Basic", "Allowances", "Gross", "Status"],
            ...rows.map((e) => [e.bpNo, e.name, e.role, e.department, e.costCenter ?? "", e.basicSalary, e.allowances, e.basicSalary + e.allowances, e.status]),
          ])}
          className="ml-auto rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50"
        >
          Export CSV
        </button>
      </div>

      {rows.length === 0 ? (
        <EmptyState title="No employees match" detail="Adjust the search or add an employee to begin building the directory." />
      ) : (
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[760px] border-collapse">
            <thead><tr><th className={thCls}>Employee</th><th className={thCls}>Role / department</th><th className={thCls}>Cost centre</th><th className={thCls}>Gross pay</th><th className={thCls}>Status</th></tr></thead>
            <tbody>
              {rows.map((e) => (
                <tr key={e.id} className={rowCls}>
                  <td className={tdCls}><div className="font-bold text-[#082f4f]">{e.name}</div><div className="font-mono text-[10.5px] text-[#355875]">{e.bpNo}</div></td>
                  <td className={tdCls}><div className="font-semibold">{e.role}</div><div className="text-[11px] text-[#355875]">{e.department}</div></td>
                  <td className={tdCls}>{e.costCenter ?? "—"}</td>
                  <td className={numCls}>{fmt(e.basicSalary + e.allowances)}</td>
                  <td className={tdCls}><Badge tone={e.status === "active" ? "green" : "slate"}>{e.status}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

function OrgStructure({ desk, employees }: { desk: ReturnType<typeof useDeskRecords<Department>>; employees: EmployeeProfile[] }) {
  const [draft, setDraft] = useState({ name: "", code: "", manager: "", parent: "", location: "", purpose: "" });
  const headcount = (name: string) => employees.filter((e) => e.department.toLowerCase() === name.toLowerCase()).length;

  const add = async () => {
    if (!draft.name.trim()) return;
    const saved = await desk.save({ ...draft, name: draft.name.trim(), code: draft.code.trim() || draft.name.slice(0, 3).toUpperCase() });
    if (saved) setDraft({ name: "", code: "", manager: "", parent: "", location: "", purpose: "" });
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
      <Card title="Department & reporting units" sub="Parent units build the hierarchy; headcount is derived live from the employee directory.">
        {desk.error && <Alert>{desk.error}</Alert>}
        {desk.loading ? <p className="text-xs text-[#355875]">Loading structure…</p> : desk.records.length === 0 ? (
          <EmptyState title="No structure captured yet" detail="Add departments or reporting units — for example Finance, Operations, Sales and Warehouse." />
        ) : (
          <div className="space-y-2">
            {desk.records.map((d) => (
              <div key={d.id} className="rounded-lg border border-sky-200 bg-white p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 text-sm font-bold text-[#082f4f]"><Network className="h-4 w-4 text-[#6d3fb3]" />{d.name}<Badge tone="hr">{d.code}</Badge></div>
                    <div className="mt-0.5 text-[11px] text-[#355875]">{d.parent ? `Reports to ${d.parent}` : "Top-level unit"}{d.location ? ` · ${d.location}` : ""}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge tone="slate">{headcount(d.name)} staff</Badge>
                    <span className="text-[11px] font-semibold text-[#355875]">{d.manager || "Manager not set"}</span>
                    <button onClick={() => void desk.remove(d.id)} aria-label={`Delete ${d.name}`} className="rounded border border-rose-200 p-1 text-rose-700 hover:bg-rose-50"><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                </div>
                {d.purpose && <p className="mt-1.5 text-[11px] text-[#2d4f6d]">{d.purpose}</p>}
              </div>
            ))}
          </div>
        )}
      </Card>
      <Card title="Add a unit" sub="Units are audit-logged against this entity.">
        <div className="space-y-2">
          <Field label="Unit name *"><input className={inputCls} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="Finance & Accounts" /></Field>
          <Field label="Unit code"><input className={inputCls} value={draft.code} onChange={(e) => setDraft({ ...draft, code: e.target.value })} placeholder="FIN" /></Field>
          <Field label="Reports to"><input className={inputCls} value={draft.parent} onChange={(e) => setDraft({ ...draft, parent: e.target.value })} list="org-units" placeholder="Executive Office" /><datalist id="org-units">{desk.records.map((d) => <option key={d.id} value={d.name} />)}</datalist></Field>
          <Field label="Unit manager"><input className={inputCls} value={draft.manager} onChange={(e) => setDraft({ ...draft, manager: e.target.value })} list="org-managers" placeholder="Name" /><datalist id="org-managers">{employees.map((e) => <option key={e.id} value={e.name} />)}</datalist></Field>
          <Field label="Location"><input className={inputCls} value={draft.location} onChange={(e) => setDraft({ ...draft, location: e.target.value })} placeholder="Accra HQ" /></Field>
          <Field label="Purpose / mandate"><textarea className={inputCls} rows={2} value={draft.purpose} onChange={(e) => setDraft({ ...draft, purpose: e.target.value })} /></Field>
          <button onClick={() => void add()} disabled={desk.saving || !draft.name.trim()} className="w-full rounded-lg bg-[#082f4f] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50">{desk.saving ? "Saving…" : "Add unit"}</button>
        </div>
      </Card>
    </div>
  );
}

function AttendanceDesk({ desk, employees }: { desk: ReturnType<typeof useDeskRecords<Attendance>>; employees: EmployeeProfile[] }) {
  const { today } = useMoney();
  const [draft, setDraft] = useState({ date: today(), employeeId: "", status: "present", hours: 8, note: "" });
  const [filterDate, setFilterDate] = useState(today());

  const add = async () => {
    const employee = employees.find((e) => String(e.id) === draft.employeeId);
    if (!employee) return;
    const saved = await desk.save({ ...draft, employeeId: String(employee.id), employeeName: employee.name, hours: Number(draft.hours) || 0, date: draft.date || today() });
    if (saved) setDraft({ ...draft, employeeId: "", note: "" });
  };
  const rows = desk.records.filter((a) => !filterDate || a.date === filterDate);
  const summary = ["present", "late", "absent", "leave", "remote"].map((s) => ({ status: s, count: rows.filter((r) => r.status === s).length }));

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
      <Card
        title="Attendance register"
        sub="Daily clock-in status by employee. Late arrivals, absence and approved leave are visible in one place."
        action={<input type="date" className={`${inputCls} max-w-[160px]`} value={filterDate} onChange={(e) => setFilterDate(e.target.value)} />}
      >
        {desk.error && <Alert>{desk.error}</Alert>}
        <div className="mb-3 grid grid-cols-2 gap-2 sm:grid-cols-5">
          {summary.map((s) => <div key={s.status} className="rounded-lg border border-sky-200 bg-sky-50/60 px-2 py-1.5"><div className="text-[10px] font-bold uppercase text-[#355875]">{s.status}</div><div className="font-mono text-sm font-bold text-[#082f4f]">{s.count}</div></div>)}
        </div>
        {rows.length === 0 ? <EmptyState title="No attendance logged for this date" detail="Record attendance on the right; it is saved to the server for every device." /> : (
          <div className="overflow-x-auto rounded-lg border border-sky-200">
            <table className="w-full min-w-[560px] border-collapse">
              <thead><tr><th className={thCls}>Employee</th><th className={thCls}>Status</th><th className={thCls}>Hours</th><th className={thCls}>Note</th><th className={thCls}></th></tr></thead>
              <tbody>{rows.map((a) => (
                <tr key={a.id} className={rowCls}>
                  <td className={tdCls}><div className="font-semibold">{String(a.employeeName ?? a.employeeId)}</div><div className="text-[10.5px] text-[#355875]">{a.date}</div></td>
                  <td className={tdCls}><Badge tone={statusTone(a.status)}>{a.status}</Badge></td>
                  <td className={numCls}>{Number(a.hours ?? 0).toFixed(1)}</td>
                  <td className={tdCls}>{a.note || "—"}</td>
                  <td className={tdCls}><button onClick={() => void desk.remove(a.id)} aria-label="Delete attendance" className="rounded border border-rose-200 p-1 text-rose-700 hover:bg-rose-50"><Trash2 className="h-3 w-3" /></button></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </Card>
      <Card title="Record attendance" sub="One row per employee per day.">
        <div className="space-y-2">
          <Field label="Date"><input type="date" className={inputCls} value={draft.date} onChange={(e) => setDraft({ ...draft, date: e.target.value })} /></Field>
          <Field label="Employee *">
            <select className={inputCls} value={draft.employeeId} onChange={(e) => setDraft({ ...draft, employeeId: e.target.value })}>
              <option value="">Select employee…</option>
              {employees.filter((e) => e.status === "active").map((e) => <option key={e.id} value={e.id}>{e.name} · {e.department}</option>)}
            </select>
          </Field>
          <Field label="Status">
            <select className={inputCls} value={draft.status} onChange={(e) => setDraft({ ...draft, status: e.target.value })}>
              {["present", "remote", "late", "leave", "absent", "holiday"].map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Hours worked"><input type="number" step="0.5" className={inputCls} value={draft.hours} onChange={(e) => setDraft({ ...draft, hours: Number(e.target.value) })} /></Field>
          <Field label="Note"><input className={inputCls} value={draft.note} onChange={(e) => setDraft({ ...draft, note: e.target.value })} placeholder="Optional" /></Field>
          <button onClick={() => void add()} disabled={desk.saving || !draft.employeeId} className="w-full rounded-lg bg-[#082f4f] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50">{desk.saving ? "Saving…" : "Save attendance"}</button>
        </div>
      </Card>
    </div>
  );
}

function RequestDesk({ desk, employees, canApprove, username }: { desk: ReturnType<typeof useDeskRecords<HrRequest>>; employees: EmployeeProfile[]; canApprove: boolean; username: string }) {
  const { fmt, today } = useMoney();
  const [draft, setDraft] = useState({ employeeId: "", type: "Annual leave", from: today(), to: today(), amount: 0, reason: "" });
  const add = async () => {
    const employee = employees.find((e) => String(e.id) === draft.employeeId);
    if (!employee) return;
    const saved = await desk.save({ ...draft, employeeName: employee.name, amount: Number(draft.amount) || 0, status: "pending" });
    if (saved) setDraft({ ...draft, employeeId: "", reason: "", amount: 0 });
  };
  const decide = async (r: HrRequest, status: string) => {
    await desk.save({ ...r, status, decidedBy: username, decidedOn: today() });
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
      <Card title="Employee requests" sub={canApprove ? "Leave, advances, overtime and training requests. Approvals are recorded against your username." : "Your entity's requests. Only owners, partners and managers can decide them."}>
        {desk.error && <Alert>{desk.error}</Alert>}
        {desk.records.length === 0 ? <EmptyState title="No requests yet" detail="Submit a leave, salary-advance, overtime or training request." /> : (
          <div className="space-y-2">
            {[...desk.records].reverse().map((r) => (
              <div key={r.id} className="rounded-lg border border-sky-200 bg-white p-3">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="text-sm font-bold text-[#082f4f]">{r.type} · {String(r.employeeName ?? r.employeeId)}</div>
                    <div className="mt-0.5 text-[11px] text-[#355875]">{r.from} → {r.to}{Number(r.amount) > 0 ? ` · GH₵ ${fmt(Number(r.amount))}` : ""}</div>
                  </div>
                  <Badge tone={statusTone(r.status)}>{r.status}</Badge>
                </div>
                {r.reason && <p className="mt-1 text-[11px] text-[#2d4f6d]">{r.reason}</p>}
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  {canApprove && r.status === "pending" && (
                    <>
                      <button onClick={() => void decide(r, "approved")} className="rounded-lg bg-[#087a55] px-2.5 py-1 text-[10.5px] font-bold text-white">Approve</button>
                      <button onClick={() => void decide(r, "rejected")} className="rounded-lg bg-[#b42318] px-2.5 py-1 text-[10.5px] font-bold text-white">Reject</button>
                    </>
                  )}
                  {r.decidedBy && <span className="text-[10.5px] text-[#355875]">Decided by {r.decidedBy}</span>}
                  {r.status === "approved" && <button onClick={() => void desk.remove(r.id)} className="ml-auto text-[10.5px] font-bold text-rose-700 hover:underline">Archive</button>}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
      <Card title="New request" sub="The request enters the pending queue.">
        <div className="space-y-2">
          <Field label="Employee *">
            <select className={inputCls} value={draft.employeeId} onChange={(e) => setDraft({ ...draft, employeeId: e.target.value })}>
              <option value="">Select employee…</option>
              {employees.filter((e) => e.status === "active").map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}
            </select>
          </Field>
          <Field label="Request type">
            <select className={inputCls} value={draft.type} onChange={(e) => setDraft({ ...draft, type: e.target.value })}>
              {["Annual leave", "Sick leave", "Maternity / paternity leave", "Salary advance", "Overtime", "Training", "Expense reimbursement", "Other"].map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="From"><input type="date" className={inputCls} value={draft.from} onChange={(e) => setDraft({ ...draft, from: e.target.value })} /></Field>
            <Field label="To"><input type="date" className={inputCls} value={draft.to} onChange={(e) => setDraft({ ...draft, to: e.target.value })} /></Field>
          </div>
          <Field label="Amount (if financial)"><input type="number" className={inputCls} value={draft.amount} onChange={(e) => setDraft({ ...draft, amount: Number(e.target.value) })} /></Field>
          <Field label="Reason"><textarea rows={2} className={inputCls} value={draft.reason} onChange={(e) => setDraft({ ...draft, reason: e.target.value })} /></Field>
          <button onClick={() => void add()} disabled={desk.saving || !draft.employeeId} className="w-full rounded-lg bg-[#082f4f] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50">{desk.saving ? "Submitting…" : "Submit request"}</button>
        </div>
      </Card>
    </div>
  );
}

function TaskDesk({ desk, employees, departments }: { desk: ReturnType<typeof useDeskRecords<HrTask>>; employees: EmployeeProfile[]; departments: Department[] }) {
  const { today } = useMoney();
  const [draft, setDraft] = useState({ title: "", assignee: "", department: "", priority: "Medium", due: today(), notes: "" });
  const add = async () => {
    if (!draft.title.trim()) return;
    const saved = await desk.save({ ...draft, status: "open" });
    if (saved) setDraft({ ...draft, title: "", notes: "" });
  };
  const toggle = async (t: HrTask) => {
    await desk.save({ ...t, status: t.status === "done" ? "open" : "done", completedOn: t.status === "done" ? "" : today() });
  };
  const cols = [
    { id: "open", title: "To do", icon: ClipboardList },
    { id: "in-progress", title: "In progress", icon: Clock },
    { id: "done", title: "Completed", icon: CheckCircle2 },
  ];

  return (
    <div className="space-y-4">
      <Card title="Task management" sub="Assign work, set priority and due dates, and move items across the board. Overdue work is highlighted automatically.">
        {desk.error && <Alert>{desk.error}</Alert>}
        <div className="mb-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-6">
          <Field label="Task title"><input className={inputCls} value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} placeholder="Reconcile stock count" /></Field>
          <Field label="Assignee">
            <select className={inputCls} value={draft.assignee} onChange={(e) => setDraft({ ...draft, assignee: e.target.value })}>
              <option value="">Unassigned</option>
              {employees.map((e) => <option key={e.id} value={e.name}>{e.name}</option>)}
            </select>
          </Field>
          <Field label="Department">
            <select className={inputCls} value={draft.department} onChange={(e) => setDraft({ ...draft, department: e.target.value })}>
              <option value="">General</option>
              {departments.map((d) => <option key={d.id} value={d.name}>{d.name}</option>)}
            </select>
          </Field>
          <Field label="Priority">
            <select className={inputCls} value={draft.priority} onChange={(e) => setDraft({ ...draft, priority: e.target.value })}>
              {["Low", "Medium", "High", "Critical"].map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </Field>
          <Field label="Due date"><input type="date" className={inputCls} value={draft.due} onChange={(e) => setDraft({ ...draft, due: e.target.value })} /></Field>
          <div className="flex items-end"><button onClick={() => void add()} disabled={desk.saving || !draft.title.trim()} className="w-full rounded-lg bg-[#082f4f] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50">Add task</button></div>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          {cols.map((c) => {
            const items = desk.records.filter((t) => (c.id === "open" ? t.status === "open" || !t.status : t.status === c.id));
            const Icon = c.icon;
            return (
              <div key={c.id} className="rounded-xl border border-sky-200 bg-sky-50/40 p-2">
                <div className="mb-2 flex items-center justify-between px-1 text-[11px] font-black uppercase tracking-wider text-[#355875]">
                  <span className="flex items-center gap-1.5"><Icon className="h-3.5 w-3.5" />{c.title}</span>
                  <span className="font-mono">{items.length}</span>
                </div>
                <div className="space-y-2">
                  {items.length === 0 && <p className="px-1 py-4 text-center text-[10.5px] text-[#355875]">Nothing here</p>}
                  {items.map((t) => {
                    const overdue = t.status !== "done" && t.due && t.due < today();
                    return (
                      <div key={t.id} className="rounded-lg border border-sky-200 bg-white p-2.5">
                        <div className="flex items-start justify-between gap-2">
                          <p className={`text-[11.5px] font-bold ${t.status === "done" ? "text-[#355875] line-through" : "text-[#082f4f]"}`}>{t.title}</p>
                          <Badge tone={t.priority === "Critical" || t.priority === "High" ? "red" : "slate"}>{String(t.priority ?? "Medium")}</Badge>
                        </div>
                        <div className="mt-1 text-[10.5px] text-[#355875]">{String(t.assignee || "Unassigned")}{t.department ? ` · ${String(t.department)}` : ""}</div>
                        <div className="mt-1 flex items-center justify-between gap-1">
                          <span className={`text-[10px] font-bold ${overdue ? "text-rose-700" : "text-[#355875]"}`}>{overdue ? `Overdue · ${String(t.due)}` : t.due ? `Due ${String(t.due)}` : "No due date"}</span>
                          <div className="flex items-center gap-1">
                            <button onClick={() => void toggle(t)} className="rounded border border-emerald-200 p-1 text-emerald-700 hover:bg-emerald-50" aria-label="Toggle task done"><UserCheck className="h-3 w-3" /></button>
                            <button onClick={() => void desk.remove(t.id)} className="rounded border border-rose-200 p-1 text-rose-700 hover:bg-rose-50" aria-label="Delete task"><Trash2 className="h-3 w-3" /></button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-3 text-[10.5px] text-[#355875]">
          <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" /> {desk.records.length} tasks</span>
          <span className="flex items-center gap-1"><CalendarCheck className="h-3.5 w-3.5" /> {desk.records.filter((t) => t.status !== "done" && t.due && t.due < today()).length} overdue</span>
          <button onClick={() => downloadCsv("hr-tasks.csv", [["Title", "Assignee", "Department", "Priority", "Due", "Status"], ...desk.records.map((t) => [t.title, t.assignee, t.department, t.priority, t.due, t.status])])} className="ml-auto rounded-lg border border-sky-300 bg-white px-2.5 py-1 text-[10.5px] font-bold text-[#082f4f]">Export tasks</button>
        </div>
      </Card>
    </div>
  );
}
