import React, { useMemo, useState } from 'react';
import type { ACDOCALine, BankAccount, ClientEntity, UserAccount } from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import { Plus, CheckCircle, AlertCircle, Landmark, ArrowRight } from 'lucide-react';
import { nextDocNo, uniqueId } from '../utils/ids';
import { localToday } from '../utils/periods';
import { persistentStorage } from '../utils/persistentStorage';
import { apiFetch } from '../utils/session';
import { useWorkbooks } from '@/lib/workbookClient';
import { generateLoanSchedule, deriveDebtServiceBills, debtAccrualDoc, money, type LoanFacility, type AmortisationRow, type FacilityType } from '../utils/loanSchedule';
import { ScheduleActions } from './ScheduleActions';
import type { ExcelSheet } from '../utils/excelExport';
export type { LoanFacility, AmortisationRow, FacilityType } from '../utils/loanSchedule';

interface Props {
  currentClient: ClientEntity; currentUser: UserAccount; lines?: ACDOCALine[]; bankAccounts?: BankAccount[];
  onAddJournalLines: (lines: ACDOCALine[], docCurrency?: string, expectedClientId?: number, onRejected?: () => void, options?: { syncBankFromGl?: boolean }) => boolean | void;
  onBankBalanceChange?: (bankId: number, delta: number) => void;
  onApprovalSubmitted?: () => void; onServerMutation?: () => Promise<void>; onNavigate?: (section: string) => void;
}
const scheduleColumns = ['Instalment', 'Due date', 'Opening principal', 'Interest expense', 'Principal due', 'Cash due at maturity/payment date', 'Closing principal', 'Accrual document', 'Accrued', 'Paid', 'Outstanding'];
const moneyCols = [2, 3, 4, 5, 6, 8, 9, 10];

export const LoansAmortisationDesk: React.FC<Props> = ({ currentClient, currentUser, lines = [], bankAccounts = [], onAddJournalLines, onBankBalanceChange, onApprovalSubmitted, onServerMutation, onNavigate }) => {
  const wb = useWorkbooks<{ facilities: LoanFacility[] }>(currentClient.id, 'loan_facilities');
  const saved = wb.items.find((w) => w.key === 'register');
  const [draft, setDraft] = useState<LoanFacility[] | null>(null);
  const facilities = draft ?? saved?.payload?.facilities ?? [];
  const [selectedId, setSelectedId] = useState('');
  const [feedback, setFeedback] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [name, setName] = useState(''); const [lender, setLender] = useState('');
  const [principal, setPrincipal] = useState(0); const [rate, setRate] = useState(21.5);
  const [term, setTerm] = useState(24); const [fee, setFee] = useState(0);
  const [startDate, setStartDate] = useState(localToday); const [type, setType] = useState<FacilityType>('amortising');
  const [frequency, setFrequency] = useState<'monthly' | 'quarterly'>('monthly');
  const readOnly = currentUser.role === 'auditor' || currentUser.status !== 'active' || currentUser.permissions?.canPostJournals === false;
  const symbol = currentClient.currency === 'GHS' ? '₵' : `${currentClient.currency} `;
  const clientLines = useMemo(() => lines.filter((l) => l.clientId === currentClient.id), [lines, currentClient.id]);
  const bills = useMemo(() => deriveDebtServiceBills(clientLines, currentClient.id), [clientLines, currentClient.id]);
  const selected = facilities.find((f) => f.id === selectedId) || facilities[0];
  const schedule = useMemo(() => { try { return selected ? generateLoanSchedule(selected) : []; } catch { return []; } }, [selected]);
  const notify = (tone: 'ok' | 'err', text: string) => setFeedback({ tone, text });
  const billFor = (loan: LoanFacility, row: AmortisationRow) => bills.find((b) => b.docNo === debtAccrualDoc(loan.code, row.periodNum));
  const scheduleRows = (loan: LoanFacility, rows: AmortisationRow[]) => rows.map((r) => {
    const bill = billFor(loan, r);
    return [r.periodNum, r.date, r.openingBalance, r.interestExpense, r.principalPayment, r.totalPayment, r.closingBalance, debtAccrualDoc(loan.code, r.periodNum), bill ? 'Yes' : 'No', bill?.paid || 0, bill?.outstanding || 0];
  });
  const termsSheet = (loan: LoanFacility): ExcelSheet => ({ name: `${loan.code}-terms`, columns: ['Field', 'Value'], rows: [['Entity', currentClient.name], ['Facility', loan.code], ['Name', loan.facilityName], ['Lender', loan.lender], ['Currency', currentClient.currency], ['Principal', loan.principal], ['Nominal annual rate %', loan.annualRatePct], ['Term months', loan.termMonths], ['Frequency', loan.frequency], ['Structure', loan.facilityType], ['Arrangement fee', loan.arrangementFee], ['Start date', loan.startDate], ['Basis', 'Nominal annual rate divided by payment frequency; final instalment absorbs cent rounding. Confirm against executed loan agreement.']] });
  const excelSheets: ExcelSheet[] = selected ? [termsSheet(selected), { name: `${selected.code}-schedule`, columns: scheduleColumns, rows: scheduleRows(selected, schedule), moneyColumns: moneyCols }, { name: 'Open debt payables', columns: ['Accrual document', 'Facility/reference', 'Due date', 'Gross', 'Paid', 'Outstanding'], rows: bills.map((b) => [b.docNo, b.reference, b.date, b.gross, b.paid, b.outstanding]), moneyColumns: [3, 4, 5] }] : [];

  const createFacility = async (e: React.FormEvent) => {
    e.preventDefault(); if (busy) return;
    const loan: LoanFacility = { id: uniqueId('LN'), code: nextDocNo(`LN-${lender.replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase() || 'BNK'}`, facilities.map((f) => f.code), 3), facilityName: name.trim(), lender: lender.trim(), principal: money(principal), annualRatePct: rate, termMonths: term, frequency, facilityType: type, arrangementFee: money(fee), startDate, status: 'Active' };
    try { generateLoanSchedule(loan); } catch (error) { notify('err', error instanceof Error ? error.message : 'Invalid facility.'); return; }
    if (!loan.facilityName || !loan.lender) { notify('err', 'Facility name and lender are required.'); return; }
    setBusy(true); const next = [...facilities, loan]; setDraft(next);
    const result = await wb.save('register', `${currentClient.code} loan facilities`, { facilities: next }, saved?.version ?? 0);
    setBusy(false);
    if (result.ok) { setDraft(null); setSelectedId(loan.id); setShowNew(false); setName(''); setLender(''); setPrincipal(0); setFee(0); notify('ok', `${loan.code} saved. Review the terms against the signed agreement before posting.`); }
    else notify('err', result.error || 'Facility was not saved.');
  };

  const accrue = async (row: AmortisationRow) => {
    if (!selected || busy) return; setBusy(true); setFeedback(null);
    try {
      const response = await apiFetch('/api/debt', { method: 'POST', body: JSON.stringify({ clientId: currentClient.id, facilityId: selected.id, periodNum: row.periodNum, action: 'accrue' }) });
      const body = await response.json().catch(() => null);
      if (!response.ok || !body?.ok) { notify('err', body?.error || 'Accrual was not committed.'); return; }
      await onServerMutation?.();
      notify('ok', `${body.docNo || 'Instalment'} accrued. ${symbol}${formatGHS(Number(body.payable) || 0)} is payable; no cash has moved. Settle it at the Payment Desk.`);
    } catch { notify('err', 'Connection failed. Refresh the schedule before retrying to avoid a duplicate.'); }
    finally { setBusy(false); }
  };

  const banks = bankAccounts.filter((b) => (b.glAccount || '100000') === '100000' && b.currency === currentClient.currency);
  const drawdown = (loan: LoanFacility) => {
    if (readOnly || busy) return;
    if (banks.length !== 1) { notify('err', 'Cash drawdown requires exactly one operating bank mapped to GL 100000 in this currency. Resolve the treasury mapping first.'); return; }
    const bank = banks[0], docNo = `LOAN-DRAW-${loan.code}`;
    if (clientLines.some((l) => l.docNo === docNo)) { notify('err', 'Drawdown already recorded.'); return; }
    const proceeds = money(loan.principal - loan.arrangementFee);
    const base = { clientId: currentClient.id, docNo, date: loan.startDate, period: loan.startDate.slice(0, 7), module: 'FI' as const, docType: 'JE' as const, currency: currentClient.currency, createdBy: currentUser.username, costCenter: 'CC-ADM', reference: loan.code };
    const journal: ACDOCALine[] = [{ ...base, id: uniqueId('JL'), accountNo: '100000', accountName: bank.name, debit: proceeds, credit: 0, description: `Cash drawdown ${loan.code}` }];
    if (loan.arrangementFee > 0) journal.push({ ...base, id: uniqueId('JL'), accountNo: '700000', accountName: 'Loan arrangement fee', debit: loan.arrangementFee, credit: 0, description: `Fee deducted from drawdown ${loan.code}; confirm EIR treatment` });
    journal.push({ ...base, id: uniqueId('JL'), accountNo: '250000', accountName: 'Commercial Borrowings', debit: 0, credit: loan.principal, description: `Loan principal ${loan.code}` });
    const total = journal.reduce((s, l) => s + l.debit, 0);
    if (currentUser.makerLimit > 0 && total > currentUser.makerLimit) {
      persistentStorage.addApprovalRequest({ id: uniqueId('APP-LOAN'), clientId: currentClient.id, clientCode: currentClient.code, clientName: currentClient.name, docNo, docType: 'JE', amount: total, requestedBy: `${currentUser.name} (${currentUser.username})`, requestedAt: new Date().toISOString(), description: `Cash drawdown ${loan.code}`, reasonForApproval: 'Loan drawdown exceeds maker limit.', status: 'pending', payload: { lines: journal, settlement: { kind: 'expense', clientId: currentClient.id, settleAmount: total, cashDelta: proceeds, bankId: bank.id } } });
      onApprovalSubmitted?.(); notify('ok', 'Drawdown queued for independent approval; no cash has moved yet.'); return;
    }
    const ok = onAddJournalLines(journal, currentClient.currency, currentClient.id, () => onBankBalanceChange?.(bank.id, -proceeds), { syncBankFromGl: false });
    if (ok === false) { notify('err', 'Drawdown refused by posting controls.'); return; }
    onBankBalanceChange?.(bank.id, proceeds); notify('ok', `${docNo} submitted for server posting. Verify the ledger and bank receipt before relying on it.`);
  };

  const glPrincipal = money(clientLines.filter((l) => l.accountNo === '250000').reduce((s, l) => s + l.credit - l.debit, 0));
  const due = money(bills.reduce((s, b) => s + b.outstanding, 0));
  return <div className="space-y-6">
    <PageHeader kicker={`FIN · BORROWINGS · ${currentClient.code}`} title="Loan Amortisation & Debt Service" desc="Review facility terms, accrue interest and principal when due, then settle the payable at the Payment Desk. Accrual and cash settlement are separate accounting events.">
      <button type="button" disabled={readOnly || busy} onClick={() => { setFeedback(null); setShowNew(true); }} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white disabled:opacity-40"><Plus className="h-4 w-4" />New borrowing facility</button>
    </PageHeader>
    {feedback && <div role="status" className={`flex items-start gap-2 rounded-xl border p-3 text-xs font-bold ${feedback.tone === 'ok' ? 'border-emerald-300 bg-emerald-50 text-emerald-900' : 'border-rose-300 bg-rose-50 text-rose-900'}`}>{feedback.tone === 'ok' ? <CheckCircle className="h-4 w-4 shrink-0" /> : <AlertCircle className="h-4 w-4 shrink-0" />}<span>{feedback.text}</span></div>}
    {wb.error && <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 p-3 text-xs text-rose-800">{wb.error}</div>}
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      <Stat label="Facilities" value={facilities.length} sub="Saved per entity" />
      <Stat label="Contracted principal" value={`${symbol}${formatGHS(facilities.reduce((s, f) => s + f.principal, 0))}`} sub="Not a ledger balance" />
      <Stat label="GL principal outstanding" value={`${symbol}${formatGHS(glPrincipal)}`} sub="250000 · all entity facilities" />
      <Stat label="Accrued debt awaiting payment" value={`${symbol}${formatGHS(due)}`} tone={due > 0 ? 'text-rose-700' : 'text-emerald-700'} sub="213000 · settle at Payment Desk" />
    </div>
    <div className="rounded-xl border border-sky-200 bg-white p-4 text-xs text-[#2d4f6d]"><strong className="text-[#082f4f]">Two-step workflow:</strong> ① Create accrual → Dr interest expense / principal liability, Cr debt-service payable. ② Pay at Payment Desk → Dr debt-service payable, Cr bank/cash. Bullet loans accrue interest even when cash is not yet due. Nominal-rate schedules are working papers; confirm day count, fees and effective-interest treatment against the signed agreement. Accruals are created here; cash settlement is only at the Payment Desk.</div>
    {facilities.length === 0 ? <Card title="No borrowing facilities" sub="Register a facility to generate its full-term schedule"><p className="py-5 text-xs text-[#355875]">No demonstration loans are inserted into a client&apos;s books. Add the entity&apos;s own facility using its executed agreement.</p></Card> : <>
      <div className="grid gap-3 md:grid-cols-2" data-print-hide>{facilities.map((loan) => <div key={loan.id} className={`rounded-xl border p-4 text-xs ${selected?.id === loan.id ? 'border-[#082f4f] bg-sky-50 ring-1 ring-[#082f4f]' : 'border-sky-200 bg-white'}`}>
        <button type="button" onClick={() => setSelectedId(loan.id)} className="w-full text-left"><span className="font-mono font-bold text-[#855b00]">{loan.code}</span><div className="mt-1 text-sm font-black text-[#082f4f]">{loan.facilityName}</div><div className="mt-1 flex items-center gap-1 text-[#355875]"><Landmark className="h-3.5 w-3.5" />{loan.lender} · {loan.annualRatePct}% · {loan.termMonths} months · {loan.frequency}</div><div className="mt-2 font-mono font-bold text-[#082f4f]">{symbol}{formatGHS(loan.principal)}</div></button>
        <div className="mt-3 border-t border-sky-200 pt-2">{clientLines.some((l) => l.docNo === `LOAN-DRAW-${loan.code}`) ? <span className="font-bold text-emerald-700">Cash drawdown recorded</span> : <button type="button" disabled={readOnly || busy} onClick={() => drawdown(loan)} className="rounded border border-sky-300 bg-white px-2.5 py-1 font-bold text-[#082f4f] disabled:opacity-40">Record cash drawdown</button>}</div>
      </div>)}</div>
      {selected && <Card title={`Amortisation schedule — ${selected.facilityName}`} sub={`${selected.code} · ${selected.lender} · ${selected.frequency} · ${selected.facilityType.replace('_', ' ')} · ${currentClient.currency}`} action={<ScheduleActions title={`Loan amortisation — ${selected.code}`} subtitle={`${currentClient.name} · ${selected.lender} · ${selected.annualRatePct}% nominal p.a.`} targetId="loan-selected-schedule" filename={`${currentClient.code}-${selected.code}-amortisation.xlsx`} sheets={excelSheets} disabled={wb.loading || !schedule.length} />}>
        <div id="loan-selected-schedule">
          <div className="mb-3 grid grid-cols-2 gap-3 rounded-lg border border-sky-200 bg-sky-50 p-3 text-xs md:grid-cols-4"><div><span className="block text-[#355875]">Principal</span><strong>{symbol}{formatGHS(selected.principal)}</strong></div><div><span className="block text-[#355875]">Nominal annual rate</span><strong>{selected.annualRatePct}%</strong></div><div><span className="block text-[#355875]">Start / instalments</span><strong>{selected.startDate} · {schedule.length}</strong></div><div><span className="block text-[#355875]">Total interest</span><strong>{symbol}{formatGHS(money(schedule.reduce((s, r) => s + r.interestExpense, 0)))}</strong></div></div>
          <p className="mb-3 text-[11px] text-[#355875]">Amounts are calculated in whole cents. The final instalment absorbs accumulated monthly cent rounding. “Cash due” is zero before a bullet loan matures; interest still accrues. Print/export includes this selected facility only.</p>
          <div className="overflow-x-auto"><table className="w-full min-w-[1050px] text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Period / due date</th><th className={thCls + ' text-right'}>Opening principal</th><th className={thCls + ' text-right'}>Interest</th><th className={thCls + ' text-right'}>Principal due</th><th className={thCls + ' text-right'}>Cash due</th><th className={thCls + ' text-right'}>Closing principal</th><th className={thCls}>Accounting status</th><th className={thCls + ' text-center'}>Accounting action</th></tr></thead><tbody>
            {schedule.map((row) => { const bill = billFor(selected, row); const obligation = row.interestExpense + row.principalPayment; const settled = bill && bill.outstanding < 0.01; return <tr key={row.periodNum} className={rowCls}>
              <td className="px-3 py-2 font-mono"><strong className="text-[#855b00]">M{row.periodNum}</strong><span className="block text-[10px] text-[#355875]">{row.date}</span></td>
              <td className={numCls}>{formatGHS(row.openingBalance)}</td><td className={numCls + ' text-rose-700'}>{formatGHS(row.interestExpense)}</td><td className={numCls}>{formatGHS(row.principalPayment)}</td><td className={numCls + ' font-bold'}>{formatGHS(row.totalPayment)}</td><td className={numCls}>{formatGHS(row.closingBalance)}</td>
              <td className="px-3 py-2"><span className={`rounded px-2 py-0.5 text-[10px] font-bold ${settled ? 'bg-emerald-100 text-emerald-800' : bill ? 'bg-amber-100 text-amber-900' : 'bg-slate-100 text-slate-600'}`}>{settled ? 'Paid' : bill ? `Payable ${formatGHS(bill.outstanding)}` : 'Not accrued'}</span>{bill && <span className="mt-1 block font-mono text-[9px] text-[#355875]">{bill.docNo}</span>}</td>
              <td className="px-3 py-2 text-center"><div className="flex flex-wrap justify-center gap-1" data-print-hide>{obligation > 0 && !bill && <button type="button" disabled={readOnly || busy} onClick={() => void accrue(row)} className="rounded bg-[#082f4f] px-2 py-1 text-[10px] font-bold text-white disabled:opacity-40">Create accrual</button>}{bill && bill.outstanding > 0 && <button type="button" onClick={() => onNavigate?.('payment_desk')} className="inline-flex items-center gap-1 rounded bg-emerald-700 px-2 py-1 text-[10px] font-bold text-white">Pay at Payment Desk<ArrowRight className="h-3 w-3" /></button>}{settled && <span className="font-bold text-emerald-700">Settled</span>}</div></td>
            </tr>; })}
          </tbody></table></div>
        </div>
      </Card>}
    </>}
    {due > 0 && <button type="button" onClick={() => onNavigate?.('payment_desk')} className="rounded-lg bg-emerald-700 px-4 py-2 text-xs font-bold text-white">Open Payment Desk · {symbol}{formatGHS(due)} accrued debt due</button>}
    {showNew && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"><form onSubmit={(e) => void createFacility(e)} className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl text-xs">
      <div className="mb-4 flex items-center justify-between border-b border-sky-200 pb-3"><h3 className="text-base font-black text-[#082f4f]">Register borrowing facility</h3><button type="button" onClick={() => setShowNew(false)} aria-label="Close" className="text-xl">×</button></div>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="font-bold text-[#355875]">Facility name<input value={name} onChange={(e) => setName(e.target.value)} required className="mt-1 w-full rounded border border-sky-300 p-2" /></label>
        <label className="font-bold text-[#355875]">Lender<input value={lender} onChange={(e) => setLender(e.target.value)} required className="mt-1 w-full rounded border border-sky-300 p-2" /></label>
        <label className="font-bold text-[#355875]">Principal ({symbol})<input type="number" min="0.01" max="10000000000" step="0.01" value={principal || ''} onChange={(e) => setPrincipal(Number(e.target.value))} required className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" /></label>
        <label className="font-bold text-[#355875]">Nominal annual rate %<input type="number" min="0" max="100" step="0.01" value={rate} onChange={(e) => setRate(Number(e.target.value))} required className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" /></label>
        <label className="font-bold text-[#355875]">Term (months)<input type="number" min="1" max="600" step="1" value={term} onChange={(e) => setTerm(Number(e.target.value))} required className="mt-1 w-full rounded border border-sky-300 p-2" /></label>
        <label className="font-bold text-[#355875]">Payment frequency<select value={frequency} onChange={(e) => setFrequency(e.target.value as 'monthly' | 'quarterly')} className="mt-1 w-full rounded border border-sky-300 p-2"><option value="monthly">Monthly</option><option value="quarterly">Quarterly</option></select></label>
        <label className="font-bold text-[#355875]">Repayment structure<select value={type} onChange={(e) => setType(e.target.value as FacilityType)} className="mt-1 w-full rounded border border-sky-300 p-2"><option value="amortising">Amortising</option><option value="interest_only">Interest-only + balloon</option><option value="bullet">Bullet principal at maturity</option></select></label>
        <label className="font-bold text-[#355875]">Arrangement fee ({symbol})<input type="number" min="0" step="0.01" value={fee} onChange={(e) => setFee(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" /></label>
        <label className="font-bold text-[#355875]">Start date<input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} required className="mt-1 w-full rounded border border-sky-300 p-2" /></label>
      </div><p className="mt-3 text-[11px] text-[#355875]">Confirm the executed agreement&apos;s day-count and fee/EIR treatment. This schedule uses a nominal annual rate divided by payment frequency.</p>
      <div className="mt-4 flex justify-end gap-2 border-t border-sky-100 pt-3"><button type="button" onClick={() => setShowNew(false)} className="px-3 py-2 font-bold text-[#355875]">Cancel</button><button type="submit" disabled={busy} className="rounded-lg bg-[#082f4f] px-4 py-2 font-bold text-white disabled:opacity-40">{busy ? 'Saving…' : 'Save facility & generate schedule'}</button></div>
    </form></div>}
  </div>;
};
