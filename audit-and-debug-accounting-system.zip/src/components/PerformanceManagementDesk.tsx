import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Copy, Download, Plus, RotateCcw, Save, Send, Target, Trash2, TrendingUp, Wallet, XCircle } from 'lucide-react';
import type { ACDOCALine, AccountMaster, ClientEntity, EmployeeProfile, SalesInvoice, UserAccount } from '@/types/accounting';
import { Card, PageHeader, Stat, cn, formatGHS, numCls, rowCls, tdCls, thCls } from '@/components/ui';
import { ComboChart, PALETTE, TornadoChart, WaterfallChart, Sparkline } from '@/components/charts';
import { downloadCsv } from '@/utils/printReport';
import { sectorCitRate } from '@/utils/reports';
import { groupOf } from '@/utils/ifrsPack';
import { fiscalStartMonthIndex, fiscalYearStartFor, localToday } from '@/utils/periods';
import { STATUS_STYLE, useWorkbooks, type Workbook, type WorkflowAction } from '@/lib/workbookClient';
import {
  DRIVER_META, KPI_DEFS, actualsMatrix, baseFromLedger, breakEven, budgetTotals, budgetVsActual, cashForecast, computeKpis, defaultDrivers, fiscalMonths, lastDay, monthLabel, projectScenario, ragStatus, rollingForecast, seedBudget, sensitivity, shiftMonth,
  type BudgetLine, type BudgetPayload, type CashPlanPayload, type ForecastMethod, type ScenarioPayload, type SeedMethod,
} from '@/utils/planning';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  invoices: SalesInvoice[];
  employees: EmployeeProfile[];
  fiscalYearStart?: string;
}

type Tab = 'budget' | 'variance' | 'forecast' | 'scenarios' | 'kpis' | 'cash';
const TABS: { id: Tab; label: string }[] = [
  { id: 'budget', label: 'Budgets' },
  { id: 'variance', label: 'Budget vs Actual' },
  { id: 'forecast', label: 'Rolling Forecast' },
  { id: 'scenarios', label: 'Scenario Planning' },
  { id: 'kpis', label: 'KPI Scorecard' },
  { id: 'cash', label: 'Cash Forecast' },
];
const inputCls = 'rounded border border-sky-200 bg-white px-2 py-1 text-xs text-[#0a253e] outline-none focus:border-[#082f4f] disabled:bg-slate-50';
const btn = 'inline-flex items-center gap-1 rounded-md border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50 disabled:opacity-50';
const btnPrimary = 'inline-flex items-center gap-1 rounded-md bg-[#082f4f] px-2.5 py-1.5 text-[11px] font-bold text-white hover:bg-[#0c3f68] disabled:opacity-50';
const sgn = (n: number) => (n < 0 ? `(${formatGHS(-n)})` : formatGHS(n));
const sumArr = (xs: number[]) => Math.round(xs.reduce((s, x) => s + x, 0) * 100) / 100;

function latestBudget(items: Workbook<BudgetPayload>[]): Workbook<BudgetPayload> | undefined {
  const approved = items.filter((b) => b.status === 'approved');
  const pool = approved.length ? approved : items;
  return [...pool].sort((a, b) => (Number(b.key.split('-v')[1]) || 0) - (Number(a.key.split('-v')[1]) || 0))[0];
}

export function PerformanceManagementDesk({ currentClient, currentUser, lines, accounts, invoices, employees, fiscalYearStart }: Props) {
  const [tab, setTab] = useState<Tab>('budget');
  const today = localToday();
  const fyIdx = fiscalStartMonthIndex(fiscalYearStart);
  const currentFy = fiscalYearStartFor(today, fyIdx);
  const [fyStart, setFyStart] = useState(currentFy);
  const months = useMemo(() => fiscalMonths(fyStart), [fyStart]);
  const fyLabel = `FY${months[11].slice(0, 4)}`;
  const readOnly = currentUser.role === 'auditor' || (currentUser.status ?? 'active') !== 'active';
  const clientId = currentClient.id;
  const cur = currentClient.currency === 'GHS' ? '₵' : `${currentClient.currency} `;
  const citRate = sectorCitRate(currentClient.sector).rate;
  const [method, setMethod] = useState<ForecastMethod>('run_rate');
  const [periodicity, setPeriodicity] = useState<'monthly' | 'quarterly' | 'annual'>('monthly');

  const entityLines = useMemo(() => lines.filter((l) => l.clientId === clientId), [lines, clientId]);
  const actuals = useMemo(() => actualsMatrix(entityLines, accounts, clientId, months), [entityLines, accounts, clientId, months]);
  const prior = useMemo(() => actualsMatrix(entityLines, accounts, clientId, months.map((m) => shiftMonth(m, -12))), [entityLines, accounts, clientId, months]);
  const thisMonth = today.slice(0, 7);
  const closedIdx = months[11] < thisMonth ? 11 : months.findIndex((m) => m === thisMonth) - 1;
  const budgets = useWorkbooks<BudgetPayload>(clientId, 'budget');
  const fyBudgets = budgets.items.filter((b) => b.key.startsWith(`${fyLabel}-v`));
  const active = latestBudget(fyBudgets);
  const plAccounts = useMemo(() => accounts.filter((a) => (a.type === 'Income' || a.type === 'Expense') && a.active !== false), [accounts]);
  const emptyBudget: BudgetPayload = { fiscalYear: Number(months[11].slice(0, 4)), startMonth: fyStart, method: 'zero_based', growthPct: 0, inflationPct: 0, assumptions: '', lines: [], capex: [] };
  const basis = active?.payload ?? emptyBudget;
  const forecast = useMemo(() => rollingForecast(basis, actuals, prior, closedIdx, method), [basis, actuals, prior, closedIdx, method]);
  const fyOptions = [shiftMonth(currentFy, -12), currentFy, shiftMonth(currentFy, 12)];

  return (
    <div className="space-y-5">
      <PageHeader kicker="Performance management · EPM" title="Budgeting, Forecasting & Scenario Planning" desc="Version-controlled budgets with maker-checker approval, budget-versus-actual variance analysis, rolling forecasts, driver-based scenarios with sensitivity and break-even, a balanced scorecard and a 12-month cash-flow forecast — all driven by the posted ledger.">
        <label className="text-[11px] font-bold text-[#355875]">Fiscal year
          <select value={fyStart} onChange={(e) => setFyStart(e.target.value)} className={cn(inputCls, 'ml-1')}>
            {fyOptions.map((m) => <option key={m} value={m}>FY{fiscalMonths(m)[11].slice(0, 4)} ({monthLabel(m)} – {monthLabel(fiscalMonths(m)[11])})</option>)}
          </select>
        </label>
        <label className="text-[11px] font-bold text-[#355875]">Periodicity
          <select value={periodicity} onChange={(e) => setPeriodicity(e.target.value as 'monthly' | 'quarterly' | 'annual')} className={cn(inputCls, 'ml-1')}>
            <option value="monthly">Monthly</option>
            <option value="quarterly">Quarterly</option>
            <option value="annual">Annual</option>
          </select>
        </label>
      </PageHeader>
      <div role="tablist" aria-label="Performance management" className="flex flex-wrap gap-1 border-b border-sky-200">
        {TABS.map((t) => (
          <button key={t.id} role="tab" type="button" aria-selected={tab === t.id} onClick={() => setTab(t.id)} className={cn('rounded-t-md px-3 py-2 text-xs font-bold', tab === t.id ? 'border border-b-white border-sky-200 bg-white text-[#082f4f] -mb-px' : 'text-[#355875] hover:text-[#082f4f]')}>{t.label}</button>
        ))}
      </div>
      {budgets.error && <div role="alert" className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-xs font-bold text-amber-900">{budgets.error}</div>}

      {tab === 'budget' && <BudgetTab {...{ currentUser, readOnly, months, fyLabel, fyStart, entityLines, accounts, clientId, plAccounts, budgets, fyBudgets, active, cur }} />}
      {tab === 'variance' && <VarianceTab {...{ months, active, actuals, closedIdx, cur, code: currentClient.code, fyLabel, periodicity }} />}
      {tab === 'forecast' && <ForecastTab {...{ months, forecast, closedIdx, method, setMethod, active, cur, code: currentClient.code, fyLabel, periodicity }} />}
      {tab === 'scenarios' && <ScenarioTab {...{ clientId, entityLines, accounts, today, citRate, readOnly, fyLabel, cur }} />}
      {tab === 'kpis' && <KpiTab {...{ clientId, entityLines, accounts, invoices, employees, months, fyStart, today, active, closedIdx, readOnly, periodicity }} />}
      {tab === 'cash' && <CashTab {...{ clientId, entityLines, accounts, months, forecast, today, readOnly, fyLabel, cur, periodicity }} />}
    </div>
  );
}

/* ------------------------------------------------------------------ */

function bucketLabel(periodicity: 'monthly' | 'quarterly' | 'annual', month: string, idx: number, total: number) {
  if (periodicity === 'monthly') return monthLabel(month);
  if (periodicity === 'annual') return idx === 0 ? `FY ${month.slice(0, 4)}` : '';
  const q = Math.floor((idx % 12) / 3) + 1;
  return `Q${q} ${month.slice(0, 4)}`;
}
function bucketIndexes(periodicity: 'monthly' | 'quarterly' | 'annual', len: number) {
  if (periodicity === 'monthly') return Array.from({ length: len }, (_, i) => [i]);
  if (periodicity === 'annual') return [Array.from({ length: len }, (_, i) => i)];
  return Array.from({ length: Math.ceil(len / 3) }, (_, i) => [i * 3, i * 3 + 1, i * 3 + 2].filter((x) => x < len));
}
function aggregateSeries(values: number[], periodicity: 'monthly' | 'quarterly' | 'annual') {
  return bucketIndexes(periodicity, values.length).map((idxs) => idxs.reduce((s, i) => s + (values[i] ?? 0), 0));
}
function aggregateRows<T extends { months: number[] }>(rows: T[], periodicity: 'monthly' | 'quarterly' | 'annual') {
  return rows.map((r) => ({ ...r, months: aggregateSeries(r.months, periodicity) }));
}

function BudgetTab({ currentUser, readOnly, months, fyLabel, fyStart, entityLines, accounts, clientId, plAccounts, budgets, fyBudgets, active, cur }: {
  currentUser: UserAccount; readOnly: boolean; months: string[]; fyLabel: string; fyStart: string; entityLines: ACDOCALine[]; accounts: AccountMaster[]; clientId: number; plAccounts: AccountMaster[];
  budgets: ReturnType<typeof useWorkbooks<BudgetPayload>>; fyBudgets: Workbook<BudgetPayload>[]; active?: Workbook<BudgetPayload>; cur: string;
}) {
  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [draft, setDraft] = useState<{ key: string; payload: BudgetPayload } | null>(null);
  const [seedMethod, setSeedMethod] = useState<SeedMethod>('prior_year');
  const [growth, setGrowth] = useState(10);
  const [inflation, setInflation] = useState(15);
  const [comment, setComment] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [addAccount, setAddAccount] = useState('');
  const key = draft?.key ?? selectedKey ?? active?.key ?? null;
  const saved = fyBudgets.find((b) => b.key === key);
  const payload = draft && draft.key === key ? draft.payload : saved?.payload;
  const editable = !readOnly && (!saved || saved.status === 'draft' || saved.status === 'rejected');
  const nextKey = () => `${fyLabel}-v${Math.max(0, ...fyBudgets.map((b) => Number(b.key.split('-v')[1]) || 0), draft ? Number(draft.key.split('-v')[1]) || 0 : 0) + 1}`;
  const totals = payload ? budgetTotals(payload.lines) : null;

  const generate = () => {
    const k = nextKey();
    setDraft({ key: k, payload: { fiscalYear: Number(months[11].slice(0, 4)), startMonth: fyStart, method: seedMethod, growthPct: growth, inflationPct: inflation, assumptions: `Seeded by ${seedMethod.replace('_', ' ')} · revenue growth ${growth}% · cost inflation ${inflation}%`, lines: seedBudget(entityLines, accounts, clientId, fyStart, seedMethod, growth, inflation), capex: [] } });
    setSelectedKey(k);
    setMsg({ ok: true, text: `Draft ${k} generated. Review the figures, then save.` });
  };
  const edit = (fn: (p: BudgetPayload) => BudgetPayload) => { if (payload && key && editable) setDraft({ key, payload: fn(payload) }); };
  const setCell = (row: number, m: number, v: number) => edit((p) => ({ ...p, lines: p.lines.map((l, i) => (i === row ? { ...l, months: l.months.map((x, j) => (j === m ? v : x)) } : l)) }));
  const spread = (row: number, total: number) => edit((p) => ({ ...p, lines: p.lines.map((l, i) => (i === row ? { ...l, months: Array.from({ length: 12 }, (_, j) => Math.round(((total / 12) + (j === 11 ? total - Math.round((total / 12) * 100) / 100 * 12 : 0)) * 100) / 100) } : l)) }));
  const save = async () => {
    if (!payload || !key) return;
    const res = await budgets.save(key, `${fyLabel} budget ${key.split('-')[1]}`, payload, saved?.version ?? 0);
    if (res.ok) setDraft(null);
    setMsg(res.ok ? { ok: true, text: `Saved ${key} (version ${res.workbook?.version}).` } : { ok: false, text: res.error ?? 'Save failed.' });
  };
  const act = async (a: WorkflowAction) => {
    if (!saved) return;
    if (a === 'reject' && !comment.trim()) { setMsg({ ok: false, text: 'Enter a rejection reason first.' }); return; }
    const res = await budgets.act(saved.key, a, saved.version, comment);
    setMsg(res.ok ? { ok: true, text: `${saved.key}: ${a} recorded.` } : { ok: false, text: res.error ?? 'Action failed.' });
    if (res.ok) setComment('');
  };
  const revise = () => {
    if (!saved) return;
    const k = nextKey();
    setDraft({ key: k, payload: { ...saved.payload, assumptions: `${saved.payload.assumptions} · Revision of ${saved.key}` } });
    setSelectedKey(k);
    setMsg({ ok: true, text: `Revision ${k} created from ${saved.key}. Save to persist.` });
  };
  const remove = async () => {
    if (draft && !saved) { setDraft(null); setSelectedKey(null); return; }
    if (!saved) return;
    const res = await budgets.remove(saved.key);
    setMsg(res.ok ? { ok: true, text: `${saved.key} deleted.` } : { ok: false, text: res.error ?? 'Delete failed.' });
    if (res.ok) setSelectedKey(null);
  };
  const canReview = saved?.status === 'submitted' && !readOnly && (currentUser.role === 'owner' || currentUser.role === 'partner' || currentUser.canCheck) && saved.preparedBy !== currentUser.username && saved.submittedBy !== currentUser.username;
  const exportCsv = () => payload && downloadCsv(`${key}_budget.csv`, [['Account', 'Name', 'Type', ...months.map(monthLabel), 'FY total'], ...payload.lines.map((l) => [l.accountNo, l.accountName, l.type, ...l.months, sumArr(l.months)])]);

  return (
    <div className="space-y-4">
      {msg && <div role="status" className={cn('rounded-lg border px-3 py-2 text-xs font-bold', msg.ok ? 'border-emerald-300 bg-emerald-50 text-emerald-800' : 'border-rose-300 bg-rose-50 text-rose-800')}>{msg.text}</div>}
      <div className="grid gap-4 lg:grid-cols-[18rem_1fr]">
        <div className="space-y-4">
          <Card title="Budget versions" sub={fyLabel}>
            <div className="space-y-1.5">
              {fyBudgets.length === 0 && !draft && <p className="text-xs text-[#355875]">No budget for {fyLabel} yet.</p>}
              {[...fyBudgets.map((b) => ({ key: b.key, status: b.status as string, by: b.preparedBy })), ...(draft && !fyBudgets.some((b) => b.key === draft.key) ? [{ key: draft.key, status: 'unsaved', by: currentUser.username }] : [])].map((b) => (
                <button key={b.key} type="button" onClick={() => setSelectedKey(b.key)} className={cn('flex w-full items-center justify-between rounded-md border px-2.5 py-1.5 text-left text-xs', key === b.key ? 'border-[#082f4f] bg-[#eaf4ff]' : 'border-sky-100 hover:bg-sky-50')}>
                  <span className="font-bold text-[#0a253e]">{b.key}{active?.key === b.key && <span className="ml-1 text-[9px] font-black text-[#855b00]">ACTIVE</span>}</span>
                  <span className={cn('rounded border px-1.5 py-0.5 text-[9.5px] font-bold', b.status === 'unsaved' ? 'border-sky-300 bg-sky-50 text-sky-800' : STATUS_STYLE[b.status as keyof typeof STATUS_STYLE])}>{b.status}</span>
                </button>
              ))}
            </div>
          </Card>
          <Card title="Generate a budget" sub="Top-down seeding from the ledger">
            <div className="space-y-2 text-xs">
              <label className="block font-semibold text-[#355875]">Method
                <select value={seedMethod} onChange={(e) => setSeedMethod(e.target.value as SeedMethod)} className={cn(inputCls, 'mt-1 w-full')}>
                  <option value="prior_year">Prior-year actuals × growth (seasonal)</option>
                  <option value="run_rate">Trailing average run-rate × growth</option>
                  <option value="zero_based">Zero-based (blank lines)</option>
                </select>
              </label>
              <label className="block font-semibold text-[#355875]">Revenue growth %<input type="number" step="any" value={growth} onChange={(e) => setGrowth(Number(e.target.value))} className={cn(inputCls, 'mt-1 w-full text-right')} /></label>
              <label className="block font-semibold text-[#355875]">Cost inflation %<input type="number" step="any" value={inflation} onChange={(e) => setInflation(Number(e.target.value))} className={cn(inputCls, 'mt-1 w-full text-right')} /></label>
              <button type="button" disabled={readOnly} onClick={generate} className={cn(btnPrimary, 'w-full justify-center')}><Plus className="h-3.5 w-3.5" />Generate new version</button>
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          {!payload ? (
            <Card title="No budget selected"><p className="text-xs text-[#355875]">Generate a budget version or select one from the list. Approved budgets drive the variance, forecast and KPI views.</p></Card>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                <Stat label="Budgeted revenue" value={`${cur}${formatGHS(sumArr(totals!.revenue))}`} />
                <Stat label="Budgeted expenses" value={`${cur}${formatGHS(sumArr(totals!.expenses))}`} />
                <Stat label="Budgeted profit" value={`${cur}${sgn(sumArr(totals!.profit))}`} tone={sumArr(totals!.profit) < 0 ? 'text-rose-700' : 'text-emerald-700'} />
                <Stat label="Status" value={<span className="text-sm">{saved ? saved.status.toUpperCase() : 'UNSAVED'}</span>} sub={saved ? `v${saved.version} · prepared ${saved.preparedBy ?? '—'}${saved.approvedBy ? ` · approved ${saved.approvedBy}` : ''}` : 'Save to persist'} />
              </div>
              <Card title={`${key} — monthly budget`} sub={payload.assumptions || 'Bottom-up edits allowed while in draft'} pad={false}
                action={<>
                  <button type="button" onClick={exportCsv} className={btn}><Download className="h-3 w-3" />CSV</button>
                  {editable && <button type="button" onClick={() => void save()} className={btnPrimary}><Save className="h-3 w-3" />Save draft</button>}
                  {saved && (saved.status === 'draft' || saved.status === 'rejected') && !readOnly && !draft && <button type="button" onClick={() => void act('submit')} className={btn}><Send className="h-3 w-3" />Submit for approval</button>}
                  {saved?.status === 'submitted' && !readOnly && <button type="button" onClick={() => void act('withdraw')} className={btn}><RotateCcw className="h-3 w-3" />Withdraw</button>}
                  {saved?.status === 'approved' && !readOnly && <button type="button" onClick={revise} className={btn}><Copy className="h-3 w-3" />Revise</button>}
                  {(!saved || saved.status === 'draft' || saved.status === 'rejected') && !readOnly && <button type="button" onClick={() => void remove()} className={cn(btn, 'text-rose-700')}><Trash2 className="h-3 w-3" />Delete</button>}
                </>}>
                {saved?.reviewComment && <p className="border-b border-sky-100 px-4 py-2 text-[11px] font-semibold text-[#855b00]">Reviewer comment: {saved.reviewComment}</p>}
                {saved?.status === 'submitted' && (
                  <div className="flex flex-wrap items-center gap-2 border-b border-sky-100 bg-amber-50/60 px-4 py-2">
                    <span className="text-[11px] font-bold text-amber-900">Awaiting independent review (submitted by {saved.submittedBy}).</span>
                    <input aria-label="Review comment" placeholder="Review comment (required to reject)" value={comment} onChange={(e) => setComment(e.target.value)} className={cn(inputCls, 'min-w-[14rem] flex-1')} />
                    <button type="button" disabled={!canReview} onClick={() => void act('approve')} className={btnPrimary}><CheckCircle2 className="h-3 w-3" />Approve</button>
                    <button type="button" disabled={!canReview} onClick={() => void act('reject')} className={cn(btn, 'text-rose-700')}><XCircle className="h-3 w-3" />Reject</button>
                    {!canReview && <span className="text-[10px] text-amber-900">Checker rights and independence from the preparer/submitter are required.</span>}
                  </div>
                )}
                <div className="max-h-[60vh] overflow-auto">
                  <table className="w-full min-w-[1200px]">
                    <thead className="sticky top-0 z-10"><tr><th className={thCls}>Account</th>{months.map((m) => <th key={m} className={cn(thCls, 'text-right')}>{monthLabel(m)}</th>)}<th className={cn(thCls, 'text-right')}>FY total</th><th className={thCls}><span className="sr-only">Remove</span></th></tr></thead>
                    <tbody>
                      {payload.lines.map((l: BudgetLine, i: number) => (
                        <tr key={l.accountNo} className={rowCls}>
                          <td className={cn(tdCls, 'whitespace-nowrap')}><span className={cn('mr-1 rounded px-1 text-[9px] font-black', l.type === 'Income' ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800')}>{l.type === 'Income' ? 'INC' : 'EXP'}</span>{l.accountNo} · {l.accountName}</td>
                          {l.months.map((v, m) => <td key={m} className="px-1 py-1"><input aria-label={`${l.accountName} ${monthLabel(months[m])}`} type="number" step="any" disabled={!editable} value={v} onChange={(e) => setCell(i, m, Number(e.target.value) || 0)} className={cn(inputCls, 'w-24 text-right font-mono')} /></td>)}
                          <td className="px-1 py-1"><input aria-label={`${l.accountName} full-year total (spreads evenly)`} type="number" step="any" disabled={!editable} value={sumArr(l.months)} onChange={(e) => spread(i, Number(e.target.value) || 0)} className={cn(inputCls, 'w-28 text-right font-mono font-bold')} /></td>
                          <td className="px-1 py-1">{editable && <button type="button" aria-label={`Remove ${l.accountName}`} onClick={() => edit((p) => ({ ...p, lines: p.lines.filter((_, j) => j !== i) }))} className="rounded p-1 text-rose-700 hover:bg-rose-50"><Trash2 className="h-3.5 w-3.5" /></button>}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-[#f7fbff]">
                      {(['revenue', 'expenses', 'profit'] as const).map((k) => (
                        <tr key={k} className="border-t border-sky-200"><td className={cn(tdCls, 'font-extrabold capitalize')}>{k === 'profit' ? 'Budgeted profit' : `Total ${k}`}</td>{totals![k].map((v, i) => <td key={i} className={cn(numCls, 'font-bold', v < 0 && 'text-rose-700')}>{sgn(v)}</td>)}<td className={cn(numCls, 'font-extrabold')}>{sgn(sumArr(totals![k]))}</td><td /></tr>
                      ))}
                    </tfoot>
                  </table>
                </div>
                {editable && (
                  <div className="flex flex-wrap items-center gap-2 border-t border-sky-100 px-4 py-2">
                    <select aria-label="Add account to budget" value={addAccount} onChange={(e) => setAddAccount(e.target.value)} className={inputCls}>
                      <option value="">Add P&L account…</option>
                      {plAccounts.filter((a) => !payload.lines.some((l) => l.accountNo === a.accountNo)).map((a) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>)}
                    </select>
                    <button type="button" disabled={!addAccount} onClick={() => { const a = plAccounts.find((x) => x.accountNo === addAccount); if (a) edit((p) => ({ ...p, lines: [...p.lines, { accountNo: a.accountNo, accountName: a.name, type: a.type as 'Income' | 'Expense', group: groupOf(a, a.accountNo), months: new Array(12).fill(0) }] })); setAddAccount(''); }} className={btn}><Plus className="h-3 w-3" />Add line</button>
                  </div>
                )}
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function VarianceTab({ months, active, actuals, closedIdx, cur, code, fyLabel, periodicity }: { months: string[]; active?: Workbook<BudgetPayload>; actuals: Map<string, number[]>; closedIdx: number; cur: string; code: string; fyLabel: string; periodicity: 'monthly' | 'quarterly' | 'annual' }) {
  const [monthIdx, setMonthIdx] = useState(Math.max(0, Math.min(11, closedIdx)));
  const [pct, setPct] = useState(10);
  const [amount, setAmount] = useState(1000);
  if (!active) return <Card title="No budget available"><p className="text-xs text-[#355875]">Create and approve a budget for {fyLabel} to run variance analysis.</p></Card>;
  const bva = budgetVsActual(active.payload, actuals, monthIdx, { pct, amount });
  const bt = budgetTotals(active.payload.lines);
  const labels = bucketIndexes(periodicity, months.length).map((idxs, b) => bucketLabel(periodicity, months[idxs[0]], b, months.length)).filter(Boolean);
  const actRev = aggregateSeries(months.map((_, i) => sumArr(active.payload.lines.filter((l) => l.type === 'Income').map((l) => actuals.get(l.accountNo)?.[i] ?? 0).concat([...actuals.entries()].filter(([k]) => !active.payload.lines.some((l) => l.accountNo === k)).filter(([k]) => bva.rows.find((r) => r.accountNo === k)?.type === 'Income').map(([, v]) => v[i] ?? 0)))), periodicity);
  const actExp = aggregateSeries(months.map((_, i) => sumArr(bva.rows.filter((r) => r.type === 'Expense').map((r) => actuals.get(r.accountNo)?.[i] ?? 0))), periodicity);
  const budgetRev = aggregateSeries(bt.revenue, periodicity);
  const budgetExp = aggregateSeries(bt.expenses, periodicity);
  const material = bva.rows.filter((r) => r.material);
  const steps = [{ label: 'Budget profit', value: bva.profit.budget, total: true }, { label: 'Revenue var.', value: Math.round((bva.revenue.actual - bva.revenue.budget) * 100) / 100 }, { label: 'Cost var.', value: Math.round((bva.expenses.budget - bva.expenses.actual) * 100) / 100 }, { label: 'Actual profit', value: bva.profit.actual, total: true }];
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-3">
        <label className="text-[11px] font-bold text-[#355875]">Reporting month<select value={monthIdx} onChange={(e) => setMonthIdx(Number(e.target.value))} className={cn(inputCls, 'ml-1')}>{months.map((m, i) => <option key={m} value={i}>{monthLabel(m)}</option>)}</select></label>
        <label className="text-[11px] font-bold text-[#355875]">Materiality %<input type="number" value={pct} onChange={(e) => setPct(Number(e.target.value))} className={cn(inputCls, 'ml-1 w-20 text-right')} /></label>
        <label className="text-[11px] font-bold text-[#355875]">and at least<input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value))} className={cn(inputCls, 'ml-1 w-28 text-right')} /></label>
        <span className="text-[11px] text-[#355875]">Budget basis: <strong>{active.key}</strong> ({active.status})</span>
        <button type="button" className={btn} onClick={() => downloadCsv(`${code}_${fyLabel}_BvA_${months[monthIdx]}.csv`, [['Account', 'Name', 'Type', 'Budget (month)', 'Actual (month)', 'Budget YTD', 'Actual YTD', 'Fav/(Adv) YTD', 'Var %', 'Full-year budget', 'Material'], ...bva.rows.map((r) => [r.accountNo, r.accountName, r.type, r.budgetMonth, r.actualMonth, r.budgetYtd, r.actualYtd, r.favVarYtd, r.varPct, r.budgetFy, r.material ? 'Yes' : ''])])}><Download className="h-3 w-3" />CSV</button>
      </div>
      {active.status !== 'approved' && <div className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-xs font-bold text-amber-900">This budget is not approved yet — variances are indicative only.</div>}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Revenue YTD vs budget" value={`${cur}${formatGHS(bva.revenue.actual)}`} sub={`Budget ${formatGHS(bva.revenue.budget)} · ${bva.revenue.budget ? ((bva.revenue.actual / bva.revenue.budget) * 100).toFixed(1) : '—'}% attained`} />
        <Stat label="Expenses YTD vs budget" value={`${cur}${formatGHS(bva.expenses.actual)}`} sub={`Budget ${formatGHS(bva.expenses.budget)}`} tone={bva.expenses.actual > bva.expenses.budget ? 'text-rose-700' : undefined} />
        <Stat label="Profit YTD vs budget" value={`${cur}${sgn(bva.profit.actual)}`} sub={`Budget ${sgn(bva.profit.budget)}`} tone={bva.profit.actual < bva.profit.budget ? 'text-rose-700' : 'text-emerald-700'} />
        <Stat label="Material variances" value={material.length} sub={`≥ ${pct}% and ≥ ${formatGHS(amount)}`} tone={material.length ? 'text-amber-700' : undefined} />
      </div>
      <div className="grid gap-4 xl:grid-cols-2">
        <Card title="Monthly budget vs actual"><ComboChart title="Monthly budget versus actual" labels={labels} series={[{ name: 'Budget revenue', values: budgetRev, color: '#bcd7ee' }, { name: 'Actual revenue', values: actRev, color: PALETTE.navy }, { name: 'Budget expenses', values: budgetExp, type: 'line', color: PALETTE.amber, dashed: true }, { name: 'Actual expenses', values: actExp, type: 'line', color: PALETTE.red }]} /></Card>
        <Card title="Profit bridge — budget to actual (YTD)"><WaterfallChart title="Profit bridge" steps={steps} /></Card>
      </div>
      <Card title="Variance analysis by account" sub="Favourable/(adverse): income above budget or costs below budget are favourable" pad={false}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px]">
            <thead><tr><th className={thCls}>Account</th><th className={cn(thCls, 'text-right')}>Budget (month)</th><th className={cn(thCls, 'text-right')}>Actual (month)</th><th className={cn(thCls, 'text-right')}>Budget YTD</th><th className={cn(thCls, 'text-right')}>Actual YTD</th><th className={cn(thCls, 'text-right')}>Fav / (Adv)</th><th className={cn(thCls, 'text-right')}>%</th><th className={cn(thCls, 'text-right')}>FY budget</th></tr></thead>
            <tbody>{bva.rows.map((r) => (
              <tr key={r.accountNo} className={cn(rowCls, r.material && 'bg-amber-50/50')}>
                <td className={tdCls}><span className={cn('mr-1 rounded px-1 text-[9px] font-black', r.type === 'Income' ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800')}>{r.type === 'Income' ? 'INC' : 'EXP'}</span>{r.accountNo} · {r.accountName}{r.material && <span className="ml-1 text-[9px] font-black text-amber-800">MATERIAL</span>}</td>
                <td className={numCls}>{formatGHS(r.budgetMonth)}</td><td className={numCls}>{formatGHS(r.actualMonth)}</td><td className={numCls}>{formatGHS(r.budgetYtd)}</td><td className={numCls}>{formatGHS(r.actualYtd)}</td>
                <td className={cn(numCls, 'font-bold', r.favourable ? 'text-emerald-700' : 'text-rose-700')}>{sgn(r.favVarYtd)}</td><td className={cn(numCls, r.favourable ? 'text-emerald-700' : 'text-rose-700')}>{r.varPct.toFixed(1)}%</td><td className={numCls}>{formatGHS(r.budgetFy)}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function ForecastTab({ months, forecast, closedIdx, method, setMethod, active, cur, code, fyLabel, periodicity }: { months: string[]; forecast: ReturnType<typeof rollingForecast>; closedIdx: number; method: ForecastMethod; setMethod: (m: ForecastMethod) => void; active?: Workbook<BudgetPayload>; cur: string; code: string; fyLabel: string; periodicity: 'monthly' | 'quarterly' | 'annual' }) {
  const labels = bucketIndexes(periodicity, months.length).map((idxs, b) => bucketLabel(periodicity, months[idxs[0]], b, months.length)).filter(Boolean);
  const view = aggregateRows(forecast, periodicity);
  const rev = labels.map((_, i) => sumArr(view.filter((r) => r.type === 'Income').map((r) => r.months[i])));
  const exp = labels.map((_, i) => sumArr(view.filter((r) => r.type === 'Expense').map((r) => r.months[i])));
  const bt = active ? budgetTotals(active.payload.lines) : null;
  const fyRev = sumArr(rev);
  const fyProfit = sumArr(rev) - sumArr(exp);
  const budgetProfit = bt ? sumArr(bt.profit) : 0;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-3">
        <label className="text-[11px] font-bold text-[#355875]">Forecast method
          <select value={method} onChange={(e) => setMethod(e.target.value as ForecastMethod)} className={cn(inputCls, 'ml-1')}>
            <option value="run_rate">Run-rate (average of last 3 actual months)</option>
            <option value="trend">Linear trend (least squares)</option>
            <option value="seasonal">Seasonal (prior-year pattern × YTD ratio)</option>
            <option value="budget">Budget for remaining months</option>
          </select>
        </label>
        <span className="text-[11px] text-[#355875]">Actuals through <strong>{closedIdx >= 0 ? monthLabel(months[closedIdx]) : 'none yet'}</strong>; remaining months forecast.</span>
        <button type="button" className={btn} onClick={() => downloadCsv(`${code}_${fyLabel}_forecast_${method}.csv`, [['Account', 'Name', 'Type', ...months.map((m, i) => `${monthLabel(m)} ${i <= closedIdx ? '(A)' : '(F)'}`), 'FY forecast', 'FY budget', 'Fav/(Adv)'], ...view.map((r) => [r.accountNo, r.accountName, r.type, ...r.months, r.fy, r.budgetFy, r.favVar])])}><Download className="h-3 w-3" />CSV</button>
      </div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Full-year revenue outturn" value={`${cur}${formatGHS(fyRev)}`} sub={bt ? `Budget ${formatGHS(sumArr(bt.revenue))}` : 'No budget'} />
        <Stat label="Full-year expenses outturn" value={`${cur}${formatGHS(sumArr(exp))}`} sub={bt ? `Budget ${formatGHS(sumArr(bt.expenses))}` : ''} />
        <Stat label="Full-year profit outturn" value={`${cur}${sgn(fyProfit)}`} tone={fyProfit < 0 ? 'text-rose-700' : 'text-emerald-700'} sub={bt ? `Budget ${sgn(budgetProfit)}` : ''} />
        <Stat label="Outturn vs budget" value={bt ? sgn(Math.round((fyProfit - budgetProfit) * 100) / 100) : '—'} tone={bt && fyProfit < budgetProfit ? 'text-rose-700' : 'text-emerald-700'} sub="Profit gap (latest estimate)" />
      </div>
      <Card title="Revenue and expenses — actual + forecast vs budget"><ComboChart title="Rolling forecast" labels={labels.map((l, i) => `${l}${periodicity === 'monthly' && bucketIndexes(periodicity, months.length)[i]?.every((x) => x <= closedIdx) ? '' : periodicity === 'monthly' ? '*' : ''}`)} series={[{ name: 'Revenue (actual / forecast*)', values: rev, color: PALETTE.navy }, { name: 'Expenses (actual / forecast*)', values: exp, color: PALETTE.gold }, ...(bt ? [{ name: 'Budget revenue', values: bt.revenue, type: 'line' as const, color: PALETTE.green, dashed: true }, { name: 'Budget expenses', values: bt.expenses, type: 'line' as const, color: PALETTE.red, dashed: true }] : [])]} /></Card>
      <Card title="Forecast by account" pad={false}>
        <div className="max-h-[55vh] overflow-auto">
          <table className="w-full min-w-[1200px]">
            <thead className="sticky top-0"><tr><th className={thCls}>Account</th>{months.map((m, i) => <th key={m} className={cn(thCls, 'text-right', i > closedIdx && 'text-[#855b00]')}>{monthLabel(m)} {i <= closedIdx ? 'A' : 'F'}</th>)}<th className={cn(thCls, 'text-right')}>FY</th><th className={cn(thCls, 'text-right')}>Budget</th><th className={cn(thCls, 'text-right')}>Fav/(Adv)</th></tr></thead>
            <tbody>{view.map((r) => (
              <tr key={r.accountNo} className={rowCls}><td className={cn(tdCls, 'whitespace-nowrap')}>{r.accountNo} · {r.accountName}</td>{r.months.map((v, i) => <td key={i} className={cn(numCls, i > closedIdx && 'italic text-[#855b00]')}>{formatGHS(v)}</td>)}<td className={cn(numCls, 'font-bold')}>{formatGHS(r.fy)}</td><td className={numCls}>{formatGHS(r.budgetFy)}</td><td className={cn(numCls, r.favVar >= 0 ? 'text-emerald-700' : 'text-rose-700')}>{sgn(r.favVar)}</td></tr>
            ))}</tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */

interface ScenarioSet { scenarios: ScenarioPayload[] }

function ScenarioTab({ clientId, entityLines, accounts, today, citRate, readOnly, fyLabel, cur }: { clientId: number; entityLines: ACDOCALine[]; accounts: AccountMaster[]; today: string; citRate: number; readOnly: boolean; fyLabel: string; cur: string }) {
  const base = useMemo(() => baseFromLedger(entityLines, accounts, clientId, today), [entityLines, accounts, clientId, today]);
  const wb = useWorkbooks<ScenarioSet>(clientId, 'scenario');
  const key = `${fyLabel}-set`;
  const saved = wb.items.find((w) => w.key === key);
  const defaults: ScenarioPayload[] = [
    { name: 'Base case', description: 'Management expectation', horizonYears: 3, probabilityPct: 60, drivers: defaultDrivers('base', citRate, base) },
    { name: 'Best case', description: 'Upside — demand growth, stable FX', horizonYears: 3, probabilityPct: 20, drivers: defaultDrivers('best', citRate, base) },
    { name: 'Worst case', description: 'Downside — FX shock, cost inflation, slower collections', horizonYears: 3, probabilityPct: 20, drivers: defaultDrivers('worst', citRate, base) },
  ];
  const [draft, setDraft] = useState<ScenarioPayload[] | null>(null);
  const scenarios = draft ?? (saved?.payload?.scenarios?.length ? saved.payload.scenarios : defaults);
  const [sel, setSel] = useState(0);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const s = scenarios[Math.min(sel, scenarios.length - 1)];
  const proj = scenarios.map((x) => projectScenario(base, x.drivers, x.horizonYears));
  const sens = sensitivity(base, s.drivers, 5);
  const be = breakEven(proj[Math.min(sel, scenarios.length - 1)][0]);
  const totalP = scenarios.reduce((t, x) => t + x.probabilityPct, 0);
  const ev = totalP ? scenarios.reduce((t, x, i) => t + (x.probabilityPct / totalP) * (proj[i][0]?.netProfit ?? 0), 0) : 0;
  const setDriver = (k: keyof ScenarioPayload['drivers'], v: number) => setDraft(scenarios.map((x, i) => (i === sel ? { ...x, drivers: { ...x.drivers, [k]: v } } : x)));
  const setField = (patch: Partial<ScenarioPayload>) => setDraft(scenarios.map((x, i) => (i === sel ? { ...x, ...patch } : x)));
  const save = async () => {
    const res = await wb.save(key, `${fyLabel} scenario set`, { scenarios }, saved?.version ?? 0);
    if (res.ok) setDraft(null);
    setMsg(res.ok ? { ok: true, text: `Scenarios saved (version ${res.workbook?.version}).` } : { ok: false, text: res.error ?? 'Save failed.' });
  };
  const horizon = Math.max(...scenarios.map((x) => x.horizonYears));
  return (
    <div className="space-y-4">
      {msg && <div role="status" className={cn('rounded-lg border px-3 py-2 text-xs font-bold', msg.ok ? 'border-emerald-300 bg-emerald-50 text-emerald-800' : 'border-rose-300 bg-rose-50 text-rose-800')}>{msg.text}</div>}
      <Card title="Base financials (trailing twelve months from the ledger)" sub={`${base.from} to ${base.asAt}`}>
        <div className="grid grid-cols-2 gap-2 text-xs md:grid-cols-6">
          {([['Revenue', base.revenue], ['Cost of sales', base.cogs], ['Staff costs', base.staff], ['Overheads', base.opex], ['Depreciation', base.depreciation], ['Finance costs', base.financeCosts], ['Cash', base.cash], ['Receivables', base.receivables], ['Inventory', base.inventory], ['Payables', base.payables], ['Borrowings & leases', base.borrowings]] as const).map(([l, v]) => (
            <div key={l} className="rounded border border-sky-100 bg-[#f7fbff] px-2 py-1.5"><div className="text-[10px] font-bold uppercase text-[#355875]">{l}</div><div className="font-mono font-bold">{formatGHS(v)}</div></div>
          ))}
        </div>
      </Card>
      <div className="grid gap-4 xl:grid-cols-[22rem_1fr]">
        <Card title="Scenario drivers" action={<>
          <button type="button" disabled={readOnly} onClick={() => { setDraft([...scenarios, { ...s, name: `Custom ${scenarios.length + 1}`, probabilityPct: 0 }]); setSel(scenarios.length); }} className={btn}><Plus className="h-3 w-3" />Add</button>
          <button type="button" disabled={readOnly || draft === null} onClick={() => void save()} className={btnPrimary}><Save className="h-3 w-3" />Save</button>
        </>}>
          <div className="mb-2 flex flex-wrap gap-1">{scenarios.map((x, i) => <button key={`${x.name}-${i}`} type="button" onClick={() => setSel(i)} className={cn('rounded border px-2 py-1 text-[11px] font-bold', i === sel ? 'border-[#082f4f] bg-[#082f4f] text-white' : 'border-sky-200 text-[#082f4f]')}>{x.name}</button>)}</div>
          <div className="space-y-1.5 text-xs">
            <label className="block font-semibold text-[#355875]">Name<input disabled={readOnly} value={s.name} onChange={(e) => setField({ name: e.target.value })} className={cn(inputCls, 'mt-0.5 w-full')} /></label>
            <div className="grid grid-cols-2 gap-2">
              <label className="font-semibold text-[#355875]">Horizon (years)<input type="number" min={1} max={5} disabled={readOnly} value={s.horizonYears} onChange={(e) => setField({ horizonYears: Math.max(1, Math.min(5, Number(e.target.value) || 1)) })} className={cn(inputCls, 'mt-0.5 w-full text-right')} /></label>
              <label className="font-semibold text-[#355875]">Probability %<input type="number" min={0} max={100} disabled={readOnly} value={s.probabilityPct} onChange={(e) => setField({ probabilityPct: Number(e.target.value) || 0 })} className={cn(inputCls, 'mt-0.5 w-full text-right')} /></label>
            </div>
            {DRIVER_META.map((m) => (
              <label key={m.key} className="flex items-center justify-between gap-2 font-semibold text-[#355875]">{m.label}{m.unit !== 'amount' ? ` (${m.unit})` : ''}
                <input type="number" step="any" disabled={readOnly} value={s.drivers[m.key]} onChange={(e) => setDriver(m.key, Number(e.target.value) || 0)} className={cn(inputCls, 'w-28 text-right font-mono')} />
              </label>
            ))}
            {scenarios.length > 1 && <button type="button" disabled={readOnly} onClick={() => { setDraft(scenarios.filter((_, i) => i !== sel)); setSel(0); }} className={cn(btn, 'mt-1 text-rose-700')}><Trash2 className="h-3 w-3" />Remove scenario</button>}
          </div>
        </Card>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <Stat label={`${s.name} — Y1 net profit`} value={`${cur}${sgn(proj[sel]?.[0]?.netProfit ?? 0)}`} tone={(proj[sel]?.[0]?.netProfit ?? 0) < 0 ? 'text-rose-700' : 'text-emerald-700'} />
            <Stat label="Probability-weighted Y1 profit" value={`${cur}${sgn(Math.round(ev * 100) / 100)}`} sub={totalP !== 100 ? `Probabilities sum to ${totalP}% (normalised)` : 'Expected value'} />
            <Stat label="Break-even revenue (Y1)" value={`${cur}${formatGHS(be.breakEvenRevenue)}`} sub={`CM ratio ${be.cmRatioPct}%`} />
            <Stat label="Margin of safety" value={`${be.marginOfSafetyPct}%`} tone={be.marginOfSafetyPct < 10 ? 'text-rose-700' : undefined} />
          </div>
          <Card title="Net profit by scenario and year"><ComboChart title="Scenario net profit" labels={Array.from({ length: horizon }, (_, i) => `Year ${i + 1}`)} series={scenarios.map((x, i) => ({ name: x.name, values: Array.from({ length: horizon }, (_, y) => proj[i][y]?.netProfit ?? NaN), type: 'line' as const }))} /></Card>
          <Card title="Scenario comparison (Year 1)" pad={false}>
            <div className="overflow-x-auto"><table className="w-full min-w-[760px]">
              <thead><tr><th className={thCls}>Metric</th>{scenarios.map((x, i) => <th key={i} className={cn(thCls, 'text-right')}>{x.name}</th>)}</tr></thead>
              <tbody>{([['Revenue', 'revenue'], ['Gross profit', 'grossProfit'], ['EBITDA', 'ebitda'], ['Profit before tax', 'pbt'], ['Net profit', 'netProfit'], ['Gross margin %', 'grossMarginPct'], ['Net margin %', 'netMarginPct'], ['Operating cash flow', 'operatingCashFlow'], ['Free cash flow', 'freeCashFlow'], ['Closing cash', 'closingCash']] as const).map(([label, k]) => (
                <tr key={k} className={rowCls}><td className={tdCls}>{label}</td>{proj.map((p, i) => <td key={i} className={cn(numCls, (p[0]?.[k] ?? 0) < 0 && 'text-rose-700')}>{k.endsWith('Pct') ? `${(p[0]?.[k] ?? 0).toFixed(1)}%` : sgn(p[0]?.[k] ?? 0)}</td>)}</tr>
              ))}</tbody>
            </table></div>
          </Card>
          <Card title={`Sensitivity of Year-1 net profit — ${s.name} (±5 percentage points)`}><TornadoChart title="Sensitivity" base={sens.baseProfit} rows={sens.rows} /></Card>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function KpiTab({ clientId, entityLines, accounts, invoices, employees, months, fyStart, today, active, closedIdx, readOnly, periodicity }: { clientId: number; entityLines: ACDOCALine[]; accounts: AccountMaster[]; invoices: SalesInvoice[]; employees: EmployeeProfile[]; months: string[]; fyStart: string; today: string; active?: Workbook<BudgetPayload>; closedIdx: number; readOnly: boolean; periodicity: 'monthly' | 'quarterly' | 'annual' }) {
  const from = `${fyStart}-01`;
  const through = today < lastDay(months[11]) ? today : lastDay(months[11]);
  const wb = useWorkbooks<{ targets: Record<string, number> }>(clientId, 'kpi_targets');
  const saved = wb.items.find((w) => w.key === 'default');
  const [draft, setDraft] = useState<Record<string, number> | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const targets = draft ?? { ...Object.fromEntries(KPI_DEFS.map((k) => [k.id, k.target])), ...(saved?.payload?.targets ?? {}) };
  const activeEmployees = employees.filter((e) => e.status === 'active').length;
  const ytdIdx = Math.max(0, Math.min(11, months.findIndex((m) => m === today.slice(0, 7)) >= 0 ? months.findIndex((m) => m === today.slice(0, 7)) : closedIdx));
  const budgetRevenueYtd = active ? sumArr(active.payload.lines.filter((l) => l.type === 'Income').map((l) => sumArr(l.months.slice(0, ytdIdx + 1)))) : undefined;
  const kpis = useMemo(() => computeKpis(entityLines, accounts, clientId, from, through, { invoices, employees: activeEmployees, budgetRevenueYtd }), [entityLines, accounts, clientId, from, through, invoices, activeEmployees, budgetRevenueYtd]);
  const history = useMemo(() => Array.from({ length: 6 }, (_, i) => shiftMonth(today.slice(0, 7), i - 5)).map((m) => computeKpis(entityLines, accounts, clientId, `${m}-01`, lastDay(m), { invoices, employees: activeEmployees })), [entityLines, accounts, clientId, today, invoices, activeEmployees]);
  const fmtK = (v: number | null, unit: string) => (v === null ? '—' : unit === '%' ? `${v.toFixed(1)}%` : unit === 'x' ? `${v.toFixed(2)}×` : unit === 'days' ? `${Math.round(v)} d` : unit === 'months' ? `${v.toFixed(1)} mo` : formatGHS(v));
  const ragCls = { green: 'bg-emerald-500', amber: 'bg-amber-400', red: 'bg-rose-500', na: 'bg-slate-300' };
  const rags = KPI_DEFS.map((k) => ragStatus(kpis[k.id] ?? null, targets[k.id] ?? 0, k.direction));
  const save = async () => {
    const res = await wb.save('default', 'KPI targets', { targets }, saved?.version ?? 0);
    if (res.ok) setDraft(null);
    setMsg(res.ok ? 'Targets saved.' : res.error ?? 'Save failed.');
  };
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="On target" value={rags.filter((r) => r === 'green').length} tone="text-emerald-700" sub={`Period ${from} → ${through}`} />
        <Stat label="Watch" value={rags.filter((r) => r === 'amber').length} tone="text-amber-700" />
        <Stat label="Off target" value={rags.filter((r) => r === 'red').length} tone="text-rose-700" />
        <Stat label="Not measurable" value={rags.filter((r) => r === 'na').length} sub="Missing data or target" />
      </div>
      {msg && <div role="status" className="rounded-lg border border-sky-300 bg-sky-50 px-3 py-2 text-xs font-bold text-[#0a4a6e]">{msg}</div>}
      <Card title={<span className="inline-flex items-center gap-2"><Target className="h-4 w-4 text-[#855b00]" />Balanced scorecard</span>} sub="Targets are saved per entity; RAG: green meets target, amber within 10%, red worse" pad={false} action={<button type="button" disabled={readOnly || draft === null} onClick={() => void save()} className={btnPrimary}><Save className="h-3 w-3" />Save targets</button>}>
        <div className="overflow-x-auto"><table className="w-full min-w-[900px]">
          <thead><tr><th className={thCls}>Perspective</th><th className={thCls}>KPI</th><th className={cn(thCls, 'text-right')}>Actual</th><th className={cn(thCls, 'text-right')}>Target</th><th className={thCls}>Status</th><th className={thCls}>6-month trend</th><th className={thCls}>Definition</th></tr></thead>
          <tbody>{KPI_DEFS.map((k, i) => (
            <tr key={k.id} className={rowCls}>
              <td className={cn(tdCls, 'text-[10px] font-bold uppercase text-[#855b00]')}>{k.perspective}</td>
              <td className={cn(tdCls, 'font-semibold')}>{k.label}<span className="ml-1 text-[10px] text-[#355875]">({k.direction === 'higher' ? '↑ better' : '↓ better'})</span></td>
              <td className={cn(numCls, 'font-bold')}>{fmtK(kpis[k.id] ?? null, k.unit)}</td>
              <td className="px-1 py-1 text-right"><input aria-label={`Target for ${k.label}`} type="number" step="any" disabled={readOnly} value={targets[k.id] ?? 0} onChange={(e) => setDraft({ ...targets, [k.id]: Number(e.target.value) || 0 })} className={cn(inputCls, 'w-24 text-right font-mono')} /></td>
              <td className={tdCls}><span className="inline-flex items-center gap-1.5"><span className={cn('inline-block h-2.5 w-2.5 rounded-full', ragCls[rags[i]])} />{rags[i] === 'na' ? 'n/a' : rags[i]}</span></td>
              <td className={tdCls}><Sparkline label={k.label} values={history.map((h) => (h[k.id] ?? NaN) as number)} /></td>
              <td className={cn(tdCls, 'text-[10.5px] text-[#355875]')}>{k.formula}</td>
            </tr>
          ))}</tbody>
        </table></div>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function CashTab({ clientId, entityLines, accounts, months, forecast, today, readOnly, fyLabel, cur, periodicity }: { clientId: number; entityLines: ACDOCALine[]; accounts: AccountMaster[]; months: string[]; forecast: ReturnType<typeof rollingForecast>; today: string; readOnly: boolean; fyLabel: string; cur: string; periodicity: 'monthly' | 'quarterly' | 'annual' }) {
  const wb = useWorkbooks<CashPlanPayload>(clientId, 'cashflow_plan');
  const saved = wb.items.find((w) => w.key === fyLabel);
  const [draft, setDraft] = useState<CashPlanPayload | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const plan = draft ?? saved?.payload ?? { collectionLagMonths: 1, paymentLagMonths: 1, minimumCash: 0, items: [] };
  const base = useMemo(() => baseFromLedger(entityLines, accounts, clientId, today), [entityLines, accounts, clientId, today]);
  const byCode = new Map(accounts.map((a) => [a.accountNo, a]));
  const start = today.slice(0, 7);
  const horizon = Array.from({ length: 12 }, (_, i) => shiftMonth(start, i));
  const forecastView = aggregateRows(forecast, periodicity);
  const labels = bucketIndexes(periodicity, months.length).map((idxs, b) => bucketLabel(periodicity, months[idxs[0]], b, months.length)).filter(Boolean);
  const fyRev = labels.map((_, i) => sumArr(forecastView.filter((r) => r.type === 'Income').map((r) => r.months[i])));
  const fyExp = labels.map((_, i) => sumArr(forecastView.filter((r) => r.type === 'Expense').map((r) => r.months[i])));
  const fyDep = labels.map((_, i) => sumArr(forecastView.filter((r) => groupOf(byCode.get(r.accountNo), r.accountNo) === 'depreciation').map((r) => r.months[i])));
  const avg = (xs: number[]) => (xs.length ? sumArr(xs) / xs.length : 0);
  const pick = (arr: number[], m: string) => { const i = months.indexOf(m); return i >= 0 ? arr[i] : avg(arr); };
  const rows = cashForecast(horizon, horizon.map((m) => pick(fyRev, m)), horizon.map((m) => pick(fyExp, m)), horizon.map((m) => pick(fyDep, m)), base.cash, base.receivables, base.payables, plan);
  const lowest = rows.reduce((mn, r) => Math.min(mn, r.closing), Number.POSITIVE_INFINITY);
  const breaches = rows.filter((r) => r.belowMinimum);
  const setPlan = (patch: Partial<CashPlanPayload>) => setDraft({ ...plan, ...patch });
  const save = async () => {
    const res = await wb.save(fyLabel, `${fyLabel} cash-flow plan`, plan, saved?.version ?? 0);
    if (res.ok) setDraft(null);
    setMsg(res.ok ? 'Cash-flow plan saved.' : res.error ?? 'Save failed.');
  };
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Opening cash (ledger)" value={`${cur}${sgn(base.cash)}`} />
        <Stat label="Closing cash (12 months)" value={`${cur}${sgn(rows[rows.length - 1]?.closing ?? 0)}`} tone={(rows[rows.length - 1]?.closing ?? 0) < 0 ? 'text-rose-700' : 'text-emerald-700'} />
        <Stat label="Lowest projected balance" value={`${cur}${sgn(Number.isFinite(lowest) ? lowest : 0)}`} tone={lowest < plan.minimumCash ? 'text-rose-700' : undefined} />
        <Stat label="Months below minimum" value={breaches.length} tone={breaches.length ? 'text-rose-700' : 'text-emerald-700'} sub={breaches[0] ? `First: ${monthLabel(breaches[0].month)}` : 'Liquidity headroom maintained'} />
      </div>
      {msg && <div role="status" className="rounded-lg border border-sky-300 bg-sky-50 px-3 py-2 text-xs font-bold text-[#0a4a6e]">{msg}</div>}
      <div className="grid gap-4 xl:grid-cols-[20rem_1fr]">
        <Card title={<span className="inline-flex items-center gap-2"><Wallet className="h-4 w-4 text-[#855b00]" />Cash-flow assumptions</span>} action={<button type="button" disabled={readOnly || draft === null} onClick={() => void save()} className={btnPrimary}><Save className="h-3 w-3" />Save</button>}>
          <div className="space-y-2 text-xs">
            <label className="flex items-center justify-between font-semibold text-[#355875]">Collection lag (months)<input type="number" min={0} max={3} disabled={readOnly} value={plan.collectionLagMonths} onChange={(e) => setPlan({ collectionLagMonths: Number(e.target.value) || 0 })} className={cn(inputCls, 'w-20 text-right')} /></label>
            <label className="flex items-center justify-between font-semibold text-[#355875]">Payment lag (months)<input type="number" min={0} max={3} disabled={readOnly} value={plan.paymentLagMonths} onChange={(e) => setPlan({ paymentLagMonths: Number(e.target.value) || 0 })} className={cn(inputCls, 'w-20 text-right')} /></label>
            <label className="flex items-center justify-between font-semibold text-[#355875]">Minimum cash buffer<input type="number" min={0} disabled={readOnly} value={plan.minimumCash} onChange={(e) => setPlan({ minimumCash: Number(e.target.value) || 0 })} className={cn(inputCls, 'w-28 text-right')} /></label>
            <div className="pt-1 font-bold uppercase tracking-wider text-[#2d4f6d]">Other cash items (capex, loans, dividends, tax)</div>
            {plan.items.map((it, i) => (
              <div key={it.id} className="grid grid-cols-[1fr_5rem_6rem_auto] gap-1">
                <input aria-label="Item" disabled={readOnly} value={it.label} onChange={(e) => setPlan({ items: plan.items.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)) })} className={inputCls} />
                <select aria-label="Month" disabled={readOnly} value={it.month} onChange={(e) => setPlan({ items: plan.items.map((x, j) => (j === i ? { ...x, month: Number(e.target.value) } : x)) })} className={inputCls}>{horizon.map((m, k) => <option key={m} value={k}>{monthLabel(m)}</option>)}</select>
                <input aria-label="Amount (+ inflow / − outflow)" type="number" step="any" disabled={readOnly} value={it.amount} onChange={(e) => setPlan({ items: plan.items.map((x, j) => (j === i ? { ...x, amount: Number(e.target.value) || 0 } : x)) })} className={cn(inputCls, 'text-right')} />
                <button type="button" aria-label="Remove item" disabled={readOnly} onClick={() => setPlan({ items: plan.items.filter((_, j) => j !== i) })} className="rounded p-1 text-rose-700 hover:bg-rose-50"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            ))}
            <button type="button" disabled={readOnly} onClick={() => setPlan({ items: [...plan.items, { id: Math.random().toString(36).slice(2, 9), label: 'Capital expenditure', month: 0, amount: 0 }] })} className={btn}><Plus className="h-3 w-3" />Add item</button>
            <p className="text-[10.5px] text-[#355875]">Receipts and payments follow the rolling forecast (current method) with the lags above; depreciation is excluded as non-cash.</p>
          </div>
        </Card>
        <div className="space-y-4">
          <Card title={<span className="inline-flex items-center gap-2"><TrendingUp className="h-4 w-4 text-[#855b00]" />Projected closing cash</span>}><ComboChart title="Cash forecast" labels={periodicity === 'monthly' ? rows.map((r) => monthLabel(r.month)) : labels} series={[{ name: 'Net cash flow', values: aggregateSeries(rows.map((r) => r.net), periodicity), color: '#bcd7ee' }, { name: 'Closing cash', values: aggregateSeries(rows.map((r) => r.closing), periodicity), type: 'line', color: PALETTE.navy }, { name: 'Minimum buffer', values: aggregateSeries(rows.map(() => plan.minimumCash), periodicity), type: 'line', color: PALETTE.red, dashed: true }]} /></Card>
          <Card title="12-month cash-flow forecast (direct method)" pad={false}>
            <div className="overflow-x-auto"><table className="w-full min-w-[760px]">
              <thead><tr><th className={thCls}>Month</th><th className={cn(thCls, 'text-right')}>Opening</th><th className={cn(thCls, 'text-right')}>Receipts</th><th className={cn(thCls, 'text-right')}>Payments</th><th className={cn(thCls, 'text-right')}>Other</th><th className={cn(thCls, 'text-right')}>Net</th><th className={cn(thCls, 'text-right')}>Closing</th></tr></thead>
              <tbody>{rows.map((r) => (
                <tr key={r.month} className={cn(rowCls, r.belowMinimum && 'bg-rose-50/60')}><td className={tdCls}>{monthLabel(r.month)}{r.belowMinimum && <span className="ml-1 text-[9px] font-black text-rose-700">BELOW MIN</span>}</td><td className={numCls}>{sgn(r.opening)}</td><td className={numCls}>{sgn(r.receipts)}</td><td className={numCls}>{sgn(-r.payments)}</td><td className={numCls}>{sgn(r.other)}</td><td className={cn(numCls, r.net < 0 && 'text-rose-700')}>{sgn(r.net)}</td><td className={cn(numCls, 'font-bold', r.closing < 0 && 'text-rose-700')}>{sgn(r.closing)}</td></tr>
              ))}</tbody>
            </table></div>
          </Card>
        </div>
      </div>
    </div>
  );
}
