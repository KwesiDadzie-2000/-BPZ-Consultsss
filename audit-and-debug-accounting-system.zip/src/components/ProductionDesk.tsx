"use client";

import { useState } from "react";
import { AlertTriangle, ArrowRight, Factory, PackageCheck, ShieldCheck } from "lucide-react";
import type { AccountMaster, ClientEntity, StockItem, UserAccount } from "@/types/accounting";
import { useProduction } from "@/lib/productionClient";
import { finishedReceiptCost, plannedComponentQty, productionQty } from "@/lib/productionRules";
import { Alert, DeskTabs, EmptyState, Field, inputCls, useMoney } from "./DeskKit";
import { Badge, Card, PageHeader, Stat, numCls, rowCls, tdCls, thCls } from "./ui";

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  accounts: AccountMaster[];
  stockItems: StockItem[];
  onNavigate: (section: string) => void;
  onServerMutation: () => Promise<void>;
}

const isManager = (role: string) => role === 'owner' || role === 'partner' || role === 'manager';

/**
 * Production orders are server-authoritative. Stock, WIP, finished goods and
 * journal evidence commit together in /api/production; this UI never mutates
 * browser stock or creates a ledger posting on its own.
 */
export function ProductionDesk({ currentClient, currentUser, accounts, stockItems, onNavigate, onServerMutation }: Props) {
  const { fmt, today } = useMoney();
  const production = useProduction(currentClient.id, onServerMutation);
  const [tab, setTab] = useState('orders');
  const [notice, setNotice] = useState('');
  const [orderKey, setOrderKey] = useState(() => crypto.randomUUID());
  const [issueKey, setIssueKey] = useState(() => crypto.randomUUID());
  const [costKey, setCostKey] = useState(() => crypto.randomUUID());
  const [receiptKey, setReceiptKey] = useState(() => crypto.randomUUID());
  const [orderForm, setOrderForm] = useState({ itemCode: '', qty: '', startDate: today(), costCenter: 'CC-OPS' });
  const [issueForm, setIssueForm] = useState({ orderId: '', itemCode: '', qty: '', date: today() });
  const [costForm, setCostForm] = useState({ orderId: '', sourceDocNo: '', accountNo: '', amount: '', reason: '', date: today() });
  const [receiptForm, setReceiptForm] = useState({ orderId: '', qty: '', date: today() });

  const readOnly = currentUser.role === 'auditor' || currentUser.status !== 'active';
  const canPost = !readOnly && currentUser.permissions?.canPostJournals !== false && currentUser.makerLimit > 0;
  const canRelease = !readOnly && isManager(currentUser.role);
  const finished = stockItems.filter((i) => i.category.toLowerCase().includes('finished'));
  const open = production.orders.filter((o) => o.status === 'Released' || o.status === 'In Production');
  const inProgress = production.orders.filter((o) => o.status === 'In Production');
  const selectedIssueOrder = open.find((o) => o.id === issueForm.orderId);
  const issueBoms = production.boms.filter((b) => b.parentItemCode === selectedIssueOrder?.itemCode && b.active);
  const selectedBom = issueBoms.find((b) => b.componentItemCode === issueForm.itemCode);
  const used = production.issues.filter((i) => i.productionOrderId === issueForm.orderId && i.itemCode === issueForm.itemCode)
    .reduce((sum, i) => sum + i.qty, 0);
  const allowable = selectedBom && selectedIssueOrder
    ? productionQty(plannedComponentQty(selectedIssueOrder.qty, selectedBom.qtyPerUnit, selectedBom.wastePct) - used)
    : 0;
  const selectedReceipt = inProgress.find((o) => o.id === receiptForm.orderId);
  const produced = production.receipts.filter((r) => r.productionOrderId === receiptForm.orderId)
    .reduce((sum, r) => sum + r.qty, 0);
  const remaining = selectedReceipt ? productionQty(selectedReceipt.qty - produced) : 0;
  const wip = selectedReceipt ? production.wipByOrder[selectedReceipt.id] ?? 0 : 0;
  let previewCost: number | null = null;
  try {
    if (selectedReceipt && Number(receiptForm.qty) > 0) previewCost = finishedReceiptCost(wip, Number(receiptForm.qty), remaining);
  } catch { /* the server explains invalid receipts on submit */ }

  async function makeOrder() {
    const result = await production.run('create_order', { ...orderForm, qty: Number(orderForm.qty) }, orderKey);
    if (result.ok) {
      setNotice(`Draft ${result.order?.docNo ?? 'work order'} saved. A manager must release it before material issue.`);
      setOrderForm({ ...orderForm, itemCode: '', qty: '' });
      setOrderKey(crypto.randomUUID());
    }
  }
  async function release(orderId: string) {
    const result = await production.run('release_order', { orderId });
    if (result.ok) setNotice('Order released. Issue the approved BOM components to WIP.');
  }
  async function issue() {
    const result = await production.run('issue_material', { ...issueForm, qty: Number(issueForm.qty) }, issueKey);
    if (result.ok) {
      setNotice(`Material issue posted: ${result.docNo}. Stock, WIP and the journal are reconciled.`);
      setIssueForm({ ...issueForm, itemCode: '', qty: '' });
      setIssueKey(crypto.randomUUID());
    }
  }
  async function allocateConversion() {
    const result = await production.run('record_conversion', { ...costForm, amount: Number(costForm.amount) }, costKey);
    if (result.ok) {
      setNotice(`Direct labour/overhead reclassified to WIP: ${result.docNo}. No second expense or cash payment was created.`);
      setCostForm({ ...costForm, sourceDocNo: '', accountNo: '', amount: '', reason: '' });
      setCostKey(crypto.randomUUID());
    }
  }
  async function receive() {
    const result = await production.run('receive_output', { ...receiptForm, qty: Number(receiptForm.qty) }, receiptKey);
    if (result.ok) {
      setNotice(`Finished goods received: ${result.docNo}. The same item is now available in Sales & Invoicing.`);
      setReceiptForm({ ...receiptForm, orderId: '', qty: '' });
      setReceiptKey(crypto.randomUUID());
    }
  }
  async function close(orderId: string) {
    const result = await production.run('close_order', { orderId });
    if (result.ok) setNotice('Order closed after a zero-WIP reconciliation.');
  }

  return (
    <div className="space-y-4" data-desk="production_desk">
      <PageHeader kicker={`${currentClient.code} · Inventory-to-sales accounting`} title="Production Desk"
        desc="Materials → work in progress → finished goods → sales. Movements post atomically to the server with stock, balanced journals, period locks and maker limits; merely creating an order does not post inventory.">
        <button type="button" onClick={() => onNavigate('boms')} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-xs font-bold text-[#082f4f]">BOM →</button>
        <button type="button" onClick={() => onNavigate('inventory_ledger')} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-xs font-bold text-[#082f4f]">Stock ledger →</button>
        <button type="button" onClick={() => onNavigate('sales')} className="rounded-lg bg-[#082f4f] px-2.5 py-1.5 text-xs font-bold text-white">Sales →</button>
      </PageHeader>
      {production.error && <Alert>{production.error}</Alert>}
      {notice && <Alert tone="success">{notice}</Alert>}
      {production.legacyCount > 0 && <Alert tone="info"><AlertTriangle className="mr-1 inline h-3.5 w-3.5" />{production.legacyCount} legacy prototype production records remain in the database, but were not journal-backed. Do not include them in production valuation; reconcile them against source evidence before recreating orders here.</Alert>}
      {!canPost && <Alert tone="info">This account cannot post production: an active, non-auditor user with journal authority and a positive maker limit is required. Above-limit postings must be made by an independently authorised maker through the normal approval controls.</Alert>}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Open work orders" value={open.length} />
        <Stat label="WIP in ledger" value={`${currentClient.currency} ${fmt(Object.values(production.wipByOrder).reduce((n, v) => n + v, 0))}`} sub="Account 122000 · order referenced" />
        <Stat label="Issued material movements" value={production.issues.length} />
        <Stat label="Finished output receipts" value={production.receipts.length} />
      </div>
      <DeskTabs tabs={[{ id: 'orders', label: 'Work orders' }, { id: 'issues', label: 'Material issues' },
        { id: 'conversion', label: 'Labour & overhead' }, { id: 'outputs', label: 'Finished output' }, { id: 'wip', label: 'WIP reconciliation' }]}
      active={tab} onChange={setTab} />

      {tab === 'orders' && <div className="grid gap-4 xl:grid-cols-[350px_1fr]">
        <Card title="Authorise a production order" sub="Choose a finished item with a BOM; no inventory or cash posts at this stage.">
          <div className="space-y-3">
            <Field label="Finished item"><select value={orderForm.itemCode} onChange={(e) => setOrderForm({ ...orderForm, itemCode: e.target.value })} className={inputCls}>
              <option value="">Choose output…</option>{finished.map((item) => <option key={item.id} value={item.itemCode}>{item.itemCode} · {item.description}</option>)}
            </select></Field>
            <Field label="Planned output quantity"><input type="number" min="0.001" step="0.001" value={orderForm.qty} onChange={(e) => setOrderForm({ ...orderForm, qty: e.target.value })} className={inputCls} /></Field>
            <Field label="Start date"><input type="date" value={orderForm.startDate} onChange={(e) => setOrderForm({ ...orderForm, startDate: e.target.value })} className={inputCls} /></Field>
            <Field label="Site / cost centre"><input value={orderForm.costCenter} onChange={(e) => setOrderForm({ ...orderForm, costCenter: e.target.value })} className={inputCls} /></Field>
            <button type="button" onClick={() => void makeOrder()} disabled={readOnly || production.busy || production.loading || !orderForm.itemCode || !(Number(orderForm.qty) > 0)} className="w-full rounded-lg bg-[#082f4f] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">{production.busy ? 'Saving…' : 'Create draft order'}</button>
            <p className="text-[10.5px] text-[#355875]">A manager must release it. BOM changes are blocked while the released order is open.</p>
          </div>
        </Card>
        <Card title="Order register" sub="Controlled status: draft → released → in production → completed → closed.">
          {production.loading ? <p className="text-xs text-[#355875]">Loading work orders…</p> : production.orders.length === 0 ? <EmptyState title="No production orders" detail="First set up raw materials and a finished item in Inventory, then build its BOM." /> : (
            <div className="overflow-x-auto rounded-lg border border-sky-200"><table className="min-w-[740px] w-full">
              <thead><tr><th className={thCls}>Order</th><th className={thCls}>Output</th><th className={thCls}>Qty</th><th className={thCls}>WIP</th><th className={thCls}>Status</th><th className={thCls}>Action</th></tr></thead>
              <tbody>{production.orders.map((o) => <tr key={o.id} className={rowCls}>
                <td className={tdCls}><span className="font-mono font-bold">{o.docNo}</span><span className="block text-[10px] text-[#355875]">{o.costCenter}</span></td>
                <td className={tdCls}>{o.itemCode}<span className="block text-[10px] text-[#355875]">{o.itemDescription}</span></td>
                <td className={numCls}>{o.qty} {o.uom}</td>
                <td className={numCls}>{fmt(production.wipByOrder[o.id] ?? 0)}</td>
                <td className={tdCls}><Badge tone={o.status === 'Closed' ? 'green' : o.status === 'Completed' ? 'fi' : 'amber'}>{o.status}</Badge></td>
                <td className={tdCls}>{o.status === 'Draft' && <button type="button" disabled={!canRelease || production.busy} onClick={() => void release(o.id)} className="rounded border border-sky-300 bg-white px-2 py-1 text-[10.5px] font-bold text-[#082f4f] disabled:opacity-40">Release</button>}
                  {o.status === 'Completed' && <button type="button" disabled={!canRelease || production.busy} onClick={() => void close(o.id)} className="rounded border border-emerald-300 bg-emerald-50 px-2 py-1 text-[10.5px] font-bold text-emerald-800 disabled:opacity-40">Close (WIP = 0)</button>}</td>
              </tr>)}</tbody>
            </table></div>
          )}
        </Card>
      </div>}

      {tab === 'issues' && <div className="grid gap-4 lg:grid-cols-[340px_1fr]">
        <Card title="Issue approved materials" sub="Dr WIP 122000 / Cr item's stock control. Negative stock and unapproved BOM overruns are blocked.">
          <div className="space-y-3">
            <Field label="Released work order"><select className={inputCls} value={issueForm.orderId} onChange={(e) => setIssueForm({ ...issueForm, orderId: e.target.value, itemCode: '', qty: '' })}>
              <option value="">Choose order…</option>{open.map((o) => <option key={o.id} value={o.id}>{o.docNo} · {o.itemCode}</option>)}
            </select></Field>
            <Field label="BOM component"><select className={inputCls} value={issueForm.itemCode} onChange={(e) => setIssueForm({ ...issueForm, itemCode: e.target.value, qty: '' })}>
              <option value="">Choose material…</option>{issueBoms.map((b) => { const item = stockItems.find((i) => i.itemCode === b.componentItemCode); return <option key={b.id} value={b.componentItemCode}>{b.componentItemCode} · {item?.description ?? 'Missing item'}</option>; })}
            </select></Field>
            {selectedBom && <div className="rounded-lg border border-sky-200 bg-sky-50 p-2 text-[11px] text-[#355875]">Planned remaining: <strong>{allowable} {selectedBom.uom}</strong> · On hand: {stockItems.find((i) => i.itemCode === issueForm.itemCode)?.quantityOnHand ?? '—'}</div>}
            <Field label="Quantity"><input type="number" min="0.001" max={allowable || undefined} step="0.001" className={inputCls} value={issueForm.qty} onChange={(e) => setIssueForm({ ...issueForm, qty: e.target.value })} /></Field>
            <Field label="Posting date"><input type="date" className={inputCls} value={issueForm.date} onChange={(e) => setIssueForm({ ...issueForm, date: e.target.value })} /></Field>
            <button type="button" onClick={() => void issue()} disabled={!canPost || production.busy || !selectedBom || !(Number(issueForm.qty) > 0) || Number(issueForm.qty) > allowable} className="w-full rounded-lg bg-[#082f4f] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">Post material issue</button>
          </div>
        </Card>
        <Card title="Posted material issues" sub="Every line has a stock movement, balanced journal and order reference.">
          {production.issues.length === 0 ? <EmptyState title="No materials issued" detail="Release a work order first, then issue its BOM components." /> : <div className="overflow-x-auto"><table className="min-w-[680px] w-full"><thead><tr><th className={thCls}>Order</th><th className={thCls}>Material</th><th className={thCls}>Qty</th><th className={thCls}>Cost</th><th className={thCls}>Date</th></tr></thead><tbody>{production.issues.map((i) => { const o = production.orders.find((order) => order.id === i.productionOrderId); return <tr key={i.id} className={rowCls}><td className={tdCls}>{o?.docNo ?? '—'}</td><td className={tdCls}>{i.itemCode}</td><td className={numCls}>{i.qty} {i.uom}</td><td className={numCls}>{fmt(i.totalCost)}</td><td className={tdCls}>{i.issuedAt}</td></tr>; })}</tbody></table></div>}
        </Card>
      </div>}

      {tab === 'conversion' && <div className="grid gap-4 lg:grid-cols-[360px_1fr]">
        <Card title="Allocate actual direct labour / overhead" sub="Reclassify a previously posted qualifying expense into WIP. Does NOT create a new expense or cash payment.">
          <div className="space-y-3">
            <Field label="In-production work order"><select className={inputCls} value={costForm.orderId} onChange={(e) => setCostForm({ ...costForm, orderId: e.target.value })}><option value="">Choose order…</option>{inProgress.map((o) => <option key={o.id} value={o.id}>{o.docNo}</option>)}</select></Field>
            <Field label="Source journal / payroll document"><input className={inputCls} value={costForm.sourceDocNo} onChange={(e) => setCostForm({ ...costForm, sourceDocNo: e.target.value })} placeholder="EXPB-… or PAYROLL-…" /></Field>
            <Field label="Previously debited expense account"><select className={inputCls} value={costForm.accountNo} onChange={(e) => setCostForm({ ...costForm, accountNo: e.target.value })}><option value="">Choose expense…</option>{accounts.filter((a) => a.type === 'Expense' && a.active).map((a) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>)}</select></Field>
            <Field label={`Qualifying amount (${currentClient.currency})`}><input type="number" min="0.01" step="0.01" className={inputCls} value={costForm.amount} onChange={(e) => setCostForm({ ...costForm, amount: e.target.value })} /></Field>
            <Field label="Evidence / why capitalisable"><textarea rows={3} className={inputCls} value={costForm.reason} onChange={(e) => setCostForm({ ...costForm, reason: e.target.value })} placeholder="Direct labour on batch …; no idle/abnormal waste" /></Field>
            <Field label="Posting date"><input type="date" className={inputCls} value={costForm.date} onChange={(e) => setCostForm({ ...costForm, date: e.target.value })} /></Field>
            <button type="button" onClick={() => void allocateConversion()} disabled={!canPost || !canRelease || production.busy || !costForm.orderId || !costForm.sourceDocNo || !costForm.accountNo || !(Number(costForm.amount) > 0) || costForm.reason.trim().length < 12} className="w-full rounded-lg bg-[#082f4f] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">Post reviewed WIP allocation</button>
          </div>
        </Card>
        <Card title="Conversion cost policy" sub="IAS 2: qualifying direct labour and normal-capacity overhead only.">
          <div className="space-y-3 text-[11.5px] leading-relaxed text-[#355875]">
            <p>First record the actual, supported labour or overhead cost through Payroll, Expenses or a reviewed journal. Then enter its posted document number above. The server checks that document and prevents reallocating more than its unallocated cost.</p>
            <p><strong>Do not capitalise</strong> abnormal waste, idle capacity, selling expenses or unsupported estimates. The controller must document the cost basis; tax treatment is reviewed separately.</p>
            <button type="button" onClick={() => onNavigate('general_ledger')} className="rounded border border-sky-300 px-3 py-1.5 text-xs font-bold text-[#082f4f]">Inspect source journal →</button>
          </div>
        </Card>
      </div>}

      {tab === 'outputs' && <div className="grid gap-4 lg:grid-cols-[350px_1fr]">
        <Card title="Receive finished output" sub="Dr Finished Goods 121000 / Cr WIP 122000. Available WIP is allocated by remaining output units; the last receipt clears the balance.">
          <div className="space-y-3">
            <Field label="In-production work order"><select className={inputCls} value={receiptForm.orderId} onChange={(e) => setReceiptForm({ ...receiptForm, orderId: e.target.value, qty: '' })}><option value="">Choose order…</option>{inProgress.map((o) => <option key={o.id} value={o.id}>{o.docNo} · {o.itemCode}</option>)}</select></Field>
            {selectedReceipt && <div className="rounded-lg border border-sky-200 bg-sky-50 p-2 text-[11px] text-[#355875]">Remaining output: <strong>{remaining} {selectedReceipt.uom}</strong> · Available WIP: {currentClient.currency} {fmt(wip)}</div>}
            <Field label="Good units accepted by quality"><input type="number" min="0.001" max={remaining || undefined} step="0.001" className={inputCls} value={receiptForm.qty} onChange={(e) => setReceiptForm({ ...receiptForm, qty: e.target.value })} /></Field>
            {previewCost !== null && <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-2 text-[11px] font-bold text-emerald-900">Projected receipt value: {currentClient.currency} {fmt(previewCost)} (ledger WIP).</div>}
            <Field label="Posting date"><input type="date" className={inputCls} value={receiptForm.date} onChange={(e) => setReceiptForm({ ...receiptForm, date: e.target.value })} /></Field>
            <button type="button" onClick={() => void receive()} disabled={!canPost || production.busy || !selectedReceipt || !(Number(receiptForm.qty) > 0) || Number(receiptForm.qty) > remaining || !(wip > 0)} className="w-full rounded-lg bg-[#087a55] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">Post finished-goods receipt</button>
          </div>
        </Card>
        <Card title="Accepted output register" sub="The item enters Inventory and can be invoiced through Sales; COGS uses its FG control account.">
          {production.receipts.length === 0 ? <EmptyState title="No output received" detail="Issue materials into WIP, then receive quality-approved finished goods." /> : <div className="overflow-x-auto"><table className="min-w-[650px] w-full"><thead><tr><th className={thCls}>Order</th><th className={thCls}>Item</th><th className={thCls}>Qty</th><th className={thCls}>Value</th><th className={thCls}>Date</th></tr></thead><tbody>{production.receipts.map((r) => { const o = production.orders.find((order) => order.id === r.productionOrderId); return <tr key={r.id} className={rowCls}><td className={tdCls}>{o?.docNo ?? '—'}</td><td className={tdCls}>{r.itemCode}</td><td className={numCls}>{r.qty} {r.uom}</td><td className={numCls}>{fmt(r.totalCost)}</td><td className={tdCls}>{r.receivedAt}</td></tr>; })}</tbody></table></div>}
        </Card>
      </div>}

      {tab === 'wip' && <Card title="WIP by work order" sub="Costed from posted GL account 122000 by order reference, not from editable order totals. An order cannot close until WIP is zero.">
        {production.orders.length === 0 ? <EmptyState title="No WIP yet" detail="Create a BOM, release a work order and post material issues to build WIP." /> : <div className="overflow-x-auto rounded-lg border border-sky-200"><table className="min-w-[760px] w-full"><thead><tr><th className={thCls}>Order</th><th className={thCls}>Material cost</th><th className={thCls}>Conversion allocated</th><th className={thCls}>FG received</th><th className={thCls}>GL WIP</th><th className={thCls}>Status</th></tr></thead><tbody>{production.orders.map((o) => { const received = production.receipts.filter((r) => r.productionOrderId === o.id).reduce((n, r) => n + r.totalCost, 0); const balance = production.wipByOrder[o.id] ?? 0; const difference = Math.round((o.totalMaterialCost + o.totalConversionCost - received - balance) * 100) / 100; return <tr key={o.id} className={rowCls}><td className={tdCls}><span className="font-mono font-bold">{o.docNo}</span></td><td className={numCls}>{fmt(o.totalMaterialCost)}</td><td className={numCls}>{fmt(o.totalConversionCost)}</td><td className={numCls}>{fmt(received)}</td><td className={numCls}><span className={balance < -0.009 ? 'font-bold text-rose-700' : ''}>{fmt(balance)}</span>{Math.abs(difference) > 0.009 && <span className="block text-[10px] font-bold text-rose-700">{fmt(difference)} unreconciled</span>}</td><td className={tdCls}><Badge tone={o.status === 'Closed' ? 'green' : 'amber'}>{o.status}</Badge></td></tr>; })}</tbody></table></div>}
        <p className="mt-3 text-[10.5px] text-[#355875]">The balance should agree to cost captured less finished output received. Differences need review, not a plug journal.</p>
      </Card>}
    </div>
  );
}
