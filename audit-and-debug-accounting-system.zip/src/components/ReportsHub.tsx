"use client";

import { useMemo, useState } from "react";
import { BarChart3, Boxes, FileSpreadsheet, Printer, ShoppingCart, Store, Users } from "lucide-react";
import type { ACDOCALine, AccountMaster, BusinessPartner, ClientEntity, EmployeeProfile, PurchaseOrder, SalesInvoice, StockItem, StockMovement, UserAccount } from "../types/accounting";
import { maySeeSection } from "../utils/access";
import { AgeingAnalysisDesk } from "./AgeingAnalysisDesk";
import { Badge, Card, PageHeader, Stat, formatGHS, numCls, rowCls, tdCls, thCls } from "./ui";
import { DeskTabs, downloadCsv, EmptyState, useMoney } from "./DeskKit";
import { useProduction } from "@/lib/productionClient";
import { productionMoney } from "@/lib/productionRules";
import { printModuleView } from "@/utils/printModuleView";
import { downloadExcel } from "@/utils/excelExport";

interface Props {
  currentClient: ClientEntity;
  currentUser?: UserAccount;
  invoices: SalesInvoice[];
  orders: PurchaseOrder[];
  partners: BusinessPartner[];
  stockItems: StockItem[];
  stockMovements: StockMovement[];
  employees: EmployeeProfile[];
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  onNavigate?: (section: string) => void;
}

const ALL_TABS = [
  { id: "sales", sectionId: "report_sales_r", label: "Sales reports" },
  { id: "purchases", sectionId: "report_purchases_r", label: "Purchases reports" },
  { id: "inventory", sectionId: "report_inventory_r", label: "Inventory reports" },
  { id: "clients", sectionId: "report_clients_r", label: "Clients reports" },
  { id: "store", sectionId: "report_store_r", label: "Store reports" },
  { id: "hr", sectionId: "report_hr_r", label: "HR & payroll reports" },
  { id: "ageing", sectionId: "report_ageing_r", label: "Ageing analysis (AR & AP)" },
  { id: "production", sectionId: "report_production_r", label: "Production & WIP" },
  { id: "financial", sectionId: "report_financial_r", label: "Financial reports" },
];

export function ReportsHub({ currentClient, currentUser, invoices, orders, partners, stockItems, stockMovements, employees, lines, accounts, onNavigate, initialTab = "sales" }: Props & { initialTab?: string }) {
  const visibleTabs = useMemo(
    () => ALL_TABS.filter((t) => !currentUser || maySeeSection(currentUser, currentClient, t.sectionId)),
    [currentUser, currentClient]
  );
  const [selectedTab, setTab] = useState(initialTab);
  const tab = visibleTabs.some((t) => t.id === selectedTab) ? selectedTab : (visibleTabs[0]?.id ?? "sales");
  const { fmt, today } = useMoney();
  const totals = useMemo(() => {
    const sales = invoices.reduce((s, i) => s + i.totalReceivable, 0);
    const paid = invoices.reduce((s, i) => s + i.paidAmount, 0);
    const purchases = orders.reduce((s, o) => s + o.totalAmount, 0);
    const purchasePaid = orders.reduce((s, o) => s + (o.paidAmount ?? 0), 0);
    const stockValue = stockItems.reduce((s, i) => s + i.totalValue, 0);
    const low = stockItems.filter((s) => (s.reorderLevel ?? 0) > 0 && s.quantityOnHand <= (s.reorderLevel ?? 0));
    const payroll = employees.reduce((s, e) => s + e.basicSalary + e.allowances, 0);
    return { sales, paid, purchases, purchasePaid, stockValue, low, payroll };
  }, [invoices, orders, stockItems, employees]);

  const print = () => printModuleView({ title: `Reports Centre — ${tab}`, subtitle: currentClient.name, root: document.getElementById("report-active-content"), orientation: "landscape" });

  return (
    <div>
      <PageHeader
        kicker={`${currentClient.code} · Management reporting`}
        title="Reports Centre"
        desc="Every report in one place, driven directly from the ledger and the operational desks. Print the working paper, or export a formula-safe CSV for Excel."
      >
        <Badge tone="slate">{today()}</Badge>
        <button onClick={print} className="inline-flex items-center gap-1 rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f]"><Printer className="h-3.5 w-3.5" /> Print</button>
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-5">
        {visibleTabs.some((t) => t.id === "sales") && (
          <>
            <Stat label="Sales invoiced" value={`GH₵ ${fmt(totals.sales)}`} sub={`${invoices.length} invoices`} />
            <Stat label="Collections" value={`GH₵ ${fmt(totals.paid)}`} sub={`GH₵ ${fmt(totals.sales - totals.paid)} outstanding`} />
          </>
        )}
        {visibleTabs.some((t) => t.id === "purchases") && (
          <Stat label="Purchases" value={`GH₵ ${fmt(totals.purchases)}`} sub={`${orders.length} orders`} />
        )}
        {visibleTabs.some((t) => t.id === "inventory") && (
          <Stat label="Inventory value" value={`GH₵ ${fmt(totals.stockValue)}`} sub={`${stockItems.length} items`} />
        )}
        {visibleTabs.some((t) => t.id === "hr") && (
          <Stat label="Monthly payroll" value={`GH₵ ${fmt(totals.payroll)}`} sub={`${employees.length} employees`} />
        )}
      </div>

      <DeskTabs tabs={visibleTabs} active={tab} onChange={setTab} />

      <div id="report-active-content">
      {tab === "sales" && <SalesReport invoices={invoices} />}
      {tab === "purchases" && <PurchasesReport orders={orders} />}
      {tab === "inventory" && <InventoryReport stockItems={stockItems} movements={stockMovements} />}
      {tab === "clients" && <ClientsReport invoices={invoices} partners={partners} />}
      {tab === "store" && <StoreReport stockItems={stockItems} movements={stockMovements} />}
      {tab === "hr" && <HrReport employees={employees} />}
      {tab === "production" && <ProductionReport currentClient={currentClient} />}
      {tab === "ageing" && <AgeingAnalysisDesk currentClient={currentClient} invoices={invoices} orders={orders} lines={lines} onNavigate={onNavigate} />}
      {tab === "financial" && <FinancialReport lines={lines} accounts={accounts} />}
      </div>
    </div>
  );
}

function ReportShell({ title, sub, filename, rows, children }: { title: string; sub: string; filename: string; rows: (string | number)[][]; children: React.ReactNode }) {
  return (
    <Card
      title={title}
      sub={sub}
      action={<div className="flex flex-wrap gap-2"><button onClick={() => void downloadExcel(filename.replace(/\.csv$/, '.xlsx'), [{ name: title, columns: (rows[0] || []).map(String), rows: rows.slice(1), moneyColumns: (rows[0] || []).map((h,i) => /net|vat|total|paid|balance|value|cost|revenue|amount|debit|credit/i.test(String(h)) ? i : -1).filter((i) => i >= 0) }]).catch(() => window.alert('Excel export failed. Please retry.'))} className="inline-flex items-center gap-1 rounded-lg border border-emerald-300 bg-emerald-50 px-2.5 py-1.5 text-[11px] font-bold text-emerald-800"><FileSpreadsheet className="h-3.5 w-3.5" />Excel (.xlsx)</button><button onClick={() => downloadCsv(filename, rows)} className="inline-flex items-center gap-1 rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f]">CSV</button><button type="button" onClick={(e) => { const root = (e.currentTarget.closest('section') as HTMLElement | null); printModuleView({ title, subtitle: sub, root, orientation: 'landscape' }); }} className="rounded-lg border border-sky-300 px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f]">Print this report</button></div>}
    >
      {children}
    </Card>
  );
}

function SalesReport({ invoices }: { invoices: SalesInvoice[] }) {
  const { fmt } = useMoney();
  const byCustomer = new Map<string, { invoiced: number; paid: number; count: number }>();
  const byStream = new Map<string, number>();
  const byMonth = new Map<string, number>();
  invoices.forEach((i) => {
    const c = byCustomer.get(i.customerName) ?? { invoiced: 0, paid: 0, count: 0 };
    byCustomer.set(i.customerName, { invoiced: c.invoiced + i.totalReceivable, paid: c.paid + i.paidAmount, count: c.count + 1 });
    byStream.set(i.revenueStream, (byStream.get(i.revenueStream) ?? 0) + i.netRevenue);
    const month = i.date.slice(0, 7);
    byMonth.set(month, (byMonth.get(month) ?? 0) + i.totalReceivable);
  });
  const customers = [...byCustomer.entries()].sort((a, b) => b[1].invoiced - a[1].invoiced);
  return (
    <div className="space-y-4">
      <ReportShell title="Sales register" sub="Every sales invoice with revenue, tax and settlement status" filename="sales-register.csv"
        rows={[["Invoice", "Date", "Customer", "Stream", "Net revenue", "VAT", "Total", "Paid", "Balance", "Status"], ...invoices.map((i) => [i.invNo, i.date, i.customerName, i.revenueStream, i.netRevenue, i.vatOutput, i.totalReceivable, i.paidAmount, i.totalReceivable - i.paidAmount, i.status])]}>
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[820px] border-collapse">
            <thead><tr><th className={thCls}>Invoice</th><th className={thCls}>Date</th><th className={thCls}>Customer</th><th className={thCls}>Stream</th><th className={thCls}>Net</th><th className={thCls}>VAT</th><th className={thCls}>Total</th><th className={thCls}>Balance</th><th className={thCls}>Status</th></tr></thead>
            <tbody>{invoices.map((i) => (
              <tr key={i.id} className={rowCls}><td className={tdCls}>{i.invNo}</td><td className={tdCls}>{i.date}</td><td className={tdCls}>{i.customerName}</td><td className={tdCls}>{i.revenueStream}</td><td className={numCls}>{fmt(i.netRevenue)}</td><td className={numCls}>{fmt(i.vatOutput)}</td><td className={numCls}>{fmt(i.totalReceivable)}</td><td className={numCls}>{fmt(i.totalReceivable - i.paidAmount)}</td><td className={tdCls}><Badge tone={i.status === "Paid" ? "green" : i.paidAmount > 0 ? "amber" : "slate"}>{i.status}</Badge></td></tr>
            ))}</tbody>
          </table>
        </div>
      </ReportShell>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Revenue by customer" sub="Ranked by total invoiced value">
          <BarRows data={customers.map(([name, v]) => ({ label: name, value: v.invoiced }))} />
        </Card>
        <Card title="Revenue by stream & month" sub="IFRS 15 revenue disaggregation support">
          <BarRows data={[...byStream.entries()].map(([label, value]) => ({ label, value }))} />
          <div className="mt-3 border-t border-sky-100 pt-2">{[...byMonth.entries()].sort().map(([m, v]) => <div key={m} className="flex justify-between py-0.5 text-[11px]"><span className="font-mono text-[#355875]">{m}</span><span className="font-mono font-bold text-[#082f4f]">GH₵ {fmt(v)}</span></div>)}</div>
        </Card>
      </div>
    </div>
  );
}

function BarRows({ data }: { data: { label: string; value: number }[] }) {
  const { fmt } = useMoney();
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <div className="space-y-1.5">
      {data.length === 0 && <p className="text-[11px] text-[#355875]">No data.</p>}
      {data.slice(0, 12).map((d) => (
        <div key={d.label}>
          <div className="flex justify-between text-[11px]"><span className="truncate font-semibold text-[#163653]">{d.label}</span><span className="ml-2 shrink-0 font-mono font-bold text-[#082f4f]">{fmt(d.value)}</span></div>
          <div className="mt-0.5 h-1.5 rounded bg-sky-100"><div className="h-1.5 rounded bg-[#315f91]" style={{ width: `${Math.max((d.value / max) * 100, 2)}%` }} /></div>
        </div>
      ))}
    </div>
  );
}

function PurchasesReport({ orders }: { orders: PurchaseOrder[] }) {
  const { fmt } = useMoney();
  const byVendor = new Map<string, number>();
  orders.forEach((o) => byVendor.set(o.vendorName, (byVendor.get(o.vendorName) ?? 0) + o.totalAmount));
  return (
    <div className="space-y-4">
      <ReportShell title="Purchase register" sub="Purchase orders, payments and open commitments by supplier" filename="purchase-register.csv"
        rows={[["PO", "Date", "Supplier", "Item", "Qty", "Unit price", "VAT", "Total", "Paid", "Status"], ...orders.map((o) => [o.poNo, o.date, o.vendorName, o.itemDescription, o.qty, o.unitPrice, o.vatRecoverable, o.totalAmount, o.paidAmount ?? 0, o.status])]}>
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[780px] border-collapse">
            <thead><tr><th className={thCls}>PO</th><th className={thCls}>Supplier</th><th className={thCls}>Item</th><th className={thCls}>Qty</th><th className={thCls}>Total</th><th className={thCls}>Paid</th><th className={thCls}>Balance</th><th className={thCls}>Status</th></tr></thead>
            <tbody>{orders.map((o) => (
              <tr key={o.id} className={rowCls}><td className={tdCls}><div className="font-semibold">{o.poNo}</div><div className="text-[10px] text-[#355875]">{o.date}</div></td><td className={tdCls}>{o.vendorName}</td><td className={tdCls}>{o.itemDescription}</td><td className={numCls}>{o.qty}</td><td className={numCls}>{fmt(o.totalAmount)}</td><td className={numCls}>{fmt(o.paidAmount ?? 0)}</td><td className={numCls}>{fmt(o.totalAmount - (o.paidAmount ?? 0))}</td><td className={tdCls}><Badge tone={o.status === "Paid" ? "green" : o.status === "Invoiced" ? "amber" : "slate"}>{o.status}</Badge></td></tr>
            ))}</tbody>
          </table>
        </div>
      </ReportShell>
      <Card title="Spend by supplier" sub="Concentration and negotiation insight">
        <BarRows data={[...byVendor.entries()].sort((a, b) => b[1] - a[1]).map(([label, value]) => ({ label, value }))} />
      </Card>
    </div>
  );
}

function InventoryReport({ stockItems, movements }: { stockItems: StockItem[]; movements: StockMovement[] }) {
  const { fmt } = useMoney();
  const byCategory = new Map<string, number>();
  stockItems.forEach((s) => byCategory.set(s.category, (byCategory.get(s.category) ?? 0) + s.totalValue));
  const byType = new Map<string, number>();
  movements.forEach((m) => byType.set(m.type, (byType.get(m.type) ?? 0) + 1));
  return (
    <div className="space-y-4">
      <ReportShell title="Inventory valuation" sub="Lower of cost and net realisable value by product (IAS 2)" filename="inventory-valuation.csv"
        rows={[["Code", "Description", "Category", "UoM", "On hand", "Unit cost", "Total value", "NRV", "Reorder level"], ...stockItems.map((s) => [s.itemCode, s.description, s.category, s.uom, s.quantityOnHand, s.unitCost, s.totalValue, s.netRealisableValue ?? "", s.reorderLevel ?? 0])]}>
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[720px] border-collapse">
            <thead><tr><th className={thCls}>Code</th><th className={thCls}>Description</th><th className={thCls}>Category</th><th className={thCls}>On hand</th><th className={thCls}>Unit cost</th><th className={thCls}>Value</th><th className={thCls}>Reorder level</th><th className={thCls}>Status</th></tr></thead>
            <tbody>{stockItems.map((s) => {
              const low = (s.reorderLevel ?? 0) > 0 && s.quantityOnHand <= (s.reorderLevel ?? 0);
              return <tr key={s.id} className={rowCls}><td className={tdCls}>{s.itemCode}</td><td className={tdCls}>{s.description}</td><td className={tdCls}>{s.category}</td><td className={numCls}>{s.quantityOnHand} {s.uom}</td><td className={numCls}>{fmt(s.unitCost)}</td><td className={numCls}>{fmt(s.totalValue)}</td><td className={numCls}>{s.reorderLevel ?? 0}</td><td className={tdCls}><Badge tone={low ? "red" : "green"}>{low ? "Reorder" : "Healthy"}</Badge></td></tr>;
            })}</tbody>
          </table>
        </div>
      </ReportShell>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Stock value by category"><BarRows data={[...byCategory.entries()].map(([label, value]) => ({ label, value }))} /></Card>
        <Card title="Movements by type" sub={`${movements.length} movements in the ledger`}>
          <BarRows data={[...byType.entries()].map(([label, value]) => ({ label, value }))} />
        </Card>
      </div>
    </div>
  );
}

function ClientsReport({ invoices, partners }: { invoices: SalesInvoice[]; partners: BusinessPartner[] }) {
  const { fmt } = useMoney();
  const map = new Map<string, { billed: number; paid: number; count: number; last: string }>();
  invoices.forEach((i) => {
    const c = map.get(i.customerName) ?? { billed: 0, paid: 0, count: 0, last: "" };
    map.set(i.customerName, { billed: c.billed + i.totalReceivable, paid: c.paid + i.paidAmount, count: c.count + 1, last: !c.last || i.date > c.last ? i.date : c.last });
  });
  partners.filter((p) => p.type === "Customer").forEach((p) => { if (!map.has(p.name)) map.set(p.name, { billed: 0, paid: 0, count: 0, last: "" }); });
  const rows = [...map.entries()].sort((a, b) => b[1].billed - a[1].billed);
  const total = rows.reduce((s, [, v]) => s + v.billed, 0);
  return (
    <ReportShell title="Client statement & profitability" sub="Billed value, collection performance and share of revenue by client" filename="clients-report.csv"
      rows={[["Client", "Invoices", "Billed", "Settled", "Outstanding", "Share %", "Last invoice"], ...rows.map(([name, v]) => [name, v.count, v.billed, v.paid, v.billed - v.paid, total ? (v.billed / total) * 100 : 0, v.last])]}>
      <div className="overflow-x-auto rounded-lg border border-sky-200">
        <table className="w-full min-w-[720px] border-collapse">
          <thead><tr><th className={thCls}>Client</th><th className={thCls}>Invoices</th><th className={thCls}>Billed</th><th className={thCls}>Settled</th><th className={thCls}>Outstanding</th><th className={thCls}>Share</th><th className={thCls}>Last invoice</th></tr></thead>
          <tbody>{rows.map(([name, v]) => (
            <tr key={name} className={rowCls}><td className={tdCls}><div className="font-bold text-[#082f4f]">{name}</div></td><td className={numCls}>{v.count}</td><td className={numCls}>{fmt(v.billed)}</td><td className={numCls}>{fmt(v.paid)}</td><td className={numCls}><span className={v.billed - v.paid > 0 ? "text-rose-700" : "text-emerald-700"}>{fmt(v.billed - v.paid)}</span></td><td className={numCls}>{total ? ((v.billed / total) * 100).toFixed(1) : "0.0"}%</td><td className={tdCls}>{v.last || "—"}</td></tr>
          ))}</tbody>
        </table>
      </div>
    </ReportShell>
  );
}

function StoreReport({ stockItems, movements }: { stockItems: StockItem[]; movements: StockMovement[] }) {
  const { fmt } = useMoney();
  const warehouses = new Map<string, { items: number; value: number }>();
  stockItems.forEach((s) => {
    const key = s.location || "Main store";
    const w = warehouses.get(key) ?? { items: 0, value: 0 };
    warehouses.set(key, { items: w.items + 1, value: w.value + s.totalValue });
  });
  const lastMovement = [...movements].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 10);
  return (
    <div className="space-y-4">
      <Card title="Store position" sub="Value and item count by physical location">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">{[...warehouses.entries()].map(([name, v]) => (
          <div key={name} className="rounded-xl border border-sky-200 bg-sky-50/50 p-3"><div className="flex items-center gap-1.5 text-[11px] font-black uppercase text-[#355875]"><Store className="h-3.5 w-3.5" />{name}</div><div className="mt-1 font-mono text-lg font-bold text-[#082f4f]">GH₵ {fmt(v.value)}</div><div className="text-[11px] text-[#355875]">{v.items} product lines</div></div>
        ))}</div>
      </Card>
      <ReportShell title="Recent stock movements" sub="Last ten receipts, issues and adjustments" filename="store-movements.csv"
        rows={[["Date", "Item", "Type", "Qty", "Unit cost", "Value", "Reference"], ...lastMovement.map((m) => [m.date, m.description, m.type, m.quantity, m.unitCost, m.totalValue, m.reference ?? ""])]}>
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[600px] border-collapse">
            <thead><tr><th className={thCls}>Date</th><th className={thCls}>Item</th><th className={thCls}>Type</th><th className={thCls}>Qty</th><th className={thCls}>Value</th><th className={thCls}>Reference</th></tr></thead>
            <tbody>{lastMovement.map((m) => <tr key={m.id} className={rowCls}><td className={tdCls}>{m.date}</td><td className={tdCls}>{m.description}</td><td className={tdCls}><Badge tone="gold">{m.type}</Badge></td><td className={numCls}>{m.quantity}</td><td className={numCls}>{fmt(m.totalValue)}</td><td className={tdCls}>{m.reference ?? "—"}</td></tr>)}</tbody>
          </table>
        </div>
      </ReportShell>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Highest-value products"><BarRows data={[...stockItems].sort((a, b) => b.totalValue - a.totalValue).slice(0, 10).map((s) => ({ label: s.description, value: s.totalValue }))} /></Card>
        <Card title="Dead stock watch" sub="Items with no movement recorded">
          <ul className="space-y-1 text-[11.5px]">{stockItems.filter((s) => !movements.some((m) => m.itemCode === s.itemCode)).slice(0, 10).map((s) => <li key={s.id} className="flex justify-between border-b border-sky-100 py-1"><span>{s.description}</span><span className="font-mono text-[#355875]">{s.quantityOnHand} {s.uom}</span></li>)}{stockItems.every((s) => movements.some((m) => m.itemCode === s.itemCode)) && <li className="text-[#355875]">All stocked items have moved.</li>}</ul>
        </Card>
      </div>
    </div>
  );
}

function HrReport({ employees }: { employees: EmployeeProfile[] }) {
  const { fmt } = useMoney();
  const byDept = new Map<string, { count: number; cost: number }>();
  employees.forEach((e) => {
    const d = byDept.get(e.department) ?? { count: 0, cost: 0 };
    byDept.set(e.department, { count: d.count + 1, cost: d.cost + e.basicSalary + e.allowances });
  });
  const gross = employees.reduce((s, e) => s + e.basicSalary + e.allowances, 0);
  return (
    <div className="space-y-4">
      <ReportShell title="Employee cost analysis" sub="Headcount and gross pay by department" filename="hr-report.csv"
        rows={[["BP No", "Name", "Role", "Department", "Cost centre", "Basic", "Allowances", "Gross", "Status"], ...employees.map((e) => [e.bpNo, e.name, e.role, e.department, e.costCenter ?? "", e.basicSalary, e.allowances, e.basicSalary + e.allowances, e.status])]}>
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[620px] border-collapse">
            <thead><tr><th className={thCls}>Department</th><th className={thCls}>Headcount</th><th className={thCls}>Gross monthly cost</th><th className={thCls}>Average</th></tr></thead>
            <tbody>{[...byDept.entries()].sort((a, b) => b[1].cost - a[1].cost).map(([dept, v]) => (
              <tr key={dept} className={rowCls}><td className={tdCls}>{dept}</td><td className={numCls}>{v.count}</td><td className={numCls}>{fmt(v.cost)}</td><td className={numCls}>{fmt(v.cost / Math.max(v.count, 1))}</td></tr>
            ))}</tbody>
          </table>
        </div>
      </ReportShell>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Payroll cost by department"><BarRows data={[...byDept.entries()].map(([label, v]) => ({ label, value: v.cost }))} /></Card>
        <Card title="Payroll summary">
          <div className="space-y-1.5 text-xs">{[["Total employees", `${employees.length}`], ["Active", `${employees.filter((e) => e.status === "active").length}`], ["Monthly gross", `GH₵ ${fmt(gross)}`], ["Annualised gross", `GH₵ ${fmt(gross * 12)}`], ["Average gross", `GH₵ ${fmt(gross / Math.max(employees.length, 1))}`]].map(([k, v]) => <div key={k} className="flex justify-between border-b border-sky-100 py-1"><span className="text-[#355875]">{k}</span><span className="font-mono font-bold text-[#082f4f]">{v}</span></div>)}</div>
        </Card>
      </div>
    </div>
  );
}

function FinancialReport({ lines, accounts }: { lines: ACDOCALine[]; accounts: AccountMaster[] }) {
  const { fmt } = useMoney();
  const map = new Map<string, { name: string; type: string; debit: number; credit: number }>();
  lines.forEach((l) => {
    const account = accounts.find((a) => a.accountNo === l.accountNo);
    const row = map.get(l.accountNo) ?? { name: l.accountName || account?.name || l.accountNo, type: account?.type ?? "Unclassified", debit: 0, credit: 0 };
    map.set(l.accountNo, { ...row, debit: row.debit + l.debit, credit: row.credit + l.credit });
  });
  const rows = [...map.entries()].map(([no, v]) => ({ no, ...v })).sort((a, b) => a.no.localeCompare(b.no));
  const typeTotal = (predicate: (type: string) => boolean) => rows.filter((r) => predicate(r.type.toLowerCase())).reduce((s, r) => s + (r.debit - r.credit), 0);
  const assets = typeTotal((t) => t.includes("asset"));
  const liabilities = typeTotal((t) => t.includes("liabilit"));
  const equity = typeTotal((t) => t.includes("equity"));
  const revenue = typeTotal((t) => t.includes("revenue") || t.includes("income"));
  const expenses = typeTotal((t) => t.includes("expense") || t.includes("cost"));
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label="Total assets" value={`GH₵ ${fmt(assets)}`} />
        <Stat label="Liabilities" value={`GH₵ ${fmt(Math.abs(liabilities))}`} />
        <Stat label="Equity" value={`GH₵ ${fmt(Math.abs(equity))}`} />
        <Stat label="Revenue" value={`GH₵ ${fmt(Math.abs(revenue))}`} />
        <Stat label="Expenses" value={`GH₵ ${fmt(expenses)}`} />
      </div>
      <ReportShell title="Trial balance" sub="All posted journals by account, net of reversals" filename="trial-balance.csv"
        rows={[["Account", "Name", "Type", "Debit", "Credit", "Net"], ...rows.map((r) => [r.no, r.name, r.type, r.debit, r.credit, r.debit - r.credit])]}>
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[620px] border-collapse">
            <thead><tr><th className={thCls}>Account</th><th className={thCls}>Name</th><th className={thCls}>Type</th><th className={thCls}>Debit</th><th className={thCls}>Credit</th><th className={thCls}>Net</th></tr></thead>
            <tbody>{rows.map((r) => (
              <tr key={r.no} className={rowCls}><td className={tdCls}>{r.no}</td><td className={tdCls}>{r.name}</td><td className={tdCls}><Badge tone="fi">{r.type}</Badge></td><td className={numCls}>{fmt(r.debit)}</td><td className={numCls}>{fmt(r.credit)}</td><td className={numCls}>{fmt(r.debit - r.credit)}</td></tr>
            ))}</tbody>
          </table>
        </div>
      </ReportShell>
      <Card title="Report links" sub="Drill into the statutory statements or a specific operational report">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4 text-[11.5px] font-semibold text-[#163653]">
          {[{ icon: BarChart3, label: "Sales analysis", hint: "Register, revenue streams and monthly trend" }, { icon: ShoppingCart, label: "Purchase analysis", hint: "Supplier spend and open commitments" }, { icon: Boxes, label: "Inventory valuation", hint: "IAS 2 cost / NRV and reorder status" }, { icon: Users, label: "Client profitability", hint: "Revenue share, collections and ageing" }].map(({ icon: Icon, label, hint }) => (
            <div key={label} className="rounded-lg border border-sky-200 p-2.5"><Icon className="mb-1 h-4 w-4 text-[#315f91]" /><div className="font-bold">{label}</div><div className="text-[10.5px] font-normal text-[#355875]">{hint}</div></div>
          ))}
        </div>
      </Card>
    </div>
  );
}

/** Work-order WIP from the posted GL, not editable prototype records. */
function ProductionReport({ currentClient }: { currentClient: ClientEntity }) {
  const { fmt } = useMoney();
  const p = useProduction(currentClient.id);
  const rows = p.orders.map((order) => {
    const received = productionMoney(p.receipts.filter((r) => r.productionOrderId === order.id).reduce((sum, r) => sum + r.totalCost, 0));
    const wip = p.wipByOrder[order.id] ?? 0;
    const expected = productionMoney(order.totalMaterialCost + order.totalConversionCost - received);
    return { order, received, wip, difference: productionMoney(expected - wip) };
  });
  const sum = (key: 'totalMaterialCost' | 'totalConversionCost') => productionMoney(rows.reduce((n, r) => n + r.order[key], 0));
  const totalWip = productionMoney(rows.reduce((n, r) => n + r.wip, 0));
  const currency = currentClient.currency;
  return <div data-desk="report_production">
    <PageHeader kicker={`${currentClient.code} · Reconciled production reporting`} title="Production & WIP report"
      desc="Material issues and eligible conversion costs less received output, reconciled by work order to the actual WIP control account (122000).">
      <Badge tone="fi">GL-backed</Badge>
    </PageHeader>
    {p.error && <div role="alert" className="mb-3 rounded-lg border border-rose-300 bg-rose-50 p-3 text-xs font-semibold text-rose-900">{p.error}</div>}
    {p.legacyCount > 0 && <div role="alert" className="mb-3 rounded-lg border border-amber-300 bg-amber-50 p-3 text-xs text-amber-900">{p.legacyCount} unposted prototype records remain excluded; review source evidence before using historical totals.</div>}
    <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
      <Stat label="Materials capitalised" value={`${currency} ${fmt(sum('totalMaterialCost'))}`} />
      <Stat label="Conversion allocated" value={`${currency} ${fmt(sum('totalConversionCost'))}`} />
      <Stat label="GL WIP balance" value={`${currency} ${fmt(totalWip)}`} tone={totalWip < -0.009 ? 'text-rose-700' : undefined} />
      <Stat label="Unreconciled orders" value={rows.filter((r) => Math.abs(r.difference) > 0.009).length} tone={rows.some((r) => Math.abs(r.difference) > 0.009) ? 'text-rose-700' : undefined} />
    </div>
    <Card title="Work-order reconciliation" sub="Differences require evidence and correction, not a balancing plug." action={
      <button type="button" onClick={() => downloadCsv(`${currentClient.code}-production-wip.csv`, [
        ['Order', 'Item', 'Status', 'Materials', 'Conversion', 'Finished received', 'GL WIP', 'Difference'],
        ...rows.map((r) => [r.order.docNo, r.order.itemCode, r.order.status, r.order.totalMaterialCost, r.order.totalConversionCost, r.received, r.wip, r.difference]),
      ])} className="rounded border border-sky-300 bg-white px-2 py-1 text-xs font-bold text-[#082f4f]">Export CSV</button>
    }>
      {p.loading ? <p className="text-xs text-[#355875]">Loading controlled production records…</p> : !rows.length
        ? <EmptyState title="No controlled production orders" detail="Create a BOM, then a work order in Manufacturing & Production." />
        : <div className="overflow-x-auto"><table className="min-w-[900px] w-full border-collapse"><thead><tr>
            <th className={thCls}>Work order</th><th className={thCls}>Item</th><th className={thCls}>Material</th><th className={thCls}>Conversion</th><th className={thCls}>FG received</th><th className={thCls}>GL WIP</th><th className={thCls}>Difference</th><th className={thCls}>Status</th>
          </tr></thead><tbody>{rows.map((r) => <tr key={r.order.id} className={rowCls}>
            <td className={tdCls}><span className="font-mono font-bold">{r.order.docNo}</span></td><td className={tdCls}>{r.order.itemCode}</td>
            <td className={numCls}>{fmt(r.order.totalMaterialCost)}</td><td className={numCls}>{fmt(r.order.totalConversionCost)}</td>
            <td className={numCls}>{fmt(r.received)}</td><td className={numCls}>{fmt(r.wip)}</td>
            <td className={`${numCls} ${Math.abs(r.difference) > 0.009 ? 'font-bold text-rose-700' : 'text-emerald-700'}`}>{fmt(r.difference)}</td>
            <td className={tdCls}><Badge tone={r.order.status === 'Closed' ? 'green' : 'slate'}>{r.order.status}</Badge></td>
          </tr>)}</tbody></table></div>}
    </Card>
  </div>;
}
