'use client';
import { useState } from 'react';
import { Download, Printer } from 'lucide-react';
import { downloadExcel, type ExcelSheet } from '@/utils/excelExport';
import { printModuleView } from '@/utils/printModuleView';

/** Export/print exactly the selected schedule, never the surrounding workspace. */
export function ScheduleActions({ title, subtitle, targetId, filename, sheets, disabled = false }: {
  title: string; subtitle?: string; targetId: string; filename: string; sheets: ExcelSheet[]; disabled?: boolean;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const exportXlsx = async () => {
    setBusy(true); setError('');
    try { await downloadExcel(filename, sheets); }
    catch { setError('Excel export failed. Please retry; no accounting records were changed.'); }
    finally { setBusy(false); }
  };
  return <div className="flex flex-wrap items-center gap-2" data-print-hide>
    <button type="button" onClick={() => void exportXlsx()} disabled={busy || disabled} className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-300 bg-emerald-50 px-3 py-1.5 text-[11px] font-bold text-emerald-800 hover:bg-emerald-100 disabled:opacity-40"><Download className="h-3.5 w-3.5" />{busy ? 'Preparing…' : 'Export Excel (.xlsx)'}</button>
    <button type="button" disabled={disabled} onClick={() => {
      const root = document.getElementById(targetId);
      if (!root) { setError('Select a schedule before printing.'); return; }
      printModuleView({ title, subtitle, root, orientation: 'landscape' });
    }} className="inline-flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50 disabled:opacity-40"><Printer className="h-3.5 w-3.5" />Print this schedule</button>
    {error && <span role="alert" className="text-[11px] font-bold text-rose-700">{error}</span>}
  </div>;
}
