"use client";

import { useMemo, useState } from "react";
import { AlertTriangle, Boxes, FileText, Image as ImageIcon, PackageCheck, Plus, Send, ShoppingCart, Trash2, Truck, UserRound } from "lucide-react";
import type { BusinessPartner, ClientEntity, PurchaseOrder, SalesInvoice, StockItem, StockMovement, UserAccount } from "../types/accounting";
import { Badge, Card, PageHeader, Stat, formatGHS, numCls, rowCls, tdCls, thCls } from "./ui";
import { Alert, DeskTabs, EmptyState, Field, deliverEmail, downloadCsv, inputCls, useDeskRecords, useMoney } from "./DeskKit";

interface ProductMeta extends Record<string, unknown> { id: string; itemCode: string; barcode: string; sellingPrice: number; imageUrl: string; brand: string; supplier: string; notes: string; }
interface Quotation extends Record<string, unknown> { id: string; quoteNo: string; customer: string; date: string; validUntil: string; itemCode: string; description: string; qty: number; unitPrice: number; vatRate: number; status: string; notes: string; }
interface StorePo extends Record<string, unknown> { id: string; poNo: string; supplier: string; supplierEmail: string; date: string; expected: string; itemCode: string; description: string; qty: number; unitCost: number; status: string; notes: string; }
interface SupplierRec extends Record<string, unknown> { id: string; name: string; contact: string; email: string; phone: string; terms: string; leadTime: string; }

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  stockItems: StockItem[];
  movements: StockMovement[];
  partners: BusinessPartner[];
  orders: PurchaseOrder[];
  invoices: SalesInvoice[];
  onAddItem: (item: StockItem) => void;
  onNavigate?: (section: string) => void;
}

const TABS = [
  { id: "overview", label: "Overview" },
  { id: "products", label: "Products & barcodes" },
  { id: "quotations", label: "Quotations" },
  { id: "purchases", label: "Purchase orders" },
  { id: "alerts", label: "Low-stock alerts" },
  { id: "suppliers", label: "Suppliers" },
];

const money = (n: number) => `GH₵ ${formatGHS(n)}`;
const localDate = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
const newDocNo = (prefix: string) => `${prefix}-${localDate().replace(/-/g, "")}-${String(Math.floor(Math.random() * 900) + 100)}`;

export function StoreOperationsDesk({ currentClient, currentUser, stockItems, movements, partners, orders, invoices, onAddItem, onNavigate }: Props) {
  const [tab, setTab] = useState("overview");
  const { fmt, today } = useMoney();
  const products = useDeskRecords<ProductMeta>("store", currentClient.id, "product");
  const quotations = useDeskRecords<Quotation>("store", currentClient.id, "quotation");
  const storePos = useDeskRecords<StorePo>("store", currentClient.id, "purchase_order");
  const suppliers = useDeskRecords<SupplierRec>("store", currentClient.id, "supplier");

  const lowStock = useMemo(
    () => stockItems.filter((s) => (s.reorderLevel ?? 0) > 0 && s.quantityOnHand <= (s.reorderLevel ?? 0)).sort((a, b) => a.quantityOnHand - b.quantityOnHand),
    [stockItems]
  );
  const stockValue = stockItems.reduce((s, i) => s + i.totalValue, 0);
  const metaFor = (code: string) => products.records.find((p) => p.itemCode === code);
  const openQuotes = quotations.records.filter((q) => q.status === "draft" || q.status === "sent");
  const openPos = storePos.records.filter((p) => p.status !== "received" && p.status !== "cancelled");
  const salesThisMonth = invoices.filter((i) => i.date.startsWith(today().slice(0, 7))).reduce((s, i) => s + i.totalReceivable, 0);

  return (
    <div>
      <PageHeader
        kicker={`${currentClient.code} · Store & Inventory Operations`}
        title="Inventory Command Desk"
        desc="Manage your store and follow up sales and purchases from any internet-connected device — mobile, tablet or PC. Add unlimited products with pictures, data and barcodes; issue quotations and invoices; raise and follow purchase orders; and receive an alert the moment stock reaches the reorder level you set."
      >
        <Badge tone="gold">STORE</Badge>
        <Badge tone="slate">{stockItems.length} stocked items</Badge>
        {lowStock.length > 0 && <Badge tone="red">{lowStock.length} reorder alerts</Badge>}
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label="Stock on hand" value={money(stockValue)} sub={`${stockItems.length} products`} />
        <Stat label="Reorder alerts" value={lowStock.length} sub="At or below reorder level" tone={lowStock.length ? "text-[#b42318]" : "text-[#087a55]"} />
        <Stat label="Open quotations" value={openQuotes.length} sub={`${quotations.records.length} issued`} />
        <Stat label="Purchase orders" value={openPos.length} sub={`${storePos.records.length} raised here`} />
        <Stat label="Sales this month" value={money(salesThisMonth)} sub="Invoiced to clients" />
      </div>

      <DeskTabs tabs={TABS.map((t) => ({ ...t, badge: t.id === "products" ? stockItems.length : t.id === "quotations" ? openQuotes.length : t.id === "purchases" ? openPos.length : t.id === "alerts" ? lowStock.length : t.id === "suppliers" ? suppliers.records.length : 0 }))} active={tab} onChange={setTab} />

      {tab === "overview" && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card title="Reorder watchlist" sub="Items at or below the reorder level you defined" className="lg:col-span-2">
            {lowStock.length === 0 ? <EmptyState title="Stock levels are healthy" detail="Set a reorder level on each product; we will flag it here before you run out." /> : (
              <div className="overflow-x-auto rounded-lg border border-amber-300">
                <table className="w-full min-w-[620px] border-collapse">
                  <thead><tr><th className={thCls}>Product</th><th className={thCls}>On hand</th><th className={thCls}>Reorder at</th><th className={thCls}>Suggested order</th><th className={thCls}>Value</th></tr></thead>
                  <tbody>{lowStock.map((s) => (
                    <tr key={s.id} className={rowCls}>
                      <td className={tdCls}><div className="font-bold text-[#082f4f]">{s.description}</div><div className="font-mono text-[10.5px] text-[#355875]">{s.itemCode} · {metaFor(s.itemCode)?.barcode || "no barcode"}</div></td>
                      <td className={numCls}>{s.quantityOnHand} {s.uom}</td>
                      <td className={numCls}>{s.reorderLevel}</td>
                      <td className={numCls}>{Math.max((s.reorderLevel ?? 0) * 2 - s.quantityOnHand, 1)}</td>
                      <td className={numCls}>{money(s.totalValue)}</td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            )}
          </Card>
          <Card title="Quick actions" sub="Everything a store manager needs, one click away">
            <div className="space-y-2">
              <QuickAction icon={PackageCheck} label="Add a product" onClick={() => setTab("products")} hint="Pictures, barcode, price and reorder level" />
              <QuickAction icon={FileText} label="Issue a quotation" onClick={() => setTab("quotations")} hint="Convert to an invoice from Sales" />
              <QuickAction icon={ShoppingCart} label="Raise a purchase order" onClick={() => setTab("purchases")} hint="Send to the supplier and follow up" />
              <QuickAction icon={AlertTriangle} label="Review low-stock alerts" onClick={() => setTab("alerts")} hint={`${lowStock.length} item(s) need attention`} />
              {onNavigate && <QuickAction icon={Boxes} label="Open the stock ledger" onClick={() => onNavigate("inventory_ledger")} hint="Receipts, issues, write-downs and valuation" />}
              {onNavigate && currentUser.role !== "auditor" && <QuickAction icon={UserRound} label="Delegate store access" onClick={() => onNavigate("user_permissions")} hint="Add team members with pre-set inventory permissions" />}
            </div>
            <div className="mt-3 rounded-lg border border-sky-200 bg-sky-50/60 p-3 text-[11px] text-[#2d4f6d]">
              Works on any device: this desk is responsive and the data is stored on the server, so a phone, tablet and PC always see the same stock position.
            </div>
          </Card>
        </div>
      )}

      {tab === "products" && <ProductsTab stockItems={stockItems} movements={movements} products={products} onAddItem={onAddItem} onGoAlerts={() => setTab("alerts")} canEdit={currentUser.role !== 'auditor' && currentUser.status !== 'restricted' && currentUser.status !== 'suspended'} />}
      {tab === "quotations" && <QuotationsTab desk={quotations} stockItems={stockItems} partners={partners} products={products.records} onNavigate={onNavigate} clientId={currentClient.id} />}
      {tab === "purchases" && <PurchasesTab desk={storePos} stockItems={stockItems} partners={partners} lowStock={lowStock} onNavigate={onNavigate} clientId={currentClient.id} />}
      {tab === "alerts" && <AlertsTab stockItems={stockItems} products={products.records} lowStock={lowStock} onNavigate={() => setTab("purchases")} />}
      {tab === "suppliers" && <SuppliersTab desk={suppliers} partners={partners} orders={orders} />}
    </div>
  );
}

function QuickAction({ icon: Icon, label, hint, onClick }: { icon: typeof Boxes; label: string; hint: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex w-full items-start gap-2 rounded-lg border border-sky-200 bg-white px-2.5 py-2 text-left transition hover:bg-sky-50">
      <Icon className="mt-0.5 h-4 w-4 shrink-0 text-[#855b00]" />
      <span><span className="block text-[11.5px] font-bold text-[#082f4f]">{label}</span><span className="block text-[10.5px] text-[#355875]">{hint}</span></span>
    </button>
  );
}

function ProductsTab({ stockItems, movements, products, onAddItem, onGoAlerts, canEdit }: {
  stockItems: StockItem[]; movements: StockMovement[]; products: ReturnType<typeof useDeskRecords<ProductMeta>>; onAddItem: (i: StockItem) => void; onGoAlerts: () => void; canEdit: boolean;
}) {
  const { fmt, today } = useMoney();
  const [query, setQuery] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [draft, setDraft] = useState({ itemCode: "", description: "", category: "General", uom: "pcs", unitCost: 0, sellingPrice: 0, quantity: 0, reorderLevel: 0, location: "Main store", barcode: "", brand: "", supplier: "", imageUrl: "", notes: "" });
  const rows = stockItems.filter((s) => `${s.itemCode} ${s.description} ${s.category} ${products.records.find((p) => p.itemCode === s.itemCode)?.barcode ?? ""}`.toLowerCase().includes(query.toLowerCase()));

  /** Product picture: accept any camera/phone image, downscale it in the browser
   *  and store a compact JPEG data URL so the record stays small and syncs on
   *  every device without a separate file service. */
  const handlePicture = (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) { setFormError("Choose an image file (JPEG, PNG or WebP)."); return; }
    const reader = new FileReader();
    reader.onload = () => {
      const img = new window.Image();
      img.onload = () => {
        const max = 480;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        setDraft((d) => ({ ...d, imageUrl: canvas.toDataURL("image/jpeg", 0.72) }));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const [formError, setFormError] = useState<string | null>(null);
  const add = async () => {
    if (!canEdit) { setFormError('This account cannot change stock master data.'); return; }
    if (!draft.description.trim() || !draft.itemCode.trim()) return;
    const code = draft.itemCode.trim().toUpperCase();
    if (stockItems.some((s) => s.itemCode.toUpperCase() === code)) {
      setFormError(`Product code ${code} already exists. Open the stock ledger to adjust it, or use a new code.`);
      return;
    }
    setFormError(null);
    const existingMeta = products.records.find((m) => String(m.itemCode).toUpperCase() === code);
    // A product master is NOT an inventory receipt. Opening balances must
    // pass the Stock Ledger/Opening Balance posting controls, never this form.
    const saved = await products.save({ ...draft, id: existingMeta?.id, itemCode: code, sellingPrice: Number(draft.sellingPrice) || 0, barcode: draft.barcode.trim(), imageUrl: draft.imageUrl.trim() });
    if (!saved) return;
    const category = draft.category.trim() || "General";
    onAddItem({
      id: `stk-${code}-${crypto.randomUUID()}`, clientId: 0, itemCode: code, description: draft.description.trim(), category,
      uom: draft.uom.trim() || "pcs", quantityOnHand: 0, unitCost: 0, totalValue: 0, reorderLevel: Number(draft.reorderLevel) || 0,
      location: draft.location.trim() || "Main store", costMethod: "weighted_average",
      glAccount: category.toLowerCase().includes('finished') ? '121000' : '120000',
    });
    setDraft({ itemCode: "", description: "", category: "General", uom: "pcs", unitCost: 0, sellingPrice: 0, quantity: 0, reorderLevel: 0, location: "Main store", barcode: "", brand: "", supplier: "", imageUrl: "", notes: "" });
    setShowForm(false);
  };

  return (
    <Card
      title="Product catalogue"
      sub="Unlimited products with a picture, barcode, cost, selling price and a reorder level. Product metadata is stored centrally; quantities and valuation come from the stock ledger."
      action={
        <div className="flex items-center gap-2">
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search product, barcode…" className={`${inputCls} max-w-[200px]`} />
          <button onClick={() => downloadCsv("product-catalogue.csv", [["Code", "Description", "Barcode", "Category", "UoM", "On hand", "Cost", "Selling price", "Reorder level", "Location"], ...stockItems.map((s) => { const m = products.records.find((p) => p.itemCode === s.itemCode); return [s.itemCode, s.description, m?.barcode ?? "", s.category, s.uom, s.quantityOnHand, s.unitCost, m?.sellingPrice ?? 0, s.reorderLevel ?? 0, s.location ?? ""]; })])} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f]">Export</button>
          <button onClick={() => setShowForm((s) => !s)} disabled={!canEdit} className="inline-flex items-center gap-1 rounded-lg bg-[#082f4f] px-2.5 py-1.5 text-[11px] font-bold text-white disabled:opacity-40"><Plus className="h-3.5 w-3.5" /> Add product</button>
        </div>
      }
    >
      {products.error && <Alert>{products.error}</Alert>}
      {showForm && (
        <div className="mb-4 rounded-xl border border-sky-200 bg-sky-50/50 p-3">
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            <Field label="Item code / SKU *"><input className={inputCls} value={draft.itemCode} onChange={(e) => setDraft({ ...draft, itemCode: e.target.value })} placeholder="SKU-1001" /></Field>
            <Field label="Product name *"><input className={inputCls} value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} placeholder="Rice 25kg bag" /></Field>
            <Field label="Barcode"><input className={inputCls} value={draft.barcode} onChange={(e) => setDraft({ ...draft, barcode: e.target.value })} placeholder="Scan or type EAN" /></Field>
            <Field label="Category"><select className={inputCls} value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value })}>
              <option value="General">General / trading stock</option>
              <option value="Raw Materials">Raw Materials / inputs</option>
              <option value="Finished Goods">Finished Goods / sellable output</option>
              <option value="Consumables">Consumables</option>
            </select></Field>
            <Field label="Unit of measure"><input className={inputCls} value={draft.uom} onChange={(e) => setDraft({ ...draft, uom: e.target.value })} /></Field>
            <Field label="Selling price (GHS)"><input type="number" min="0" className={inputCls} value={draft.sellingPrice} onChange={(e) => setDraft({ ...draft, sellingPrice: Number(e.target.value) })} /></Field>
            <p className="self-end text-[10.5px] font-semibold text-[#355875]">Starts with zero quantity and cost. Post supported receipts in Stock Ledger or Procurement; a product master never creates an opening balance.</p>
            <Field label="Reorder level" hint="We alert you at or below this quantity"><input type="number" className={inputCls} value={draft.reorderLevel} onChange={(e) => setDraft({ ...draft, reorderLevel: Number(e.target.value) })} /></Field>
            <Field label="Store location"><input className={inputCls} value={draft.location} onChange={(e) => setDraft({ ...draft, location: e.target.value })} /></Field>
            <Field label="Default supplier"><input className={inputCls} value={draft.supplier} onChange={(e) => setDraft({ ...draft, supplier: e.target.value })} /></Field>
            <Field label="Picture"><div className="flex items-center gap-2"><label className="inline-flex cursor-pointer items-center gap-1 rounded-lg border border-sky-300 bg-white px-2 py-1.5 text-[10.5px] font-bold text-[#082f4f]"><ImageIcon className="h-3.5 w-3.5" /> Upload photo<input type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => handlePicture(e.target.files?.[0])} /></label>{draft.imageUrl ? <img src={draft.imageUrl} alt="Product preview" className="h-9 w-9 rounded border border-sky-200 object-cover" /> : <span className="text-[10px] text-[#355875]">No photo</span>}</div></Field>
            <Field label="Or picture URL"><input className={inputCls} value={draft.imageUrl.startsWith("data:") ? "" : draft.imageUrl} onChange={(e) => setDraft({ ...draft, imageUrl: e.target.value })} placeholder="https://…" /></Field>
          </div>
          {formError && <p role="alert" className="mt-2 rounded border border-rose-300 bg-rose-50 px-2 py-1 text-[11px] font-semibold text-rose-900">{formError}</p>}
          <div className="mt-3 flex items-center gap-2">
            <button onClick={() => void add()} disabled={!canEdit || !draft.description.trim() || !draft.itemCode.trim() || products.saving} className="rounded-lg bg-[#087a55] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50">Save product</button>
            <button onClick={() => setShowForm(false)} className="rounded-lg border border-sky-300 bg-white px-3 py-1.5 text-[11px] font-bold text-[#082f4f]">Cancel</button>
          </div>
        </div>
      )}
      {rows.length === 0 ? <EmptyState title="No products yet" detail="Add your first product with a picture, barcode, cost and reorder level." /> : (
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[860px] border-collapse">
            <thead><tr><th className={thCls}>Product</th><th className={thCls}>Barcode</th><th className={thCls}>On hand</th><th className={thCls}>Cost</th><th className={thCls}>Sell</th><th className={thCls}>Reorder</th><th className={thCls}>Value</th></tr></thead>
            <tbody>{rows.map((s) => {
              const meta = products.records.find((p) => p.itemCode === s.itemCode);
              const low = (s.reorderLevel ?? 0) > 0 && s.quantityOnHand <= (s.reorderLevel ?? 0);
              return (
                <tr key={s.id} className={rowCls}>
                  <td className={tdCls}>
                    <div className="flex items-center gap-2">
                      {meta?.imageUrl ? <img src={String(meta.imageUrl)} alt="" className="h-8 w-8 rounded border border-sky-200 object-cover" /> : <span className="flex h-8 w-8 items-center justify-center rounded border border-sky-200 bg-sky-50"><Boxes className="h-4 w-4 text-[#855b00]" /></span>}
                      <span><span className="block font-bold text-[#082f4f]">{s.description}</span><span className="font-mono text-[10.5px] text-[#355875]">{s.itemCode} · {s.category} · {s.location ?? "Main store"}</span></span>
                    </div>
                  </td>
                  <td className={tdCls}><span className="font-mono text-[10.5px]">{meta?.barcode || "—"}</span></td>
                  <td className={numCls}><span className={low ? "font-bold text-rose-700" : ""}>{s.quantityOnHand} {s.uom}</span>{low && <AlertTriangle className="ml-1 inline h-3 w-3 text-rose-700" />}</td>
                  <td className={numCls}>{fmt(s.unitCost)}</td>
                  <td className={numCls}>{fmt(Number(meta?.sellingPrice ?? 0))}</td>
                  <td className={numCls}>{s.reorderLevel ?? 0}</td>
                  <td className={numCls}>{fmt(s.totalValue)}</td>
                </tr>
              );
            })}</tbody>
          </table>
        </div>
      )}
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[10.5px] text-[#355875]">
        <span>{movements.length} stock movements recorded · as at {today()}</span>
        <button onClick={onGoAlerts} className="rounded-lg border border-amber-300 bg-amber-50 px-2.5 py-1 text-[10.5px] font-bold text-[#8a5d00]">Review alerts</button>
      </div>
    </Card>
  );
}

function QuotationsTab({ desk, stockItems, partners, products, onNavigate, clientId }: {
  desk: ReturnType<typeof useDeskRecords<Quotation>>; stockItems: StockItem[]; partners: BusinessPartner[]; products: ProductMeta[]; onNavigate?: (s: string) => void; clientId: number;
}) {
  const [mailMsg, setMailMsg] = useState<string | null>(null);
  const emailQuotation = async (q: Quotation) => {
    const bodyText = `Dear ${q.customer},\n\nPlease find our quotation ${q.quoteNo} for ${q.qty} × ${q.description} at GH₵ ${formatGHS(Number(q.unitPrice) || 0)} each, totalling GH₵ ${formatGHS(total(q))} including VAT.\n\n${q.notes || ""}\n\nKind regards`;
    const r = await deliverEmail({ clientId, to: emailFor(q.customer), subject: `Quotation ${q.quoteNo}`, body: bodyText, ref: q.quoteNo });
    setMailMsg(r.message);
  };
  const customers = Array.from(new Set(partners.filter((p) => p.type === "Customer").map((p) => p.name)));
  const emailFor = (name: string) => partners.find((p) => p.type === "Customer" && p.name === name)?.email ?? "";
  const [draft, setDraft] = useState({ customer: "", date: localDate(), validUntil: "", itemCode: stockItems[0]?.itemCode ?? "", qty: 1, unitPrice: 0, vatRate: 15, notes: "", status: "draft" });
  const item = stockItems.find((s) => s.itemCode === draft.itemCode);
  const meta = products.find((p) => p.itemCode === draft.itemCode);
  const net = (Number(draft.qty) || 0) * (Number(draft.unitPrice) || 0);
  const vat = net * (Number(draft.vatRate) || 0) / 100;
  const create = async () => {
    if (!draft.customer.trim() || !draft.itemCode) return;
    const saved = await desk.save({ ...draft, quoteNo: newDocNo("QT"), description: item?.description ?? draft.itemCode, customer: draft.customer.trim(), qty: Number(draft.qty) || 0, unitPrice: Number(draft.unitPrice) || 0, vatRate: Number(draft.vatRate) || 0 });
    if (saved) setDraft({ ...draft, customer: "", qty: 1, unitPrice: 0, notes: "" });
  };
  const total = (q: Quotation) => (Number(q.qty) || 0) * (Number(q.unitPrice) || 0) * (1 + (Number(q.vatRate) || 0) / 100);

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
      <Card title="Quotations issued" sub="Quote your client from the live product catalogue, then convert the accepted quote to an invoice in Sales.">
        {desk.error && <Alert>{desk.error}</Alert>}
        {mailMsg && <Alert tone="info">{mailMsg}</Alert>}
        {desk.records.length === 0 ? <EmptyState title="No quotations yet" detail="Create a quotation on the right — the line value, VAT and total calculate automatically." /> : (
          <div className="overflow-x-auto rounded-lg border border-sky-200">
            <table className="w-full min-w-[720px] border-collapse">
              <thead><tr><th className={thCls}>Quote</th><th className={thCls}>Client</th><th className={thCls}>Item</th><th className={thCls}>Qty</th><th className={thCls}>Total inc. VAT</th><th className={thCls}>Status</th><th className={thCls}></th></tr></thead>
              <tbody>{desk.records.map((q) => (
                <tr key={q.id} className={rowCls}>
                  <td className={tdCls}><div className="font-mono text-[11px] font-bold text-[#082f4f]">{q.quoteNo}</div><div className="text-[10.5px] text-[#355875]">{q.date}{q.validUntil ? ` → ${q.validUntil}` : ""}</div></td>
                  <td className={tdCls}>{q.customer}</td>
                  <td className={tdCls}><div className="font-semibold">{q.description}</div><div className="font-mono text-[10.5px] text-[#355875]">{q.itemCode}</div></td>
                  <td className={numCls}>{q.qty}</td>
                  <td className={numCls}>{money(total(q))}</td>
                  <td className={tdCls}><Badge tone={q.status === "accepted" ? "green" : q.status === "declined" ? "red" : q.status === "sent" ? "amber" : "slate"}>{q.status}</Badge></td>
                  <td className={tdCls}>
                    <div className="flex items-center gap-1">
                      <select value={q.status} onChange={(e) => void desk.save({ ...q, status: e.target.value })} className="rounded border border-sky-200 px-1 py-0.5 text-[10px] font-bold text-[#082f4f]">{["draft", "sent", "accepted", "declined", "expired"].map((s) => <option key={s}>{s}</option>)}</select>
                      <button type="button" onClick={() => void emailQuotation(q)} className="rounded border border-sky-200 p-1 text-[#082f4f]" title="Email quotation to client"><Send className="h-3 w-3" /></button>
                      <button onClick={() => void desk.remove(q.id)} className="text-rose-700" aria-label="Delete quotation"><Trash2 className="h-3 w-3" /></button>
                    </div>
                  </td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
        {onNavigate && <button onClick={() => onNavigate("sales")} className="mt-3 rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f]">Create an invoice in Sales →</button>}
      </Card>
      <Card title="New quotation" sub="Sent by email or printed to your client letterhead.">
        <div className="space-y-2">
          <Field label="Client *"><input list="quote-customers" className={inputCls} value={draft.customer} onChange={(e) => setDraft({ ...draft, customer: e.target.value })} /><datalist id="quote-customers">{customers.map((c) => <option key={c} value={c} />)}</datalist></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Date"><input type="date" className={inputCls} value={draft.date} onChange={(e) => setDraft({ ...draft, date: e.target.value })} /></Field>
            <Field label="Valid until"><input type="date" className={inputCls} value={draft.validUntil} onChange={(e) => setDraft({ ...draft, validUntil: e.target.value })} /></Field>
          </div>
          <Field label="Product">
            <select className={inputCls} value={draft.itemCode} onChange={(e) => { const s = stockItems.find((x) => x.itemCode === e.target.value); const m = products.find((p) => p.itemCode === e.target.value); setDraft({ ...draft, itemCode: e.target.value, unitPrice: Number(m?.sellingPrice ?? s?.unitCost ?? 0) }); }}>
              {stockItems.map((s) => <option key={s.id} value={s.itemCode}>{s.itemCode} · {s.description}</option>)}
            </select>
          </Field>
          <div className="grid grid-cols-3 gap-2">
            <Field label="Qty"><input type="number" min="1" className={inputCls} value={draft.qty} onChange={(e) => setDraft({ ...draft, qty: Number(e.target.value) })} /></Field>
            <Field label="Unit price"><input type="number" className={inputCls} value={draft.unitPrice} onChange={(e) => setDraft({ ...draft, unitPrice: Number(e.target.value) })} /></Field>
            <Field label="VAT %"><input type="number" className={inputCls} value={draft.vatRate} onChange={(e) => setDraft({ ...draft, vatRate: Number(e.target.value) })} /></Field>
          </div>
          <Field label="Notes / terms"><textarea rows={2} className={inputCls} value={draft.notes} onChange={(e) => setDraft({ ...draft, notes: e.target.value })} placeholder="Payment terms, delivery" /></Field>
          <div className="rounded-lg border border-sky-200 bg-sky-50/60 px-2.5 py-2 text-[11px]">
            <div className="flex justify-between"><span>Net</span><span className="font-mono font-bold">GH₵ {formatGHS(net)}</span></div>
            <div className="flex justify-between"><span>VAT</span><span className="font-mono font-bold">GH₵ {formatGHS(vat)}</span></div>
            <div className="mt-1 flex justify-between border-t border-sky-200 pt-1 font-bold"><span>Total</span><span className="font-mono">GH₵ {formatGHS(net + vat)}</span></div>
          </div>
          <button onClick={() => void create()} disabled={desk.saving || !draft.customer.trim() || !draft.itemCode} className="inline-flex w-full items-center justify-center gap-1 rounded-lg bg-[#082f4f] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50"><Send className="h-3.5 w-3.5" /> Create quotation</button>
        </div>
      </Card>
    </div>
  );
}

function PurchasesTab({ desk, stockItems, partners, lowStock, onNavigate, clientId }: {
  desk: ReturnType<typeof useDeskRecords<StorePo>>; stockItems: StockItem[]; partners: BusinessPartner[]; lowStock: StockItem[]; onNavigate?: (s: string) => void; clientId: number;
}) {
  const [mailMsg, setMailMsg] = useState<string | null>(null);
  const emailPo = async (po: StorePo) => {
    const bodyText = `Please supply ${po.qty} × ${po.description} (${po.itemCode}). Order value GH₵ ${formatGHS(poTotal(po))}. Expected ${po.expected || "as agreed"}.`;
    const r = await deliverEmail({ clientId, to: po.supplierEmail, subject: `Purchase order ${po.poNo}`, body: bodyText, ref: po.poNo });
    setMailMsg(r.message);
  };
  const suppliers = Array.from(new Set(partners.filter((p) => p.type === "Vendor").map((p) => p.name)));
  const [draft, setDraft] = useState({ supplier: "", supplierEmail: "", date: localDate(), expected: "", itemCode: "", qty: 1, unitCost: 0, status: "draft", notes: "" });
  const item = stockItems.find((s) => s.itemCode === draft.itemCode);
  const total = (Number(draft.qty) || 0) * (Number(draft.unitCost) || 0);
  const create = async () => {
    if (!draft.supplier.trim() || !draft.itemCode) return;
    const saved = await desk.save({ ...draft, poNo: newDocNo("LPO"), description: item?.description ?? draft.itemCode, supplier: draft.supplier.trim(), qty: Number(draft.qty) || 0, unitCost: Number(draft.unitCost) || 0 });
    if (saved) setDraft({ ...draft, qty: 1, unitCost: 0, notes: "" });
  };
  const replenish = (s: StockItem) => {
    setDraft({ ...draft, itemCode: s.itemCode, qty: Math.max((s.reorderLevel ?? 0) * 2 - s.quantityOnHand, 1), unitCost: s.unitCost, notes: `Replenishment for ${s.description} — stock at ${s.quantityOnHand}, reorder level ${s.reorderLevel}.` });
  };
  const poTotal = (p: StorePo) => (Number(p.qty) || 0) * (Number(p.unitCost) || 0);

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
      <Card title="Purchase orders" sub="Raise, send and follow up supplier orders. Update the status as goods are received; the stock ledger records the receipt.">
        {desk.error && <Alert>{desk.error}</Alert>}
        {lowStock.length > 0 && (
          <div className="mb-3 rounded-lg border border-amber-300 bg-amber-50 p-2.5">
            <div className="text-[10.5px] font-black uppercase tracking-wider text-[#8a5d00]">Reorder now</div>
            <div className="mt-1 flex flex-wrap gap-1.5">{lowStock.slice(0, 6).map((s) => <button key={s.id} onClick={() => replenish(s)} className="rounded border border-amber-400 bg-white px-2 py-1 text-[10.5px] font-bold text-[#8a5d00] hover:bg-amber-100">{s.description} ({s.quantityOnHand})</button>)}</div>
          </div>
        )}
        {desk.records.length === 0 ? <EmptyState title="No purchase orders yet" detail="Create a purchase order and send it to your supplier in one step." /> : (
          <div className="overflow-x-auto rounded-lg border border-sky-200">
            <table className="w-full min-w-[780px] border-collapse">
              <thead><tr><th className={thCls}>Order</th><th className={thCls}>Supplier</th><th className={thCls}>Item</th><th className={thCls}>Qty</th><th className={thCls}>Value</th><th className={thCls}>Expected</th><th className={thCls}>Status</th><th className={thCls}></th></tr></thead>
              <tbody>{desk.records.map((p) => (
                <tr key={p.id} className={rowCls}>
                  <td className={tdCls}><div className="font-mono text-[11px] font-bold text-[#082f4f]">{p.poNo}</div><div className="text-[10.5px] text-[#355875]">{p.date}</div></td>
                  <td className={tdCls}>{p.supplier}</td>
                  <td className={tdCls}><div className="font-semibold">{p.description}</div><div className="font-mono text-[10.5px] text-[#355875]">{p.itemCode}</div></td>
                  <td className={numCls}>{p.qty}</td>
                  <td className={numCls}>{money(poTotal(p))}</td>
                  <td className={tdCls}>{p.expected || "—"}</td>
                  <td className={tdCls}>
                    <select value={p.status} onChange={(e) => void desk.save({ ...p, status: e.target.value })} className="rounded border border-sky-200 px-1 py-0.5 text-[10px] font-bold text-[#082f4f]">{["draft", "sent", "partial", "received", "cancelled"].map((s) => <option key={s}>{s}</option>)}</select>
                  </td>
                  <td className={tdCls}>
                    <div className="flex items-center gap-1">
                      {p.supplierEmail && <button type="button" onClick={() => void emailPo(p)} className="rounded border border-sky-200 p-1 text-[#082f4f]" title="Email supplier"><Send className="h-3 w-3" /></button>}
                      <button onClick={() => void desk.remove(p.id)} className="text-rose-700" aria-label="Delete purchase order"><Trash2 className="h-3 w-3" /></button>
                    </div>
                  </td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
        {onNavigate && <button onClick={() => onNavigate("procurement")} className="mt-3 rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f]">Open Procurement & P2P for invoice matching →</button>}
      </Card>
      <Card title="New purchase order" sub="Send to your supplier immediately, or save as a draft.">
        <div className="space-y-2">
          <Field label="Supplier *"><input list="po-suppliers" className={inputCls} value={draft.supplier} onChange={(e) => setDraft({ ...draft, supplier: e.target.value })} /><datalist id="po-suppliers">{suppliers.map((s) => <option key={s} value={s} />)}</datalist></Field>
          <Field label="Supplier email"><input type="email" className={inputCls} value={draft.supplierEmail} onChange={(e) => setDraft({ ...draft, supplierEmail: e.target.value })} placeholder="orders@supplier.com" /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Order date"><input type="date" className={inputCls} value={draft.date} onChange={(e) => setDraft({ ...draft, date: e.target.value })} /></Field>
            <Field label="Expected"><input type="date" className={inputCls} value={draft.expected} onChange={(e) => setDraft({ ...draft, expected: e.target.value })} /></Field>
          </div>
          <Field label="Product">
            <select className={inputCls} value={draft.itemCode} onChange={(e) => { const s = stockItems.find((x) => x.itemCode === e.target.value); setDraft({ ...draft, itemCode: e.target.value, unitCost: s?.unitCost ?? 0 }); }}>
              <option value="">Select product…</option>
              {stockItems.map((s) => <option key={s.id} value={s.itemCode}>{s.itemCode} · {s.description}</option>)}
            </select>
          </Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Quantity"><input type="number" min="1" className={inputCls} value={draft.qty} onChange={(e) => setDraft({ ...draft, qty: Number(e.target.value) })} /></Field>
            <Field label="Unit cost"><input type="number" className={inputCls} value={draft.unitCost} onChange={(e) => setDraft({ ...draft, unitCost: Number(e.target.value) })} /></Field>
          </div>
          <Field label="Notes"><textarea rows={2} className={inputCls} value={draft.notes} onChange={(e) => setDraft({ ...draft, notes: e.target.value })} /></Field>
          <div className="flex items-center justify-between rounded-lg border border-sky-200 bg-sky-50/60 px-2.5 py-2 text-[11px] font-bold"><span>Order value</span><span className="font-mono">GH₵ {formatGHS(total)}</span></div>
          <button onClick={() => void create()} disabled={desk.saving || !draft.supplier.trim() || !draft.itemCode} className="inline-flex w-full items-center justify-center gap-1 rounded-lg bg-[#855b00] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50"><Truck className="h-3.5 w-3.5" /> Create purchase order</button>
        </div>
      </Card>
    </div>
  );
}

function AlertsTab({ stockItems, products, lowStock, onNavigate }: { stockItems: StockItem[]; products: ProductMeta[]; lowStock: StockItem[]; onNavigate: () => void }) {
  return (
    <div className="space-y-4">
      <Card title="Stock alerts" sub="The system alerts you when an item reaches the limit you set, so you can order before you run out.">
        {lowStock.length === 0 ? <EmptyState title="No alerts right now" detail="Every stocked item with a reorder level is above its threshold." /> : (
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {lowStock.map((s) => {
              const meta = products.find((p) => p.itemCode === s.itemCode);
              const suggested = Math.max((s.reorderLevel ?? 0) * 2 - s.quantityOnHand, 1);
              return (
                <div key={s.id} className="rounded-xl border border-amber-300 bg-amber-50/60 p-3">
                  <div className="flex items-center justify-between"><Badge tone="red">Reorder</Badge><span className="font-mono text-[10.5px] text-[#8a5d00]">{s.itemCode}</span></div>
                  <div className="mt-1 text-sm font-bold text-[#082f4f]">{s.description}</div>
                  <div className="text-[11px] text-[#355875]">{s.quantityOnHand} {s.uom} on hand · reorder at {s.reorderLevel} · order ~{suggested}</div>
                  {meta?.supplier && <div className="text-[10.5px] text-[#355875]">Supplier: {String(meta.supplier)}</div>}
                  <div className="mt-2 flex items-center gap-2">
                    <button onClick={onNavigate} className="rounded-lg bg-[#855b00] px-2.5 py-1 text-[10.5px] font-bold text-white">Create purchase order</button>
                    {meta?.supplier && <a href={`mailto:?subject=${encodeURIComponent(`Stock replenishment: ${s.description}`)}&body=${encodeURIComponent(`Please quote and supply ${suggested} ${s.uom} of ${s.description} (${s.itemCode}).`)}`} className="rounded-lg border border-amber-400 bg-white px-2 py-1 text-[10.5px] font-bold text-[#8a5d00]">Email supplier</a>}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
      <Card title="All reorder settings" sub="Set the threshold on each product; leave at zero to switch alerts off.">
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[560px] border-collapse">
            <thead><tr><th className={thCls}>Item</th><th className={thCls}>On hand</th><th className={thCls}>Reorder level</th><th className={thCls}>Status</th></tr></thead>
            <tbody>{stockItems.map((s) => {
              const low = (s.reorderLevel ?? 0) > 0 && s.quantityOnHand <= (s.reorderLevel ?? 0);
              return <tr key={s.id} className={rowCls}><td className={tdCls}>{s.description}<div className="font-mono text-[10px] text-[#355875]">{s.itemCode}</div></td><td className={numCls}>{s.quantityOnHand} {s.uom}</td><td className={numCls}>{s.reorderLevel || "—"}</td><td className={tdCls}><Badge tone={low ? "red" : "green"}>{low ? "Reorder" : "Healthy"}</Badge></td></tr>;
            })}</tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function SuppliersTab({ desk, partners, orders }: { desk: ReturnType<typeof useDeskRecords<SupplierRec>>; partners: BusinessPartner[]; orders: PurchaseOrder[] }) {
  const [draft, setDraft] = useState({ name: "", contact: "", email: "", phone: "", terms: "30 days", leadTime: "7 days" });
  const create = async () => {
    if (!draft.name.trim()) return;
    const saved = await desk.save({ ...draft, name: draft.name.trim() });
    if (saved) setDraft({ ...draft, name: "", contact: "", email: "", phone: "" });
  };
  const master = partners.filter((p) => p.type === "Vendor");
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
      <Card title="Supplier directory" sub="Master-file vendors and the procurement terms captured in the store desk.">
        {desk.error && <Alert>{desk.error}</Alert>}
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[640px] border-collapse">
            <thead><tr><th className={thCls}>Supplier</th><th className={thCls}>Contact</th><th className={thCls}>Email</th><th className={thCls}>Terms / lead time</th><th className={thCls}>POs</th><th className={thCls}></th></tr></thead>
            <tbody>
              {master.map((p) => (
                <tr key={p.id} className={rowCls}><td className={tdCls}><div className="font-bold text-[#082f4f]">{p.name}</div><div className="font-mono text-[10px] text-[#355875]">{p.code} · TIN {p.tin || "—"}</div></td><td className={tdCls}>{p.phone || "—"}</td><td className={tdCls}>{p.email || "—"}</td><td className={tdCls}>Master file</td><td className={numCls}>{orders.filter((o) => o.vendorName === p.name).length}</td><td></td></tr>
              ))}
              {desk.records.map((s) => (
                <tr key={s.id} className={rowCls}><td className={tdCls}><div className="font-bold text-[#082f4f]">{s.name}</div><div className="text-[10px] text-[#355875]">Store desk</div></td><td className={tdCls}>{s.contact || "—"}</td><td className={tdCls}>{s.email || "—"}</td><td className={tdCls}>{s.terms} · {s.leadTime}</td><td className={numCls}>—</td><td className={tdCls}><button onClick={() => void desk.remove(s.id)} className="text-rose-700" aria-label="Delete supplier"><Trash2 className="h-3 w-3" /></button></td></tr>
              ))}
            </tbody>
          </table>
        </div>
        {master.length + desk.records.length === 0 && <EmptyState title="No suppliers yet" detail="Add suppliers here or in Business Partners." />}
      </Card>
      <Card title="Add supplier terms" sub="Used when raising a purchase order.">
        <div className="space-y-2">
          <Field label="Supplier name *"><input className={inputCls} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></Field>
          <Field label="Contact person"><input className={inputCls} value={draft.contact} onChange={(e) => setDraft({ ...draft, contact: e.target.value })} /></Field>
          <Field label="Email"><input type="email" className={inputCls} value={draft.email} onChange={(e) => setDraft({ ...draft, email: e.target.value })} /></Field>
          <Field label="Phone"><input className={inputCls} value={draft.phone} onChange={(e) => setDraft({ ...draft, phone: e.target.value })} /></Field>
          <Field label="Payment terms"><input className={inputCls} value={draft.terms} onChange={(e) => setDraft({ ...draft, terms: e.target.value })} /></Field>
          <Field label="Lead time"><input className={inputCls} value={draft.leadTime} onChange={(e) => setDraft({ ...draft, leadTime: e.target.value })} /></Field>
          <button onClick={() => void create()} disabled={desk.saving || !draft.name.trim()} className="w-full rounded-lg bg-[#082f4f] px-3 py-1.5 text-[11px] font-bold text-white disabled:opacity-50">Save supplier</button>
        </div>
      </Card>
    </div>
  );
}
