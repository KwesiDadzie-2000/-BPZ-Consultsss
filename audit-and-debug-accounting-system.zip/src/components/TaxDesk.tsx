"use client";

import { useState, type ReactNode } from "react";
import { FileCheck2, ListOrdered } from "lucide-react";

/**
 * Tax Desk — one module for the monthly statutory cycle.
 *
 * "WHT & VAT Schedules" (the line-level GRA schedules) and "Tax & Statutory
 * Returns" (the period reconciliation and filing working paper) were two menu
 * entries with near-identical ids for ONE workflow: build the schedules, then
 * reconcile and file. They now share one desk with two tabs.
 */
export function TaxDesk({ initialTab, returns, schedules }: {
  initialTab: "returns" | "schedules";
  returns: (openSchedules: () => void) => ReactNode;
  schedules: ReactNode;
}) {
  const [tab, setTab] = useState(initialTab);
  const tabs = [
    { id: "schedules" as const, label: "1 · WHT & VAT schedules", hint: "Line-level GRA schedules from posted documents", icon: ListOrdered },
    { id: "returns" as const, label: "2 · Returns, reconciliation & filing", hint: "Period liabilities, remittances and CIT", icon: FileCheck2 },
  ];
  return (
    <div className="space-y-4">
      <div role="tablist" aria-label="Tax desk" className="flex flex-col gap-1.5 rounded-xl border border-sky-200 bg-white p-1.5 shadow-sm sm:flex-row">
        {tabs.map(({ id, label, hint, icon: Icon }) => (
          <button key={id} role="tab" type="button" aria-selected={tab === id} onClick={() => setTab(id)}
            className={`flex flex-1 items-start gap-2.5 rounded-lg px-3 py-2.5 text-left transition ${tab === id ? "bg-[#082f4f] text-white" : "text-[#163653] hover:bg-sky-100"}`}>
            <Icon className={`mt-0.5 h-4 w-4 shrink-0 ${tab === id ? "text-[#f5b719]" : "text-[#355875]"}`} />
            <span><span className="block text-xs font-bold">{label}</span><span className={`block text-[10.5px] ${tab === id ? "text-sky-100" : "text-[#355875]"}`}>{hint}</span></span>
          </button>
        ))}
      </div>
      {tab === "schedules" ? schedules : returns(() => setTab("schedules"))}
    </div>
  );
}
