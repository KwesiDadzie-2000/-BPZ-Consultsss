import { ReactNode } from "react";

export function cn(...parts: (string | false | null | undefined)[]): string {
  return parts.filter(Boolean).join(" ");
}

export type Tone = "slate" | "gold" | "mm" | "sd" | "hr" | "aa" | "ad" | "fi" | "green" | "red" | "amber";

const TONES: Record<Tone, string> = {
  slate: "border-sky-300/60 bg-sky-100/60 text-[#163653]",
  gold: "border-amber-400/60 bg-amber-100/60 text-[#855b00]",
  mm: "border-sky-300 bg-sky-50 text-[#006f98]",
  sd: "border-emerald-300 bg-emerald-50 text-[#087a55]",
  hr: "border-purple-300 bg-purple-50 text-[#6d3fb3]",
  aa: "border-amber-400 bg-amber-50 text-[#8a5d00]",
  ad: "border-pink-300 bg-pink-50 text-[#a51f58]",
  fi: "border-blue-300 bg-blue-50 text-[#315f91]",
  green: "border-emerald-300 bg-emerald-50 text-[#087a55]",
  red: "border-rose-300 bg-rose-50 text-[#b42318]",
  amber: "border-amber-400 bg-amber-50 text-[#8a5d00]",
};

export function Badge({
  tone = "slate",
  children,
  className,
}: {
  tone?: Tone;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 whitespace-nowrap rounded border px-2 py-0.5 font-mono text-[11px] font-bold tracking-wide",
        TONES[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

export function ModuleTag({ m }: { m: string }) {
  const meta: Record<string, { label: string; tone: Tone }> = {
    MM: { label: "Procurement", tone: "mm" },
    SD: { label: "Sales", tone: "sd" },
    HR: { label: "Payroll", tone: "hr" },
    "FI-AA": { label: "Fixed Assets", tone: "aa" },
    ADMIN: { label: "Admin & Insurance", tone: "ad" },
    FI: { label: "Finance", tone: "fi" },
    INV: { label: "Inventory", tone: "gold" },
    PP: { label: "Production", tone: "mm" },
    PC: { label: "Project Costing", tone: "fi" },
  };
  const item = meta[m] || { label: m, tone: "slate" };
  return <Badge tone={item.tone}>{m}</Badge>;
}

export function StatusBadge({ status }: { status: string }) {
  const tones: Record<string, Tone> = {
    Open: "slate",
    Draft: "slate",
    "Goods Received": "mm",
    Invoiced: "amber",
    Paid: "green",
    Approved: "green",
    Posted: "fi",
    Credited: "gold",
    Debited: "gold",
    "Awaiting payment": "amber",
    "Partially paid": "mm",
    Partial: "mm",
    Reversed: "gold",
  };
  return <Badge tone={tones[status] || "slate"}>{status}</Badge>;
}

export function Card({
  title,
  sub,
  action,
  children,
  className,
  id,
  pad = true,
}: {
  title?: ReactNode;
  sub?: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  id?: string;
  pad?: boolean;
}) {
  return (
    <section id={id} className={cn("rounded-xl border border-sky-200/90 bg-white shadow-sm", className)}>
      {(title || action) && (
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-sky-100 bg-[#f7fbff] px-4 py-3 rounded-t-xl">
          <div className="min-w-0">
            <h3 className="text-sm font-bold tracking-wide text-[#0a253e]">{title}</h3>
            {sub && <p className="mt-0.5 truncate text-xs text-[#2d4f6d]">{sub}</p>}
          </div>
          {action && <div className="flex items-center gap-2">{action}</div>}
        </header>
      )}
      <div className={pad ? "p-4" : ""}>{children}</div>
    </section>
  );
}

export function Stat({
  label,
  value,
  sub,
  tone,
}: {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  tone?: string;
}) {
  return (
    <div className="rounded-xl border border-sky-200/80 bg-white px-4 py-3.5 shadow-sm">
      <div className="text-[11.5px] font-bold uppercase tracking-wider text-[#2d4f6d]">{label}</div>
      <div className={cn("mt-1 font-mono text-[21px] font-extrabold leading-tight tabular-nums", tone ?? "text-[#0a253e]")}>
        {value}
      </div>
      {sub && <div className="mt-1 text-xs text-[#355875]">{sub}</div>}
    </div>
  );
}

export function PageHeader({
  kicker,
  title,
  desc,
  children,
}: {
  kicker?: ReactNode;
  title: string;
  desc?: string;
  children?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4 border-b border-sky-200/70 pb-4">
      <div className="min-w-0">
        {kicker && (
          <div className="mb-1 text-[11px] font-bold uppercase tracking-widest text-[#855b00]">{kicker}</div>
        )}
        <h1 className="text-2xl font-black leading-tight text-[#082f4f]">{title}</h1>
        {desc && <p className="mt-1 max-w-3xl text-xs sm:text-sm leading-relaxed text-[#2d4f6d]">{desc}</p>}
      </div>
      {children && <div className="flex flex-wrap items-center gap-2">{children}</div>}
    </div>
  );
}

export const tdCls = "px-3 py-2 text-xs text-[#0a253e]";
export const thCls = "px-3 py-2 text-left text-xs font-bold uppercase tracking-wider text-[#2d4f6d] bg-sky-50/70";
export const numCls = "px-3 py-2 text-right font-mono text-xs tabular-nums text-[#0a253e]";
export const rowCls = "border-b border-sky-100 hover:bg-[#f3f9ff] transition-colors";

export function formatGHS(n: number): string {
  return n.toLocaleString("en-GH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
