import { GHANA_ECONOMY_SECTORS, type GhanaSectorDef } from "./ghanaSectors";

/**
 * Sector workflow profiles — the "switcher".
 *
 * Each Ghana sector maps to a workflow profile distilled from the BPZ
 * sector accounting manual: the operational flow (event → posting → report),
 * the modules and dimensions the workspace must expose, the key GL accounts,
 * the sector compliance calendar and the close controls. When a client
 * workspace is opened, the system switches to the profile of that client's
 * sector so the accounting workflow matches the industry automatically.
 */

export interface SectorWorkflowStep {
  label: string;
  /** Sidebar section id this step maps to (deep link). */
  section?: string;
}

export interface SectorComplianceItem {
  obligation: string;
  due: string;
  authority: string;
  section?: string;
}

export interface SectorProfile {
  sectorCode: string;
  sectorName: string;
  category: GhanaSectorDef["category"];
  /** Manual module reference, e.g. "Module 11 — Manufacturing". */
  manualRef: string;
  tagline: string;
  /** Operational flow from source event to reporting (the "Flow"). */
  flow: string[];
  /** Modules the workspace should emphasise for this sector (sidebar ids). */
  modules: { id: string; label: string; reason: string }[];
  /** Dimensions to configure for this sector. */
  dimensions: string[];
  /** Key GL accounts used by the sector workflow. */
  keyAccounts: { accountNo: string; name: string; why: string }[];
  /** Sector-specific recognition / accounting notes. */
  accountingNotes: string[];
  /** Close & control checks specific to the sector. */
  closeControls: string[];
  /** Compliance calendar entries (beyond the standard PAYE/SSNIT/VAT). */
  compliance: SectorComplianceItem[];
  /** Recommended contracted services. */
  services: string[];
}

const STANDARD_COMPLIANCE: SectorComplianceItem[] = [
  { obligation: "PAYE and income-tax WHT remittance", due: "15th of the following month", authority: "GRA", section: "tax_schedule" },
  { obligation: "SSNIT Tier 1 & Tier 2 remittance", due: "Within 14 days of the following month", authority: "SSNIT", section: "payment_desk" },
  { obligation: "Monthly VAT return (VAT 15% + NHIL 2.5% + GETFund 2.5%)", due: "Last working day of the following month", authority: "GRA", section: "tax_schedule" },
  { obligation: "CIT instalment payments", due: "Quarterly per GRA schedule", authority: "GRA", section: "tax_schedule" },
  { obligation: "Annual CIT return & financial statements filing", due: "Within 4 months of year end", authority: "GRA / Registrar-General", section: "ifrs_statements" },
];

const PROFILES: Record<string, Omit<SectorProfile, "sectorCode" | "sectorName" | "category">> = {
  // ---- Extractives & energy ----
  mining_metals: {
    manualRef: "Module 1 — Mining, quarrying & mineral processing",
    tagline: "Licence → work order → extraction → stockpile → processing → assay → sale → royalty/tax.",
    flow: [
      "Licence and approved budget (Fixed Assets / Projects)",
      "Exploration & development work orders (Production Desk)",
      "Ore extraction and stockpile measurement (Inventory & Store)",
      "Processing and metal recovery (Production Desk)",
      "Assay / refinery confirmation (Procurement / attachments)",
      "Sale and settlement (Sales & Invoicing)",
      "Royalty & tax computation (Tax & Statutory Returns)",
      "Closure-obligation update (Adjustments / IAS 37)",
    ],
    modules: [
      { id: "production_desk", label: "Production Desk", reason: "Extraction, WIP and stockpile accounting" },
      { id: "inventory", label: "Inventory Command Desk", reason: "Ore / stockpile / finished minerals" },
      { id: "sales", label: "Sales & Invoicing", reason: "Off-take contracts and settlement" },
      { id: "tax_schedule", label: "Tax Desk", reason: "Price-linked royalty (L.I. 2517) + CIT 35%" },
      { id: "assets", label: "Fixed Assets Register", reason: "Units-of-production depreciation" },
    ],
    dimensions: ["mine", "pit", "licence", "processing stage", "cost centre"],
    keyAccounts: [
      { accountNo: "500000", name: "Cost of Extraction & Processing", why: "Production cost capture" },
      { accountNo: "120000", name: "Inventories — Raw Materials & Spares", why: "Ore / stockpiles" },
      { accountNo: "121000", name: "Inventories — Finished Goods", why: "Finished minerals" },
      { accountNo: "122000", name: "Inventories — Work in Progress", why: "In-process ore" },
    ],
    accountingNotes: [
      "IFRS 6 exploration/evaluation policy must be assessed before capitalising.",
      "Royalty under L.I. 2517 (from 10 Mar 2026) is price-linked — do not hard-code flat 5%.",
      "Units-of-production depreciation; reconcile tonnes × grade × recovery to payable metal.",
    ],
    closeControls: [
      "Reconcile tonnes × grade × recovery to payable metal and sales",
      "Investigate stockpile / assay variances before posting",
      "Assess restoration / rehabilitation provision (IAS 37)",
    ],
    compliance: [
      ...STANDARD_COMPLIANCE,
      { obligation: "Mineral royalty (price-linked, L.I. 2517)", due: "Per concession agreement / monthly", authority: "Minerals Commission / GRA", section: "tax_schedule" },
      { obligation: "EPA environmental permits & reports", due: "Per permit conditions", authority: "EPA", section: "compliance_review" },
    ],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  oil_gas_upstream: {
    manualRef: "Module 2 — Upstream oil, gas & petroleum services",
    tagline: "Petroleum agreement → work programme → well costs → cash calls → production → entitlement/lifting → settlement.",
    flow: [
      "Petroleum / joint arrangement assessment (IFRS Desk)",
      "Authorised work programme & AFE (Production Desk)",
      "Well / service cost capture (Procurement & Expenses)",
      "Partner cash calls (Banking / Payment Desk)",
      "Production measurement & entitlement/lifting reconciliation (Inventory)",
      "Sales / service certification (Sales & Invoicing)",
      "Partner, tax and regulator reporting (Tax / IFRS Desk)",
    ],
    modules: [
      { id: "production_desk", label: "Production Desk", reason: "Work programmes and WIP" },
      { id: "payment_desk", label: "Payment Desk", reason: "Partner cash calls" },
      { id: "inventory", label: "Inventory Command Desk", reason: "Entitlement / lifting reconciliation" },
      { id: "ifrs_desk", label: "IFRS Desk", reason: "Joint operation vs JV; decommissioning" },
      { id: "tax_schedule", label: "Tax Desk", reason: "PPT 35% + petroleum WHT" },
    ],
    dimensions: ["field", "well", "licence", "AFE", "partner", "recoverability"],
    keyAccounts: [
      { accountNo: "130000", name: "PPE (Cost)", why: "Development & producing assets" },
      { accountNo: "122000", name: "WIP", why: "Well costs in progress" },
      { accountNo: "200000", name: "Trade Payables", why: "Partner / operator billings" },
    ],
    accountingNotes: [
      "Determine joint operation vs joint venture — ownership % alone is insufficient.",
      "Partner cash call is funding, not revenue.",
      "Assess over/under-lift, reserves-based depreciation, decommissioning.",
    ],
    closeControls: ["Reconcile production → entitlements → liftings → invoices → receipts", "Operator billings → recoverable partner costs"],
    compliance: [
      ...STANDARD_COMPLIANCE,
      { obligation: "Petroleum Production Tax (PPT 35%)", due: "Per Act 894 schedule", authority: "GRA", section: "tax_schedule" },
      { obligation: "Petroleum Commission returns & work programme reports", due: "Per licence conditions", authority: "Petroleum Commission", section: "compliance_review" },
    ],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  oil_gas_downstream: {
    manualRef: "Module 3 — Downstream petroleum, bulk distribution, filling stations & LPG",
    tagline: "Depot receipt → measured storage → dispatch → station receipt → pump sale → daily stock & margin reconciliation → levies.",
    flow: [
      "Product purchase/import (Procurement & P2P)",
      "Depot receipt & measured storage (Inventory & Store)",
      "Dispatch / station receipt (Inventory transfers)",
      "Pump / retail sale (Sales & Invoicing)",
      "Daily collections (Payment Desk)",
      "Stock & margin reconciliation (Reports Centre)",
      "Levy & industry settlement (Tax & Statutory Returns)",
    ],
    modules: [
      { id: "inventory", label: "Inventory Command Desk", reason: "Tank dips, batches, measured stock" },
      { id: "sales", label: "Sales & Invoicing", reason: "Pump / retail sales" },
      { id: "payment_desk", label: "Payment Desk", reason: "Daily collections by shift" },
      { id: "tax_schedule", label: "Tax Desk", reason: "UPPF / ESRL / NPA levies" },
      { id: "reports", label: "Reports Centre", reason: "Litres sold, loss rates, margin per unit" },
    ],
    dimensions: ["product", "depot", "tank", "station", "batch", "pricing window"],
    keyAccounts: [
      { accountNo: "120000", name: "Inventories — Raw Materials", why: "Fuel stock at landed cost" },
      { accountNo: "121000", name: "Inventories — Finished Goods", why: "Pump-ready product" },
      { accountNo: "504000", name: "COGS", why: "Margin per unit" },
    ],
    accountingNotes: [
      "Build inventory cost with qualifying purchase + landing costs; separate recoverable taxes.",
      "Distinguish owned stock from consignment; cylinder deposits are liabilities, not sales.",
      "Normal measurement losses vs abnormal shortages must be separated.",
    ],
    closeControls: ["Daily opening stock + receipts − metered sales − approved losses = closing measured stock", "Reconcile cash/card/mobile-money sales by shift"],
    compliance: [
      ...STANDARD_COMPLIANCE,
      { obligation: "UPPF levy & NPA price build-up", due: "Monthly per NPA", authority: "NPA", section: "tax_schedule" },
      { obligation: "Energy Sector Recovery Levy (ESRL)", due: "Monthly", authority: "GRA / Ministry of Energy", section: "tax_schedule" },
    ],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  renewable_energy: {
    manualRef: "Module 17 — Electricity, renewable energy & IPPs",
    tagline: "Tariff/PPA setup → asset & connection setup → generation → metered billing → unbilled accrual → collections.",
    flow: ["Supply contract/tariff setup", "Asset & connection setup (Fixed Assets)", "Generation & meter readings (Production Desk / Inventory)", "Billing & unbilled accrual (Sales)", "Collections (Payment Desk)", "Regulatory reconciliation (Reports)"],
    modules: [
      { id: "assets", label: "Fixed Assets Register", reason: "Plant, connection assets, PURC tariffs" },
      { id: "sales", label: "Sales & Invoicing", reason: "Metered & unbilled revenue" },
      { id: "payment_desk", label: "Payment Desk", reason: "Collections" },
      { id: "tax_schedule", label: "Tax Desk", reason: "Concessionary CIT; levies" },
    ],
    dimensions: ["plant", "meter", "customer class", "tariff version", "service zone"],
    keyAccounts: [{ accountNo: "130000", name: "PPE (Cost)", why: "Generation plant" }, { accountNo: "400000", name: "Revenue from contracts", why: "Capacity & energy charges" }, { accountNo: "118100", name: "Unbilled Contract Assets", why: "Unbilled earned revenue" }],
    accountingNotes: ["Assess capacity/energy charges, take-or-pay, connection fees, deposits, subsidies", "A tariff-recovery shortfall is not automatically a regulatory asset under IFRS."],
    closeControls: ["Reconcile generated volume → technical losses → billed volume → collections", "Reconcile estimated unbilled revenue to subsequent actual bills"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "PURC tariff & Energy Commission filings", due: "Per licence", authority: "PURC / Energy Commission", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  // ---- Agriculture ----
  commercial_agric: {
    manualRef: "Module 14 — Agriculture, plantations, livestock & poultry",
    tagline: "Farm plan → input purchase → planting/stocking → field activity → biological measurement → harvest → storage/grading → sale.",
    flow: ["Farm/crop plan", "Input purchase (Procurement)", "Planting / stocking (Production Desk)", "Field & herd activity capture (HR attendance + Expenses)", "Biological measurement (Inventory)", "Harvest / production (Production Desk)", "Storage & grading (Inventory)", "Sale (Sales & Invoicing)"],
    modules: [
      { id: "production_desk", label: "Production Desk", reason: "Crop cycles, harvest, WIP" },
      { id: "inventory", label: "Inventory Command Desk", reason: "Inputs, produce, batch" },
      { id: "sales", label: "Sales & Invoicing", reason: "Harvest sales" },
      { id: "ifrs_desk", label: "IFRS Desk", reason: "IAS 41 biological assets (fair value)" },
      { id: "tax_schedule", label: "Tax Desk", reason: "1% CIT / 5-yr holiday (Act 896 s.10(4))" },
    ],
    dimensions: ["farm", "plot", "species/crop", "season", "cycle", "batch"],
    keyAccounts: [{ accountNo: "124000", name: "Biological Assets (IAS 41)", why: "Growing crops / livestock at FVLCD" }, { accountNo: "120000", name: "Inventories — Raw Materials", why: "Seed, fertiliser, feed" }, { accountNo: "121000", name: "Finished Goods", why: "Harvested produce" }],
    accountingNotes: ["IAS 41: in-scope biological assets & produce at fair value less costs to sell at harvest", "Distinguish bearer plants, produce, other biological assets and harvested inventory", "Analyse mortality, disease losses, seasonal labour, grants, farmer advances separately"],
    closeControls: ["Opening count/qty + additions/births − sales/deaths/harvests = closing", "Test harvest quantities, valuations, perishable stock and input leakage"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "CIT at 1% (initial 5 yrs) — farming holiday", due: "Annual", authority: "GRA", section: "tax_schedule" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts"],
  },
  agro_processing: {
    manualRef: "Module 14/11 — Agro-processing & value-add food manufacturing",
    tagline: "BOM-driven processing: inputs → production → finished food products → sale.",
    flow: ["BOM per finished product (Bill of Materials)", "Input purchase (Procurement)", "Production order (Production Desk)", "Finished goods receipt (Inventory)", "Sale (Sales & Invoicing)", "Cost & variance reporting (Reports)"],
    modules: [
      { id: "boms", label: "Bill of Materials", reason: "Recipes / formulations" },
      { id: "production_desk", label: "Production Desk", reason: "Batches, WIP, yield" },
      { id: "inventory", label: "Inventory Command Desk", reason: "Inputs & finished food stock" },
      { id: "sales", label: "Sales & Invoicing", reason: "Finished goods sales" },
      { id: "tax_schedule", label: "Tax Desk", reason: "Excise / food-specific reliefs where applicable" },
    ],
    dimensions: ["item", "recipe/version", "batch", "machine", "production line", "warehouse"],
    keyAccounts: [{ accountNo: "500000", name: "Cost of Extraction & Processing", why: "Processing cost" }, { accountNo: "122000", name: "WIP", why: "In-process batches" }, { accountNo: "121000", name: "Finished Goods", why: "Packaged product" }],
    accountingNotes: ["IAS 2: include qualifying costs to present location/condition; allocate fixed overhead at normal capacity", "Expense abnormal waste / idle capacity — never hide in inventory", "Assess NRV of finished food stock"],
    closeControls: ["Reconcile raw materials → WIP → finished goods → sales/returns by batch", "Review yield, scrap, labour efficiency, overhead absorption, expiry"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "FDA / GSA product registration & food-safety", due: "Per licence", authority: "FDA / GSA", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  fisheries_aquaculture: {
    manualRef: "Module 16 — Fisheries, aquaculture & cold-chain seafood",
    tagline: "Vessel trip / pond cycle → catch measurement → landing & weighing → grading/processing → cold storage → dispatch → settlement.",
    flow: ["Vessel trip / pond cycle approval", "Fuel, feed & labour capture (Procurement / Expenses)", "Catch / biological measurement (Production Desk)", "Landing & weighing (Inventory)", "Grading / processing (Production Desk)", "Cold storage (Inventory)", "Dispatch / export (Sales)", "Settlement (Payment Desk)"],
    modules: [
      { id: "production_desk", label: "Production Desk", reason: "Trip / cycle costing, yield" },
      { id: "inventory", label: "Inventory Command Desk", reason: "Cold-store stock, batch" },
      { id: "sales", label: "Sales & Invoicing", reason: "Dispatch / export sales" },
      { id: "ifrs_desk", label: "IFRS Desk", reason: "IAS 41 aquaculture biological assets" },
    ],
    dimensions: ["vessel/trip", "pond/cycle", "batch", "cold-room", "customer", "species/grade"],
    keyAccounts: [{ accountNo: "124000", name: "Biological Assets", why: "Aquaculture stock" }, { accountNo: "120000", name: "Inventories", why: "Wild-capture fish at cost" }, { accountNo: "121000", name: "Finished Goods", why: "Processed / frozen product" }],
    accountingNotes: ["Distinguish wild-capture inventory from aquaculture biological assets", "Allocate qualifying trip/processing costs; review spoilage and NRV of frozen stock"],
    closeControls: ["Reconcile stocking/catch → landing → processed yield → cold-store → sales by species/grade", "Investigate catch-weight differences, by-catch, fuel variances, deterioration"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "Fisheries Commission licence & catch reports", due: "Per licence", authority: "Fisheries Commission", section: "compliance_review" }, { obligation: "Export / food-quality certification", due: "Per shipment", authority: "GSA / MOFAD", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts"],
  },
  // ---- Manufacturing / industry ----
  manufacturing_fmcg: {
    manualRef: "Module 11 — Manufacturing, food, pharma, cement & textiles",
    tagline: "Demand plan → BOM & routing → raw-material procurement → production order → FG inspection → dispatch → sale → cost & variance.",
    flow: ["Demand plan & BOM (Bill of Materials)", "Raw-material procurement (Procurement & P2P)", "Production order (Production Desk)", "Material / labour / overhead capture (Production Desk + HR + Expenses)", "Finished-goods inspection & receipt (Inventory)", "Dispatch & sale (Sales & Invoicing)", "Cost & variance reporting (Reports Centre)"],
    modules: [
      { id: "boms", label: "Bill of Materials", reason: "Components per unit + waste" },
      { id: "procurement", label: "Procurement & P2P", reason: "Raw-material purchasing" },
      { id: "production_desk", label: "Production Desk", reason: "Work orders, WIP, FG receipt" },
      { id: "inventory", label: "Inventory Command Desk", reason: "RM / WIP / FG stock" },
      { id: "sales", label: "Sales & Invoicing", reason: "Dispatch & invoicing" },
      { id: "reports", label: "Reports Centre", reason: "Contribution margin, unit cost, capacity" },
    ],
    dimensions: ["item", "recipe/version", "batch", "machine", "production line", "warehouse"],
    keyAccounts: [{ accountNo: "120000", name: "Raw Materials", why: "Consumed via BOM" }, { accountNo: "122000", name: "WIP", why: "Production in progress" }, { accountNo: "121000", name: "Finished Goods", why: "Sellable output" }, { accountNo: "504000", name: "COGS", why: "Standard vs actual variance" }],
    accountingNotes: ["IAS 2: qualifying costs + fixed overhead at normal capacity into inventory", "Expense abnormal waste & idle capacity", "Reconcile standard to actual cost; assess NRV; serial/lot traceability where relevant"],
    closeControls: ["Reconcile RM → WIP → FG → sales/returns by batch", "Review yield, scrap, labour efficiency, overhead absorption, expiry, recalls", "Scrutinise manual cost overrides"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "Excise duty / tax stamps where legally applicable to product", due: "Per GRA schedule", authority: "GRA", section: "tax_schedule" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  heavy_industry_steel: {
    manualRef: "Module 11 — Heavy industry, steel & cement",
    tagline: "BOM → production order → WIP → FG → dispatch; capital-intensive assets with units-of-production depreciation.",
    flow: ["BOM & routing", "Input procurement", "Production order", "WIP capture", "FG receipt", "Dispatch / sale", "Asset depreciation (units of production)", "Variance reporting"],
    modules: [
      { id: "boms", label: "Bill of Materials", reason: "Steel / cement recipes" },
      { id: "production_desk", label: "Production Desk", reason: "Work orders & WIP" },
      { id: "assets", label: "Fixed Assets Register", reason: "Heavy plant, UoP depreciation" },
      { id: "sales", label: "Sales & Invoicing", reason: "Dispatch sales" },
    ],
    dimensions: ["item", "batch", "machine", "line", "plant"],
    keyAccounts: [{ accountNo: "132000", name: "PPE — Plant & Machinery", why: "Heavy plant" }, { accountNo: "122000", name: "WIP", why: "In-process production" }, { accountNo: "121000", name: "Finished Goods", why: "Output" }],
    accountingNotes: ["Separate capital maintenance from routine repairs", "Units-of-production depreciation for plant", "IAS 2 costing with overhead absorption"],
    closeControls: ["RM → WIP → FG → sales reconciliation", "Overhead absorption & capacity utilisation review"],
    compliance: [...STANDARD_COMPLIANCE],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  pharmaceuticals_manufacturing: {
    manualRef: "Module 11/20 — Pharmaceutical manufacturing & distribution",
    tagline: "BOM (formulation) → batch production → quality release → finished pharma → dispatch; batch traceability & expiry control.",
    flow: ["Formulation BOM", "Input procurement (GMP materials)", "Batch production order", "Quality release", "FG receipt with batch/expiry", "Dispatch / sale", "Pharmacy stock & wastage reconciliation"],
    modules: [
      { id: "boms", label: "Bill of Materials", reason: "Formulations" },
      { id: "production_desk", label: "Production Desk", reason: "Batch production" },
      { id: "inventory", label: "Inventory Command Desk", reason: "Batch / expiry tracking" },
      { id: "sales", label: "Sales & Invoicing", reason: "Distribution sales" },
      { id: "tax_schedule", label: "Tax Desk", reason: "Pharma-specific reliefs / excise" },
    ],
    dimensions: ["item", "batch", "expiry", "machine", "clean-room", "warehouse"],
    keyAccounts: [{ accountNo: "121000", name: "Finished Goods", why: "Released batches" }, { accountNo: "505000", name: "Clinical Supplies & Pharmaceuticals", why: "Input cost" }],
    accountingNotes: ["Batch traceability and expiry are mandatory control dimensions", "Assess NRV for expired / near-expiry stock", "Quality release before stock becomes sellable"],
    closeControls: ["Reconcile dispensing/production to authorised wastage", "Expiry review of finished stock"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "FDA Ghana manufacturing licence & batch release", due: "Per licence", authority: "FDA Ghana", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  // ---- Construction & real estate ----
  construction_infrastructure: {
    manualRef: "Module 8 — Construction, engineering & long-term contracting",
    tagline: "Tender → contract → budget → procurement → site measurement → certification/billing → retention → completion & defects.",
    flow: ["Tender & approved estimate (CRM pipeline)", "Contract review (IFRS 15 over-time assessment)", "Project budget (Performance Management)", "Materials / subcontract procurement (Procurement)", "Site measurement & cost capture (Production Desk + Expenses)", "Progress certification / billing (Sales)", "Collection & retention (Payment Desk)", "Completion & defects review (Compliance Review)"],
    modules: [
      { id: "crm_desk", label: "Client Relationship Desk", reason: "Tenders & contracts pipeline" },
      { id: "performance", label: "Budgeting & Forecast", reason: "Project budgets & forecast margin" },
      { id: "procurement", label: "Procurement & P2P", reason: "Materials & subcontracts" },
      { id: "sales", label: "Sales & Invoicing", reason: "Progress billing / certificates" },
      { id: "payment_desk", label: "Payment Desk", reason: "Collections & retention release" },
      { id: "ifrs_desk", label: "IFRS Desk", reason: "IFRS 15 contract assets / retentions" },
    ],
    dimensions: ["project", "contract", "work package", "cost code", "subcontractor"],
    keyAccounts: [{ accountNo: "118000", name: "Capitalised Contract & Bid Costs", why: "Pre-contract costs" }, { accountNo: "118100", name: "Unbilled Contract Assets", why: "Earned not yet billed" }, { accountNo: "400000", name: "Revenue from contracts", why: "Over-time revenue" }, { accountNo: "200000", name: "Trade Payables", why: "Retentions & subcontractors" }],
    accountingNotes: ["IFRS 15: over-time recognition only after assessment; faithful progress measure", "Separate unbilled contract assets, receivables, advances, retentions", "Review onerous contracts, claims, penalties, warranty/defects (IAS 37)"],
    closeControls: ["Actual cost + forecast to complete vs latest approved estimate", "Margin movement & unapproved variations review", "Evidence before recognising disputed claims"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "Withholding on works contracts (5% resident)", due: "At payment", authority: "GRA", section: "payment_desk" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting", "advisory"],
  },
  real_estate_development: {
    manualRef: "Module 9 — Real-estate development, rental & facilities management",
    tagline: "Land/title due diligence → development budget → construction costs → unit allocation → sale/lease → handover → billing → service-charge accounting.",
    flow: ["Title due diligence & development budget", "Construction cost capture (CIP)", "Unit / phase allocation", "Sale or lease agreement (CRM)", "Handover / occupancy", "Billing & collection (Sales / Payment Desk)", "Service-charge accounting", "Portfolio reporting (Reports)"],
    modules: [
      { id: "crm_desk", label: "Client Relationship Desk", reason: "Sales & tenancy pipeline" },
      { id: "assets", label: "Fixed Assets Register", reason: "CIP → completed property; IAS 40 investment property" },
      { id: "inventory", label: "Inventory Command Desk", reason: "Development property as inventory" },
      { id: "sales", label: "Sales & Invoicing", reason: "Unit sales & rent billing" },
      { id: "ifrs_desk", label: "IFRS Desk", reason: "IAS 40 classification, deposits vs revenue" },
    ],
    dimensions: ["property", "phase", "unit", "tenant", "lease", "service charge"],
    keyAccounts: [{ accountNo: "121000", name: "Finished Goods (development units)", why: "Units held for sale" }, { accountNo: "141000", name: "Investment Property (IAS 40)", why: "Rental property held for rental / capital appreciation" }, { accountNo: "217000", name: "Refundable Tenant & Customer Deposits", why: "Deposits are liabilities, not revenue" }],
    accountingNotes: ["Classify as inventory vs investment property vs owner-occupied — not every building alike", "Deposits are not automatically revenue; document IAS 40 policy choice", "Revenue point for unit sales from the contract, not booking deposit"],
    closeControls: ["Reconcile each unit status to contracts, invoices, receipts, deposits", "NRV / valuation review of unsold units"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "Property rates / ground rent", due: "Annual", authority: "Local Assembly / GRA", section: "tax_schedule" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  // ---- Commerce & retail ----
  wholesale_retail_supermarket: {
    manualRef: "Module 13 — Multi-branch retail, e-commerce & marketplaces",
    tagline: "Product/pricing setup → branch receipt → POS/online order → fulfilment → settlement → returns → margin reporting.",
    flow: ["Product & pricing setup (Inventory)", "Purchase & branch receipt (Procurement)", "POS / online order (Sales)", "Delivery / collection confirmation", "Settlement by cash/card/mobile money (Payment Desk)", "Returns & refunds (Sales credit notes)", "Inventory & margin reporting (Reports)"],
    modules: [
      { id: "inventory", label: "Inventory Command Desk", reason: "SKU, branch stock, shrinkage" },
      { id: "sales", label: "Sales & Invoicing", reason: "POS / online orders & returns" },
      { id: "payment_desk", label: "Payment Desk", reason: "Processor settlement & till reconciliation" },
      { id: "procurement", label: "Procurement & P2P", reason: "Branch replenishment" },
      { id: "reports", label: "Reports Centre", reason: "Margin after fees/returns, settlement ageing" },
    ],
    dimensions: ["store/channel", "order", "SKU", "promotion", "processor"],
    keyAccounts: [{ accountNo: "120000", name: "Inventories", why: "Merchandise at branch" }, { accountNo: "400000", name: "Revenue", why: "Net of agent commissions (principal/agent)" }, { accountNo: "504000", name: "COGS", why: "Margin reporting" }],
    accountingNotes: ["Establish principal vs agent before grossing merchandise value as revenue", "Track gift cards, deposits, loyalty obligations, delivery charges, refunds", "Consignment: distinguish inventory ownership & commission"],
    closeControls: ["Orders → fulfilment → sales → processor settlement → bank receipts", "Branch transfers & return authorisations; limit price overrides & refund access"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "VAT registration threshold check (goods GHS 750,000)", due: "Continuous", authority: "GRA", section: "tax_schedule" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts"],
  },
  import_export_trade: {
    manualRef: "Module 12 — Import/export, wholesale distribution & bonded operations",
    tagline: "Contract & shipping terms → LC/FCY commitment → shipment → customs clearance → landed cost → domestic sale/export → FX & tax reconciliation.",
    flow: ["Contract & shipping terms (CRM)", "FCY commitment / letter of credit (Banking)", "Shipment & control-in-transit assessment", "Customs declaration / clearance (attachments)", "Receiving & landed-cost allocation (Inventory / Procurement)", "Domestic sale / export (Sales)", "Collection (Payment Desk)", "FX & tax reconciliation (Banking / Tax)"],
    modules: [
      { id: "procurement", label: "Procurement & P2P", reason: "Foreign supplier orders & clearing agents" },
      { id: "inventory", label: "Inventory Command Desk", reason: "Landed cost, lots, bonded status" },
      { id: "banking", label: "Banking & Reconcile", reason: "FCY accounts, IAS 21 revaluation" },
      { id: "sales", label: "Sales & Invoicing", reason: "Domestic & export sales" },
      { id: "tax_schedule", label: "Tax Desk", reason: "Customs duty, import VAT, exemptions" },
    ],
    dimensions: ["shipment/container", "customs reference", "currency", "stock lot", "bonded status"],
    keyAccounts: [{ accountNo: "120000", name: "Inventories", why: "Goods in transit when control passes" }, { accountNo: "126000", name: "Import Duty & Customs VAT Recoverable", why: "Recoverable import taxes" }, { accountNo: "200000", name: "Trade Payables", why: "Foreign suppliers (FCY)" }],
    accountingNotes: ["Recognise goods in transit only when control assessment supports it", "Allocate freight, insurance, duty, landing costs; separate recoverable import taxes", "Remeasure FCY monetary payables (IAS 21); inventory stays at historical cost"],
    closeControls: ["Supplier invoice → shipment → customs entry → warehouse receipt → payable & landed cost", "Report uncleared shipments, provisional landing costs, FX exposure"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "Customs entries & import declarations", due: "Per shipment", authority: "GRA Customs Division", section: "tax_schedule" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  // ---- Financial & fintech ----
  banking_finance: {
    manualRef: "Module 4 — Banks, SDIs & lending businesses",
    tagline: "Onboarding → deposit/loan approval → disbursement → daily interest & fees → receipts/allocation → arrears → ECL → regulatory reporting.",
    flow: ["Customer onboarding & credit approval", "Deposit / loan approval", "Disbursement (Payment Desk)", "Daily interest & fee processing (Manual Journal)", "Receipts & allocation (Payment Desk)", "Arrears monitoring (Ageing Analysis)", "ECL measurement (IFRS Desk — IFRS 9)", "BoG prudential & financial reporting (Reports)"],
    modules: [
      { id: "ifrs_desk", label: "IFRS Desk", reason: "IFRS 9 classification, ECL, EIR" },
      { id: "payment_desk", label: "Payment Desk", reason: "Disbursements & receipts" },
      { id: "ageing", label: "Ageing Analysis", reason: "Arrears & loan ageing" },
      { id: "banking", label: "Banking & Reconcile", reason: "Daily subledger→ledger→custodian reconciliation" },
      { id: "loans_desk", label: "Loan Amortisation", reason: "Contract-level schedules" },
    ],
    dimensions: ["contract", "facility", "collateral", "borrower"],
    keyAccounts: [{ accountNo: "110000", name: "Trade Receivables", why: "Loans at amortised cost" }, { accountNo: "119000", name: "Allowance for ECL", why: "IFRS 9 allowance (contra)" }, { accountNo: "216000", name: "Customer Deposits (Banking)", why: "Deposits are liabilities, not revenue" }],
    accountingNotes: ["IFRS 9: classification, EIR, SICR & credit-impaired assessment", "Deposits are liabilities; loan principal collected is not interest income", "Accounting impairment vs regulatory provisioning reconciled, not assumed equal"],
    closeControls: ["Daily core-banking → subledger → ledger → custodian confirmation", "Review interest suspense, restructurings, write-offs, model overlays"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "Bank of Ghana prudential returns", due: "Per BoG directives", authority: "Bank of Ghana", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  fintech_mobile_money: {
    manualRef: "Module 5 — Fintech, mobile money & payment service providers",
    tagline: "Merchant/agent onboarding → transaction → authorisation → processing → settlement file → merchant settlement → safeguarding & ledger reconciliation.",
    flow: ["Merchant / agent onboarding (Business Partners)", "Transaction initiation & authorisation", "Processing (trade engine)", "Settlement file (Banking)", "Merchant / agent settlement (Payment Desk)", "Fee allocation (Manual Journal)", "Refunds / chargebacks", "Daily safeguarding & ledger reconciliation (Banking / Ageing)"],
    modules: [
      { id: "banking", label: "Banking & Reconcile", reason: "Settlement bank & safeguarding" },
      { id: "payment_desk", label: "Payment Desk", reason: "Merchant / agent settlement" },
      { id: "ageing", label: "Ageing Analysis", reason: "Processor receivables, merchant payables" },
      { id: "ifrs_desk", label: "IFRS Desk", reason: "Wallet liabilities, clearing accounts" },
      { id: "compliance_review", label: "Compliance Review", reason: "BoG PSP/e-money licence safeguarding" },
    ],
    dimensions: ["merchant/agent", "processor", "settlement date", "transaction ID"],
    keyAccounts: [{ accountNo: "215000", name: "E-money / Wallet Liabilities", why: "Safeguarded customer funds — not revenue" }, { accountNo: "400000", name: "Fee income", why: "Contractual fee only — processed value is not revenue" }, { accountNo: "110000", name: "Processor receivables", why: "Settlement in transit" }],
    accountingNotes: ["Processed payment value is not the provider's revenue — recognise contractual fee", "Safeguarded funds: assess legal control before balance-sheet presentation", "Track merchant payables, wallet liabilities, processor receivables, disputed transactions separately"],
    closeControls: ["Reconcile successful/failed/reversed/pending transactions platform → processor → settlement bank → ledger by unique ID", "Investigate every unexplained safeguarding shortfall promptly"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "BoG PSP / e-money safeguarding & returns", due: "Per BoG requirements", authority: "Bank of Ghana", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  insurance_pensions: {
    manualRef: "Modules 6–7 — Insurance, reinsurance, funds & pensions",
    tagline: "Policy issuance → premiums → claims → actuarial measurement (IFRS 17) → CSM/RA → finance journals → NIC/NPRA reporting.",
    flow: ["Product / contract classification", "Policy issuance (Sales contracts)", "Premiums & acquisition cash flows", "Claims notification & data (CRM tickets)", "Actuarial measurement (IFRS Desk — IFRS 17)", "Finance journals (Manual Journal)", "Disclosure & regulator reporting (Reports)"],
    modules: [
      { id: "ifrs_desk", label: "IFRS Desk", reason: "IFRS 17 grouping, CSM, RA, PAA" },
      { id: "crm_desk", label: "CRM Desk", reason: "Policyholders & claims tickets" },
      { id: "payment_desk", label: "Payment Desk", reason: "Premium receipts & claim payments" },
      { id: "compliance_review", label: "Compliance Review", reason: "NIC / NPRA solvency & returns" },
    ],
    dimensions: ["policy/cohort", "treaty", "model version", "member (pensions)"],
    keyAccounts: [{ accountNo: "415000", name: "Insurance Premium Income (IFRS 17)", why: "Insurance revenue as service is provided" }, { accountNo: "231000", name: "Insurance Contract Liabilities (IFRS 17)", why: "LRC + LIC" }, { accountNo: "400000", name: "Fee / management income", why: "Funds — subscriptions are not fee revenue" }],
    accountingNotes: ["IFRS 17: grouping, fulfilment cash flows, risk adjustment, CSM, or PAA eligibility", "Premium cash received is not automatically revenue; onerous-group losses recognised", "Do not mix client/fund assets with the manager's operating assets"],
    closeControls: ["Bridge opening→closing LRC & LIC, cash flows, insurance service result", "Reconcile actuarial inputs to policy/claims records; validate model adjustments"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "NIC solvency & returns (insurance)", due: "Per NIC calendar", authority: "NIC", section: "compliance_review" }, { obligation: "NPRA pension scheme returns", due: "Per NPRA", authority: "NPRA", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  // ---- Technology & telecom ----
  telecommunications: {
    manualRef: "Module 18 — Telecom, ISPs & tower companies",
    tagline: "Tariff approval → subscriber/enterprise contract → usage capture → rating/billing → interconnect settlement → deferred revenue.",
    flow: ["Product & tariff approval", "Subscriber / enterprise contract (CRM)", "Recharge / service activation", "Usage capture (trade engine)", "Rating / billing (Sales)", "Interconnect / roaming settlement (Payment Desk)", "Collections", "Deferred revenue & network cost reporting (Reports)"],
    modules: [
      { id: "sales", label: "Sales & Invoicing", reason: "Rated billing, bundles" },
      { id: "crm_desk", label: "Client Relationship Desk", reason: "Enterprise contracts" },
      { id: "payment_desk", label: "Payment Desk", reason: "Interconnect / agent settlement" },
      { id: "ifrs_desk", label: "IFRS Desk", reason: "IFRS 15 multi-element allocation, prepaid breakage" },
      { id: "tax_schedule", label: "Tax Desk", reason: "CST 5% Class 1 providers (cascades into VAT base)" },
    ],
    dimensions: ["subscriber/product", "enterprise contract", "cell/site", "route", "tariff"],
    keyAccounts: [{ accountNo: "400000", name: "Revenue", why: "Allocated consideration" }, { accountNo: "225000", name: "Contract Liabilities (IFRS 15 Advances)", why: "Prepaid balances until earned / qualifying breakage" }, { accountNo: "223000", name: "CST liability", why: "Communications service tax" }],
    accountingNotes: ["Separate performance obligations: handsets, data, voice, installation", "Prepaid balances are obligations until earned or qualifying breakage", "Do not assume every bundled item has identical tax treatment (CST vs VAT)"],
    closeControls: ["Network usage → rating → billing → ledger & prepaid-wallet → cash", "Investigate unbilled events, free usage, discounts, settlement disputes"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "CST 5% (GRA-notified Class 1 providers)", due: "With monthly VAT", authority: "GRA", section: "tax_schedule" }, { obligation: "NCA licence & reporting", due: "Per licence", authority: "National Communications Authority", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  software_it_bpo: {
    manualRef: "Module 23 — Software, SaaS, IT implementation & digital platforms",
    tagline: "Contract → milestone/obligation assessment → time capture → delivery → subscription billing → revenue recognition → renewals.",
    flow: ["Contract approval (CRM)", "Obligation & milestone assessment (IFRS Desk — IFRS 15)", "Implementation / development time capture (HR tasks + Advisory timesheets)", "Activation / delivery", "Subscription billing (Sales)", "Revenue recognition (IFRS Desk)", "Renewals / refunds", "Project & recurring-revenue reporting (Reports)"],
    modules: [
      { id: "crm_desk", label: "Client Relationship Desk", reason: "Contracts & pipeline" },
      { id: "advisory", label: "Advisory & Timesheets", reason: "Time capture on projects" },
      { id: "sales", label: "Sales & Invoicing", reason: "Subscription & project billing" },
      { id: "ifrs_desk", label: "IFRS Desk", reason: "IFRS 15 allocation, capitalised development" },
      { id: "performance", label: "Budgeting & Forecast", reason: "Project profitability, churn" },
    ],
    dimensions: ["contract", "performance obligation", "subscription", "product version", "development project"],
    keyAccounts: [{ accountNo: "400000", name: "Revenue", why: "Recognised over time / at point" }, { accountNo: "225000", name: "Contract Liabilities (IFRS 15 Advances)", why: "Prepaid subscriptions until delivered" }, { accountNo: "118000", name: "Capitalised contract costs", why: "IFRS 15 incremental costs" }],
    accountingNotes: ["Distinguish licence vs hosted access vs implementation vs support", "Upfront fees are not automatically immediate revenue", "Assess whether development expenditure meets capitalisation criteria; cloud-arrangement costs; principal/agent"],
    closeControls: ["Active contracts & service periods → billings → deferred revenue → cash", "Verify eligible development costs vs approved time records"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "Cross-border digital-service tax assessment", due: "Per contract", authority: "GRA", section: "tax_schedule" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting", "advisory"],
  },
  // ---- Services & tourism ----
  hospitality_hotels: {
    manualRef: "Module 22 — Hotels, tourism, restaurants & events",
    tagline: "Reservation → deposit → room/service delivery → front-office & restaurant billing → night audit → channel settlement → levies.",
    flow: ["Reservation / event contract (CRM)", "Deposit", "Room / service delivery", "Front-office & restaurant billing (Sales)", "Daily night audit (Reports)", "Channel / agent settlement (Payment Desk)", "Cash & stock reconciliation (Banking / Inventory)", "Levy reporting (Tax)"],
    modules: [
      { id: "crm_desk", label: "Client Relationship Desk", reason: "Bookings & events" },
      { id: "sales", label: "Sales & Invoicing", reason: "Folio & F&B billing" },
      { id: "payment_desk", label: "Payment Desk", reason: "Channel / agent settlement" },
      { id: "inventory", label: "Inventory Command Desk", reason: "Kitchen/bar stock, food cost" },
      { id: "tax_schedule", label: "Tax Desk", reason: "Tourism Levy 1% (Tourism Act 817)" },
    ],
    dimensions: ["property", "room", "outlet", "event", "channel"],
    keyAccounts: [{ accountNo: "400000", name: "Accommodation & F&B revenue", why: "Recognised as nights/services provided" }, { accountNo: "224000", name: "Tourism Levy Payable", why: "1% on accommodation" }, { accountNo: "225000", name: "Contract Liabilities (IFRS 15 Advances)", why: "Booking deposits until the stay / cancellation" }],
    accountingNotes: ["Accommodation recognised as nights provided; event services per contract delivery", "Track deposits, cancellations, no-shows, vouchers, packages, loyalty", "Assess principal/agent on channel commissions — do not net against revenue automatically"],
    closeControls: ["Occupied rooms × approved rates → revenue; restaurant sales → kitchen/bar issues; channel statements → bank settlements", "Investigate comps, voids, refunds, stock losses"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "Tourism Development Levy 1% (Act 817)", due: "With monthly returns", authority: "Ghana Tourism Authority / GRA", section: "tax_schedule" }, { obligation: "GTA registration & returns", due: "Per licence", authority: "Ghana Tourism Authority", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts"],
  },
  healthcare_clinics: {
    manualRef: "Module 20 — Hospitals, clinics, labs & pharma distribution",
    tagline: "Patient registration → service authorisation → treatment record → charge capture → NHIS claim → remittance allocation → collections.",
    flow: ["Patient / customer registration (CRM contacts)", "Service authorisation", "Treatment / test / dispensing record", "Charge capture", "Patient or insurer / NHIS claim (Sales)", "Validation & submission", "Remittance allocation (Payment Desk)", "Rejection / credit review (CRM tickets)", "Collections"],
    modules: [
      { id: "crm_desk", label: "Client Relationship Desk", reason: "Patients, insurers, claim tickets" },
      { id: "sales", label: "Sales & Invoicing", reason: "Charges & claims billing" },
      { id: "payment_desk", label: "Payment Desk", reason: "Remittance allocation & collections" },
      { id: "inventory", label: "Inventory Command Desk", reason: "Pharmacy stock, expiry, wastage" },
      { id: "ifrs_desk", label: "IFRS Desk", reason: "IFRS 15 concessions, ECL on claims" },
    ],
    dimensions: ["department", "service", "payer", "claim", "medicine batch"],
    keyAccounts: [{ accountNo: "400000", name: "Patient / insurance revenue", why: "Net of expected concessions" }, { accountNo: "110000", name: "Receivables (NHIS / insurers)", why: "Claim ageing" }, { accountNo: "121000", name: "Pharmacy inventory", why: "Medicines at cost" }],
    accountingNotes: ["Assess contract terms, expected price concessions, rejected claims, credit losses separately", "Patient advances are not automatically revenue", "Track medicines, consignment, donated equipment, restricted funding; assess expiry & impairment", "Tax exemptions must be established for the specific supply, not assumed for all hospital income"],
    closeControls: ["Services performed → charges → claims submitted → approved/rejected → cash", "Dispensing → stock → authorised wastage", "Restrict patient-identifying data to authorised roles"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "NHIS / NHIA claims requirements", due: "Per claim cycle", authority: "NHIA", section: "compliance_review" }, { obligation: "FDA / Medical & Dental Council licensing", due: "Per licence", authority: "FDA / MDC", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
  },
  education_training: {
    manualRef: "Module 21 — Schools, universities, training & research",
    tagline: "Enrolment → student billing → term delivery → receipts & sponsorship allocation → revenue release → grants reporting.",
    flow: ["Programme / fee approval", "Enrolment (CRM)", "Student billing (Sales)", "Term / semester delivery", "Receipts & sponsorship allocation (Payment Desk)", "Revenue release over service period (IFRS Desk)", "Payroll & programme cost allocation", "Grants / research reporting (Reports)"],
    modules: [
      { id: "crm_desk", label: "Client Relationship Desk", reason: "Enrolment & sponsors" },
      { id: "sales", label: "Sales & Invoicing", reason: "Fee billing" },
      { id: "payment_desk", label: "Payment Desk", reason: "Receipts & bursary allocation" },
      { id: "ifrs_desk", label: "IFRS Desk", reason: "Deferred fee revenue over term" },
      { id: "payroll", label: "Payroll Desk", reason: "Staff & programme cost allocation" },
    ],
    dimensions: ["student account", "programme", "term", "campus", "sponsor", "research project"],
    keyAccounts: [{ accountNo: "400000", name: "Fee income", why: "Recognised over service period" }, { accountNo: "225000", name: "Contract Liabilities (IFRS 15 Advances)", why: "Unearned term fees" }, { accountNo: "232000", name: "Restricted Grants & Deferred Income", why: "Research / donor funding until conditions met" }],
    accountingNotes: ["Recognise fees over the relevant service period, not when term fees are paid", "Separate refundable deposits, accommodation, transport, bursaries, restricted research funding, endowments", "Assess scholarships/discounts and credit losses"],
    closeControls: ["Enrolled students → fee tables → billings → receipts → deferred revenue & debtors", "Research project expenditure → funder budgets & reports"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "Education regulator & funder reporting", due: "Per regulator", authority: "GES / NAB / funders", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts"],
  },
  professional_legal_advisory: {
    manualRef: "Module 24 — Professional services, consulting, legal, media & creative",
    tagline: "Engagement approval → scope/fee agreement → timesheets & costs → deliverable approval → revenue → billing → collections → project closure.",
    flow: ["Engagement / project approval (CRM)", "Scope & fee agreement", "Timesheets & third-party costs (Advisory)", "Deliverable / milestone approval", "Revenue assessment (IFRS Desk)", "Billing (Sales)", "Collections (Payment Desk)", "Project closure & rights tracking"],
    modules: [
      { id: "advisory", label: "Advisory & Timesheets", reason: "Time & cost capture" },
      { id: "crm_desk", label: "Client Relationship Desk", reason: "Engagements & clients" },
      { id: "sales", label: "Sales & Invoicing", reason: "Billing" },
      { id: "payment_desk", label: "Payment Desk", reason: "Collections; client-trust money kept separate" },
      { id: "ifrs_desk", label: "IFRS Desk", reason: "Fixed-fee / retainer / royalty revenue recognition" },
    ],
    dimensions: ["client", "engagement / content title", "service line", "milestone", "rights period"],
    keyAccounts: [{ accountNo: "400000", name: "Professional fee income", why: "Per engagement terms" }, { accountNo: "118100", name: "Unbilled work-in-progress", why: "Unbilled services" }, { accountNo: "219000", name: "Client Money / Trust Liabilities", why: "Held for clients — not revenue" }],
    accountingNotes: ["Analyse fixed-fee, time-based, retainer, advertising, royalty, licence separately", "Retainers and client trust money are not automatically revenue", "Review unbilled services, recoverability, contingent consideration, agency pass-through"],
    closeControls: ["Time & costs → approved deliverables → earned revenue → invoices → receipts", "Write-downs & overruns review; client-money reconciliation exceptions"],
    compliance: [...STANDARD_COMPLIANCE],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting", "advisory"],
  },
  // ---- Transport & infrastructure ----
  transport_logistics_shipping: {
    manualRef: "Module 19 — Transport, haulage, shipping, aviation, freight & warehousing",
    tagline: "Booking → route/voyage/shipment plan → fuel/handling procurement → trip movement → proof of delivery → job billing → settlements → job profitability.",
    flow: ["Booking / job approval (CRM)", "Route / voyage / shipment plan", "Fuel & handling procurement (Procurement)", "Trip movement", "Proof of delivery / carriage completion", "Job billing (Sales)", "Customer settlement (Payment Desk)", "Carrier / agent settlement", "Job profitability (Reports)"],
    modules: [
      { id: "crm_desk", label: "Client Relationship Desk", reason: "Bookings & jobs" },
      { id: "procurement", label: "Procurement & P2P", reason: "Fuel, handling, maintenance" },
      { id: "sales", label: "Sales & Invoicing", reason: "Job billing" },
      { id: "payment_desk", label: "Payment Desk", reason: "Customer & carrier settlement" },
      { id: "inventory", label: "Inventory Command Desk", reason: "Fuel stock, containers, warehouse" },
      { id: "reports", label: "Reports Centre", reason: "Job margin, fuel variance, claims ageing" },
    ],
    dimensions: ["vehicle/vessel/flight", "job", "route", "container", "shipment"],
    keyAccounts: [{ accountNo: "400000", name: "Carrier revenue", why: "Owned-carrier only; agent = commission" }, { accountNo: "225000", name: "Contract Liabilities (IFRS 15 Advances)", why: "Booking advances until carriage is provided" }, { accountNo: "623000", name: "Vehicle running costs", why: "Fuel allocated to jobs, not expensed by cash date" }],
    accountingNotes: ["Distinguish owned-carrier revenue from agent commissions & customer disbursements", "Ticket/booking receipts may be advance liabilities until service provided", "Assess demurrage, claims, fuel charges, container deposits, leased vehicles, major-component maintenance"],
    closeControls: ["Jobs booked → completed movements → invoiced → collections + accrued unbilled", "Fuel consumption → mileage/hours & approved allowances"],
    compliance: [...STANDARD_COMPLIANCE, { obligation: "DVLA / port / customs / aviation permits per activity", due: "Per authority", authority: "DVLA / GHA / GCAA / Customs", section: "compliance_review" }],
    services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts"],
  },
};

/** Fallback profile for any sector code not explicitly mapped. */
const FALLBACK: Omit<SectorProfile, "sectorCode" | "sectorName" | "category"> = {
  manualRef: "Common backbone (Sections 2–4)",
  tagline: "Standard procure-to-pay, order-to-cash, inventory, payroll, assets, treasury and reporting backbone.",
  flow: ["Master data & chart of accounts", "Procure to pay", "Order to cash", "Inventory & production", "Payroll to statutory settlement", "Assets, leases & projects", "Treasury & record to report", "Exception handling & period close"],
  modules: [
    { id: "procurement", label: "Procurement & P2P", reason: "Request → PO → receipt → match → pay" },
    { id: "sales", label: "Sales & Invoicing", reason: "Order → delivery → invoice → receipt" },
    { id: "inventory", label: "Inventory Command Desk", reason: "Stock movements & valuation" },
    { id: "payment_desk", label: "Payment Desk", reason: "Single treasury gateway" },
    { id: "payroll", label: "Payroll Desk", reason: "Payroll → PAYE/SSNIT settlement" },
    { id: "reports", label: "Reports Centre", reason: "TB, P&L, SFP, ageing, tax exposure" },
  ],
  dimensions: ["legal entity", "branch/site", "department", "project", "contract", "customer/supplier", "currency"],
  keyAccounts: [
    { accountNo: "120000", name: "Inventories", why: "Stock control" },
    { accountNo: "400000", name: "Revenue", why: "O2C" },
    { accountNo: "504000", name: "COGS", why: "Margin" },
  ],
  accountingNotes: ["Apply the common backbone; add sector modules when the business model requires them."],
  closeControls: ["Subledger → GL reconciliation; exception queue; period close after sign-off"],
  compliance: STANDARD_COMPLIANCE,
  services: ["bookkeeping", "payroll", "tax_compliance", "management_accounts", "ifrs_reporting"],
};

/** Resolve the full workflow profile for a sector code. */
export function sectorProfile(sectorCode: string): SectorProfile {
  const def = GHANA_ECONOMY_SECTORS.find((s) => s.code === sectorCode);
  const base = PROFILES[sectorCode] ?? FALLBACK;
  return {
    sectorCode,
    sectorName: def?.name ?? "General commerce & services",
    category: def?.category ?? "Commerce & Retail",
    ...base,
    modules: ['mining_metals','oil_gas_upstream','oil_gas_downstream','insurance_pensions','banking_finance','fintech_mobile_money','commercial_agric','fisheries_aquaculture','manufacturing_fmcg','heavy_industry_steel','pharmaceuticals_manufacturing','agro_processing','construction_infrastructure'].includes(sectorCode)
      ? [{ id: 'sector_regulation', label: 'Industry Measurement & Regulatory', reason: 'Native calculation, evidence, independent approval and controlled posting' }, ...base.modules]
      : base.modules,
  };
}

/** Resolve the profile for a client entity by matching its sector text. */
export function profileForClientSector(sectorText: string): SectorProfile {
  const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, " ").split(/\s+/).filter((w) => w.length > 3 && !["with", "from", "other"].includes(w));
  const words = new Set(normalize(sectorText));
  let best: { code: string; score: number } | null = null;
  for (const def of GHANA_ECONOMY_SECTORS) {
    const score = normalize(def.name).filter((w) => words.has(w)).length;
    if (!best || score > best.score) best = { code: def.code, score };
  }
  return sectorProfile(best && best.score > 0 ? best.code : "");
}

export const ALL_SECTOR_PROFILES: SectorProfile[] = GHANA_ECONOMY_SECTORS.map((s) => sectorProfile(s.code));
