/**
 * Idempotent DDL for the review extensions (performance management, IFRS
 * schedule workbooks and first-run activation). Mirrors the Drizzle
 * definitions in `src/db/schema.ts` (`entityWorkbooks`, `systemSettings`) so a
 * fresh database self-provisions exactly like the original tables do.
 */
export const EXTENSIONS_DDL: string[] = [
  `CREATE TABLE IF NOT EXISTS "entity_workbooks" (
    "id" text PRIMARY KEY NOT NULL,
    "client_id" integer NOT NULL,
    "kind" text NOT NULL,
    "key" text NOT NULL,
    "title" text DEFAULT '' NOT NULL,
    "payload" jsonb NOT NULL,
    "status" text DEFAULT 'draft' NOT NULL,
    "version" integer DEFAULT 1 NOT NULL,
    "prepared_by" text,
    "submitted_by" text,
    "approved_by" text,
    "approved_at" text,
    "review_comment" text,
    "created_at" timestamp with time zone DEFAULT now() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT now() NOT NULL
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "entity_workbooks_scope_idx" ON "entity_workbooks" USING btree ("client_id","kind","key")`,
  `CREATE TABLE IF NOT EXISTS "desk_records" (
    "id" text PRIMARY KEY NOT NULL,
    "client_id" integer NOT NULL,
    "desk" text NOT NULL,
    "kind" text NOT NULL,
    "payload" jsonb NOT NULL,
    "created_by" text NOT NULL,
    "updated_by" text,
    "created_at" timestamp with time zone DEFAULT now() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT now() NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS "desk_records_lookup_idx" ON "desk_records" USING btree ("client_id","desk","kind")`,
  `CREATE TABLE IF NOT EXISTS "system_settings" (
    "key" text PRIMARY KEY NOT NULL,
    "value" jsonb NOT NULL,
    "updated_at" timestamp with time zone DEFAULT now() NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS "bill_of_materials" (
    "id" text PRIMARY KEY NOT NULL,
    "client_id" integer NOT NULL,
    "parent_item_code" text NOT NULL,
    "component_item_code" text NOT NULL,
    "qty_per_unit" double precision NOT NULL,
    "uom" text NOT NULL,
    "waste_pct" double precision DEFAULT 0 NOT NULL,
    "active" boolean DEFAULT true NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS "bom_lookup_idx" ON "bill_of_materials" USING btree ("client_id","parent_item_code")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "bom_component_scope_idx" ON "bill_of_materials" USING btree ("client_id","parent_item_code","component_item_code")`,
  `CREATE TABLE IF NOT EXISTS "production_orders" (
    "id" text PRIMARY KEY NOT NULL,
    "client_id" integer NOT NULL,
    "doc_no" text NOT NULL,
    "item_code" text NOT NULL,
    "item_description" text NOT NULL,
    "qty" double precision NOT NULL,
    "uom" text NOT NULL,
    "status" text NOT NULL,
    "start_date" text NOT NULL,
    "end_date" text,
    "cost_center" text NOT NULL,
    "cost_center_name" text NOT NULL,
    "gl_wip_account" text NOT NULL,
    "gl_wip_account_name" text NOT NULL,
    "gl_finished_goods_account" text NOT NULL,
    "gl_finished_goods_account_name" text NOT NULL,
    "gl_raw_material_account" text NOT NULL,
    "gl_raw_material_account_name" text NOT NULL,
    "total_material_cost" double precision DEFAULT 0 NOT NULL,
    "total_conversion_cost" double precision DEFAULT 0 NOT NULL,
    "total_cost" double precision DEFAULT 0 NOT NULL,
    "created_by" text NOT NULL,
    "created_at" text NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS "production_orders_lookup_idx" ON "production_orders" USING btree ("client_id","status")`,
  `CREATE INDEX IF NOT EXISTS "production_orders_docno_idx" ON "production_orders" USING btree ("client_id","doc_no")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "production_orders_unique_doc_idx" ON "production_orders" USING btree ("client_id","doc_no")`,
  `CREATE TABLE IF NOT EXISTS "production_issues" (
    "id" text PRIMARY KEY NOT NULL,
    "client_id" integer NOT NULL,
    "production_order_id" text NOT NULL,
    "item_code" text NOT NULL,
    "item_description" text NOT NULL,
    "qty" double precision NOT NULL,
    "uom" text NOT NULL,
    "unit_cost" double precision NOT NULL,
    "total_cost" double precision NOT NULL,
    "issued_at" text NOT NULL,
    "issued_by" text NOT NULL,
    "stock_movement_id" text NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS "production_issues_lookup_idx" ON "production_issues" USING btree ("client_id","production_order_id")`,
  `CREATE TABLE IF NOT EXISTS "production_receipts" (
    "id" text PRIMARY KEY NOT NULL,
    "client_id" integer NOT NULL,
    "production_order_id" text NOT NULL,
    "item_code" text NOT NULL,
    "item_description" text NOT NULL,
    "qty" double precision NOT NULL,
    "uom" text NOT NULL,
    "unit_cost" double precision NOT NULL,
    "total_cost" double precision NOT NULL,
    "received_at" text NOT NULL,
    "received_by" text NOT NULL,
    "stock_movement_id" text NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS "production_receipts_lookup_idx" ON "production_receipts" USING btree ("client_id","production_order_id")`,
  // Performance indexes found by the volume stress test.
  `CREATE INDEX IF NOT EXISTS "journal_lines_doc_idx" ON "journal_lines" USING btree ("doc_no")`,
  `CREATE INDEX IF NOT EXISTS "journal_headers_doc_idx" ON "journal_headers" USING btree ("doc_no")`,
  `CREATE INDEX IF NOT EXISTS "audit_log_time_idx" ON "audit_log" USING btree ("timestamp" DESC)`,
  `CREATE INDEX IF NOT EXISTS "audit_log_client_time_idx" ON "audit_log" USING btree ("client_id","timestamp" DESC)`,
  `CREATE INDEX IF NOT EXISTS "stock_movements_client_doc_idx" ON "stock_movements" USING btree ("client_id","doc_no")`
];
