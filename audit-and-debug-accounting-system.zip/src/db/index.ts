import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error("DATABASE_URL is required");
}

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

const intEnv = (name: string, fallback: number) => {
  const value = Number(process.env[name]);
  return Number.isInteger(value) && value > 0 ? value : fallback;
};

/**
 * Production pool settings.
 *  - bounded size (BPZ_DB_POOL_MAX, default 20) so a traffic spike queues instead
 *    of exhausting PostgreSQL's connection limit;
 *  - a statement timeout so one runaway query cannot hold the global posting
 *    lock indefinitely, and an idle-in-transaction timeout so an abandoned
 *    transaction cannot block every other writer;
 *  - a connection timeout so requests fail fast (503) when the DB is down.
 */
export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: databaseUrl,
    max: intEnv("BPZ_DB_POOL_MAX", 20),
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: intEnv("BPZ_DB_CONNECT_TIMEOUT_MS", 10_000),
    statement_timeout: intEnv("BPZ_DB_STATEMENT_TIMEOUT_MS", 60_000),
    idle_in_transaction_session_timeout: intEnv("BPZ_DB_IDLE_TX_TIMEOUT_MS", 60_000),
    application_name: "bpz-consult-erp",
  });

// An idle client losing its connection (DB restart, network blip) emits 'error'
// on the pool. Unhandled, that event terminates the whole Node process.
if (!globalForDb.__arenaNextJsPostgresqlPool) {
  pool.on("error", (error) => {
    console.error("[db] idle PostgreSQL client error — connection discarded, pool continues", error.message);
  });
}

globalForDb.__arenaNextJsPostgresqlPool = pool;

export const db = drizzle(pool);
