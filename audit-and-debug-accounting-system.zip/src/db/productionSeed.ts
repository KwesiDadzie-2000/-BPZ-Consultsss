import type { Tx } from "@/db/seedData";
import { INITIAL_CHART_OF_ACCOUNTS } from "@/data/accountingSeed";
import { chartAccounts, clients, systemSettings, users } from "@/db/schema";

/**
 * Clean first-run bootstrap for a live deployment. No demonstration clients,
 * users, journal entries, balances, banking details, identifiers, or statements
 * are copied into a production database.
 *
 * Deliberately requires a setup token BEFORE the first request is served: a
 * publicly accessible first-run activation without one is a takeover window.
 */
export async function seedProductionInto(tx: Tx): Promise<void> {
  const setupToken = process.env.BPZ_SETUP_TOKEN ?? "";
  const email = (process.env.BPZ_OWNER_EMAIL ?? "").trim().toLowerCase();
  if (setupToken.length < 24) {
    throw new Error("Production bootstrap requires BPZ_SETUP_TOKEN (at least 24 characters).");
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error("Production bootstrap requires a valid BPZ_OWNER_EMAIL.");
  }

  await tx.insert(users).values({
    id: "owner",
    username: "owner",
    email,
    name: "Firm Owner",
    role: "owner",
    makerLimit: 1_000_000_000,
    canCheck: true,
    clientId: null,
    passwordHash: null,
    passwordSalt: null,
    status: "active",
    permissions: {
      canPostJournals: true,
      canApprovePayments: true,
      canRunPayroll: true,
      canClosePeriod: true,
      canModifyCOA: true,
    },
  });
  await tx.insert(systemSettings).values({
    key: "owner_activation",
    value: { pending: true, ownerUsername: "owner" },
  });

  await tx.insert(clients).values({
    id: 1,
    code: "HQ",
    name: "Firm Management (set legal name in Company Profile)",
    sector: "Professional Services / Advisory",
    currency: "GHS",
    jurisdiction: "GH",
    regNumber: "",
    isParent: true,
    assignedServices: null,
  });

  // Start with the same accounting chart, but ZERO opening balances/transactions.
  // Entries are master data only and can be tailored per entity after activation.
  await tx.insert(chartAccounts).values(INITIAL_CHART_OF_ACCOUNTS.map((account) => ({
    accountNo: account.accountNo,
    name: account.name,
    type: account.type,
    category: account.category,
    active: account.active ?? true,
    isCustom: false,
    clientId: null,
  })));
}
