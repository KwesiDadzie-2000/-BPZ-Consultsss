import "dotenv/config";
import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { loginAttempts, sessions, users } from "@/db/schema";
import { hashPassword, newSalt, passwordPolicyError } from "@/lib/password";

/**
 * Break-glass credential reset for when the owner account itself is locked out
 * (in-app resets live in Owner Administration → User Permissions).
 *
 *   npx tsx src/db/reset-password.ts <username-or-email> '<NewPassword1!>'
 *
 * Hashes with scrypt, re-activates the account and revokes its open sessions.
 */
async function main() {
  const [identifierArg, password] = process.argv.slice(2);
  if (!identifierArg || !password) {
    console.error("Usage: npx tsx src/db/reset-password.ts <username-or-email> '<NewPassword1!>'");
    process.exit(2);
  }
  const policyError = passwordPolicyError(password);
  if (policyError) {
    console.error(`Rejected: ${policyError}`);
    process.exit(2);
  }
  await ensureDatabaseReady();
  const identifier = identifierArg.trim().toLowerCase();
  const found = await db
    .select()
    .from(users)
    .where(or(eq(users.username, identifier), eq(users.email, identifier)))
    .limit(1);
  const user = found[0];
  if (!user) {
    console.error(`No account matches "${identifierArg}".`);
    process.exit(1);
  }
  const salt = newSalt();
  await db
    .update(users)
    .set({ passwordSalt: salt, passwordHash: await hashPassword(password, salt), status: "active", restrictionReason: null })
    .where(eq(users.id, user.id));
  await db.delete(sessions).where(eq(sessions.userId, user.id));
  await db.delete(loginAttempts).where(or(eq(loginAttempts.identifier, user.username), eq(loginAttempts.identifier, user.email)));
  console.log(`Password reset for "${user.username}" (${user.role}). Account active; existing sessions and lockouts cleared.`);
}

main().then(() => process.exit(0)).catch((e) => {
  console.error(e);
  process.exit(1);
});
