import { randomUUID } from 'node:crypto';
import { and, eq } from 'drizzle-orm';
import type { Tx } from '@/db/seedData';
import { auditLog, chartAccounts, closedPeriods, journalHeaders, journalLines, postingEvents, users, clients } from '@/db/schema';
import { accountPostabilityFor, postingUserDirectory, sessionPostingRecord } from '@/lib/postingControls';
import { validateJournalLines, validateMakerChecker, validatePostingIdentity } from '@/lib/journalValidation';
import { buildJournalHeader, buildPostingEvent } from '@/lib/journalPosting';
import type { ACDOCALine, UserAccount } from '@/types/accounting';

/** Atomic, tenant-scoped posting under the SAME caller-held ledger lock. */
export async function postEntityJournal(tx: Tx, user: UserAccount, entity: typeof clients.$inferSelect, lines: ACDOCALine[], action: string) {
  const [coa, periods, directoryRows] = [
    await tx.select().from(chartAccounts),
    await tx.select().from(closedPeriods).where(eq(closedPeriods.clientId, entity.id)),
    await tx.select().from(users),
  ];
  const directory = postingUserDirectory(directoryRows);
  const error = validateJournalLines(lines, { allowedClientIds: [entity.id], closedPeriodKeys: new Set(periods.map((p) => `${p.clientId}:${p.period}`)),
    coaAccountNos: new Set(coa.filter((a) => a.clientId === null || a.clientId === entity.id).map((a) => a.accountNo)), isAccountPostable: accountPostabilityFor(coa) })
    || validatePostingIdentity(lines, { session: sessionPostingRecord(user), users: directory })
    || validateMakerChecker(lines, { username: user.username, makerLimit: user.makerLimit, users: directory });
  if (error) throw new Error(error);
  const header = buildJournalHeader(lines);
  const duplicate = (await tx.select().from(journalHeaders).where(and(eq(journalHeaders.clientId, entity.id), eq(journalHeaders.docNo, lines[0].docNo))).limit(1))[0];
  if (duplicate) throw new Error('This document was already posted. Refresh before retrying.');
  await tx.insert(journalLines).values(lines);
  await tx.insert(journalHeaders).values(header);
  await tx.insert(postingEvents).values(buildPostingEvent(lines, user.username));
  await tx.insert(auditLog).values({ id: randomUUID(), timestamp: new Date().toISOString(), userId: user.username, username: user.username,
    action, target: lines[0].docNo, details: `${lines.length} lines; debit ${header.debitTotal.toFixed(2)} ${entity.currency}`, clientId: entity.id });
}
