/**
 * Bounded JSON request reader.
 *
 * Route handlers previously called `req.json()` with no size limit, so a single
 * oversized or hostile request could make the server buffer and parse an
 * arbitrarily large body. This reader rejects early on a declared
 * Content-Length and again on the actual body length.
 */
export class RequestBodyError extends Error {
  constructor(message: string, readonly status: 400 | 413) { super(message); }
}

export async function readJsonBody<T = unknown>(req: Request, maxBytes: number): Promise<T> {
  const declared = Number(req.headers.get('content-length') ?? '');
  if (Number.isFinite(declared) && declared > maxBytes) {
    throw new RequestBodyError(`Request body exceeds the ${Math.round(maxBytes / 1024)} KB limit.`, 413);
  }
  const text = await req.text();
  if (text.length > maxBytes) {
    throw new RequestBodyError(`Request body exceeds the ${Math.round(maxBytes / 1024)} KB limit.`, 413);
  }
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new RequestBodyError('Invalid JSON payload.', 400);
  }
}

/** Payload ceilings per route (bytes). */
export const BODY_LIMITS = {
  login: 16 * 1024,
  journal: 2 * 1024 * 1024,
  // A full workspace sync legitimately carries masters, registers and stock; the
  // journal itself is now sent as a delta, so 25 MB is generous headroom.
  state: 25 * 1024 * 1024,
  users: 64 * 1024,
} as const;
