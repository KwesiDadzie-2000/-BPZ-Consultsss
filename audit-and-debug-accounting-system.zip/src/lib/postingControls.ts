import type { chartAccounts, users } from "@/db/schema";
import type { ACDOCALine, UserAccount } from "@/types/accounting";
import type { PostingUserRecord } from "@/lib/journalValidation";
import { CONTROL_ACCOUNT_DEFINITIONS } from "@/utils/controlAccounts";

const PROTECTED_CONTROLS = new Set(CONTROL_ACCOUNT_DEFINITIONS.filter((d) => d.lockDirectManualEntry).map((d) => d.accountNo));
/** Staff must use the owning subledger; privileged reconciliation adjustments remain possible. */
export function validateControlAccountAuthority(lines: readonly ACDOCALine[], role: string): string | null {
  if (['owner', 'manager', 'partner'].includes(role)) return null;
  const hit = lines.find((l) => l.docType === 'JE' && PROTECTED_CONTROLS.has(l.accountNo) &&
    !/^(DOC-OPEN-BAL|OPEN-|YE-CLOSE-)/.test(l.docNo));
  return hit ? `Account ${hit.accountNo} is a protected subledger control account. Post through its operational desk or request a controller reconciliation adjustment.` : null;
}

type UserRow = typeof users.$inferSelect;
type AccountRow = typeof chartAccounts.$inferSelect;

/** Username → posting record, for maker-limit resolution and checker vetting. */
export function postingUserDirectory(rows: readonly UserRow[]): Map<string, PostingUserRecord> {
  return new Map(
    rows.map((row) => [
      row.username,
      { username: row.username, role: row.role, makerLimit: row.makerLimit, canCheck: row.canCheck, status: row.status, clientId: row.clientId, canPostJournals: (row.permissions as UserAccount['permissions'])?.canPostJournals },
    ]),
  );
}

export function sessionPostingRecord(user: UserAccount): PostingUserRecord {
  return { username: user.username, role: user.role, makerLimit: user.makerLimit, canCheck: user.canCheck, status: user.status ?? "active", clientId: user.clientId, canPostJournals: user.permissions?.canPostJournals };
}

/**
 * Account postability: an account may be posted to by an entity only when it is
 * ACTIVE and is either a firm-master account (clientId null) or that entity's own
 * tailored account. Where an entity has tailored a master account, the entity's
 * version governs (a deactivated tailored copy blocks posting for that entity).
 */
export function accountPostabilityFor(accounts: readonly AccountRow[]): (accountNo: string, clientId: number) => boolean {
  const master = new Map<string, boolean>();
  const tailored = new Map<string, boolean>();
  for (const account of accounts) {
    if (account.clientId === null) master.set(account.accountNo, account.active);
    else tailored.set(`${account.clientId}:${account.accountNo}`, account.active);
  }
  return (accountNo, clientId) => {
    const own = tailored.get(`${clientId}:${accountNo}`);
    if (own !== undefined) return own;
    const shared = master.get(accountNo);
    return shared === true;
  };
}
