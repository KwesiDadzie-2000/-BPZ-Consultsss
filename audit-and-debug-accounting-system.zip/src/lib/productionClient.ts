"use client";

import { useCallback, useEffect, useState } from "react";
import type { BillOfMaterial, ProductionIssue, ProductionOrder, ProductionReceipt } from "@/types/accounting";
import { apiFetch } from "@/utils/session";

export type ProductionAction =
  | "save_bom" | "remove_bom" | "create_order" | "release_order"
  | "issue_material" | "record_conversion" | "receive_output" | "close_order";

export interface ProductionState {
  boms: BillOfMaterial[];
  orders: ProductionOrder[];
  issues: ProductionIssue[];
  receipts: ProductionReceipt[];
  wipByOrder: Record<string, number>;
  legacyCount: number;
}

const EMPTY: ProductionState = { boms: [], orders: [], issues: [], receipts: [], wipByOrder: {}, legacyCount: 0 };

export function useProduction(clientId: number, onServerMutation?: () => Promise<void>) {
  const [state, setState] = useState<ProductionState>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // `loading` starts true; later refreshes keep the current view while fetching.
  const reload = useCallback(async () => {
    try {
      const response = await apiFetch(`/api/production?clientId=${clientId}`);
      const data = await response.json().catch(() => null);
      if (!response.ok || !data?.ok) throw new Error(data?.error || "Production data could not be loaded.");
      setState({ boms: data.boms ?? [], orders: data.orders ?? [], issues: data.issues ?? [],
        receipts: data.receipts ?? [], wipByOrder: data.wipByOrder ?? {}, legacyCount: data.legacyCount ?? 0 });
      setError(null);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Production data could not be loaded.");
    } finally {
      setLoading(false);
    }
  }, [clientId]);

  // Initial load with a cancellation guard: a slow response for a previous
  // entity can never overwrite the production view of the entity now open.
  useEffect(() => {
    let cancelled = false;
    apiFetch(`/api/production?clientId=${clientId}`)
      .then(async (response) => ({ response, data: await response.json().catch(() => null) }))
      .then(({ response, data }) => {
        if (cancelled) return;
        if (!response.ok || !data?.ok) throw new Error(data?.error || "Production data could not be loaded.");
        setState({ boms: data.boms ?? [], orders: data.orders ?? [], issues: data.issues ?? [],
          receipts: data.receipts ?? [], wipByOrder: data.wipByOrder ?? {}, legacyCount: data.legacyCount ?? 0 });
        setError(null);
      })
      .catch((cause) => { if (!cancelled) setError(cause instanceof Error ? cause.message : "Production data could not be loaded."); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [clientId]);

  const run = useCallback(async (
    action: ProductionAction, payload: Record<string, unknown>, requestKey?: string,
  ): Promise<{ ok: boolean; error?: string; idempotent?: boolean; order?: ProductionOrder; docNo?: string }> => {
    if (busy) return { ok: false, error: "An action is already in progress." };
    setBusy(true);
    setError(null);
    try {
      const response = await apiFetch("/api/production", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ clientId, action, payload, requestKey }),
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data?.ok) {
        const message = data?.error || `Production action failed (HTTP ${response.status}). Nothing was posted.`;
        setError(message);
        return { ok: false, error: message };
      }
      await reload();
      if (onServerMutation && (action === "issue_material" || action === "record_conversion" || action === "receive_output" || action === "create_order")) {
        await onServerMutation(); // Pull authoritative stock/journal before browser's next state sync.
      }
      return data;
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Network failure; retry with the same request key to avoid duplicates.";
      setError(message);
      return { ok: false, error: message };
    } finally {
      setBusy(false);
    }
  }, [busy, clientId, reload, onServerMutation]);

  return { ...state, loading, busy, error, reload, run, clearError: () => setError(null) };
}
