import type { StockItem } from '@/types/accounting';

/** Production quantities are stored at three decimal places; money in cents. */
export function productionQty(value: number): number {
  return Math.round(value * 1000) / 1000;
}
export function productionMoney(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

/** Planned requirement for an entire order, including explicitly authorised normal waste. */
export function plannedComponentQty(orderQty: number, perUnit: number, wastePct: number): number {
  return productionQty(orderQty * perUnit * (1 + wastePct / 100));
}

/**
 * Allocate available WIP to a partial output receipt. The last output receipt
 * clears every remaining cent, so completed work orders do not leave a rounding
 * residue in account 122000. New conversion costs added later remain in WIP for
 * later receipts, not retroactively allocated to already-received output.
 */
export function finishedReceiptCost(availableWip: number, outputQty: number, remainingQty: number): number {
  if (!Number.isFinite(availableWip) || availableWip <= 0 || !Number.isFinite(outputQty) || !Number.isFinite(remainingQty)
    || outputQty <= 0 || outputQty > remainingQty + 0.0001) {
    throw new Error('A finished-goods receipt needs available WIP and a quantity no greater than the open order.');
  }
  const cents = Math.round(availableWip * 100);
  const final = remainingQty - outputQty <= 0.0001;
  const allocated = final ? cents : Math.round(cents * (outputQty / remainingQty));
  if (allocated <= 0 || allocated > cents) throw new Error('The WIP allocation is too small or exceeds available WIP.');
  return allocated / 100;
}

/** Adds received output without rounding the value away through unit-cost math. */
export function receiveFinishedItem(item: StockItem, quantity: number, cost: number): StockItem {
  if (!Number.isFinite(quantity) || quantity <= 0 || !Number.isFinite(cost) || cost <= 0) {
    throw new Error('A finished-goods receipt needs a positive quantity and a positive WIP cost.');
  }
  const quantityOnHand = productionQty(item.quantityOnHand + quantity);
  const totalValue = productionMoney(item.totalValue + cost);
  return { ...item, quantityOnHand, totalValue, unitCost: productionMoney(totalValue / quantityOnHand) };
}
