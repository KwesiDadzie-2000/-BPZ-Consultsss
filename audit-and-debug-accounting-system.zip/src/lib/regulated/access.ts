import { profileForClientSector } from '@/data/sectorProfiles';
import type { SectorDomain } from './engines';
export function sectorDomains(sectorName: string): SectorDomain[] {
  const code=profileForClientSector(sectorName).sectorCode;
  if(code==='mining_metals')return ['mining'];
  if(code.startsWith('oil_gas'))return ['petroleum'];
  if(code==='insurance_pensions')return ['insurance','pension'];
  if(['banking_finance','fintech_mobile_money'].includes(code))return ['financial'];
  if(['commercial_agric','fisheries_aquaculture'].includes(code))return ['agriculture'];
  if(['manufacturing_fmcg','heavy_industry_steel','pharmaceuticals_manufacturing','agro_processing','renewable_energy','construction_infrastructure'].includes(code))return ['manufacturing'];
  return [];
}
export const DOMAIN_LABELS:Record<SectorDomain,string>={mining:'Mineral royalties',petroleum:'Petroleum levies & fiscal terms',insurance:'IFRS 17 contract groups',financial:'IFRS 9 & prudential measures',pension:'Pension custody & units',agriculture:'IAS 41 biological assets',manufacturing:'Material requirements (MRP)'};
