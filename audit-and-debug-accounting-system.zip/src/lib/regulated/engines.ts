/* Native sector measurement kernels. Amounts are rounded to cents at document
 * boundaries; probabilities/rates are percentages. These are accounting working
 * papers, NOT regulator filing certifications. Rules require source evidence.
 */
export type SectorDomain = 'mining' | 'petroleum' | 'insurance' | 'financial' | 'pension' | 'agriculture' | 'manufacturing';
export interface RuleBand { upper: number | null; ratePct: number }
export interface SourceRule { reference: string; effectiveFrom: string; effectiveTo?: string; approvedBy?: string }
export interface MeasurementLeg { accountNo: string; debit: number; credit: number; label: string }
export interface MeasurementResult { domain: SectorDomain; title: string; values: Record<string, number>; rows: (string | number)[][]; legs: MeasurementLeg[]; warnings: string[]; filingReady: false }
export interface SectorInput { domain: SectorDomain; asAt: string; source: SourceRule; data: Record<string, unknown> }
const finite = (v: unknown, label: string, min = 0, max = 1e12): number => {
  const n = Number(v); if (!Number.isFinite(n) || n < min || n > max) throw new Error(`${label} must be between ${min} and ${max}.`); return n;
};
const integer = (v: unknown, label: string, min = 0, max = 1e9) => { const n = finite(v,label,min,max); if (!Number.isInteger(n)) throw new Error(`${label} must be a whole number.`); return n; };
export const money = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const pct = (v: unknown, label: string) => finite(v,label,0,100);
const date = (v: unknown, label: string) => { const s=String(v||''); const d=new Date(`${s}T00:00:00Z`); if(!/^\d{4}-\d{2}-\d{2}$/.test(s)||!Number.isFinite(d.getTime())||d.toISOString().slice(0,10)!==s) throw new Error(`${label} must be a valid YYYY-MM-DD date.`); return s; };
const text = (v: unknown,label:string) => { const s=String(v||'').trim(); if(s.length<3||s.length>500) throw new Error(`${label} requires a source/reference of 3–500 characters.`); return s; };
const list = (v: unknown,label:string,max=1000): Record<string,unknown>[] => { if(!Array.isArray(v)||v.length>max||v.some(x=>!x||typeof x!=='object'||Array.isArray(x))) throw new Error(`${label} must be an array of at most ${max} records.`); return v; };
function bands(v:unknown): RuleBand[] { const rows=list(v,'Royalty bands',100).map(r=>({upper:r.upper==null?null:finite(r.upper,'Band ceiling',0,1e8),ratePct:pct(r.ratePct,'Band rate')})); if(!rows.length||rows[rows.length-1].upper!==null) throw new Error('Royalty bands need a final unbounded band.'); for(let i=1;i<rows.length;i++) if(rows[i].upper!==null&&Number(rows[i-1].upper)>=Number(rows[i].upper)) throw new Error('Royalty band ceilings must increase.'); return rows; }
function legs(items:MeasurementLeg[]) { const out=items.filter(l=>l.debit||l.credit).map(l=>({...l,debit:money(l.debit),credit:money(l.credit)})); const dr=out.reduce((s,l)=>s+Math.round(l.debit*100),0),cr=out.reduce((s,l)=>s+Math.round(l.credit*100),0); if(dr!==cr) throw new Error('Measurement journal does not balance.'); return out; }
const result=(domain:SectorDomain,title:string,values:Record<string,number>,rows:(string|number)[][],items:MeasurementLeg[]=[],warnings:string[]=[]):MeasurementResult=>({domain,title,values,rows,legs:legs(items),warnings,filingReady:false});

export function computeSector(input:SectorInput):MeasurementResult {
  const asAt=date(input.asAt,'Measurement date'); const from=date(input.source?.effectiveFrom,'Rule effective date');
  text(input.source?.reference,'Legal/contract/actuarial source'); if(from>asAt||(input.source.effectiveTo&&date(input.source.effectiveTo,'Rule expiry')<asAt)) throw new Error('The cited rule is not effective on the measurement date.');
  const d=input.data||{};
  if(input.domain==='mining') {
    const quantity=finite(d.quantity,'Payable quantity',0.000001),price=finite(d.referencePrice,'Reference price'),fx=finite(d.fxRate,'FX to entity currency',0.000001);
    const table=bands(d.bands); const band=table.find(b=>b.upper===null||price<=Number(b.upper))!;
    const gross=money(quantity*price*fx),royalty=money(gross*band.ratePct/100);
    const gslPct=pct(d.gslPct??0,'GSL rate'); const gslBase=finite(d.gslBase??0,'GSL statutory base'); const gsl=money(gslBase*gslPct/100);
    return result('mining','Mineral royalty & levy accrual',{quantity,price,fx,gross,ratePct:band.ratePct,royalty,gsl,total:money(royalty+gsl)},[['Payable quantity',quantity],['Reference price',price],['FX',fx],['Royalty base',gross],['Royalty %',band.ratePct],['Royalty',royalty],['GSL base',gslBase],['GSL',gsl]],[{accountNo:'507000',debit:royalty,credit:0,label:'Mineral royalty expense'},{accountNo:'691200',debit:gsl,credit:0,label:'Growth & sustainability levy'},{accountNo:'227000',debit:0,credit:money(royalty+gsl),label:'Royalty & sector levies payable'}],['Confirm assay, payable-metal terms, price index/averaging window, FX source and any stability/development agreement.']);
  }
  if(input.domain==='petroleum') {
    const litres=finite(d.litres,'Litres',0.000001); const schedule=list(d.levies,'NPA levy schedule',40).map(r=>({name:text(r.name,'Levy name'),perLitre:finite(r.perLitre,'Levy per litre',0,1000),accountNo:String(r.accountNo||'227000')}));
    if(!schedule.length)throw new Error('Enter the applicable pricing-window levy schedule.');
    const rows=schedule.map(r=>[r.name,r.perLitre,litres,money(litres*r.perLitre)] as (string|number)[]); const total=money(rows.reduce((s,r)=>s+Number(r[3]),0));
    const items:MeasurementLeg[]=[{accountNo:'507000',debit:total,credit:0,label:'Petroleum levies expense'},...schedule.map(r=>({accountNo:r.accountNo,debit:0,credit:money(litres*r.perLitre),label:r.name}))];
    // Optional contractual cost-recovery/profit-oil fiscal calculation.
    const recoverable=finite(d.recoverableCosts??0,'Recoverable cost pool'),grossRevenue=finite(d.grossRevenue??0,'Gross petroleum revenue');
    const capPct=pct(d.costRecoveryCapPct??100,'Cost recovery cap'); const recovered=money(Math.min(recoverable,grossRevenue*capPct/100));
    const profitOil=money(Math.max(0,grossRevenue-recovered)); const tiers=list(d.profitTiers??[],'Contract profit-oil tiers',30);
    if(tiers.length){if(tiers[tiers.length-1].upper!=null)throw new Error('Profit-oil tiers require a final unbounded band.');for(let i=1;i<tiers.length;i++)if(tiers[i].upper!=null&&Number(tiers[i-1].upper)>=Number(tiers[i].upper))throw new Error('Profit-oil tier ceilings must increase.');}
    let remaining=profitOil,gov=0,previous=0;
    for(const t of tiers){const upper=t.upper==null?Infinity:finite(t.upper,'Tier ceiling');const share=pct(t.contractorPct,'Contractor profit share');const tranche=Math.max(0,Math.min(remaining,upper-previous));gov=money(gov+tranche*(100-share)/100);remaining=money(remaining-tranche);previous=upper;}
    gov=money(gov+remaining); // no approved tier for residual => government retains residual, never silently zero.
    if(grossRevenue)rows.push(...([['Cost recovery cap %',capPct],['Recovered costs',recovered],['Profit oil',profitOil],['Government profit share',gov],['Contractor profit share',money(profitOil-gov)]] as (string|number)[][]));
    return result('petroleum','Petroleum levies & contractual fiscal split',{litres,total,recovered,profitOil,governmentProfit:gov,contractorProfit:money(profitOil-gov)},rows,items,['Use the official NPA/OMC pricing-window schedule; pump-price floors are NOT levy rates.','Profit-oil tiers and recoverable costs must follow the executed petroleum agreement.']);
  }
  if(input.domain==='insurance') {
    const model=String(d.model||'GMM'); if(!['GMM','PAA'].includes(model))throw new Error('Supported models: GMM and eligible PAA. VFA/reinsurance require a separate validated model.');
    const scenarios=model==='GMM'?list(d.scenarios,'Probability-weighted cash-flow scenarios',100):[]; let probability=0,pvOut=0,pvIn=0;
    const rows:(string|number)[][]=[];
    if(model==='GMM') for(const s of scenarios){const p=finite(s.probability,'Scenario probability',0,1);probability+=p;const flows=list(s.flows,'Scenario cash flows',240);let out=0,inc=0;for(const f of flows){const years=finite(f.years,'Years from measurement',0,100);const rate=finite(f.discountPct??0,'Discount rate',0,100)/100;const factor=Math.pow(1+rate,-years);out+=finite(f.outflow,'Cash outflow')*factor;inc+=finite(f.inflow,'Cash inflow')*factor;}pvOut+=p*out;pvIn+=p*inc;rows.push([String(s.name||'Scenario'),p,money(out),money(inc)]);}
    if(model==='GMM'&&Math.abs(probability-1)>1e-8)throw new Error('Scenario probabilities must sum to 1.');
    const ra=finite(d.riskAdjustment??(model==='PAA'?0:NaN),'Risk adjustment'); const openingCsm=finite(d.openingCsm??0,'Opening CSM');const lockedPct=pct(d.lockedInPct??0,'Locked-in CSM rate');
    const futureChange=Number(d.futureServiceChange??0);if(!Number.isFinite(futureChange))throw new Error('Future-service change must be finite.');
    const coverage=model==='GMM'?finite(d.coverageThisPeriod,'Coverage units this period'):0,futureCoverage=model==='GMM'?finite(d.futureCoverageUnits,'Future coverage units'):0;
    const fcf=money(pvOut-pvIn+ra);
    if(model==='PAA'){
      if(d.eligibilityConfirmed!==true||finite(d.coverageMonths,'Coverage months',1,12)>12||d.materialDifferenceConfirmed!==true||d.financingConfirmed!==true)throw new Error('PAA requires documented eligibility, coverage ≤12 months (or evidenced immaterial difference), and confirmation that financing is insignificant or separately adjusted.');
      const opening=finite(d.openingLrc,'Opening LRC'),premiums=finite(d.premiums,'Premiums received'),acquisition=finite(d.acquisitionAmortisation,'Acquisition cash-flow amortisation'),claims=finite(d.incurredClaims,'Incurred claims'),loss=finite(d.onerousLoss,'Onerous loss');
      const closing=money(opening+premiums-acquisition-claims+loss);return result('insurance','IFRS 17 PAA liability for remaining coverage',{opening,premiums,acquisition,claims,loss,closing},[['Opening LRC',opening],['Premiums',premiums],['Acquisition amortisation',-acquisition],['Service/claims allocation',-claims],['Onerous increase',loss],['Closing LRC',closing]],[],['PAA is a measurement simplification, not an exemption from grouping, onerous-contract or disclosure requirements.']);
    }
    const initial=d.initialMeasurement===true;
    const interest=initial?0:money(openingCsm*lockedPct/100);
    const beforeRelease=initial?money(-fcf):money(openingCsm+interest-futureChange);
    const onerous=money(Math.max(0,-beforeRelease));
    const csmBefore=money(Math.max(0,beforeRelease)); const release=coverage+futureCoverage>0?money(csmBefore*coverage/(coverage+futureCoverage)):0;
    const csm=money(csmBefore-release);const lrc=money(fcf+csm);const lic=finite(d.incurredClaimsLiability??0,'Incurred claims liability');
    const items:MeasurementLeg[]=[];
    if(!initial){
      const openingGl=finite(d.openingGlLiability,'Opening GL insurance contract liability');
      const raRelease=finite(d.riskAdjustmentRelease??0,'Risk adjustment release');if(raRelease>ra)throw new Error('Risk adjustment release exceeds the measured risk adjustment.');
      const serviceExpense=finite(d.insuranceServiceExpense??0,'Insurance service expense excluding onerous loss');
      const financeExpense=finite(d.insuranceFinanceExpense??0,'Insurance finance expense (including CSM interest)');
      const revenueRelease=money(release+raRelease);const closingBridge=money(openingGl+serviceExpense+financeExpense+onerous-revenueRelease);
      if(Math.abs(closingBridge-money(lrc+lic))>0.009)throw new Error(`Insurance liability bridge does not reconcile: opening ${openingGl} plus service/finance/onerous less revenue release = ${closingBridge}, measured closing = ${money(lrc+lic)}.`);
      items.push({accountNo:'231000',debit:revenueRelease,credit:0,label:'CSM and risk-adjustment release'},{accountNo:'415000',debit:0,credit:revenueRelease,label:'Insurance revenue'},{accountNo:'585000',debit:serviceExpense,credit:0,label:'Insurance service expense'},{accountNo:'692500',debit:onerous,credit:0,label:'Onerous contract loss'},{accountNo:'712000',debit:financeExpense,credit:0,label:'Insurance finance expense'},{accountNo:'231000',debit:0,credit:money(serviceExpense+financeExpense+onerous),label:'Insurance liability movement'});
    }
    return result('insurance','IFRS 17 GMM contract-group measurement',{pvOut:money(pvOut),pvIn:money(pvIn),riskAdjustment:ra,fcf,openingCsm,interest,futureServiceChange:futureChange,onerousLoss:onerous,csmRelease:release,csm,lrc,lic,totalLiability:money(lrc+lic)},[...rows,['PV outflows',money(pvOut)],['PV inflows',money(pvIn)],['Risk adjustment',ra],['Fulfilment cash flows',fcf],['CSM interest',interest],['Future-service change',futureChange],['Onerous loss',onerous],['CSM release',release],['Closing CSM',csm],['LRC',lrc],['LIC',lic]],items,['Group-level actuarial cash flows and risk adjustment must be independently validated.','No day-one gain is recognised. This kernel does not replace policy administration, VFA, reinsurance held, OCI disaggregation or regulatory solvency systems.']);
  }
  if(input.domain==='financial') {
    const exposures=list(d.exposures,'Credit exposures',5000);let ecl=0,gross=0;const rows:(string|number)[][]=[];
    for(const e of exposures){const ead=finite(e.ead,'Exposure at default'),pd=pct(e.pdPct,'Probability of default')/100,lgd=pct(e.lgdPct,'Loss given default')/100,years=finite(e.years??0,'Years to default'),rate=finite(e.eirPct??0,'Effective interest rate')/100;const stage=integer(e.stage,'IFRS 9 stage',1,3);if(stage===1&&years>1)throw new Error('Stage 1 uses a 12-month default horizon.');if(stage===3&&Math.abs(pd-1)>1e-8)throw new Error('Stage 3 credit-impaired exposure requires default probability of 100%.');const loss=money(ead*pd*lgd*Math.pow(1+rate,-years)*(stage===3?1:1));ecl=money(ecl+loss);gross=money(gross+ead);rows.push([String(e.id||'Exposure'),stage,ead,pd*100,lgd*100,loss]);}
    const booked=finite(d.bookedAllowance??0,'Booked ECL allowance'),adjustment=money(ecl-booked);
    const capital=finite(d.regulatoryCapital??0,'Eligible regulatory capital'),rwa=finite(d.riskWeightedAssets??0,'Risk-weighted assets'),liquid=finite(d.qualifyingLiquidAssets??0,'Qualifying liquid assets'),outflows=finite(d.regulatoryOutflows??0,'Regulatory liquidity denominator'),deposits=finite(d.reserveBaseDeposits??0,'Reserve-base deposits'),reservePct=pct(d.reserveRatioPct??0,'Approved reserve ratio');
    const car=rwa?capital/rwa*100:0,liquidity=outflows?liquid/outflows*100:0,reserve=money(deposits*reservePct/100);
    rows.push(...([['Gross exposure',gross],['Required ECL',ecl],['Booked allowance',booked],['ECL true-up',adjustment],['CAR % (input basis)',money(car)],['Liquidity % (input basis)',money(liquidity)],['Reserve requirement',reserve]] as (string|number)[][]));
    return result('financial','IFRS 9 ECL & prudential working paper',{gross,ecl,booked,adjustment,car:money(car),liquidity:money(liquidity),reserve},rows,adjustment>0?[{accountNo:'680000',debit:adjustment,credit:0,label:'ECL expense'},{accountNo:'119000',debit:0,credit:adjustment,label:'ECL allowance'}]:adjustment<0?[{accountNo:'119000',debit:-adjustment,credit:0,label:'ECL allowance release'},{accountNo:'680000',debit:0,credit:-adjustment,label:'ECL expense release'}]:[],['Stage 1 requires 12-month PD; stages 2/3 require lifetime PD. Inputs must carry the correct horizon.','CAR/liquidity/reserve ratios are only as valid as the regulatory definitions and source data. Not a BoG/NPRA regulatory return.']);
  }
  if(input.domain==='pension') {
    const assets=finite(d.assetsAtFairValue,'Scheme assets at fair value'),liabilities=finite(d.schemeLiabilities,'Scheme liabilities'),units=finite(d.unitsOutstanding,'Units outstanding',0.000001),contributions=finite(d.contributions,'Contributions'),benefits=finite(d.benefits,'Benefits/expenses');
    const openingNav=assets/units;const issuedUnits=openingNav>0?contributions/openingNav:0;const unitsBeforeBenefits=units+issuedUnits;const transactionNav=unitsBeforeBenefits>0?(assets+contributions)/unitsBeforeBenefits:0;const redeemedUnits=transactionNav>0?benefits/transactionNav:0;if(redeemedUnits>unitsBeforeBenefits+1e-8)throw new Error('Benefit payments exceed scheme assets available for unit redemption.');const closingUnits=Math.max(0,unitsBeforeBenefits-redeemedUnits);const closingAssets=money(assets+contributions-benefits);const nav=closingUnits>1e-8?closingAssets/closingUnits:0;const surplus=money(assets-liabilities);
    return result('pension','Pension scheme custody & unit-account reconciliation',{assets,liabilities,surplus,units:money(units),contributions,benefits,closingAssets,closingUnits:money(closingUnits),nav:money(nav)},[['Custody assets',assets],['Scheme liabilities',liabilities],['Net surplus/(deficit)',surplus],['Contributions',contributions],['Benefits/expenses',benefits],['Closing assets',closingAssets],['Closing units',money(closingUnits)],['NAV per unit',money(nav)]],[],['Reconcile assets to independent custodian/trustee statements. This is not an NPRA actuarial valuation or benefit administration engine.']);
  }
  if(input.domain==='agriculture') {
    const quantity=finite(d.quantity,'Biological quantity',0.000001),price=finite(d.fairValuePerUnit,'Fair value per unit'),costs=finite(d.costsToSellPerUnit,'Costs to sell per unit'),carrying=finite(d.carryingAmount,'Current carrying amount');
    if(costs>price)throw new Error('Costs to sell cannot exceed fair value without a separate onerous assessment.');const fairValue=money(quantity*(price-costs)),change=money(fairValue-carrying),harvestCost=money(Math.min(fairValue,finite(d.harvestQuantity??0,'Harvest quantity')*(price-costs)));
    const items:MeasurementLeg[]=change>=0?[{accountNo:'124000',debit:change,credit:0,label:'Biological asset FV change'},{accountNo:'417000',debit:0,credit:change,label:'IAS 41 fair-value gain'}]:[{accountNo:'691500',debit:-change,credit:0,label:'IAS 41 fair-value loss'},{accountNo:'124000',debit:0,credit:-change,label:'Biological asset FV change'}];
    if(harvestCost>0)items.push({accountNo:'121000',debit:harvestCost,credit:0,label:'Harvested produce at FV less costs'},{accountNo:'124000',debit:0,credit:harvestCost,label:'Transfer from biological assets'});
    return result('agriculture','IAS 41 biological asset valuation & harvest',{quantity,price,costsToSell:costs,fairValue,carrying,change,harvestCost},[['Quantity',quantity],['Fair value/unit',price],['Costs to sell/unit',costs],['FV less costs to sell',fairValue],['Carrying amount',carrying],['Fair-value movement',change],['Harvest transfer',harvestCost]],items,['Bearer plants are IAS 16, not IAS 41. Separate them from this measurement.','Fair value requires market evidence, grade/age adjustments and an independent valuation review.']);
  }
  if(input.domain==='manufacturing') {
    const requirements=list(d.requirements,'Material requirements',5000);const rows:(string|number)[][]=[];let planned=0;
    for(const r of requirements){const grossQty=finite(r.grossQty,'Gross requirement'),onHand=finite(r.onHand??0,'On hand'),scheduled=finite(r.scheduledReceipts??0,'Scheduled receipts'),safety=finite(r.safetyStock??0,'Safety stock'),lot=finite(r.lotMultiple??1,'Lot multiple',0.000001);const net=Math.max(0,grossQty+safety-onHand-scheduled);const order=Math.ceil(net/lot)*lot;planned+=order;rows.push([String(r.itemCode||'Item'),grossQty,onHand,scheduled,safety,money(net),money(order),date(r.needBy,'Requirement date')]);}
    return result('manufacturing','MRP net requirements & planned purchasing',{lines:requirements.length,plannedQuantity:money(planned)},rows,[],['Planned orders are not stock receipts or accounting postings. Release through approved procurement and receive against a PO.','This is single-level MRP; multi-level BOM explosion, capacity scheduling and shop-floor control remain separate systems.']);
  }
  throw new Error('Unsupported regulated-sector domain.');
}
