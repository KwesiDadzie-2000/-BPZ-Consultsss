/**
 * Await LAZY query builders one after another on the same transaction client.
 *
 * `Promise.all([tx.select()…, tx.select()…])` dispatches several queries on a
 * single pg client at once. node-postgres serialises them today but warns that
 * this is unsupported (removed in pg@9), and it obscures lock ordering inside a
 * transaction. Drizzle query builders only execute when awaited, so awaiting
 * them in order here runs them strictly sequentially.
 */
export async function sequential<T extends readonly unknown[]>(
  queries: readonly [...{ [K in keyof T]: PromiseLike<T[K]> }],
): Promise<T> {
  const results: unknown[] = [];
  for (const query of queries) results.push(await query);
  return results as unknown as T;
}
