/* Snapshot guards for the legacy /api/state endpoint.
 *
 * The legacy browser sends every register on every edit. An unmodified register
 * must not be rewritten by an account which lacks permission to change it, and
 * a stale tab must not delete records that appeared after its bootstrap.
 * Canonical comparison deliberately ignores extra client-side display fields
 * and normalises optional null/undefined (PostgreSQL returns null for both).
 */

function canonical(value: unknown): unknown {
  if (value == null) return null;
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map(canonical);
  if (typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .filter(([key]) => key !== 'createdAt' && key !== 'updatedAt')
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([key, val]) => [key, canonical(val)]),
    );
  }
  return value;
}

/**
 * Compare only server-persisted fields, keyed by a stable record identity, not
 * array ordering. Use on GET/PUT shapes before accepting a client mutation.
 */
export function unchangedSnapshotRows(
  supplied: readonly Record<string, unknown>[],
  stored: readonly Record<string, unknown>[],
  keyOf: (row: Record<string, unknown>) => string = (row) => String(row.id),
): boolean {
  if (supplied.length !== stored.length) return false;
  const existing = new Map<string, Record<string, unknown>>();
  for (const row of stored) {
    const key = keyOf(row);
    if (existing.has(key)) return false;
    existing.set(key, row);
  }
  const seen = new Set<string>();
  for (const row of supplied) {
    if (!row || typeof row !== 'object') return false;
    const key = keyOf(row);
    if (seen.has(key)) return false;
    seen.add(key);
    const old = existing.get(key);
    if (!old) return false;
    const persistedKeys = Object.keys(old).filter((k) => k !== 'createdAt' && k !== 'updatedAt');
    const actual = Object.fromEntries(persistedKeys.map((k) => [k, canonical(row[k])]));
    const expected = Object.fromEntries(persistedKeys.map((k) => [k, canonical(old[k])]));
    if (JSON.stringify(canonical(actual)) !== JSON.stringify(canonical(expected))) return false;
  }
  return true;
}

/** Missing rows are never a safe instruction to delete accounting evidence. */
export function missingSnapshotKeys(
  supplied: readonly Record<string, unknown>[],
  stored: readonly Record<string, unknown>[],
  keyOf: (row: Record<string, unknown>) => string = (row) => String(row.id),
): string[] {
  const present = new Set(supplied.map(keyOf));
  return stored.map(keyOf).filter((key) => !present.has(key));
}
