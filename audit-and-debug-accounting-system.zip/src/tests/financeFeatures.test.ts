import assert from 'node:assert/strict';
import { test } from 'node:test';
import { generateLoanSchedule, deriveDebtServiceBills, debtAccrualDoc, type LoanFacility } from '../utils/loanSchedule';
import { summariseProject, type CostProject } from '../utils/projectCosting';
import { buildExcelBuffer } from '../utils/excelExport';
import type { ACDOCALine, AccountMaster } from '../types/accounting';

const loan: LoanFacility = { id: 'L1', code: 'LN-TEST', facilityName: 'Test facility', lender: 'Test bank', principal: 1200000, annualRatePct: 21.5, termMonths: 60, frequency: 'monthly', facilityType: 'amortising', arrangementFee: 0, startDate: '2026-01-01', status: 'Active' };
const line = (id: string, accountNo: string, debit: number, credit: number, extra: Partial<ACDOCALine> = {}): ACDOCALine => ({ id, docNo: id, period: '2026-11', date: '2026-11-06', module: 'FI', docType: 'JE', accountNo, accountName: accountNo, debit, credit, currency: 'GHS', description: id, createdBy: 'owner', clientId: 2, ...extra });

test('loan schedule uses exact cents, constant instalments and a rounding-adjusted final row', () => {
  const rows = generateLoanSchedule(loan);
  assert.equal(rows.length, 60); assert.equal(rows[0].interestExpense, 21500);
  assert.equal(rows[0].closingBalance, Math.round((rows[0].openingBalance - rows[0].principalPayment) * 100) / 100);
  assert.equal(rows[59].closingBalance, 0);
  assert.equal(rows.reduce((s, r) => s + Math.round(r.principalPayment * 100), 0), 120000000);
  const cash = new Set(rows.slice(0, -1).map((r) => Math.round(r.totalPayment * 100)));
  assert.equal(cash.size, 1);
  // Each month's cent rounding accumulates; the final row clears it (<= n/2 cents).
  assert.ok(Math.abs(rows[59].totalPayment - rows[0].totalPayment) <= rows.length * 0.005 + 0.01);
  for (const r of rows) for (const v of [r.openingBalance, r.interestExpense, r.principalPayment, r.totalPayment, r.closingBalance]) assert.ok(Math.abs(v * 100 - Math.round(v * 100)) < 1e-6);
});
test('bullet loans accrue interest before cash maturity and quarterly schedules use three-month periods', () => {
  const rows = generateLoanSchedule({ ...loan, facilityType: 'bullet', termMonths: 12 });
  assert.equal(rows[0].totalPayment, 0); assert.equal(rows[0].interestExpense, 21500); assert.equal(rows[11].principalPayment, 1200000);
  const q = generateLoanSchedule({ ...loan, frequency: 'quarterly', termMonths: 12 });
  assert.equal(q.length, 4); assert.equal(q[0].date, '2026-04-01'); assert.equal(q[0].interestExpense, 64500);
  assert.throws(() => generateLoanSchedule({ ...loan, frequency: 'quarterly', termMonths: 10 }), /divisible/);
});
test('debt open items are reduced only by payments referencing that accrual', () => {
  const docNo = debtAccrualDoc(loan.code, 1);
  const rows = [line(docNo, '213000', 0, 32802.46, { docType: 'STAT', reference: 'LOAN:LN-TEST:M1' }), line('PAY-1', '213000', 10000, 0, { docType: 'PAY', reference: docNo }), line('PAY-2', '213000', 0, 500, { docType: 'PAY', reference: 'OTHER' })];
  const bill = deriveDebtServiceBills(rows, 2)[0]; assert.equal(bill.outstanding, 22802.46); assert.equal(bill.paid, 10000);
});
test('project cost allocation does not double count the source expense and WIP', () => {
  const project: CostProject = { id: 'P1', code: 'PRJ-001', name: 'Project', customer: 'Customer', manager: 'Manager', costCenter: 'PRJ-001', startDate: '2026-01-01', endDate: '2026-12-31', contractRevenue: 10000, directBudget: 5000, overheadBudget: 1000, status: 'Active', budgetLines: [] };
  const accounts: AccountMaster[] = [{ accountNo: '621000', name: 'Direct services', type: 'Expense', category: 'Direct Costs', active: true }, { accountNo: '122000', name: 'WIP', type: 'Asset', category: 'Inventories', active: true }, { accountNo: '504000', name: 'COGS', type: 'Expense', category: 'Cost of Sales', active: true }];
  const rows = [line('EXP', '621000', 5000, 0), line('ALLOC', '122000', 1000, 0, { module: 'PC', costCenter: 'PRJ-001', reference: 'PRJ-001' }), line('ALLOC', '621000', 0, 1000, { module: 'PC', costCenter: 'PRJ-001', reference: 'PRJ-001' }), line('REL', '504000', 400, 0, { module: 'PC', costCenter: 'PRJ-001', reference: 'PRJ-001' }), line('REL', '122000', 0, 400, { module: 'PC', costCenter: 'PRJ-001', reference: 'PRJ-001' })];
  const s = summariseProject(project, rows, accounts, [], 2, 'GHS'); assert.equal(s.wip, 600); assert.equal(s.recognisedCost, 400); assert.equal(s.totalCost, 1000); assert.equal(s.variance, 5000);
});
test('Excel export is a real workbook with numeric amounts and formula-safe text', async () => {
  const bytes = await buildExcelBuffer([{ name: 'Schedule', columns: ['Description', 'Amount'], rows: [['=HYPERLINK("bad")', 1234.56]], moneyColumns: [1] }]);
  assert.equal(Buffer.from(bytes.slice(0, 2)).toString(), 'PK');
  const imported = await import('exceljs');
  const ExcelJS = (imported as unknown as { default?: typeof imported }).default ?? imported;
  const wb = new ExcelJS.Workbook(); await wb.xlsx.load(bytes as never);
  const sheet = wb.getWorksheet('Schedule')!; assert.equal(sheet.getCell('A2').value, '=HYPERLINK("bad")'); assert.equal(sheet.getCell('B2').value, 1234.56); assert.equal(sheet.getCell('B2').type, 2);
});
