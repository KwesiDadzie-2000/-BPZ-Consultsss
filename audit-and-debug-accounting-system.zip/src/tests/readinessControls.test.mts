import assert from 'node:assert/strict';
import { randomBytes, randomUUID } from 'node:crypto';

// Destructive test fixture: NEVER run this against the preview or a production database.
const url = process.env.BPZ_READINESS_TEST_DATABASE_URL;
if (!url) throw new Error('Set BPZ_READINESS_TEST_DATABASE_URL to local bpz_readiness_test.');
const parsed = new URL(url);
if (!['localhost', '127.0.0.1'].includes(parsed.hostname) || parsed.pathname !== '/bpz_readiness_test') {
  throw new Error('Refusing to run outside local bpz_readiness_test.');
}
process.env.DATABASE_URL = url;
process.env.BPZ_BOOTSTRAP_MODE = 'production';
process.env.BPZ_OWNER_EMAIL = 'readiness-owner@example.invalid';
process.env.BPZ_SETUP_TOKEN = randomBytes(32).toString('hex');

const { pool } = await import('@/db');
await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public');
const setup = await import('@/app/api/auth/setup/route');
const clientsRoute = await import('@/app/api/clients/route');
const login = await import('@/app/api/auth/login/route');
const bootstrap = await import('@/app/api/bootstrap/route');
const state = await import('@/app/api/state/route');
const workbooks = await import('@/app/api/workbooks/route');
const { db } = await import('@/db');
const { bankAccounts, companyProfiles, loginAttempts, salesInvoices, users } = await import('@/db/schema');
const { eq } = await import('drizzle-orm');

const pass = () => `Pilot-${randomBytes(10).toString('hex')}Aa1!`;
const ownerPassword = pass();
type Handler = (request: Request) => Promise<Response>;
const call = (handler: Handler, method: string, path: string, body?: unknown, token?: string) => handler(new Request(`http://localhost${path}`, {
  method, headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
  ...(body === undefined ? {} : { body: JSON.stringify(body) }),
}));
const activate = await call(setup.POST, 'POST', '/api/auth/setup', { password: ownerPassword, confirm: ownerPassword, setupToken: process.env.BPZ_SETUP_TOKEN });
assert.equal(activate.status, 200, JSON.stringify(await activate.clone().json()));
const owner = (await activate.json()).token as string;

async function makeClient(code: string, modules: string[]) {
  const username = `user_${code.toLowerCase()}`;
  const password = pass();
  const response = await call(clientsRoute.POST, 'POST', '/api/clients', {
    client: { code, name: `${code} Practice Limited`, sector: 'Services', currency: 'GHS', jurisdiction: 'GH', regNumber: `RC-${code}`, assignedServices: ['bookkeeping', 'management_accounts', 'ifrs_reporting'] },
    admin: { username, name: `${code} Controller`, email: `${username}@example.invalid`, role: 'manager', password, makerLimit: 25000, allowedModules: modules },
  }, owner);
  assert.equal(response.status, 201, JSON.stringify(await response.clone().json()));
  const entity = (await response.json()).client;
  const signIn = await call(login.POST, 'POST', '/api/auth/login', { usernameOrEmail: username, password, workspace: code });
  assert.equal(signIn.status, 200, JSON.stringify(await signIn.clone().json()));
  return { ...entity, username, token: (await signIn.json()).token as string };
}

const a = await makeClient('PILOTA', ['sales']);
const b = await makeClient('PILOTB', ['sales', 'banking']);
const getState = async (token: string) => {
  const response = await call(bootstrap.GET, 'GET', '/api/bootstrap', undefined, token);
  assert.equal(response.status, 200);
  return (await response.json()).state as Record<string, any>;
};
const ownerSnapshot = await getState(owner);

// A client whose owner ticked only Sales must not be able to change the legal
// profile/bank payment instructions via a direct state-sync request.
const clientSnapshot = await getState(a.token);
const badProfile = {
  ...clientSnapshot,
  companyProfiles: { [a.id]: { clientId: a.id, legalName: a.name, tradingName: a.name, tin: 'X', vatRegNo: 'X', address: 'X', phone: '', email: '', website: '', fiscalYearStart: 'January', bankPaymentDetails: 'attacker account' } },
};
const profileResult = await call(state.PUT, 'PUT', '/api/state', badProfile, a.token);
assert.equal(profileResult.status, 403, `Client changed owner-only bank instructions: ${profileResult.status} ${await profileResult.text()}`);
assert.equal((await db.select().from(companyProfiles).where(eq(companyProfiles.clientId, a.id))).length, 0);

// A full-state owner snapshot must not delete rows created by another tab after
// it was loaded. This is a replica of the former global delete-and-reinsert path.
await db.insert(bankAccounts).values({ id: 20000001, clientId: b.id, code: 'BNK-PILOT', name: 'Real bank', bankName: 'Test bank', accountNo: '123456789', currency: 'GHS', balance: 0, kind: 'bank', glAccount: '100000' });
const staleResult = await call(state.PUT, 'PUT', '/api/state', ownerSnapshot, owner);
assert.notEqual(staleResult.status, 200, 'Stale owner snapshot was accepted and erased newly created client bank account.');
assert.equal((await db.select().from(bankAccounts).where(eq(bankAccounts.id, 20000001))).length, 1);

// A pair of bank balances mapped to the same GL account must not be arbitrarily
// shifted while their aggregate remains unchanged.
await db.insert(bankAccounts).values({ id: 20000002, clientId: b.id, code: 'BNK-PILOT-2', name: 'Other bank', bankName: 'Test bank', accountNo: '987654321', currency: 'GHS', balance: 0, kind: 'bank', glAccount: '100000' });
const bState = await getState(b.token);
const bankTransfer = { ...bState, bankAccounts: bState.bankAccounts.map((r: { id: number; balance: number }) => r.id === 20000001 ? { ...r, balance: 500 } : r.id === 20000002 ? { ...r, balance: -500 } : r) };
const bankResult = await call(state.PUT, 'PUT', '/api/state', bankTransfer, b.token);
assert.notEqual(bankResult.status, 200, 'Unposted transfer between two bank accounts bypassed the GL aggregate check.');

// Same-total invoice reallocation is not a receipt: it must be performed through
// a server-authoritative, auditable settlement workflow, not a browser snapshot.
await db.insert(salesInvoices).values([
  { id: randomUUID(), clientId: b.id, invNo: 'TEST-INV-A', customerName: 'A', revenueStream: 'Services', netRevenue: 100, vatOutput: 0, totalReceivable: 100, paidAmount: 0, status: 'Open', date: '2026-11-06' },
  { id: randomUUID(), clientId: b.id, invNo: 'TEST-INV-B', customerName: 'B', revenueStream: 'Services', netRevenue: 100, vatOutput: 0, totalReceivable: 100, paidAmount: 100, status: 'Paid', date: '2026-11-06' },
]);
const settledState = await getState(b.token);
const shifted = { ...settledState, salesInvoices: settledState.salesInvoices.map((i: { invNo: string }) =>
  i.invNo === 'TEST-INV-A' ? { ...i, paidAmount: 100, status: 'Paid' } : { ...i, paidAmount: 0, status: 'Open' },
) };
const shiftedResult = await call(state.PUT, 'PUT', '/api/state', shifted, b.token);
assert.notEqual(shiftedResult.status, 200, 'An invoice was marked Paid using a different invoice’s settlement.');

// Retrieving ALL workbook kinds must not disclose IFRS measurement assumptions
// to an account ticked for performance reports only.
const reportOnly = await makeClient('PILOTC', ['performance']);
const ifrsWb = await call(workbooks.PUT, 'PUT', '/api/workbooks', {
  clientId: reportOnly.id, kind: 'ifrs_inputs', key: 'private-assumptions', title: 'Sensitive measurement inputs', payload: { privateValuation: 250000 }, expectedVersion: 0,
}, owner);
assert.equal(ifrsWb.status, 201);
const perfWb = await call(workbooks.PUT, 'PUT', '/api/workbooks', {
  clientId: reportOnly.id, kind: 'budget', key: 'visible-budget', title: 'Budget', payload: { year: 2026 }, expectedVersion: 0,
}, owner);
assert.equal(perfWb.status, 201);
const allWorkbooks = await call(workbooks.GET, 'GET', `/api/workbooks?clientId=${reportOnly.id}`, undefined, reportOnly.token);
assert.equal(allWorkbooks.status, 200);
assert.deepEqual((await allWorkbooks.json()).workbooks.map((w: { kind: string }) => w.kind), ['budget']);
assert.equal((await call(workbooks.GET, 'GET', `/api/workbooks?clientId=${reportOnly.id}&kind=ifrs_inputs`, undefined, reportOnly.token)).status, 403);

// After the 5-minute lockout expires, one new typo must not immediately relock.
const now = Date.now();
await db.insert(loginAttempts).values({ identifier: reportOnly.username, count: 5, until: now - 1000, updatedAt: now - 301000 });
const afterExpiry = await call(login.POST, 'POST', '/api/auth/login', { usernameOrEmail: reportOnly.username, password: 'Wrong-after-expiry!9' });
assert.equal(afterExpiry.status, 401);
const attempt = (await db.select().from(loginAttempts).where(eq(loginAttempts.identifier, reportOnly.username)))[0];
assert.equal(attempt.count, 1);
assert.equal(attempt.until, 0);

// New finance workflows: server-calculated debt accrual → referenced Payment
// Desk settlement, and source-evidenced project WIP allocation/release.
const debtRoute = await import('@/app/api/debt/route');
const projectsRoute = await import('@/app/api/projects/route');
const journalRoute = await import('@/app/api/journal/route');
const { generateLoanSchedule, deriveDebtServiceBills, debtAccrualDoc } = await import('@/utils/loanSchedule');
const facility = { id: randomUUID(), code: 'LN-PILOT', facilityName: 'Pilot facility', lender: 'Pilot Bank', principal: 1200000, annualRatePct: 21.5, termMonths: 60, frequency: 'monthly', facilityType: 'amortising', arrangementFee: 0, startDate: '2026-01-01', status: 'Active' };
const loanSave = await call(workbooks.PUT, 'PUT', '/api/workbooks', { clientId: b.id, kind: 'loan_facilities', key: 'register', title: 'Pilot loans', payload: { facilities: [facility] }, expectedVersion: 0 }, owner);
assert.equal(loanSave.status, 201, JSON.stringify(await loanSave.clone().json()));
const accrual = await call(debtRoute.POST, 'POST', '/api/debt', { clientId: b.id, facilityId: facility.id, periodNum: 1, action: 'accrue' }, owner);
assert.equal(accrual.status, 200, JSON.stringify(await accrual.clone().json()));
const accrued = await accrual.json();
const expectedRow = generateLoanSchedule(facility as any)[0];
assert.equal(accrued.payable, Math.round((expectedRow.interestExpense + expectedRow.principalPayment) * 100) / 100);
assert.equal((await call(debtRoute.POST, 'POST', '/api/debt', { clientId: b.id, facilityId: facility.id, periodNum: 1, action: 'accrue' }, owner)).status, 200);
assert.equal((await call(debtRoute.POST, 'POST', '/api/debt', { clientId: b.id, facilityId: facility.id, periodNum: 1, action: 'accrue' }, b.token)).status, 403);
const afterAccrual = await getState(owner);
const accrualDoc = debtAccrualDoc(facility.code, 1);
assert.equal(deriveDebtServiceBills(afterAccrual.journalLines, b.id).find((x: { docNo: string }) => x.docNo === accrualDoc)?.outstanding, accrued.payable);
const baseLine = { period: '2026-11', date: '2026-11-06', module: 'FI', docType: 'PAY', currency: 'GHS', createdBy: 'owner', clientId: b.id, costCenter: 'CC-ADM' };
const unauthorizedPayment = await call(journalRoute.POST, 'POST', '/api/journal', { lines: [
  { ...baseLine, id: randomUUID(), docNo: 'BAD-DEBT-PAY', accountNo: '213000', accountName: 'Debt payable', debit: 100, credit: 0, description: accrualDoc, reference: accrualDoc, createdBy: b.username },
  { ...baseLine, id: randomUUID(), docNo: 'BAD-DEBT-PAY', accountNo: '100000', accountName: 'Bank', debit: 0, credit: 100, description: accrualDoc, createdBy: b.username },
] }, b.token);
assert.equal(unauthorizedPayment.status, 403);
const payment = await call(journalRoute.POST, 'POST', '/api/journal', { lines: [
  { ...baseLine, id: randomUUID(), docNo: 'PILOT-DEBT-PAY', accountNo: '213000', accountName: 'Debt payable', debit: 10000, credit: 0, description: `Settlement ${accrualDoc}`, reference: accrualDoc },
  { ...baseLine, id: randomUUID(), docNo: 'PILOT-DEBT-PAY', accountNo: '100000', accountName: 'Bank', debit: 0, credit: 10000, description: `Payment ${accrualDoc}`, reference: accrualDoc },
] }, owner);
assert.equal(payment.status, 200, JSON.stringify(await payment.clone().json()));
const afterPayment = await getState(owner);
assert.equal(deriveDebtServiceBills(afterPayment.journalLines, b.id).find((x: { docNo: string }) => x.docNo === accrualDoc)?.outstanding, Math.round((accrued.payable - 10000) * 100) / 100);
const project = { id: randomUUID(), code: 'PRJ-PILOT', name: 'Pilot project', customer: 'Customer', manager: 'Manager', costCenter: 'PRJ-PILOT', startDate: '2026-01-01', endDate: '2026-12-31', contractRevenue: 20000, directBudget: 5000, overheadBudget: 1000, status: 'Active', budgetLines: [] };
assert.equal((await call(workbooks.PUT, 'PUT', '/api/workbooks', { clientId: b.id, kind: 'project_costing', key: 'register', title: 'Projects', payload: { projects: [project] }, expectedVersion: 0 }, owner)).status, 201);
const sourceDoc = 'PRJ-SOURCE';
assert.equal((await call(journalRoute.POST, 'POST', '/api/journal', { lines: [
  { ...baseLine, id: randomUUID(), docNo: sourceDoc, docType: 'JE', accountNo: '621000', accountName: 'Direct expense', debit: 5000, credit: 0, description: 'Project source expense' },
  { ...baseLine, id: randomUUID(), docNo: sourceDoc, docType: 'JE', accountNo: '200000', accountName: 'Payables', debit: 0, credit: 5000, description: 'Project source payable' },
] }, owner)).status, 200);
const allocationBody = { clientId: b.id, projectId: project.id, action: 'allocate', amount: 1000, date: '2026-11-06', sourceDocNo: sourceDoc, accountNo: '621000', reason: 'Timesheet and supplier evidence', requestKey: randomUUID() };
const allocated = await call(projectsRoute.POST, 'POST', '/api/projects', allocationBody, owner);
assert.equal(allocated.status, 200, JSON.stringify(await allocated.clone().json()));
assert.equal((await call(projectsRoute.POST, 'POST', '/api/projects', allocationBody, owner)).status, 200);
assert.equal((await call(projectsRoute.POST, 'POST', '/api/projects', { ...allocationBody, amount: 4500, requestKey: randomUUID() }, owner)).status, 409);
assert.equal((await call(projectsRoute.POST, 'POST', '/api/projects', { ...allocationBody, requestKey: randomUUID() }, b.token)).status, 403);
const release = await call(projectsRoute.POST, 'POST', '/api/projects', { clientId: b.id, projectId: project.id, action: 'release_wip', amount: 400, date: '2026-11-06', reason: 'Performance obligation satisfied', requestKey: randomUUID() }, owner);
assert.equal(release.status, 200, JSON.stringify(await release.clone().json()));
const finalState = await getState(owner);
const projectWip = finalState.journalLines.filter((l: { clientId: number; costCenter: string; accountNo: string }) => l.clientId === b.id && l.costCenter === project.costCenter && l.accountNo === '122000').reduce((s: number, l: { debit: number; credit: number }) => s + l.debit - l.credit, 0);
assert.equal(Math.round(projectWip * 100) / 100, 600);

console.log('Readiness controls: access, stale snapshots, settlement, debt accrual/payment and project WIP workflows passed.');
await pool.end();
