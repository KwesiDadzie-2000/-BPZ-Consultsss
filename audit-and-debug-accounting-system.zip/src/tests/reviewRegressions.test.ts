import assert from 'node:assert/strict';
import { test } from 'node:test';
import { INITIAL_CLIENTS } from '../data/accountingSeed';
import type { ACDOCALine } from '../types/accounting';
import { validateJournalLines, validatePostingIdentity, type PostingUserRecord } from '../lib/journalValidation';
import { immutableJournalConflict } from '../lib/immutableJournal';
import { dashboardModel } from '../utils/dashboardModel';
import { csvCell } from '../utils/printReport';
import { persistentStorage } from '../utils/persistentStorage';
import { browserStorage } from '../utils/browserStorage';
import { reconcileControlAccounts } from '../utils/controlAccounts';
import { contractPositionMovement } from '../utils/contractPosition';

const base: ACDOCALine = {
  id: 'line-a', docNo: 'TEST-001', period: '2026-10', date: '2026-10-29', module: 'FI',
  docType: 'JE', accountNo: '100000', accountName: 'Bank', debit: 100, credit: 0,
  currency: 'GHS', description: 'Review regression', createdBy: 'maker', clientId: 2,
};
const pair = (): ACDOCALine[] => [ { ...base }, { ...base, id: 'line-b', accountNo: '400000', debit: 0, credit: 100 } ];
const context = { allowedClientIds: [2], closedPeriodKeys: new Set<string>(), coaAccountNos: new Set(['100000', '400000']) };
const maker: PostingUserRecord = { username: 'maker', role: 'accountant', makerLimit: 50, canCheck: false, status: 'active', clientId: 2 };
const checker: PostingUserRecord = { username: 'checker', role: 'manager', makerLimit: 10000, canCheck: true, status: 'active', clientId: 2 };
const users = new Map([['maker', maker], ['checker', checker]]);

test('valid balanced document is accepted', () => assert.equal(validateJournalLines(pair(), context), null));
test('invalid collection is rejected without crashing', () => assert.ok(validateJournalLines(null as unknown as ACDOCALine[], context)));
test('null lines are rejected without crashing', () => assert.ok(validateJournalLines([null] as unknown as ACDOCALine[], context)));
test('duplicate line identifiers are refused', () => assert.match(validateJournalLines([base, { ...base }], context)!, /Duplicate/));
test('blank document numbers are refused', () => assert.ok(validateJournalLines(pair().map((line) => ({ ...line, docNo: '' })), context)));
test('date cannot escape the accounting period freeze', () => assert.match(validateJournalLines(pair().map((line) => ({ ...line, period: '2026-09' })), context)!, /posting date/));
test('impossible calendar dates are refused', () => assert.ok(validateJournalLines(pair().map((line) => ({ ...line, date: '2026-02-30', period: '2026-02' })), context)));
test('fractional pennies cannot silently round to a balanced document', () => assert.ok(validateJournalLines(pair().map((line) => ({ ...line, debit: line.debit ? 100.001 : 0 })), context)));
test('non-finite money is refused', () => assert.ok(validateJournalLines([{ ...base, debit: Infinity }, pair()[1]], context)));
test('money beyond the integer precision boundary is refused', () => assert.ok(validateJournalLines([{ ...base, debit: Number.MAX_SAFE_INTEGER }, pair()[1]], context)));
test('legitimate floating point representation is tolerated', () => assert.equal(validateJournalLines([{ ...base, debit: 0.1 + 0.2 }, { ...pair()[1], credit: 0.3 }], context), null));
test('different checker stamps within one document are refused', () => assert.match(validateJournalLines([{ ...base, checkedBy: 'checker' }, pair()[1]], context)!, /checker/));
test('a maker cannot claim the approval of a real checker', () => assert.match(validatePostingIdentity(pair().map((line) => ({ ...line, checkedBy: 'checker' })), { session: maker, users })!, /authenticated checker/));
test('the authenticated checker can submit the approved document', () => assert.equal(validatePostingIdentity(pair().map((line) => ({ ...line, checkedBy: 'checker' })), { session: checker, users }), null));
test('a checker cannot approve another tenant record', () => {
  const outside = { ...checker, clientId: 3 };
  assert.match(validatePostingIdentity(pair().map((line) => ({ ...line, checkedBy: 'checker' })), { session: outside, users: new Map([...users, ['checker', outside]]) })!, /another entity/);
});
test('revoked posting permission is enforced', () => assert.match(validatePostingIdentity(pair(), { session: { ...maker, canPostJournals: false }, users })!, /permission/));
test('zero maker limit means read-only, not unlimited', () => assert.match(validatePostingIdentity(pair(), { session: maker, users: new Map([...users, ['maker', { ...maker, makerLimit: 0 }]]) })!, /read-only/));
test('inactive maker cannot be posted on behalf of', () => assert.ok(validatePostingIdentity(pair().map((line) => ({ ...line, checkedBy: 'checker' })), { session: checker, users: new Map([...users, ['maker', { ...maker, status: 'suspended' }]]) })));
test('replaying a posted document is safe', () => assert.equal(immutableJournalConflict(pair(), pair()), null));
test('reordering a replay is safe', () => assert.equal(immutableJournalConflict(pair(), pair().reverse()), null));
test('a changed amount cannot replace a posted document', () => assert.match(immutableJournalConflict(pair(), pair().map((line) => ({ ...line, debit: line.debit * 2, credit: line.credit * 2 })))!, /immutable/));
test('removing one line of a posted document is refused', () => assert.ok(immutableJournalConflict(pair(), [base])));
test('reversal is a new document, not mutation of the old document', () => assert.equal(immutableJournalConflict(pair(), pair().map((line) => ({ ...line, id: `rev-${line.id}`, docNo: 'REV-TEST-001', debit: line.credit, credit: line.debit, docType: 'REV', reference: 'TEST-001' }))), null));
test('missing documents do not request deletion', () => assert.equal(immutableJournalConflict(pair(), []), null));
test('tenant-scoped dashboard excludes another entity', () => assert.equal(dashboardModel([...pair(), ...pair().map((line) => ({ ...line, clientId: 3 }))], INITIAL_CLIENTS[1]).cashBank, 100));
test('dashboard never adds foreign currency without a rate', () => {
  const model = dashboardModel([...pair(), ...pair().map((line) => ({ ...line, currency: 'USD' }))], INITIAL_CLIENTS[1]);
  assert.equal(model.cashBank, 100); assert.equal(model.excludedLines, 2);
});
test('opposite currency imbalances cannot cancel each other', () => assert.equal(dashboardModel([base, { ...pair()[1], currency: 'USD' }], INITIAL_CLIENTS[1]).isBalanced, false));
test('recent activity sorts by date without mutating the ledger', () => {
  const rows = [base, { ...base, id: 'old', date: '2026-01-01' }, { ...base, id: 'new', date: '2026-10-30' }];
  assert.equal(dashboardModel(rows, INITIAL_CLIENTS[1]).recent[0].id, 'new');
  assert.equal(rows[0].id, 'line-a');
});
test('empty entities have a balanced zero-value model', () => {
  const model = dashboardModel([], INITIAL_CLIENTS[1]); assert.equal(model.isBalanced, true); assert.equal(model.recent.length, 0);
});
for (const value of ['=1+1', '+SUM(A1:A2)', '-1+1', '@SUM(A1:A2)', '\t=1+1', '  =1+1']) {
  test(`CSV neutralises formula-like text ${JSON.stringify(value)}`, () => assert.ok(csvCell(value).startsWith('"\'')));
}
test('CSV preserves negative numeric amounts', () => assert.equal(csvCell(-12.5), '"-12.5"'));
test('CSV quotes names safely', () => assert.equal(csvCell('The "Mining", Co.'), '"The ""Mining"", Co."'));

class MemoryStorage implements Storage {
  values = new Map<string, string>();
  failKey: string | null = null;
  get length() { return this.values.size; }
  clear() { this.values.clear(); }
  key(index: number) { return [...this.values.keys()][index] || null; }
  getItem(key: string) { return this.values.get(key) ?? null; }
  setItem(key: string, value: string) {
    if (this.failKey === key) { this.failKey = null; throw new Error('Quota exceeded'); }
    this.values.set(key, String(value));
  }
  removeItem(key: string) { this.values.delete(key); }
}
test('backup includes all operational registers', () => {
  const data = JSON.parse(persistentStorage.exportFullBackup());
  assert.equal(data.version, '2026.5');
  for (const key of ['stockItems', 'stockMovements', 'fixedAssets', 'approvalRequests', 'taxScheduleEntries', 'prepaymentRecords', 'prepaymentSchedules']) assert.ok(Array.isArray(data[key]), key);
});
test('full backup restores inventory, assets and prepayments', () => {
  const store = new MemoryStorage();
  Object.defineProperty(globalThis, 'localStorage', { value: store, configurable: true });
  const backup = persistentStorage.exportFullBackup();
  assert.equal(persistentStorage.restoreFullBackup(backup), true);
  const original = JSON.parse(backup);
  assert.deepEqual(persistentStorage.getStockItems(), original.stockItems);
  assert.deepEqual(persistentStorage.getAssets(), original.fixedAssets);
  assert.deepEqual(persistentStorage.getPrepayments(), original.prepaymentRecords);
});
test('incomplete new backups are refused before any write', () => {
  const before = persistentStorage.exportFullBackup();
  const backup = JSON.parse(before); delete backup.stockItems;
  assert.equal(persistentStorage.restoreFullBackup(JSON.stringify(backup)), false);
  assert.deepEqual(JSON.parse(persistentStorage.exportFullBackup()).stockItems, JSON.parse(before).stockItems);
});
test('backup restore rolls back if a storage write fails', () => {
  const store = new MemoryStorage();
  Object.defineProperty(globalThis, 'localStorage', { value: store, configurable: true });
  store.setItem('bpz_clients_v1', JSON.stringify(INITIAL_CLIENTS));
  const previous = new Map(store.values);
  store.failKey = 'bpz_employees_v1';
  assert.equal(persistentStorage.restoreFullBackup(persistentStorage.exportFullBackup()), false);
  assert.deepEqual(store.values, previous);
});
test('malformed saved arrays are quarantined rather than crashing', () => {
  const store = new MemoryStorage();
  Object.defineProperty(globalThis, 'localStorage', { value: store, configurable: true });
  store.setItem('bpz_clients_v1', '[null]');
  assert.equal(browserStorage.getItem('bpz_clients_v1'), null);
  assert.equal(store.getItem('bpz_clients_v1:quarantined'), '[null]');
});
test('passwords are not written to browser user storage', () => {
  const store = new MemoryStorage();
  Object.defineProperty(globalThis, 'localStorage', { value: store, configurable: true });
  persistentStorage.saveUserAccounts([{ username: 'fixture', name: 'Fixture', role: 'accountant', email: '', makerLimit: 1, canCheck: false, password: 'NotARealPassword' }]);
  assert.ok(!store.getItem('bpz_user_accounts_v1')!.includes('NotARealPassword'));
});

test('ledger-derived payroll, tax and WIP cannot verify themselves as independent control-account tie-outs', () => {
  const rows = reconcileControlAccounts({ clientId: 2, lines: [], accounts: [], bankAccounts: [], salesInvoices: [], purchaseOrders: [], stockItems: [], fixedAssets: [], prepaymentRecords: [], prepaymentSchedules: [] });
  for (const accountNo of ['207000', '209000', '220000', '122000', '202000']) {
    const row = rows.find((r) => r.def.accountNo === accountNo);
    assert.ok(row, accountNo);
    assert.equal(row.independentlySupported, false, accountNo);
    assert.equal(row.reconciled, false, `${accountNo}: a zero balance is not independent evidence`);
  }
});

test('IFRS 15 clears a contract asset before recognising an over-billing liability', () => {
  const legs = contractPositionMovement(-100, 100, 0);
  assert.deepEqual(legs, [
    { accountNo: '118100', debit: 0, credit: 100 },
    { accountNo: '225000', debit: 0, credit: 100 },
    { accountNo: '400000', debit: 200, credit: 0 },
  ]);
  assert.equal(legs.reduce((s, l) => s + l.debit - l.credit, 0), 0);
  assert.deepEqual(contractPositionMovement(100, 0, 100), [
    { accountNo: '118100', debit: 100, credit: 0 },
    { accountNo: '225000', debit: 100, credit: 0 },
    { accountNo: '400000', debit: 0, credit: 200 },
  ]);
  assert.deepEqual(contractPositionMovement(100, 100, 0), []);
});