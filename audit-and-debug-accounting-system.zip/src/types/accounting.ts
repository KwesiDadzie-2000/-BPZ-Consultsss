export interface UserPermissions {
  canPostJournals: boolean;
  canApprovePayments: boolean;
  canRunPayroll: boolean;
  canClosePeriod: boolean;
  canModifyCOA: boolean;
  /**
   * Module ticks for a non-owner user (sidebar section ids). Absent = every module
   * the client's contracted services allow. Present = only the ticked modules open.
   */
  allowedModules?: string[];
}

export interface ClientEntity {
  id: number;
  code: string;
  name: string;
  sector: string;
  currency: string;
  jurisdiction: string;
  regNumber: string;
  isParent?: boolean;
  assignedServices?: string[];
  adminUsername?: string;
  adminEmail?: string;
  adminPassword?: string;
  loginUrl?: string;
}

export interface UserAccount {
  username: string;
  name: string;
  role: 'owner' | 'partner' | 'manager' | 'accountant' | 'auditor';
  makerLimit: number;
  canCheck: boolean;
  email: string;
  clientId?: number;
  password?: string;
  passwordHash?: string;
  passwordSalt?: string;
  status?: 'active' | 'restricted' | 'suspended';
  restrictionReason?: string;
  permissions?: UserPermissions;
}

export interface CompanyProfile {
  clientId: number;
  legalName: string;
  tradingName: string;
  tin: string;
  vatRegNo: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  fiscalYearStart: string;
  bankPaymentDetails: string;
}

export interface ApprovalRequest {
  id: string;
  clientId: number;
  clientCode: string;
  clientName: string;
  docNo: string;
  docType: 'JE' | 'PO' | 'PAY' | 'PAYROLL' | 'REV';
  amount: number;
  requestedBy: string;
  requestedAt: string;
  description: string;
  reasonForApproval: string;
  status: 'pending' | 'approved' | 'rejected';
  reviewedBy?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  /** Proposed journal lines — posted exactly once when the request is approved. */
  payload?: { lines: ACDOCALine[]; settlement?: PaymentSettlementMeta };
}

/**
 * Side effects attached to an above-maker-limit payment request. When the
 * approver signs off, the journal is posted AND these effects are applied
 * (treasury balance movement, supplier/customer document settlement), so an
 * approved payment is actually effected — never silently left unexecuted.
 */
export interface PaymentSettlementMeta {
  kind: 'supplier' | 'customer' | 'salary' | 'expense' | 'statutory';
  clientId: number;
  /** PO id / invoice id / expense bill no / statutory GL account, as applicable. */
  targetId?: string;
  /** Amount applied against the payable/receivable document (gross of WHT). */
  settleAmount: number;
  /** Signed change to the funding treasury record (negative = disbursement). */
  cashDelta: number;
  /** Treasury record that funds the payment / receives the receipt. */
  bankId: number;
}

export interface ACDOCALine {
  id: string;
  docNo: string;
  period: string;
  date: string;
  module: 'MM' | 'SD' | 'HR' | 'FI-AA' | 'ADMIN' | 'FI' | 'INV' | 'PP' | 'PC';
  docType: 'INV' | 'PO' | 'PAY' | 'JE' | 'DEP' | 'STAT' | 'REV' | 'WO';
  accountNo: string;
  accountName: string;
  costCenter?: string;
  debit: number;
  credit: number;
  currency: string;
  description: string;
  createdBy: string;
  checkedBy?: string;
  clientId: number;
  isReversed?: boolean;
  reference?: string;
}

export interface BankAccount {
  id: number;
  clientId?: number;
  code: string;
  name: string;
  bankName: string;
  accountNo: string;
  currency: string;
  balance: number;
  /** Treasury classification: a true bank account or a cash-on-hand float/wallet. */
  kind?: 'bank' | 'cash';
  /** GL account in the chart of accounts that this treasury account is reconciled against. */
  glAccount?: string;
}

export interface PayrollDeductionConfig {
  id: string;
  name: string;
  base: 'gross' | 'basic' | 'net';
  ratePct?: number;
  fixedAmount: number;
}

export interface EmployeeProfile {
  id: number;
  clientId?: number;
  bpNo: string;
  name: string;
  role: string;
  department: string;
  /** Cost centre the employee's payroll cost is charged to (e.g. CC-OPS). */
  costCenter?: string;
  jurisdiction: string;
  basicSalary: number;
  allowances: number;
  ssnitNumber: string;
  tin: string;
  status: 'active' | 'inactive';
  isResident?: boolean;
  exemptTier1?: boolean;
  exemptTier2?: boolean;
  ssnitExempt?: boolean;
  ssnitExemptionReason?: string;
  taxRelief?: number;
  reliefType?: string;
  deductions?: PayrollDeductionConfig[];
}

export interface MonthlyPayrollRecord {
  id: string;
  clientId?: number;
  employeeId: number;
  bpNo: string;
  name: string;
  department: string;
  role: string;
  period: string; // e.g. "2026-03"
  currency: string;
  isResident: boolean;
  exemptTier1: boolean;
  exemptTier2: boolean;
  ssnitExempt?: boolean;
  ssnitExemptionReason?: string;

  // Earnings
  basicSalary: number;
  allowances: number;
  bonusAdditions: number;
  grossPay: number;

  // Reliefs & Taxable
  taxRelief: number;
  reliefType?: string;

  // Statutory Pension (SSNIT 18.5% of insurable basic salary = 5.5% employee + 13% employer)
  ssnitInsurableBase: number;   // 2026 insurable-earnings band (min 587.80 / max 69,000)
  ssnitTier1Employee: number;   // 5.5% of insurable basic — the worker's mandatory deduction
  ssnitTier2Employee: number;   // 0 — the Tier 2 5% is funded inside the combined 18.5% remittance
  ssnitEmployerCost: number;    // 13.0% of insurable basic — the employer's mandatory cost
  ssnitTier1Allocation: number; // 13.5% of insurable basic → SSNIT Tier 1 (incl. 2.5% → NHIA)
  ssnitTier2Allocation: number; // 5.0% of insurable basic → Tier 2 occupational trustee (mandatory)
  nhiaRemittance: number;       // 2.5% of insurable basic → NHIA (routed via the 13.5%)

  // Tax
  taxableIncome: number;
  payeTax: number;
  /** Portion of payeTax that is the 5% final tax on the qualifying bonus (Act 896 s.6). */
  bonusFinalTax?: number;
  /** Bonus amount taxed at the 5% final rate (≤ 15% of annual basic). */
  qualifyingBonus?: number;

  // Other Deductions on Gross, Basic, or Net
  customDeductions: {
    id: string;
    name: string;
    base: 'gross' | 'basic' | 'net';
    amount: number;
  }[];
  totalCustomDeductions: number;

  // Summary
  totalEmployeeDeductions: number;
  netSalary: number;
  employerTotalCost: number;

  // Status & Posting
  status: 'Draft' | 'Approved' | 'Posted';
  docNo?: string;
  postedDate?: string;
}

export interface StockItem {
  id: string;
  clientId: number;
  itemCode: string;
  description: string;
  category: string;
  uom: string;
  quantityOnHand: number;
  unitCost: number; // Perpetual weighted-average / FIFO carrying cost
  totalValue: number;
  reorderLevel?: number;
  location?: string;
  glAccount?: string; // Inventory control account, defaults to '120000'
  /** Cost formula applied consistently to this item (IAS 2.25). */
  costMethod?: 'weighted_average' | 'fifo' | 'specific';
  /** Latest assessed net realisable value per unit (IAS 2.9 lower of cost and NRV). */
  netRealisableValue?: number;
}

export type StockMovementType =
  | 'Receipt'
  | 'Issue'
  | 'Freight'
  | 'Adjustment'
  | 'WriteDown'
  | 'ReturnIn'
  | 'ReturnOut';

export interface StockMovement {
  id: string;
  clientId: number;
  date: string;
  itemCode: string;
  description: string;
  type: StockMovementType;
  quantity: number;
  unitCost: number;
  totalValue: number;
  uom: string;
  reference?: string;
  docNo?: string;
  note?: string;
}

/** Bill of Materials: components consumed to produce one unit of a finished item. */
export interface BillOfMaterial {
  id: string;
  clientId: number;
  parentItemCode: string;
  componentItemCode: string;
  qtyPerUnit: number;
  uom: string;
  wastePct: number;
  active: boolean;
  [key: string]: unknown;
}

/** Production order: authorises production of finished goods from components. */
export interface ProductionOrder {
  id: string;
  clientId: number;
  docNo: string;
  itemCode: string;
  itemDescription: string;
  qty: number;
  uom: string;
  status: 'Draft' | 'Released' | 'In Production' | 'Completed' | 'Closed';
  startDate: string;
  endDate?: string;
  costCenter: string;
  costCenterName: string;
  glWipAccount: string;
  glWipAccountName: string;
  glFinishedGoodsAccount: string;
  glFinishedGoodsAccountName: string;
  glRawMaterialAccount: string;
  glRawMaterialAccountName: string;
  totalMaterialCost: number;
  totalConversionCost: number;
  totalCost: number;
  createdBy: string;
  createdAt: string;
  [key: string]: unknown;
}

/** Materials issued from raw-materials stock into a production order (WIP). */
export interface ProductionIssue {
  id: string;
  clientId: number;
  productionOrderId: string;
  itemCode: string;
  itemDescription: string;
  qty: number;
  uom: string;
  unitCost: number;
  totalCost: number;
  issuedAt: string;
  issuedBy: string;
  stockMovementId: string;
  [key: string]: unknown;
}

/** Finished goods received from a production order into sellable stock. */
export interface ProductionReceipt {
  id: string;
  clientId: number;
  productionOrderId: string;
  itemCode: string;
  itemDescription: string;
  qty: number;
  uom: string;
  unitCost: number;
  totalCost: number;
  receivedAt: string;
  receivedBy: string;
  stockMovementId: string;
  [key: string]: unknown;
}

export interface PurchaseOrder {
  id: string;
  clientId?: number;
  poNo: string;
  vendorName: string;
  itemType: 'material' | 'service';
  itemCode?: string;
  itemDescription: string;
  qty: number;
  unitPrice: number;
  inwardFreight?: number;
  vatRecoverable: number;
  totalAmount: number;
  paidAmount?: number;
  status: 'Open' | 'Goods Received' | 'Invoiced' | 'Paid' | 'Debited';
  date: string;
  /** Transaction currency of the purchase order (defaults to the entity's functional currency). */
  currency?: string;
  /**
   * VAT treatment of the vendor's quotation / bill:
   * - 'standard'   quotation exclusive of VAT; 20% input VAT added (VAT-registered vendor)
   * - 'inclusive'  quoted price already includes VAT; input VAT split out
   * - 'none'       vendor not VAT-registered / bill not VAT-inclusive; no input VAT
   * - 'zero_rated' zero-rated supply; no input VAT
   */
  vatTreatment?: 'standard' | 'inclusive' | 'none' | 'zero_rated';
  /** VAT-exclusive consideration of the order (used as the WHT base). */
  netAmount?: number;
  /** Supplier quotation / competitive tender reference the PO was raised from. */
  quotationRef?: string;
  glAccount: string;
  glAccountName: string;
  costCenter: string;
  costCenterName: string;
  isAdvance?: boolean;
}

export interface SalesInvoice {
  id: string;
  clientId?: number;
  invNo: string;
  customerName: string;
  revenueStream: string;
  /** Exact revenue GL account selected from Chart of Accounts (defaults to 400000). */
  revenueAccount?: string;
  revenueAccountName?: string;
  itemType?: 'goods' | 'service';
  itemCode?: string;
  quantity?: number;
  unitSellingPrice?: number;
  unitCost?: number;
  cogsAmount?: number;
  netRevenue: number;
  vatOutput: number;
  cstAmount?: number;
  tourismLevyAmount?: number;
  vatWithheldByCustomer?: number;
  totalReceivable: number;
  paidAmount: number;
  status: 'Draft' | 'Open' | 'Partial' | 'Paid' | 'Credited';
  date: string;
  returnToStock?: boolean;
}

export interface AccountMaster {
  accountNo: string;
  name: string;
  type: 'Asset' | 'Liability' | 'Equity' | 'Income' | 'Expense';
  category: string;
  active: boolean;
  isCustom?: boolean;
  /**
   * Owning entity for custom accounts (absent = firm master chart, shared by all).
   * An entity-owned row that shares an account number with a firm master account
   * is a per-entity TAILORING of that master account (renamed, re-categorised or
   * deactivated for that client only) and shadows the master in that workspace.
   */
  clientId?: number;
}

/* ============================================
 * STATUTORY SCHEDULES (WHT & VAT)
 * -----------------------------------------------------------------------------
 * Schedules are derived live from the posted journal (and the sales / purchase
 * registers). Rows can be EDITED (party TIN, nature of payment, references) and
 * manual rows can be ADDED for items that never passed through the Payment Desk.
 * - source 'ledger': editable overrides for a journal-derived row (sourceKey)
 * - source 'manual': a standalone schedule line added by the user
 * -----------------------------------------------------------------------------
 */
export type TaxScheduleKind = 'wht' | 'wht_credit' | 'vat_output' | 'vat_input';

export interface TaxScheduleEntry {
  id: string;
  clientId: number;
  kind: TaxScheduleKind;
  source: 'manual' | 'ledger';
  /** Stable key of the journal-derived row this entry overrides (`${kind}:${docNo}`). */
  sourceKey?: string;
  period: string;
  date: string;
  docNo: string;
  partyName: string;
  partyTin: string;
  /** WHT: nature of payment (goods / services / works / rent …). VAT: supply classification. */
  nature: string;
  /** WHT: gross payment before deduction. VAT: taxable value exclusive of VAT and levies. */
  grossAmount: number;
  /** WHT rate % or VAT rate % applied. */
  rate: number;
  /** WHT amount deducted, or VAT amount. */
  taxAmount: number;
  /** WHT: VAT withheld (appointed agents). VAT: NHIL + GETFund (+ other levies). */
  levyAmount: number;
  reference: string;
  status: string;
  note?: string;
  createdBy: string;
  updatedAt: string;
}

export type PrepaymentCategory =
  | 'Insurance'
  | 'Rent'
  | 'Software subscription'
  | 'Maintenance contract'
  | 'Professional retainer'
  | 'Licence & permits'
  | 'Utilities deposit'
  | 'Other';

export type PrepaymentMethod = 'straight_line' | 'daily_prorata';
export type PrepaymentSource = 'bank' | 'supplier_payable' | 'opening_balance';
export type PrepaymentStatus = 'active' | 'fully_amortised' | 'cancelled';

export interface PrepaymentRecord {
  id: string;
  clientId: number;
  code: string;
  title: string;
  category: PrepaymentCategory;
  vendorName: string;
  reference: string;
  paymentDate: string;
  benefitStart: string;
  benefitEnd: string;
  termMonths: number;
  totalAmount: number;
  prepaidAccountNo: string;
  prepaidAccountName: string;
  expenseAccountNo: string;
  expenseAccountName: string;
  costCenter: string;
  method: PrepaymentMethod;
  source: PrepaymentSource;
  status: PrepaymentStatus;
  createdBy: string;
  createdAt: string;
  note?: string;
}

export interface PrepaymentScheduleLine {
  id: string;
  prepaymentId: string;
  clientId: number;
  sequence: number;
  period: string;
  recognitionDate: string;
  openingBalance: number;
  amount: number;
  closingBalance: number;
  status: 'scheduled' | 'posted';
  docNo?: string;
  postedAt?: string;
}

export interface BusinessPartner {
  id: string;
  clientId?: number;
  code: string;
  name: string;
  type: 'Vendor' | 'Customer';
  tin: string;
  email: string;
  phone: string;
  address: string;
  currency: string;
  isVatWithholdingAgent: boolean;
  vatWithholdingRate?: number;
  isCstApplicable: boolean;
  isTourismLevyApplicable: boolean;
  /** Is the partner VAT-registered (i.e. do their bills carry VAT)? Defaults to true when unset. */
  isVatRegistered?: boolean;
}

export interface FixedAsset {
  id: string;
  clientId?: number;
  assetTag: string;
  name: string;
  classCode: string;
  cost: number;
  accumDep: number;
  /** Carrying amount (cost less accumulated depreciation). Derived — kept for reporting. */
  nbv?: number;
  usefulLife: string;
  /** Depreciation rate percentage per annum (e.g. 20 for 20%). */
  depreciationRate?: number;
  /** Depreciation method chosen (Straight-Line or Reducing Balance). */
  depreciationMethod?: 'straight_line' | 'reducing_balance';
  /** Capital allowance pool (Act 896 Third Schedule): CLASS_1 … CLASS_6 / NONE. */
  capitalAllowanceClass?: string;
  /** Capital allowance rate percentage per annum under Tax Law (e.g. 20, 30, 40). */
  capitalAllowanceRate?: number;
  /** Cumulative capital allowances claimed for tax purposes. */
  accumCapitalAllowance?: number;
  /** Tax Base / Tax Written Down Value (TWDV) = Cost - accumCapitalAllowance. */
  taxBase?: number;
  location: string;
  acquired?: string;
  disposedDate?: string;
  disposalProceeds?: number;
}

export interface IAS12ScheduleRow {
  assetId: string;
  assetTag: string;
  name: string;
  cost: number;
  accountingAccumDep: number;
  accountingNbv: number;
  taxAccumCA: number;
  taxBase: number;
  temporaryDifference: number; // NBV - Tax Base
  deferredTaxType: 'liability' | 'asset' | 'nil';
  deferredTaxAmount: number; // |temporaryDifference| * 25% (or corporate tax rate)
}

export interface PracticeTimesheet {
  id: string;
  staffName: string;
  engagement: string;
  hours: number;
  hourlyRate: number;
  billableFee: number;
  date: string;
  status: 'Approved' | 'Draft';
}

export interface GroupSubsidiary {
  clientId: number;
  code: string;
  name: string;
  ownershipPct: number;
  method: 'Full (IFRS 10)' | 'Equity (IAS 28)';
  nciPct: number;
  goodwill: number;
  reportingCcy: string;
}

export interface EliminationRecord {
  id: string;
  fromEntity: string;
  toEntity: string;
  description: string;
  amount: number;
  eliminated: boolean;
  journalRef: string;
}

export interface DisclosureNote {
  key: string;
  noteNumber: number;
  title: string;
  standardRef: string;
  applicable: boolean;
  notApplicableReason?: string;
  body: string;
  tables?: {
    headers: string[];
    rows: (string | number)[][];
  }[];
  editableOverride?: boolean;
}

/* ============================================
 * PAYE TAX BANDS (Progressive Income Tax)
 * -----------------------------------------------------------------------------
 * Ghana PAYE brackets effective 2024/2025 per GRA
 * -----------------------------------------------------------------------------
 */
export interface PayeBand {
  id: string;
  name: string;
  from: number;        // Lower bound (inclusive)
  to: number | null;   // Upper bound (exclusive), null = no upper limit
  rate: number;        // Percentage rate
  effectiveFrom: string; // Date this band became effective
  isActive: boolean;
}

/* ============================================
 * VAT & TAX COMPONENTS
 * -----------------------------------------------------------------------------
 * Ghana statutory taxes:
 * - VAT: 12.5%
 * - NHIL: 2.5%
 * - GETFund: 2.5%
 * - COVID-19 Recovery Levy: 1%
 * - Total VAT-inclusive rate: 17.5%
 * - Withholding Tax: 5% goods, 7.5% services, 15% professional
 * - CST (Communication Service Tax): 5%
 * - Tourism Levy: 1%
 * -----------------------------------------------------------------------------
 */
export interface TaxComponent {
  id: string;
  code: string;           // e.g. 'VAT', 'NHIL', 'GETFUND', 'COVID', 'WHT_GOODS', 'WHT_SERVICES', 'CST', 'TOURISM_LEVY'
  name: string;
  rate: number;           // Percentage rate
  type: 'sales_tax' | 'purchase_tax' | 'withholding_tax' | 'special_levy';
  appliesTo: 'sales' | 'purchase' | 'both';
  isActive: boolean;
  effectiveFrom: string;
}

/* ============================================
 * BUSINESS PARTNER EXTENSIONS
 * -----------------------------------------------------------------------------
 * Extended fields for tax withholding agent status
 * -----------------------------------------------------------------------------
 */
export interface BusinessPartnerExtended extends BusinessPartner {
  isVatWithholdingAgent: boolean;      // Is this customer a VAT withholding agent?
  vatWithholdingRate?: number;         // Custom WHT rate if different from default
  isCstApplicable: boolean;            // Is Communication Service Tax applicable?
  isTourismLevyApplicable: boolean;    // Is Tourism Levy applicable?
}

/* ============================================
 * EMPLOYEE EXTENSIONS
 * -----------------------------------------------------------------------------
 * SSNIT exemption flag
 * -----------------------------------------------------------------------------
 */
export interface EmployeeProfileExtended extends EmployeeProfile {
  ssnitExempt: boolean;           // Is employee exempt from SSNIT?
  ssnitExemptionReason?: string;  // Reason for exemption
}
