import type { ClientEntity, UserAccount } from '../types/accounting';
import {
  CLIENT_MODULE_IDS,
  OWNER_ONLY_MODULES,
  isSectionInServices,
  serviceForSection,
} from './moduleCatalog';

export { serviceForSection };

const REPORT_SECTION_IDS = [
  'report_sales_r',
  'report_purchases_r',
  'report_inventory_r',
  'report_clients_r',
  'report_store_r',
  'report_production_r',
  'report_hr_r',
  'report_ageing_r',
  'report_financial_r',
];

/** Canonical alias map so legacy route ids inherit the same module tick as their primary module. */
const SECTION_TICK_ALIAS: Record<string, string> = {
  manual_journal: 'universal_journal',
  standards_desk: 'ifrs_desk',
  ifrs_schedules: 'ifrs_desk',
  tax_schedules: 'tax_schedule',
  business_partners: 'business_partners_crm',
  financial_reports: 'report_financial_r',
  report_sales: 'report_sales_r',
  report_purchases: 'report_purchases_r',
  report_inventory: 'report_inventory_r',
  report_clients: 'report_clients_r',
  report_clients_crm: 'report_clients_r',
  report_store: 'report_store_r',
  report_hr: 'report_hr_r',
  report_financial: 'report_financial_r',
  financial_issue_position: 'ifrs_statements',
  financial_issue_profit: 'ifrs_statements',
  financial_issue_equity: 'ifrs_statements',
  financial_issue_cashflow: 'ifrs_statements',
  financial_issue_notes: 'disclosures',
  financial_issue_compliance: 'compliance_review',
};

export const maySeeSection = (user: UserAccount, client: ClientEntity, section: string): boolean => {
  if (user.role === 'owner') return true;
  // Firm administration is never shown to anyone but the Firm Owner.
  if (OWNER_ONLY_MODULES.has(section)) return false;
  if (user.clientId && user.clientId !== client.id) return false;
  if (user.status === 'restricted' || user.status === 'suspended') return false;

  if (!isSectionInServices(section, client.assignedServices)) return false;

  // Per-user module ticks: when the owner has ticked specific modules, only those open.
  const allowed = user.permissions?.allowedModules;
  if (Array.isArray(allowed)) {
    const canonical = SECTION_TICK_ALIAS[section] ?? section;
    if (canonical === 'reports') {
      const anyReportAllowed = REPORT_SECTION_IDS.some((r) => allowed.includes(r) && isSectionInServices(r, client.assignedServices));
      if (!allowed.includes('reports') && !anyReportAllowed) return false;
    } else if (CLIENT_MODULE_IDS.has(canonical) && !allowed.includes(canonical)) {
      return false;
    }
  }

  if (section === 'payroll' && user.permissions?.canRunPayroll === false) return false;
  if (section === 'month_end' && user.permissions?.canClosePeriod === false) return false;
  if (section === 'coa_master' && user.permissions?.canModifyCOA === false) return false;
  return true;
};

/**
 * Firm-wide data scope: the owner plus firm-level partner/manager accounts that
 * are not bound to a client entity. Shared by the API (tenant filtering) and the
 * UI (entity switcher) so both apply exactly the same rule.
 */
export function hasFirmWideScope(user: { role: string; clientId?: number | null }): boolean {
  if (user.role === 'owner') return true;
  return (user.clientId === undefined || user.clientId === null) && (user.role === 'partner' || user.role === 'manager');
}

/**
 * Who may rename / re-categorise / deactivate general ledger (chart of
 * accounts) names.
 */
export const mayEditChartOfAccounts = (user: {
  role: string;
  status?: string;
  permissions?: { canModifyCOA?: boolean };
}): boolean => {
  if (user.status === 'restricted' || user.status === 'suspended') return false;
  if (user.role === 'owner') return true;
  if (user.role !== 'manager') return false;
  return user.permissions?.canModifyCOA !== false;
};

/** Human-readable reason shown when the chart of accounts is read-only. */
export const chartEditDenialReason = (user: { role: string; status?: string; permissions?: { canModifyCOA?: boolean } }): string => {
  if (user.status === 'restricted' || user.status === 'suspended') return 'Your account is restricted, so master data cannot be changed.';
  if (user.role === 'owner' || user.role === 'manager') return 'Your chart-of-accounts rights have been withdrawn by the Firm Owner.';
  return 'Only the Firm Owner or the entity\'s owner/manager may edit general ledger account names. Your role has read and posting access only.';
};
