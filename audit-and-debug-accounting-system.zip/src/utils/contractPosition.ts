/* IFRS 15 contract position movement in minor units.
 * A move from an unbilled contract asset to an over-billed contract liability
 * must clear the asset AND recognise the liability, not merely post the net
 * difference to one side. This calculation still requires independently
 * evidenced cost-to-complete and billing inputs before any journal is approved.
 */
export interface ContractPositionLeg {
  accountNo: '118100' | '225000' | '400000';
  debit: number;
  credit: number;
}

const cents = (amount: number) => Math.round(amount * 100);
const money = (amount: number) => amount / 100;

export function contractPositionMovement(
  netTarget: number,
  currentAsset: number,
  currentLiability: number,
): ContractPositionLeg[] {
  if (![netTarget, currentAsset, currentLiability].every(Number.isFinite) || currentAsset < 0 || currentLiability < 0) {
    throw new Error('Contract position amounts must be finite; gross asset and liability balances cannot be negative.');
  }
  const target = cents(netTarget);
  const assetMove = Math.max(0, target) - cents(currentAsset);
  const liabilityMove = Math.max(0, -target) - cents(currentLiability);
  const revenueMove = assetMove - liabilityMove;
  const legs: ContractPositionLeg[] = [];
  const push = (accountNo: ContractPositionLeg['accountNo'], signedDebit: number) => {
    if (signedDebit === 0) return;
    legs.push({ accountNo, debit: signedDebit > 0 ? money(signedDebit) : 0, credit: signedDebit < 0 ? money(-signedDebit) : 0 });
  };
  push('118100', assetMove);
  push('225000', -liabilityMove);
  push('400000', -revenueMove);
  return legs;
}
