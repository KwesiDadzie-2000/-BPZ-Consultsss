import type {
  ACDOCALine,
  AccountMaster,
  BankAccount,
  FixedAsset,
  PrepaymentRecord,
  PrepaymentScheduleLine,
  PurchaseOrder,
  SalesInvoice,
  StockItem,
} from '../types/accounting';
import { deriveExpenseBills, EXPENSE_PAYABLE_ACCOUNT } from './payables';

const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const toMinor = (n: number) => Math.round(n * 100);

export type SubledgerFamily =
  | 'treasury'
  | 'receivables'
  | 'payables'
  | 'accrued_payables'
  | 'prepayments'
  | 'inventory_rm'
  | 'inventory_fg'
  | 'inventory_wip'
  | 'inventory_spares'
  | 'fixed_assets'
  | 'accum_depreciation'
  | 'payroll'
  | 'debt_service'
  | 'tax';

export interface ControlAccountDef {
  accountNo: string;
  label: string;
  normalSide: 'debit' | 'credit';
  subledgerFamily: SubledgerFamily;
  subledgerLabel: string;
  subledgerSection: string;
  /** True when direct manual `JE` postings should be restricted to Owner/Manager reconciliation overrides. */
  lockDirectManualEntry: boolean;
  /** Operational modules that legitimately post to this control account. */
  expectedModules: string[];
}

export const CONTROL_ACCOUNT_DEFINITIONS: ControlAccountDef[] = [
  {
    accountNo: '100000',
    label: 'Cash at Bank — Operating Control',
    normalSide: 'debit',
    subledgerFamily: 'treasury',
    subledgerLabel: 'Treasury & Bank Accounts (100000)',
    subledgerSection: 'banking',
    lockDirectManualEntry: false,
    expectedModules: ['FI', 'SD', 'MM', 'HR'],
  },
  {
    accountNo: '101000',
    label: 'Foreign Currency Bank Control',
    normalSide: 'debit',
    subledgerFamily: 'treasury',
    subledgerLabel: 'Treasury & Bank Accounts (101000)',
    subledgerSection: 'banking',
    lockDirectManualEntry: false,
    expectedModules: ['FI', 'SD', 'MM'],
  },
  {
    accountNo: '102000',
    label: 'Petty Cash Float Control',
    normalSide: 'debit',
    subledgerFamily: 'treasury',
    subledgerLabel: 'Treasury & Cash Floats (102000)',
    subledgerSection: 'banking',
    lockDirectManualEntry: false,
    expectedModules: ['FI'],
  },
  {
    accountNo: '104000',
    label: 'Mobile Money Clearing Control',
    normalSide: 'debit',
    subledgerFamily: 'treasury',
    subledgerLabel: 'Treasury & Mobile Money (104000)',
    subledgerSection: 'banking',
    lockDirectManualEntry: false,
    expectedModules: ['FI'],
  },
  {
    accountNo: '110000',
    label: 'Trade Receivables Control',
    normalSide: 'debit',
    subledgerFamily: 'receivables',
    subledgerLabel: 'Sales Invoices & Customer Receipts (O2C)',
    subledgerSection: 'sales',
    lockDirectManualEntry: true,
    expectedModules: ['SD', 'FI'],
  },
  {
    accountNo: '200000',
    label: 'Trade Payables Control',
    normalSide: 'credit',
    subledgerFamily: 'payables',
    subledgerLabel: 'Purchase Orders & Supplier Payments (P2P)',
    subledgerSection: 'procurement',
    lockDirectManualEntry: true,
    expectedModules: ['MM', 'FI'],
  },
  {
    accountNo: '202000',
    label: 'Accrued Expenses & Other Payables Control',
    normalSide: 'credit',
    subledgerFamily: 'accrued_payables',
    subledgerLabel: 'Expense Bills & Payment Desk Settlements',
    subledgerSection: 'expenses',
    lockDirectManualEntry: true,
    expectedModules: ['FI'],
  },
  {
    accountNo: '120000',
    label: 'Inventories — Raw Materials Control',
    normalSide: 'debit',
    subledgerFamily: 'inventory_rm',
    subledgerLabel: 'Perpetual Stock Register (120000)',
    subledgerSection: 'inventory_ledger',
    lockDirectManualEntry: true,
    expectedModules: ['MM', 'PP', 'INV'],
  },
  {
    accountNo: '121000',
    label: 'Inventories — Finished Goods Control',
    normalSide: 'debit',
    subledgerFamily: 'inventory_fg',
    subledgerLabel: 'Perpetual Stock Register (121000)',
    subledgerSection: 'inventory_ledger',
    lockDirectManualEntry: true,
    expectedModules: ['PP', 'SD', 'INV'],
  },
  {
    accountNo: '122000',
    label: 'Work-in-Progress (WIP) Control',
    normalSide: 'debit',
    subledgerFamily: 'inventory_wip',
    subledgerLabel: 'Production Work Orders (Open WIP)',
    subledgerSection: 'production_desk',
    lockDirectManualEntry: true,
    expectedModules: ['PP'],
  },
  {
    accountNo: '123000',
    label: 'Inventories — Spares & Consumables Control',
    normalSide: 'debit',
    subledgerFamily: 'inventory_spares',
    subledgerLabel: 'Perpetual Stock Register (123000)',
    subledgerSection: 'inventory_ledger',
    lockDirectManualEntry: true,
    expectedModules: ['MM', 'INV'],
  },
  {
    accountNo: '130000',
    label: 'Property, Plant & Equipment Cost Control',
    normalSide: 'debit',
    subledgerFamily: 'fixed_assets',
    subledgerLabel: 'Fixed Assets Register (Gross Cost)',
    subledgerSection: 'assets',
    lockDirectManualEntry: true,
    expectedModules: ['FI-AA'],
  },
  {
    accountNo: '139000',
    label: 'Accumulated Depreciation & Impairment Control',
    normalSide: 'credit',
    subledgerFamily: 'accum_depreciation',
    subledgerLabel: 'Fixed Assets Register (Accum. Dep)',
    subledgerSection: 'assets',
    lockDirectManualEntry: true,
    expectedModules: ['FI-AA'],
  },
  {
    accountNo: '116000',
    label: 'Prepayments & Deferred Charges Control',
    normalSide: 'debit',
    subledgerFamily: 'prepayments',
    subledgerLabel: 'Prepayment Amortisation Schedules',
    subledgerSection: 'prepayments',
    lockDirectManualEntry: true,
    expectedModules: ['FI'],
  },
  {
    accountNo: '213000', label: 'Accrued Interest & Debt Service Payable Control', normalSide: 'credit',
    subledgerFamily: 'debt_service', subledgerLabel: 'Loan accruals and referenced Payment Desk settlements',
    subledgerSection: 'payment_desk', lockDirectManualEntry: true, expectedModules: ['FI'],
  },
  {
    accountNo: '205000',
    label: 'Net Salaries Payable Control',
    normalSide: 'credit',
    subledgerFamily: 'payroll',
    subledgerLabel: 'Payroll Desk & Salary Disbursements',
    subledgerSection: 'payroll',
    lockDirectManualEntry: true,
    expectedModules: ['HR', 'FI'],
  },
  {
    accountNo: '206000',
    label: 'SSNIT Tier 1 Statutory Control (13.5%)',
    normalSide: 'credit',
    subledgerFamily: 'payroll',
    subledgerLabel: 'Payroll & Statutory Remittance Schedule',
    subledgerSection: 'tax_schedule',
    lockDirectManualEntry: false,
    expectedModules: ['HR', 'FI'],
  },
  {
    accountNo: '206100',
    label: 'SSNIT Tier 2 Occupational Pension Control (5%)',
    normalSide: 'credit',
    subledgerFamily: 'payroll',
    subledgerLabel: 'Payroll & Statutory Remittance Schedule',
    subledgerSection: 'tax_schedule',
    lockDirectManualEntry: false,
    expectedModules: ['HR', 'FI'],
  },
  {
    accountNo: '207000',
    label: 'GRA PAYE Income Tax Control',
    normalSide: 'credit',
    subledgerFamily: 'payroll',
    subledgerLabel: 'Payroll & GRA PAYE Schedule',
    subledgerSection: 'tax_schedule',
    lockDirectManualEntry: false,
    expectedModules: ['HR', 'FI'],
  },
  {
    accountNo: '209000',
    label: 'Withholding Tax (WHT) Payable Control',
    normalSide: 'credit',
    subledgerFamily: 'tax',
    subledgerLabel: 'WHT Deduction Schedule',
    subledgerSection: 'tax_schedule',
    lockDirectManualEntry: false,
    expectedModules: ['FI'],
  },
  {
    accountNo: '125000',
    label: 'VAT Input Tax Recoverable Control',
    normalSide: 'debit',
    subledgerFamily: 'tax',
    subledgerLabel: 'Input VAT Schedule',
    subledgerSection: 'tax_schedule',
    lockDirectManualEntry: false,
    expectedModules: ['MM', 'FI'],
  },
  {
    accountNo: '220000',
    label: 'VAT / NHIL / GETFund Output Control',
    normalSide: 'credit',
    subledgerFamily: 'tax',
    subledgerLabel: 'Output VAT Schedule',
    subledgerSection: 'tax_schedule',
    lockDirectManualEntry: false,
    expectedModules: ['SD', 'FI'],
  },
];

const CONTROL_MAP = new Map<string, ControlAccountDef>(
  CONTROL_ACCOUNT_DEFINITIONS.map((d) => [d.accountNo, d])
);

export function getControlAccountDef(accountNo: string): ControlAccountDef | undefined {
  return CONTROL_MAP.get(accountNo);
}

export interface ControlAccountReconciliationRow {
  def: ControlAccountDef;
  accountName: string;
  glBalance: number;
  subledgerBalance: number;
  variance: number;
  /** True only when a distinct operational register exists to compare with the GL. */
  independentlySupported: boolean;
  /** A register-to-GL tie-out, not a bank statement / regulator confirmation. */
  reconciled: boolean;
  directManualLines: ACDOCALine[];
  directManualAmount: number;
  subledgerItemCount: number;
  diagnosis: string;
}

export interface ControlReconciliationInput {
  clientId: number;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  bankAccounts: BankAccount[];
  salesInvoices: SalesInvoice[];
  purchaseOrders: PurchaseOrder[];
  stockItems: StockItem[];
  fixedAssets: FixedAsset[];
  prepaymentRecords: PrepaymentRecord[];
  prepaymentSchedules: PrepaymentScheduleLine[];
  openWipFromOrders?: number;
  openWipOrderCount?: number;
}

export function reconcileControlAccounts(input: ControlReconciliationInput): ControlAccountReconciliationRow[] {
  const {
    clientId,
    lines,
    accounts,
    bankAccounts,
    salesInvoices,
    purchaseOrders,
    stockItems,
    fixedAssets,
    prepaymentRecords,
    prepaymentSchedules,
    openWipFromOrders,
    openWipOrderCount,
  } = input;

  const clientLines = lines.filter((l) => l.clientId === clientId);
  const nameOf = (accNo: string, fallback: string) =>
    accounts.find((a) => a.accountNo === accNo)?.name || fallback;

  return CONTROL_ACCOUNT_DEFINITIONS.map((def) => {
    const accLines = clientLines.filter((l) => l.accountNo === def.accountNo);
    const glMinor = accLines.reduce(
      (s, l) => s + (def.normalSide === 'debit' ? toMinor(l.debit) - toMinor(l.credit) : toMinor(l.credit) - toMinor(l.debit)),
      0
    );
    const glBalance = r2(glMinor / 100);

    // Direct manual JE lines (entries posted through Manual Journal / GL without subledger workflow)
    const directManualLines = accLines.filter(
      (l) => l.docType === 'JE' && !l.docNo.startsWith('DOC-OPEN-BAL') && !l.docNo.startsWith('OPEN-') && !l.docNo.startsWith('YE-CLOSE-')
    );
    const directManualAmount = r2(
      directManualLines.reduce(
        (s, l) => s + (def.normalSide === 'debit' ? l.debit - l.credit : l.credit - l.debit),
        0
      )
    );

    let subledgerBalance = 0;
    let subledgerItemCount = 0;

    switch (def.subledgerFamily) {
      case 'treasury': {
        const matchingBanks = bankAccounts.filter(
          (b) => (b.clientId ?? clientId) === clientId && (b.glAccount || '100000') === def.accountNo
        );
        subledgerBalance = r2(matchingBanks.reduce((s, b) => s + b.balance, 0));
        subledgerItemCount = matchingBanks.length;
        break;
      }
      case 'receivables': {
        const openInvoices = salesInvoices.filter(
          (i) => (i.clientId ?? clientId) === clientId && i.status !== 'Draft' && i.status !== 'Credited'
        );
        subledgerBalance = r2(openInvoices.reduce((s, i) => s + Math.max(0, i.totalReceivable - (i.paidAmount || 0)), 0));
        subledgerItemCount = openInvoices.filter((i) => i.totalReceivable - (i.paidAmount || 0) > 0.009).length;
        break;
      }
      case 'payables': {
        const openOrders = purchaseOrders.filter(
          (p) => (p.clientId ?? clientId) === clientId && p.status !== 'Open' && p.status !== 'Debited'
        );
        subledgerBalance = r2(openOrders.reduce((s, p) => s + Math.max(0, p.totalAmount - (p.paidAmount || 0)), 0));
        subledgerItemCount = openOrders.filter((p) => p.totalAmount - (p.paidAmount || 0) > 0.009).length;
        break;
      }
      case 'accrued_payables': {
        const bills = deriveExpenseBills(clientLines, clientId).filter(
          (b) => b.status === 'Awaiting payment' || b.status === 'Partially paid'
        );
        subledgerBalance = r2(bills.reduce((s, b) => s + b.outstanding, 0));
        subledgerItemCount = bills.length;
        break;
      }
      case 'inventory_rm': {
        const items = stockItems.filter(
          (s) => s.clientId === clientId && (s.glAccount || '120000') === '120000'
        );
        subledgerBalance = r2(items.reduce((s, i) => s + i.totalValue, 0));
        subledgerItemCount = items.length;
        break;
      }
      case 'inventory_fg': {
        const items = stockItems.filter(
          (s) => s.clientId === clientId && s.glAccount === '121000'
        );
        subledgerBalance = r2(items.reduce((s, i) => s + i.totalValue, 0));
        subledgerItemCount = items.length;
        break;
      }
      case 'inventory_wip': {
        subledgerBalance = openWipFromOrders !== undefined ? r2(openWipFromOrders) : glBalance;
        subledgerItemCount = openWipOrderCount ?? 0;
        break;
      }
      case 'inventory_spares': {
        const items = stockItems.filter(
          (s) => s.clientId === clientId && s.glAccount === '123000'
        );
        subledgerBalance = r2(items.reduce((s, i) => s + i.totalValue, 0));
        subledgerItemCount = items.length;
        break;
      }
      case 'fixed_assets': {
        const active = fixedAssets.filter((a) => (a.clientId ?? clientId) === clientId && !a.disposedDate);
        subledgerBalance = r2(active.reduce((s, a) => s + a.cost, 0));
        subledgerItemCount = active.length;
        break;
      }
      case 'accum_depreciation': {
        const active = fixedAssets.filter((a) => (a.clientId ?? clientId) === clientId && !a.disposedDate);
        subledgerBalance = r2(active.reduce((s, a) => s + a.accumDep, 0));
        subledgerItemCount = active.length;
        break;
      }
      case 'prepayments': {
        const activePrepayments = prepaymentRecords.filter(
          (p) => (p.clientId ?? clientId) === clientId && p.status === 'active'
        );
        const activeIds = new Set(activePrepayments.map((p) => p.id));
        const unpostedLines = prepaymentSchedules.filter(
          (s) => (s.clientId ?? clientId) === clientId && activeIds.has(s.prepaymentId) && s.status !== 'posted'
        );
        subledgerBalance = r2(unpostedLines.reduce((s, l) => s + l.amount, 0));
        subledgerItemCount = activePrepayments.length;
        break;
      }
      case 'debt_service': {
        subledgerBalance = glBalance;
        subledgerItemCount = accLines.filter((l) => l.docNo.startsWith('LOAN-ACC-')).length;
        break;
      }
      case 'payroll':
      case 'tax': {
        // No external PAYE/SSNIT/GRA returns are loaded here. Calling the
        // journal itself a "subledger" would falsely show a perfect tie-out.
        subledgerBalance = glBalance;
        subledgerItemCount = accLines.length;
        break;
      }
    }

    const independentlySupported = subledgerItemCount > 0 &&
      !['payroll', 'tax', 'accrued_payables', 'inventory_wip', 'debt_service'].includes(def.subledgerFamily);
    const variance = r2(glBalance - subledgerBalance);
    const reconciled = independentlySupported && Math.abs(variance) < 0.01;

    let diagnosis = 'Working register ties to its GL control account; confirm external source evidence separately.';
    if (!independentlySupported && Math.abs(variance) < 0.01) {
      diagnosis = def.subledgerFamily === 'debt_service'
        ? 'Debt open items are derived from the same accrual/payment journal. Reconcile facility statements and lender confirmations independently.'
        : def.subledgerFamily === 'payroll' || def.subledgerFamily === 'tax'
        ? 'Not independently verified: this schedule is calculated from the same journal. Reconcile to approved payroll, GRA/SSNIT returns and actual remittances.'
        : def.subledgerFamily === 'inventory_wip'
          ? 'WIP values derive from posted journals. Match material quantities, conversion evidence and work orders independently before close.'
          : def.subledgerFamily === 'accrued_payables'
            ? 'Expense bills are reconstructed from journal descriptions; obtain the original invoice register and supplier statements for independent sign-off.'
            : 'No separate subledger records support this zero balance yet. Do not interpret a zero difference as a verified control.';
    } else if (Math.abs(variance) >= 0.01) {
      if (directManualLines.length > 0 && Math.abs(variance - directManualAmount) < 0.05) {
        diagnosis = `Explained by ${directManualLines.length} direct manual journal line(s) posted to ${def.accountNo} without a subledger document.`;
      } else if (def.subledgerFamily === 'treasury') {
        diagnosis = 'Treasury working balance differs from GL — click "Reconcile Working Balances to GL" or verify opening bank balances.';
      } else if (def.subledgerFamily === 'receivables' || def.subledgerFamily === 'payables') {
        diagnosis = 'GL includes opening or manual entries without matching subledger invoices/orders, or unposted draft documents exist.';
      } else {
        diagnosis = `GL (${glBalance.toFixed(2)}) and ${def.subledgerLabel} (${subledgerBalance.toFixed(2)}) differ by ${variance.toFixed(2)}. Review subledger entries or direct journals.`;
      }
    }

    return {
      def,
      accountName: nameOf(def.accountNo, def.label),
      glBalance,
      subledgerBalance,
      variance,
      independentlySupported,
      reconciled,
      directManualLines,
      directManualAmount,
      subledgerItemCount,
      diagnosis,
    };
  });
}
