export type ExcelCell = string | number | boolean | null | undefined;
export interface ExcelSheet { name: string; columns: string[]; rows: ExcelCell[][]; moneyColumns?: number[] }

/** A genuine XLSX workbook, with numeric money cells, frozen headers and filters.
 * Loaded only when the user exports. Strings are never interpreted as formulas.
 */
export async function buildExcelBuffer(sheets: ExcelSheet[]): Promise<Uint8Array> {
  type ExcelModule = typeof import('exceljs');
  const imported: unknown = await import('exceljs');
  const candidate = imported as { Workbook?: ExcelModule['Workbook']; default?: { Workbook?: ExcelModule['Workbook'] } };
  const Workbook = candidate.Workbook ?? candidate.default?.Workbook;
  if (!Workbook) throw new Error('Excel writer could not be loaded.');
  const workbook = new Workbook();
  workbook.creator = 'BPZ Consult';
  workbook.created = new Date();
  for (const spec of sheets) {
    const name = spec.name.replace(/[\\/*?:\[\]]/g, '-').slice(0, 31) || 'Schedule';
    let unique = name; let suffix = 2;
    while (workbook.getWorksheet(unique)) unique = `${name.slice(0, 27)}-${suffix++}`;
    const sheet = workbook.addWorksheet(unique, { views: [{ state: 'frozen', ySplit: 1 }] });
    sheet.addRow(spec.columns);
    for (const row of spec.rows) sheet.addRow(row.map((v) => v == null ? '' : v));
    sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
    sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF082F4F' } };
    sheet.getRow(1).alignment = { wrapText: true, vertical: 'middle' };
    sheet.getRow(1).height = 30;
    sheet.columns.forEach((col, i) => {
      const length = Math.max(spec.columns[i].length, ...spec.rows.slice(0, 200).map((r) => String(r[i] ?? '').length));
      col.width = Math.min(42, Math.max(13, length + 2));
      if (spec.moneyColumns?.includes(i)) col.numFmt = '#,##0.00;[Red](#,##0.00)';
    });
    if (spec.columns.length) sheet.autoFilter = { from: { row: 1, column: 1 }, to: { row: Math.max(1, spec.rows.length + 1), column: spec.columns.length } };
    sheet.pageSetup = { orientation: spec.columns.length > 7 ? 'landscape' : 'portrait', paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0, printTitlesRow: '1:1' };
    sheet.headerFooter.oddFooter = '&LBPZ Consult — working paper&RPage &P of &N';
  }
  const buffer = await workbook.xlsx.writeBuffer();
  return new Uint8Array(buffer as ArrayBuffer);
}

export async function downloadExcel(filename: string, sheets: ExcelSheet[]): Promise<void> {
  const bytes = await buildExcelBuffer(sheets);
  const blob = new Blob([new Uint8Array(bytes)], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a'); anchor.href = url;
  anchor.download = filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`;
  document.body.appendChild(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
