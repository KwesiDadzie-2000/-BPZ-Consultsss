import { addMonths } from './ifrsSchedules';
import { isValidIsoDate } from '@/lib/journalValidation';
import type { ACDOCALine } from '@/types/accounting';

export type FacilityType = 'amortising' | 'interest_only' | 'bullet';
export interface LoanFacility {
  id: string; code: string; facilityName: string; lender: string;
  principal: number; annualRatePct: number; termMonths: number;
  frequency: 'monthly' | 'quarterly'; facilityType: FacilityType;
  arrangementFee: number; startDate: string; status: 'Active';
}
export interface AmortisationRow {
  periodNum: number; date: string; openingBalance: number; interestExpense: number;
  principalPayment: number; totalPayment: number; closingBalance: number;
}
export const DEBT_PAYABLE_ACCOUNT = '213000';
export const cents = (n: number) => Math.round(n * 100);
export const money = (n: number) => cents(n) / 100;
export const debtReference = (code: string, period: number) => `LOAN:${code}:M${period}`;
export const debtAccrualDoc = (code: string, period: number) => `LOAN-ACC-${code}-M${period}`;

/** Nominal annual rate / payment frequency. All schedule legs are exact cents.
 * The final instalment absorbs rounding, so it may differ by a few pesewas.
 * Bullet loans accrue interest every period even when no cash is due.
 */
export function generateLoanSchedule(loan: LoanFacility): AmortisationRow[] {
  if (!loan || !Number.isFinite(loan.principal) || loan.principal <= 0 || loan.principal > 1e10 || cents(loan.principal) !== loan.principal * 100 && Math.abs(cents(loan.principal) - loan.principal * 100) > 1e-5) throw new Error('Principal must be a positive amount with at most two decimal places.');
  if (!Number.isFinite(loan.annualRatePct) || loan.annualRatePct < 0 || loan.annualRatePct > 100) throw new Error('Annual interest rate must be between 0 and 100%.');
  if (!Number.isInteger(loan.termMonths) || loan.termMonths < 1 || loan.termMonths > 600) throw new Error('Loan term must be 1–600 whole months.');
  if (!['monthly', 'quarterly'].includes(loan.frequency)) throw new Error('Choose monthly or quarterly payments.');
  const step = loan.frequency === 'quarterly' ? 3 : 1;
  if (loan.termMonths % step !== 0) throw new Error('A quarterly facility needs a term divisible by three months.');
  if (!['amortising', 'interest_only', 'bullet'].includes(loan.facilityType)) throw new Error('Unknown repayment structure.');
  if (!isValidIsoDate(loan.startDate)) throw new Error('A valid facility start date is required.');
  if (!Number.isFinite(loan.arrangementFee) || loan.arrangementFee < 0 || loan.arrangementFee > loan.principal) throw new Error('Arrangement fee must be between zero and principal.');
  const n = loan.termMonths / step;
  const rate = loan.annualRatePct / 100 * step / 12;
  let balance = cents(loan.principal);
  const instalment = loan.facilityType === 'amortising'
    ? cents(rate === 0 ? balance / 100 / n : (balance / 100 * rate) / (1 - Math.pow(1 + rate, -n)))
    : 0;
  const rows: AmortisationRow[] = [];
  for (let k = 1; k <= n; k++) {
    const opening = balance;
    const interest = cents(opening / 100 * rate);
    let principal = 0;
    if (loan.facilityType === 'amortising') principal = k === n ? opening : Math.min(opening, Math.max(0, instalment - interest));
    else if (k === n) principal = opening;
    balance = opening - principal;
    const cash = loan.facilityType === 'bullet' && k !== n ? 0 : interest + principal;
    rows.push({ periodNum: k, date: addMonths(loan.startDate, k * step), openingBalance: opening / 100,
      interestExpense: interest / 100, principalPayment: principal / 100, totalPayment: cash / 100, closingBalance: balance / 100 });
  }
  return rows;
}

export interface DebtServiceBill {
  docNo: string; reference: string; date: string; lender: string; gross: number; paid: number; outstanding: number;
}
/** Per-obligation open items, derived from posted accruals and referenced payments. */
export function deriveDebtServiceBills(lines: readonly ACDOCALine[], clientId: number): DebtServiceBill[] {
  const scoped = lines.filter((l) => l.clientId === clientId);
  const accruals = scoped.filter((l) => l.accountNo === DEBT_PAYABLE_ACCOUNT && l.docNo.startsWith('LOAN-ACC-') && l.credit > 0);
  return accruals.map((l) => {
    const paid = money(scoped.filter((p) => p.accountNo === DEBT_PAYABLE_ACCOUNT && p.docNo !== l.docNo && p.docType === 'PAY' && (p.reference === l.docNo || p.description.includes(l.docNo)))
      .reduce((s, p) => s + p.debit - p.credit, 0));
    const outstanding = money(Math.max(0, l.credit - paid));
    const code = l.reference?.split(':')[1] || l.docNo;
    return { docNo: l.docNo, reference: l.reference || l.docNo, date: l.date, lender: code, gross: l.credit, paid, outstanding };
  }).sort((a, b) => a.date.localeCompare(b.date));
}
