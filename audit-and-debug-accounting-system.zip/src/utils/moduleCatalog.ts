/**
 * Single source of truth for workspace modules (sidebar section ids).
 *
 * Used by:
 *  - `maySeeSection` (utils/access.ts) — UI and sidebar visibility for every user,
 *  - the Client Workspaces & User Access desks — the owner ticks which modules
 *    a client user may open (`permissions.allowedModules`),
 *  - the server APIs (/api/users, /api/clients, /api/desk, /api/workbooks,
 *    /api/trade, /api/journal) — validates and enforces module access.
 *
 * OWNER_ONLY_MODULES are firm administration. They are never shown to clients,
 * regardless of contract services or per-user ticks.
 */

export interface ModuleCatalogEntry {
  id: string;
  label: string;
  group: string;
}

/** Modules that only the Firm Owner can open. */
export const OWNER_ONLY_MODULES: ReadonlySet<string> = new Set([
  'clients_management',
  'advisory',
  'user_permissions',
  'group_consolidation',
  'enterprise_sso',
  'global_tax',
  'tax_settings',
  'soc_dr',
  'realtime_integrations',
]);

/** Client-facing modules a firm can tick for a client user. Dashboard is always visible. */
export const CLIENT_MODULE_CATALOG: ModuleCatalogEntry[] = [
  { id: 'company_profile', label: 'Company Profile & Backup', group: 'Setup' },
  { id: 'sector_workflow', label: 'Sector Workflow Switcher', group: 'Setup' },
  { id: 'opening_balance', label: 'Opening Balances Setup', group: 'Setup' },
  { id: 'coa_master', label: 'Chart of Accounts Master', group: 'Setup' },
  { id: 'universal_journal', label: 'Journals (Universal & Manual)', group: 'Ledger' },
  { id: 'general_ledger', label: 'General Ledger', group: 'Ledger' },
  { id: 'control_accounts', label: 'Control Accounts & Tie-Out', group: 'Ledger' },
  { id: 'adjustments', label: 'Adjustment of Accounts', group: 'Ledger' },
  { id: 'month_end', label: 'Month-End Close', group: 'Ledger' },
  { id: 'procurement', label: 'Procurement & P2P', group: 'Trade' },
  { id: 'sales', label: 'Sales & Invoicing · O2C', group: 'Trade' },
  { id: 'business_partners_crm', label: 'Client Master File', group: 'Trade' },
  { id: 'expenses', label: 'Expenses & Statutory', group: 'Trade' },
  { id: 'payment_desk', label: 'Payment Desk', group: 'Treasury' },
  { id: 'banking', label: 'Banking & Reconcile', group: 'Treasury' },
  { id: 'ageing', label: 'Ageing Analysis (AR & AP)', group: 'Treasury' },
  { id: 'inventory', label: 'Inventory Command Desk', group: 'Operations' },
  { id: 'inventory_ledger', label: 'Stock Ledger & Valuation', group: 'Operations' },
  { id: 'boms', label: 'Bill of Materials', group: 'Operations' },
  { id: 'production_desk', label: 'Production Desk', group: 'Operations' },
  { id: 'assets', label: 'Fixed Assets Register', group: 'Operations' },
  { id: 'prepayments', label: 'Prepayments & Deferrals', group: 'Operations' },
  { id: 'payroll', label: 'Payroll Desk', group: 'People' },
  { id: 'hr_desk', label: 'HR Management Desk', group: 'People' },
  { id: 'hr_employees', label: 'Employees', group: 'People' },
  { id: 'hr_attendance', label: 'Employee Attendance', group: 'People' },
  { id: 'hr_requests', label: 'Employee Requests', group: 'People' },
  { id: 'hr_structure', label: 'Organisational Structure', group: 'People' },
  { id: 'hr_tasks', label: 'Task Management', group: 'People' },
  { id: 'tax_schedule', label: 'Tax Desk (Schedules, Returns & Filing)', group: 'Tax & Compliance' },
  { id: 'ifrs_desk', label: 'IFRS Desk (Standards + Schedules)', group: 'Reporting' },
  { id: 'ifrs_statements', label: 'Financial Statements & IFRS', group: 'Reporting' },
  { id: 'disclosures', label: 'Notes to Accounts', group: 'Reporting' },
  { id: 'loans_desk', label: 'Loan Amortisation Schedules', group: 'Finance' },
  { id: 'project_costing', label: 'Project Costing & WIP', group: 'Finance' },
  { id: 'sector_regulation', label: 'Industry Measurement & Regulatory Desk', group: 'Sector accounting' },
  { id: 'compliance_review', label: 'Compliance Review & Gaps', group: 'Reporting' },
  { id: 'reports', label: 'Reports Centre', group: 'Reports' },
  { id: 'report_sales_r', label: 'Sales Reports', group: 'Reports' },
  { id: 'report_purchases_r', label: 'Purchases Reports', group: 'Reports' },
  { id: 'report_inventory_r', label: 'Inventory Reports', group: 'Reports' },
  { id: 'report_clients_r', label: 'Clients Reports', group: 'Reports' },
  { id: 'report_store_r', label: 'Store Reports', group: 'Reports' },
  { id: 'report_production_r', label: 'Production & WIP', group: 'Reports' },
  { id: 'report_hr_r', label: 'HR & Payroll Reports', group: 'Reports' },
  { id: 'report_ageing_r', label: 'Ageing Analysis (AR & AP)', group: 'Reports' },
  { id: 'report_financial_r', label: 'Financial Reports', group: 'Reports' },
  { id: 'crm_desk', label: 'Client Relationship Desk', group: 'Clients & CRM' },
  { id: 'performance', label: 'Budgeting, Forecast & Scenarios', group: 'Analytics' },
  { id: 'analytics', label: 'Data Analytics & CAATs', group: 'Analytics' },
];

/** Ids a per-user module tick can refer to. */
export const CLIENT_MODULE_IDS: ReadonlySet<string> = new Set(CLIENT_MODULE_CATALOG.map((m) => m.id));

/** Upper bound on the ticked list, so a crafted payload cannot bloat the user record. */
export const MAX_ALLOWED_MODULES = 200;

/** Maps each section / legacy route id to the contracted service line required. */
export const serviceForSection: Record<string, string> = {
  procurement: 'bookkeeping',
  sales: 'bookkeeping',
  business_partners: 'bookkeeping',
  business_partners_crm: 'bookkeeping',
  crm_desk: 'bookkeeping',
  expenses: 'bookkeeping',
  inventory: 'bookkeeping',
  inventory_ledger: 'bookkeeping',
  assets: 'bookkeeping',
  sector_workflow: 'bookkeeping',
  sector_regulation: 'management_accounts',
  boms: 'bookkeeping',
  production_desk: 'bookkeeping',
  report_sales: 'bookkeeping',
  report_sales_r: 'bookkeeping',
  report_purchases: 'bookkeeping',
  report_purchases_r: 'bookkeeping',
  report_inventory: 'bookkeeping',
  report_inventory_r: 'bookkeeping',
  report_clients: 'bookkeeping',
  report_clients_r: 'bookkeeping',
  report_clients_crm: 'bookkeeping',
  report_store: 'bookkeeping',
  report_store_r: 'bookkeeping',

  payment_desk: 'management_accounts',
  banking: 'management_accounts',
  ageing: 'management_accounts',
  report_ageing_r: 'management_accounts',
  report_production_r: 'management_accounts',
  prepayments: 'management_accounts',
  coa_master: 'management_accounts',
  general_ledger: 'management_accounts',
  control_accounts: 'management_accounts',
  universal_journal: 'management_accounts',
  manual_journal: 'management_accounts',
  adjustments: 'management_accounts',
  opening_balance: 'management_accounts',
  month_end: 'management_accounts',
  financial_reports: 'management_accounts',
  report_financial: 'management_accounts',
  report_financial_r: 'management_accounts',
  performance: 'management_accounts',
  analytics: 'management_accounts',

  payroll: 'payroll',
  hr_desk: 'payroll',
  hr_employees: 'payroll',
  hr_structure: 'payroll',
  hr_attendance: 'payroll',
  hr_requests: 'payroll',
  hr_tasks: 'payroll',
  report_hr: 'payroll',
  report_hr_r: 'payroll',

  tax_schedule: 'tax_compliance',
  tax_schedules: 'tax_compliance',

  ifrs_desk: 'ifrs_reporting',
  standards_desk: 'ifrs_reporting',
  ifrs_schedules: 'ifrs_reporting',
  loans_desk: 'management_accounts',
  project_costing: 'management_accounts',
  disclosures: 'ifrs_reporting',
  ifrs_statements: 'ifrs_reporting',
  compliance_review: 'ifrs_reporting',
  financial_issue_position: 'ifrs_reporting',
  financial_issue_profit: 'ifrs_reporting',
  financial_issue_equity: 'ifrs_reporting',
  financial_issue_cashflow: 'ifrs_reporting',
  financial_issue_notes: 'ifrs_reporting',
  financial_issue_compliance: 'ifrs_reporting',
};

/** Sections available when EITHER `bookkeeping` OR `management_accounts` is contracted. */
export const DUAL_BK_MGMT_SECTIONS = new Set([
  'payment_desk',
  'banking',
  'ageing',
  'report_ageing_r',
  'report_production_r',
]);

/** Returns whether a section is covered by a client's contracted services list. */
export function isSectionInServices(section: string, assignedServices?: string[] | null): boolean {
  if (OWNER_ONLY_MODULES.has(section)) return false;
  if (!assignedServices || assignedServices.length === 0) return true;
  if (DUAL_BK_MGMT_SECTIONS.has(section)) {
    return assignedServices.includes('management_accounts') || assignedServices.includes('bookkeeping');
  }
  const required = serviceForSection[section];
  if (!required) return true;
  return assignedServices.includes(required);
}

/** Computes the default ticked modules for a client user given contracted services. */
export function defaultModulesForServices(assignedServices: string[]): string[] {
  return CLIENT_MODULE_CATALOG
    .map((m) => m.id)
    .filter((id) => isSectionInServices(id, assignedServices));
}

/** Sanitises an untrusted `allowedModules` array against the client module catalogue. */
export function sanitizeAllowedModules(raw: unknown): string[] | undefined {
  if (!Array.isArray(raw)) return undefined;
  const ids = raw
    .filter((id): id is string => typeof id === 'string' && CLIENT_MODULE_IDS.has(id) && !OWNER_ONLY_MODULES.has(id))
    .slice(0, MAX_ALLOWED_MODULES);
  return Array.from(new Set(ids));
}
