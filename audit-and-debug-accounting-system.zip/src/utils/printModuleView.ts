/** Print a selected working paper, never the application shell. */
const esc = (v: unknown): string => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
export interface ModulePrintOptions {
  title: string; subtitle?: string; root?: HTMLElement | null; orientation?: 'portrait' | 'landscape';
}
function styleMarkup(): string {
  return Array.from(document.querySelectorAll('style, link[rel="stylesheet"]')).map((n) => n.tagName === 'STYLE' ? `<style>${n.textContent ?? ''}</style>` : n.outerHTML).join('\n');
}
export function cleanPrintClone(root: HTMLElement): HTMLElement {
  const clone = root.cloneNode(true) as HTMLElement;
  // Preserve the value the user selected before removing interactive controls.
  clone.querySelectorAll('input, select, textarea').forEach((node) => {
    const el = node as HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;
    const replacement = document.createElement('span');
    replacement.className = 'print-field-value';
    replacement.textContent = el instanceof HTMLSelectElement ? el.selectedOptions[0]?.textContent || '' : el instanceof HTMLInputElement && (el.type === 'checkbox' || el.type === 'radio') ? (el.checked ? 'Yes' : 'No') : el.value;
    node.replaceWith(replacement);
  });
  clone.querySelectorAll('button, nav, form:not([data-print-include]), [data-print-hide], .no-print, [role="alert"], [role="status"], .fixed, script, iframe, noscript').forEach((n) => n.remove());
  clone.querySelectorAll('[inert]').forEach((n) => n.removeAttribute('inert'));
  clone.querySelectorAll('details').forEach((n) => n.setAttribute('open', ''));
  clone.querySelectorAll<HTMLElement>('*').forEach((el) => {
    el.style.maxHeight = 'none'; el.style.overflow = 'visible'; el.style.position = '';
    el.style.transform = 'none'; el.style.height = '';
  });
  clone.style.maxWidth = 'none'; clone.style.width = '100%';
  return clone;
}
export function buildModuleHtml(options: ModulePrintOptions): string {
  const root = options.root ?? document.querySelector<HTMLElement>('#active-module-content') ?? document.querySelector<HTMLElement>('[data-module-root]');
  const body = root ? cleanPrintClone(root).innerHTML : '<p>The selected working paper is not available. Select a schedule and retry.</p>';
  const printedAt = new Date().toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' });
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"/><title>${esc(options.title)}</title>${styleMarkup()}<style>
  @page { size: A4 ${options.orientation === 'landscape' ? 'landscape' : 'portrait'}; margin: 14mm 12mm 16mm; }
  html,body { background:#fff!important; margin:0; padding:0; max-width:none!important; height:auto!important; overflow:visible!important; }
  body { font-family:Arial,sans-serif; color:#0a253e; }
  .print-letterhead { display:flex; justify-content:space-between; gap:16px; border-bottom:2px solid #082f4f; padding-bottom:8px; }
  .print-letterhead .mark { display:inline-block; background:#f5b719; color:#082f4f; padding:9px; border-radius:7px; font-weight:900; margin-right:8px; }
  .print-letterhead .firm { font-weight:800; font-size:11pt; color:#082f4f; }
  .print-letterhead .meta { text-align:right; font-size:8pt; color:#355875; }
  .print-title { font-size:15pt; margin:12px 0 3px; color:#082f4f; }
  .print-subtitle { font-size:9pt; margin:0 0 12px; color:#355875; }
  main { width:100%; } main * { box-shadow:none!important; }
  table { width:100%!important; min-width:0!important; border-collapse:collapse; font-size:8pt; page-break-inside:auto; }
  th,td { padding:5px!important; white-space:normal!important; overflow-wrap:anywhere; }
  tr { page-break-inside:avoid; } thead { display:table-header-group; }
  section { break-inside:auto; border-color:#cbd5e1!important; }
  .print-field-value { font-weight:600; }
  .print-foot { margin-top:14px; border-top:1px solid #cbd5e1; padding-top:6px; font-size:7.5pt; color:#355875; }
  </style></head><body><header class="print-letterhead"><div><span class="mark">BPZ</span><span class="firm">BPZ CONSULT</span></div><div class="meta">${esc(options.subtitle || '')}<br/>Printed ${esc(printedAt)}</div></header><h1 class="print-title">${esc(options.title)}</h1>${options.subtitle ? `<p class="print-subtitle">${esc(options.subtitle)}</p>` : ''}<main>${body}</main><footer class="print-foot">BPZ Consult · Selected working paper · ${esc(printedAt)}</footer></body></html>`;
}
export function printModuleView(options: ModulePrintOptions): void {
  const html = buildModuleHtml(options);
  // Some embedded browsers do not emit afterprint. Never accumulate old frames.
  document.querySelectorAll('iframe[data-bpz-print-frame]').forEach((old) => old.remove());
  const frame = document.createElement('iframe');
  frame.setAttribute('aria-hidden', 'true'); frame.setAttribute('data-bpz-print-frame', 'true'); frame.title = 'Print working paper';
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:1px;height:1px;border:0;opacity:0;pointer-events:none';
  let done = false;
  const cleanup = () => { if (done) return; done = true; frame.remove(); };
  frame.onload = () => {
    const doc = frame.contentDocument, win = frame.contentWindow;
    if (!doc || !win) return cleanup();
    doc.open(); doc.write(html); doc.close();
    const ready = async () => {
      try {
        await Promise.race([
          Promise.all([doc.fonts?.ready, ...Array.from(doc.querySelectorAll('link[rel="stylesheet"]')).map((link) => new Promise<void>((resolve) => { if ((link as HTMLLinkElement).sheet) return resolve(); link.addEventListener('load', () => resolve(), { once: true }); link.addEventListener('error', () => resolve(), { once: true }); }))]),
          new Promise((resolve) => setTimeout(resolve, 2500)),
        ]);
      } catch { /* system print styles remain available */ }
      if (done) return;
      win.addEventListener('afterprint', cleanup, { once: true });
      win.focus(); win.print();
      setTimeout(cleanup, 60000);
    };
    void ready();
  };
  document.body.appendChild(frame);
}
