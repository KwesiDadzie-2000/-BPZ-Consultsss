import type { ACDOCALine, AccountMaster, PurchaseOrder } from '@/types/accounting';
export interface CostBudgetLine { accountNo: string; label: string; amount: number }
export interface CostProject {
  id: string; code: string; name: string; customer: string; manager: string;
  costCenter: string; startDate: string; endDate: string; contractRevenue: number;
  directBudget: number; overheadBudget: number; status: 'Active' | 'Completed';
  budgetLines: CostBudgetLine[];
}
export interface ProjectCostSummary {
  project: CostProject; directCost: number; overhead: number; releasedCost: number;
  wip: number; revenue: number; commitments: number; recognisedCost: number;
  totalCost: number; budget: number; variance: number; margin: number;
}
const cents = (v: number) => Math.round(v * 100);
const sum = (rows: readonly ACDOCALine[], sign: 1 | -1 = 1) => rows.reduce((s, l) => s + sign * (cents(l.debit) - cents(l.credit)), 0) / 100;
export function summariseProject(project: CostProject, lines: readonly ACDOCALine[], accounts: readonly AccountMaster[], orders: readonly PurchaseOrder[], clientId: number, currency: string): ProjectCostSummary {
  const scoped = lines.filter((l) => l.clientId === clientId && l.currency === currency && (l.costCenter === project.costCenter || l.reference === project.code));
  const type = (l: ACDOCALine) => accounts.find((a) => a.accountNo === l.accountNo)?.type;
  // Allocation credits carry the project tag but their source expense may be
  // untagged. Do not turn that transfer into negative direct project cost.
  const expenses = scoped.filter((l) => type(l) === 'Expense' && l.accountNo !== '504000' &&
    (l.module !== 'PC' || scoped.some((source) => source.docNo === l.docNo && source.module !== 'PC' && source.debit > 0 && type(source) === 'Expense')));
  const isOverhead = (l: ACDOCALine) => /admin|overhead|rent|utilities|insurance/i.test(accounts.find((a) => a.accountNo === l.accountNo)?.category || l.accountName);
  const directCost = sum(expenses.filter((l) => !isOverhead(l)));
  const overhead = sum(expenses.filter(isOverhead));
  const releasedCost = sum(scoped.filter((l) => l.accountNo === '504000'));
  const wip = sum(scoped.filter((l) => l.accountNo === '122000'));
  const revenue = sum(scoped.filter((l) => type(l) === 'Income'), -1);
  // Only unposted open orders are commitments; received/invoiced orders are in GL.
  const commitments = orders.filter((p) => p.clientId === clientId && p.costCenter === project.costCenter && p.status === 'Open' && (p.currency || currency) === currency)
    .reduce((s, p) => s + cents(p.totalAmount), 0) / 100;
  const recognisedCost = Math.round((directCost + overhead + releasedCost) * 100) / 100;
  const totalCost = Math.round((recognisedCost + wip) * 100) / 100;
  const budget = project.directBudget + project.overheadBudget;
  return { project, directCost, overhead, releasedCost, wip, revenue, commitments, recognisedCost, totalCost, budget,
    variance: Math.round((budget - totalCost - commitments) * 100) / 100,
    margin: Math.round((revenue - recognisedCost) * 100) / 100 };
}
export function normaliseProjects(raw: unknown): CostProject[] {
  const rows = (raw as { projects?: unknown })?.projects;
  if (!Array.isArray(rows)) return [];
  return rows.filter((p): p is CostProject => !!p && typeof p === 'object' && typeof p.id === 'string' && typeof p.code === 'string' && typeof p.costCenter === 'string')
    .map((p) => ({ ...p, budgetLines: Array.isArray(p.budgetLines) ? p.budgetLines : [], directBudget: Number(p.directBudget) || 0, overheadBudget: Number(p.overheadBudget) || 0, contractRevenue: Number(p.contractRevenue) || 0 }));
}
