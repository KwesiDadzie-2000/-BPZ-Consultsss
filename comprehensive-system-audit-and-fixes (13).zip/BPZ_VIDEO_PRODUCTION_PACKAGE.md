# BPZ Consult ERP — Video Production Package

## Overview

This package contains everything you need to produce **two downloadable videos** using any screen recorder (OBS Studio, Loom, QuickTime, Camtasia, ScreenFlow, etc.). No special software is required beyond a screen recorder and a basic video editor.

### What You Get
1. **Marketing Video** — "BPZ Consults ERP: Built for Your Business" (≈ 90–120 seconds)
2. **Demo/Walkthrough Video** — "Accountant at Work: Live Case Scenario Transactions" (≈ 3–4 minutes)
3. **Complete scripts, voiceover text, and on-screen directions**
4. **Custom-generated assets**: logo, UI screenshots, and graphic elements
5. **Step-by-step recording instructions**

---

## PART 1: MARKETING VIDEO
### Title: "BPZ Consults ERP — Accounting That Works Like You Do"
**Duration:** 90–120 seconds  
**Target Audience:** Business owners, accountants, practice managers  
**Tone:** Professional, confident, warm, trustworthy  
**Voiceover Style:** Clear, mid-paced, authoritative but friendly (male or female, neutral accent)

---

### SCRIPT & STORYBOARD

| Time | Visual (What the Viewer Sees) | Audio / Voiceover | On-Screen Text |
|------|------------------------------|-------------------|----------------|
| 0:00–0:05 | **Black screen → BPZ Consults logo fades in** (clean, dark navy + gold) | [Soft, confident instrumental music begins — corporate, uplifting] | **BPZ CONSULTS**<br>ERP Accounting System |
| 0:05–0:12 | Screen recording: Login screen → Owner dashboard with client list | "Running an accounting practice means managing dozens of clients, dozens of books, and endless compliance deadlines. BPZ Consults ERP brings everything into one secure, professional workspace." | **One Workspace. All Your Clients.** |
| 0:12–0:18 | Screen recording: Quick toggle between two different client workspaces (Gold Coast Mines → Zurich Gold Refinery) | "Switch between client workspaces instantly. Each client has their own chart of accounts, tax settings, and reporting calendar — fully isolated, fully secure." | **Multi-Entity Management**<br>Client-isolated books |
| 0:18–0:24 | Screen recording: Banking & Reconcile → Import a bank CSV → System Analysis panel shows variance analysis | "Bank reconciliation that actually works. Import your bank statement, match it to the ledger automatically, and see variances clearly flagged — before they become problems." | **Bank Reconciliation**<br>Auto-match + System Analysis |
| 0:24–0:30 | Screen recording: Procurement → Purchase Order → Goods Receipt → Supplier Invoice → Payment Desk payment | "From purchase order to payment, every transaction posts to the ledger the moment it happens. No double entry. No missing journals." | **Procure-to-Pay**<br>Fully Automated |
| 0:30–0:36 | Screen recording: Sales → Invoice → Customer Receipt → Payment Desk allocation | "Sales, invoicing, and customer receipts flow into receivables automatically. Credit limits are enforced before an invoice is even posted." | **Order-to-Cash**<br>Credit-Controlled |
| 0:36–0:42 | Screen recording: Fixed Assets → Acquisition → Depreciation run → Disposal | "Fixed assets, depreciation, and capital allowances — calculated and posted automatically, reconciled to the general ledger." | **Fixed Assets**<br>IAS 16 Compliant |
| 0:42–0:48 | Screen recording: Tax Desk → VAT schedules → CIT provision → Compliance Review | "VAT, WHT, PAYE, SSNIT, and corporate income tax — calculated from your posted journals, not guessed. File with confidence." | **Statutory Compliance**<br>VAT • WHT • PAYE • CIT |
| 0:48–0:54 | Screen recording: Control Accounts desk → all green ticks; Month-End Close → close period | "Control accounts reconcile automatically. Month-end close is a controlled, auditable event — not a guessing game." | **Control Accounts**<br>Month-End Close |
| 0:54–1:00 | Screen recording: Business Partners → Register a customer → Set credit limit → Issue a credit memo | "Register customers and vendors with credit limits and payment terms. The system enforces credit limits before a single invoice is issued." | **Customer & Vendor Credit Control** |
| 01:00–1:08 | Screen recording: Audit trail / Compliance Review → filter by user, date, action | "Every posting is audited. Who did what, when, and why — fully traceable, fully immutable." | **Full Audit Trail**<br>Immutable Postings |
| 01:08–1:14 | Split screen: Left = messy spreadsheets/paper files; Right = clean BPZ dashboard | "Stop stitching together spreadsheets. Stop chasing paper. One system. One source of truth." | **Stop Juggling. Start Reconciling.** |
| 01:14–1:20 | Logo animation: BPZ Consults → Tagline appears | "BPZ Consults ERP. Built for accountants. Trusted by businesses." | **BPZ Consults**<br>Accounting, Simplified. |
| 01:20–1:30 | Final screen: Contact info, website, "Book Your Demo" button | "Visit bpzconsult.com to book your free demonstration." | **BPZ Consults ERP**<br>bpzconsult.com<br>Book Your Demo |

---

### VOICEOICE SCRIPT (Full Text)

> "Running an accounting practice means managing dozens of clients, dozens of books, and endless compliance deadlines. BPZ Consults ERP brings everything into one secure, professional workspace.
>
> Switch between client workspaces instantly. Each client has their own chart of accounts, tax settings, and reporting calendar — fully isolated, fully secure.
>
> Bank reconciliation that actually works. Import your bank statement, match it to the ledger automatically, and see variances clearly flagged — before they become problems.
>
> From purchase order to payment, every transaction posts to the ledger the moment it happens. No double entry. No missing journals.
>
> Sales, invoicing, and customer receipts flow into receivables automatically. Credit limits are enforced before an invoice is even posted.
>
> Fixed assets, depreciation, and capital allowances — calculated and posted automatically, reconciled to the general ledger.
>
> VAT, WHT, PAYE, SSNIT, and corporate income tax — calculated from your posted journals, not guessed. File with confidence.
>
> Control accounts reconcile automatically. Month-end close is a controlled, auditable event — not a guessing game.
>
> Register customers and vendors with credit limits and payment terms. The system enforces credit limits before a single invoice is issued.
>
> Every posting is audited. Who did what, when, and why — fully traceable, fully immutable.
>
> Stop stitching together spreadsheets. Stop chasing paper. One system. One source of truth.
>
> BPZ Consults ERP. Built for accountants. Trusted by businesses.
>
> Visit bpzconsult.com to book your free demonstration."

---

## PART 2: LIVE CASE SCENARIO VIDEO
### Title: "BPZ Consults ERP — Live Case: A Month in the Life of an Accountant"
### Duration: 3–4 minutes
### Scenario: Sarah, an accountant at BPZ Consults, completes a full month-end cycle for "Gold Coast Mines Ltd"

---

### SCENARIO OVERVIEW

**Client:** Gold Coast Mines Ltd (mining client)  
**Accountant:** Sarah (owner/checker role)  
**Period:** March 2026  
**Currency:** GHS  

### Day-by-Day Scenario

| Day | Activity | Desk Used | Journal Impact |
|-----|----------|-----------|----------------|
| Mar 2 | Receive goods from SteelMasters Ltd (drill rods) | Banking & Reconcile / Procurement | Dr Inventory 120000 / Cr GRNI 204000 |
| Mar 5 | Supplier invoice arrives (PO-2026-088) | Procurement → Supplier Invoice | Dr GRNI 204000 / Cr Trade Payables 200000 |
| Mar 8 | Pay supplier via bank | Payment Desk | Dr Trade Payables 200000 / Cr Bank 100000 |
| Mar 10 | Sell gold to Zurich Gold Refinery | Sales & Invoicing | Dr Trade Receivables 110000 / Cr Revenue 400000 + Output VAT 220000 |
| Mar 12 | Customer pays via bank transfer | Payment Desk | Dr Bank 100000 / Cr Trade Receivables 110000 |
| Mar 15 | Pay salaries | Payroll / Payment Desk | Dr Salaries 510000 / Cr Net Salaries Payable 205000 → Dr Net Salaries 205000 / Cr Bank |
| Mar 20 | Fixed asset acquired (drill rig) | Fixed Assets | Dr PPE 132000 / Cr Bank 100000 |
| Mar 25 | Monthly depreciation run | Fixed Assets | Dr Depreciation 600000 / Cr Accumulated Depreciation 139000 |
| Mar 28 | Bank statement import & reconciliation | Banking & Reconcile | Match statement lines to posted journals |
| Mar 31 | Month-end close | Month-End Section | Close period 2026-03 |

---

### SCRIPT & STORYBOARD

| Time | Visual | Audio / Voiceover | On-Screen Text |
|------|--------|-------------------|----------------|
| 0:00–0:10 | Title card: "BPZ Consults ERP — Live Case: Month-End in 3 Minutes" | [Upbeat professional music] | **LIVE CASE: MONTH-END IN 3 MINUTES**<br>Gold Coast Mines Ltd · March 2026 |
| 0:10–0:20 | Login screen → Sign in as Sarah (owner) → Dashboard shows Gold Coast Mines Ltd | "Meet Sarah. She's the firm owner at BPZ Consults. Today she's closing the books for Gold Coast Mines Ltd for March 2026." | **Sarah · Firm Owner**<br>Client: Gold Coast Mines Ltd |
| 0:20–0:30 | Banking & Reconcile desk → Import statement CSV → System Analysis shows matched lines | "First, Sarah imports the March bank statement. The system auto-matches each line to posted journals — cash in, cash out, all accounted for." | **Step 1: Bank Reconciliation**<br>Import → Match → Reconcile |
| 0:30–0:40 | Procurement desk → Create PO for SteelMasters → Goods Received → Supplier Invoice | "She receives drill rods from SteelMasters. The receipt posts to inventory and GRNI — not to payables, because the bill hasn't arrived yet." | **Step 2: Procurement**<br>PO → Goods Receipt → GRNI |
| 0:40–0:50 | Procurement → Supplier Invoice for PO-2026-088 → Post journal | "When the supplier invoice arrives, GRNI clears and Trade Payables is created. Everything links back to the original purchase order." | **Step 3: Supplier Invoice**<br>GRNI → Trade Payables |
| 0:50–1:00 | Sales & Invoicing → Create sales invoice for Zurich Gold Refinery → Post | "On the sales side, she issues an invoice to Zurich Gold Refinery. Revenue, output VAT, and trade receivables post instantly." | **Step 4: Sales Invoice**<br>Dr Receivables / Cr Revenue + VAT |
| 1:00–1:10 | Payment Desk → Customer receipt from Zurich Gold → Allocate to invoice | "The customer pays. Sarah records the receipt, allocates it to the invoice, and the receivable clears automatically." | **Step 5: Customer Receipt**<br>Dr Bank / Cr Receivables |
| 1:10–1:20 | Payment Desk → Salary payment → Bank | "She runs payroll. Net salaries post to the payables control, and when disbursed, cash moves through the treasury account." | **Step 6: Payroll**<br>Dr Salaries / Cr Net Salaries Payable → Cr Bank |
| 1:20–1:30 | Fixed Assets → Acquire drill rig → Run depreciation | "She registers a new drill rig. Depreciation runs automatically — cost to PPE, credit to bank, and depreciation charges hit the P&L." | **Step 7: Fixed Assets**<br>Acquire → Depreciate |
| 1:30–1:40 | Banking & Reconcile → Final statement match → All green checks | "She reconciles the final bank statement. Every line matches. No unexplained differences." | **Step 8: Final Reconciliation**<br>100% Matched |
| 1:40–1:50 | Month-End Close → Review control accounts (all green) → Close period 2026-03 | "Control accounts reconcile. She closes the period. The books are frozen, auditable, and ready for statutory reporting." | **Step 9: Month-End Close**<br>Period Frozen |
| 1:50–2:00 | Tax Desk → CIT provision → Statutory schedules | "CIT is calculated from posted profit. VAT, WHT, PAYE — all ready for filing." | **Step 10: Tax & Compliance** |
| 2:00–2:10 | Final dashboard → All green indicators | "One workspace. One set of books. Audit-ready, period closed." | **Books Closed. Ready for Filing.** |
| 2:10–2:15 | Logo + contact | "BPZ Consults ERP. Accounting done right." | **BPZ Consults**<br>bpzconsult.com |

---

### PART 3: RECORDING INSTRUCTIONS

#### Equipment Needed
- Computer with the BPZ Consults ERP running (this project)
- Screen recording software (OBS Studio — free; Loom; QuickTime Player on Mac; Camtasia)
- Microphone (built-in is fine, USB microphone recommended)
- Quiet room

#### Step-by-Step Recording Process

**Step 1: Prepare the Environment**
1. Open the production preview: `https://3000-i300y2aa1ak5nciwcydiq.e2b.app`
2. Sign in as: **Username:** `owner` | **Password:** (set during first-run activation)
3. Switch to client: **Gold Coast Mines Ltd**
4. Close all unrelated browser tabs and notifications
5. Set screen resolution to 1920×1080
6. Hide desktop icons and taskbar icons for a clean look

**Step 2: Record Each Scene Separately**
Record each desk/module separately (don't do one continuous take):
- Scene 1: Login & Dashboard
- Scene 2: Banking & Reconcile
- Scene 3: Procurement → Goods Received → Supplier Invoice
- Scene 4: Sales & Invoicing
- Step 5: Payment Desk
- Scene 6: Payroll
- Scene 7: Fixed Assets
- Scene 8: Month-End Close
- Scene 9: Tax Desk

**Step 3: Record Voiceover Separately**
- Read the voiceover script while watching your recorded footage
- Record in a quiet room
- Speak clearly, at a moderate pace
- Pause between sections for easy editing

**Step 4: Edit**
- Import video and audio into your editor (iMovie, DaVinci Resolve, Adobe Premiere, CapCut, etc.)
- Sync voiceover to video
- Add background music (low volume, behind voice)
- Add text overlays as shown in the storyboard
- Export as MP4 (1080p, 30fps)

---

## PART 4: GENERATED ASSETS

Below are generated assets you can use in your videos:

### Logo Concept
A professional accounting logo has been generated for use in video intros/outros.

### Screen Mockups
Key screens have been prepared for use in your video if live recording isn't possible:

*(Images will be generated below)*

---

## PART 5: GENERATED IMAGES

Below are custom-generated visual assets for your video production:

<slot name="generated_assets" />

---

### How to Use These Assets

1. **Logo:** Place at the start and end of both videos
2. **Banking screenshot:** Use in marketing video during "Bank Reconciliation" segment
3. **Statement analysis screenshot:** Use in marketing video during system analysis segment
4. **Fixed assets screenshot:** Use in both videos for fixed assets section
5. **Control accounts screenshot:** Use in marketing video during month-end close section

---

### Final Export Settings

| Setting | Recommended Value |
|---------|-------------------|
| Resolution | 1920 × 1080 (1080p) |
| Frame Rate | 30 fps |
| Codec | H.264 |
| Format | MP4 |
| Audio | AAC, 48 kHz, stereo |
| Bitrate | 5–10 Mbps |

---

**Ready to record?** Open the preview at `https://3000-i300y2aa1ak5nciwcydiq.e2b.app`, sign in as `owner`, and start recording following the scripts above.