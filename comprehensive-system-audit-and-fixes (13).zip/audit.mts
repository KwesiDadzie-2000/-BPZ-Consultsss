process.env.DATABASE_URL = 'postgresql://postgres:postgres@127.0.0.1:5432/app_db';
const { db } = await import('/app/src/db');
const { journalLines, chartAccounts, clients } = await import('/app/src/db/schema');
const { buildIasStatements } = await import('/app/src/utils/statements');
const { buildIfrsPack } = await import('/app/src/utils/ifrsPack');
const { reconcileControlAccounts, controlAccountSummary } = await import('/app/src/utils/controlAccounts');
const { resolveTreasuryBalances } = await import('/app/src/lib/treasuryAuthority');
const [lines, accts, cs] = await Promise.all([db.select().from(journalLines), db.select().from(chartAccounts), db.select().from(clients)]);

for (const c of cs) {
  const L = lines.filter(l => l.clientId === c.id);
  if (!L.length) continue;
  const A = accts.filter(a => a.clientId == null || a.clientId === c.id);
  console.log(`\n=== ${c.code} (${L.length} lines) ===`);

  // 1. Trial balance must balance
  const dr = L.reduce((n,l)=>n+Math.round(l.debit*100),0)/100;
  const cr = L.reduce((n,l)=>n+Math.round(l.credit*100),0)/100;
  console.log(`trial balance: Dr ${dr.toFixed(2)} vs Cr ${cr.toFixed(2)} -> ${Math.abs(dr-cr)<0.005?'BALANCED':'**OUT OF BALANCE**'}`);

  // 2. IFRS 18 statement set
  try {
    const st = buildIasStatements(L, A, '2026-01-01', '2026-12-31', c.currency, c.name);
    const gap = Math.round((st.totals.totalAssets - st.totals.totalEquityAndLiabilities)*100)/100;
    console.log(`IFRS18 SFP: assets ${st.totals.totalAssets} vs E+L ${st.totals.totalEquityAndLiabilities} -> gap ${gap} ${st.totals.balanced?'BALANCED':'**OUT OF BALANCE**'}`);
    console.log(`  op profit ${st.totals.operatingProfit} | PBFIT ${st.totals.profitBeforeFinancingAndTax} | profit ${st.totals.profitForPeriod}`);
    // verify required subtotals foot
    const pl = st.profitOrLoss.flatMap(s=>s.rows);
    const opRow = pl.find(r=>r.label==='Operating profit');
    const pbfRow = pl.find(r=>r.label==='Profit before financing and income taxes');
    if (!opRow) console.log('  ** MISSING Operating profit subtotal');
    if (!pbfRow) console.log('  ** MISSING Profit before financing and income taxes subtotal');
    // cash flow: must start from operating profit
    const cf = st.cashFlows.flatMap(s=>s.rows);
    const opStart = cf.find(r=>r.label==='Operating profit');
    if (opStart && opStart.current !== st.totals.operatingProfit) console.log(`  ** CF starts from ${opStart.current} not operating profit ${st.totals.operatingProfit}`);
    if (opStart) console.log(`  CF starts from operating profit ✓ (${opStart.current})`);
    else console.log('  ** CF does NOT start from operating profit');
  } catch(e) { console.log('IFRS18 ERROR:', (e as Error).message); }

  // 3. IFRS pack (statutory desk)
  try {
    const pack = buildIfrsPack({ lines: L, accounts: A, from: '2026-01-01', through: '2026-12-31', currency: c.currency, entityName: c.name, entityCode: c.code, jurisdiction: c.jurisdiction });
    const failing = pack.checks.filter(k=>k.severity==='critical');
    console.log(`IFRS pack: ${pack.checks.length} checks, ${failing.length} critical, balanced=${pack.totals.balanced}`);
    // profit statement five categories present?
    const prof = pack.statements.find(s=>s.id==='profit');
    const titles = prof?.blocks.map(b=>b.title).join(' | ');
    console.log(`  profit blocks: ${titles}`);
  } catch(e) { console.log('PACK ERROR:', (e as Error).message); }

  // 4. Control accounts
  try {
    const banks = await resolveTreasuryBalances(db, [], cs as any);
    const rows = reconcileControlAccounts({
      clientId: c.id, lines: L as any, invoices: [], orders: [], stockItems: [], bankAccounts: banks.filter((b:any)=>b.clientId===c.id) as any,
      assets: [], prepayments: [], prepaymentSchedules: [], payrollRecords: [], partners: [], taxEntries: [],
    });
    const s = controlAccountSummary(rows);
    if (s.outOfBalance>0) { console.log(`control accounts: ${s.outOfBalance} OUT`); for(const e of s.exceptions) console.log('  OUT', JSON.stringify(e).slice(0,160)); }
    else console.log(`control accounts: all reconciled ✓`);
  } catch(e) { console.log('CONTROL ERROR:', (e as Error).message); }
}
process.exit(0);
