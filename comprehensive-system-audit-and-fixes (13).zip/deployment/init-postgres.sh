#!/usr/bin/env bash
set -euo pipefail

# Used only by the official Postgres entrypoint on an empty data volume.
for secret in "$POSTGRES_PASSWORD" "$BPZ_DB_PASSWORD" "$BPZ_RECOVERY_PASSWORD"; do
  if [[ ! "$secret" =~ ^[a-fA-F0-9]{40,128}$ ]]; then
    echo 'Use distinct, randomly generated hexadecimal PostgreSQL passwords (at least 40 characters).' >&2
    exit 1
  fi
done
if [[ "$POSTGRES_PASSWORD" == "$BPZ_DB_PASSWORD" || "$POSTGRES_PASSWORD" == "$BPZ_RECOVERY_PASSWORD" || "$BPZ_DB_PASSWORD" == "$BPZ_RECOVERY_PASSWORD" ]]; then
  echo 'PostgreSQL credentials must be different for admin, app and recovery.' >&2
  exit 1
fi
psql --username "$POSTGRES_USER" --dbname postgres -v ON_ERROR_STOP=1 \
  -v application_pw="$BPZ_DB_PASSWORD" -v recovery_pw="$BPZ_RECOVERY_PASSWORD" <<'SQL'
CREATE ROLE bpz_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT PASSWORD :'application_pw';
CREATE ROLE bpz_recovery LOGIN NOSUPERUSER CREATEDB NOCREATEROLE NOINHERIT PASSWORD :'recovery_pw';
CREATE DATABASE bpz_prod OWNER bpz_app;
REVOKE CONNECT ON DATABASE bpz_prod FROM PUBLIC;
GRANT CONNECT ON DATABASE bpz_prod TO bpz_app;
SQL
