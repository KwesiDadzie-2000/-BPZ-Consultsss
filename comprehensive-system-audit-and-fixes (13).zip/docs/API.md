# Public Developer API

Versioned, key-authenticated access to the ledger, invoices and statements.
Generate a key as the owner under **Enterprise Administration → API & Webhooks**
(or `POST /api/apikeys`). Keys are shown once.

**Auth:** `Authorization: Bearer bpz_live_…` · **Rate limit:** 60 requests/minute/key

## Endpoints

| Method & path | Scope | Description |
|---|---|---|
| `GET /api/v1/ledger?from=&to=` | read | Posted journal lines (up to 1000) |
| `GET /api/v1/invoices` | read | Sales invoices for the entity |
| `POST /api/v1/invoices` | write | Create + post a sales invoice (journal + register, atomic) |
| `GET /api/v1/statements?partyId=&side=&from=&to=` | read | Customer/vendor statement of account |

## Example

```bash
curl -H "Authorization: Bearer $BPZ_KEY" \
  "https://your-domain/api/v1/ledger?from=2026-01-01&to=2026-12-31"

curl -X POST -H "Authorization: Bearer $BPZ_KEY" -H "content-type: application/json" \
  -d '{"clientId":2,"customerName":"Accra Retail Ltd","description":"Consulting","netRevenue":1000,"vatOutput":200}' \
  "https://your-domain/api/v1/invoices"
```

## Posting controls on API writes

Machine writes pass through the **same gate** as a signed-in user:

- **Closed periods** — a document dated inside a locked month is refused, exactly
  as it would be from a desk. Migration cannot back-door a locked period either.
- **Posting limit** — a key is created with `makerLimit` (default **0**). A key at
  0 cannot post at all. A document above the key's limit is refused, because a
  machine credential cannot obtain independent checker approval.
- **Attribution** — API documents are attributed to `api:<key name>`, never to a
  human user.

Create a write key with an explicit limit:

```bash
curl -X POST -H "Authorization: Bearer $SESSION" -H "content-type: application/json" \
  -d '{"name":"erp-bridge","scope":"write","makerLimit":50000}' \
  "https://your-domain/api/apikeys"
```

Grant the smallest limit the integration actually needs, and revoke the key when
the integration is retired.

## Errors

`401` missing/invalid key · `403` read-only key used to write · `404` not found ·
`409` validation conflict · `422` unusable input · `429` rate limited.
All responses are JSON with `{ ok, ... }` and `cache-control: no-store`.
