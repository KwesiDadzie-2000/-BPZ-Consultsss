# BPZ Consult ERP: controlled production cutover

Use this procedure with the audited working copy. A successful sandbox build, a synthetic close packet, and an uploaded backup are not a production cutover. Do not enter real client books into the sandbox. The ERP cannot create a public route to a private E2B sandbox; use the platform’s authenticated Preview for evaluation.

## 1. Put the working copy on your HTTPS host

**Prefer the production Compose package:** `compose.production.yml`, `Dockerfile`, `deployment/Caddyfile`, and `deployment/init-postgres.sh`. A native Ubuntu/Caddy route remains in [Deployment Guide](DEPLOYMENT_GUIDE.md). Use a fresh production-provisioned PostgreSQL database or restore a known production snapshot first. Do not promote a demonstration DB. Existing unclassified books require an isolated migration, backup and validation, not manual invention of production provenance.

1. On the firm’s host install Docker Engine with Compose v2. Point a real DNS hostname at that host and allow inbound TCP 80 and 443; UDP 443 is optional for HTTP/3. Do not expose the database or the direct app port. Use the revised workspace source, not the original GitHub archive.
2. Copy `.env.production.example` to `.env.production`, set mode `600`, and replace its placeholders. Generate independent random hex strings (`openssl rand -hex 32`) for each database password, `BPZ_SETUP_TOKEN`, and `BPZ_DEPLOYMENT_ID`. Keep the deployment ID unchanged for this installation. Store activation and database secrets in the operator’s password manager, not in chat or Git.
3. Provision an off-host **private** S3/S3-compatible bucket and configure a scoped credential that can write and read the ERP backup prefix. Block public access, enable versioning/appropriate retention, and keep a separately protected recovery copy. Use only HTTPS endpoints; the standard AWS endpoint can be left implicit. Keep separate storage configuration for staging and production. The uploaded bytes contain sensitive books; restrict logs, access and transfer of backup files accordingly.
4. Validate configuration, then start the package:

   ```sh
   docker compose --env-file .env.production -f compose.production.yml config --quiet
   docker compose --env-file .env.production -f compose.production.yml up -d --build --wait
   ```

   The package persists the database, local backups and TLS state in named volumes. Only Caddy publishes ports and it provisions certificates for the configured DNS name. The app database role cannot create databases. A separate `bpz_recovery` login can create disposable databases but cannot connect to `bpz_prod`. Use `docker compose ... logs app caddy` for readiness or TLS errors. Do not use `down -v` on live volumes.
5. Open the real HTTPS hostname. The first-run form requires your setup token and a **new** owner password; enroll the owner's authenticator. The owner username is `owner`, and there is no production default password. Confirm successful sign-in from a normal browser. Keep production owner and checker MFA enabled. Distribute client invitations only for the live hostname.

Verify that the public TLS endpoint is the actual installation (run on the owned host):

```sh
docker compose --env-file .env.production -f compose.production.yml run --rm operator scripts/verify-production.mts
```

For the native route run `npx tsx scripts/verify-production.mts` under the application account. The verifier checks the public TLS endpoint, the installation identifier from `/api/health`, and the ERP sign-in page. Exit `1` is a verification failure; exit `2` means HTTPS was verified but other release gates are still outstanding. The proof expires after seven days or when domain/installation changes. There is no API for entering a manual “verified” result.

## 2. Complete one full month against the existing system

Start in **Accounting & Finance → Parallel Close & Go-Live**, or use the shortcut from **Month-End Close**. Use the selected client entity and real source evidence. Parallel operation is an accounting task: post the **same authorized transactions** in both systems throughout one completed month; reconcile opening balances and normalize account mapping and close policy. Do not copy the BPZ export back into its own legacy comparison. The reviewer must validate the original source independently.

1. **Overview:** choose the completed pilot month, enter the legacy close reference and describe scope/cut-off. Save the draft.
2. **Trial balance:** export the *legacy* system’s net closing balances under the mapped six-digit BPZ GLs. Import a UTF-8 CSV, TSV or semicolon-separated `.csv` of `Account,Debit,Credit` with optional `Currency`. Use a decimal point, no thousands separator, one unique account and one net side per row (the other must be 0). Keep a signed/datable source workpaper, not only the exported numbers. The server compares functional-currency closing balances against its posted journal through the month-end, using cents. Both totals and each account must agree; a balanced but misclassified trial fails. A full month is required with actual in-month entries; unresolved legacy foreign-currency and malformed journal lines block sign-off. Correct errors through normal controlled accounting or a separately approved historical conversion workflow rather than rewriting posted lines.
3. **Control accounts:** compare appropriately scoped totals from source schedules (not from off-the-cuff netting). The BPZ amount must match the server’s posted control:

   | Check | Posted basis used in the packet |
   | --- | --- |
   | Bank | Functional-currency net debit across `10xxxx`. Include signed individual bank, cash and wallet reconciliations, cleared items and translated FX sheets. Review each account, not just the sum. |
   | Receivables | Net debit `110000`, `111000`, `112000`. Support with customer ageing, credits, notes and advance schedules. |
   | Payables | Net credit `200000`, with supplier ageing, credits and separately reviewed accruals and advances. |
   | Inventory and WIP | Net debit `120000–124000` by the five standard controls; use signed counts, moving average/FIFO evidence, WIP and production reconciliations. |
   | Payroll | Net salaries recorded in `205000` by the month’s `PAYROLL-*` journals net of linked payroll reversals. It excludes disbursement movements. Attach a minimized summary of gross/net pay, deductions, contributions and remittances. |
   | Tax | Net closing credit of `206000`, `206100`, `207000`, `209000`, `212000`, `220000`, `221000`, `223000`, `224000`, `227000`, `228000` less input VAT `125000`. Check each tax/levy separately, including confirmed tax credits and current settings; the net is a tie-out, not a filing. |

   Each mandatory control requires a schedule, reference and notes, even if its supported amount is zero. Upload PDFs, UTF-8 CSV/text or PNG/JPEG (2 MB per file). Use aggregate/minimized schedules and avoid identifiers unnecessary for reconciliation. Record documented opening take-on, current tax/payroll and sector policy checks. Attach approved group translation, eliminations, NCI and goodwill working papers if applicable; the same-currency group trial balance is not a consolidated financial statement. Verify enabled integrations on the real site, or explain why none apply. Group and integration evidence can be marked not applicable only with a reason/reference.
4. **Review & go-live:** save all work, confirm no blockers and submit. On a fresh installation an owner can **Add close reviewer**, scoped to the selected entity with no posting or preparation rights. Share the temporary credential securely with a different person and have that person enroll MFA and review the evidence. The reviewer either returns the packet or records their independent approval. A preparer, contributor or submitter cannot approve, including the owner if they prepared it. A changed closing journal invalidates the seal; reopen/withdraw, reconcile and resubmit rather than reusing the approval. Actions and evidence hashes are recorded in the audit trail.

## 3. Prove off-site recovery and record the owner decision

After independent approval, run the off-site recovery drill (it creates a new snapshot):

```sh
docker compose --env-file .env.production -f compose.production.yml run --rm operator scripts/verify-recovery.mts --offsite
```

Native route: configure `BPZ_RECOVERY_DATABASE_URL` to a separate credential ending in `/bpz_recovery_test`, then run `npx tsx scripts/verify-recovery.mts --offsite` on the host. The command creates a uniquely named scratch DB, retrieves the uploaded object, verifies its hash, restores it into the scratch database, compares each table’s row contents and counts, then removes that scratch DB. It does **not** restore into the source database. Its CLI credential must be able to create/drop its own scratch DB only. If the provider cannot create isolated databases, configure a separate controlled PostgreSQL recovery instance. A local-file parse, an upload, or a local-only drill does not satisfy the off-site gate. Fresh off-site upload is required within 30 hours and after the reviewed packet; the recovery proof stays valid for 30 days for the same installation and storage. Run fresh drills after infrastructure changes and at least monthly if continuing to use these release gates.

Refresh **Operations & Backup** and the **Review & go-live** tab. All release indicators must be verified, the independent sign-off must still match, and the owner must type the exact workspace code and record a cutover decision. **Designate live books** is one atomic server action. It records the first live month and closes it; journal, trade, production and state sync reject new postings through that month even if another period lock is removed. The header identifies the live workspace. Later-period corrections still go through the normal approval/posting workflow.

Export the signed close packet and evidence index. After designation take another off-site snapshot to retain the final live marker. If the cutover must be rolled back, use the separately approved disaster recovery/continuity procedure; do not bypass the lock by changing the database by hand. A fresh deployment proves its own gates with its own domain and data. These are engineering and operational release controls, not a statutory audit opinion.
