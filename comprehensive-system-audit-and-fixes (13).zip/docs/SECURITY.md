# BPZ Consults ERP — Security & Controls

This document maps the system's implemented controls to the criteria a security
reviewer, SOC 2 auditor or ISO 27001 assessor asks for. It is evidence of
*implemented* controls, not a certification. Independent certification (SOC 2
Type II / ISO 27001) requires a third-party audit of the operating organisation,
not only the code.

## Authentication & access

| Control | Implementation | Reference |
|---|---|---|
| Password hashing | scrypt (N=16384, r=8, p=1), per-user salt, transparent re-hash | `src/lib/password.ts` |
| Sessions | HttpOnly, SameSite, server-stored, sliding expiry, revocation | `src/lib/auth.ts` |
| MFA | TOTP (RFC 6238), enforced for owner/checker roles | `src/app/api/auth/mfa` |
| Login lockout | Shared, DB-backed attempt budget after 5 failures | `src/lib/rateLimit.ts` |
| Maker–checker | Independent approval; a maker cannot approve their own document | `src/lib/journalValidation.ts` |
| Tenant isolation | Every query scoped by `client_id`; cross-tenant writes rejected | `src/app/api/state/route.ts` |
| Machine access | Public API keys are hashed, scoped, revocable, rate-limited | `src/lib/apiKeys.ts` |

## Accounting integrity

| Control | Implementation |
|---|---|
| Immutability | Posted journals are append-only; corrections are reversing entries |
| Idempotency | Content-hash + posting-event key; replay posts exactly once |
| Double-entry | Per-document balance validation, minor-unit (cents) arithmetic |
| Period locks | Closed periods reject postings; reopening is audited |
| Control accounts | AR/AP/inventory/treasury/GRNI reconcile to sub-ledgers |
| GRNI discipline | Receipts accrue to 204000; only matched invoices open 200000 |

## Data protection

- Tenant data is isolated at the row level; the API never returns another tenant's rows.
- API payloads are size-limited; JSON body parsing is strict.
- Rate limiting is PostgreSQL-backed and shared across instances.
- Backups are owner-gated, verifiable, and support off-site (S3-compatible) copies.
- Secrets are read from environment variables only; none are committed.

## Responsible disclosure

Report vulnerabilities privately to the system owner. Do not test against a
production workspace; use a disposable database and the suites in `src/tests/`.
