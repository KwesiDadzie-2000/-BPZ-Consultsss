# BPZ Consults ERP — Setup & Migration Guide

This guide walks a firm through (a) migrating a client from another accounting
system into BPZ, (b) the initial workspace setup, and (c) what each technical
desk or module does. Follow it top to bottom for a clean go-live.

---

## Part 1 — Migrating a client from another system

Migration is a controlled import of **opening balances, ledger history,
customers/vendors and bank accounts**. Nothing is written until the entire file
validates, and every write happens in a single database transaction — a
half-finished migration can never land in the books.

The whole migration is run from **Data Migration** (owner only) in the sidebar.

### 1.1 Before you start

| Step | Why |
|---|---|
| Create the client workspace (**Clients & CRM → Client Workspaces**) | Migration writes into a specific entity. |
| Agree the **cut-over date** with the client | Everything before it becomes opening balances; everything after is posted live. |
| Export from the legacy system as **CSV** | The importer reads CSV/TSV/plain text. PDF and Excel are not parsed directly — save those as CSV first. |
| Get the **signed trial balance** at the cut-over date | This is your reconciliation anchor. |
| Download the **CSV template** from Data Migration | Guarantees the exact column names the importer expects. |

### 1.2 The four imports, in order

Run them in this order. Later imports depend on earlier ones.

**A. Opening balances** — the signed trial balance at cut-over.
- Template columns: `Account, Debit, Credit`
- Rules: one six-digit GL account per row; put the balance on **one** side and `0`
  on the other; total debits **must** equal total credits. The importer refuses an
  out-of-balance file outright.
- Posts one balanced journal (`OPENING-<date>`) at the cut-over date.

**B. Bank accounts** — treasury records mapped to `10xxxx` GLs.
- Template columns: `Code, Name, Bank, AccountNo, GL, OpeningBalance`
- The GL must be a treasury account (`10xxxx`). This registers the accounts the
  Payment Desk and Banking desk will use. Balances are **derived from the ledger**,
  so ensure the opening journal (A) already carries the matching cash figures.

**C. Customers & vendors** — the party master with credit terms.
- Template columns: `Code, Name, Type, CreditLimit, CreditTermsDays, TIN, Email, Phone`
- `Type` is `Customer` or `Vendor`. Credit limit `0` means cash-on-delivery;
  a positive limit grants credit up to that amount.

**D. Ledger history** — the historical journal documents.
- Template columns: `Document, Date, Account, Debit, Credit, Description`
- Rules: each document number must balance (Dr = Cr); every row needs a real date
  and a six-digit account. Import as much history as the client needs for
  comparative reporting — typically the current financial year plus the prior.

### 1.3 Preview, then commit

Every import has two buttons:

1. **Preview / validate** — parses and checks the whole file, shows row counts,
   totals, a sample and every error with its row number. **Nothing is written.**
2. **Commit migration** — only enabled after a clean preview. Posts the journals,
   writes the registers, bumps the workspace revision, and records an audit entry.

If preview reports errors, fix the CSV and re-preview. The importer names the
exact row and reason (e.g. `Row 47: Account "12345" must be six digits.`).

### 1.4 Reconcile after migration (mandatory)

Before trusting the migrated books:

1. **Trial balance** (Financial Reports) — debits equal credits.
2. **Control Accounts Reconciliation** — AR, AP, inventory, treasury and GRNI
   each agree to their sub-ledger. Any difference is a real reconciling item to
   investigate.
3. **Balance sheet & P&L** — compare to the legacy system's closing statements.
4. **Bank balances** — agree to bank statements.

Only when these tie out should the client's cut-over be treated as live.

### 1.5 Rollback safety

Because migration posts immutable journals, **corrections are made with reversing
entries**, not edits. If a migration is wrong, reverse the document
(`OPENING-<date>` or the document numbers) and re-import.

---

## Part 2 — Initial workspace setup

1. **Firm owner activation** — first run asks for the setup token and a password
   (see `docs/DEPLOYMENT_GUIDE.md` step 9).
2. **Client workspace** — create one per legal entity. Each has its own
   currency, sector, services and its own set of books.
3. **Company Profile** — legal name, TIN, VAT number, fiscal year start, bank
   details. These appear on invoices, statements and financial statements.
4. **Chart of Accounts** — the firm master ships with ~205 accounts. An entity may
   tailor names or add custom accounts for its own reporting.
5. **Opening balances** — via **Data Migration** (above) or **Opening Balances
   Setup** for a single manual take-on.
6. **Users & permissions** — create client admins and staff; assign maker limits
   and which desks they may open.
7. **Read the in-app Setup Guide** (Overview → Setup Guide & Modules) — setup steps,
   every module, and the cut-over checklist.

---

## Part 3 — Technical desks and modules

The **in-app Setup Guide** (Overview → Setup Guide & Modules) renders every
module with its accounting treatment and key GL accounts — the documentation
is kept in sync from `src/data/guide.ts`. This section summarizes the system:

### Financial reporting

| Desk / module | What it does | Key points |
|---|---|---|
| **General Ledger** | Full account activity with running balances | Every posted line, drill-down by document. |
| **Financial Statements & IFRS** | Primary statements + notes | Statement of financial position, P&L and OCI, changes in equity, cash flows (IAS 7), plus IFRS notes. Assets split **non-current / current**; liabilities split **non-current / current** (IAS 1.69). |
| **Control Accounts Reconciliation** | GL vs sub-ledger, per control | AR 110000, AP 200000, GRNI 204000, inventory, treasury, statutory. Non-zero differences are named reconciling items. |
| **Group Consolidation** | Full IFRS 10 workbench | Control establishment (hold % > 50%), translation at closing rate (IAS 21), intercompany elimination of name-matched AR/AP (110000 vs 200000), goodwill (IFRS 3, investment − hold% × NAV), NCI (IFRS 10, NCI% × (NAV + goodwill)), consolidated trial balance. Read-only — nothing is posted. |
| **Month-End Close / Parallel Close & Go-Live** | Lock a period; parallel-run before cutover | Parallel Close reconciles one full month against the legacy books with evidence and independent sign-off before designation. |
| **Statements of Account** | Customer/vendor account statements | Journal-backed, opening + closing balance, printable. |

### Trading & operations

| Desk / module | What it does | Key accounting treatment |
|---|---|---|
| **Procurement & P2P** | Requisition → PO → receipt → invoice → payment | Goods receipt accrues to **204000 GRNI** (not payable). Only the matched invoice opens **200000 trade payables**. |
| **Sales & Invoicing (O2C)** | Order → delivery → invoice → receipt | Invoice posts receivable, revenue, output tax; goods invoices also release cost of sales and the stock issue in the same document. |
| **Inventory Command Desk** | Stock master, receipts, issues, valuation | Receipts are recognised at cost (IAS 2). "Sell stock / recognise revenue" hands off to Sales so revenue and its cost post together. |
| **Payment Desk** | Settle invoices, record receipts, withholding tax | Only **invoiced** balances are payable; WHT is recognised as statutory payable. |
| **Fixed Assets Register** | PPE with depreciation (IAS 16) | Cost, accumulated depreciation, NBV, disposal gains/losses. |
| **Prepayments & Deferrals** | Spreading costs across periods (IAS 1) | Straight-line or custom schedules, released to expense. |
| **Tax Desk** | VAT, NHIL/GETFund, CST, tourism levy, WHT, returns | Ghana statutory schedules and filing working papers. |
| **Ageing Analysis (AR & AP)** | Receivables/payables aging | Current / 1–30 / 31–60 / 61–90 / >90 days. |
| **Banking & Reconcile** | Treasury records, statement import | Server-side import (`/api/bank-feeds`), persisted + auto-matched to the GL. Balances are derived from the ledger, never edited by hand. |
| **Expenses & Statutory** | Operating expense claims and statutory payables | 202000 Accrued Expenses; settlement only at the Payment Desk. |
| **Prepayments & Deferrals** | Spreading costs across periods | Releases to expense; drives IAS 1 line. |
| **Project Costing & Contracts** | WIP and job-cost ledgers | IAS 2 cost-of-sale release. |
| **Compliance Review** | Gap analysis vs IFRS/statutory | `buildIfrsPack` ControlChecks; blocks issue of statements. |
| **Parallel Close & Go-Live** | Parallel-run a month vs legacy books | Evidence + sign-off; never cuts over without it. |
| **Data Migration** | CSV import: opening balances, ledger history, parties, banks | Validates the whole file, then commits atomically. Preview never writes. |

### People & administration

| Desk / module | What it does |
|---|---|
| **Payroll Desk** | PAYE, SSNIT tiers, allowances and deductions; posts payroll to the ledger. |
| **HR Management Desk** | Employees, structure, attendance, requests. |
| **Customer & Vendor Master (BP)** | Register parties, grant/restrict credit, credit limits and terms. |
| **Data Migration** | Import opening balances, history, parties, banks (this guide, Part 1). |
| **User Access & Restrictions** | Per-user roles, maker limits, module ticks. |
| **Enterprise Administration** | SSO, tax settings, SOC/DR, operations/backup, API & webhooks. |

### Integration & developer

| Feature | What it does |
|---|---|
| **Open API (`/api/v1`)** | Key-authenticated ledger, invoice and statement access. See `docs/API.md`. |
| **Bank feeds (`/api/bank-feeds`)** | Upload a statement once; the server parses, persists and auto-matches it to the ledger. |
| **E-invoicing (`/api/einvoice`)** | Submission queue to a GRA/e-VAT gateway. Opt-in; posting is never blocked. |
| **PWA / mobile** | Installable app manifest; the workspace is responsive on phones and tablets. |

---

## Part 4 — Controls you can rely on

- **Double entry enforced** — every document balances before it posts.
- **Immutability** — posted journals are append-only; corrections are reversals.
- **Idempotency** — replaying a document posts it exactly once.
- **Maker–checker** — independent approval; a maker cannot approve their own work.
- **Period locks** — closed periods reject postings; reopening is audited.
- **Tenant isolation** — every query is scoped to one entity; cross-entity
  access is refused server-side.
- **GRNI discipline** — receipts are never treated as invoiced payables.

See `docs/SECURITY.md` for the full control mapping.

---

## Quick reference: cut-over checklist

- [ ] Client workspace created with correct currency and fiscal year
- [ ] Company profile filled (TIN, VAT, bank details)
- [ ] Opening balances imported and previewed cleanly
- [ ] Bank accounts registered to `10xxxx` GLs
- [ ] Customers & vendors imported with credit terms
- [ ] Ledger history imported for the reporting year
- [ ] Trial balance balances; control accounts reconcile
- [ ] Balance sheet and P&L agree to the legacy system
- [ ] One month parallel-run closed and signed off
- [ ] Period locked; BPZ designated book of record
