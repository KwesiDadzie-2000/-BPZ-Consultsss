# Service Level Commitment

This SLA governs the BPZ Consults ERP hosted workspace. It is a commercial
commitment template; final terms are set in the client agreement.

## Availability

- **Target availability:** 99.5% monthly, excluding scheduled maintenance.
- **Scheduled maintenance:** announced at least 48 hours in advance, performed
  in low-usage windows.
- **Measurement:** availability is measured by successful responses from
  `/api/health` at one-minute intervals.

## Support tiers

| Severity | Definition | Response target |
|---|---|---|
| Critical | Ledger cannot be written or read; data integrity at risk | 4 business hours |
| High | A core desk is unusable; workaround exists | 1 business day |
| Normal | Cosmetic or non-blocking issue | 3 business days |

## Data durability

- The ledger is the system of record; it is append-only and never silently mutated.
- Point-in-time backups run on the configured schedule; off-site copies are kept
  per the retention policy (`BPZ_BACKUP_KEEP`).
- Recovery point objective (RPO): last completed scheduled backup.
- Recovery time objective (RTO): one business day from a verified backup.

## Exclusions

Availability does not cover client-side connectivity, browser issues, planned
maintenance, or third-party gateway outages (payment, e-invoicing, email).
