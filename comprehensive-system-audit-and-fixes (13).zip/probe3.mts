process.env.DATABASE_URL = 'postgresql://postgres:postgres@127.0.0.1:5432/app_db';
const { db } = await import('/app/src/db');
const { journalLines, chartAccounts, clients } = await import('/app/src/db/schema');
const { buildIfrsPack, groupOf } = await import('/app/src/utils/ifrsPack');
const [L, A, cs] = await Promise.all([db.select().from(journalLines), db.select().from(chartAccounts), db.select().from(clients)]);
const c = cs.find(x=>x.code==='CLI-001')!;
const lines = L.filter(l=>l.clientId===c.id);
const accts = A.filter(a=>a.clientId==null||a.clientId===c.id);
// net per account
const net = new Map<string, number>();
for (const l of lines) net.set(l.accountNo, (net.get(l.accountNo)||0) + Math.round((l.debit-l.credit)*100)/100);
console.log('account | type | name | net | group');
let creditNoHome = 0;
for (const [code, v] of [...net].sort()) {
  const a = accts.find(x=>x.accountNo===code);
  if (Math.abs(v) < 0.005) continue;
  const g = groupOf(a, code);
  console.log(`${code} | ${a?.type} | ${(a?.name||'').slice(0,40)} | ${v} | ${g}`);
}
// failing check severities
const pack = buildIfrsPack({ lines, accounts: accts, from:'2026-01-01', through:'2026-12-31', currency:c.currency, entityName:c.name, entityCode:c.code, jurisdiction:c.jurisdiction });
console.log('\nCHECKS:');
for (const k of pack.checks) console.log(` ${k.severity} ${k.id}: ${k.title} -> ${k.action.slice(0,90)}`);
process.exit(0);
