process.env.DATABASE_URL = 'postgresql://postgres:postgres@127.0.0.1:5432/app_db';
const { db } = await import('/app/src/db');
const { journalLines, chartAccounts, clients } = await import('/app/src/db/schema');
const R = await import('/app/src/utils/reports');
const [L, A, cs] = await Promise.all([db.select().from(journalLines), db.select().from(chartAccounts), db.select().from(clients)]);
const c = cs.find(x=>x.code==='CLI-001')!;
const lines = L.filter(l=>l.clientId===c.id && l.date>='2026-01-01' && l.date<='2026-12-31');
// every balance-sheet account with a movement
const moved = new Map<string, number>();
for (const l of lines) moved.set(l.accountNo, (moved.get(l.accountNo)||0)+Math.round((l.debit-l.credit)*100)/100);
// classified lists from reports.ts source
const src = await import('fs').then(fs=>fs.readFileSync('/app/src/utils/reports.ts','utf8'));
const pick = (name:string) => { const m = new RegExp(`const ${name} = \\[([^\\]]+)\\]`).exec(src); return m ? m[1].split(',').map(s=>s.trim().replace(/['"]/g,'')) : []; };
const covered = new Set<string>();
for (const n of ['RECEIVABLE_ACCOUNTS','INVENTORY_ACCOUNTS','PREPAID_ACCOUNTS','PAYABLE_ACCOUNTS','INVESTING_ACCOUNTS','FINANCING_ACCOUNTS','CASH_ACCOUNTS','ADD_BACK_EXPENSE','ADD_BACK_CREDIT','REMOVE_GAIN']) for (const a of pick(n)) covered.add(a);
console.log('accounts with movement NOT in any cash-flow group:');
for (const [code, v] of [...moved].sort()) {
  if (covered.has(code)) continue;
  const a = A.find(x=>x.accountNo===code);
  console.log(`  ${code} ${(a?.name||'').slice(0,50)} delta=${v} type=${a?.type}`);
}
console.log('\ncash lines:');
for (const l of lines.filter(l=>/^10\d{4}$/.test(l.accountNo))) console.log(`  ${l.date} ${l.docNo} ${l.accountNo} dr=${l.debit} cr=${l.credit} :: ${l.description.slice(0,60)}`);
process.exit(0);
