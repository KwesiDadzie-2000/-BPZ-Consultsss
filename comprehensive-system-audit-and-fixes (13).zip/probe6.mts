process.env.DATABASE_URL = 'postgresql://postgres:postgres@127.0.0.1:5432/app_db';
const { db } = await import('/app/src/db');
const { journalLines, clients } = await import('/app/src/db/schema');
const [L, cs] = await Promise.all([db.select().from(journalLines), db.select().from(clients)]);
const c = cs.find(x=>x.code==='CLI-001')!;
const lines = L.filter(l=>l.clientId===c.id).sort((a,b)=>a.date.localeCompare(b.date));
for (const l of lines) console.log(`${l.date} ${l.docNo.padEnd(26)} ${l.accountNo} dr=${String(l.debit).padStart(9)} cr=${String(l.credit).padStart(9)} ${l.docType} :: ${l.description.slice(0,52)}`);
process.exit(0);
