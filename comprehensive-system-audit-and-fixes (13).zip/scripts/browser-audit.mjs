import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { createRequire } from 'node:module';
import { createServer } from 'node:net';
import { resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import pg from 'pg';

// Resets only the named disposable local database, not the preview or live books.
const url = new URL(process.env.BPZ_BROWSER_DATABASE_URL ?? 'postgresql://postgres:postgres@127.0.0.1:5432/bpz_browser_test');
assert.ok(['localhost', '127.0.0.1'].includes(url.hostname) && url.pathname === '/bpz_browser_test', 'Browser audit requires the disposable local bpz_browser_test database.');
const require = createRequire(process.env.BPZ_PLAYWRIGHT_ROOT ? resolve(process.env.BPZ_PLAYWRIGHT_ROOT, 'package.json') : import.meta.url);
const { chromium } = require('playwright');
const fixture = new pg.Pool({ connectionString: url.href });
try { await fixture.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;'); } finally { await fixture.end(); }
const port = await new Promise((ok, fail) => {
  const server = createServer().once('error', fail).listen(0, '127.0.0.1', () => {
    const { port } = server.address();
    server.close((error) => error ? fail(error) : ok(port));
  });
});
const base = `http://127.0.0.1:${port}`;
const password = `Audit-${randomUUID()}-1a!`;
const server = spawn(process.execPath, ['node_modules/next/dist/bin/next', 'start', '-H', '127.0.0.1', '-p', String(port)], {
  env: { ...process.env, NODE_ENV: 'production', DATABASE_URL: url.href, BPZ_BOOTSTRAP_MODE: 'demo', BPZ_SEED_PASSWORD_OWNER: password,
    BPZ_SEED_PASSWORD_DEMO: password, BPZ_ENFORCE_MFA_OWNER: 'false', BPZ_ENFORCE_MFA_CHECKERS: 'false', BPZ_BACKUP_SCHEDULE_ENABLED: 'false' },
  stdio: ['ignore', 'pipe', 'pipe'],
});
let serverTail = '';
for (const stream of [server.stdout, server.stderr]) stream.on('data', (chunk) => { serverTail = (serverTail + chunk).slice(-16_000); });
const failures = [];
let browser;
let deskCount = 0;
let tabCount = 0;
let sectorCount = 0;
let flowCount = 0;
const shutdown = () => { server.kill('SIGTERM'); };
process.once('SIGTERM', () => { shutdown(); process.exit(1); });
const check = async (name, fn) => {
  try { await fn(); console.log(`PASS ${name}`); return true; }
  catch (error) { failures.push(`${name}: ${error.message}`); console.error(`FAIL ${failures.at(-1)}`); return false; }
};

try {
  let ready = false;
  for (let i = 0; i < 70 && server.exitCode === null; i++) {
    if (await fetch(`${base}/api/health`, { signal: AbortSignal.timeout(2_000) }).then((r) => r.ok).catch(() => false)) { ready = true; break; }
    await delay(220);
  }
  assert.ok(ready, 'Isolated preview failed its health check');
  browser = await chromium.launch();
  const errors = new Set();
  function observe(page) {
    page.on('pageerror', (error) => errors.add(error.message));
    page.on('console', (message) => {
      // Track status via the response event instead of Chromium's generic resource error.
      if (message.type() === 'error' && !message.text().startsWith('Failed to load resource: the server responded with a status of')) errors.add(message.text());
    });
    page.on('response', (r) => {
      const path = new URL(r.url()).pathname;
      if (r.url().startsWith(base) && (r.status() >= 500 || (r.status() === 401 && path !== '/api/auth/session'))) errors.add(`HTTP ${r.status()} ${path}`);
    });
    page.setDefaultTimeout(6500);
  }
  const page = await browser.newPage({ viewport: { width: 1440, height: 960 }, acceptDownloads: true });
  observe(page);
  const signIn = async (tab, user, section = 'dashboard') => {
    await tab.goto(base);
    await tab.getByLabel('Username or email').fill(user);
    await tab.getByLabel('Password', { exact: true }).fill(password);
    await tab.getByRole('button', { name: 'Sign In', exact: true }).click();
    await tab.locator(`main[data-module-id="${section}"]`).waitFor();
  };
  let snapshotWrites = 0;
  page.on('request', (r) => { if (r.method() === 'PUT' && r.url().endsWith('/api/state')) snapshotWrites++; });
  await signIn(page, 'owner');
  if (await check('idle workspace reads do not write an unchanged snapshot', async () => {
    await delay(1250);
    assert.equal(snapshotWrites, 0);
  })) flowCount++;
  const navigation = page.locator('#workspace-navigation');
  for (const group of await navigation.locator('nav button[aria-controls^="nav-group-"]').all()) {
    if (await group.getAttribute('aria-expanded') === 'false') await group.click();
  }
  const modules = await navigation.locator('button[data-module-id]').evaluateAll((nodes) => nodes.map((node) => node.getAttribute('data-module-id')));
  assert.ok(modules.length >= 50, `Expected the full owner sidebar, got ${modules.length} desks`);
  const main = page.locator('#workspace-content');
  const assertDesk = async (section) => {
    await main.and(page.locator(`[data-module-id="${section}"]`)).waitFor();
    await main.locator('h1,h2,h3').first().waitFor();
    assert.equal(await main.getByText(/module could not be displayed/i).count(), 0, `${section} hit the error boundary`);
    assert.equal(await main.getByRole('status').filter({ hasText: /did not accept|sync is paused/i }).count(), 0, `${section} reported a workspace sync fault`);
  };
  const open = async (section) => {
    await navigation.locator(`button[data-module-id="${section}"]`).click();
    await assertDesk(section);
  };
  for (const section of modules) {
    if (await check(`desk ${section}`, async () => {
      await open(section);
      if (section === 'parallel_close') await main.getByRole('tablist', { name: 'Parallel close sections' }).waitFor();
      // Exercise the desk's top-level tab strip, not nested tables or forms on one tab.
      const tabs = main.getByRole('tablist').first().getByRole('tab');
      if (await tabs.count()) {
        for (const entry of await tabs.all()) {
          if (await entry.isDisabled()) continue;
          await entry.click();
          assert.equal(await entry.getAttribute('aria-selected'), 'true');
          await assertDesk(section);
          tabCount++;
        }
      }
    })) deskCount++;
  }

  if (await check('all configured sector profiles switch and render', async () => {
    await open('sector_workflow');
    const selector = main.getByRole('combobox', { name: 'Entity sector' });
    const sectors = await selector.locator('option').evaluateAll((options) => options.map((opt) => ({ code: opt.value, name: opt.textContent.trim() })));
    assert.equal(sectors.length, 24);
    for (const sector of sectors) {
      await selector.selectOption(sector.code);
      const profile = main.getByText('Current profile:', { exact: true }).locator('..');
      assert.ok((await profile.innerText()).includes(sector.name), `${sector.code} rendered the wrong profile`);
      sectorCount++;
    }
  })) flowCount++;

  if (await check('register a customer and vendor with credit terms and reload', async () => {
    await open('business_partners_crm');
    for (const type of ['Customer', 'Vendor']) {
      await main.getByRole('button', { name: 'Register Customer / Vendor' }).click();
      const form = page.locator('form').filter({ has: page.getByRole('heading', { name: 'Register Customer or Vendor', exact: true }) });
      await form.getByText('Partner Type', { exact: true }).locator('..').locator('select').selectOption(type);
      await form.getByText('Legal Company / Business Name', { exact: true }).locator('..').locator('input').fill(`Browser Audit ${type}`);
      await form.getByLabel(/Credit limit/).fill('1250.50');
      await form.getByLabel(/Credit terms \(days\)/).fill('28');
      const saved = page.waitForResponse((r) => r.url().endsWith('/api/state') && r.request().method() === 'PUT' && r.request().postDataJSON()?.businessPartners?.some((bp) => bp.name === `Browser Audit ${type}`), { timeout: 9000 });
      await form.getByRole('button', { name: 'Register Partner' }).click();
      const result = await saved;
      assert.ok(result.ok(), `Partner sync failed: ${result.status()}`);
    }
    await page.reload();
    await main.waitFor();
    await navigation.getByLabel('Find a module').fill('Customers & Vendors');
    await open('business_partners_crm');
    for (const type of ['Customer', 'Vendor']) {
      const row = main.getByRole('row').filter({ hasText: `Browser Audit ${type}` });
      assert.match(await row.innerText(), /1,250\.50/);
      assert.match(await row.innerText(), /28-day terms/);
    }
  })) flowCount++;

  if (await check('customer and vendor credit actions persist journal and open items', async () => {
    await navigation.getByLabel('Find a module').fill('Customers & Vendors');
    await open('business_partners_crm');
    for (const [name, amount, register] of [['Zurich Gold Refinery AG', '12.50', 'salesInvoices'], ['Browser Audit Vendor', '21.00', 'purchaseOrders']]) {
      const row = main.getByRole('row').filter({ hasText: name });
      await row.getByRole('button', { name: 'Credit / Memo', exact: true }).click();
      const form = main.locator('form').filter({ has: page.getByRole('heading', { name: /Credit Customer|Credit \/ Adjust Vendor/ }) });
      await form.getByLabel(/Amount \(/).fill(amount);
      await form.getByLabel('Reason / Audit Reference').fill(`Browser audit adjustment ${name}`);
      const persisted = page.waitForResponse((response) => {
        if (!response.url().endsWith('/api/state') || response.request().method() !== 'PUT') return false;
        return response.request().postDataJSON()?.[register]?.some((r) => register === 'salesInvoices' ? r.invNo === 'INV-2026-001' && r.paidAmount === 12.5 : r.vendorName === name && r.totalAmount === 21);
      }, { timeout: 9_000 });
      await form.getByRole('button', { name: 'Post Credit Adjustment' }).click();
      assert.ok((await persisted).ok(), `Credit register failed for ${name}`);
    }
    const response = await page.request.get(`${base}/api/bootstrap`, { timeout: 4000 });
    assert.ok(response.ok());
    const books = (await response.json()).state;
    assert.ok(books.journalLines.some((l) => l.accountNo === '110000' && l.credit === 12.5 && l.reference === 'INV-2026-001'));
    assert.ok(books.journalLines.some((l) => l.accountNo === '200000' && l.credit === 21 && l.description.includes('Browser Audit Vendor')));
  })) flowCount++;

  if (await check('import a bank statement, match, export, and isolate the selected account', async () => {
    await navigation.getByLabel('Find a module').fill('Banking & Reconcile');
    await open('banking');
    const books = (await (await page.request.get(`${base}/api/bootstrap`)).json()).state;
    const sample = books.journalLines.find((l) => l.clientId === 2 && l.accountNo === '100000' && l.currency === 'GHS' && l.credit > 0);
    assert.ok(sample, 'The fixture must have a posted cash outflow');
    const csv = 'Date,Description,Debit,Credit,Reference\n' + `${sample.date},=Audit outflow,${sample.credit},,${sample.docNo}\n`
      + Array.from({ length: 140 }, (_, i) => `2026-03-12,Audit deposit ${i},,${1201 + i},AUD-${i}`).join('\n');
    await main.locator('input[type="file"]').setInputFiles({ name: 'audit.csv', mimeType: 'text/csv', buffer: Buffer.from(csv) });
    await main.getByText(/System analysis.*audit\.csv/i).waitFor();
    assert.ok(await main.getByText(`Matched · ${sample.docNo}`, { exact: true }).count());
    assert.ok(await main.getByText(/Page 1 of 2/).isVisible());
    await main.getByRole('button', { name: 'Next', exact: true }).click();
    assert.ok(await main.getByText(/Page 2 of 2/).isVisible());
    const download = page.waitForEvent('download', { timeout: 8000 });
    await main.getByRole('button', { name: 'Download analysis' }).click();
    const downloaded = await download;
    assert.match(downloaded.suggestedFilename(), /statement-analysis.*\.csv$/);
    const stream = await downloaded.createReadStream();
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    const output = Buffer.concat(chunks).toString('utf8');
    assert.match(output, /Audit deposit 139/);
    assert.match(output, /"'=Audit outflow"/);
    await main.getByRole('button').filter({ hasText: /Export Bullion Collateral/ }).click();
    assert.equal(await main.getByText(/System analysis.*audit\.csv/i).count(), 0, 'Statement moved to a different account');
    await main.getByRole('button').filter({ hasText: /Operating Account \(GHS\)/ }).click();
    await main.getByText(/System analysis.*audit\.csv/i).waitFor();
  })) flowCount++;

  if (await check('prior-period expense reaches the permanent payable ledger', async () => {
    await navigation.getByLabel('Find a module').fill('Expenses & Statutory');
    await open('expenses');
    await main.getByLabel('Expense period').fill('2026-02');
    await main.getByLabel('Payee / vendor').fill('Browser audit prior period');
    await main.getByLabel('Bill amount (gross)').fill('37.50');
    await main.getByRole('button', { name: /Record bill as payable/ }).click();
    let payable;
    for (let attempt = 0; attempt < 20 && !payable; attempt++) {
      const response = await page.request.get(`${base}/api/bootstrap`, { timeout: 4000 });
      assert.ok(response.ok(), `Bootstrap after expense: ${response.status()}`);
      const books = (await response.json()).state;
      payable = books.journalLines.find((l) => l.accountNo === '202000' && l.description.includes('Browser audit prior period'));
      if (!payable) await delay(150);
    }
    assert.ok(payable);
    assert.deepEqual([payable.period, payable.date, payable.credit], ['2026-02', '2026-02-28', 37.5]);
  })) flowCount++;

  if (await check('parallel-close draft, trial import and reviewer scope', async () => {
    await navigation.getByLabel('Find a module').fill('Parallel Close');
    await open('parallel_close');
    await main.getByLabel('Pilot month').fill('2026-02');
    await main.getByRole('button', { name: 'Open month' }).click();
    await main.getByLabel('Legacy system / close reference').fill('Browser exercise / February legacy close');
    await main.getByLabel('Scope and cut-off notes').fill('This bounded browser exercise verifies the draft, source file and reviewer access.');
    await main.getByRole('button', { name: 'Create draft' }).click();
    await main.getByText('Draft saved on the server.').waitFor();
    await main.getByRole('tab', { name: 'Trial balance', exact: true }).click();
    await main.getByLabel('Import legacy trial CSV').setInputFiles({ name: 'close-fixture.csv', mimeType: 'text/csv', buffer: Buffer.from('Account,Debit,Credit,Currency\n100000,12,0,GHS\n300000,0,12,GHS') });
    await main.getByText('Legacy trial balance imported and compared to the ledger.').waitFor();
    await main.getByRole('tab', { name: 'Review & go-live', exact: true }).click();
    assert.ok(await main.getByRole('button', { name: 'Submit for review' }).isDisabled());
    await main.getByRole('button', { name: 'Add close reviewer' }).click();
    await main.getByLabel('Reviewer full name').fill('Browser Close Reviewer');
    await main.getByLabel('Reviewer username').fill('browser_close_reviewer');
    await main.getByLabel('Reviewer email').fill('browser-reviewer@example.invalid');
    await main.getByLabel('Temporary password').fill(password);
    await main.getByRole('button', { name: 'Create reviewer account' }).click();
    await main.getByText(/Reviewer browser_close_reviewer created/).waitFor();
    const reviewer = await browser.newPage();
    observe(reviewer);
    await signIn(reviewer, 'browser_close_reviewer', 'parallel_close');
    const workspace = reviewer.locator('#workspace-content');
    await workspace.getByRole('heading', { name: 'Parallel Close & Go-Live' }).waitFor();
    const scopedState = await reviewer.request.get(`${base}/api/bootstrap`);
    assert.equal((await scopedState.json()).state.journalLines, undefined);
    const direct = await reviewer.request.get(`${base}/api/trade?clientId=2`);
    assert.equal(direct.status(), 401);
    assert.equal(await workspace.getByRole('button', { name: 'Save draft' }).count(), 0);
    await reviewer.locator('#workspace-navigation').getByLabel('Find a module').fill('Banking & Reconcile');
    await reviewer.getByText(/No module matches/).waitFor();
    await reviewer.close();
    await page.reload();
    await main.waitFor();
    await navigation.getByLabel('Find a module').fill('Parallel Close');
    await open('parallel_close');
    await main.getByLabel('Pilot month').fill('2026-02');
    await main.getByRole('button', { name: 'Open month' }).click();
    assert.equal(await main.getByLabel('Legacy system / close reference').inputValue(), 'Browser exercise / February legacy close');
    await main.getByRole('tab', { name: 'Trial balance', exact: true }).click();
    await main.getByText('close-fixture.csv', { exact: true }).waitFor();
  })) flowCount++;

  if (await check('mobile drawer opens, navigates and closes', async () => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.getByRole('button', { name: 'Open navigation menu' }).click();
    await page.getByRole('dialog', { name: 'Main navigation' }).waitFor();
    await navigation.getByLabel('Find a module').fill('General Ledger');
    await open('general_ledger');
    assert.equal(await page.getByRole('button', { name: 'Open navigation menu' }).getAttribute('aria-expanded'), 'false');
  })) flowCount++;

  if (await check('client login is scoped and does not show owner desks', async () => {
    const client = await browser.newPage({ viewport: { width: 1400, height: 900 } });
    observe(client);
    await signIn(client, 'demo');
    assert.equal(await client.getByLabel('Active accounting workspace').count(), 0);
    await client.locator('#workspace-navigation').getByLabel('Find a module').fill('User Access & Restrictions');
    await client.getByText(/No module matches/).waitFor();
    const state = await client.request.get(`${base}/api/bootstrap`);
    assert.ok(state.ok());
    assert.deepEqual((await state.json()).state.clients.map((row) => row.id), [2]);
    await client.close();
  })) flowCount++;
  await check('browser has no uncaught errors or HTTP 5xx', async () => assert.deepEqual([...errors], []));
} catch (error) {
  failures.push(error.message);
  console.error(error.stack ?? error);
} finally {
  await browser?.close().catch(() => undefined);
  shutdown();
  if (server.exitCode === null) await Promise.race([new Promise((ok) => server.once('exit', ok)), delay(2200)]);
  if (server.exitCode === null) server.kill('SIGKILL');
}
console.log(`Browser audit: ${deskCount} sidebar desks, ${tabCount} tab visits, ${sectorCount} sector profiles, ${flowCount} workflows; ${failures.length} failed.`);
if (failures.length) {
  console.error(serverTail);
  process.exitCode = 1;
}
