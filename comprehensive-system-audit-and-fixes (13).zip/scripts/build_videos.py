"""Build the two standalone BPZ videos (slides + gTTS voiceover + ffmpeg)."""
import os, subprocess, tempfile, time
import imageio_ffmpeg
from gtts import gTTS
from mutagen.mp3 import MP3
from PIL import Image, ImageDraw, ImageFont

FF = imageio_ffmpeg.get_ffmpeg_exe()
W, H = 1280, 720
NAVY, GOLD, BG, INK, MUTED = (8,47,79),(245,183,25),(240,246,252),(10,37,62),(53,88,117)
FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FR = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FM = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
OUT = os.path.join(os.path.dirname(__file__), "..", "public", "videos")
os.makedirs(OUT, exist_ok=True)

def fnt(p,s): return ImageFont.truetype(p,s)
def wrap(d,t,f,mw):
    out=[]; cur=""
    for w in t.split():
        c=(cur+" "+w).strip()
        if d.textlength(c,font=f)<=mw: cur=c
        else:
            if cur: out.append(cur)
            cur=w
    if cur: out.append(cur)
    return out

def slide(p,k,title,lines,i,total,mono=False):
    img=Image.new("RGB",(W,H),BG); d=ImageDraw.Draw(img)
    d.rectangle([0,0,W,170],fill=NAVY)
    d.text((64,30),k,font=fnt(FB,26),fill=GOLD)
    ft=fnt(FB,54); y=62
    for ln in wrap(d,title,ft,W-128)[:2]:
        d.text((64,y),ln,font=ft,fill=(255,255,255)); y+=62
    d.rectangle([0,170,W,176],fill=GOLD)
    fb=fnt(FM if mono else FR,30); y=230
    for line in lines:
        for ln in wrap(d,("  "+line) if mono else ("\u25b8  "+line),fb,W-160):
            d.text((80,y),ln,font=fb,fill=INK); y+=44
            if y>H-110: break
    d.line([(64,H-70),(W-64,H-70)],fill=(207,224,241),width=2)
    d.text((64,H-58),"BPZ Consults",font=fnt(FB,22),fill=MUTED)
    tag=f"{i+1} / {total}"; d.text((W-64-d.textlength(tag,font=fnt(FR,22)),H-58),tag,font=fnt(FR,22),fill=MUTED)
    d.rectangle([0,H-6,int(W*(i+1)/total),H],fill=GOLD)
    img.save(p)

def voice(mp3,text):
    for a in range(3):
        try: gTTS(text,lang="en",tld="com").save(mp3); time.sleep(0.4); return
        except Exception:
            if a==2: raise
            time.sleep(2)

def seg(sl,au,out,dur):
    subprocess.run([FF,"-y","-loop","1","-t",f"{dur:.2f}","-i",sl,"-i",au,"-c:v","libx264","-preset","veryfast","-crf","22","-pix_fmt","yuv420p","-c:a","aac","-b:a","128k","-af","apad","-shortest","-movflags","+faststart",out],check=True,capture_output=True)

def build(name,slides):
    print(f"== {name} ==",flush=True)
    tmp=tempfile.mkdtemp(prefix="bpz_"); parts=[]
    for i,s in enumerate(slides):
        png=f"{tmp}/s{i}.png"; mp3=f"{tmp}/s{i}.mp3"; mv=f"{tmp}/s{i}.mp4"
        slide(png,s["kicker"],s["title"],s["lines"],i,len(slides),s.get("mono",False))
        voice(mp3,s["say"]); dur=max(MP3(mp3).info.length+0.9,3.6); seg(png,mp3,mv,dur); parts.append(mv)
        print(f"  scene {i+1}/{len(slides)} ({dur:.1f}s)",flush=True)
    lst=f"{tmp}/list.txt"
    open(lst,"w").write("".join(f"file '{p}'\n" for p in parts))
    final=os.path.join(OUT,name+".mp4")
    subprocess.run([FF,"-y","-f","concat","-safe","0","-i",lst,"-c","copy","-movflags","+faststart",final],check=True,capture_output=True)
    Image.open(f"{tmp}/s0.png").convert("RGB").save(os.path.join(OUT,name+"-poster.jpg"),quality=82)
    print(f"DONE {final} ({os.path.getsize(final)/1e6:.1f} MB)",flush=True)

MARKETING=[
 dict(kicker="BPZ CONSULTS · CHARTERED ACCOUNTANTS",title="Accurate books. On time. Every time.",lines=["One workspace for your whole business","Built for Ghanaian practice, ready for IFRS"],say="Welcome to BPZ Consults, chartered accountants and business advisors. Accurate books, on time, every time."),
 dict(kicker="THE SYSTEM",title="One workspace, one balanced ledger",lines=["Sales and invoicing","Procurement with three-way matching","Inventory, payroll, banking","Tax and IFRS financial statements"],say="BPZ Consults runs your whole business in one workspace. Sales, procurement, inventory, payroll, banking, tax and IFRS financial statements, all posting to one balanced ledger."),
 dict(kicker="KEY FEATURES",title="Receipts are never payables",lines=["Warehouse receipts accrue to 204000 GRNI","Supplier invoices clear GRNI into 200000 payables","Only invoiced balances can ever be paid"],say="Warehouse receipts accrue to goods received not invoiced, never directly to payables. The supplier invoice clears GRNI and opens the payable, so only invoiced balances can ever be paid."),
 dict(kicker="KEY FEATURES",title="Statements you can send",lines=["Customer and vendor statements of account","Every control account reconciles to the pesewa","Maker-checker approvals with full audit trail"],say="Generate customer and vendor statements from posted journals. Reconcile every control account to the pesewa, with maker checker approvals and a full audit trail."),
 dict(kicker="BENEFITS FOR CLIENTS",title="Know exactly where you stand",lines=["Who owes you, and who you owe","Correct VAT and a faster month-end","Clean books your auditor and bank trust"],say="As a client you always know who owes you and who you owe. Correct VAT, a faster month-end, and clean books your auditor and bank can trust."),
 dict(kicker="NEXT STEP",title="Ask for a live walkthrough",lines=["Bring one month of transactions","We post them with you, live","BPZ Consults — your books, done right"],say="Ask your firm for a live walkthrough. Bring one month of transactions and we will post them with you, live. BPZ Consults, your books, done right."),
]
LIVECASE=[
 dict(kicker="LIVE CASE · PURCHASE CYCLE",title="From order to paid supplier",lines=["Approved purchase order, then warehouse receipt","Supplier invoice, then payment"],say="A live case, exactly as it posts. From purchase order, to warehouse receipt, to supplier invoice, to payment."),
 dict(kicker="STEP 1 · GOODS RECEIVED",title="Inventory in, GRNI accrual",lines=["Dr  120000  Inventory .......... 100.00","Cr  204000  GRNI clearing ....... 100.00","An accrual — not a payable, no tax yet"],mono=True,say="The warehouse receives the goods. We debit inventory one hundred and credit GRNI clearing one hundred. This is an accrual, not a payable, and no tax is claimed yet."),
 dict(kicker="STEP 2 · SUPPLIER INVOICE",title="Match, clear, recognise payable",lines=["Dr  204000  GRNI clearing ....... 100.00","Dr  125000  Input VAT ........... 20.00","Cr  200000  Trade payables ..... 120.00"],mono=True,say="The supplier invoice arrives and matches. We clear GRNI one hundred, recognise twenty input VAT, and open a one hundred and twenty payable."),
 dict(kicker="STEP 3 · PAYMENT",title="Only invoiced balances are paid",lines=["Dr  200000  Trade payables ..... 120.00","Cr  100000  Cash at bank ....... 120.00","Withholding tax recognised where due"],mono=True,say="Payment settles the invoiced balance. Debit payables, credit the bank. Uninvoiced receipts can never be paid."),
 dict(kicker="STEP 4 · SALE OF STOCK",title="Revenue with its matching cost",lines=["Dr 110000 Receivable · Cr 402000 Revenue · Cr 220000 VAT","Dr 504000 Cost of sales · Cr 120000 Inventory","One document — revenue is never a stock movement alone"],mono=True,say="Selling stock posts the receivable, revenue and output tax, with cost of sales and the stock issue in the same document."),
 dict(kicker="STEP 5 · RECEIPT AND STATEMENT",title="Cash in, account stated",lines=["Dr 100000 Cash · Cr 110000 Receivable","Receipt allocated to the open invoice","Owner generates the statement of account"],mono=True,say="The customer pays, the receipt clears the invoice, and the owner generates the statement of account."),
 dict(kicker="FINAL WORK DONE",title="Sign-off checklist",lines=["Trial balance balanced, debits equal credits","GRNI zero · payables and receivables reconciled","Bank agrees to the ledger · period closed"],say="Final work done. The trial balance balances. GRNI is zero. Payables and receivables agree to their sub ledgers. The bank agrees to the ledger. Then the period is closed."),
]
if __name__=="__main__":
    build("bpz-consults-marketing",MARKETING)
    build("accountant-live-case-scenario",LIVECASE)
    print("ALL DONE")
