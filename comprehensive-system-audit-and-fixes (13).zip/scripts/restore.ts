import "dotenv/config";
import { readFile } from "node:fs/promises";
import { gunzipSync } from "node:zlib";
import { pool } from "@/db";

/**
 * Restore a backup written by scripts/backup.ts.
 *
 *   npx tsx scripts/restore.ts <backup.json.gz> [--dry-run] [--force]
 *
 * Safety:
 *  - refuses to write if the database already contains users, unless --force;
 *  - --dry-run only parses the file and reports table/row counts;
 *  - replaces the tables in the snapshot and revokes all sessions, so
 *    run it against a maintenance window with the app stopped.
 */
async function main() {
  const [file, ...flags] = process.argv.slice(2);
  if (!file) {
    console.error("Usage: npx tsx scripts/restore.ts <backup.json.gz> [--dry-run] [--force]");
    process.exit(2);
  }
  const dryRun = flags.includes("--dry-run");
  const force = flags.includes("--force");

  const raw = await readFile(file);
  const text = file.endsWith(".gz") ? gunzipSync(raw).toString("utf8") : raw.toString("utf8");
  const payload = JSON.parse(text) as { app?: string; createdAt?: string; tables: Record<string, Record<string, unknown>[]> };
  if (payload.app !== "bpz-consult-erp" || !payload.tables) {
    console.error("Not a BPZ Consult backup file.");
    process.exit(2);
  }
  const volatile = new Set(['bpz_sessions', 'bpz_login_attempts', 'bpz_mfa_enrollments', 'bpz_rate_limits']);
  const names = Object.keys(payload.tables).filter((table) => !volatile.has(table));
  if (!names.length || names.some((n) => !/^[a-z_][a-z0-9_]*$/.test(n) || !Array.isArray(payload.tables[n]))) {
    throw new Error("Backup contains invalid or missing table data.");
  }
  const counts = names.map((n) => `${n}:${payload.tables[n].length}`).join(" ");
  console.log(`Backup ${payload.createdAt ?? ""} — ${names.length} tables — ${counts}`);

  if (dryRun) {
    console.log("Dry run only; nothing written.");
    await pool.end();
    return;
  }

  const existing = await pool.query<{ n: number }>(`select count(*)::int as n from users`);
  if (Number(existing.rows[0]?.n ?? 0) > 0 && !force) {
    console.error("Refusing to restore into a database that already has users. Stop the app, then re-run with --force.");
    await pool.end();
    process.exit(1);
  }

  const client = await pool.connect();
  try {
    await client.query("begin");
    const existingTables = await client.query<{ table_name: string }>(
      "select table_name from information_schema.tables where table_schema = 'public' and table_type = 'BASE TABLE'"
    );
    const present = new Set(existingTables.rows.map((r) => r.table_name));
    const missing = names.filter((n) => !present.has(n));
    if (missing.length) throw new Error(`Target database lacks backup tables: ${missing.join(', ')}. Provision the schema first.`);
    const identities = await client.query<{ table_name: string; column_name: string }>(
      "select table_name, column_name from information_schema.columns where table_schema = 'public' and is_identity = 'YES'"
    );
    const identityByTable = new Map<string, string[]>();
    for (const { table_name, column_name } of identities.rows) {
      identityByTable.set(table_name, [...(identityByTable.get(table_name) ?? []), column_name]);
    }
    const dependencies = await client.query<{ child: string; parent: string }>(`
      select child.relname as child, parent.relname as parent
        from pg_constraint fk
        join pg_class child on child.oid = fk.conrelid
        join pg_class parent on parent.oid = fk.confrelid
        join pg_namespace cns on cns.oid = child.relnamespace
        join pg_namespace pns on pns.oid = parent.relnamespace
       where fk.contype = 'f' and cns.nspname = 'public' and pns.nspname = 'public'
    `);
    const ordered: string[] = [];
    const waiting = new Set(names);
    while (waiting.size) {
      const ready = [...waiting].filter((n) => !dependencies.rows.some((r) => r.child === n && r.parent !== n && waiting.has(r.parent)));
      if (!ready.length) throw new Error('The snapshot contains cyclic foreign-key dependencies and cannot be safely restored.');
      for (const n of ready) { ordered.push(n); waiting.delete(n); }
    }
    const truncated = new Set([...names, ...[...volatile].filter((n) => present.has(n))]);
    // Older snapshots may not yet contain newer FK child tables. Include only
    // empty children, and never erase records absent from the snapshot silently.
    for (;;) {
      const extra = [...new Set(dependencies.rows.filter((r) => truncated.has(r.parent) && !truncated.has(r.child)).map((r) => r.child))];
      if (!extra.length) break;
      for (const child of extra) {
        if (!/^[a-z_][a-z0-9_]*$/.test(child)) throw new Error('Unexpected target table name.');
        const found = await client.query(`select 1 from "${child}" limit 1`);
        if (found.rows.length) throw new Error(`The target contains data in ${child}, which is absent from the snapshot. Restore to a fresh database.`);
        truncated.add(child);
      }
    }
    const quoted = [...truncated].map((n) => `"${n}"`).join(", ");
    await client.query(`truncate table ${quoted} restart identity`);
    for (const name of ordered) {
      const rows = payload.tables[name];
      for (const row of rows) {
        const cols = Object.keys(row);
        if (cols.some((c) => !/^[a-z_][a-z0-9_]*$/.test(c))) throw new Error('Backup contains an invalid column name.');
        if (!cols.length) continue;
        const values = cols.map((c) => {
          const v = row[c];
          if (v === null || v === undefined) return null;
          if (v instanceof Date) return v;
          // pg bytea columns are serialised by node-postgres as {type:"Buffer",data:[...]}.
          // JSON.stringify would otherwise turn an attachment into invalid bytea text.
          if (v && typeof v === "object" && (v as { type?: unknown }).type === "Buffer" && Array.isArray((v as { data?: unknown }).data)) {
            return Buffer.from((v as { data: number[] }).data);
          }
          if (typeof v === "object") return JSON.stringify(v);
          return v;
        });
        await client.query(
          `insert into "${name}" (${cols.map((c) => `"${c}"`).join(", ")}) ${identityByTable.has(name) ? "overriding system value" : ""} values (${cols.map((_, i) => `$${i + 1}`).join(", ")})`,
          values
        );
      }
      // Keep identity sequences above restored IDs so the next insert cannot
      // collide with a restored chart or disclosure-note row.
      for (const column of identityByTable.get(name) ?? []) {
        const result = await client.query<{ max: number | null }>(`select max("${column}")::int as max from "${name}"`);
        const max = result.rows[0]?.max;
        await client.query("select setval(pg_get_serial_sequence($1, $2), $3::bigint, $4::boolean)",
          [`public.${name}`, column, max ?? 1, max != null]);
      }
    }
    await client.query("commit");
  } catch (e) {
    await client.query("rollback").catch(() => undefined);
    throw e;
  } finally {
    client.release();
  }

  console.log("Restore complete. Restart the application and sign in.");
  await pool.end();
}

main().catch(async (e) => {
  console.error("Restore failed:", e);
  await pool.end().catch(() => undefined);
  process.exit(1);
});
