import 'dotenv/config';
import { db, pool } from '@/db';
import { ensureDatabaseReady } from '@/db/bootstrap';
import { getProvenance, HTTPS_PROOF_KEY, readReleaseGates, releaseScope, verifyHttpsDeployment, writeReleaseProof } from '@/lib/releaseReadiness';

try {
  await ensureDatabaseReady();
  const { origin, scope } = releaseScope(await getProvenance(db));
  if (!origin || !scope) throw new Error('This server does not have a production-provisioned database, a stable HTTPS origin and a deployment ID.');
  const proof = await verifyHttpsDeployment(origin, scope);
  await writeReleaseProof(db, HTTPS_PROOF_KEY, proof);
  console.log(`Verified public HTTPS for ${origin}.`);
  const gates = await readReleaseGates(db);
  for (const gate of gates) console.log(`${gate.passed ? 'PASS' : 'REQUIRED'} · ${gate.label}: ${gate.detail}`);
  if (gates.some((gate) => !gate.passed)) process.exitCode = 2;
} catch (error) {
  console.error(error instanceof Error ? error.message : 'HTTPS verification failed.');
  process.exitCode = 1;
} finally {
  await pool.end();
}
