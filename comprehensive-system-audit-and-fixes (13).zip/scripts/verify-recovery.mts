import 'dotenv/config';
import { execFileSync } from 'node:child_process';
import { createHash, randomBytes } from 'node:crypto';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Pool } from 'pg';
import { db, pool } from '@/db';
import { createBackup, downloadOffsiteBackup, readBackupFile } from '@/lib/backupService';
import { backupStorageScope, getProvenance, releaseScope, RESTORE_PROOF_KEY, writeReleaseProof } from '@/lib/releaseReadiness';

// The production source is read only in the restore phase. A newly created,
// uniquely named scratch database is the ONLY target that may be written/dropped.
const configured = new URL(process.env.BPZ_RECOVERY_DATABASE_URL || 'postgresql://postgres:postgres@127.0.0.1:5432/bpz_recovery_test');
if (configured.pathname !== '/bpz_recovery_test' || !['postgres:', 'postgresql:'].includes(configured.protocol)) {
  throw new Error('The recovery URL must end in /bpz_recovery_test. A unique disposable database is created on that server.');
}
const source = new URL(process.env.DATABASE_URL ?? '');
const scratchName = `bpz_recovery_${randomBytes(8).toString('hex')}`;
const scratchUrl = new URL(configured);
scratchUrl.pathname = `/${scratchName}`;
if (source.pathname === scratchUrl.pathname) throw new Error('Source and recovery database must be different.');
const adminUrl = new URL(configured);
adminUrl.pathname = '/postgres';
const admin = new Pool({ connectionString: adminUrl.href, max: 1 });
const fromOffsite = process.argv.includes('--offsite');
const temp = await mkdtemp(join(tmpdir(), 'bpz-recovery-'));
let created = false;
let checked: { sha256: string; verifiedAt: string; tables: number; rows: number } | null = null;

const stable = (value: unknown): unknown => {
  if (Array.isArray(value)) return value.map(stable);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => [key, stable(item)]));
};
const fingerprint = (rows: readonly unknown[]) => {
  const normalized = JSON.parse(JSON.stringify(rows)) as unknown[];
  const hashes = normalized.map((row) => createHash('sha256').update(JSON.stringify(stable(row))).digest('hex')).sort();
  return createHash('sha256').update(hashes.join('\n')).digest('hex');
};

try {
  process.env.BPZ_BACKUP_DIR ||= '/tmp/bpz-recovery-verification';
  const backup = await createBackup();
  console.log(`Snapshot created: ${backup.tableCount} tables / ${backup.rowCount} rows · secondary storage ${backup.offsite}`);
  let file = backup.file;
  if (fromOffsite) {
    if (backup.offsite !== 'uploaded' || !backup.offsiteUri) throw new Error('The off-site upload did not succeed. No off-site restore can be verified.');
    file = join(temp, 'offsite-snapshot.json.gz');
    await downloadOffsiteBackup(backup.offsiteUri, file);
  }
  const digest = createHash('sha256').update(await readFile(file)).digest('hex');
  if (digest !== backup.sha256) throw new Error('Snapshot checksum mismatch; no restore was attempted.');
  const payload = await readBackupFile(file);
  await admin.query(`create database "${scratchName}"`);
  created = true;
  const env = { ...process.env, DATABASE_URL: scratchUrl.href, BPZ_BACKUP_SCHEDULE_ENABLED: 'false' };
  const tsx = ['node_modules/tsx/dist/cli.mjs'];
  execFileSync(process.execPath, [...tsx, '-e', 'import { ensureSchema } from "./src/db/bootstrap"; import { pool } from "./src/db"; void ensureSchema().catch((err) => { console.error(err instanceof Error ? err.name : "Schema failure"); process.exitCode = 1; }).finally(() => pool.end());'], { env, stdio: 'inherit', timeout: 120_000 });
  // An empty scratch target needs no --force override.
  execFileSync(process.execPath, [...tsx, 'scripts/restore.ts', file], { env, stdio: 'inherit', timeout: 600_000 });
  const restored = new Pool({ connectionString: scratchUrl.href });
  const names = Object.keys(payload.tables);
  let rows = 0;
  try {
    for (const table of names) {
      if (!/^[a-z_][a-z0-9_]*$/.test(table)) throw new Error('Invalid snapshot table identifier.');
      const result = await restored.query(`select * from "${table}"`);
      const expected = payload.tables[table];
      if (result.rows.length !== expected.length || fingerprint(result.rows) !== fingerprint(expected)) throw new Error(`Restored row content differs in ${table}.`);
      rows += result.rows.length;
    }
    checked = { sha256: digest, verifiedAt: new Date().toISOString(), tables: names.length, rows };
  } finally { await restored.end(); }
} catch (error) {
  console.error(error instanceof Error ? error.message : 'Recovery verification failed.');
  process.exitCode = 1;
} finally {
  try { if (created) await admin.query(`drop database "${scratchName}" with (force)`); }
  catch { console.error('The scratch database could not be removed. No go-live proof was saved.'); process.exitCode = 1; }
  await admin.end();
  await rm(temp, { recursive: true, force: true });
  try {
    if (checked && !process.exitCode) {
      console.log(`RECOVERY VERIFIED (${fromOffsite ? 'off-site download' : 'local snapshot'}): ${checked.tables} tables and ${checked.rows} rows matched by count and content.`);
      if (fromOffsite) {
        const { scope } = releaseScope(await getProvenance(db));
        const storage = backupStorageScope();
        if (scope && storage) {
          await writeReleaseProof(db, RESTORE_PROOF_KEY, { ...checked, scope, storage });
          console.log('Production off-site restore proof recorded.');
        } else console.log('Test-only restore. No production go-live proof was recorded.');
      }
    }
  } catch (error) { console.error(error instanceof Error ? error.message : 'Cannot record restore proof.'); process.exitCode = 1; }
  finally { await pool.end(); }
}
