import { and, eq, inArray, lte } from 'drizzle-orm';
import { db } from '@/db';
import { ensureDatabaseReady } from '@/db/bootstrap';
import { businessPartners, clients, journalLines, purchaseOrders, salesInvoices, tradeDocuments, tradePayments } from '@/db/schema';
import { authJson, getSessionUser } from '@/lib/auth';
import { isValidIsoDate } from '@/lib/journalValidation';
import { buildAccountStatement, samePartyName, type StatementSide } from '@/utils/accountStatement';
import type { ACDOCALine, PurchaseOrder, SalesInvoice } from '@/types/accounting';

export const dynamic = 'force-dynamic';

/** Owner-only, tenant-scoped, read-only statement based on posted journals. */
export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return authJson(req, { ok: false, error: 'Sign in to generate a statement.' }, { status: 401 });
    if (user.role !== 'owner' || user.status !== 'active') {
      return authJson(req, { ok: false, error: 'Only the firm owner can generate account statements.' }, { status: 403 });
    }
    const q = new URL(req.url).searchParams;
    const entityId = Number(q.get('entityId'));
    const kind = q.get('kind');
    const partyId = (q.get('partyId') || '').trim();
    const from = q.get('from') || '';
    const to = q.get('to') || '';
    if (!Number.isSafeInteger(entityId) || entityId <= 0 || !['client', 'customer', 'vendor'].includes(kind || '') || !partyId
      || !isValidIsoDate(from) || !isValidIsoDate(to) || from > to) {
      return authJson(req, { ok: false, error: 'Choose a valid entity, party and date range.' }, { status: 400 });
    }
    return await db.transaction(async (tx) => {
      const entity = (await tx.select().from(clients).where(eq(clients.id, entityId)).limit(1))[0];
      if (!entity) return authJson(req, { ok: false, error: 'The accounting workspace was not found.' }, { status: 404 });
      const side: StatementSide = kind === 'vendor' ? 'vendor' : 'customer';
      const partners = await tx.select().from(businessPartners).where(and(eq(businessPartners.clientId, entityId), eq(businessPartners.type, side === 'vendor' ? 'Vendor' : 'Customer')));
      let name = '';
      let code = '';
      let ids: string[] = [];
      let notice = '';
      if (kind === 'client') {
        // Client workspaces are independent legal books, not receivables owed to
        // the firm. A client statement always reads the FIRM's customer ledger.
        if (!entity.isParent) return authJson(req, { ok: false, error: 'Client billing statements must use the firm’s own workspace, not the client’s books.' }, { status: 400 });
        const clientId = Number(partyId);
        if (!Number.isSafeInteger(clientId) || clientId <= 0) return authJson(req, { ok: false, error: 'Choose a client workspace.' }, { status: 400 });
        const client = (await tx.select().from(clients).where(eq(clients.id, clientId)).limit(1))[0];
        if (!client || client.isParent) return authJson(req, { ok: false, error: 'Client workspace not found.' }, { status: 404 });
        name = client.name; code = client.code;
        const matched = partners.filter((p) => samePartyName(p.name, client.name));
        if (matched.length > 1) return authJson(req, { ok: false, error: 'More than one firm customer has this client name. Resolve the duplicate customer records before generating a client statement.' }, { status: 409 });
        if (matched[0]) ids = [matched[0].id, matched[0].sourceId];
        else notice = 'No customer master in the firm workspace exactly matches this client. Only unambiguously name-linked firm transactions are included; register a matching customer and post the firm’s invoices first.';
      } else {
        const partner = partners.find((p) => p.sourceId === partyId || p.id === partyId);
        if (!partner) return authJson(req, { ok: false, error: 'The selected partner does not exist in this workspace.' }, { status: 404 });
        name = partner.name; code = partner.code; ids = [partner.id, partner.sourceId];
        if (partners.filter((p) => samePartyName(p.name, name)).length > 1) {
          return authJson(req, { ok: false, error: 'Partners with the same name cannot be distinguished reliably in older transactions. Correct the duplicate names before generating this statement.' }, { status: 409 });
        }
      }
      const lines = await tx.select().from(journalLines).where(and(eq(journalLines.clientId, entityId), inArray(journalLines.accountNo, side === 'vendor' ? ['200000', '116000'] : ['110000', '225000']), lte(journalLines.date, to)));
      const documents = await tx.select().from(tradeDocuments).where(eq(tradeDocuments.clientId, entityId));
      const payments = await tx.select().from(tradePayments).where(eq(tradePayments.clientId, entityId));
      const invoices = side === 'customer' ? await tx.select().from(salesInvoices).where(eq(salesInvoices.clientId, entityId)) : [];
      const orders = side === 'vendor' ? await tx.select().from(purchaseOrders).where(eq(purchaseOrders.clientId, entityId)) : [];
      const statement = buildAccountStatement({
        side, party: { name, code, ids }, from, to, currency: entity.currency,
        lines: lines as unknown as ACDOCALine[], documents, payments,
        invoices: invoices as unknown as SalesInvoice[], orders: orders as unknown as PurchaseOrder[],
      });
      return authJson(req, { ok: true, entity: { id: entity.id, name: entity.name, code: entity.code, currency: entity.currency },
        party: { name, code, kind }, from, to, generatedAt: new Date().toISOString(), notice, ...statement });
    }, { isolationLevel: 'repeatable read', accessMode: 'read only' });
  } catch (error) {
    console.error('account statements: failed', error);
    return authJson(req, { ok: false, error: 'The statement could not be generated. Please retry.' }, { status: 503 });
  }
}
