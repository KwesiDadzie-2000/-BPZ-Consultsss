import { requireOwner } from "@/lib/auth";
import { authJson } from "@/lib/auth";
import { createApiKey, listApiKeys, revokeApiKey } from "@/lib/apiKeys";
import { ensureDatabaseReady } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

/** Owner-only API key management for the public developer API. */
export async function GET(req: Request) {
  await ensureDatabaseReady();
  const owner = await requireOwner(req);
  if (!owner) return authJson(req, { ok: false, error: "Owner access required." }, { status: 403 });
  const keys = (await listApiKeys()).map((k) => ({ ...k, keyHash: undefined }));
  return authJson(req, { ok: true, keys });
}

export async function POST(req: Request) {
  await ensureDatabaseReady();
  const owner = await requireOwner(req);
  if (!owner) return authJson(req, { ok: false, error: "Owner access required." }, { status: 403 });
  const body = await req.json().catch(() => null) as { name?: string; scope?: string; clientId?: number | null; makerLimit?: number } | null;
  const name = body?.name?.trim();
  const scope = body?.scope === "write" ? "write" : "read";
  if (!name) return authJson(req, { ok: false, error: "A key name is required." }, { status: 400 });
  // A machine credential's posting authority is explicit and defaults to ZERO:
  // a leaked key must not be able to move money just because it can authenticate.
  const limit = Number(body?.makerLimit ?? 0);
  if (!Number.isFinite(limit) || limit < 0) {
    return authJson(req, { ok: false, error: "makerLimit must be a non-negative number." }, { status: 400 });
  }
  const created = await createApiKey({ clientId: body?.clientId ?? null, name, scope, createdBy: owner.username, makerLimit: limit });
  return authJson(req, {
    ok: true, id: created.id, prefix: created.prefix, key: created.rawKey, makerLimit: limit,
    warning: limit > 0
      ? `Store this key now — shown once. It may post documents up to ${limit.toFixed(2)} in the entity currency.`
      : "Store this key now — shown once. It is read-capable only until you grant a posting limit.",
  });
}

export async function DELETE(req: Request) {
  await ensureDatabaseReady();
  const owner = await requireOwner(req);
  if (!owner) return authJson(req, { ok: false, error: "Owner access required." }, { status: 403 });
  const id = new URL(req.url).searchParams.get("id") || "";
  if (!id) return authJson(req, { ok: false, error: "Key id required." }, { status: 400 });
  const ok = await revokeApiKey(id);
  return authJson(req, { ok, error: ok ? undefined : "Key not found." }, { status: ok ? 200 : 404 });
}
