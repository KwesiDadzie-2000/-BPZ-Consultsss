import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { ssoIdentities, users } from "@/db/schema";
import { authJson, createSession, getSessionUser, requireOwner, sessionCookie } from "@/lib/auth";
import { federatedSignIn, ssoConfig, recordFederationEvent } from "@/lib/sso";

export const dynamic = "force-dynamic";

/**
 * Federated single sign-on.
 *
 * POST /api/auth/sso  { token }      → federated sign-in (issuer allow-listed,
 *                                     signature, audience and expiry enforced)
 * GET  /api/auth/sso                → owner: list linked identities + config
 * POST /api/auth/sso { link }        → owner: link a subject to a local user
 * POST /api/auth/sso { revoke|reinstate } → owner: SCIM-style deprovision
 */
export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
    const action = String(body?.action || "signin");

    if (action === "signin") {
      const token = String(body?.token || "");
      const result = await federatedSignIn(token);
      if (!result.ok) return authJson(req, { ok: false, error: result.error, code: result.code }, { status: 401 });
      const session = await createSession(result.userId);
      return authJson(req, { ok: true, token: session, username: result.username, provisioned: result.provisioned }, { status: 200 });
    }

    // Owner-only identity management.
    const owner = await requireOwner(req);
    if (!owner) return authJson(req, { ok: false, error: "Owner access required." }, { status: 403 });

    if (action === "link") {
      const issuer = String(body?.issuer || "").replace(/\/+$/, "");
      const subject = String(body?.subject || "");
      const userId = String(body?.userId || "");
      if (!issuer || !subject || !userId) return authJson(req, { ok: false, error: "issuer, subject and userId are required." }, { status: 400 });
      const target = (await db.select().from(users).where(eq(users.id, userId)).limit(1))[0]
        ?? (await db.select().from(users).where(eq(users.username, userId)).limit(1))[0];
      if (!target) return authJson(req, { ok: false, error: "Local user not found." }, { status: 404 });
      const existing = (await db.select().from(ssoIdentities).where(eq(ssoIdentities.subject, subject)))[0];
      if (existing && existing.issuer === issuer) return authJson(req, { ok: false, error: "That identity is already linked." }, { status: 409 });
      await db.insert(ssoIdentities).values({
        id: crypto.randomUUID(), issuer, subject, userId: target.id,
        email: (String(body?.email || target.email || "")).toLowerCase(), status: "active", createdBy: owner.username,
      }).onConflictDoNothing();
      await recordFederationEvent("IDENTITY_LINKED", `user ${target.username}`, { issuer, subject });
      return authJson(req, { ok: true, linked: { issuer, subject, username: target.username } });
    }

    if (action === "revoke" || action === "reinstate") {
      const id = String(body?.id || "");
      if (!id) return authJson(req, { ok: false, error: "Identity id is required." }, { status: 400 });
      const next = action === "revoke" ? "revoked" : "active";
      const rows = await db.update(ssoIdentities).set({ status: next }).where(eq(ssoIdentities.id, id)).returning({ id: ssoIdentities.id });
      if (!rows.length) return authJson(req, { ok: false, error: "Identity not found." }, { status: 404 });
      await recordFederationEvent(action === "revoke" ? "IDENTITY_REVOKED" : "IDENTITY_REINSTATED", id, { id });
      return authJson(req, { ok: true, status: next });
    }

    return authJson(req, { ok: false, error: `Unknown SSO action "${action}".` }, { status: 400 });
  } catch (error) {
    console.error("sso POST failed", error);
    return authJson(req, { ok: false, error: "SSO request failed." }, { status: 500 });
  }
}

export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
    const owner = await requireOwner(req);
    const cfg = ssoConfig();
    // The configuration summary is safe to surface; no secret material.
    const summary = {
      enabled: cfg.enabled,
      issuers: cfg.issuers,
      audience: cfg.audience ? "(configured)" : "",
      secretConfigured: Boolean(cfg.secret),
      provisioning: cfg.provisioning,
    };
    if (!owner) return authJson(req, { ok: true, sso: summary, links: [] });
    const links = await db.select().from(ssoIdentities);
    const usernames = await db.select({ id: users.id, username: users.username, email: users.email, status: users.status }).from(users);
    const byId = new Map(usernames.map((u) => [u.id, u]));
    return authJson(req, {
      ok: true,
      sso: summary,
      links: links.map((l) => ({ id: l.id, issuer: l.issuer, subject: l.subject, email: l.email, status: l.status, lastLoginAt: l.lastLoginAt, createdBy: l.createdBy, username: byId.get(l.userId)?.username ?? "(unlinked)" })),
    });
  } catch (error) {
    console.error("sso GET failed", error);
    return authJson(req, { ok: false, error: "SSO status unavailable." }, { status: 500 });
  }
}
