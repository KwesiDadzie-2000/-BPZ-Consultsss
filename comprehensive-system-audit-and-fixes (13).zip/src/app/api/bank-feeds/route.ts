import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { bankAccounts, journalLines, tradeBankStatements } from "@/db/schema";
import { authJson, getSessionUser } from "@/lib/auth";
import { MAX_STATEMENT_BYTES, matchStatementLines, parseStatementReport } from "@/utils/bankStatement";
import type { ACDOCALine } from "@/types/accounting";

export const dynamic = "force-dynamic";

/**
 * Automated bank feed: upload a statement (CSV/TSV/text) once, and the server
 * parses it, persists every line (idempotent per import batch), and auto-matches
 * against the posted ledger. Replaces browser-only imports that vanished on
 * refresh — the matched state now survives across devices and sessions.
 */
export async function POST(req: Request) {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Sign in required." }, { status: 401 });
  if (user.status !== "active" || user.role === "auditor") return authJson(req, { ok: false, error: "Read-only account." }, { status: 403 });

  const body = (await req.json().catch(() => null)) as {
    clientId?: number; bankAccountId?: number; content?: string; externalRef?: string; convention?: string; dateOrder?: string;
  } | null;
  const clientId = Number(body?.clientId);
  const bankAccountId = Number(body?.bankAccountId);
  const content = String(body?.content || "");
  if (!Number.isSafeInteger(clientId) || clientId <= 0) return authJson(req, { ok: false, error: "clientId required." }, { status: 400 });
  if (!Number.isSafeInteger(bankAccountId)) return authJson(req, { ok: false, error: "bankAccountId required." }, { status: 400 });
  if (!content.trim()) return authJson(req, { ok: false, error: "Statement content required." }, { status: 400 });
  if (content.length > MAX_STATEMENT_BYTES) return authJson(req, { ok: false, error: "Statement too large (max 5 MB)." }, { status: 413 });

  const account = (await db.select().from(bankAccounts).where(and(eq(bankAccounts.id, bankAccountId), eq(bankAccounts.clientId, clientId))).limit(1))[0];
  if (!account) return authJson(req, { ok: false, error: "Bank account not found in this entity." }, { status: 404 });

  const report = parseStatementReport(content, {
    convention: body?.convention === "debit-is-in" ? "debit-is-in" : "debit-is-out",
    dateOrder: body?.dateOrder === "month-first" ? "month-first" : "day-first",
  });
  if (!report.lines.length) {
    return authJson(req, { ok: false, error: "No usable statement lines. Expected columns like Date, Description/Details, Debit/Credit or Amount." }, { status: 422 });
  }

  const externalRef = (body?.externalRef || `stmt-${clientId}-${bankAccountId}-${report.lines[0]?.date ?? ""}-${report.lines.length}`).slice(0, 120);
  const gl = account.glAccount || "100000";
  const ledger = (await db.select().from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.accountNo, gl)))) as unknown as ACDOCALine[];
  const matches = matchStatementLines(report.lines, ledger, gl);
  const matchedCount = matches.filter((m) => m.matched).length;

  // Persist the batch idempotently; re-importing the same batch replaces it.
  const batch = externalRef;
  await db.delete(tradeBankStatements).where(and(eq(tradeBankStatements.clientId, clientId), eq(tradeBankStatements.bankAccountId, bankAccountId), eq(tradeBankStatements.importBatch, batch)));
  await db.insert(tradeBankStatements).values(report.lines.map((line, i) => ({
    id: crypto.randomUUID(), clientId, bankAccountId,
    statementDate: line.date, externalRef: line.reference || `${batch}:${i + 1}`,
    description: line.description || "Statement line",
    amount: Math.round((line.credit - line.debit) * 100) / 100, currency: account.currency, importBatch: batch,
    matchStatus: matches[i]?.matched ? "matched" : matches[i]?.ambiguous ? "ambiguous" : "unmatched",
  })));

  return authJson(req, {
    ok: true, batch, imported: report.lines.length, matched: matchedCount,
    unmatched: report.lines.length - matchedCount, skipped: report.skippedRows,
    totals: report.totals, warnings: report.warnings,
    matchRate: report.lines.length ? Math.round((matchedCount / report.lines.length) * 1000) / 10 : 0,
  });
}

/** Read the imported batches + match status for an account. */
export async function GET(req: Request) {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Sign in required." }, { status: 401 });
  const q = new URL(req.url).searchParams;
  const clientId = Number(q.get("clientId"));
  const bankAccountId = Number(q.get("bankAccountId"));
  const conditions = [Number.isSafeInteger(clientId) ? eq(tradeBankStatements.clientId, clientId) : undefined,
    Number.isSafeInteger(bankAccountId) ? eq(tradeBankStatements.bankAccountId, bankAccountId) : undefined].filter(Boolean) as never[];
  const rows = conditions.length ? await db.select().from(tradeBankStatements).where(and(...conditions)) : [];
  const batches = new Map<string, { batch: string; lines: number; matched: number }>();
  for (const r of rows) {
    const b = batches.get(r.importBatch) || { batch: r.importBatch, lines: 0, matched: 0 };
    b.lines += 1; if (r.matchStatus === "matched") b.matched += 1; batches.set(r.importBatch, b);
  }
  return authJson(req, { ok: true, batches: [...batches.values()], total: rows.length });
}
