import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import {
  approvalRequests,
  bankAccounts,
  businessPartners,
  chartAccounts,
  closedPeriods,
  clients,
  companyProfiles,
  disclosureNotes,
  employees,
  journalLines,
  payrollRecords,
  prepaymentRecords,
  prepaymentSchedules,
  purchaseOrders,
  salesInvoices,
  stockItems,
  stockMovements,
  fixedAssets,
  taxScheduleEntries,
  users,
  systemSettings,
  liveBooks,
} from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope, sanitizeUser } from "@/lib/auth";
import { eq, inArray } from "drizzle-orm";
import { sequential } from "@/lib/sequential";
import { resolveTreasuryBalances } from "@/lib/treasuryAuthority";
import { visiblePostingDirectory } from "@/lib/postingControls";
import { canAccessFamily, type WorkspaceFamily } from "@/lib/workspaceScope";
import { workspaceInvitationUrl } from "@/lib/workspaceLink";
import { maySeeSection } from "@/utils/access";
import type { ClientEntity } from "@/types/accounting";

export const dynamic = "force-dynamic";

/**
 * Returns the full workspace state for the authenticated user, tenant-scoped:
 * the owner receives every entity's books; other users receive only their own
 * entity's data (plus the firm-level chart of accounts and disclosure notes).
 */
export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    console.error("bootstrap: database unavailable", e);
    return authJson(req, { ok: false, error: "database-unavailable" }, { status: 503 });
  }

  let user;
  try {
    user = await getSessionUser(req);
  } catch (e) {
    // An infrastructure fault is NOT an expired session: answering 401 here is
    // what used to throw a signed-in user back to the login portal.
    console.error("bootstrap: session lookup failed", e);
    return authJson(req, { ok: false, error: "session-check-failed" }, { status: 503 });
  }
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });

  // The revision is valid only for the exact registers returned with it. A read
  // spanning concurrent commits can otherwise carry old registers under a new revision.
  try {
    return await db.transaction(async (tx) => {
      const firmWide = hasFirmWideScope(user);
      const clientId = user.clientId ?? null;

      const visibleClients = firmWide
        ? await tx.select().from(clients)
        : clientId === null
          ? []
          : await tx.select().from(clients).where(eq(clients.id, clientId));
      const visibleIds = visibleClients.map((c) => c.id);
      const bookCutovers = visibleIds.length ? await tx.select({ clientId: liveBooks.clientId, period: liveBooks.period })
        .from(liveBooks).where(inArray(liveBooks.clientId, visibleIds)) : [];
      const cutoffs = new Map(bookCutovers.map((r) => [r.clientId, r.period]));
      const wireClients = visibleClients.map((row) => ({ ...row, liveCutoverPeriod: cutoffs.get(row.id), loginUrl: workspaceInvitationUrl(row.code, process.env.BPZ_PUBLIC_ORIGIN) }));
      if (user.permissions?.parallelCloseReviewOnly) {
        return authJson(req, { ok: true, state: { clients: wireClients, users: [user], journalScope: 'all' } });
      }
      // Non-firm users read only their own entity at the database, not every tenant filtered in memory.
      const scopeIds = visibleIds.length ? visibleIds : [-1];
      // Firm-wide users load journals per entity (?entity=<id>) so a large practice
      // does not ship every client's ledger to the browser at sign-in. `entity=all`
      // (or no parameter, for older clients) returns every visible entity.
      const entityParam = new URL(req.url).searchParams.get("entity");
      const journalScope = firmWide && entityParam && entityParam !== "all" && visibleIds.includes(Number(entityParam)) ? [Number(entityParam)] : null;
      const scoped = <T extends { clientId: number | null }>(rows: T[]) =>
        firmWide ? rows : rows.filter((r) => r.clientId !== null && visibleIds.includes(r.clientId));

      const [
        allLines,
        allBanks,
        allPOs,
        allInvoices,
        allEmployees,
        allPartners,
        allPayroll,
        allApprovals,
        allClosed,
        allPrepayments,
        allPrepaymentSchedules,
        allTaxSchedules,
        allStockItems,
        allStockMovements,
        allFixedAssets,
      ] = await sequential([
        journalScope ? tx.select().from(journalLines).where(inArray(journalLines.clientId, journalScope)) : firmWide ? tx.select().from(journalLines) : tx.select().from(journalLines).where(inArray(journalLines.clientId, scopeIds)),
        firmWide ? tx.select().from(bankAccounts) : tx.select().from(bankAccounts).where(inArray(bankAccounts.clientId, scopeIds)),
        firmWide ? tx.select().from(purchaseOrders) : tx.select().from(purchaseOrders).where(inArray(purchaseOrders.clientId, scopeIds)),
        firmWide ? tx.select().from(salesInvoices) : tx.select().from(salesInvoices).where(inArray(salesInvoices.clientId, scopeIds)),
        firmWide ? tx.select().from(employees) : tx.select().from(employees).where(inArray(employees.clientId, scopeIds)),
        firmWide ? tx.select().from(businessPartners) : tx.select().from(businessPartners).where(inArray(businessPartners.clientId, scopeIds)),
        firmWide ? tx.select().from(payrollRecords) : tx.select().from(payrollRecords).where(inArray(payrollRecords.clientId, scopeIds)),
        firmWide ? tx.select().from(approvalRequests) : tx.select().from(approvalRequests).where(inArray(approvalRequests.clientId, scopeIds)),
        firmWide ? tx.select().from(closedPeriods) : tx.select().from(closedPeriods).where(inArray(closedPeriods.clientId, scopeIds)),
        firmWide ? tx.select().from(prepaymentRecords) : tx.select().from(prepaymentRecords).where(inArray(prepaymentRecords.clientId, scopeIds)),
        firmWide ? tx.select().from(prepaymentSchedules) : tx.select().from(prepaymentSchedules).where(inArray(prepaymentSchedules.clientId, scopeIds)),
        firmWide ? tx.select().from(taxScheduleEntries) : tx.select().from(taxScheduleEntries).where(inArray(taxScheduleEntries.clientId, scopeIds)),
        firmWide ? tx.select().from(stockItems) : tx.select().from(stockItems).where(inArray(stockItems.clientId, scopeIds)),
        firmWide ? tx.select().from(stockMovements) : tx.select().from(stockMovements).where(inArray(stockMovements.clientId, scopeIds)),
        firmWide ? tx.select().from(fixedAssets) : tx.select().from(fixedAssets).where(inArray(fixedAssets.clientId, scopeIds)),
      ]);

      // Treasury balances come from the ledger, never from a stored browser figure.
      const authoritativeBanks = await resolveTreasuryBalances(tx, allBanks, visibleClients);

      const profiles = firmWide ? await tx.select().from(companyProfiles) : await tx.select().from(companyProfiles).where(inArray(companyProfiles.clientId, scopeIds));
      const allCoa = await tx.select().from(chartAccounts);
      // Chart of accounts: firm master (clientId null) plus the user's own entity customs.
      const coa = firmWide ? allCoa : allCoa.filter((a) => a.clientId === null || a.clientId === clientId);
      const notes = await tx.select().from(disclosureNotes);
      // The full administration directory remains owner-only. Every posting user,
      // however, needs the maker/checker identities relevant to their own books;
      // returning [] made every newly onboarded client fail local identity validation.
      const revisionSetting = (await tx.select({ value: systemSettings.value }).from(systemSettings)
        .where(eq(systemSettings.key, 'workspace_state_revision')).limit(1))[0];
      const stateRevision = Number((revisionSetting?.value as { revision?: number } | undefined)?.revision ?? 0);
      const userDirectory = (await tx.select().from(users)).map(sanitizeUser);
      const allUsers = visiblePostingDirectory(userDirectory, user).map((entry) =>
        firmWide || entry.username === user.username ? entry : {
          ...entry,
          email: '', // not needed to validate a maker or checker
          mfaEnabled: false,
          permissions: {
            canPostJournals: entry.permissions?.canPostJournals !== false,
            canApprovePayments: false, canRunPayroll: false, canClosePeriod: false, canModifyCOA: false,
          },
        });
      const entity = !firmWide ? visibleClients[0] as ClientEntity | undefined : undefined;
      const permitted = (family: WorkspaceFamily) => firmWide || canAccessFamily(user, entity ?? null, family, 'read');

      return authJson(req, {
        ok: true,
        state: {
          stateRevision,
          clients: wireClients,
          // A financial dashboard still needs aggregate journal amounts. Payroll
          // narration is masked for users without the payroll module.
          journalLines: scoped(allLines).map((line) =>
            !firmWide && !permitted('payrollRecords') && line.module === 'HR'
              ? { ...line, description: 'Payroll posting (details restricted)', accountName: line.accountNo }
              : line),
          journalScope: journalScope ? journalScope[0] : "all",
          bankAccounts: permitted('bankAccounts') ? scoped(authoritativeBanks) : [],
          purchaseOrders: permitted('purchaseOrders') ? scoped(allPOs) : [],
          salesInvoices: permitted('salesInvoices') ? scoped(allInvoices) : [],
          employees: permitted('employees') ? scoped(allEmployees) : [],
          businessPartners: permitted('businessPartners') ? scoped(allPartners).map(({ sourceId, id, ...partner }) => ({ ...partner, id: sourceId ?? id })) : [],
          payrollRecords: permitted('payrollRecords') ? scoped(allPayroll).map((r) => r.record) : [],
          approvalRequests: permitted('approvalRequests') ? scoped(allApprovals) : [],
          prepaymentRecords: permitted('prepaymentRecords') ? scoped(allPrepayments).map((r) => r.record) : [],
          prepaymentSchedules: permitted('prepaymentSchedules') ? scoped(allPrepaymentSchedules).map((r) => r.line) : [],
          taxScheduleEntries: permitted('taxScheduleEntries') ? scoped(allTaxSchedules).map((t) => ({ ...t, sourceKey: t.sourceKey ?? undefined, note: t.note ?? undefined })) : [],
          stockItems: permitted('stockItems') ? scoped(allStockItems) : [],
          stockMovements: permitted('stockMovements') ? scoped(allStockMovements) : [],
          fixedAssets: permitted('fixedAssets') ? scoped(allFixedAssets) : [],
          companyProfiles: Object.fromEntries(
            profiles
              .filter((p) => firmWide || (p.clientId === clientId && entity && (
                maySeeSection(user, entity, 'company_profile') || maySeeSection(user, entity, 'ifrs_statements')
              )))
              .map((p) => [p.clientId, p])
          ),
          chartOfAccounts: coa,
          disclosureNotes: firmWide || (entity && maySeeSection(user, entity, 'disclosures')) ? notes : [],
          closedPeriods: scoped(allClosed).map((c) => ({ clientId: c.clientId, period: c.period })),
          users: allUsers,
        },
      });
    }, { isolationLevel: "repeatable read", accessMode: "read only" });
  } catch (error) {
    console.error('bootstrap: snapshot could not be read', error instanceof Error ? error.name : 'UnknownError');
    return authJson(req, { ok: false, error: 'The workspace snapshot is temporarily unavailable.' }, { status: 503 });
  }
}
