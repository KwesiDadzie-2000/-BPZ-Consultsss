import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { einvoiceQueue } from "@/db/schema";
import { authJson, getSessionUser } from "@/lib/auth";
import { dispatchEinvoiceQueue, einvoiceEnabled, enqueueEinvoice } from "@/lib/einvoice";

export const dynamic = "force-dynamic";

/** E-invoice queue: enqueue an issued invoice, read status, drive the dispatcher. */
export async function GET(req: Request) {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Sign in required." }, { status: 401 });
  const clientId = Number(new URL(req.url).searchParams.get("clientId"));
  if (!Number.isSafeInteger(clientId)) return authJson(req, { ok: false, error: "clientId required." }, { status: 400 });
  if (user.clientId != null && user.clientId !== clientId && user.role !== "owner") return authJson(req, { ok: false, error: "Cross-entity access forbidden." }, { status: 403 });
  const rows = await db.select().from(einvoiceQueue).where(eq(einvoiceQueue.clientId, clientId));
  return authJson(req, {
    ok: true, enabled: einvoiceEnabled(), count: rows.length,
    queued: rows.filter((r) => r.status === "queued").length,
    accepted: rows.filter((r) => r.status === "accepted").length,
    failed: rows.filter((r) => r.status === "failed").length,
    records: rows.slice(0, 100),
  });
}

export async function POST(req: Request) {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Sign in required." }, { status: 401 });
  if (user.status !== "active" || user.role === "auditor") return authJson(req, { ok: false, error: "Read-only." }, { status: 403 });
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  const action = String(body?.action || "enqueue");
  if (action === "dispatch") {
    if (user.role !== "owner") return authJson(req, { ok: false, error: "Only the owner may dispatch the e-invoice queue." }, { status: 403 });
    const result = await dispatchEinvoiceQueue();
    return authJson(req, { ok: true, ...result });
  }
  const clientId = Number(body?.clientId);
  if (!Number.isSafeInteger(clientId)) return authJson(req, { ok: false, error: "clientId required." }, { status: 400 });
  if (user.clientId != null && user.clientId !== clientId && user.role !== "owner") return authJson(req, { ok: false, error: "Cross-entity access forbidden." }, { status: 403 });
  const invoiceNo = String(body?.invoiceNo || "");
  const invoiceId = String(body?.invoiceId || "");
  if (!invoiceNo || !invoiceId) return authJson(req, { ok: false, error: "invoiceNo and invoiceId required." }, { status: 400 });
  await enqueueEinvoice({ clientId, invoiceNo, invoiceId, payload: (body?.payload as Record<string, unknown>) ?? {} });
  return authJson(req, { ok: true, queued: true, enabled: einvoiceEnabled() });
}
