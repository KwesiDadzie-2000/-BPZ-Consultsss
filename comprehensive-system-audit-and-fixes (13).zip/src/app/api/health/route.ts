import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import { sql } from "drizzle-orm";
import { getProvenance, releaseScope } from "@/lib/releaseReadiness";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    await ensureDatabaseReady();
    const { scope } = process.env.BPZ_BOOTSTRAP_MODE === "production" ? releaseScope(await getProvenance(db)) : { scope: null };
    return Response.json({ ok: true }, { headers: { "cache-control": "no-store", ...(scope ? { "x-bpz-deployment": scope } : {}) } });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
