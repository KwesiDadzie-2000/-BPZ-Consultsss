import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { bankAccounts, businessPartners, chartAccounts, clients, closedPeriods, journalHeaders, journalLines, postingEvents, systemSettings } from "@/db/schema";
import { authJson, getSessionUser } from "@/lib/auth";
import { isValidIsoDate, validateJournalLines } from "@/lib/journalValidation";
import { enforcePostingControls } from "@/lib/postingGate";
import { buildJournalHeader, buildPostingEvent } from "@/lib/journalPosting";
import {
  buildLedgerJournal, buildOpeningJournal, MAX_MIGRATION_BYTES,
  parseBanks, parseLedgerHistory, parseOpeningBalances, parsePartners, type MigrationPreview,
} from "@/lib/migration";
import type { ACDOCALine } from "@/types/accounting";

export const dynamic = "force-dynamic";

/**
 * Migration endpoint: import balances and ledger history from another system.
 * `?preview=1` validates and reports without writing anything. The full
 * write path runs in ONE transaction — validate → post journals → write
 * registers → bump workspace revision → audit — so a half-finished migration
 * can never land in the books.
 */
async function bumpRevision(tx: Parameters<Parameters<typeof db.transaction>[0]>[0]) {
  const row = (await tx.select({ value: systemSettings.value }).from(systemSettings).where(eq(systemSettings.key, "workspace_state_revision")).limit(1))[0];
  const next = Number((row?.value as { revision?: number } | undefined)?.revision ?? 0) + 1;
  await tx.insert(systemSettings).values({ key: "workspace_state_revision", value: { revision: next } })
    .onConflictDoUpdate({ target: systemSettings.key, set: { value: { revision: next }, updatedAt: new Date() } });
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return authJson(req, { ok: false, error: "Sign in required." }, { status: 401 });
    if (user.status !== "active" || user.role === "auditor") return authJson(req, { ok: false, error: "Read-only account." }, { status: 403 });

    const body = (await req.text());
    if (body.length > MAX_MIGRATION_BYTES) return authJson(req, { ok: false, error: "Migration file too large (max 5 MB)." }, { status: 413 });
    const parsed = JSON.parse(body) as { kind?: string; clientId?: number; content?: string; date?: string; mode?: string };
    const kind = String(parsed.kind || "");
    const clientId = Number(parsed.clientId);
    const content = String(parsed.content || "");
    const previewOnly = parsed.mode === "preview";

    if (!["opening", "ledger", "partners", "banks"].includes(kind)) return authJson(req, { ok: false, error: "kind must be opening, ledger, partners or banks." }, { status: 400 });
    if (!Number.isSafeInteger(clientId) || clientId <= 0) return authJson(req, { ok: false, error: "clientId required." }, { status: 400 });
    if (!content.trim()) return authJson(req, { ok: false, error: "File content required." }, { status: 400 });
    if (user.clientId != null && user.clientId !== clientId && user.role !== "owner") return authJson(req, { ok: false, error: "Cross-entity migration forbidden." }, { status: 403 });

    const entity = (await db.select().from(clients).where(eq(clients.id, clientId)).limit(1))[0];
    if (!entity) return authJson(req, { ok: false, error: "Entity not found." }, { status: 404 });
    const currency = entity.currency || "GHS";

    // --- Preview: validate only, never write ---
    if (previewOnly) {
      const preview: MigrationPreview = kind === "opening" ? parseOpeningBalances(content, currency)
        : kind === "ledger" ? parseLedgerHistory(content, currency)
        : kind === "partners" ? parsePartners(content)
        : parseBanks(content);
      return authJson(req, { ok: preview.ok, preview });
    }

    // --- Commit: one transaction, validate everything first ---
    return await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(4027331)`);
      const coa = await tx.select().from(chartAccounts);
      const activeAccounts = new Set(coa.filter((a) => a.clientId === null || a.clientId === clientId).filter((a) => a.active).map((a) => a.accountNo));

      if (kind === "opening" || kind === "ledger") {
        const built = kind === "opening"
          ? buildOpeningJournal(content, currency, clientId, isValidIsoDate(parsed.date) ? (parsed.date as string) : `${new Date().getFullYear()}-01-01`, user.username)
          : buildLedgerJournal(content, currency, clientId, user.username);
        if (!built.ok) return authJson(req, { ok: false, preview: built }, { status: 422 });
        const lines = built.lines;
        // THE GATE. Migration must not be a way around a closed period: a client
        // whose March is locked cannot have March history imported afterwards.
        // An owner performing a cut-over opens the target period explicitly.
        const gateError = await enforcePostingControls(tx, {
          actor: { username: user.username, makerLimit: user.makerLimit, canCheck: user.canCheck },
          lines,
          sessionUser: user,
        });
        if (gateError) return authJson(req, { ok: false, error: gateError }, { status: 409 });
        const validation = validateJournalLines(lines, {
          allowedClientIds: [clientId],
          closedPeriodKeys: new Set((await tx.select({ clientId: closedPeriods.clientId, period: closedPeriods.period })
            .from(closedPeriods).where(eq(closedPeriods.clientId, clientId))).map((row) => `${row.clientId}:${row.period}`)),
          coaAccountNos: activeAccounts, isAccountPostable: (no) => activeAccounts.has(no),
        });
        if (validation) return authJson(req, { ok: false, error: validation }, { status: 409 });

        // Refuse a repeat import CLEANLY. The importer derives deterministic ids
        // and document numbers, so re-running the same file used to hit the
        // journal_lines primary key and surface as an opaque HTTP 500. A posted
        // document is immutable evidence: the correct response is a 409 naming
        // the document and telling the user to reverse it first.
        const docs = [...new Set(lines.map((l) => l.docNo))];
        const alreadyPosted = docs.length
          ? await tx.select({ docNo: journalLines.docNo }).from(journalLines)
            .where(and(eq(journalLines.clientId, clientId), inArray(journalLines.docNo, docs)))
          : [];
        if (alreadyPosted.length) {
          const which = [...new Set(alreadyPosted.map((row) => row.docNo))].slice(0, 5).join(', ');
          return authJson(req, {
            ok: false,
            error: `These documents are already posted and cannot be imported twice: ${which}${alreadyPosted.length > 5 ? ' …' : ''}. Posted journals are immutable — reverse the original first, then import a corrected file.`,
          }, { status: 409 });
        }
        await tx.insert(journalLines).values(lines.map((line) => ({
          id: line.id, docNo: line.docNo, period: line.period, date: line.date, module: line.module, docType: line.docType,
          accountNo: line.accountNo, accountName: line.accountName, costCenter: line.costCenter ?? null,
          debit: line.debit, credit: line.credit, currency: line.currency, description: line.description,
          createdBy: line.createdBy, checkedBy: line.checkedBy ?? null, isReversed: false,
          reference: line.reference ?? null, clientId: line.clientId,
        })));
        for (const docNo of docs) {
          const group = lines.filter((l) => l.docNo === docNo);
          await tx.insert(journalHeaders).values(buildJournalHeader(group as ACDOCALine[])).onConflictDoNothing();
          await tx.insert(postingEvents).values(buildPostingEvent(group as ACDOCALine[], user.username)).onConflictDoNothing();
        }
        await tx.insert(systemSettings).values({ key: "migration_log", value: { kind, clientId, rows: lines.length, docs: docs.length, by: user.username, at: new Date().toISOString() } })
          .onConflictDoUpdate({ target: systemSettings.key, set: { value: { kind, clientId, rows: lines.length, docs: docs.length, by: user.username, at: new Date().toISOString() } } });
        await bumpRevision(tx);
        return authJson(req, { ok: true, migrated: lines.length, documents: docs.length, kind });
      }

      if (kind === "partners") {
        const preview = parsePartners(content);
        if (!preview.ok) return authJson(req, { ok: false, preview }, { status: 422 });
        // Re-read rows for insertion (preview validated shape and balances).
        const rows = content.replace(/^\uFEFF/, "").split(/\r\n|\r|\n/).filter((l) => l.trim());
        const header = rows[0].toLowerCase().replace(/[^a-z0-9,;\t]/g, "").split(/[,;\t]/);
        const find = (...names: string[]) => names.map((n) => header.indexOf(n)).find((i) => i >= 0) ?? -1;
        const iCode = find("code", "partnercode", "account");
        const iName = find("name", "partnername", "customer", "vendor", "supplier");
        const iType = find("type", "category", "kind");
        const iLimit = find("creditlimit", "limit");
        const iTerms = find("credittermsdays", "terms", "creditterms", "days");
        const iTin = find("tin", "taxid", "vat");
        const iEmail = find("email");
        const iPhone = find("phone", "telephone", "mobile");
        const existingRows = await tx.select({ code: businessPartners.code }).from(businessPartners).where(eq(businessPartners.clientId, clientId));
        const existingCodes = new Set(existingRows.map((row) => row.code));
        let inserted = 0;
        let skipped = 0;
        for (let r = 1; r < rows.length; r += 1) {
          const cells = rows[r].split(/[,;\t]/).map((c) => c.replace(/^"|"$/g, "").trim());
          const code = (cells[iCode] || "").toUpperCase();
          const name = cells[iName] || "";
          const type = (cells[iType] || "").toLowerCase().startsWith("v") ? "Vendor" : "Customer";
          // Already in this entity: skip and SAY SO. Reporting a write that did
          // not happen is a silent lie — the user must know nothing changed.
          if (existingCodes.has(code)) { skipped += 1; continue; }
          const partnerId = `mig-${clientId}-${code}`;
          await tx.insert(businessPartners).values({
            id: partnerId, sourceId: partnerId, clientId, code, name, type,
            tin: iTin >= 0 ? cells[iTin] || "" : "", email: iEmail >= 0 ? cells[iEmail] || "" : "",
            phone: iPhone >= 0 ? cells[iPhone] || "" : "", address: "", currency,
            isVatWithholdingAgent: false, isCstApplicable: false, isTourismLevyApplicable: false,
            creditLimit: iLimit >= 0 && Number(cells[iLimit]) > 0 ? Number(cells[iLimit]) : null,
            creditTermsDays: iTerms >= 0 ? Number(cells[iTerms]) || 0 : 0,
            paymentTerms: iTerms >= 0 ? `Net ${Number(cells[iTerms]) || 0} days` : "",
            creditStatus: "Active", openingBalance: null,
          }).onConflictDoNothing();
          existingCodes.add(code);
          inserted += 1;
        }
        await bumpRevision(tx);
        return authJson(req, { ok: true, migrated: inserted, skipped, kind: "partners",
          note: skipped ? `${skipped} partner(s) already existed in this entity and were left unchanged.` : undefined });
      }

      // banks
      const preview = parseBanks(content);
      if (!preview.ok) return authJson(req, { ok: false, preview }, { status: 422 });
      const rows = content.replace(/^\uFEFF/, "").split(/\r\n|\r|\n/).filter((l) => l.trim());
      const header = rows[0].toLowerCase().replace(/[^a-z0-9,;\t]/g, "").split(/[,;\t]/);
      const find = (...names: string[]) => names.map((n) => header.indexOf(n)).find((i) => i >= 0) ?? -1;
      const iCode = find("code", "bankcode");
      const iName = find("name", "accountname", "account");
      const iBank = find("bank", "bankname");
      const iNo = find("accountno", "number");
      const iGl = find("gl", "glaccount");
      let inserted = 0;
      const existing = await tx.select().from(bankAccounts).where(eq(bankAccounts.clientId, clientId));
      // One treasury record per (GL, currency): the ledger derives that GL's
      // balance onto a single record. A second record on the same GL would be
      // unattributable and would also duplicate the treasury position.
      const takenGl = new Set(existing.map((row) => `${row.glAccount || ""}:${row.currency.toUpperCase()}`));
      const takenCode = new Set(existing.map((row) => row.code.toUpperCase()));
      let nextId = existing.reduce((max, row) => Math.max(max, row.id), 0) + 1;
      let skipped = 0;
      for (let r = 1; r < rows.length; r += 1) {
        const cells = rows[r].split(/[,;\t]/).map((c) => c.replace(/^"|"$/g, "").trim());
        const gl = (cells[iGl] || "").trim();
        if (!/^10\d{4}$/.test(gl)) continue;
        const key = `${gl}:${currency.toUpperCase()}`;
        const code = (cells[iCode] || `BNK-${r}`).toUpperCase();
        if (takenGl.has(key) || takenCode.has(code)) { skipped += 1; continue; }
        await tx.insert(bankAccounts).values({
          id: nextId++, clientId, code,
          name: cells[iName] || `Account ${r}`, bankName: iBank >= 0 ? cells[iBank] || "" : "",
          accountNo: iNo >= 0 ? cells[iNo] || "" : "", currency, balance: 0, kind: "bank", glAccount: gl,
        });
        takenGl.add(key); takenCode.add(code);
        inserted += 1;
      }
      await bumpRevision(tx);
      return authJson(req, { ok: true, migrated: inserted, skipped, kind: "banks",
        note: skipped ? `${skipped} account(s) already exist for that GL/currency (or code) and were left unchanged — a treasury GL can only back one record.` : undefined });
    });
  } catch (error) {
    const code = (error as { code?: string })?.code;
    console.error("migrate POST failed", error);
    if (code === "23505") {
      return authJson(req, { ok: false, error: "A record in this file already exists (duplicate document or code). Posted journals are immutable: reverse the original before re-importing." }, { status: 409 });
    }
    if (code === "23503") {
      return authJson(req, { ok: false, error: "A referenced entity or account does not exist. Check the file's client and GL accounts." }, { status: 409 });
    }
    return authJson(req, { ok: false, error: "Migration failed. Nothing was committed." }, { status: 500 });
  }
}
