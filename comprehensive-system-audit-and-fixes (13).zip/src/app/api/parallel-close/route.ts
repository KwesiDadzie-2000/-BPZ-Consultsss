import { ensureDatabaseReady } from '@/db/bootstrap';
import { authJson, getSessionUser } from '@/lib/auth';
import { readJsonBody, RequestBodyError } from '@/lib/http';
import { changeClose, CloseError, getClose, getCloseFile, validateCloseScope } from '@/lib/parallelCloseService';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

async function handle(req: Request, mutate: boolean) {
  try {
    await ensureDatabaseReady();
    const actor = await getSessionUser(req);
    if (!actor) return authJson(req, { ok: false, error: 'Sign in to review this workspace.' }, { status: 401 });
    const params = new URL(req.url).searchParams;
    const { id, period } = validateCloseScope(params.get('clientId'), params.get('period'));
    const file = params.get('file');
    if (!mutate && file) {
      if (!/^[a-f0-9-]{36}$/i.test(file)) throw new CloseError('Invalid evidence identifier.');
      const row = await getCloseFile(actor, id, period, file);
      return new Response(new Uint8Array(row.bytes), { headers: {
        'content-disposition': `attachment; filename="${row.name.replace(/[^a-zA-Z0-9._ -]/g, '_')}"`,
        'content-type': 'application/octet-stream', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff',
      } });
    }
    if (mutate) await changeClose(actor, id, period, await readJsonBody(req, 3 * 1024 * 1024));
    return authJson(req, { ok: true, close: await getClose(actor, id, period) });
  } catch (error) {
    if (error instanceof CloseError || error instanceof RequestBodyError) return authJson(req, { ok: false, error: error.message }, { status: error.status });
    console.error('parallel close:', error instanceof Error ? error.name : 'unavailable');
    return authJson(req, { ok: false, error: 'Parallel Close could not be loaded or saved. Reload the packet before retrying.' }, { status: 503 });
  }
}
export const GET = (req: Request) => handle(req, false);
export const POST = (req: Request) => handle(req, true);
