import { getSessionUser } from "@/lib/auth";
import { authJson } from "@/lib/auth";
import { canAccessFamily } from "@/lib/workspaceScope";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { postSalesInvoice, registerPartner, RegisterError } from "@/lib/registerService";
import { clients } from "@/db/schema";
import { db } from "@/db";

export const dynamic = "force-dynamic";

/**
 * Server-authoritative register writes for the desks. Replaces the legacy
 * browser-authoritative path for the highest-risk operational registers:
 * partner registration and sales-invoice issue. The journal and the register
 * row commit in one transaction; the browser snapshot can never fabricate them.
 */
export async function POST(req: Request) {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Sign in required." }, { status: 401 });
  if (user.status !== "active" || user.role === "auditor") return authJson(req, { ok: false, error: "Read-only account." }, { status: 403 });
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  const action = String(body?.action || "");
  const clientId = Number(body?.clientId);
  if (!Number.isSafeInteger(clientId) || clientId <= 0) return authJson(req, { ok: false, error: "clientId required." }, { status: 400 });
  const entity = (await db.select().from(clients)).find((c) => c.id === clientId);
  if (!entity) return authJson(req, { ok: false, error: "Unknown entity." }, { status: 404 });

  try {
    if (action === "register_partner") {
      const entity2 = entity as never;
      if (!canAccessFamily(user, entity2, "businessPartners", "write")) return authJson(req, { ok: false, error: "No permission to register partners in this entity." }, { status: 403 });
      const result = await registerPartner({
        clientId, actor: user.username, code: String(body?.code || ""), name: String(body?.name || ""),
        type: body?.type === "Vendor" ? "Vendor" : "Customer",
        tin: body?.tin as string | undefined, email: body?.email as string | undefined,
        phone: body?.phone as string | undefined, address: body?.address as string | undefined,
        currency: body?.currency as string | undefined,
        creditLimit: body?.creditLimit != null ? Number(body.creditLimit) : undefined,
        creditTermsDays: body?.creditTermsDays != null ? Number(body.creditTermsDays) : undefined,
        paymentTerms: body?.paymentTerms as string | undefined,
        creditStatus: body?.creditStatus === "On Hold" || body?.creditStatus === "Blocked" ? body.creditStatus : "Active",
        openingBalance: body?.openingBalance != null ? Number(body.openingBalance) : undefined,
      });
      return authJson(req, { ok: true, partner: result });
    }
    if (action === "post_sales_invoice") {
      const entity2 = entity as never;
      if (!canAccessFamily(user, entity2, "salesInvoices", "write")) return authJson(req, { ok: false, error: "No permission to post invoices in this entity." }, { status: 403 });
      const result = await postSalesInvoice({
        clientId, actor: user.username, sessionUser: user, customerName: String(body?.customerName || ""),
        revenueStream: String(body?.revenueStream || "Sale"),
        revenueAccount: body?.revenueAccount ? String(body.revenueAccount) : undefined,
        date: String(body?.date || new Date().toISOString().slice(0, 10)),
        netRevenue: Number(body?.netRevenue), vatOutput: body?.vatOutput != null ? Number(body.vatOutput) : 0,
        currency: String(body?.currency || entity.currency || "GHS").toUpperCase(),
      });
      return authJson(req, { ok: true, invoice: result });
    }
    return authJson(req, { ok: false, error: `Unknown register action "${action}".` }, { status: 400 });
  } catch (e) {
    if (e instanceof RegisterError) return authJson(req, { ok: false, error: e.message }, { status: e.status });
    console.error("registers POST failed", e);
    return authJson(req, { ok: false, error: "Register write failed." }, { status: 500 });
  }
}
