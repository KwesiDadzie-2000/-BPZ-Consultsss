import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { salesInvoices } from "@/db/schema";
import { json, requireApiKey } from "@/lib/apiAuth";
import { postSalesInvoice, RegisterError } from "@/lib/registerService";

export const dynamic = "force-dynamic";

/** Public v1 invoices: list open/posted sales invoices for the key's entity. */
export async function GET(req: Request) {
  await ensureDatabaseReady();
  const auth = await requireApiKey(req);
  if ("response" in auth) return auth.response;
  const conditions = auth.ctx.clientId != null ? [eq(salesInvoices.clientId, auth.ctx.clientId)] : [];
  const rows = await db.select().from(salesInvoices).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(salesInvoices.date)).limit(500);
  return json({ ok: true, count: rows.length, invoices: rows });
}

/** Public v1 invoices: create and post (write-scoped keys only, server-authoritative). */
export async function POST(req: Request) {
  await ensureDatabaseReady();
  const auth = await requireApiKey(req, true);
  if ("response" in auth) return auth.response;
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  const clientId = auth.ctx.clientId ?? Number(body?.clientId);
  if (!Number.isSafeInteger(clientId) || clientId <= 0) return json({ ok: false, error: "clientId required." }, 400);
  try {
    const result = await postSalesInvoice({
      // A machine credential posts as itself, never as a human — and it is
      // subject to the SAME period lock and posting-limit gate as a person.
      clientId, actor: `api:${auth.ctx.name}`, serviceCredential: auth.ctx.keyId, serviceMakerLimit: auth.ctx.makerLimit,
      customerName: String(body?.customerName || ""), revenueStream: String(body?.description || body?.revenueStream || "API sale"),
      revenueAccount: body?.revenueAccount ? String(body.revenueAccount) : undefined,
      date: String(body?.date || new Date().toISOString().slice(0, 10)),
      netRevenue: Number(body?.netRevenue ?? body?.amount),
      vatOutput: body?.vatOutput != null ? Number(body.vatOutput) : 0,
      currency: String(body?.currency || "GHS").toUpperCase(),
    });
    return json({ ok: true, invoice: result }, 201);
  } catch (e) {
    if (e instanceof RegisterError) return json({ ok: false, error: e.message }, e.status);
    throw e;
  }
}
