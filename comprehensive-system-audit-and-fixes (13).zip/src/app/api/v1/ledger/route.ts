import { and, desc, eq, gte, lte } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { journalLines } from "@/db/schema";
import { json, requireApiKey } from "@/lib/apiAuth";

export const dynamic = "force-dynamic";

/** Public v1 ledger: read posted journal lines, scoped to the key's entity. */
export async function GET(req: Request) {
  await ensureDatabaseReady();
  const auth = await requireApiKey(req);
  if ("response" in auth) return auth.response;
  const q = new URL(req.url).searchParams;
  const from = q.get("from") || "0000-01-01";
  const to = q.get("to") || "9999-12-31";
  const conditions = [gte(journalLines.date, from), lte(journalLines.date, to)];
  if (auth.ctx.clientId != null) conditions.push(eq(journalLines.clientId, auth.ctx.clientId));
  const rows = await db.select().from(journalLines).where(and(...conditions)).orderBy(desc(journalLines.date)).limit(1000);
  return json({
    ok: true, scope: auth.ctx.clientId == null ? "firm" : `client:${auth.ctx.clientId}`,
    from, to, count: rows.length,
    lines: rows.map((l) => ({ docNo: l.docNo, date: l.date, account: l.accountNo, accountName: l.accountName, debit: l.debit, credit: l.credit, currency: l.currency, description: l.description })),
  });
}
