import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { businessPartners, journalLines } from "@/db/schema";
import { json, requireApiKey } from "@/lib/apiAuth";
import { buildAccountStatement } from "@/utils/accountStatement";
import type { ACDOCALine } from "@/types/accounting";

export const dynamic = "force-dynamic";

/**
 * Public v1 statements of account. `?partyId=<id>&side=customer|vendor&from&to`.
 * Read-only, journal-derived, scoped to the key's entity.
 */
export async function GET(req: Request) {
  await ensureDatabaseReady();
  const auth = await requireApiKey(req);
  if ("response" in auth) return auth.response;
  const q = new URL(req.url).searchParams;
  const side = q.get("side") === "vendor" ? "vendor" : "customer";
  const partyId = q.get("partyId") || "";
  const from = q.get("from") || "0000-01-01";
  const to = q.get("to") || new Date().toISOString().slice(0, 10);
  if (!partyId) return json({ ok: false, error: "partyId required." }, 400);
  const clientId = auth.ctx.clientId ?? Number(q.get("clientId"));
  if (!Number.isSafeInteger(clientId) || clientId <= 0) return json({ ok: false, error: "clientId required." }, 400);
  const partner = (await db.select().from(businessPartners).where(eq(businessPartners.id, partyId)).limit(1))[0];
  if (!partner || partner.clientId !== clientId) return json({ ok: false, error: "Partner not found in this entity." }, 404);
  const lines = await db.select().from(journalLines).where(eq(journalLines.clientId, clientId));
  const statement = buildAccountStatement({
    side, party: { name: partner.name, code: partner.code, ids: [partner.id] },
    from, to, currency: partner.currency, lines: lines as unknown as ACDOCALine[],
    documents: [], payments: [], invoices: [], orders: [],
  });
  return json({ ok: true, party: { id: partner.id, name: partner.name, code: partner.code }, side, from, to, ...statement });
}
