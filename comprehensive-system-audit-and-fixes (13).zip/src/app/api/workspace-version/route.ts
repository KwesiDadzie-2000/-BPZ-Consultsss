import { eq, sql } from 'drizzle-orm';
import { db } from '@/db';
import { ensureDatabaseReady } from '@/db/bootstrap';
import { clients, systemSettings } from '@/db/schema';
import { getSessionUser, authJson, hasFirmWideScope } from '@/lib/auth';

export const dynamic = 'force-dynamic';

/**
 * A small cross-device change marker. Full-state saves use an optimistic global
 * revision; append-only journals and the trade engine do not advance that
 * revision, so their independent activity is included as well. No amounts,
 * names or other client data are exposed by this endpoint.
 */
export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return authJson(req, { ok: false, error: 'Unauthorized' }, { status: 401 });
    if (user.status !== 'active') return authJson(req, { ok: false, error: 'Account is not active' }, { status: 403 });
    const entityId = Number(new URL(req.url).searchParams.get('entity'));
    if (!Number.isSafeInteger(entityId) || entityId < 1) {
      return authJson(req, { ok: false, error: 'Choose an entity' }, { status: 400 });
    }
    if (!hasFirmWideScope(user) && entityId !== user.clientId) {
      return authJson(req, { ok: false, error: 'Cross-entity read forbidden' }, { status: 403 });
    }
    const entity = await db.select({ id: clients.id }).from(clients).where(eq(clients.id, entityId)).limit(1);
    if (!entity.length) return authJson(req, { ok: false, error: 'Entity not found' }, { status: 404 });
    const rev = await db.select({ value: systemSettings.value }).from(systemSettings)
      .where(eq(systemSettings.key, 'workspace_state_revision')).limit(1);
    const revision = Number((rev[0]?.value as { revision?: number } | undefined)?.revision ?? 0);
    // Count journal LINES, not headers: `journal_headers` is only written by the
    // posting routes, so seeded/imported documents would be invisible to this
    // marker and a colleague's new posting would go unnoticed on other laptops.
    const query = await db.execute<{
      journals: string; journal_at: string | null; trade_docs: string; trade_at: string | null;
      payments: string; payment_at: string | null;
    }>(sql`
      select
        (select count(*)::text from journal_lines where client_id = ${entityId}) as journals,
        (select max(posted_at)::text from journal_headers where client_id = ${entityId}) as journal_at,
        (select count(*)::text from trade_documents where client_id = ${entityId}) as trade_docs,
        (select max(updated_at)::text from trade_documents where client_id = ${entityId}) as trade_at,
        (select count(*)::text from trade_payments where client_id = ${entityId}) as payments,
        (select max(created_at)::text from trade_payments where client_id = ${entityId}) as payment_at
    `);
    const row = query.rows[0];
    const latestLine = await db.execute<{ n: string; at: string | null }>(sql`
      select count(*)::text as n, max(date) as at from journal_lines where client_id = ${entityId}`);
    const line = latestLine.rows[0];
    const marker = [revision, row.journals, line?.n ?? '0', line?.at || '', row.journal_at || '',
      row.trade_docs, row.trade_at || '', row.payments, row.payment_at || ''].join(':');
    const response = authJson(req, { ok: true, entityId, revision, marker });
    response.headers.set('Cache-Control', 'no-store');
    return response;
  } catch (error) {
    console.error('workspace-version GET failed', error);
    return Response.json({ ok: false, error: 'Change check unavailable' }, { status: 503 });
  }
}
