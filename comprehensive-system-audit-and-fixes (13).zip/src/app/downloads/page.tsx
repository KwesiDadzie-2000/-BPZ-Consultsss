"use client";

import { Download, FileText, Image, Film, FileSpreadsheet } from "lucide-react";
import Link from "next/link";

interface Asset {
  name: string;
  description: string;
  url: string;
  type: "image" | "video" | "document";
  size: string;
}

const assets: Asset[] = [
  // Images
  { name: "BPZ Logo", description: "Professional BPZ Consults logo (PNG, 1280x720)", url: "/images/bpz-logo.png", type: "image", size: "315 KB" },
  { name: "Banking & Reconcile Desk", description: "Banking statement import & reconciliation dashboard", url: "/images/banking-desk.png", type: "image", size: "618 KB" },
  { name: "Customers & Vendors Directory", description: "Business partners master file with credit control", url: "/images/business-partners.png", type: "image", size: "755 KB" },
  { name: "General Ledger", description: "Account ledger with debits, credits and balances", url: "/images/general-ledger.png", type: "image", size: "734 KB" },
  { name: "Fixed Assets Register", description: "Fixed asset register with depreciation schedules", url: "/images/fixed-assets.png", type: "image", size: "838 KB" },
  { name: "Financial Reports", description: "Financial statements dashboard with trial balance", url: "/images/financial-reports.png", type: "image", size: "859 KB" },

  // Videos (Animated GIFs)
  { name: "Marketing Intro", description: "BPZ Consults ERP title card (animated, 3 seconds)", url: "/images/bpz-marketing-intro.gif", type: "video", size: "11 KB" },
  { name: "Statement Import Demo", description: "Banking, partners, GL, assets & reports walkthrough (animated, ~6 seconds)", url: "/images/bpz-statement-demo.gif", type: "video", size: "2.1 MB" },
  { name: "Full System Demo", description: "Complete 6-desk system walkthrough (animated, ~12 seconds)", url: "/images/bpz-full-demo.gif", type: "video", size: "2.1 MB" },
];

const typeIcons = { image: Image, video: Film, document: FileText };
const typeColors = { image: "bg-blue-100 text-blue-700", video: "bg-purple-100 text-purple-700", document: "bg-green-100 text-green-700" };

export default function DownloadsPage() {
  return (
    <div className="min-h-screen bg-[#f0f6fc] py-12">
      <div className="mx-auto max-w-4xl px-4">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-black tracking-tight text-[#003366]">
            BPZ Consults ERP — Downloads
          </h1>
          <p className="mt-2 text-lg text-[#666666]">
            Marketing assets, product screenshots, and demo videos — ready to share
          </p>
          <p className="mt-1 text-sm text-[#999999]">
            All files are directly downloadable. No external links required.
          </p>
        </div>

        {/* Navigation */}
        <div className="mb-6 flex justify-center gap-3">
          <Link
            href="/"
            className="rounded-lg border border-[#003366] bg-white px-4 py-2 text-sm font-semibold text-[#003366] hover:bg-[#003366] hover:text-white transition"
          >
            ← Back to ERP
          </Link>
        </div>

        {/* Stats */}
        <div className="mb-8 grid grid-cols-3 gap-4">
          <div className="rounded-xl border border-blue-200 bg-blue-50 p-4 text-center">
            <div className="text-2xl font-black text-blue-600">6</div>
            <div className="text-xs font-semibold text-blue-500">Product Screenshots</div>
          </div>
          <div className="rounded-xl border border-purple-200 bg-purple-50 p-4 text-center">
            <div className="text-2xl font-black text-purple-600">3</div>
            <div className="text-xs font-semibold text-purple-500">Demo Videos (GIF)</div>
          </div>
          <div className="rounded-xl border border-green-200 bg-green-50 p-4 text-center">
            <div className="text-2xl font-black text-green-600">9</div>
            <div className="text-xs font-semibold text-green-500">Total Assets</div>
          </div>
        </div>

        {/* Video Section */}
        <section className="mb-8">
          <h2 className="mb-4 text-xl font-bold text-[#003366]">
            <Film className="mr-2 inline h-5 w-5" />
            Demo Videos
          </h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {assets.filter((a) => a.type === "video").map((asset) => {
              const Icon = typeIcons[asset.type];
              return (
                <div
                  key={asset.name}
                  className="group overflow-hidden rounded-xl border border-purple-200 bg-white shadow-sm transition hover:shadow-md"
                >
                  <div className="relative">
                    <img
                      src={asset.url}
                      alt={asset.name}
                      className="h-40 w-full object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 transition group-hover:opacity-100">
                      <a
                        href={asset.url}
                        download
                        className="flex items-center gap-2 rounded-lg bg-white px-4 py-2 text-sm font-bold text-purple-700 shadow-lg transition hover:bg-purple-50"
                      >
                        <Download className="h-4 w-4" />
                        Download
                      </a>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center gap-2">
                      <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold ${typeColors[asset.type]}`}>
                        <Icon className="mr-1 inline h-3 w-3" />
                        {asset.type}
                      </span>
                      <span className="text-xs text-[#999999]">{asset.size}</span>
                    </div>
                    <h3 className="mt-1 font-bold text-[#003366]">{asset.name}</h3>
                    <p className="mt-1 text-xs text-[#666666]">{asset.description}</p>
                    <a
                      href={asset.url}
                      download
                      className="mt-2 inline-flex items-center gap-1 rounded-lg bg-purple-600 px-3 py-1.5 text-xs font-bold text-white transition hover:bg-purple-700"
                    >
                      <Download className="h-3.5 w-3.5" />
                      Download Video
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Image Section */}
        <section className="mb-8">
          <h2 className="mb-4 text-xl font-bold text-[#003366]">
            <Image className="mr-2 inline h-5 w-5" />
            Product Screenshots
          </h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {assets.filter((a) => a.type === "image").map((asset) => {
              const Icon = typeIcons[asset.type];
              return (
                <div
                  key={asset.name}
                  className="group overflow-hidden rounded-xl border border-blue-200 bg-white shadow-sm transition hover:shadow-md"
                >
                  <div className="relative">
                    <img
                      src={asset.url}
                      alt={asset.name}
                      className="h-40 w-full object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 transition group-hover:opacity-100">
                      <a
                        href={asset.url}
                        download
                        className="flex items-center gap-2 rounded-lg bg-white px-4 py-2 text-sm font-bold text-blue-700 shadow-lg transition hover:bg-blue-50"
                      >
                        <Download className="h-4 w-4" />
                        Download
                      </a>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center gap-2">
                      <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold ${typeColors[asset.type]}`}>
                        <Icon className="mr-1 inline h-3 w-3" />
                        {asset.type}
                      </span>
                      <span className="text-xs text-[#999999]">{asset.size}</span>
                    </div>
                    <h3 className="mt-1 font-bold text-[#003366]">{asset.name}</h3>
                    <p className="mt-1 text-xs text-[#666666]">{asset.description}</p>
                    <a
                      href={asset.url}
                      download
                      className="mt-2 inline-flex items-center gap-1 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-bold text-white transition hover:bg-blue-700"
                    >
                      <Download className="h-3.5 w-3.5" />
                      Download Image
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Footer */}
        <div className="rounded-xl border border-sky-200 bg-white p-6 text-center shadow-sm">
          <p className="text-sm text-[#666666]">
            All assets are served directly from the BPZ Consults ERP application.
          </p>
          <p className="mt-1 text-xs text-[#999999]">
            For the production-ready marketing video production package, see the documentation in the project repository.
          </p>
        </div>
      </div>
    </div>
  );
}
