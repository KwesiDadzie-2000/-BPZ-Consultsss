import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "BPZ Consult ERP",
  description: "BPZ Consult — multi-entity accounting, tax, payroll and IFRS reporting workspace.",
  manifest: "/manifest.json",
  appleWebApp: { capable: true, statusBarStyle: "default", title: "BPZ ERP" },
  icons: { icon: "/images/bpz-logo.png", apple: "/images/bpz-logo.png" },
};

// Mobile: responsive, installable, correct theme; never pinch-locked so the
// financial tables stay usable and accessible on phones.
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#082f4f",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#f0f6fc] text-[#0a253e] antialiased">{children}</body>
    </html>
  );
}
