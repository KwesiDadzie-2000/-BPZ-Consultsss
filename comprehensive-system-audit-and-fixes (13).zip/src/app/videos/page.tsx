import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "BPZ Consults — Videos (download & share)",
  description: "Standalone BPZ Consults videos: marketing introduction and accountant live-case walkthrough. Download and share freely.",
};

/**
 * Standalone public video library — deliberately NOT part of the ERP workspace.
 * No login, no workspace shell, no app template imports. The MP4s are static
 * files under /public/videos, so each download link hits the file directly.
 */
const card: React.CSSProperties = {
  background: "#fff", border: "1px solid #cfe0f1", borderRadius: 14, padding: 20, marginBottom: 20,
};
const btn = (gold: boolean): React.CSSProperties => ({
  display: "inline-block", background: gold ? "#f5b719" : "#082f4f", color: gold ? "#082f4f" : "#fff",
  fontWeight: 800, fontSize: 13, padding: "10px 16px", borderRadius: 9, textDecoration: "none",
});

export default function VideosPage() {
  return (
    <div style={{ margin: 0, background: "#f0f6fc", color: "#0a253e", minHeight: "100vh", fontFamily: "-apple-system,'Segoe UI',Roboto,Arial,sans-serif" }}>
      <header style={{ background: "#082f4f", color: "#fff", padding: "28px 20px", borderBottom: "4px solid #f5b719" }}>
        <div style={{ color: "#f5b719", fontSize: 12, fontWeight: 800, letterSpacing: ".14em" }}>BPZ CONSULTS · VIDEO LIBRARY</div>
        <h1 style={{ margin: "6px 0 4px", fontSize: 26 }}>Watch, download &amp; share</h1>
        <p style={{ margin: 0, color: "#cfe0f1", fontSize: 14, maxWidth: 760 }}>
          Two standalone videos, separate from the workspace. Save the MP4 files and share them with prospects — no sign-in needed on this page.
        </p>
      </header>
      <main style={{ maxWidth: 980, margin: "0 auto", padding: "24px 20px 60px" }}>
        <section style={card}>
          <h2 style={{ margin: "0 0 4px", fontSize: 18, color: "#082f4f" }}>1 · BPZ Consults — marketing introduction (with voiceover)</h2>
          <p style={{ margin: "0 0 12px", fontSize: 13, color: "#355875" }}>Who we are, what the system does, key features and client benefits · English voiceover</p>
          <video style={{ width: "100%", borderRadius: 10, background: "#000" }} controls preload="metadata" poster="/videos/bpz-consults-marketing-poster.jpg" src="/videos/bpz-consults-marketing.mp4" />
          <div style={{ display: "flex", flexWrap: "wrap", gap: 10, marginTop: 12, alignItems: "center" }}>
            <a href="/videos/bpz-consults-marketing.mp4" download="bpz-consults-marketing.mp4" style={btn(true)}>⬇ Download marketing video (MP4)</a>
            <span style={{ fontSize: 12, color: "#355875" }}>H.264 + AAC · 720p · ~1.3 MB · plays on phone, laptop &amp; WhatsApp</span>
          </div>
        </section>
        <section style={card}>
          <h2 style={{ margin: "0 0 4px", fontSize: 18, color: "#082f4f" }}>2 · Accountant at work — live case postings (with voiceover)</h2>
          <p style={{ margin: "0 0 12px", fontSize: 13, color: "#355875" }}>Goods received → supplier invoice → payment → stock sale → receipt → close, with the exact Dr/Cr lines</p>
          <video style={{ width: "100%", borderRadius: 10, background: "#000" }} controls preload="metadata" poster="/videos/accountant-live-case-scenario-poster.jpg" src="/videos/accountant-live-case-scenario.mp4" />
          <div style={{ display: "flex", flexWrap: "wrap", gap: 10, marginTop: 12, alignItems: "center" }}>
            <a href="/videos/accountant-live-case-scenario.mp4" download="accountant-live-case-scenario.mp4" style={btn(true)}>⬇ Download live-case video (MP4)</a>
            <span style={{ fontSize: 12, color: "#355875" }}>H.264 + AAC · 720p · ~1.3 MB · free to forward to prospects</span>
          </div>
        </section>
      </main>
      <footer style={{ fontSize: 12, color: "#355875", padding: "0 20px 40px", maxWidth: 980, margin: "0 auto" }}>
        © BPZ Consults · These videos are standalone share assets. The workspace application itself is unchanged.
      </footer>
    </div>
  );
}
