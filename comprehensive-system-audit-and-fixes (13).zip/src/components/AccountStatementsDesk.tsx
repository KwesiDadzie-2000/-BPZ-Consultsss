import { useMemo, useState } from 'react';
import { Download, FileText, Printer, Search, ShieldCheck } from 'lucide-react';
import type { BusinessPartner, ClientEntity, UserAccount } from '../types/accounting';
import type { AccountStatement } from '../utils/accountStatement';
import { apiFetchVerified } from '../utils/session';
import { localToday } from '../utils/periods';
import { downloadCsv, printReport } from '../utils/printReport';
import { toPrintEntity } from '../utils/printEntity';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';

type Kind = 'client' | 'customer' | 'vendor';
type StatementResponse = AccountStatement & {
  ok: true;
  entity: { id: number; name: string; code: string; currency: string };
  party: { name: string; code: string; kind: Kind };
  from: string; to: string; generatedAt: string; notice: string;
};
interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  clients: ClientEntity[];
  partners: BusinessPartner[];
  onSessionLost: () => void;
}

const field = 'mt-1.5 w-full rounded-lg border border-sky-200 bg-white px-3 py-2.5 text-sm text-[#082f4f] outline-none transition focus:border-[#006f98] focus:ring-2 focus:ring-sky-100';
const label = 'block text-[11px] font-bold uppercase tracking-wide text-[#355875]';
const money = (n: number, currency: string) => `${currency} ${formatGHS(n)}`;

/** Confidential, owner-only account statements, generated from server-held journals. */
export function AccountStatementsDesk({ currentClient, currentUser, clients, partners, onSessionLost }: Props) {
  const firm = clients.find((client) => client.isParent);
  const [kind, setKind] = useState<Kind>('customer');
  const [entityId, setEntityId] = useState(currentClient.id);
  const [partyId, setPartyId] = useState('');
  const [from, setFrom] = useState(() => `${localToday().slice(0, 4)}-01-01`);
  const [to, setTo] = useState(() => localToday());
  const [report, setReport] = useState<StatementResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const effectiveEntity = kind === 'client' ? firm : clients.find((client) => client.id === entityId);
  const options = useMemo(() => kind === 'client'
    ? clients.filter((client) => !client.isParent).map((client) => ({ id: String(client.id), code: client.code, name: client.name }))
    : partners.filter((partner) => partner.clientId === entityId && partner.type === (kind === 'vendor' ? 'Vendor' : 'Customer'))
      .map((partner) => ({ id: partner.id, code: partner.code, name: partner.name })),
  [kind, clients, partners, entityId]);

  const reset = () => { setReport(null); setError(null); };
  const changeKind = (next: Kind) => { setKind(next); setPartyId(''); reset(); };
  const generate = async (event: React.FormEvent) => {
    event.preventDefault();
    reset();
    if (!effectiveEntity || !partyId) { setError('Choose a workspace and a client, customer or vendor.'); return; }
    if (!from || !to || from > to) { setError('Choose a valid start and end date.'); return; }
    setLoading(true);
    try {
      const query = new URLSearchParams({ entityId: String(effectiveEntity.id), kind, partyId, from, to });
      const { response, sessionLost } = await apiFetchVerified(`/api/account-statements?${query}`);
      if (sessionLost) { onSessionLost(); return; }
      if (!response) { setError('The server could not be reached. No statement was generated.'); return; }
      const body = await response.json().catch(() => null);
      if (!response.ok || !body?.ok) { setError(body?.error || `Could not generate statement (HTTP ${response.status}).`); return; }
      setReport(body as StatementResponse);
    } catch {
      setError('The statement could not be generated. Please try again.');
    } finally { setLoading(false); }
  };

  const exportCsv = () => {
    if (!report) return;
    downloadCsv(`statement-${report.entity.code}-${report.party.code}-${report.to}.csv`, [
      ['Statement of account', report.party.name, report.party.code],
      ['Entity', report.entity.name, 'Currency', report.entity.currency],
      ['Period', report.from, report.to],
      ['Opening balance', report.opening],
      ['Date', 'Source document', 'Journal', 'Description', 'Account', 'Debit', 'Credit', 'Running balance'],
      ...report.rows.map((r) => [r.date, r.document, r.journal, r.description, r.account, r.debit, r.credit, r.balance]),
      ['Closing balance', '', '', '', '', '', '', report.closing],
      ['Note', 'Positive = amount due; negative = credit/advance. Functional-currency posted ledger; unbilled GRNI is excluded.'],
      ...(report.notice ? [['Notice', report.notice]] : []),
      ...(report.unattributedCount ? [['Notice', `${report.unattributedCount} control-account line(s) have no reliable party attribution and are excluded.`]] : []),
    ]);
  };
  const print = () => {
    if (!report) return;
    printReport({
      title: 'Statement of account', subtitle: `${report.party.name} · ${report.party.code}`,
      kicker: `${report.party.kind} statement · posted ledger`, entity: toPrintEntity(report.entity),
      periodLabel: `${report.from} to ${report.to}`, preparedBy: currentUser.name,
      stats: [{ label: 'Opening balance', value: money(report.opening, report.entity.currency) },
        { label: 'Debits', value: money(report.totalDebit, report.entity.currency) },
        { label: 'Credits', value: money(report.totalCredit, report.entity.currency) },
        { label: 'Closing balance', value: money(report.closing, report.entity.currency) }],
      sections: [{ columns: [
        { key: 'date', label: 'Date' }, { key: 'document', label: 'Document' }, { key: 'description', label: 'Description' },
        { key: 'debit', label: 'Debit', numeric: true }, { key: 'credit', label: 'Credit', numeric: true }, { key: 'balance', label: 'Balance', numeric: true },
      ], rows: report.rows.map((row) => ({ ...row })),
      note: 'Positive balance means amount due; negative balance means a credit or advance. Figures are in functional currency. Unbilled GRNI is not an invoiced payable.' }],
      paragraphs: [report.notice, report.unattributedCount ? `${report.unattributedCount} control-account entries could not be reliably attributed and are excluded. Reconcile the general ledger.` : ''].filter(Boolean),
      footerNote: `Generated ${new Date(report.generatedAt).toLocaleString()} from posted journal entries. Review and reconcile before sending.`,
      orientation: 'landscape',
    });
  };

  return (
    <div className="space-y-6">
      <PageHeader kicker="SOA · Owner reporting" title="Statements of account" desc="Prepare a clear account statement for a client, customer or vendor using posted ledger activity.">
        <div className="flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-800"><ShieldCheck className="h-4 w-4" /> Owner access</div>
      </PageHeader>

      <Card title="Build a statement" sub="Choose whose account to review and the period to include. The opening balance includes posted activity before the start date.">
        <form onSubmit={generate} className="space-y-5">
          <div className="flex flex-wrap gap-2" role="group" aria-label="Statement type">
            {([['client', 'Firm clients'], ['customer', 'Customers'], ['vendor', 'Vendors']] as const).map(([value, text]) => (
              <button type="button" key={value} onClick={() => changeKind(value)} aria-pressed={kind === value}
                className={`rounded-lg px-4 py-2 text-xs font-bold transition ${kind === value ? 'bg-[#082f4f] text-white' : 'border border-sky-200 bg-white text-[#355875] hover:bg-sky-50'}`}>{text}</button>
            ))}
          </div>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <label className={label}>Accounting workspace
              {kind === 'client' ? <div className={`${field} bg-slate-50`}>{firm ? `${firm.code} · ${firm.name}` : 'No firm workspace configured'}</div>
                : <select className={field} value={entityId} onChange={(e) => { setEntityId(Number(e.target.value)); setPartyId(''); reset(); }}>
                  {clients.map((client) => <option key={client.id} value={client.id}>{client.code} · {client.name}</option>)}
                </select>}
            </label>
            <label className={label}>{kind === 'client' ? 'Client workspace' : kind === 'vendor' ? 'Vendor / supplier' : 'Customer'}
              <select className={field} value={partyId} onChange={(e) => { setPartyId(e.target.value); reset(); }} required>
                <option value="">Select {kind}</option>
                {options.map((option) => <option key={option.id} value={option.id}>{option.code} · {option.name}</option>)}
              </select>
            </label>
            <label className={label}>From <input type="date" className={field} value={from} onChange={(e) => { setFrom(e.target.value); reset(); }} required /></label>
            <label className={label}>To <input type="date" className={field} value={to} onChange={(e) => { setTo(e.target.value); reset(); }} required /></label>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-sky-100 pt-4">
            <p className="max-w-3xl text-xs leading-relaxed text-[#355875]">
              {kind === 'client' ? 'Client statements show what the client owes the firm, using the firm workspace—not the client’s own accounting books.'
                : 'Only posted, reliably attributed transactions are included. GRNI receipts are excluded until the supplier invoice is recorded.'}
            </p>
            <button type="submit" disabled={loading || !options.length || !effectiveEntity} className="inline-flex items-center gap-2 rounded-lg bg-[#082f4f] px-4 py-2.5 text-xs font-bold text-white transition hover:bg-[#0c3f68] disabled:opacity-50"><Search className="h-4 w-4" /> {loading ? 'Generating…' : 'Generate statement'}</button>
          </div>
          {!options.length && <p className="text-xs text-amber-700">No {kind} records are available for this selection. Register the party first.</p>}
          {error && <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs font-semibold text-rose-800">{error}</div>}
        </form>
      </Card>

      {report ? (
        <>
          {(report.notice || report.unattributedCount > 0) && <div role="status" className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-xs leading-relaxed text-amber-900">
            {report.notice && <p>{report.notice}</p>}
            {report.unattributedCount > 0 && <p>{report.unattributedCount} control-account line(s) in this workspace lack a reliable party reference and are excluded. Review the general ledger before relying on this statement.</p>}
          </div>}
          <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
            <Stat label="Opening balance" value={money(report.opening, report.entity.currency)} sub={`Before ${report.from}`} />
            <Stat label="Period debits" value={money(report.totalDebit, report.entity.currency)} sub="Posted control lines" />
            <Stat label="Period credits" value={money(report.totalCredit, report.entity.currency)} sub="Posted control lines" />
            <Stat label="Closing balance" value={money(report.closing, report.entity.currency)} tone={report.closing < 0 ? 'text-amber-700' : 'text-[#006f98]'} sub={report.closing < 0 ? 'Credit / advance' : 'Amount due'} />
          </div>
          <Card title={`${report.party.name} · ${report.party.code}`} sub={`${report.entity.name} · ${report.from} to ${report.to} · ${report.entity.currency} functional currency`}
            action={<div className="flex flex-wrap gap-2"><button type="button" onClick={exportCsv} className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50"><Download className="h-4 w-4" /> CSV</button><button type="button" onClick={print} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3 py-2 text-xs font-bold text-white hover:bg-[#0c3f68]"><Printer className="h-4 w-4" /> Print / PDF</button></div>}>
            <div className="overflow-x-auto"><table className="w-full min-w-[860px] text-xs">
              <thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Date</th><th className={thCls}>Document / journal</th><th className={thCls}>Description</th><th className={thCls}>GL</th><th className={`${thCls} text-right`}>Debit</th><th className={`${thCls} text-right`}>Credit</th><th className={`${thCls} text-right`}>Balance</th></tr></thead>
              <tbody>
                <tr className={rowCls}><td className="px-3 py-2 text-[#355875]">{report.from}</td><td className="px-3 py-2 font-semibold text-[#082f4f]" colSpan={5}>Opening balance</td><td className={`${numCls} font-bold`}>{formatGHS(report.opening)}</td></tr>
                {report.rows.map((r) => <tr key={r.id} className={rowCls}><td className="px-3 py-2 font-mono text-[#355875]">{r.date}</td><td className="px-3 py-2 font-mono text-[#082f4f]">{r.document}<span className="block text-[10px] text-slate-400">{r.journal}</span></td><td className="px-3 py-2 text-[#355875]">{r.description}</td><td className="px-3 py-2 font-mono text-[#355875]">{r.account}</td><td className={numCls}>{r.debit ? formatGHS(r.debit) : '—'}</td><td className={numCls}>{r.credit ? formatGHS(r.credit) : '—'}</td><td className={`${numCls} font-bold text-[#082f4f]`}>{formatGHS(r.balance)}</td></tr>)}
              </tbody>
            </table></div>
            {!report.rows.length && <p className="py-5 text-center text-xs text-[#355875]">No posted transactions attributed to this party in the selected period.</p>}
            <p className="mt-3 text-[11px] leading-relaxed text-[#355875]">Positive balance = amount due; negative balance = credit or advance. Figures reflect posted transactions in functional currency, including reversals. Verify unassigned entries and reconcile before sending.</p>
          </Card>
        </>
      ) : !loading && <div className="rounded-xl border border-dashed border-sky-300 bg-white/60 px-6 py-10 text-center"><FileText className="mx-auto h-8 w-8 text-sky-400" /><h3 className="mt-3 text-sm font-bold text-[#082f4f]">Your statement will appear here</h3><p className="mt-1 text-xs text-[#355875]">Select an account and date range above, then generate your report.</p></div>}
    </div>
  );
}
