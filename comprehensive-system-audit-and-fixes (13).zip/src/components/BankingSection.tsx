import { localToday } from '../utils/periods';
import React, { useState } from 'react';
import { ClientEntity, BankAccount, ACDOCALine, AccountMaster, PurchaseOrder, SalesInvoice, UserAccount } from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import { ModulePrintButton } from './ModulePrintButton';
import { CheckCircle, Plus, Upload, Calculator, FileSpreadsheet, AlertTriangle } from 'lucide-react';
import { fxExposureFromRegisters } from '../utils/reports';
import { MAX_STATEMENT_BYTES, matchStatementLines, parseStatementReport, type StatementConvention, type StatementDateOrder, type StatementImportReport } from '../utils/bankStatement';
import { treasuryGlFor } from '../lib/treasuryDerivation';
import { downloadCsv } from '../utils/printReport';
import { currencySymbol } from '../utils/currency';
import { nextIntId, uniqueId } from '../utils/ids';
import { refusalReason } from '../utils/postingNotice';
import { apiFetch } from '../utils/session';

const ROWS_PER_PAGE = 100;
type StatementFile = {
  fileName: string;
  raw: string;
  convention: StatementConvention;
  dateOrder: StatementDateOrder;
  report: StatementImportReport;
};

interface BankingSectionProps {
  /** The chart valid under the current entity/sector before the modal opens. */
  accountsChart?: AccountMaster[];
  currentClient: ClientEntity;
  currentUser?: UserAccount;
  bankAccounts: BankAccount[];
  lines: ACDOCALine[];
  accounts?: AccountMaster[];
  /** Registers holding foreign-currency monetary exposure (the ledger is functional-currency only). */
  invoices?: SalesInvoice[];
  orders?: PurchaseOrder[];
  onAddBankAccount?: (acc: BankAccount) => boolean;
  onAddJournalLines?: (lines: ACDOCALine[]) => boolean;
}

export const BankingSection: React.FC<BankingSectionProps> = ({
  accountsChart,
  currentClient,
  currentUser,
  bankAccounts,
  lines,
  accounts = [],
  invoices = [],
  orders = [],
  onAddBankAccount,
  onAddJournalLines,
}) => {
  const [selectedAccId, setSelectedAccId] = useState<number>(bankAccounts[0]?.id || 1);
  const [showAddModal, setShowAddModal] = useState(false);
  const [bName, setBName] = useState('');
  const [bBank, setBBank] = useState('');
  const [bAccNo, setBAccNo] = useState('');
  const [bCcy, setBCcy] = useState(currentClient.currency);
  const [bOpenBal, setBOpenBal] = useState(0);
  const [bKind, setBKind] = useState<'bank' | 'cash'>('bank');
  const [bGl, setBGl] = useState('100000');

  const [imports, setImports] = useState<Record<number, StatementFile>>({});
  const [importErrors, setImportErrors] = useState<Record<number, string>>({});
  const [syncInfo, setSyncInfo] = useState<Record<number, string>>({});
  const [pages, setPages] = useState<Record<number, number>>({});
  const importVersions = React.useRef(new Map<number, number>());
  const [bankError, setBankError] = useState<string | null>(null);
  // IAS 21 FX revaluation state
  const [fxCcy, setFxCcy] = useState('USD');
  const [fxBookRate, setFxBookRate] = useState(12);
  const [fxClosingRate, setFxClosingRate] = useState(12.5);
  const [fxDate, setFxDate] = useState(() => localToday());
  const [fxMsg, setFxMsg] = useState<string | null>(null);

  const activeAccount = bankAccounts.find((a) => a.id === selectedAccId) || bankAccounts[0];

  const canManageBank = Boolean(onAddBankAccount && currentUser?.role !== 'auditor' && currentUser?.status !== 'restricted');
  const treasuryAccounts = accounts.filter((a) => a.active && /^10\d{4}$/.test(a.accountNo));
  const activeCurrency = (activeAccount?.currency ?? currentClient.currency).toUpperCase();
  const accountId = activeAccount?.id;
  const activeGl = activeAccount ? treasuryGlFor(activeAccount) : '';
  const sharedGl = activeAccount && bankAccounts.some((b) => b.id !== accountId && treasuryGlFor(b) === activeGl && b.currency.toUpperCase() === activeCurrency);
  const statement = accountId === undefined ? undefined : imports[accountId];
  const stmtReport = statement?.report;
  const stmtLines = stmtReport?.lines ?? [];
  const stmtMsg = accountId === undefined ? undefined : importErrors[accountId];
  const statementPageCount = Math.max(1, Math.ceil(stmtLines.length / ROWS_PER_PAGE));
  const statementPage = Math.min(accountId === undefined ? 0 : (pages[accountId] ?? 0), statementPageCount - 1);
  const bankLines = React.useMemo(() => activeGl ? lines.filter((l) => l.clientId === currentClient.id && l.accountNo === activeGl
    && l.currency.toUpperCase() === activeCurrency) : [], [activeGl, activeCurrency, lines, currentClient.id]);
  const matches = React.useMemo(() => stmtReport?.lines.length
    ? matchStatementLines(stmtReport.lines, sharedGl ? [] : bankLines, activeGl) : [], [stmtReport, bankLines, activeGl, sharedGl]);
  const matchedCount = matches.filter((m) => m.matched).length;
  const matchIds = new Set(matches.map((m) => m.matchedLineId).filter(Boolean));
  const stmtDebits = stmtReport?.totals.out ?? 0;
  const stmtCredits = stmtReport?.totals.in ?? 0;

  // IAS 21 unrealised FX revaluation preview on FCY monetary items in the journal.
  // IAS 21 exposure is measured from the registers: the ledger holds only the
  // functional currency, so foreign balances live in treasury, AR and AP.
  const fxRows = fxExposureFromRegisters({
    clientId: currentClient.id, currency: fxCcy, bookRate: fxBookRate, closingRate: fxClosingRate,
    bankAccounts, invoices, purchaseOrders: orders,
  });
  const fxGain = fxRows.reduce((n, r) => n + Math.max(0, r.gainLoss), 0);
  const fxLoss = fxRows.reduce((n, r) => n + Math.max(0, -r.gainLoss), 0);

  const storeImport = (id: number, raw: string, fileName: string, convention: StatementConvention, dateOrder: StatementDateOrder) => {
    const report = parseStatementReport(raw, { convention, dateOrder });
    setImports((previous) => ({ ...previous, [id]: { raw, fileName, report, convention, dateOrder } }));
    setImportErrors((previous) => ({ ...previous, [id]: '' }));
    setPages((previous) => ({ ...previous, [id]: 0 }));
  };

  const handleImportStatement = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.currentTarget.files?.[0];
    e.currentTarget.value = '';
    if (!file || accountId === undefined) return;
    const id = accountId; // capture the account before any async file read
    const version = (importVersions.current.get(id) ?? 0) + 1;
    importVersions.current.set(id, version);
    const fail = (msg: string) => setImportErrors((previous) => ({ ...previous, [id]: msg }));
    if (!/\.(csv|tsv|txt)$/i.test(file.name)) { fail('Export a CSV, TSV or plain-text statement first. PDF and Excel workbooks are not supported here.'); return; }
    if (file.size > MAX_STATEMENT_BYTES) { fail('Choose a statement no larger than 5 MB. Split a larger export by date.'); return; }
    try {
      const data = new Uint8Array(await file.arrayBuffer());
      if (importVersions.current.get(id) !== version) return;
      const encoding = data[0] === 0xff && data[1] === 0xfe ? 'utf-16le' : data[0] === 0xfe && data[1] === 0xff ? 'utf-16be' : 'utf-8';
      const raw = new TextDecoder(encoding).decode(data);
      storeImport(id, raw, file.name, statement?.convention ?? 'debit-is-out', statement?.dateOrder ?? 'day-first');
      // Persist the import server-side so it survives a refresh and is visible
      // on other devices — a browser-only import vanished on reload and looked
      // like a broken button. The server also auto-matches against the ledger.
      try {
        const res = await apiFetch('/api/bank-feeds', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ clientId: currentClient.id, bankAccountId: id, content: raw, externalRef: `${file.name}` }),
        });
        const body = await res.json().catch(() => null);
        if (res.ok && body?.ok) {
          setImportErrors((previous) => ({ ...previous, [id]: '' }));
          setSyncInfo((previous) => ({ ...previous, [id]: `Saved to the server · ${body.matched} matched · ${body.unmatched} unmatched` }));
        }
      } catch {
        // Offline is not a failure: the local analysis still works.
        setSyncInfo((previous) => ({ ...previous, [id]: 'Parsed locally (offline — will persist on next connection)' }));
      }
    } catch {
      if (importVersions.current.get(id) === version) fail('The file could not be read. Export the statement again and retry.');
    }
  };

  const changeStatementOptions = (convention: StatementConvention, dateOrder: StatementDateOrder) => {
    if (statement && accountId !== undefined) storeImport(accountId, statement.raw, statement.fileName, convention, dateOrder);
  };

  const statementAnalysis = (() => {
    if (!stmtLines.length || !activeGl || sharedGl) return null;
    const dates = stmtLines.map((s) => s.date).sort();
    const from = dates[0];
    const to = dates[dates.length - 1];
    const inWindow = bankLines.filter((l) => l.date >= from && l.date <= to);
    const ledgerIn = inWindow.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
    const ledgerOut = inWindow.reduce((n, l) => n + Math.round(l.credit * 100), 0) / 100;
    const ledgerNet = Math.round((ledgerIn - ledgerOut) * 100) / 100;
    const statementNet = stmtReport?.totals.net ?? 0;
    const matchedValue = matches.filter((m) => m.matched).reduce((n, m) => n + Math.abs(m.net), 0);
    const totalValue = stmtDebits + stmtCredits;
    return { from, to, gl: activeGl, ledgerIn, ledgerOut, ledgerNet, statementNet,
      variance: Math.round((statementNet - ledgerNet) * 100) / 100,
      exceptions: matches.filter((m) => !m.matched),
      matchRate: totalValue > 0 ? Math.round((matchedValue / totalValue) * 1000) / 10 : 0 };
  })();

  const handleDownloadAnalysis = () => {
    const rows: (string | number | undefined)[][] = [
      ['Account', activeAccount?.code, activeAccount?.name, activeCurrency],
      ['Source', statement?.fileName],
      ['Row', 'ValueDate', 'Narrative', 'Reference', 'MoneyOut', 'MoneyIn', 'MatchStatus', 'MatchedDocNo', 'DaysDifference'],
      ...matches.map((m) => [m.line.row, m.line.date, m.line.description, m.line.reference, m.line.debit, m.line.credit,
        m.matched ? 'MATCHED' : m.ambiguous ? 'AMBIGUOUS' : 'UNMATCHED', m.matchedDocNo, m.days]),
    ];
    if (statementAnalysis) rows.push([], ['Analysis window', statementAnalysis.from, statementAnalysis.to],
      ['Ledger movement', statementAnalysis.gl, statementAnalysis.ledgerNet], ['Statement movement', statementAnalysis.statementNet],
      ['Variance', statementAnalysis.variance], ['Matched by value (%)', statementAnalysis.matchRate]);
    if (stmtReport) rows.push(['Rows skipped', stmtReport.skippedRows], ...stmtReport.skippedSamples.map((s) => [s]));
    downloadCsv(`statement-analysis-${activeAccount?.code ?? 'account'}.csv`, rows);
  };

  const handlePostFxRevaluation = () => {
    if (!onAddJournalLines || !fxRows.length) return;
    const period = fxDate.slice(0, 7);
    const docNo = `FXREV-${fxCcy}-${period}`;
    const entries: ACDOCALine[] = [];
    fxRows.forEach((r, i) => {
      if (r.gainLoss > 0.009) {
        entries.push(
          { id: `${uniqueId('JL-FX')}-${i}-1`, docNo, period, date: fxDate, module: 'FI', docType: 'JE', accountNo: r.accountNo, accountName: `${r.accountName} (FX revaluation)`, costCenter: 'CC-ADM', debit: Math.round(r.gainLoss * 100) / 100, credit: 0, currency: currentClient.currency, description: `IAS 21 unrealised FX gain at ${fxClosingRate} (book ${fxBookRate})`, createdBy: currentUser?.username || 'fx_revaluation', clientId: currentClient.id },
          { id: `${uniqueId('JL-FX')}-${i}-2`, docNo, period, date: fxDate, module: 'FI', docType: 'JE', accountNo: '491000', accountName: 'Foreign Exchange Gain (IAS 21)', costCenter: 'CC-ADM', debit: 0, credit: Math.round(r.gainLoss * 100) / 100, currency: currentClient.currency, description: `Unrealised FX gain on ${r.accountNo} (${fxCcy})`, createdBy: currentUser?.username || 'fx_revaluation', clientId: currentClient.id },
        );
      } else if (r.gainLoss < -0.009) {
        entries.push(
          { id: `${uniqueId('JL-FX')}-${i}-1`, docNo, period, date: fxDate, module: 'FI', docType: 'JE', accountNo: '580000', accountName: 'Foreign Exchange Loss', costCenter: 'CC-ADM', debit: Math.round(-r.gainLoss * 100) / 100, credit: 0, currency: currentClient.currency, description: `IAS 21 unrealised FX loss at ${fxClosingRate} (book ${fxBookRate})`, createdBy: currentUser?.username || 'fx_revaluation', clientId: currentClient.id },
          { id: `${uniqueId('JL-FX')}-${i}-2`, docNo, period, date: fxDate, module: 'FI', docType: 'JE', accountNo: r.accountNo, accountName: `${r.accountName} (FX revaluation)`, costCenter: 'CC-ADM', debit: 0, credit: Math.round(-r.gainLoss * 100) / 100, currency: currentClient.currency, description: `Unrealised FX loss on ${r.accountNo} (${fxCcy})`, createdBy: currentUser?.username || 'fx_revaluation', clientId: currentClient.id },
        );
      }
    });
    if (!entries.length) return;
    const ok = onAddJournalLines(entries);
    setFxMsg(ok
      ? `FX revaluation ${docNo} posted: gains ${formatGHS(fxGain)}, losses ${formatGHS(fxLoss)}.`
      : `FX revaluation rejected. ${refusalReason(`The period is closed or document ${docNo} already exists.`)}`);
    setTimeout(() => setFxMsg(null), 6000);
  };

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (onAddBankAccount) {
      setBankError(null);
      const glAccount = bGl || (bKind === 'cash' ? '102000' : '100000');
      const chosen = (accountsChart ?? []).find((a) => a.accountNo === glAccount);
      if (chosen && !chosen.active) {
        setBankError(`Ledger account ${glAccount} is inactive for ${currentClient.code}. Activate it in Chart of Accounts Master before assigning a treasury balance.`);
        return;
      }
      const walletDefaults = (accountsChart ?? []).length
        ? new Set(['100000', '102000', '103000', '104000'])
        : null;
      if (walletDefaults && !chosen && !walletDefaults.has(glAccount)) {
        setBankError(`Ledger account ${glAccount} is not available for ${currentClient.code}. Add it in Chart of Accounts Master first.`);
        return;
      }
      const newAcc: BankAccount = {
        id: nextIntId(bankAccounts),
        code: `${bKind === 'cash' ? 'CSH' : 'BNK'}-0${bankAccounts.length + 1}`,
        name: bName,
        bankName: bBank,
        accountNo: bAccNo,
        currency: bCcy,
        balance: bOpenBal,
        kind: bKind,
        glAccount,
      };
      if (!onAddBankAccount(newAcc)) {
        setBankError(refusalReason('The treasury record could not be created. Check its ledger mapping and opening balance.'));
        return;
      }
      setSelectedAccId(newAcc.id);
      setShowAddModal(false);
    }
  };

  const glCash = bankLines.reduce((n, l) => n + Math.round((l.debit - l.credit) * 100), 0) / 100;
  const displayedBankLines = [...bankLines].sort((a, b) => b.date.localeCompare(a.date)).slice(0, ROWS_PER_PAGE);
  const tieOut = activeAccount ? Math.round((activeAccount.balance - glCash) * 100) / 100 : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`BANK · Treasury & Bank Accounts · ${currentClient.code}`}
        title="Banking & Statement Reconciliation"
        desc="Multi-currency accounts, statement matching and balances."
      >
        <ModulePrintButton title={`Bank accounts & reconciliation — ${currentClient.name}`} subtitle="Balances, statement matches and cash position" />
        <button
          onClick={() => { setBankError(null); setShowAddModal(true); }}
          disabled={!canManageBank}
          className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
        >
          <Plus className="h-4 w-4" />
          <span>Add Bank Account</span>
        </button>
      </PageHeader>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Total Treasury Accounts" value={bankAccounts.length} sub="Operating & foreign exchange" />
        <Stat label="Active Account" value={activeAccount ? activeAccount.code : "—"} sub={activeAccount ? activeAccount.bankName : ""} />
        <Stat label="Recorded Bank Balance" value={activeAccount ? `${activeAccount.currency} ${formatGHS(activeAccount.balance)}` : "—"} tone="text-emerald-700" sub="Treasury record; reconcile against the bank statement" />
        <Stat
          label="GL tie-out difference"
          value={activeAccount ? `${activeAccount.currency} ${formatGHS(Math.abs(tieOut))}` : "—"}
          tone={Math.abs(tieOut) < 0.01 ? "text-emerald-700" : "text-rose-700"}
          sub={activeAccount ? (Math.abs(tieOut) < 0.01 ? "Treasury record matches the general ledger" : "Treasury record and GL differ — post opening balances or clear unreconciled items") : ""}
        />
      </div>

      {/* Account Selector Strip */}
      <div className="flex flex-wrap gap-2">
        {bankAccounts.map((acc) => (
          <button
            key={acc.id}
            onClick={() => setSelectedAccId(acc.id)}
            className={`rounded-xl border p-3 text-left transition shadow-xs ${
              selectedAccId === acc.id
                ? 'border-[#082f4f] bg-sky-50 ring-1 ring-[#082f4f]'
                : 'border-sky-200 bg-white hover:bg-sky-50/50'
            }`}
          >
            <div className="flex items-center justify-between text-xs font-mono text-[#355875]">
              <span>{acc.code}</span>
              <span className="flex items-center gap-1.5">
                <span className={`rounded px-1.5 py-0.2 text-[9px] font-black uppercase ${acc.kind === 'cash' ? 'bg-amber-100 text-[#855b00]' : 'bg-sky-100 text-[#006f98]'}`}>{acc.kind === 'cash' ? 'Cash' : 'Bank'}</span>
                <span className="font-bold text-[#082f4f]">{acc.currency}</span>
              </span>
            </div>
            <div className="text-xs font-bold text-[#082f4f] mt-1">{acc.name}</div>
            <div className="text-[11px] text-[#2d4f6d]">{acc.bankName} · {acc.accountNo}</div>
            <div className="text-[10.5px] text-[#355875] font-mono mt-0.5">GL {acc.glAccount || (acc.kind === 'cash' ? '102000' : '100000')}</div>
            <div className="font-mono text-xs font-bold text-emerald-700 mt-1">
              {acc.currency} {formatGHS(acc.balance)}
            </div>
          </button>
        ))}
      </div>

      {/* Statement import, auto-reconciliation & IAS 21 FX revaluation */}
      <div className="grid gap-4 xl:grid-cols-2">
        <Card
          title="Statement import & reconciliation"
          sub="Import a bank statement (CSV / TSV / semicolon-delimited) and analyse it against the posted ledger"
          action={
            <label className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-1.5 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition cursor-pointer shadow-xs">
              <Upload className="h-3.5 w-3.5 text-[#006f98]" />
              <span>Import statement</span>
              <input type="file" accept=".csv,.tsv,.txt,text/csv,text/plain" disabled={accountId === undefined} onChange={(event) => void handleImportStatement(event)} className="hidden" />
            </label>
          }
        >
          <div className="space-y-3 text-xs">
            {stmtMsg && <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 p-2.5 font-bold text-rose-800">{stmtMsg}</div>}
            {accountId !== undefined && syncInfo[accountId] && <div role="status" className="rounded-lg border border-emerald-300 bg-emerald-50 p-2.5 text-xs font-bold text-emerald-800">{syncInfo[accountId]}</div>}
            {!activeAccount && <p>Add a treasury account before importing its statement.</p>}
            {sharedGl && <p role="note" className="rounded-lg bg-amber-50 p-2.5 text-amber-900">This GL is shared by multiple accounts in this currency. Assign a dedicated GL before matching to avoid attributing another account’s cash.</p>}

            {/* SYSTEM ANALYSIS — what the file actually contained and how it
                reconciles to the posted ledger for the selected account. */}
            {stmtReport && (
              <div className="rounded-lg border border-[#006f98]/25 bg-white/70 p-3 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-[11px] font-black uppercase tracking-[0.14em] text-[#006f98]">
                    System analysis — {statement?.fileName} · {activeAccount?.code} ({activeCurrency})
                  </h4>
                  <div className="flex flex-wrap items-center gap-2">
                    <label className="flex items-center gap-1">
                      Date order
                      <select value={statement?.dateOrder ?? 'day-first'} onChange={(event) => changeStatementOptions(statement?.convention ?? 'debit-is-out', event.target.value as StatementDateOrder)} className="rounded-lg border border-sky-300 bg-white px-2 py-1">
                        <option value="day-first">Day first</option><option value="month-first">Month first</option>
                      </select>
                    </label>
                    <button
                      type="button"
                      onClick={() => changeStatementOptions(statement?.convention === 'debit-is-in' ? 'debit-is-out' : 'debit-is-in', statement?.dateOrder ?? 'day-first')}
                      className="rounded-lg border border-sky-300 bg-white px-2.5 py-1 text-[10.5px] font-bold text-[#082f4f] hover:bg-sky-50 transition"
                    >
                      Reading: “Debit” = money {statement?.convention === 'debit-is-in' ? 'in' : 'out'} · flip
                    </button>
                    <button
                      type="button"
                      onClick={handleDownloadAnalysis}
                      disabled={!stmtLines.length}
                      className="flex items-center gap-1.5 rounded-lg border border-emerald-300 bg-white px-2.5 py-1 text-[10.5px] font-bold text-emerald-800 hover:bg-emerald-50 transition"
                    >
                      <FileSpreadsheet className="h-3 w-3" />
                      <span>Download analysis</span>
                    </button>
                  </div>
                </div>

                <dl className="grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-2 font-mono">
                  <div>
                    <dt className="text-[10px] uppercase tracking-wide text-[#355875]">Rows read</dt>
                    <dd className="text-[#082f4f] font-bold">{stmtReport.totalRows}</dd>
                  </div>
                  <div>
                    <dt className="text-[10px] uppercase tracking-wide text-[#355875]">Rows skipped</dt>
                    <dd className={stmtReport.skippedRows ? 'text-amber-700 font-bold' : 'text-[#082f4f] font-bold'}>{stmtReport.skippedRows}</dd>
                  </div>
                  <div>
                    <dt className="text-[10px] uppercase tracking-wide text-[#355875]">Delimiter detected</dt>
                    <dd className="text-[#082f4f] font-bold">{stmtReport.delimiter === '\t' ? 'TAB' : stmtReport.delimiter}</dd>
                  </div>
                  <div>
                    <dt className="text-[10px] uppercase tracking-wide text-[#355875]">Header row</dt>
                    <dd className="text-[#082f4f] font-bold">{stmtReport.headerDetected ? 'Recognised' : 'Not found — read positionally'}</dd>
                  </div>
                </dl>

                {statementAnalysis && (
                  <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-2.5">
                    <div className="flex flex-wrap gap-x-5 gap-y-1.5 font-mono">
                      <span className="text-[#355875]">Window: <strong className="text-[#082f4f]">{statementAnalysis.from} → {statementAnalysis.to}</strong></span>
                      <span className="text-[#355875]">Ledger movement (GL {statementAnalysis.gl}): <strong className="text-[#082f4f]">{formatGHS(statementAnalysis.ledgerNet)}</strong></span>
                      <span className="text-[#355875]">Statement movement: <strong className="text-[#082f4f]">{formatGHS(statementAnalysis.statementNet)}</strong></span>
                      <span className="text-[#355875]">
                        Variance:{' '}
                        <strong className={Math.abs(statementAnalysis.variance) > 0.009 ? 'text-rose-700' : 'text-emerald-700'}>
                          {formatGHS(statementAnalysis.variance)}
                        </strong>
                      </span>
                      <span className="text-[#355875]">
                        Matched by value:{' '}
                        <strong className={statementAnalysis.matchRate >= 95 ? 'text-emerald-700' : statementAnalysis.matchRate >= 70 ? 'text-amber-700' : 'text-rose-700'}>
                          {statementAnalysis.matchRate}%
                        </strong>
                      </span>
                    </div>
                    {Math.abs(statementAnalysis.variance) > 0.009 && (
                      <p className="mt-2 text-[11px] leading-relaxed text-[#8a2b3c]">
                        The statement moved {formatGHS(Math.abs(statementAnalysis.variance))} {statementAnalysis.variance > 0 ? 'more into' : 'more out of'} this account than the posted ledger did over the same dates.
                        Unposted items below are the usual cause — post them through a journal, or treat genuine bank charges as reconciling items.
                      </p>
                    )}
                  </div>
                )}

                {stmtReport.skippedSamples.length > 0 && (
                  <div className="rounded-lg border border-amber-200 bg-amber-50/70 p-2.5">
                    <p className="text-[10px] font-black uppercase tracking-[0.12em] text-[#855b00]">Rows that could not be read</p>
                    <ul className="mt-1 space-y-0.5 text-[11px] text-[#855b00]">
                      {stmtReport.skippedSamples.map((s, i) => <li key={i}>{s}</li>)}
                    </ul>
                  </div>
                )}

                {stmtReport.warnings.length > 0 && (
                  <ul className="space-y-0.5 text-[11px] text-[#355875]">
                    {stmtReport.warnings.map((w, i) => <li key={i}>• {w}</li>)}
                  </ul>
                )}
              </div>
            )}

            {stmtLines.length > 0 ? (
              <>
                <div className="flex flex-wrap gap-4 font-mono">
                  <span className="text-[#355875]">Statement lines: <strong className="text-[#082f4f]">{stmtLines.length}</strong></span>
                  <span className="text-[#355875]">Matched: <strong className="text-emerald-700">{matchedCount}</strong></span>
                  <span className="text-[#355875]">Unmatched: <strong className="text-rose-700">{stmtLines.length - matchedCount}</strong></span>
                  <span className="text-[#355875]">Statement debits: <strong className="text-[#082f4f]">{formatGHS(stmtDebits)}</strong></span>
                  <span className="text-[#355875]">Statement credits: <strong className="text-[#082f4f]">{formatGHS(stmtCredits)}</strong></span>
                </div>
                {statementAnalysis && statementAnalysis.exceptions.length > 0 && (
                  <div className="rounded-lg border border-amber-300 bg-amber-50 p-2.5">
                    <p className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-[#855b00]">
                      <AlertTriangle className="h-3.5 w-3.5" />
                      Exception queue — {statementAnalysis.exceptions.length} statement line(s) with no posted ledger match
                    </p>
                    <ul className="mt-1.5 space-y-0.5 font-mono text-[11px] text-[#855b00]">
                      {statementAnalysis.exceptions.slice(0, 8).map((m, i) => (
                        <li key={i}>
                          {m.line.date} · {m.line.description.slice(0, 48)} · {m.net > 0 ? '+' : ''}{formatGHS(Math.abs(m.net))} {m.net > 0 ? 'in' : 'out'}
                        </li>
                      ))}
                      {statementAnalysis.exceptions.length > 8 && <li>… and {statementAnalysis.exceptions.length - 8} more</li>}
                    </ul>
                  </div>
                )}
                <div className="overflow-x-auto rounded-lg border border-sky-200">
                  <table className="w-full text-xs">
                    <thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Value date</th><th className={thCls}>Narration</th><th className={thCls + ' text-right'}>Debit</th><th className={thCls + ' text-right'}>Credit</th><th className={thCls}>Match status</th></tr></thead>
                    <tbody>
                      {matches.slice(statementPage * ROWS_PER_PAGE, (statementPage + 1) * ROWS_PER_PAGE).map((m, i) => (
                        <tr key={i} className={rowCls}>
                          <td className="px-3 py-2 font-mono text-[#2d4f6d]">{m.line.date}</td>
                          <td className="px-3 py-2 text-[#0a253e]">{m.line.description}</td>
                          <td className={numCls}>{m.line.debit > 0 ? formatGHS(m.line.debit) : '—'}</td>
                          <td className={numCls}>{m.line.credit > 0 ? formatGHS(m.line.credit) : '—'}</td>
                          <td className="px-3 py-2">
                            {m.matched
                              ? <span className="inline-flex items-center gap-1 rounded bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[10.5px] font-bold"><CheckCircle className="h-3 w-3" /><span>Matched · {m.matchedDocNo}</span></span>
                              : <span className="rounded bg-amber-100 text-[#855b00] px-2 py-0.5 text-[10.5px] font-bold">{m.ambiguous ? 'Ambiguous — review' : 'Unmatched'}</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {statementPageCount > 1 && accountId !== undefined && (
                  <div className="flex flex-wrap items-center justify-between gap-2" aria-label="Statement pagination">
                    <span>Page {statementPage + 1} of {statementPageCount} · Export includes all rows.</span>
                    <div className="flex gap-2">
                      <button type="button" disabled={statementPage === 0} onClick={() => setPages((p) => ({ ...p, [accountId]: statementPage - 1 }))} className="rounded border border-sky-300 px-2 py-1 disabled:opacity-40">Previous</button>
                      <button type="button" disabled={statementPage + 1 >= statementPageCount} onClick={() => setPages((p) => ({ ...p, [accountId]: statementPage + 1 }))} className="rounded border border-sky-300 px-2 py-1 disabled:opacity-40">Next</button>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <p className="text-[#2d4f6d] leading-relaxed">
                No statement transactions available for this account. Export your statement from the bank portal — CSV, TSV or semicolon-delimited text all work — and import it here.
                Columns are matched by name (Date / Value Date, Description / Narrative, Debit / Withdrawal, Credit / Deposit, or a single signed Amount), so the exact
                wording your bank uses does not matter. Dates may be <span className="font-mono">12/03/2026</span>, <span className="font-mono">2026-03-12</span> or{' '}
                <span className="font-mono">12 MAR 2026</span>, and amounts may carry currency symbols and thousands separators. Each line is then auto-matched to
                posted journal entries on this account within a 5-day value-date window, and ambiguous and unmatched rows are reported as exceptions. The import is an analysis in this browser session; download its CSV before leaving this desk.
              </p>
            )}
          </div>
        </Card>

        <Card title="FX revaluation (IAS 21)" sub="Unrealised gain/loss on foreign-currency monetary items in the journal">
          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <label className="font-bold text-[#355875]">Currency
                <select value={fxCcy} onChange={(e) => setFxCcy(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2 font-bold text-[#082f4f]">
                  {['USD','GBP','EUR','GHS'].filter((code) => code !== currentClient.currency).map((code) => (
                    <option key={code} value={code}>{code}</option>
                  ))}
                </select>
                <span className="mt-1 block text-[10px] text-[#355875]">Entity reports in {currentClient.currency}, so the foreign currency below must differ.</span>
              </label>
              <label className="font-bold text-[#355875]">Book rate ({currentClient.currency} per 1 {fxCcy})
                <input type="number" step="0.0001" value={fxBookRate} onChange={(e) => setFxBookRate(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" />
              </label>
              <label className="font-bold text-[#355875]">Closing rate ({currentClient.currency} per 1 {fxCcy})
                <input type="number" step="0.0001" value={fxClosingRate} onChange={(e) => setFxClosingRate(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" />
              </label>
              <label className="font-bold text-[#355875]">Revaluation date
                <input type="date" value={fxDate} onChange={(e) => setFxDate(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" />
              </label>
            </div>
            {fxMsg && <div className="rounded-lg border border-sky-300 bg-sky-50 p-2.5 font-bold text-[#082f4f]">{fxMsg}</div>}
            {fxRows.length > 0 ? (
              <>
                <div className="overflow-x-auto rounded-lg border border-sky-200">
                  <table className="w-full text-xs">
                    <thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Account</th><th className={thCls + ' text-right'}>{fxCcy} balance</th><th className={thCls + ' text-right'}>Revalued (GHS)</th><th className={thCls + ' text-right'}>Gain / (loss)</th></tr></thead>
                    <tbody>
                      {fxRows.map((r) => (
                        <tr key={r.accountNo} className={rowCls}>
                          <td className="px-3 py-2"><span className="font-mono font-bold text-[#082f4f]">{r.accountNo}</span> <span className="text-[#355875]">{r.accountName}</span></td>
                          <td className={numCls}>{formatGHS(r.fcyBalance)}</td>
                          <td className={numCls}>{formatGHS(r.revaluedGhs)}</td>
                          <td className={numCls + (r.gainLoss >= 0 ? ' text-emerald-700' : ' text-rose-700')}>{formatGHS(r.gainLoss)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <span className="text-[#2d4f6d]">Net unrealised: <strong className={fxGain - fxLoss >= 0 ? 'text-emerald-700' : 'text-rose-700'}>{formatGHS(fxGain - fxLoss)}</strong> (gains {formatGHS(fxGain)} · losses {formatGHS(fxLoss)})</span>
                  <button onClick={handlePostFxRevaluation} disabled={!onAddJournalLines || fxRows.length === 0 || fxCcy === currentClient.currency} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs disabled:opacity-40">
                    <Calculator className="h-3.5 w-3.5" />
                    <span>Post revaluation JE</span>
                  </button>
                </div>
              </>
            ) : (
              <p className="text-[#2d4f6d] leading-relaxed">No {fxCcy}-denominated journal balances found for this entity. Post foreign-currency transactions (e.g. a {fxCcy} purchase order or receipt) and the revaluation preview appears here.</p>
            )}
          </div>
        </Card>
      </div>

      <Card
        title={`Statement Lines & Postings for ${activeAccount ? activeAccount.name : ""}`}
        sub={`Latest ${displayedBankLines.length} of ${bankLines.length} journal lines on this GL and currency. See General Ledger for the full history.`}
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Doc No</th>
                <th className={thCls}>Date</th>
                <th className={thCls}>Description</th>
                <th className={thCls + " text-right"}>Cash In / Debit ({currencySymbol(activeAccount?.currency || currentClient.currency)})</th>
                <th className={thCls + " text-right"}>Cash Out / Credit ({currencySymbol(activeAccount?.currency || currentClient.currency)})</th>
                <th className={thCls}>Audit Status</th>
              </tr>
            </thead>
            <tbody>
              {displayedBankLines.map((l) => (
                <tr key={l.id} className={rowCls}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{l.docNo}</td>
                  <td className="px-3 py-2 font-mono text-[#2d4f6d]">{l.date}</td>
                  <td className="px-3 py-2 text-[#0a253e]">{l.description}</td>
                  <td className={numCls + " text-emerald-700 font-bold"}>
                    {l.debit > 0 ? formatGHS(l.debit) : '—'}
                  </td>
                  <td className={numCls + " text-rose-700 font-bold"}>
                    {l.credit > 0 ? formatGHS(l.credit) : '—'}
                  </td>
                  <td className="px-3 py-2">
                    {(() => {
                      const match = matchIds.has(l.id);
                      if (match || (statementAnalysis && l.date >= statementAnalysis.from && l.date <= statementAnalysis.to)) {
                        return match
                          ? <span className="inline-flex items-center gap-1 rounded bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[10.5px] font-bold"><CheckCircle className="h-3 w-3" /><span>Matched to statement</span></span>
                          : <span className="rounded bg-amber-100 text-[#855b00] px-2 py-0.5 text-[10.5px] font-bold">Not on statement</span>;
                      }
                      return <span className="inline-flex items-center gap-1 rounded bg-sky-100 text-[#006f98] px-2 py-0.5 text-[10.5px] font-bold"><CheckCircle className="h-3 w-3" /><span>Ledger posted</span></span>;
                    })()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Add Bank Account Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleCreateAccount} className="w-full max-w-md rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Add Real Bank Account</h3>
            <div className="space-y-3">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Account Label / Purpose</label>
                <input
                  type="text"
                  value={bName}
                  onChange={(e) => setBName(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-semibold text-[#082f4f]"
                  required
                />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Bank Name / Wallet Provider</label>
                <input
                  type="text"
                  value={bBank}
                  onChange={(e) => setBBank(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-semibold text-[#082f4f]"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Record Type</label>
                  <select
                    value={bKind}
                    onChange={(e) => setBKind(e.target.value as 'bank' | 'cash')}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-bold text-[#082f4f]"
                  >
                    <option value="bank">Bank account</option>
                    <option value="cash">Cash on hand / float</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">GL Account</label>
                  <select
                    value={bGl}
                    onChange={(e) => setBGl(e.target.value)}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-mono text-[#082f4f]"
                  >
                    {treasuryAccounts.map((a) => (
                      <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>
                    ))}
                    {treasuryAccounts.length === 0 && (
                      <>
                        <option value="100000">100000 · Cash at Bank — Operating</option>
                        <option value="102000">102000 · Petty Cash Safe Float</option>
                        <option value="103000">103000 · Cash on Hand — Office Till</option>
                        <option value="104000">104000 · Mobile Money Clearing</option>
                      </>
                    )}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Account Number</label>
                  <input
                    type="text"
                    value={bAccNo}
                    onChange={(e) => setBAccNo(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Currency</label>
                  <select
                    value={bCcy}
                    onChange={(e) => { setBCcy(e.target.value); if (e.target.value !== currentClient.currency) setBOpenBal(0); }}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-bold text-[#082f4f]"
                  >
                    {Array.from(new Set([currentClient.currency, 'GHS', 'USD', 'GBP', 'EUR'])).map((code) => (
                      <option key={code} value={code}>{code}{code === currentClient.currency ? ' · entity functional' : ''}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Opening Balance ({bCcy})</label>
                <input
                  type="number"
                  step="0.01"
                  value={bOpenBal}
                  disabled={bCcy !== currentClient.currency}
                  onChange={(e) => setBOpenBal(Number(e.target.value))}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono text-[#082f4f]"
                  required
                />
              </div>
            </div>
            {bCcy !== currentClient.currency && (
              <p className="rounded-lg border border-amber-300 bg-amber-50 p-3 text-[#855b00]">Open foreign accounts at zero. Record foreign funds with the documented rate through trade settlement; this form does not post a native-currency opening entry.</p>
            )}
            {bankError && (
              <p role="alert" className="rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-900">{bankError}</p>
            )}
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setShowAddModal(false)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 font-bold text-white">Save Bank Account</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
