import React, { useMemo, useState } from 'react';
import {
  ACDOCALine,
  AccountMaster,
  BusinessPartner,
  ClientEntity,
  PurchaseOrder,
  SalesInvoice,
  UserAccount,
} from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import { ModulePrintButton } from './ModulePrintButton';
import { Plus, Search, FileSpreadsheet, Pencil, Receipt, ShieldAlert } from 'lucide-react';
import { currentYear, docSuffix, uniqueId } from '../utils/ids';
import { ccy } from '../utils/currency';
import { downloadCsv } from '../utils/printReport';
import { localToday } from '../utils/periods';
import { OPENING_EQUITY_ACCOUNT } from '../utils/openingBalances';
import { refusalReason } from '../utils/postingNotice';

interface BusinessPartnersSectionProps {
  currentClient: ClientEntity;
  currentUser?: UserAccount;
  partners: BusinessPartner[];
  salesInvoices: SalesInvoice[];
  purchaseOrders: PurchaseOrder[];
  accounts?: AccountMaster[];
  isPeriodClosed?: boolean;
  onAddPartner: (p: BusinessPartner) => void;
  onUpdatePartner?: (p: BusinessPartner) => void;
  onAddJournalLines?: (lines: ACDOCALine[]) => boolean;
  onAddInvoice?: (inv: SalesInvoice) => void;
  onUpdateInvoice?: (inv: SalesInvoice) => void;
  onAddPO?: (po: PurchaseOrder) => void;
  onUpdatePO?: (po: PurchaseOrder) => void;
  onOpenStatements?: () => void;
}

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export const BusinessPartnersSection: React.FC<BusinessPartnersSectionProps> = ({
  currentClient,
  currentUser,
  partners,
  salesInvoices,
  purchaseOrders,
  accounts = [],
  isPeriodClosed = false,
  onAddPartner,
  onUpdatePartner,
  onAddJournalLines,
  onAddInvoice,
  onUpdateInvoice,
  onAddPO,
  onUpdatePO,
  onOpenStatements,
}) => {
  const canRegister = currentUser?.role !== 'auditor' && currentUser?.status !== 'restricted' && currentUser?.status !== 'suspended';
  const canPost = canRegister && currentUser?.permissions?.canPostJournals !== false;
  const [filterType, setFilterType] = useState<'ALL' | 'Vendor' | 'Customer'>('ALL');
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingPartner, setEditingPartner] = useState<BusinessPartner | null>(null);
  const [creditPartner, setCreditPartner] = useState<BusinessPartner | null>(null);
  const [feedback, setFeedback] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);

  // Registration / Edit form states
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [type, setType] = useState<'Vendor' | 'Customer'>('Vendor');
  const [tin, setTin] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [vatWithholdingAgent, setVatWithholdingAgent] = useState(false);
  const [vatWithholdingRate, setVatWithholdingRate] = useState(7);
  const [cstApplicable, setCstApplicable] = useState(false);
  const [tourismLevyApplicable, setTourismLevyApplicable] = useState(false);
  const [isVatRegistered, setIsVatRegistered] = useState(true);
  const [creditLimit, setCreditLimit] = useState(0);
  const [creditTermsDays, setCreditTermsDays] = useState(30);
  const [paymentTerms, setPaymentTerms] = useState('Net 30 days from invoice date');
  const [creditStatus, setCreditStatus] = useState<'Active' | 'On Hold' | 'Blocked'>('Active');
  const [openingBalance, setOpeningBalance] = useState(0);

  // Credit / Memo modal state
  const [memoAction, setMemoAction] = useState<'settle_doc' | 'customer_deposit' | 'additional_bill'>('settle_doc');
  const [targetDocId, setTargetDocId] = useState('');
  const [memoAmount, setMemoAmount] = useState(0);
  const [memoAccountNo, setMemoAccountNo] = useState('');
  const [memoReason, setMemoReason] = useState('');

  const flash = (tone: 'ok' | 'err', text: string) => {
    setFeedback({ tone, text });
    setTimeout(() => setFeedback(null), 8000);
  };

  // Live receivables / payables balances per partner
  const balances = useMemo(() => {
    const map: Record<string, number> = {};
    salesInvoices.forEach((i) => {
      if (i.status === 'Open' || i.status === 'Partial') {
        const due = Math.max(0, round2(i.totalReceivable - (i.paidAmount || 0)));
        map[`Customer:${i.customerName}`] = round2((map[`Customer:${i.customerName}`] || 0) + due);
      }
    });
    purchaseOrders.forEach((p) => {
      if (p.status === 'Invoiced') {
        const due = Math.max(0, round2(p.totalAmount - (p.paidAmount || 0)));
        map[`Vendor:${p.vendorName}`] = round2((map[`Vendor:${p.vendorName}`] || 0) + due);
      }
    });
    return map;
  }, [salesInvoices, purchaseOrders]);

  const filtered = partners.filter((p) => {
    const matchType = filterType === 'ALL' || p.type === filterType;
    const q = search.toLowerCase();
    const matchSearch =
      p.code.toLowerCase().includes(q) ||
      p.name.toLowerCase().includes(q) ||
      p.tin.toLowerCase().includes(q);
    return matchType && matchSearch;
  });

  const stats = useMemo(() => {
    const customers = partners.filter((p) => p.type === 'Customer');
    const vendors = partners.filter((p) => p.type === 'Vendor');
    const totalAr = customers.reduce((s, p) => s + (balances[`${p.type}:${p.name}`] || 0), 0);
    const totalAp = vendors.reduce((s, p) => s + (balances[`${p.type}:${p.name}`] || 0), 0);
    const restricted = partners.filter((p) => p.creditStatus === 'On Hold' || p.creditStatus === 'Blocked').length;
    const overLimit = partners.filter((p) => (p.creditLimit ?? 0) > 0 && (balances[`${p.type}:${p.name}`] || 0) > (p.creditLimit ?? 0)).length;
    return { customers: customers.length, vendors: vendors.length, totalAr, totalAp, restricted, overLimit };
  }, [partners, balances]);

  const resetForm = () => {
    setCode('');
    setName('');
    setType('Vendor');
    setTin('');
    setEmail('');
    setPhone('');
    setAddress('');
    setVatWithholdingAgent(false);
    setVatWithholdingRate(7);
    setCstApplicable(false);
    setTourismLevyApplicable(false);
    setIsVatRegistered(true);
    setCreditLimit(0);
    setCreditTermsDays(30);
    setPaymentTerms('Net 30 days from invoice date');
    setCreditStatus('Active');
    setOpeningBalance(0);
  };

  const openCreateModal = () => {
    setEditingPartner(null);
    resetForm();
    setCode(`V${String(partners.length + 1).padStart(3, '0')}`);
    setShowModal(true);
  };

  const openEditModal = (p: BusinessPartner) => {
    setEditingPartner(p);
    setCode(p.code);
    setName(p.name);
    setType(p.type);
    setTin(p.tin);
    setEmail(p.email);
    setPhone(p.phone);
    setAddress(p.address);
    setVatWithholdingAgent(Boolean(p.isVatWithholdingAgent));
    setVatWithholdingRate(p.vatWithholdingRate ?? 7);
    setCstApplicable(Boolean(p.isCstApplicable));
    setTourismLevyApplicable(Boolean(p.isTourismLevyApplicable));
    setIsVatRegistered(p.isVatRegistered ?? true);
    setCreditLimit(p.creditLimit ?? 0);
    setCreditTermsDays(p.creditTermsDays ?? 30);
    setPaymentTerms(p.paymentTerms || 'Net 30 days from invoice date');
    setCreditStatus(p.creditStatus || 'Active');
    setOpeningBalance(p.openingBalance ?? 0);
    setShowModal(true);
  };

  const openCreditModal = (p: BusinessPartner) => {
    setCreditPartner(p);
    if (p.type === 'Customer') {
      const openInvs = salesInvoices.filter((i) => i.customerName === p.name && (i.status === 'Open' || i.status === 'Partial'));
      setMemoAction(openInvs.length ? 'settle_doc' : 'customer_deposit');
      setTargetDocId(openInvs[0]?.id || '');
      const firstOpen = openInvs[0];
      setMemoAmount(firstOpen ? round2(firstOpen.totalReceivable - (firstOpen.paidAmount || 0)) : 0);
      const revAcc = accounts.find((a) => a.active && a.type === 'Income' && a.accountNo === '400000')
        || accounts.find((a) => a.active && a.type === 'Income');
      setMemoAccountNo(revAcc?.accountNo || '400000');
    } else {
      const openPos = purchaseOrders.filter((o) => o.vendorName === p.name && o.status === 'Invoiced');
      setMemoAction(openPos.length ? 'settle_doc' : 'additional_bill');
      setTargetDocId(openPos[0]?.id || '');
      const firstOpen = openPos[0];
      setMemoAmount(firstOpen ? round2(firstOpen.totalAmount - (firstOpen.paidAmount || 0)) : 0);
      const expAcc = accounts.find((a) => a.active && a.type === 'Expense' && a.accountNo === '621000')
        || accounts.find((a) => a.active && a.type === 'Expense');
      setMemoAccountNo(expAcc?.accountNo || '621000');
    }
    setMemoReason('');
  };

  const handleSavePartner = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canRegister) return;
    const cleanName = name.trim();
    const cleanCode = (code.trim() || `${type === 'Vendor' ? 'V' : 'C'}${String(partners.length + 1).padStart(3, '0')}`).toUpperCase();
    if (!cleanName) return;

    const duplicateCode = partners.some((p) => p.code.toUpperCase() === cleanCode && p.id !== editingPartner?.id);
    if (duplicateCode) {
      flash('err', `Partner code ${cleanCode} is already assigned in ${currentClient.code}. Choose a unique code.`);
      return;
    }

    const cleanOpening = Math.max(0, round2(Number(openingBalance) || 0));
    const basePartner: BusinessPartner = {
      id: editingPartner?.id || uniqueId('ID'),
      clientId: currentClient.id,
      code: cleanCode,
      name: cleanName,
      type,
      tin: tin.trim(),
      email: email.trim(),
      phone: phone.trim(),
      address: address.trim(),
      currency: editingPartner?.currency || currentClient.currency,
      isVatWithholdingAgent: vatWithholdingAgent,
      vatWithholdingRate: vatWithholdingAgent ? vatWithholdingRate : undefined,
      isCstApplicable: cstApplicable,
      isTourismLevyApplicable: tourismLevyApplicable,
      isVatRegistered,
      creditLimit: Math.max(0, round2(Number(creditLimit) || 0)),
      creditTermsDays: Math.min(365, Math.max(0, Math.round(Number(creditTermsDays) || 0))),
      paymentTerms: paymentTerms.trim(),
      creditStatus,
      openingBalance: cleanOpening,
    };

    if (editingPartner) {
      if (!onUpdatePartner) return;
      onUpdatePartner(basePartner);
      setShowModal(false);
      flash('ok', `${basePartner.type} ${basePartner.name} (${basePartner.code}) updated — credit limit ${formatGHS(basePartner.creditLimit || 0)}, standing: ${basePartner.creditStatus}.`);
      return;
    }

    // If registering a new partner with an opening balance, post the take-on
    // journal AND register the matching open invoice/PO so Control Accounts
    // (110000 AR / 200000 AP) stay reconciled to the pesewa.
    if (cleanOpening > 0) {
      if (isPeriodClosed) {
        flash('err', 'Cannot post partner opening balance: the current accounting period is closed.');
        return;
      }
      if (!canPost || !onAddJournalLines || (type === 'Customer' ? !onAddInvoice : !onAddPO)) {
        flash('err', 'Cannot post opening balance from this desk. Register with 0.00 opening balance and post via Opening Balances Setup.');
        return;
      }
      const date = localToday();
      const period = date.slice(0, 7);
      const user = currentUser?.username || 'system';
      if (type === 'Customer') {
        const docNo = `OB-AR-${cleanCode}-${docSuffix()}`;
        const posted = onAddJournalLines([
          {
            id: `${uniqueId('JL-OBAR')}-1`, docNo, period, date, module: 'SD', docType: 'INV',
            accountNo: '110000', accountName: `Trade Receivables (${cleanName})`, costCenter: 'CC-SLS',
            debit: cleanOpening, credit: 0, currency: currentClient.currency,
            description: `Opening customer balance for ${cleanName} (${cleanCode})`, createdBy: user, clientId: currentClient.id,
          },
          {
            id: `${uniqueId('JL-OBAR')}-2`, docNo, period, date, module: 'SD', docType: 'INV',
            accountNo: OPENING_EQUITY_ACCOUNT, accountName: 'Opening Balance Equity', costCenter: 'CC-ADM',
            debit: 0, credit: cleanOpening, currency: currentClient.currency,
            description: `Opening balance take-on for customer ${cleanName}`, createdBy: user, clientId: currentClient.id,
          },
        ]);
        if (!posted) {
          flash('err', `Partner opening balance not posted: ${refusalReason('check open period and maker limit')}`);
          return;
        }
        onAddInvoice?.({
          id: uniqueId('INV-OB'),
          clientId: currentClient.id,
          invNo: docNo,
          customerName: cleanName,
          revenueStream: 'Opening Balance Brought Forward',
          netRevenue: 0, // Take-on opens a receivable against equity; it is not a sale.
          vatOutput: 0,
          totalReceivable: cleanOpening,
          paidAmount: 0,
          status: 'Open',
          date,
        });
      } else {
        const docNo = `OB-AP-${cleanCode}-${docSuffix()}`;
        const posted = onAddJournalLines([
          {
            id: `${uniqueId('JL-OBAP')}-1`, docNo, period, date, module: 'MM', docType: 'PO',
            accountNo: OPENING_EQUITY_ACCOUNT, accountName: 'Opening Balance Equity', costCenter: 'CC-ADM',
            debit: cleanOpening, credit: 0, currency: currentClient.currency,
            description: `Opening balance take-on for vendor ${cleanName}`, createdBy: user, clientId: currentClient.id,
          },
          {
            id: `${uniqueId('JL-OBAP')}-2`, docNo, period, date, module: 'MM', docType: 'PO',
            accountNo: '200000', accountName: `Trade Payables (${cleanName})`, costCenter: 'CC-OPS',
            debit: 0, credit: cleanOpening, currency: currentClient.currency,
            description: `Opening vendor balance for ${cleanName} (${cleanCode})`, createdBy: user, clientId: currentClient.id,
          },
        ]);
        if (!posted) {
          flash('err', `Partner opening balance not posted: ${refusalReason('check open period and maker limit')}`);
          return;
        }
        onAddPO?.({
          id: uniqueId('PO-OB'),
          clientId: currentClient.id,
          poNo: docNo,
          vendorName: cleanName,
          itemType: 'service',
          itemDescription: 'Opening Balance Brought Forward',
          qty: 1,
          unitPrice: cleanOpening,
          vatRecoverable: 0,
          totalAmount: cleanOpening,
          paidAmount: 0,
          status: 'Invoiced',
          date,
          currency: currentClient.currency,
          netAmount: cleanOpening,
          glAccount: OPENING_EQUITY_ACCOUNT,
          glAccountName: 'Opening Balance Equity',
          costCenter: 'CC-ADM',
          costCenterName: 'Administration',
        });
      }
    }

    onAddPartner(basePartner);
    setShowModal(false);
    resetForm();
    flash('ok', `Registered ${basePartner.type} ${basePartner.name} (${basePartner.code})${cleanOpening > 0 ? ` with opening balance ${formatGHS(cleanOpening)} posted to the ledger` : ''}.`);
  };

  const handleSubmitCreditMemo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!creditPartner || !canPost) return;
    if (isPeriodClosed) {
      flash('err', 'Posting refused: the current accounting period is closed.');
      return;
    }
    if (!onAddJournalLines) {
      flash('err', 'Journal posting is unavailable in this workspace.');
      return;
    }
    const amt = round2(Number(memoAmount) || 0);
    if (amt <= 0) {
      flash('err', 'Amount must be greater than zero.');
      return;
    }
    if (!memoReason.trim()) {
      flash('err', 'Enter a reason / reference for this credit or adjustment.');
      return;
    }

    const date = localToday();
    const period = date.slice(0, 7);
    const user = currentUser?.username || 'system';
    const chosenAccount = accounts.find((a) => a.accountNo === memoAccountNo && a.active);
    if (!chosenAccount) {
      flash('err', 'Select an active GL account from the Chart of Accounts.');
      return;
    }

    if (creditPartner.type === 'Customer') {
      if (memoAction === 'settle_doc') {
        const inv = salesInvoices.find((i) => i.id === targetDocId);
        if (!inv) {
          flash('err', 'Select an open customer invoice to credit.');
          return;
        }
        const outstanding = round2(inv.totalReceivable - (inv.paidAmount || 0));
        if (amt > outstanding + 0.009) {
          flash('err', `Credit amount ${formatGHS(amt)} exceeds invoice ${inv.invNo} outstanding balance of ${formatGHS(outstanding)}.`);
          return;
        }
        const docNo = `CN-BP-${currentYear()}-${docSuffix()}`;
        const posted = onAddJournalLines([
          {
            id: `${uniqueId('JL-BPCR')}-1`, docNo, period, date, module: 'SD', docType: 'REV',
            accountNo: chosenAccount.accountNo, accountName: chosenAccount.name, costCenter: 'CC-SLS',
            debit: amt, credit: 0, currency: currentClient.currency,
            description: `Customer credit memo for ${inv.invNo} — ${memoReason.trim()}`,
            reference: inv.invNo, createdBy: user, clientId: currentClient.id,
          },
          {
            id: `${uniqueId('JL-BPCR')}-2`, docNo, period, date, module: 'SD', docType: 'REV',
            accountNo: '110000', accountName: `Trade Receivables (${creditPartner.name})`, costCenter: 'CC-SLS',
            debit: 0, credit: amt, currency: currentClient.currency,
            description: `Credit applied against ${inv.invNo} (${creditPartner.name})`,
            reference: inv.invNo, createdBy: user, clientId: currentClient.id,
          },
        ]);
        if (!posted) {
          flash('err', `Customer credit memo not posted: ${refusalReason('check open period and maker limit')}`);
          return;
        }
        const nextPaid = Math.min(inv.totalReceivable, round2((inv.paidAmount || 0) + amt));
        onUpdateInvoice?.({
          ...inv,
          paidAmount: nextPaid,
          status: nextPaid + 0.009 >= inv.totalReceivable ? 'Paid' : 'Partial',
        });
        setCreditPartner(null);
        flash('ok', `Customer credit memo ${docNo} (${formatGHS(amt)}) posted against ${inv.invNo}.`);
        return;
      }

      // Standalone customer credit / refundable credit balance (217000)
      const docNo = `CCRD-${currentYear()}-${docSuffix()}`;
      const posted = onAddJournalLines([
        {
          id: `${uniqueId('JL-BPCADV')}-1`, docNo, period, date, module: 'SD', docType: 'JE',
          accountNo: chosenAccount.accountNo, accountName: chosenAccount.name, costCenter: 'CC-SLS',
          debit: amt, credit: 0, currency: currentClient.currency,
          description: `Customer credit granted to ${creditPartner.name} — ${memoReason.trim()}`,
          reference: creditPartner.code, createdBy: user, clientId: currentClient.id,
        },
        {
          id: `${uniqueId('JL-BPCADV')}-2`, docNo, period, date, module: 'SD', docType: 'JE',
          accountNo: '217000', accountName: `Refundable Tenant & Customer Deposits (${creditPartner.name})`, costCenter: 'CC-SLS',
          debit: 0, credit: amt, currency: currentClient.currency,
          description: `Customer credit balance for ${creditPartner.name} (${creditPartner.code})`,
          reference: creditPartner.code, createdBy: user, clientId: currentClient.id,
        },
      ]);
      if (!posted) {
        flash('err', `Customer credit not posted: ${refusalReason('check open period and maker limit')}`);
        return;
      }
      setCreditPartner(null);
      flash('ok', `Customer credit ${docNo} of ${formatGHS(amt)} recorded on ${creditPartner.name} (GL 217000).`);
      return;
    }

    // Vendor side
    if (memoAction === 'settle_doc') {
      const po = purchaseOrders.find((o) => o.id === targetDocId);
      if (!po) {
        flash('err', 'Select an invoiced purchase order to adjust.');
        return;
      }
      const outstanding = round2(po.totalAmount - (po.paidAmount || 0));
      if (amt > outstanding + 0.009) {
        flash('err', `Credit / debit memo ${formatGHS(amt)} exceeds ${po.poNo} outstanding payable of ${formatGHS(outstanding)}.`);
        return;
      }
      const docNo = `DN-BP-${currentYear()}-${docSuffix()}`;
      const posted = onAddJournalLines([
        {
          id: `${uniqueId('JL-BPVDR')}-1`, docNo, period, date, module: 'MM', docType: 'REV',
          accountNo: '200000', accountName: `Trade Payables (${creditPartner.name})`, costCenter: po.costCenter,
          debit: amt, credit: 0, currency: currentClient.currency,
          description: `Vendor credit / debit memo reducing ${po.poNo} — ${memoReason.trim()}`,
          reference: po.poNo, createdBy: user, clientId: currentClient.id,
        },
        {
          id: `${uniqueId('JL-BPVDR')}-2`, docNo, period, date, module: 'MM', docType: 'REV',
          accountNo: chosenAccount.accountNo, accountName: chosenAccount.name, costCenter: po.costCenter,
          debit: 0, credit: amt, currency: currentClient.currency,
          description: `Vendor credit recovery on ${po.poNo} (${creditPartner.name})`,
          reference: po.poNo, createdBy: user, clientId: currentClient.id,
        },
      ]);
      if (!posted) {
        flash('err', `Vendor credit memo not posted: ${refusalReason('check open period and maker limit')}`);
        return;
      }
      const nextPaid = Math.min(po.totalAmount, round2((po.paidAmount || 0) + amt));
      onUpdatePO?.({
        ...po,
        paidAmount: nextPaid,
        status: nextPaid + 0.009 >= po.totalAmount ? 'Paid' : 'Invoiced',
      });
      setCreditPartner(null);
      flash('ok', `Vendor credit memo ${docNo} (${formatGHS(amt)}) posted against ${po.poNo}.`);
      return;
    }

    // Credit vendor account (recognise a supplier credit / payable bill)
    const docNo = `VCR-${currentYear()}-${docSuffix()}`;
    const posted = onAddJournalLines([
      {
        id: `${uniqueId('JL-BPVCR')}-1`, docNo, period, date, module: 'MM', docType: 'PO',
        accountNo: chosenAccount.accountNo, accountName: chosenAccount.name, costCenter: 'CC-OPS',
        debit: amt, credit: 0, currency: currentClient.currency,
        description: `Vendor payable credited to ${creditPartner.name} — ${memoReason.trim()}`,
        reference: creditPartner.code, createdBy: user, clientId: currentClient.id,
      },
      {
        id: `${uniqueId('JL-BPVCR')}-2`, docNo, period, date, module: 'MM', docType: 'PO',
        accountNo: '200000', accountName: `Trade Payables (${creditPartner.name})`, costCenter: 'CC-OPS',
        debit: 0, credit: amt, currency: currentClient.currency,
        description: `Payable recognised for ${creditPartner.name} (${creditPartner.code})`,
        reference: creditPartner.code, createdBy: user, clientId: currentClient.id,
      },
    ]);
    if (!posted) {
      flash('err', `Vendor payable credit not posted: ${refusalReason('check open period and maker limit')}`);
      return;
    }
    onAddPO?.({
      id: uniqueId('PO-CR'),
      clientId: currentClient.id,
      poNo: docNo,
      vendorName: creditPartner.name,
      itemType: 'service',
      itemDescription: memoReason.trim(),
      qty: 1,
      unitPrice: amt,
      vatRecoverable: 0,
      totalAmount: amt,
      paidAmount: 0,
      status: 'Invoiced',
      date,
      currency: currentClient.currency,
      netAmount: amt,
      glAccount: chosenAccount.accountNo,
      glAccountName: chosenAccount.name,
      costCenter: 'CC-OPS',
      costCenterName: 'Operations Center',
    });
    setCreditPartner(null);
    flash('ok', `Credited vendor ${creditPartner.name} with ${formatGHS(amt)} payable (${docNo}). Available for settlement at Payment Desk.`);
  };

  const handleExportCsv = () => downloadCsv(`${currentClient.code}_Business_Partners.csv`, [
    ['BPCode', 'PartnerName', 'Type', 'TIN', 'Email', 'Phone', 'Address', 'Currency', 'CurrentBalance', 'CreditLimit', 'CreditTermsDays', 'PaymentTerms', 'CreditStatus', 'OpeningBalance'],
    ...partners.map((p) => [p.code, p.name, p.type, p.tin, p.email, p.phone, p.address, p.currency, balances[`${p.type}:${p.name}`] || 0,
      p.creditLimit, p.creditTermsDays, p.paymentTerms, p.creditStatus || 'Active', p.openingBalance]),
  ]);

  const customerOpenInvoices = creditPartner?.type === 'Customer'
    ? salesInvoices.filter((i) => i.customerName === creditPartner.name && (i.status === 'Open' || i.status === 'Partial'))
    : [];
  const vendorOpenOrders = creditPartner?.type === 'Vendor'
    ? purchaseOrders.filter((o) => o.vendorName === creditPartner.name && o.status === 'Invoiced')
    : [];

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`BP · Customers & Vendors Master · ${currentClient.code}`}
        title="Customers & Vendors Directory (Registration & Credit Control)"
        desc="Register customers and vendors, grant or restrict credit limits and payment terms, post opening balances, and issue credit/debit adjustments."
      >
        <div className="flex flex-wrap gap-2">
          <ModulePrintButton title={`Customers & vendors directory — ${currentClient.name}`} subtitle="Credit limits, terms, and open balances" />
          {onOpenStatements && <button type="button" onClick={onOpenStatements} className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50"><FileSpreadsheet className="h-4 w-4 text-[#006f98]" /> Statements of account</button>}
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-700" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={openCreateModal}
            disabled={!canRegister}
            className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
          >
            <Plus className="h-4 w-4" />
            <span>Register Customer / Vendor</span>
          </button>
        </div>
      </PageHeader>

      {feedback && (
        <div className={`rounded-lg border p-3 text-xs font-bold ${feedback.tone === 'err' ? 'border-rose-300 bg-rose-50 text-rose-900' : 'border-emerald-300 bg-emerald-50 text-emerald-900'}`}>
          {feedback.text}
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Customers / AR" value={`${ccy()} ${formatGHS(stats.totalAr)}`} sub={`${stats.customers} registered customer(s)`} tone="text-emerald-700" />
        <Stat label="Vendors / AP" value={`${ccy()} ${formatGHS(stats.totalAp)}`} sub={`${stats.vendors} registered vendor(s)`} tone="text-rose-700" />
        <Stat label="Credit restricted" value={stats.restricted} sub="On Hold or Blocked" tone={stats.restricted > 0 ? 'text-amber-700' : undefined} />
        <Stat label="Over credit limit" value={stats.overLimit} sub="Require review or collection" tone={stats.overLimit > 0 ? 'text-rose-700' : undefined} />
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-white p-3 rounded-xl border border-sky-200 shadow-xs">
        <div className="flex items-center gap-1">
          {(['ALL', 'Vendor', 'Customer'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1.5 rounded-lg font-bold transition ${
                filterType === t
                  ? 'bg-[#082f4f] text-white shadow-xs'
                  : 'bg-sky-50 text-[#355875] hover:bg-sky-100'
              }`}
            >
              {t === 'ALL' ? 'All Partners' : t === 'Vendor' ? 'Vendors / Suppliers' : 'Customers / Clients'}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-sky-400" />
          <input
            type="text"
            placeholder="Search partner, TIN, code..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-56 sm:w-64 rounded-lg border border-sky-300 bg-white pl-8 pr-3 py-1.5 text-xs text-[#082f4f] outline-none focus:border-[#082f4f]"
          />
        </div>
      </div>

      {/* Partners Table */}
      <Card title={`Registered Customers & Vendors (${filtered.length})`} sub="Credit terms, limits, and open ledger exposure integrated across Sales, Procurement & Payment Desks">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[920px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Code</th>
                <th className={thCls}>Company / Trading Name</th>
                <th className={thCls}>Category</th>
                <th className={thCls}>Tax TIN</th>
                <th className={thCls}>Contact</th>
                <th className={thCls}>Credit terms</th>
                <th className={thCls + ' text-right'}>Open Balance ({ccy()})</th>
                <th className={thCls}>Credit standing</th>
                <th className={thCls + ' text-center'}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => {
                const bal = balances[`${p.type}:${p.name}`] || 0;
                const over = (p.creditLimit ?? 0) > 0 && bal > (p.creditLimit ?? 0);
                return (
                  <tr key={p.id} className={rowCls}>
                    <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{p.code}</td>
                    <td className="px-3 py-2 font-bold text-[#082f4f]">
                      {p.name}
                      {p.isVatWithholdingAgent && <span className="ml-1.5 rounded bg-amber-100 px-1.5 py-0.5 text-[9.5px] font-bold text-[#855b00]">WHT Agent</span>}
                    </td>
                    <td className="px-3 py-2">
                      <span className={`rounded px-2 py-0.5 text-[10.5px] font-bold ${
                        p.type === 'Vendor'
                          ? 'bg-sky-100 text-[#006f98] border border-sky-300'
                          : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      }`}>
                        {p.type === 'Vendor' ? 'Vendor (AP)' : 'Customer (AR)'}
                      </span>
                    </td>
                    <td className="px-3 py-2 font-mono text-[11px] text-[#355875]">{p.tin || '—'}</td>
                    <td className="px-3 py-2 text-[#355875] text-[11px]">
                      <div>{p.phone || p.email || '—'}</div>
                      <div className="text-[10px] text-slate-400">{p.address}</div>
                    </td>
                    <td className="px-3 py-2 text-[#355875]">
                      <div className="font-mono text-[11px] text-[#082f4f]">
                        {p.creditLimit && p.creditLimit > 0 ? `Limit ${formatGHS(p.creditLimit)}` : 'Cash on delivery'}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {p.creditTermsDays ? `${p.creditTermsDays}-day terms` : 'No credit period'}
                        {p.paymentTerms ? ` · ${p.paymentTerms}` : ''}
                      </div>
                    </td>
                    <td className={numCls + ` font-mono font-bold ${
                      p.type === 'Vendor' && bal > 0 ? 'text-rose-700' :
                      p.type === 'Customer' && bal > 0 ? 'text-emerald-700' : 'text-[#355875]'
                    }`}>
                      {bal > 0 ? formatGHS(bal) : '0.00'}
                    </td>
                    <td className="px-3 py-2">
                      <span className={`rounded px-2 py-0.5 text-[10.5px] font-bold ${
                        p.creditStatus === 'Blocked' ? 'bg-rose-100 text-rose-800 border border-rose-300' :
                        p.creditStatus === 'On Hold' ? 'bg-amber-100 text-[#855b00] border border-amber-300' :
                        'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      }`}>
                        {p.creditStatus || 'Active'}
                      </span>
                      {over && (
                        <span className="ml-1 inline-flex items-center gap-0.5 rounded bg-rose-100 px-1.5 py-0.5 text-[9.5px] font-bold text-rose-800">
                          <ShieldAlert className="h-2.5 w-2.5" /> Over limit
                        </span>
                      )}
                      {p.creditLimit && p.creditLimit > 0 ? (
                        <div className="mt-1">
                          <div className="h-1.5 w-24 overflow-hidden rounded-full bg-slate-200">
                            <div
                              className={`h-full rounded-full ${bal / p.creditLimit > 0.9 ? 'bg-rose-500' : bal / p.creditLimit > 0.7 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                              style={{ width: `${Math.min(100, Math.round((bal / p.creditLimit) * 100))}%` }}
                            />
                          </div>
                          <div className="mt-0.5 text-[10px] text-slate-400">
                            {Math.round((bal / p.creditLimit) * 100)}% of limit used
                          </div>
                        </div>
                      ) : (
                        <div className="mt-1 text-[10px] text-slate-400">No credit granted</div>
                      )}
                    </td>
                    <td className="px-3 py-2 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {canRegister && onUpdatePartner && (
                          <button
                            type="button"
                            onClick={() => openEditModal(p)}
                            className="inline-flex items-center gap-1 rounded border border-sky-300 bg-white px-2 py-1 text-[10.5px] font-bold text-[#082f4f] hover:bg-sky-50"
                            title="Edit profile & grant/update credit limit"
                          >
                            <Pencil className="h-3 w-3" /> Edit / Credit
                          </button>
                        )}
                        {canPost && onAddJournalLines && (p.type === 'Customer' ? onUpdateInvoice : onUpdatePO) && (
                          <button
                            type="button"
                            onClick={() => openCreditModal(p)}
                            className="inline-flex items-center gap-1 rounded border border-emerald-300 bg-emerald-50 px-2 py-1 text-[10.5px] font-bold text-emerald-800 hover:bg-emerald-100"
                            title="Issue credit note, deposit, or payable adjustment"
                          >
                            <Receipt className="h-3 w-3" /> Credit / Memo
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Register / Edit Partner Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
          <form onSubmit={handleSavePartner} className="w-full max-w-xl rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs my-8">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">
              {editingPartner ? `Edit ${editingPartner.type} & Credit Terms — ${editingPartner.code}` : 'Register Customer or Vendor'}
            </h3>
            <div className="space-y-3 max-h-[72vh] overflow-y-auto pr-1">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Partner Type</label>
                  <select
                    value={type}
                    disabled={!!editingPartner}
                    onChange={(e) => {
                      const nextType = e.target.value as 'Vendor' | 'Customer';
                      setType(nextType);
                      if (!editingPartner) setCode(`${nextType === 'Vendor' ? 'V' : 'C'}${String(partners.length + 1).padStart(3, '0')}`);
                    }}
                    className="w-full rounded border border-sky-300 px-2 py-2 outline-none font-bold text-[#082f4f] disabled:bg-slate-100"
                  >
                    <option value="Vendor">Vendor / Supplier (AP)</option>
                    <option value="Customer">Customer / Client (AR)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Partner Code</label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono font-bold text-[#082f4f]"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Legal Company / Business Name</label>
                <input
                  type="text"
                  placeholder="e.g. Takoradi Power Solutions Ltd"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Tax TIN Number</label>
                  <input
                    type="text"
                    placeholder="e.g. C001928381"
                    value={tin}
                    onChange={(e) => setTin(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono text-[#082f4f]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Contact Phone</label>
                  <input
                    type="text"
                    placeholder="+233 30 200 0000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none text-[#082f4f]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Billing Email</label>
                  <input
                    type="email"
                    placeholder="accounts@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none text-[#082f4f]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Physical Address</label>
                  <input
                    type="text"
                    placeholder="Street address, city, region"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none text-[#082f4f]"
                  />
                </div>
              </div>

              <div className="rounded-lg border border-sky-200 bg-sky-50 p-3 space-y-2">
                <span className="block font-bold text-[#082f4f] text-[11px] uppercase tracking-wider">Tax attributes</span>
                <label className="flex items-center gap-2 text-[#2d4f6d] font-semibold"><input type="checkbox" checked={isVatRegistered} onChange={(e) => setIsVatRegistered(e.target.checked)} /> VAT-registered (bills carry VAT)</label>
                <label className="flex items-center gap-2 text-[#2d4f6d] font-semibold"><input type="checkbox" checked={vatWithholdingAgent} onChange={(e) => setVatWithholdingAgent(e.target.checked)} /> Appointed VAT withholding agent</label>
                {vatWithholdingAgent && <label className="block text-[#2d4f6d] font-semibold">VAT WHT rate %<input type="number" min="0" max="100" step="0.01" value={vatWithholdingRate} onChange={(e) => setVatWithholdingRate(Number(e.target.value))} className="ml-2 w-20 rounded border border-sky-300 px-2 py-1 font-mono" /></label>}
                <label className="flex items-center gap-2 text-[#2d4f6d] font-semibold"><input type="checkbox" checked={cstApplicable} onChange={(e) => setCstApplicable(e.target.checked)} /> CST applicable (Class 1 communications provider only)</label>
                <label className="flex items-center gap-2 text-[#2d4f6d] font-semibold"><input type="checkbox" checked={tourismLevyApplicable} onChange={(e) => setTourismLevyApplicable(e.target.checked)} /> Tourism levy applicable</label>
              </div>

              <div className="rounded-lg border border-emerald-200 bg-emerald-50/60 p-3 space-y-2.5">
                <span className="block font-bold text-emerald-900 text-[11px] uppercase tracking-wider">Credit control &amp; payment terms</span>
                <p className="text-[10.5px] leading-relaxed text-emerald-900/80">
                  Leave the limit at {ccy()} 0.00 for cash-on-delivery terms. The limit and standing inform credit checks. Manage posted receipts and supplier payments in the Payment Desk.
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <label className="block font-bold text-[#0a253e]">Credit limit ({ccy()})
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={creditLimit}
                      onChange={(e) => setCreditLimit(Number(e.target.value))}
                      className="mt-1 w-full rounded border border-emerald-300 px-3 py-2 font-mono outline-none focus:border-emerald-600"
                    />
                  </label>
                  <label className="block font-bold text-[#0a253e]">Credit terms (days)
                    <input
                      type="number"
                      min="0"
                      max="365"
                      value={creditTermsDays}
                      onChange={(e) => setCreditTermsDays(Number(e.target.value))}
                      className="mt-1 w-full rounded border border-emerald-300 px-3 py-2 font-mono outline-none focus:border-emerald-600"
                    />
                  </label>
                </div>
                <label className="block font-bold text-[#0a253e]">Payment terms shown on documents
                  <input
                    type="text"
                    value={paymentTerms}
                    onChange={(e) => setPaymentTerms(e.target.value)}
                    className="mt-1 w-full rounded border border-emerald-300 px-3 py-2 outline-none focus:border-emerald-600"
                  />
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <label className="block font-bold text-[#0a253e]">Credit status
                    <select
                      value={creditStatus}
                      onChange={(e) => setCreditStatus(e.target.value as 'Active' | 'On Hold' | 'Blocked')}
                      className="mt-1 w-full rounded border border-emerald-300 px-2 py-2 font-bold text-[#082f4f] outline-none"
                    >
                      <option value="Active">Active — credit allowed</option>
                      <option value="On Hold">On Hold — block new credit</option>
                      <option value="Blocked">Blocked — cash only</option>
                    </select>
                  </label>
                  {!editingPartner && canPost && (type === 'Customer' ? onAddInvoice : onAddPO) && (
                    <label className="block font-bold text-[#0a253e]">Opening balance take-on ({ccy()})
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={openingBalance}
                        onChange={(e) => setOpeningBalance(Number(e.target.value))}
                        className="mt-1 w-full rounded border border-emerald-300 px-3 py-2 font-mono outline-none focus:border-emerald-600"
                      />
                      <span className="mt-0.5 block text-[10px] font-normal text-emerald-900/75">If &gt; 0, posts balanced AR/AP opening journal + open item.</span>
                    </label>
                  )}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setShowModal(false)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 font-bold text-white">
                {editingPartner ? 'Update Partner' : 'Register Partner'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Credit / Debit Adjustment Modal */}
      {creditPartner && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleSubmitCreditMemo} className="w-full max-w-lg rounded-xl border border-emerald-300 bg-white p-6 shadow-xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">
              {creditPartner.type === 'Customer' ? 'Credit Customer' : 'Credit / Adjust Vendor'} — {creditPartner.name} ({creditPartner.code})
            </h3>
            <div className="space-y-3">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Action type</label>
                <select
                  value={memoAction}
                  onChange={(e) => setMemoAction(e.target.value as 'settle_doc' | 'customer_deposit' | 'additional_bill')}
                  className="w-full rounded border border-sky-300 px-2 py-2 font-bold text-[#082f4f]"
                >
                  {creditPartner.type === 'Customer' ? (
                    <>
                      <option value="settle_doc" disabled={!customerOpenInvoices.length}>
                        Issue Credit Memo against Open Invoice ({customerOpenInvoices.length} open)
                      </option>
                      <option value="customer_deposit">
                        Record Standalone Customer Credit / Advance (GL 217000)
                      </option>
                    </>
                  ) : (
                    <>
                      <option value="settle_doc" disabled={!vendorOpenOrders.length}>
                        Apply Vendor Credit / Debit Note against Open Bill ({vendorOpenOrders.length} open)
                      </option>
                      <option value="additional_bill">
                        Credit Vendor Payable Account (Raise Payable Bill on GL 200000)
                      </option>
                    </>
                  )}
                </select>
              </div>

              {memoAction === 'settle_doc' && (
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">
                    {creditPartner.type === 'Customer' ? 'Target Open Invoice' : 'Target Open Supplier Bill'}
                  </label>
                  <select
                    value={targetDocId}
                    onChange={(e) => {
                      const id = e.target.value;
                      setTargetDocId(id);
                      if (creditPartner.type === 'Customer') {
                        const inv = customerOpenInvoices.find((i) => i.id === id);
                        if (inv) setMemoAmount(round2(inv.totalReceivable - (inv.paidAmount || 0)));
                      } else {
                        const po = vendorOpenOrders.find((o) => o.id === id);
                        if (po) setMemoAmount(round2(po.totalAmount - (po.paidAmount || 0)));
                      }
                    }}
                    className="w-full rounded border border-sky-300 px-2 py-2 font-mono text-[#082f4f]"
                    required
                  >
                    {creditPartner.type === 'Customer'
                      ? customerOpenInvoices.map((i) => (
                          <option key={i.id} value={i.id}>
                            {i.invNo} · {i.date} · Open {formatGHS(i.totalReceivable - (i.paidAmount || 0))}
                          </option>
                        ))
                      : vendorOpenOrders.map((o) => (
                          <option key={o.id} value={o.id}>
                            {o.poNo} · {o.date} · Open {formatGHS(o.totalAmount - (o.paidAmount || 0))}
                          </option>
                        ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <label className="block font-bold text-[#0a253e]">Amount ({ccy()})
                  <input
                    type="number"
                    min="0.01"
                    step="0.01"
                    value={memoAmount || ''}
                    onChange={(e) => setMemoAmount(Number(e.target.value))}
                    className="mt-1 w-full rounded border border-sky-300 px-3 py-2 font-mono outline-none"
                    required
                  />
                </label>
                <label className="block font-bold text-[#0a253e]">Offsetting GL Account
                  <select
                    value={memoAccountNo}
                    onChange={(e) => setMemoAccountNo(e.target.value)}
                    className="mt-1 w-full rounded border border-sky-300 px-2 py-2 font-mono text-[#082f4f]"
                    required
                  >
                    {accounts.filter((a) => a.active).map((a) => (
                      <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>
                    ))}
                  </select>
                </label>
              </div>

              <label className="block font-bold text-[#0a253e]">Reason / Audit Reference
                <input
                  type="text"
                  placeholder="e.g. Volume rebate agreed, damaged goods credit, or supplier credit note ref"
                  value={memoReason}
                  onChange={(e) => setMemoReason(e.target.value)}
                  className="mt-1 w-full rounded border border-sky-300 px-3 py-2 outline-none"
                  required
                />
              </label>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setCreditPartner(null)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-emerald-700 px-4 py-1.5 font-bold text-white hover:bg-emerald-800">Post Credit Adjustment</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
