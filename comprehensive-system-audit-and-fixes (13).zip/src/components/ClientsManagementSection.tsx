import { configuredWorkspaceOrigin, isSandboxHostname, workspaceSignInPath } from '../lib/workspaceLink';
import React, { useState } from 'react';
import { ClientEntity, UserAccount } from '../types/accounting';
import { GHANA_ECONOMY_SECTORS, BPZ_SERVICE_LINES } from '../data/ghanaSectors';
import { persistentStorage } from '../utils/persistentStorage';
import { Card, PageHeader, thCls, rowCls } from './ui';
import {
  Plus,
  ArrowUpRight,
  Check,
  Key,
  Copy,
  Printer,
  ShieldCheck,
} from 'lucide-react';
import { apiFetch } from '../utils/session';
import { CLIENT_MODULE_CATALOG } from '../utils/moduleCatalog';
import { ccy } from '../utils/currency';

interface ClientsManagementSectionProps {
  currentClient: ClientEntity;
  clients: ClientEntity[];
  onAddClient: (newClient: ClientEntity) => void;
  onSwitchClient: (client: ClientEntity) => void;
  onOpenStatements?: () => void;
}

export const ClientsManagementSection: React.FC<ClientsManagementSectionProps> = ({
  currentClient,
  clients,
  onAddClient,
  onSwitchClient,
  onOpenStatements,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [createBusy, setCreateBusy] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);
  const [credentialReceipt, setCredentialReceipt] = useState<{
    client: ClientEntity;
    user: UserAccount;
    pass: string;
  } | null>(null);

  // New Client Form
  const [name, setName] = useState('');
  const [code, setCode] = useState(`CLI-00${clients.length + 1}`);
  const [selectedSectorCode, setSelectedSectorCode] = useState<string>(GHANA_ECONOMY_SECTORS[0].code);
  const [currency, setCurrency] = useState('GHS');
  const [regNumber, setRegNumber] = useState('');

  // Assigned Services selection
  const [selectedServices, setSelectedServices] = useState<string[]>([
    'bookkeeping',
    'payroll',
    'tax_compliance',
    'management_accounts',
    'ifrs_reporting',
  ]);

  // Client Admin Credentials Setup
  const [adminFullName, setAdminFullName] = useState('');
  const [adminUsername, setAdminUsername] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(true);
  const [adminAllowedModules, setAdminAllowedModules] = useState<string[] | undefined>(undefined);
  const [adminMakerLimit, setAdminMakerLimit] = useState(50000);
  const [adminRole, setAdminRole] = useState<'accountant' | 'manager'>('manager');

  // Inline password reset & module restriction editor in the View Login receipt modal
  const [resetPassInput, setResetPassInput] = useState('');
  const [resetBusy, setResetBusy] = useState(false);
  const [resetFeedback, setResetFeedback] = useState<{ ok: boolean; text: string } | null>(null);

  const [copiedLink, setCopiedLink] = useState(false);

  const activeSector = GHANA_ECONOMY_SECTORS.find((s) => s.code === selectedSectorCode) || GHANA_ECONOMY_SECTORS[0];

  const handleToggleService = (serviceId: string) => {
    if (selectedServices.includes(serviceId)) {
      setSelectedServices(selectedServices.filter((s) => s !== serviceId));
    } else {
      setSelectedServices([...selectedServices, serviceId]);
    }
  };

  const handleCreateClient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (createBusy) return;
    setCreateError(null);
    setCreateBusy(true);
    try {
      const response = await apiFetch('/api/clients', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          client: {
            code: code.trim().toUpperCase(),
            name: name.trim(),
            sector: activeSector.name,
            currency,
            jurisdiction: 'GH',
            regNumber: regNumber.trim(),
            assignedServices: selectedServices,
          },
          admin: {
            username: adminUsername.trim().toLowerCase(),
            name: adminFullName.trim(),
            email: adminEmail.trim().toLowerCase(),
            password: adminPassword,
            role: adminRole,
            makerLimit: adminMakerLimit,
            ...(adminAllowedModules !== undefined ? { allowedModules: adminAllowedModules } : {}),
          },
        }),
      });
      const body = await response.json().catch(() => null);
      if (!response.ok || !body?.ok || !body.client || !body.administrator) {
        setCreateError(body?.error || 'The workspace was not created. Please retry.');
        return;
      }
      const newClient: ClientEntity = {
        ...body.client,
        loginUrl: body.client.loginUrl || workspaceSignInPath(body.client.code),
      };
      const newClientUser: UserAccount = body.administrator;
      persistentStorage.saveUserAccounts([
        ...persistentStorage.getUserAccounts().filter((u) => u.username !== newClientUser.username),
        newClientUser,
      ]);
      // Keep the owner in this desk until they close the one-time receipt.
      onAddClient(newClient);
      setShowModal(false);
      setCredentialReceipt({ client: newClient, user: newClientUser, pass: adminPassword });
      setAdminPassword('');
    } catch {
      setCreateError('Could not contact the server. No workspace or account was created.');
    } finally {
      setCreateBusy(false);
    }
  };

  const resolveLoginUrl = (c: ClientEntity) => {
    const path = workspaceSignInPath(c.code);
    const active = typeof window !== 'undefined' ? window.location.origin : '';
    const storedOrigin = c.loginUrl?.endsWith(path) ? c.loginUrl.slice(0, -path.length) : '';
    const verified = configuredWorkspaceOrigin(storedOrigin);
    if (verified) return `${verified}${path}`;
    return active && !isSandboxHostname(new URL(active).hostname) ? `${active}${path}` : path;
  };

  const handleInlineResetPassword = async () => {
    if (!credentialReceipt || !resetPassInput.trim() || resetBusy) return;
    setResetBusy(true);
    setResetFeedback(null);
    const nextPass = resetPassInput.trim();
    try {
      const r = await apiFetch('/api/users', {
        method: 'PUT',
        body: JSON.stringify({
          user: {
            ...credentialReceipt.user,
            clientId: credentialReceipt.client.id,
            password: nextPass,
          },
        }),
      });
      const b = await r.json().catch(() => null);
      if (!r.ok || !b?.ok) {
        setResetFeedback({ ok: false, text: b?.error || `Password reset refused (HTTP ${r.status}).` });
        return;
      }
      if (b.user) {
        persistentStorage.upsertUserAccount(b.user as UserAccount);
      }
      setCredentialReceipt({
        ...credentialReceipt,
        user: (b.user as UserAccount) || credentialReceipt.user,
        pass: nextPass,
      });
      setResetPassInput('');
      setResetFeedback({ ok: true, text: `Password updated on the server for ${credentialReceipt.user.username}. Copy the updated slip below.` });
    } catch {
      setResetFeedback({ ok: false, text: 'Could not reach the server to reset the password.' });
    } finally {
      setResetBusy(false);
    }
  };

  const handleCopyCredentials = async () => {
    if (!credentialReceipt) return;
    const url = resolveLoginUrl(credentialReceipt.client);
    const creds = `BPZ CONSULT CLIENT ACCESS CREDENTIALS\n` +
      `Client Workspace: ${credentialReceipt.client.name} (${credentialReceipt.client.code})\n` +
      `Sector: ${credentialReceipt.client.sector}\n` +
      `Assigned Services: ${(credentialReceipt.client.assignedServices || []).join(', ')}\n` +
      `Login URL: ${url}\n` +
      `Username: ${credentialReceipt.user.username}\n` +
      `Email: ${credentialReceipt.user.email}\n` +
      (credentialReceipt.pass ? `Password: ${credentialReceipt.pass}\n` : 'Password: (set a new password in the box above or under User Access & Restrictions)\n') +
      `Role: ${credentialReceipt.user.role} (Maker Limit: ${ccy()}${credentialReceipt.user.makerLimit.toLocaleString()})\n`;

    try {
      await navigator.clipboard.writeText(creds);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 3000);
    } catch {
      setResetFeedback({ ok: false, text: 'Clipboard access is unavailable. Copy the displayed sign-in details manually.' });
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker="MGT · Client Workspace Management · Owner Control"
        title="Client Workspaces & Practice Hub"
        desc="Create a client workspace and its administrator sign-in. Accounts are created on the firm's server (passwords are hashed server-side), so clients can sign in from any device."
      >
        {onOpenStatements && <button type="button" onClick={onOpenStatements} className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50">Statements of account</button>}
        <button
          onClick={() => {
            setCode(`CLI-00${clients.length + 1}`);
            setName(''); setRegNumber(''); setAdminFullName(''); setAdminUsername(''); setAdminEmail('');
            setAdminPassword(`Bpz#${Math.random().toString(36).slice(2, 8).toUpperCase()}9!`);
            setShowAdminPassword(true);
            setAdminAllowedModules(undefined);
            setCreateError(null);
            setShowModal(true);
          }}
          className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
        >
          <Plus className="h-4 w-4" />
          <span>New Client Workspace</span>
        </button>
      </PageHeader>

      {/* Managed Client Workspaces Table */}
      <Card title="Managed Client Workspaces" sub="Click 'Open Workspace' to switch the accounting system context">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[850px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Workspace Code</th>
                <th className={thCls}>Client Legal Name</th>
                <th className={thCls}>Sector Profile</th>
                <th className={thCls}>Contracted Services</th>
                <th className={thCls}>Admin Login</th>
                <th className={thCls + ' text-center'}>Credentials</th>
                <th className={thCls + ' text-center'}>Switch Action</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((c) => {
                const isCurrent = c.id === currentClient.id;
                const servicesCount = (c.assignedServices || ['bookkeeping', 'payroll', 'tax_compliance', 'management_accounts']).length;
                return (
                  <tr key={c.id} className={`${rowCls} ${isCurrent ? 'bg-sky-50/80 font-bold' : ''}`}>
                    <td className="px-3 py-2 font-mono text-[#855b00]">{c.code}</td>
                    <td className="px-3 py-2 text-[#082f4f]">
                      {c.name} {c.isParent && <span className="ml-1 text-[10px] text-[#006f98]">(Holding HQ)</span>}
                    </td>
                    <td className="px-3 py-2 text-[#2d4f6d] max-w-xs truncate" title={c.sector}>
                      {c.sector}
                    </td>
                    <td className="px-3 py-2 font-mono">
                      <span className="rounded bg-sky-100 text-[#006f98] px-2 py-0.5 text-[10.5px] font-bold">
                        {servicesCount} Services Active
                      </span>
                    </td>
                    <td className="px-3 py-2 font-mono text-[11px] text-[#355875]">
                      {c.adminUsername || 'demo'}
                    </td>
                    <td className="px-3 py-2 text-center">
                      <button
                        onClick={() => {
                          const existingUser = persistentStorage.getUserAccounts().find(u => u.clientId === c.id) || {
                            username: c.adminUsername || 'demo',
                            email: c.adminEmail || 'client@firm.gh',
                            name: `${c.name} Controller`,
                            role: 'accountant' as const,
                            makerLimit: 50000,
                            canCheck: false,
                          };
                          setResetPassInput('');
                          setResetFeedback(null);
                          setCredentialReceipt({
                            client: { ...c, loginUrl: resolveLoginUrl(c) },
                            user: existingUser,
                            pass: '',
                          });
                        }}
                        className="rounded border border-sky-300 bg-sky-50 px-2 py-1 text-[10.5px] font-bold text-[#082f4f] hover:bg-sky-100 transition inline-flex items-center gap-1"
                      >
                        <Key className="h-3 w-3 text-[#855b00]" />
                        <span>View Login</span>
                      </button>
                    </td>
                    <td className="px-3 py-2 text-center">
                      {isCurrent ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700">
                          <Check className="h-3.5 w-3.5" />
                          <span>Active Books</span>
                        </span>
                      ) : (
                        <button
                          onClick={() => onSwitchClient(c)}
                          className="flex items-center gap-1 rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] mx-auto transition"
                        >
                          <span>Open Workspace</span>
                          <ArrowUpRight className="h-3 w-3" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Modal: Create Client with Expanded Ghanaian Sectors, Services & Credentials */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto">
          <form
            onSubmit={handleCreateClient}
            className="w-full max-w-3xl rounded-2xl border border-sky-300 bg-white p-6 sm:p-7 shadow-2xl space-y-5 text-xs text-[#0a253e]"
          >
            <div className="flex items-center justify-between border-b border-sky-200 pb-3">
              <div>
                <h3 className="text-base font-black text-[#082f4f]">Create New Client Workspace</h3>
                <p className="text-[11px] text-[#2d4f6d]">
                  Configure Ghanaian economic sector, assign contracted services, and generate client credentials.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-black text-xl font-bold p-1"
              >
                &times;
              </button>
            </div>

            {/* Step 1: Entity Details & Sector Selection */}
            <div className="space-y-3">
              <span className="block font-bold text-[#082f4f] uppercase tracking-wider text-[11px]">
                1. Legal Entity &amp; Ghanaian Economy Sector
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-bold text-[#082f4f] mb-1">Company / Business Legal Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Client Code</label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono font-bold text-[#855b00]"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#082f4f] mb-1">Company Registration / Certificate No.</label>
                <input
                  type="text"
                  value={regNumber}
                  onChange={(e) => setRegNumber(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono text-[#082f4f]"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-bold text-[#082f4f] mb-1">
                    Ghanaian Sector Profile (All 24 Major Sectors)
                  </label>
                  <select
                    value={selectedSectorCode}
                    onChange={(e) => setSelectedSectorCode(e.target.value)}
                    className="w-full rounded border border-sky-300 px-2 py-2 outline-none font-bold text-[#082f4f]"
                  >
                    {GHANA_ECONOMY_SECTORS.map((sec) => (
                      <option key={sec.code} value={sec.code}>
                        [{sec.category}] {sec.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Base Currency</label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full rounded border border-sky-300 px-2 py-2 outline-none font-bold text-[#082f4f]"
                  >
                    <option value="GHS">GHS (Ghana Cedi)</option>
                    <option value="USD">USD (US Dollar)</option>
                    <option value="EUR">EUR (Euro)</option>
                    <option value="GBP">GBP (British Pound)</option>
                  </select>
                </div>
              </div>

              {/* Sector Tax Intelligence Pill */}
              <div className="rounded-xl border border-sky-200 bg-sky-50 p-3 text-[11px] text-[#2d4f6d] space-y-1">
                <div>
                  <strong className="text-[#082f4f]">Statutory Tax Context: </strong>
                  CIT Rate: <strong className="text-rose-800">{activeSector.citRate}%</strong> · VAT Scheme:{' '}
                  <strong className="text-[#006f98]">{activeSector.vatScheme}</strong> · Regulator:{' '}
                  <strong className="text-[#855b00]">{activeSector.regulatoryBody}</strong>
                </div>
                <div className="text-[10.5px]">{activeSector.taxNotes}</div>
              </div>
            </div>

            {/* Step 2: Assigned BPZ Services */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="block font-bold text-[#082f4f] uppercase tracking-wider text-[11px]">
                  2. Contracted BPZ Accounting &amp; Advisory Services
                </span>
                <span className="text-[10.5px] text-[#355875]">Owner decides which modules client can access</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {BPZ_SERVICE_LINES.map((srv) => {
                  const isChecked = selectedServices.includes(srv.id);
                  return (
                    <label
                      key={srv.id}
                      className={`flex items-start gap-2.5 p-2.5 rounded-xl border cursor-pointer transition ${
                        isChecked
                          ? 'border-[#082f4f] bg-sky-50/70 ring-1 ring-[#082f4f]'
                          : 'border-sky-200 bg-white hover:bg-sky-50/40'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => handleToggleService(srv.id)}
                        className="rounded border-sky-300 text-[#082f4f] mt-0.5"
                      />
                      <div>
                        <div className="font-bold text-[#082f4f] text-xs flex items-center gap-1.5">
                          <span>{srv.name}</span>
                          <span className="rounded bg-sky-100 text-[#006f98] px-1 py-0.2 text-[9px] font-mono">
                            {srv.code}
                          </span>
                        </div>
                        <div className="text-[10.5px] text-[#2d4f6d] mt-0.5">{srv.description}</div>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Step 3: Client Administrator Credentials Setup */}
            <div className="space-y-3">
              <span className="block font-bold text-[#082f4f] uppercase tracking-wider text-[11px]">
                3. Client Administrator Login Credentials &amp; Access Link
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Controller / Staff Full Name</label>
                  <input
                    type="text"
                    value={adminFullName}
                    onChange={(e) => setAdminFullName(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-bold text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Official Business Email</label>
                  <input
                    type="email"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono text-[#082f4f]"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Login Username</label>
                  <input
                    type="text"
                    value={adminUsername}
                    onChange={(e) => setAdminUsername(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono font-bold text-[#855b00]"
                    required
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-bold text-[#082f4f]">Initial Password</label>
                    <div className="flex gap-1.5 text-[10px] font-bold">
                      <button
                        type="button"
                        onClick={() => setAdminPassword(`Bpz#${Math.random().toString(36).slice(2, 8).toUpperCase()}9!`)}
                        className="text-[#006f98] underline"
                      >
                        Generate
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowAdminPassword((v) => !v)}
                        className="text-[#855b00] underline"
                      >
                        {showAdminPassword ? 'Hide' : 'Show'}
                      </button>
                    </div>
                  </div>
                  <input
                    type={showAdminPassword ? 'text' : 'password'}
                    autoComplete="new-password"
                    minLength={10}
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono font-bold text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">User Role</label>
                  <select
                    value={adminRole}
                    onChange={(e) => setAdminRole(e.target.value as any)}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-semibold text-[#082f4f]"
                  >
                    <option value="manager">Manager / Reviewer</option>
                    <option value="accountant">Accountant / Maker</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Maker Limit ({ccy()})</label>
                  <input
                    type="number"
                    value={adminMakerLimit}
                    onChange={(e) => setAdminMakerLimit(Number(e.target.value))}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono text-[#082f4f]"
                  />
                </div>
              </div>

              {/* Optional Per-Module Ticks for the Client Workspace */}
              <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-3 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-bold text-[#082f4f] text-[11px] uppercase tracking-wider">
                    4. Ticked Workspace Modules for This Client
                  </span>
                  <div className="flex gap-3 text-[11px] font-bold text-[#082f4f]">
                    <button type="button" className="underline" onClick={() => setAdminAllowedModules(undefined)}>
                      All modules in contracted services
                    </button>
                    <button type="button" className="underline" onClick={() => setAdminAllowedModules(CLIENT_MODULE_CATALOG.map((m) => m.id))}>
                      Tick all
                    </button>
                    <button type="button" className="underline" onClick={() => setAdminAllowedModules([])}>
                      Clear all
                    </button>
                  </div>
                </div>
                <p className="text-[10.5px] text-[#355875]">
                  Tick the exact modules this client may see on their workspace. Unticked modules are hidden from the client sidebar and blocked.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-x-3 gap-y-1 text-[11px] max-h-44 overflow-y-auto pr-1">
                  {CLIENT_MODULE_CATALOG.map((m) => {
                    const ticked = adminAllowedModules === undefined || adminAllowedModules.includes(m.id);
                    return (
                      <label key={m.id} className="flex items-center gap-1.5 cursor-pointer text-[#0a253e]">
                        <input
                          type="checkbox"
                          checked={ticked}
                          onChange={(e) => {
                            const current = adminAllowedModules ?? CLIENT_MODULE_CATALOG.map((x) => x.id);
                            const next = e.target.checked
                              ? Array.from(new Set([...current, m.id]))
                              : current.filter((id) => id !== m.id);
                            setAdminAllowedModules(next);
                          }}
                          className="rounded border-sky-300"
                        />
                        <span className="truncate" title={`${m.label} (${m.group})`}>{m.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            </div>

            {createError && (
              <p role="alert" className="rounded-lg border border-rose-300 bg-rose-50 p-3 text-xs font-bold text-rose-900">
                {createError}
              </p>
            )}
            <div className="flex justify-end gap-2 pt-3 border-t border-sky-100">
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="rounded px-4 py-2 font-semibold text-[#2d4f6d] hover:bg-sky-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={createBusy}
                className="rounded-lg bg-[#082f4f] px-5 py-2 font-bold text-white hover:bg-[#0c3f68] transition shadow-xs disabled:opacity-50"
              >
                {createBusy ? 'Creating on server…' : 'Create Workspace & Provision Credentials'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Credential Receipt Modal / Slip for Owner */}
      {credentialReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 sm:p-7 shadow-2xl space-y-5 text-xs text-[#0a253e]">
            <div className="flex items-center justify-between border-b border-sky-200 pb-3">
              <div className="flex items-center gap-2 text-emerald-800 font-bold">
                <ShieldCheck className="h-5 w-5 text-emerald-700" />
                <span className="text-sm">Client Workspace &amp; Credentials Generated</span>
              </div>
              <button
                type="button"
                onClick={() => setCredentialReceipt(null)}
                className="text-slate-400 hover:text-black text-xl font-bold p-1"
              >
                &times;
              </button>
            </div>

            <div className="rounded-xl border border-sky-200 bg-sky-50/70 p-4 space-y-2.5">
              <div className="flex justify-between items-center border-b border-sky-200 pb-2">
                <span className="font-bold text-[#082f4f] text-sm">{credentialReceipt.client.name}</span>
                <span className="font-mono font-bold text-[#855b00]">{credentialReceipt.client.code}</span>
              </div>

              <div className="space-y-1 font-mono text-[11.5px] text-[#2d4f6d]">
                <div className="flex justify-between">
                  <span>Login Username:</span>
                  <strong className="text-[#082f4f]">{credentialReceipt.user.username}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Official Email:</span>
                  <span className="text-[#082f4f]">{credentialReceipt.user.email}</span>
                </div>
                <div className="flex justify-between">
                  <span>Initial Passcode:</span>
                  <strong className="text-[#855b00]">{credentialReceipt.pass || 'Not stored — reset in User Access'}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Role &amp; Maker Limit:</span>
                  <span>{credentialReceipt.user.role} ({ccy()}{credentialReceipt.user.makerLimit.toLocaleString()})</span>
                </div>
              </div>

              <div className="pt-2 border-t border-sky-200">
                <span className="text-[10px] text-[#355875] uppercase font-bold block mb-1">Direct Workspace Access Link:</span>
                <div className="font-mono text-[11px] text-[#006f98] bg-white p-2 rounded border border-sky-200 break-all select-all">
                  {resolveLoginUrl(credentialReceipt.client)}
                </div>
              </div>

              <div className="pt-2 border-t border-sky-200 space-y-1.5">
                <span className="text-[10px] text-[#082f4f] uppercase font-bold block">
                  Set or Reset Client Password on Server:
                </span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={resetPassInput}
                    onChange={(e) => setResetPassInput(e.target.value)}
                    placeholder="Enter new password (e.g. ClientPass#2026)"
                    className="flex-1 rounded border border-sky-300 bg-white px-2.5 py-1.5 font-mono text-xs font-bold text-[#082f4f] outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setResetPassInput(`Bpz#${Math.random().toString(36).slice(2, 8).toUpperCase()}9!`)}
                    className="rounded border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#006f98] hover:bg-sky-50"
                  >
                    Generate
                  </button>
                  <button
                    type="button"
                    disabled={resetBusy || !resetPassInput.trim()}
                    onClick={handleInlineResetPassword}
                    className="rounded bg-[#082f4f] px-3 py-1.5 text-[11px] font-bold text-white hover:bg-[#0c3f68] disabled:opacity-50"
                  >
                    {resetBusy ? 'Saving…' : 'Set Password'}
                  </button>
                </div>
                {resetFeedback && (
                  <p className={`text-[11px] font-bold ${resetFeedback.ok ? 'text-emerald-800' : 'text-rose-800'}`}>
                    {resetFeedback.text}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-sky-100">
              <span className="text-[11px] text-[#2d4f6d]">
                {copiedLink ? '✓ Credentials copied to clipboard!' : resolveLoginUrl(credentialReceipt.client).startsWith('/') ? 'Preview only: configure a production HTTPS domain before sharing this invitation.' : 'Share the sign-in details through your organisation’s secure channel.'}
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleCopyCredentials}
                  className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-4 py-2 font-bold text-white hover:bg-[#0c3f68]"
                >
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy Credentials</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 rounded-lg border border-sky-300 px-3 py-2 font-bold text-[#082f4f] hover:bg-sky-50"
                >
                  <Printer className="h-3.5 w-3.5" />
                  <span>Print Slip</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
