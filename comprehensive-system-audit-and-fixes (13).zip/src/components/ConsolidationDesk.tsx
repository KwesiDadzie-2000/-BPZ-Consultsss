import { useMemo, useState } from 'react';
import { Download, Layers, Scale, Table2 } from 'lucide-react';
import type { ACDOCALine, AccountMaster, ClientEntity } from '../types/accounting';
import { downloadCsv } from '../utils/printReport';
import { consolidateGroup, parentOf, type GroupInput } from '../utils/consolidation';
import { Card, PageHeader, Stat, formatGHS, numCls, rowCls, thCls, cn, Badge } from './ui';

interface Props {
  clients: ClientEntity[];
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  ready?: boolean;
}

/**
 * IFRS 10 Group consolidation — full workbench.
 *
 * Control establishment → translation → intercompany eliminations → goodwill
 * (IFRS 3) → NCI (IFRS 10) → consolidated trial balance. Every input is an
 * owner-editable working-paper parameter: hold %, investment, exchange rate.
 * Nothing is posted by this desk — it is read-only analysis of posted books.
 */
export function ConsolidationDesk({ clients, lines, accounts, ready = true }: Props) {
  const parent = parentOf(clients) ?? null;
  const currency = (parent?.currency ?? clients[0]?.currency ?? 'GHS').toUpperCase();
  const subs = clients.filter((c) => c.id !== parent?.id);

  const [holds, setHolds] = useState<Record<number, number>>(() =>
    Object.fromEntries(subs.map((c) => [c.id, 100])));
  const [rates, setRates] = useState<Record<number, number | undefined>>(() =>
    Object.fromEntries(subs.map((c) => [c.id, c.currency.toUpperCase() === currency ? 1 : undefined])));
  const [investments, setInvestments] = useState<Record<number, number | undefined>>(() => ({}));

  const entities = useMemo(() => subs.map((c) => ({
    client: c,
    input: { id: c.id, holdPct: Math.max(0, Math.min(100, holds[c.id] ?? 100)), exchangeRate: rates[c.id] !== undefined ? rates[c.id] : (c.currency.toUpperCase() === currency ? 1 : NaN), investment: investments[c.id] } as GroupInput,
    lines: lines.filter((l) => l.clientId === c.id),
  })), [subs, holds, rates, investments, lines]);

  const result = useMemo(() => {
    if (!parent) return null;
    const parentLines = lines.filter((l) => l.clientId === parent.id);
    return consolidateGroup({
      parent,
      accounts,
      entities: [
        { client: parent, input: { id: parent.id, holdPct: 100, exchangeRate: 1 }, lines: parentLines },
        ...entities,
      ],
    });
  }, [parent, entities, accounts, lines]);

  const number = (n: number) => formatGHS(n);

  if (!parent) {
    return (
      <div className="space-y-4">
        <PageHeader kicker="IFRS 10 · Group consolidation" title="Group Consolidation" desc="No parent entity found. Mark one workspace as the holding HQ (Clients & CRM) to consolidate." />
      </div>
    );
  }

  const totals = result?.totals;
  const eliminations = result?.eliminations ?? [];
  const errors = result?.errors ?? [];
  const balanced = result?.balanced;

  return (
    <div className="space-y-6">
      <PageHeader kicker="IFRS 10 · Group consolidation" title="Group Consolidation Workbench"
        desc="Control establishment, intercompany eliminations, goodwill (IFRS 3) and non-controlling interests (IFRS 10), translated to the parent currency. Read-only analysis — nothing is posted.">
        <button type="button" disabled={!ready || !result} onClick={() => {
          if (!result) return;
          const t = result.totals;
          downloadCsv(`group-consolidation-${parent.code}.csv`, [
            ['Group consolidation — consolidated working paper', parent.code, currency],
            ['Entity', 'Code', 'Hold %', 'Currency', 'Assets', 'Liabilities', 'NAV', 'Goodwill', 'NCI'],
            ...result.entities.map((e) => [e.name, e.code, `${e.holding}%`, e.currency, e.assets, e.liabilities, e.equity, e.goodwill, e.nCi]),
            [],
            ['Consolidated totals', '', '', '', t.assets, t.liabilities, '', t.goodwill, t.nci],
            ['Parent retained equity', '', '', '', '', '', t.parentRetained, '', ''],
            ['Eliminations', '', '', '', '', '', '', '', ''],
            ...eliminations.map((e) => [`${e.party} (${e.subsidiaryId})`, '', '', '', e.ar / 100, e.ap / 100, e.eliminated / 100, '', '']),
          ]);
        }} className="inline-flex items-center gap-2 rounded-lg border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f] disabled:opacity-40">
          <Download className="h-4 w-4" /> Export working paper
        </button>
        <Badge tone="fi">READ-ONLY</Badge>
      </PageHeader>

      {errors.length > 0 && (
        <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 p-3 text-xs leading-relaxed text-rose-800">
          {errors.map((e, i) => <p key={i}>• {e}</p>)}
        </div>
      )}

      <Card title="Control establishment" sub="A controlled subsidiary is consolidated 100%; below 50% hold it is excluded (equity-method only). Holding % is an owner working-paper input." action={<Badge tone="slate">IFRS 10.9</Badge>}>
        <div className="overflow-x-auto"><table className="w-full min-w-[640px] text-xs">
          <thead><tr><th className={thCls}>Subsidiary</th><th className={thCls}>Currency</th><th className={thCls + ' text-right'}>Hold %</th><th className={thCls + ' text-right'}>NCI %</th><th className={thCls + ' text-right'}>Rate → {currency}</th><th className={thCls + ' text-right'}>Investment</th><th className={thCls + ' text-center'}>Included</th></tr></thead>
          <tbody>
            {subs.map((c) => {
              const included = result?.entities.find((e) => e.id === c.id)?.included;
              return <tr key={c.id} className={rowCls}>
                <td className="px-3 py-2 font-bold text-[#082f4f]">{c.code} · {c.name}</td>
                <td className="px-3 py-2 font-mono">{c.currency}</td>
                <td className="px-3 py-2 text-right"><input type="number" min="0" max="100" step="0.5" value={holds[c.id] ?? 100} onChange={(e) => { const r = Number(e.target.value); setHolds((p) => ({ ...p, [c.id]: Number.isFinite(r) ? Math.max(0, Math.min(100, r)) : 100 })); }} className="w-20 rounded border border-sky-300 px-2 py-1 text-right" /></td>
                <td className="px-3 py-2 text-right font-mono">{Math.max(0, 100 - (holds[c.id] ?? 100))}%</td>
                <td className="px-3 py-2 text-right"><input type="number" min="0.0001" step="0.0001" placeholder="enter rate" value={rates[c.id] ?? ''} onChange={(e) => { const r = Number(e.target.value); setRates((p) => ({ ...p, [c.id]: Number.isFinite(r) && r > 0 ? r : undefined })); }} className="w-24 rounded border border-sky-300 px-2 py-1 text-right font-mono" /></td>
                <td className="px-3 py-2 text-right"><input type="number" min="0" step="0.01" placeholder="—" value={investments[c.id] ?? ''} onChange={(e) => { const v = e.target.value ? Number(e.target.value) : undefined; setInvestments((p) => ({ ...p, [c.id]: v !== undefined && Number.isFinite(v) && v >= 0 ? v : undefined })); }} className="w-28 rounded border border-sky-300 px-2 py-1 text-right font-mono" /></td>
                <td className="px-3 py-2 text-center">{included ? <Badge tone="green">Included</Badge> : <Badge tone="red">Excluded</Badge>}</td>
              </tr>;
            })}
          </tbody>
        </table></div>
        {subs.some((c) => c.currency.toUpperCase() !== currency && rates[c.id] === undefined) && (
          <p className="mt-3 rounded-lg border border-amber-300 bg-amber-50 p-2.5 text-[11px] font-bold text-amber-800">Enter the closing exchange rate for each foreign subsidiary — balances without a rate are shown untranslated, which is reported here and not hidden.</p>
        )}
        <p className="mt-3 text-[11px] leading-relaxed text-[#355875]">
          Holdings &gt; 50% ⇒ consolidated 100%. Investment cost is entered for goodwill.
          Exchange rate is the parent ccy per 1 unit of subsidiary ccy (1 for same currency).
        </p>
      </Card>

      {!ready ? <Card title="Loading group journals"><p role="status" className="text-xs text-[#355875]">Waiting for all entity ledgers.</p></Card> : <>

        {result && (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Consolidated assets" value={`${currency} ${number(result.totals.assets)}`} tone="text-[#006f98]" />
            <Stat label="Liabilities" value={`${currency} ${number(result.totals.liabilities)}`} tone="text-[#855b00]" />
            <Stat label="Group equity (incl NCI)" value={`${currency} ${number(result.totals.equity)}`} />
            <Stat label={`NCI · goodwill`} value={`${currency} ${number(result.totals.nci)} · ${currency} ${number(result.totals.goodwill)}`} tone="text-[#082f4f]" />
          </div>
        )}

        <div className="grid gap-4 xl:grid-cols-2">
          <Card title="Non-controlling interests & goodwill (IFRS 3/10)" sub="NCI = NCI% × (subsidiary NAV + goodwill)">
            <div className="overflow-x-auto"><table className="w-full min-w-[420px] text-xs">
              <thead><tr><th className={thCls}>Subsidiary</th><th className={thCls + ' text-right'}>NAV</th><th className={thCls + ' text-right'}>Goodwill</th><th className={thCls + ' text-right'}>NCI</th></tr></thead>
              <tbody>
                {result?.entities.filter((e) => e.id !== parent.id).map((e) => (
                  <tr key={e.id} className={rowCls}>
                    <td className="px-3 py-2 font-semibold text-[#082f4f]">{e.code} · {e.name}</td>
                    <td className={numCls}>{number(e.equity)}</td>
                    <td className={numCls}>{e.goodwill ? number(e.goodwill) : '—'}</td>
                    <td className={numCls}>{e.nCi ? number(e.nCi) : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table></div>
            {result && !result.entities.some((e) => e.id !== parent.id && e.included) && <p className="mt-2 text-[11px] text-amber-800">No controlled subsidiaries in scope — goodwill and NCI not applicable.</p>}
          </Card>

          <Card title="Intercompany eliminations" sub="AR in parent matched by exact party name against AP in controlled subs">
            <div className="overflow-x-auto"><table className="w-full min-w-[420px] text-xs">
              <thead><tr><th className={thCls}>Party</th><th className={thCls + ' text-right'}>AR (parent)</th><th className={thCls + ' text-right'}>AP (sub)</th><th className={thCls + ' text-right'}>Eliminated</th></tr></thead>
              <tbody>
                {eliminations.length === 0 && <tr><td colSpan={4} className="px-3 py-4 text-center text-[#355875]">No intercompany balances matched. Every entity's AR was eliminated against a controlled subsidiary's AP by party name.</td></tr>}
                {eliminations.map((e, i) => <tr key={i} className={rowCls}>
                  <td className="px-3 py-2 font-semibold text-[#082f4f]">{e.party}</td>
                  <td className={numCls}>{number(e.ar / 100)}</td>
                  <td className={numCls}>{number(e.ap / 100)}</td>
                  <td className={cn(numCls, 'font-bold text-emerald-700')}>{number(e.eliminated / 100)}</td>
                </tr>)}
              </tbody>
            </table></div>
            <p className="mt-2 text-[11px] text-[#355875]">Unmatched AR or AP is reported — it is never forced away. Non-matched amounts belong to third parties.</p>
          </Card>
        </div>

        <Card title={<span className="inline-flex items-center gap-2"><Table2 className="h-4 w-4" />Consolidated trial balance</span>}
          sub={`${currency} · post-elimination · parent + subsidiaries translated at closing rate`}>
          <div className="overflow-x-auto"><table className="w-full min-w-[680px] text-xs">
            <thead><tr><th className={thCls}>GL account</th><th className={thCls}>Name</th><th className={thCls}>Type</th><th className={thCls + ' text-right'}>Parent</th><th className={thCls + ' text-right'}>Subsidiary (translated)</th><th className={thCls + ' text-right'}>Consolidated</th></tr></thead>
            <tbody>
              {(result?.rows ?? []).filter((r) => Math.abs(r.parent) + Math.abs(r.subsidiary) > 0.005).map((r) => (
                <tr key={r.account} className={rowCls}>
                  <td className="px-3 py-2 font-mono font-bold">{r.account}</td>
                  <td className="px-3 py-2">{r.name}</td>
                  <td className="px-3 py-2">{r.type}</td>
                  <td className={numCls}>{number(r.parent / 100)}</td>
                  <td className={numCls}>{number(r.subsidiary / 100)}</td>
                  <td className={cn(numCls, 'font-bold text-[#082f4f]')}>{number(r.consolidated / 100)}</td>
                </tr>
              ))}
            </tbody>
          </table></div>
          {result && <p className={cn('mt-3 text-[11px] font-bold', balanced ? 'text-emerald-700' : 'text-rose-700')}>{balanced ? '✓ Consolidated totals foot: assets = equity (incl NCI) + liabilities' : '✗ Consolidated totals DO NOT foot — investigate before issue'}</p>}
        </Card>

        <Card title="Group balance sheet summary" sub="Assets = parent retained + NCI + liabilities" action={<Badge tone="slate">{currency}</Badge>}>
          <dl className="grid gap-2 sm:grid-cols-2">
            <div className="rounded-lg bg-sky-50 p-3"><dt className="text-[10px] uppercase tracking-wide text-[#355875]">Total assets</dt><dd className="font-mono text-lg font-extrabold text-[#082f4f]">{totals ? number(totals.assets) : '—'}</dd></div>
            <div className="rounded-lg bg-sky-50 p-3"><dt className="text-[10px] uppercase tracking-wide text-[#355875]">Liabilities</dt><dd className="font-mono text-lg font-extrabold text-[#082f4f]">{totals ? number(totals.liabilities) : '—'}</dd></div>
            <div className="rounded-lg bg-sky-50 p-3"><dt className="text-[10px] uppercase tracking-wide text-[#355875]">Group equity (incl NCI)</dt><dd className="font-mono text-lg font-extrabold text-[#082f4f]">{totals ? number(totals.equity) : '—'}</dd></div>
            <div className="rounded-lg bg-sky-50 p-3"><dt className="text-[10px] uppercase tracking-wide text-[#355875]">Parent retained equity</dt><dd className="font-mono text-lg font-extrabold text-[#082f4f]">{totals ? number(totals.parentRetained) : '—'}</dd></div>
            <div className="rounded-lg bg-sky-50 p-3 sm:col-span-2"><dt className="text-[10px] uppercase tracking-wide text-[#355875]">Non-controlling interests</dt><dd className="font-mono text-lg font-extrabold text-[#855b00]">{totals ? number(totals.nci) : '—'}</dd></div>
          </dl>
        </Card>

        <Card title="Method & limitations" sub="Working-paper framing for the group">
          <p className="text-xs leading-relaxed text-[#355875]">
            Full consolidation of controlled subsidiaries (hold &gt; 50%). Translation at closing rate (IAS 21 / IFRS 21); average rate for P&amp;L is not modelled.
            Intercompany elimination requires exact party names in the parent's 110000 AR and subsidiary's 200000 AP — non-matched balances are reported, never forced away.
            Goodwill uses investment − hold% × NAV (IFRS 3); NCI is NCI% × (NAV + goodwill) (IFRS 10). Consolidated totals foot by construction.
          </p>
        </Card>
      </>}
    </div>
  );
}
