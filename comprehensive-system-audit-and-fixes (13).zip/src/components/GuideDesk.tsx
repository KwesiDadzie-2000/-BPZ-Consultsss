import { useState } from 'react';
import { BookOpen, Layers, CheckSquare, ClipboardList } from 'lucide-react';
import { Card, PageHeader, Badge, cn } from './ui';
import { GUIDE_MODULES, GUIDE_SETUP_STEPS, GUIDE_CHECKLIST } from '../data/guide';
import type { ClientEntity } from '../types/accounting';

const tabs = [
  { id: 'setup', label: 'Setup & migration', icon: ClipboardList },
  { id: 'modules', label: 'Modules & desks', icon: Layers },
  { id: 'checklist', label: 'Cut-over checklist', icon: CheckSquare },
] as const;

type Tab = typeof tabs[number]['id'];

const field = 'rounded-lg border border-sky-200 bg-white px-3 py-2 text-sm text-[#082f4f] outline-none focus:border-[#006f98] focus:ring-2 focus:ring-sky-100';

/**
 * In-app Setup & Guide desk. Renders the complete documentation: setup steps,
 * migration walkthrough and every module/desk with its accounting treatment.
 * Owner and firm users may read it; it is guidance, not a config engine.
 */
export function GuideDesk({ currentClient }: { currentClient: ClientEntity }) {
  const [tab, setTab] = useState<Tab>('setup');
  const [query, setQuery] = useState('');
  const q = query.trim().toLowerCase();
  const filteredModules = GUIDE_MODULES.filter((m) =>
    !q || `${m.name} ${m.group} ${m.what}`.toLowerCase().includes(q));
  const groups = [...new Set(filteredModules.map((m) => m.group))];

  return (
    <div className="space-y-6">
      <PageHeader kicker={`GUIDES · ${currentClient.code}`} title="Setup, guide & module reference"
        desc="Complete onboarding documentation: setup steps, migration walkthrough, every module and desk, and the cut-over checklist. Read this top to bottom.">
        <Badge tone="fi">DOCS</Badge>
      </PageHeader>

      <div role="tablist" aria-label="Guide sections" className="flex flex-wrap gap-2">
        {tabs.map((t) => {
          const Icon = t.icon;
          return (
            <button key={t.id} role="tab" aria-selected={tab === t.id} onClick={() => setTab(t.id)}
              className={cn('inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-bold transition',
                tab === t.id ? 'bg-[#082f4f] text-white' : 'border border-sky-200 bg-white text-[#355875] hover:bg-sky-50')}>
              <Icon className="h-3.5 w-3.5" />{t.label}
            </button>
          );
        })}
      </div>

      {tab === 'setup' && (
        <div className="space-y-4">
          <Card title="Setup & migration walkthrough" sub="Follow the numbered steps in order" pad={false}>
            <ol className="space-y-0 divide-y divide-sky-100">
              {GUIDE_SETUP_STEPS.map((s) => (
                <li key={s.step} className="grid gap-2 px-4 py-4 sm:grid-cols-[200px_1fr]">
                  <span className="text-xs font-black uppercase tracking-wide text-[#855b00]">{s.step}</span>
                  <span className="text-xs leading-relaxed text-[#082f4f]">{s.detail}</span>
                </li>
              ))}
            </ol>
          </Card>
          <Card title="Migration families (Data Migration desk)" sub="Run in order: opening balances → bank accounts → parties → ledger history">
            <ul className="list-disc space-y-1.5 pl-5 text-xs leading-relaxed text-[#082f4f]">
              <li><strong>Opening balances</strong> — signed trial balance; Dr must equal Cr at cut-over; posts one balanced journal at the cut-over date.</li>
              <li><strong>Bank accounts</strong> — treasury records mapped to 10xxxx GLs. Balances are derived from the ledger.</li>
              <li><strong>Customers &amp; vendors</strong> — credit limits, terms, standing. Enforced on sales and purchases.</li>
              <li><strong>Ledger history</strong> — historical documents; every document must balance (Dr = Cr).</li>
            </ul>
            <p className="mt-3 text-[11px] leading-relaxed text-[#355875]">
              Preview before committing: the importer names every row and reason; nothing is written until the file validates. Committing runs in one transaction.
            </p>
          </Card>
        </div>
      )}

      {tab === 'modules' && (
        <Card title="Modules & desks" sub="What each workspace module does and the accounting it drives"
          action={<input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search modules…" aria-label="Search modules" className="rounded-lg border border-sky-200 bg-white px-3 py-1.5 text-xs text-[#082f4f] outline-none focus:border-[#006f98]" />}>
          {groups.map((group) => (
            <section key={group} className="mb-4 last:mb-0">
              <h3 className="mb-2 text-[11px] font-black uppercase tracking-wider text-[#855b00]">{group}</h3>
              <ol className="space-y-2">
                {filteredModules.filter((m) => m.group === group).map((m) => (
                  <li key={m.id} className="rounded-lg border border-sky-100 bg-[#f7fbff] p-3 text-xs leading-relaxed">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-[#082f4f]">{m.name}</span>
                      <code className="rounded bg-sky-100 px-1.5 py-0.5 font-mono text-[10px] text-[#355875]">{m.id}</code>
                    </div>
                    <p className="mt-1 text-[#2d4f6d]">{m.what}</p>
                    {m.treatment && <p className="mt-1 font-mono text-[11px] text-[#006f98]">{m.treatment}</p>}
                    {m.accounts && <p className="mt-1 text-[11px] text-[#355875]">Key accounts: {m.accounts.join(' · ')}</p>}
                    {m.controls && <p className="mt-1 text-[11px] text-[#355875]">Controls: {m.controls.join(' · ')}</p>}
                  </li>
                ))}
              </ol>
            </section>
          ))}
          {filteredModules.length === 0 && <p className="text-xs text-[#355875]">No modules match that search.</p>}
        </Card>
      )}

      {tab === 'checklist' && (
        <Card title="Cut-over checklist" sub="Do this every time a client goes live">
          <ul className="space-y-2 text-xs">
            {GUIDE_CHECKLIST.map((item, i) => (
              <li key={item} className="flex items-start gap-2 text-[#082f4f]">
                <span className="mt-0.5 inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-emerald-300 bg-emerald-50 font-mono text-[10px] font-black text-emerald-700">{i + 1}</span>
                <span className="leading-relaxed">{item}</span>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}
