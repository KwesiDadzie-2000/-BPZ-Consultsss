import { useMemo, useState } from 'react';
import type { ACDOCALine, AccountMaster, BankAccount, ClientEntity, PurchaseOrder, StockItem, StockMovement, UserAccount } from '../types/accounting';
import { buildReceiptJournal } from '../utils/receiptAccounting';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { Boxes, Save } from 'lucide-react';
import { ModulePrintButton } from './ModulePrintButton';
import { docSuffix, uniqueId } from '../utils/ids';
import {
  COGS_ACCOUNT,
  INVENTORY_ACCOUNT,
  INVENTORY_ACCOUNT_NAME,
  inventoryAccountName,
  applyIssue,
  applyLandedCost,
  applyReceipt,
  applyWriteDown,
  buildAdjustmentEntries,
  buildMovement,
  buildWriteDownEntries,
  money,
  nrvWriteDown,
  reconcileInventory,
  tradingResult,
  type CostMethod,
} from '../utils/trading';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  isPeriodClosed: boolean;
  lines: ACDOCALine[];
  items: StockItem[];
  movements: StockMovement[];
  accounts: AccountMaster[];
  bankAccounts: BankAccount[];
  onAddJournalLines: (lines: ACDOCALine[], onRejected?: () => void) => boolean;
  onAddItem: (item: StockItem) => void;
  onApplyStock: (item: StockItem, movement: StockMovement) => void;
  /** Register a warehouse receipt so its subsequent invoice can be matched. */
  onRegisterReceipt: (po: PurchaseOrder) => void;
  onUndoReceipt: (original: StockItem, movementId: string, receiptId: string) => void;
  canRegisterReceipt: boolean;
  canSellStock: boolean;
  onStartSale: (itemCode: string, quantity: number) => void;
  onNavigate?: (section: string) => void;
}

type Action = 'Receipt' | 'Sale' | 'Issue' | 'Freight' | 'WriteDown' | 'Adjustment' | 'ReturnOut';

const ACTIONS: { id: Action; label: string; help: string }[] = [
  { id: 'Receipt', label: 'Goods received (purchase)', help: 'Dr Inventory · Cr GRNI (204000). This is an accrued liability, not an invoiced or paid supplier item. Record the supplier invoice separately in Procurement.' },
  { id: 'Sale', label: 'Sell stock / recognise revenue', help: 'Continue to Sales & Invoicing. The goods invoice issues one document posting revenue, output tax, receivables, cost of sales and a stock issue together; do not make a separate stock issue.' },
  { id: 'Freight', label: 'Inward freight (capitalise)', help: 'Dr Inventory · Cr Bank — directly attributable cost of bringing goods to their present location (IAS 2.11).' },
  { id: 'Issue', label: 'Internal consumption (not sale)', help: 'Dr selected operating expense · Cr Inventory. No revenue is recognised. Use Sell stock / recognise revenue for customer sales, or Production Desk for WIP.' },
  { id: 'WriteDown', label: 'Write-down to net realisable value', help: 'Dr Impairment expense · Cr Inventory — lower of cost and NRV (IAS 2.9).' },
  { id: 'Adjustment', label: 'Stock-count adjustment', help: 'Surplus: Dr Inventory · Cr Cost of sales. Loss: Dr Impairment expense · Cr Inventory.' },
  { id: 'ReturnOut', label: 'Return goods to supplier', help: 'Use the source-linked supplier debit/credit note in Procurement. A stand-alone stock return must never debit trade payables without a posted supplier invoice.' },
];

export const InventorySection = ({
  currentClient, currentUser, isPeriodClosed, lines, items, movements, accounts, bankAccounts,
  onAddJournalLines, onAddItem, onApplyStock, onRegisterReceipt, onUndoReceipt,
  canRegisterReceipt, canSellStock, onStartSale, onNavigate,
}: Props) => {
  const [action, setAction] = useState<Action>('Receipt');
  const [itemCode, setItemCode] = useState<string>(items[0]?.itemCode || '');
  const [qty, setQty] = useState(0);
  const [unitCost, setUnitCost] = useState(0);
  const [receiptTax, setReceiptTax] = useState(0);
  const [amount, setAmount] = useState(0);
  const [nrvPerUnit, setNrvPerUnit] = useState(0);
  const [onCredit, setOnCredit] = useState(false);
  const [expenseAccount, setExpenseAccount] = useState('628000');
  const [bankId, setBankId] = useState<number | null>(null);
  const [vendor, setVendor] = useState('');
  const [note, setNote] = useState('');
  const [date, setDate] = useState(() => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); });
  const [feedback, setFeedback] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);

  // New item form
  const [showNewItem, setShowNewItem] = useState(false);
  const [newCode, setNewCode] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newUom, setNewUom] = useState('Units');
  const [newCategory, setNewCategory] = useState('Merchandise');
  const [newMethod, setNewMethod] = useState<CostMethod>('weighted_average');
  const [newReorder, setNewReorder] = useState(0);

  const isRestricted = currentUser.role === 'auditor' || currentUser.status === 'restricted' || currentUser.status === 'suspended';
  const selected = items.find((i) => i.itemCode === itemCode);
  const reconciliation = useMemo(() => reconcileInventory(items, lines, currentClient.id), [items, lines, currentClient.id]);

  const trading = useMemo(() => {
    const clientLines = lines.filter((l) => l.clientId === currentClient.id);
    const revenue = clientLines.filter((l) => l.accountNo.startsWith('4') && Number(l.accountNo) < 420000)
      .reduce((n, l) => n + Math.round(l.credit * 100) - Math.round(l.debit * 100), 0) / 100;
    const cogs = clientLines.filter((l) => l.accountNo === COGS_ACCOUNT)
      .reduce((n, l) => n + Math.round(l.debit * 100) - Math.round(l.credit * 100), 0) / 100;
    return tradingResult(revenue, cogs);
  }, [lines, currentClient.id]);

  const ctx = (docNo: string) => ({
    docNo, date, currency: currentClient.currency, clientId: currentClient.id, createdBy: currentUser.username, costCenter: 'CC-OPS',
  });

  const guard = (): string | null => {
    if (isPeriodClosed) return 'Posting blocked. The accounting period is closed.';
    if (isRestricted) return 'Action blocked. Your account has been restricted.';
    if (!selected) return 'Select a stock item first.';
    return null;
  };

  const addItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRestricted) { setFeedback({ tone: 'err', text: 'This account cannot modify stock master data.' }); return; }
    if (!newCode.trim() || !newDesc.trim()) { setFeedback({ tone: 'err', text: 'Item code and description are required.' }); return; }
    if (items.some((i) => i.itemCode.toLowerCase() === newCode.trim().toLowerCase())) {
      setFeedback({ tone: 'err', text: `Item ${newCode} already exists in this entity's item master.` });
      return;
    }
    const item: StockItem = {
      id: uniqueId('ITEM'), clientId: currentClient.id, itemCode: newCode.trim().toUpperCase(), description: newDesc.trim(),
      category: newCategory, uom: newUom, quantityOnHand: 0, unitCost: 0, totalValue: 0,
      reorderLevel: newReorder || undefined, location: 'Main store',
      glAccount: newCategory.toLowerCase().includes('finished') ? '121000' : INVENTORY_ACCOUNT, costMethod: newMethod,
    };
    onAddItem(item);
    setItemCode(item.itemCode);
    setShowNewItem(false);
    setNewCode(''); setNewDesc('');
    setFeedback({ tone: 'ok', text: `Item ${item.itemCode} added to the item master (${newMethod === 'fifo' ? 'FIFO' : 'weighted average'}).` });
  };

  const post = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const blocked = guard();
    if (blocked || !selected) { setFeedback({ tone: 'err', text: blocked || 'Select an item.' }); return; }
    const period = date.slice(0, 7);
    const control = selected.glAccount || INVENTORY_ACCOUNT;

    if (action === 'Sale') {
      if (!canSellStock) { setFeedback({ tone: 'err', text: 'You need Sales & Invoicing access to sell stock. Ask the owner to grant that module.' }); return; }
      if (!Number.isFinite(qty) || qty <= 0 || qty > selected.quantityOnHand + 0.0001) {
        setFeedback({ tone: 'err', text: `Enter a positive sale quantity not exceeding ${selected.quantityOnHand} ${selected.uom} on hand.` }); return;
      }
      // Do not post a stand-alone issue here: the goods invoice creates the
      // receivable, revenue, tax, cost of sales and stock movement together.
      onStartSale(selected.itemCode, qty);
      return;
    }
    if (action === 'ReturnOut') {
      setFeedback({ tone: 'err', text: 'A supplier return needs the source receipt or invoice. Use Procurement → P2P supplier return/debit note; do not debit trade payables from an unlinked stock movement.' });
      return;
    }

    if (action === 'Receipt') {
      if (!canRegisterReceipt) { setFeedback({ tone: 'err', text: 'Receipt matching requires purchase-register permission. Ask an authorised procurement user to receive these goods.' }); return; }
      if (!vendor.trim()) { setFeedback({ tone: 'err', text: 'Enter the supplier so the receipt can be matched to its invoice.' }); return; }
      if (![qty, unitCost, receiptTax].every(Number.isFinite) || qty <= 0 || unitCost <= 0 || receiptTax < 0) {
        setFeedback({ tone: 'err', text: 'Receipt quantity and net unit cost must be positive, and expected input tax cannot be negative.' }); return;
      }
      const result = applyReceipt(selected, qty, unitCost);
      if (result.error) { setFeedback({ tone: 'err', text: result.error }); return; }
      const docNo = `GRN-${period}-${docSuffix()}`;
      const value = result.cost;
      // The receipt register carries the expected invoice values but creates no
      // payable or input-tax posting until the invoice is actually recorded.
      const receiptOrder: PurchaseOrder = {
        id: uniqueId('WH-RECEIPT'), clientId: currentClient.id, poNo: docNo,
        vendorName: vendor.trim(), itemType: 'material', itemCode: selected.itemCode,
        itemDescription: selected.description, qty, unitPrice: unitCost,
        netAmount: value, vatRecoverable: money(receiptTax), totalAmount: money(value + receiptTax),
        paidAmount: 0, status: 'Goods Received', date, currency: currentClient.currency,
        glAccount: control, glAccountName: inventoryAccountName(control),
        costCenter: 'CC-OPS', costCenterName: 'Operations',
      };
      const entries = buildReceiptJournal(receiptOrder, { clientId: currentClient.id, currency: currentClient.currency, date, username: currentUser.username });
      const movement = buildMovement({ clientId: currentClient.id, date, item: selected, type: 'Receipt', quantity: qty, unitCost, totalValue: value, docNo, reference: vendor.trim(), note });
      if (!onAddJournalLines(entries, () => {
        onUndoReceipt(selected, movement.id, receiptOrder.id);
        setFeedback({ tone: 'err', text: `Receipt ${docNo} was rejected by the server; stock and receipt register were rolled back. Review System Notices.` });
      })) { setFeedback({ tone: 'err', text: 'Receipt rejected — check the period, the chart of accounts and duplicate documents.' }); return; }
      onApplyStock(result.item, movement);
      onRegisterReceipt(receiptOrder);
      setFeedback({ tone: 'ok', text: `Receipt ${docNo} posted to inventory and GRNI, not trade payables. Record the supplier invoice under Procurement → Quick purchases when it arrives.` });
      return;
    }

    if (action === 'Freight') {
      if (onCredit) { setFeedback({ tone: 'err', text: 'On-account freight requires a supplier invoice. Use Procurement → P2P landed cost instead of creating an unlinked payable.' }); return; }
      const bank = bankAccounts.find((row) => row.id === bankId && row.clientId === currentClient.id && row.currency === currentClient.currency);
      if (!bank || !bank.glAccount || !/^10\d{4}$/.test(bank.glAccount)) {
        setFeedback({ tone: 'err', text: 'Select a treasury account in this workspace and currency to pay freight.' }); return;
      }
      if (!Number.isFinite(amount) || amount <= 0 || bank.balance + 0.009 < amount) {
        setFeedback({ tone: 'err', text: 'Freight must be positive and covered by the selected posted bank balance.' }); return;
      }
      const result = applyLandedCost(selected, amount);
      if (result.error) { setFeedback({ tone: 'err', text: result.error }); return; }
      const docNo = `FRT-${period}-${docSuffix()}`;
      const entries: ACDOCALine[] = [
        { id: uniqueId('JL-FRT'), docNo, period, date, module: 'MM', docType: 'PO', accountNo: control, accountName: inventoryAccountName(control), costCenter: 'CC-OPS', debit: money(amount), credit: 0, currency: currentClient.currency, description: `Paid inward freight capitalised — ${selected.itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
        { id: uniqueId('JL-FRT'), docNo, period, date, module: 'MM', docType: 'PO', accountNo: bank.glAccount, accountName: bank.name, costCenter: 'CC-OPS', debit: 0, credit: money(amount), currency: currentClient.currency, description: `Paid inward freight for ${selected.itemCode} · ${bank.code}`, createdBy: currentUser.username, clientId: currentClient.id },
      ];
      const movement = buildMovement({ clientId: currentClient.id, date, item: selected, type: 'Freight', quantity: 0, unitCost: 0, totalValue: money(amount), docNo, reference: vendor, note: note || 'Inward freight capitalised' });
      if (!onAddJournalLines(entries, () => onUndoReceipt(selected, movement.id, ''))) { setFeedback({ tone: 'err', text: 'Freight capitalisation rejected — check the period and the chart of accounts.' }); return; }
      onApplyStock(result.item, movement);
      setFeedback({ tone: 'ok', text: `Paid freight ${formatGHS(amount)} capitalised; carrying unit cost ${formatGHS(result.item.unitCost)}.` });
      return;
    }

    if (action === 'Issue') {
      if (!Number.isFinite(qty) || qty <= 0 || !note.trim()) {
        setFeedback({ tone: 'err', text: 'Enter a positive quantity and a reason for internal consumption.' }); return;
      }
      const expense = accounts.find((row) => row.accountNo === expenseAccount && row.active && row.type === 'Expense');
      if (!expense) { setFeedback({ tone: 'err', text: 'Choose an active operating expense account; cost of sales is reserved for customer sales.' }); return; }
      const result = applyIssue(selected, qty, movements, (selected.costMethod as CostMethod) || 'weighted_average');
      if (result.error) { setFeedback({ tone: 'err', text: result.error }); return; }
      const docNo = `ISS-${period}-${docSuffix()}`;
      const entries: ACDOCALine[] = [
        { id: uniqueId('JL-ISS'), docNo, period, date, module: 'INV', docType: 'JE', accountNo: expense.accountNo, accountName: expense.name, costCenter: 'CC-OPS', debit: result.cost, credit: 0, currency: currentClient.currency, description: `Internal consumption ${selected.itemCode} · ${note.trim()}`, createdBy: currentUser.username, clientId: currentClient.id },
        { id: uniqueId('JL-ISS'), docNo, period, date, module: 'INV', docType: 'JE', accountNo: control, accountName: inventoryAccountName(control), costCenter: 'CC-OPS', debit: 0, credit: result.cost, currency: currentClient.currency, description: `Inventory issued for internal consumption ${selected.itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
      ];
      const movement = buildMovement({ clientId: currentClient.id, date, item: selected, type: 'Issue', quantity: qty, unitCost: result.unitCost, totalValue: result.cost, docNo, note });
      if (!onAddJournalLines(entries, () => onUndoReceipt(selected, movement.id, ''))) { setFeedback({ tone: 'err', text: 'Movement rejected — check the period and the chart of accounts.' }); return; }
      onApplyStock(result.item, movement);
      setFeedback({ tone: 'ok', text: `Internal consumption ${formatGHS(result.cost)} posted to ${expense.accountNo}, not sales cost or revenue.` });
      return;
    }

    if (action === 'WriteDown') {
      const required = nrvPerUnit > 0 ? nrvWriteDown(selected, nrvPerUnit) : money(amount);
      if (required <= 0) { setFeedback({ tone: 'err', text: 'No write-down required — cost is already at or below net realisable value.' }); return; }
      const result = applyWriteDown(selected, required);
      if (result.error) { setFeedback({ tone: 'err', text: result.error }); return; }
      const docNo = `NRV-${period}-${docSuffix()}`;
      const entries = buildWriteDownEntries(ctx(docNo), required, selected.itemCode, note || 'lower of cost and net realisable value');
      const movement = buildMovement({ clientId: currentClient.id, date, item: selected, type: 'WriteDown', quantity: 0, unitCost: 0, totalValue: required, docNo, note: note || 'NRV write-down' });
      if (!onAddJournalLines(entries, () => onUndoReceipt(selected, movement.id, ''))) { setFeedback({ tone: 'err', text: 'Write-down rejected — check the period and the chart of accounts.' }); return; }
      onApplyStock({ ...result.item, netRealisableValue: nrvPerUnit > 0 ? nrvPerUnit : result.item.unitCost }, movement);
      setFeedback({ tone: 'ok', text: `Write-down of ${formatGHS(required)} posted — carrying value is now ${formatGHS(result.item.totalValue)}.` });
      return;
    }

    // Stock-count adjustment: qty is the COUNTED quantity.
    const counted = qty;
    const diffQty = Math.round((counted - selected.quantityOnHand) * 1000) / 1000;
    if (diffQty === 0) { setFeedback({ tone: 'err', text: 'Counted quantity equals the book quantity — no adjustment required.' }); return; }
    const rate = selected.unitCost;
    const value = money(diffQty * rate);
    const docNo = `CNT-${period}-${docSuffix()}`;
    const entries = buildAdjustmentEntries(ctx(docNo), value, selected.itemCode, note || 'physical stock count');
    const movement = buildMovement({ clientId: currentClient.id, date, item: selected, type: 'Adjustment', quantity: diffQty, unitCost: rate, totalValue: value, docNo, note: note || 'physical stock count' });
    if (!onAddJournalLines(entries, () => onUndoReceipt(selected, movement.id, ''))) { setFeedback({ tone: 'err', text: 'Adjustment rejected — check the period and the chart of accounts.' }); return; }
    const nextQty = counted;
    const nextValue = money(selected.totalValue + value);
    onApplyStock({ ...selected, quantityOnHand: nextQty, totalValue: nextValue, unitCost: nextQty > 0 ? money(nextValue / nextQty) : selected.unitCost }, movement);
    setFeedback({ tone: 'ok', text: `Count adjustment posted: ${diffQty > 0 ? 'surplus' : 'loss'} of ${Math.abs(diffQty)} ${selected.uom} (${formatGHS(Math.abs(value))}).` });
  };

  const clientMovements = movements.filter((m) => m.clientId === currentClient.id).slice().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 40);

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`INV · Perpetual inventory · ${currentClient.code}`}
        title="Stock, Costing & Cost of Sales (IAS 2)"
        desc="Receipts, sales issues and adjustments update physical stock. The valuation checks raw materials, finished goods, spares and biological stock against their GL controls; WIP is reconciled separately by work order."
      >
        {onNavigate && <button type="button" onClick={() => onNavigate('production_desk')} className="rounded border border-sky-300 bg-white px-2.5 py-1.5 text-xs font-bold text-[#082f4f]">Issue to production / WIP →</button>}
        <ModulePrintButton title={`Inventory & stock register — ${currentClient.name}`} subtitle={`Valuation and movements through ${new Date().toISOString().slice(0, 10)}`} />
        <button onClick={() => setShowNewItem(true)} disabled={isRestricted} className="flex gap-1.5 items-center rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white disabled:opacity-40"><Boxes className="h-4 w-4" /> New item</button>
      </PageHeader>

      {feedback && (
        <div className={`text-xs rounded-lg p-3 border ${feedback.tone === 'ok' ? 'bg-emerald-50 text-emerald-900 border-emerald-300' : 'bg-rose-50 text-rose-900 border-rose-300'}`}>{feedback.text}</div>
      )}

      <div className="grid gap-4 md:grid-cols-3">
        <Card title="Inventory valuation" sub="Item master total">
          <div className="text-2xl font-black text-[#082f4f]">{formatGHS(reconciliation.valuation)}</div>
          <div className="mt-1 text-[11px] text-[#355875]">Physical stock GL (120000, 121000, 123000): {formatGHS(reconciliation.ledger)}</div>
          <div className={`mt-2 rounded px-2 py-1 text-[11px] font-bold ${reconciliation.reconciled ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'}`}>
            {reconciliation.reconciled ? 'Reconciled to the general ledger' : `Difference ${formatGHS(reconciliation.difference)} — investigate before reporting`}
          </div>
        </Card>
        <Card title="Trading result" sub="Posted revenue against posted cost of sales">
          <div className="space-y-1 font-mono text-xs">
            <div>Revenue: {formatGHS(trading.revenue)}</div>
            <div>Cost of sales: {formatGHS(trading.costOfSales)}</div>
            <div className="border-t pt-1 font-bold">Gross profit: {formatGHS(trading.grossProfit)}</div>
            <div>Gross margin: {trading.grossMarginPct}% · Mark-up on cost: {trading.markupOnCostPct}%</div>
          </div>
        </Card>
        <Card title="Stock health" sub="Items below reorder level or carried above NRV">
          <ul className="space-y-1 text-[11px] text-[#355875]">
            {items.filter((i) => i.reorderLevel && i.quantityOnHand <= i.reorderLevel).map((i) => (
              <li key={`re-${i.id}`} className="text-amber-800">Reorder: {i.itemCode} — {i.quantityOnHand} {i.uom} on hand (level {i.reorderLevel})</li>
            ))}
            {items.filter((i) => i.netRealisableValue != null && i.netRealisableValue < i.unitCost).map((i) => (
              <li key={`nrv-${i.id}`} className="text-rose-800">NRV below cost: {i.itemCode} — write-down required</li>
            ))}
            {!items.some((i) => (i.reorderLevel && i.quantityOnHand <= i.reorderLevel) || (i.netRealisableValue != null && i.netRealisableValue < i.unitCost)) && <li>No exceptions.</li>}
          </ul>
        </Card>
      </div>

      <Card title="Item master" sub="Perpetual quantity, cost formula and carrying value for every stocked item.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-xs">
            <thead><tr className="border-b border-sky-200 bg-sky-50/70">
              <th className={thCls}>Item</th><th className={thCls}>Description</th><th className={thCls}>Category</th>
              <th className={thCls}>Cost formula</th><th className={thCls + ' text-right'}>On hand</th>
              <th className={thCls + ' text-right'}>Unit cost</th><th className={thCls + ' text-right'}>Carrying value</th>
              <th className={thCls + ' text-right'}>NRV/unit</th>
            </tr></thead>
            <tbody>
              {items.map((i) => (
                <tr key={i.id} className={rowCls}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{i.itemCode}</td>
                  <td className="px-3 py-2">{i.description}</td>
                  <td className="px-3 py-2">{i.category}</td>
                  <td className="px-3 py-2">{i.costMethod === 'fifo' ? 'FIFO' : i.costMethod === 'specific' ? 'Specific identification' : 'Weighted average'}</td>
                  <td className={numCls}>{i.quantityOnHand} {i.uom}</td>
                  <td className={numCls}>{formatGHS(i.unitCost)}</td>
                  <td className={numCls + ' font-bold'}>{formatGHS(i.totalValue)}</td>
                  <td className={numCls}>{i.netRealisableValue != null ? formatGHS(i.netRealisableValue) : '—'}</td>
                </tr>
              ))}
              {!items.length && <tr><td colSpan={8} className="px-3 py-6 text-center text-[#355875]">No stock items yet — add one to start the perpetual records.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>

      <Card title="Record a stock movement" sub="Every movement posts its own balanced journal and updates the perpetual records in the same action.">
        <form onSubmit={post} className="grid gap-3 md:grid-cols-3 text-xs">
          <label className="block font-bold text-[#355875] md:col-span-2">Movement
            <select value={action} onChange={(e) => setAction(e.target.value as Action)} className="mt-1 block w-full rounded border border-sky-300 p-2">
              {ACTIONS.map((a) => <option key={a.id} value={a.id}>{a.label}</option>)}
            </select>
          </label>
          <label className="block font-bold text-[#355875]">Date
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
          </label>
          <label className="block font-bold text-[#355875]">Item
            <select value={itemCode} onChange={(e) => setItemCode(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2">
              <option value="">Select item</option>
              {items.map((i) => <option key={i.id} value={i.itemCode}>{i.itemCode} · {i.description}</option>)}
            </select>
          </label>
          {(action === 'Receipt' || action === 'Sale' || action === 'Issue' || action === 'ReturnOut' || action === 'Adjustment') && (
            <label className="block font-bold text-[#355875]">{action === 'Adjustment' ? 'Counted quantity' : 'Quantity'}
              <input type="number" min="0" step="0.001" value={qty || ''} onChange={(e) => setQty(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
            </label>
          )}
          {action === 'Issue' && (
            <label className="block font-bold text-[#355875]">Operating expense account (not cost of sales)
              <select value={expenseAccount} onChange={(e) => setExpenseAccount(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono">
                <option value="">Select expense</option>
                {accounts.filter((a) => a.active && a.type === 'Expense' && a.accountNo !== COGS_ACCOUNT)
                  .map((a) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>)}
              </select>
            </label>
          )}
          {action === 'Receipt' && (
            <label className="block font-bold text-[#355875]">Unit cost ({currentClient.currency})
              <input type="number" min="0" step="0.01" value={unitCost || ''} onChange={(e) => setUnitCost(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
            </label>
          )}
          {(action === 'Freight' || action === 'WriteDown') && (
            <label className="block font-bold text-[#355875]">Amount ({currentClient.currency})
              <input type="number" min="0" step="0.01" value={amount || ''} onChange={(e) => setAmount(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
            </label>
          )}
          {action === 'WriteDown' && (
            <label className="block font-bold text-[#355875]">Net realisable value per unit (optional)
              <input type="number" min="0" step="0.01" value={nrvPerUnit || ''} onChange={(e) => setNrvPerUnit(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
            </label>
          )}
          {(action === 'Receipt' || action === 'Freight' || action === 'ReturnOut') && (
            <>
              <label className="block font-bold text-[#355875]">Supplier / counterparty
                <input value={vendor} onChange={(e) => setVendor(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" />
              </label>
              {action === 'Receipt' && (
                <label className="block font-bold text-[#355875]">Expected input tax on invoice (optional)
                  <input type="number" min="0" step="0.01" value={receiptTax || ''} onChange={(e) => setReceiptTax(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
                  <span className="mt-1 block text-[10px] font-normal">For matching only; tax is not posted until the invoice is recorded. Use P2P for invoice variances.</span>
                </label>
              )}
              {action === 'Freight' && (
                <label className="block font-bold text-[#355875]">Freight settlement
                  <select value={onCredit ? 'credit' : 'cash'} onChange={(e) => setOnCredit(e.target.value === 'credit')} className="mt-1 block w-full rounded border border-sky-300 p-2">
                    <option value="cash">Paid from bank (select account below)</option>
                    <option value="credit">On account — use Procurement P2P</option>
                  </select>
                </label>
              )}
              {action === 'Freight' && !onCredit && (
                <label className="block font-bold text-[#355875]">Pay freight from
                  <select value={bankId ?? ''} onChange={(e) => setBankId(Number(e.target.value) || null)} className="mt-1 block w-full rounded border border-sky-300 p-2">
                    <option value="">Select bank account</option>
                    {bankAccounts.filter((b) => b.clientId === currentClient.id && b.currency === currentClient.currency && b.glAccount && /^10\d{4}$/.test(b.glAccount))
                      .map((b) => <option key={b.id} value={b.id}>{b.code} · {b.name} ({formatGHS(b.balance)})</option>)}
                  </select>
                </label>
              )}
            </>
          )}
          <label className="block font-bold text-[#355875] md:col-span-2">Note / reason
            <input value={note} onChange={(e) => setNote(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" placeholder="Supporting reference, approval or reason" />
          </label>
          <div className="md:col-span-3 rounded bg-sky-50 border border-sky-200 p-3 text-[11px] text-[#2d4f6d]">
            {ACTIONS.find((a) => a.id === action)?.help}
            {selected && <div className="mt-1 font-mono">On hand: {selected.quantityOnHand} {selected.uom} · unit cost {formatGHS(selected.unitCost)} · value {formatGHS(selected.totalValue)}</div>}
          </div>
          <div className="md:col-span-3 flex justify-end">
            <button type="submit" className="flex items-center gap-1.5 rounded bg-[#082f4f] px-4 py-2 text-xs font-bold text-white"><Save className="h-4 w-4" /> {action === 'Sale' ? 'Continue to Sales & Invoicing' : action === 'ReturnOut' ? 'Open return guidance' : 'Post movement'}</button>
          </div>
        </form>
      </Card>

      <Card title="Movement history" sub="Receipts, issues, freight, returns, write-downs and count adjustments with their posted document.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-xs">
            <thead><tr className="border-b border-sky-200 bg-sky-50/70">
              <th className={thCls}>Date</th><th className={thCls}>Document</th><th className={thCls}>Item</th>
              <th className={thCls}>Type</th><th className={thCls + ' text-right'}>Qty</th>
              <th className={thCls + ' text-right'}>Unit cost</th><th className={thCls + ' text-right'}>Value</th><th className={thCls}>Note</th>
            </tr></thead>
            <tbody>
              {clientMovements.map((m) => (
                <tr key={m.id} className={rowCls}>
                  <td className="px-3 py-2 font-mono">{m.date}</td>
                  <td className="px-3 py-2 font-mono text-[#855b00]">{m.docNo || '—'}</td>
                  <td className="px-3 py-2 font-mono">{m.itemCode}</td>
                  <td className="px-3 py-2">{m.type}</td>
                  <td className={numCls}>{m.quantity}</td>
                  <td className={numCls}>{formatGHS(m.unitCost)}</td>
                  <td className={numCls}>{formatGHS(m.totalValue)}</td>
                  <td className="px-3 py-2 text-[11px] text-[#355875]">{m.note || m.reference || '—'}</td>
                </tr>
              ))}
              {!clientMovements.length && <tr><td colSpan={8} className="px-3 py-6 text-center text-[#355875]">No stock movements recorded yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>

      {showNewItem && (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/50 p-4">
          <form onSubmit={addItem} className="my-8 w-full max-w-lg space-y-3 rounded-xl bg-white p-6 text-xs shadow-xl">
            <h3 className="border-b border-sky-100 pb-2 text-base font-bold text-[#082f4f]">New stock item</h3>
            <label className="block font-bold text-[#355875]">Item code<input value={newCode} onChange={(e) => setNewCode(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" /></label>
            <label className="block font-bold text-[#355875]">Description<input value={newDesc} onChange={(e) => setNewDesc(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" /></label>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block font-bold text-[#355875]">Category (sets the stock GL)
                <select value={newCategory} onChange={(e) => setNewCategory(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2">
                  <option value="Merchandise">Merchandise / trading stock → 120000</option>
                  <option value="Raw Materials">Raw materials / inputs → 120000</option>
                  <option value="Finished Goods">Finished goods / production output → 121000</option>
                  <option value="Consumables">Spares & consumables → 120000</option>
                </select>
              </label>
              <label className="block font-bold text-[#355875]">Unit of measure<input value={newUom} onChange={(e) => setNewUom(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" /></label>
              <label className="block font-bold text-[#355875]">Cost formula
                <select value={newMethod} onChange={(e) => setNewMethod(e.target.value as CostMethod)} className="mt-1 block w-full rounded border border-sky-300 p-2">
                  <option value="weighted_average">Weighted average</option>
                  <option value="fifo">First-in, first-out (FIFO)</option>
                  <option value="specific">Specific identification</option>
                </select>
              </label>
              <label className="block font-bold text-[#355875]">Reorder level<input type="number" min="0" step="0.001" value={newReorder || ''} onChange={(e) => setNewReorder(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" /></label>
            </div>
            <p className="rounded bg-sky-50 border border-sky-200 p-2 text-[10.5px] text-[#2d4f6d]">The cost formula is fixed per item and applied consistently (IAS 2.25); changing it later would rewrite historical profit.</p>
            <div className="flex justify-end gap-2 border-t border-sky-100 pt-3">
              <button type="button" onClick={() => setShowNewItem(false)} className="px-3 py-2">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-2 font-bold text-white">Add item</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
