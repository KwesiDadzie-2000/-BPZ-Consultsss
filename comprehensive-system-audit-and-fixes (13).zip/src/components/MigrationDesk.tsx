'use client';

import { useRef, useState } from 'react';
import { AlertTriangle, CheckCircle2, FileUp, RefreshCw, Rocket, Upload } from 'lucide-react';
import { apiFetch } from '@/utils/session';
import { localToday } from '@/utils/periods';
import { downloadCsv } from '@/utils/printReport';
import type { ClientEntity, UserAccount } from '@/types/accounting';
import { Badge, Card, PageHeader, formatGHS, cn, thCls, tdCls, rowCls } from './ui';

type Kind = 'opening' | 'ledger' | 'partners' | 'banks';
type Preview = Record<string, unknown> & { ok: boolean; kind?: Kind; rows?: number; documents?: number; totalDebit?: number; totalCredit?: number; balanced?: boolean; sample?: string[]; customers?: number; vendors?: number; errors?: { row: number; message: string }[] };

const KINDS: { id: Kind; label: string; help: string; columns: string }[] = [
  { id: 'opening', label: 'Opening balances', help: 'The signed opening trial balance at your cut-over date. Every account as Dr or Cr, never both.', columns: 'Account, Debit, Credit' },
  { id: 'ledger', label: 'Ledger history', help: 'Historical journal documents. Each document must balance (Dr = Cr).', columns: 'Document, Date, Account, Debit, Credit, Description' },
  { id: 'partners', label: 'Customers & vendors', help: 'Party master with credit limits and terms.', columns: 'Code, Name, Type, CreditLimit, CreditTermsDays, TIN, Email, Phone' },
  { id: 'banks', label: 'Bank accounts', help: 'Treasury records mapped to 10xxxx GL accounts.', columns: 'Code, Name, Bank, AccountNo, GL, OpeningBalance' },
];

export function MigrationDesk({ currentClient, currentUser }: { currentClient: ClientEntity; currentUser: UserAccount }) {
  const [kind, setKind] = useState<Kind>('opening');
  const [date, setDate] = useState(() => `${localToday().slice(0, 4)}-01-01`);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [committed, setCommitted] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [content, setContent] = useState('');
  const [fileName, setFileName] = useState('');
  const fileRef = useRef<HTMLInputElement | null>(null);

  const meta = KINDS.find((k) => k.id === kind)!;
  const post = async (mode: 'preview' | 'commit') => {
    setError(null); setCommitted(null); setPreview(null);
    if (!content.trim()) { setError('Choose a CSV file first.'); return; }
    setBusy(true);
    try {
      const res = await apiFetch('/api/migrate', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ kind, clientId: currentClient.id, content, date, mode }),
      });
      const body = (await res.json().catch(() => null)) as Preview & { ok: boolean; migrated?: number; documents?: number; error?: string };
      if (!body?.ok) {
        setError(body?.error || (body?.errors ? body.errors.map((e) => `Row ${e.row}: ${e.message}`).join(' · ') : 'The migration could not be completed.'));
        if (body?.errors) setPreview(body as Preview);
        return;
      }
      if (mode === 'preview') setPreview(body as Preview);
      else setCommitted(`Migrated ${body.migrated} ${kind === 'ledger' ? 'lines' : 'rows'}${body.documents ? ` across ${body.documents} documents` : ''} into ${currentClient.name}.`);
    } catch {
      setError('The migration request could not reach the server.');
    } finally { setBusy(false); }
  };

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    setError(null); setCommitted(null); setPreview(null);
    if (!/\.(csv|tsv|txt)$/i.test(file.name)) { setError('Export the data as CSV, TSV or plain text first.'); return; }
    if (file.size > 5 * 1024 * 1024) { setError('File is larger than 5 MB. Split the export.'); return; }
    const data = new Uint8Array(await file.arrayBuffer());
    const encoding = data[0] === 0xff && data[1] === 0xfe ? 'utf-16le' : data[0] === 0xfe && data[1] === 0xff ? 'utf-16be' : 'utf-8';
    setContent(new TextDecoder(encoding).decode(data));
    setFileName(file.name);
    fileRef.current?.setAttribute('data-loaded', 'true');
  };

  const downloadTemplate = () => {
    const templates: Record<Kind, string[][]> = {
      opening: [['Account', 'Debit', 'Credit'], ['100000', '250000', '0'], ['120000', '180000', '0'], ['200000', '0', '90000'], ['309000', '0', '340000']],
      ledger: [['Document', 'Date', 'Account', 'Debit', 'Credit', 'Description'], ['JV-0001', '2026-01-15', '621000', '1000', '0', 'Legal fees'], ['JV-0001', '2026-01-15', '100000', '0', '1000', 'Legal fees']],
      partners: [['Code', 'Name', 'Type', 'CreditLimit', 'CreditTermsDays', 'TIN', 'Email', 'Phone'], ['C001', 'Accra Retail Ltd', 'Customer', '50000', '30', 'C001', 'a@example.com', '+233'], ['V001', 'SteelMasters Ltd', 'Vendor', '0', '0', 'V001', 's@example.com', '+233']],
      banks: [['Code', 'Name', 'Bank', 'AccountNo', 'GL', 'OpeningBalance'], ['BNK-01', 'Operating Account', 'GCB', '0012345678', '100000', '250000']],
    };
    downloadCsv(`bpz-migration-${kind}-template.csv`, templates[kind]);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`MIG · Data migration · ${currentClient.code}`}
        title="Migrate from another system"
        desc="Import opening balances, ledger history, customers/vendors and bank accounts from a legacy system or spreadsheet. Nothing is written until the whole file validates."
      >
        <Badge tone="fi">ONE TRANSACTION</Badge>
        <button type="button" onClick={downloadTemplate} className="rounded-lg border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50">
          <Upload className="mr-1 inline h-3.5 w-3.5" /> Download CSV template
        </button>
      </PageHeader>

      <Card title="Choose what to migrate" sub="Pick a family, then upload the matching CSV. Always preview before committing.">
        <div className="flex flex-wrap gap-2">
          {KINDS.map((k) => (
            <button key={k.id} type="button" onClick={() => { setKind(k.id); setPreview(null); setCommitted(null); setError(null); setContent(''); setFileName(''); }}
              className={cn('rounded-lg px-4 py-2 text-xs font-bold transition', kind === k.id ? 'bg-[#082f4f] text-white' : 'border border-sky-200 bg-white text-[#355875] hover:bg-sky-50')}>
              {k.label}
            </button>
          ))}
        </div>
        <div className="mt-3 rounded-lg border border-sky-200 bg-[#f7fbff] p-3 text-xs text-[#2d4f6d]">
          <p className="font-semibold text-[#082f4f]">{meta.help}</p>
          <p className="mt-1 font-mono">Expected columns: {meta.columns}</p>
        </div>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <label className="grid gap-1.5 text-xs font-bold text-[#2d4f6d]">CSV file
            <input ref={fileRef} type="file" accept=".csv,.tsv,.txt,text/csv,text/plain" onChange={(e) => { void onFile(e.target.files?.[0]); e.currentTarget.value = ''; }} className="w-full rounded-lg border border-sky-200 bg-white px-3 py-2 text-sm text-[#082f4f]" />
            {fileName && <span className="text-[11px] text-emerald-700">Loaded: {fileName}</span>}
          </label>
          {kind === 'opening' && (
            <label className="grid gap-1.5 text-xs font-bold text-[#2d4f6d]">Cut-over date
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full rounded-lg border border-sky-200 bg-white px-3 py-2 text-sm text-[#082f4f]" />
            </label>
          )}
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <button type="button" disabled={busy || !content} onClick={() => void post('preview')} className="inline-flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-4 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 disabled:opacity-40">
            <RefreshCw className={cn('h-3.5 w-3.5', busy && 'animate-spin')} /> Preview / validate
          </button>
          <button type="button" disabled={busy || !content || !preview?.ok} onClick={() => void post('commit')} className="inline-flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] disabled:opacity-40">
            <Rocket className="h-3.5 w-3.5" /> Commit migration
          </button>
        </div>
      </Card>

      {error && (
        <div role="alert" className="flex items-start gap-2 rounded-xl border border-rose-300 bg-rose-50 p-3 text-xs text-rose-800">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /><span>{error}</span>
        </div>
      )}
      {committed && (
        <div role="status" className="flex items-start gap-2 rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-xs text-emerald-800">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" /><span>{committed}</span>
        </div>
      )}

      {preview && preview.ok && (
        <Card title="Preview" sub={`${preview.rows ?? 0} row(s) ready to migrate${preview.documents ? ` across ${preview.documents} document(s)` : ''}`}>
          <div className="flex flex-wrap gap-4 text-xs font-mono">
            {typeof preview.totalDebit === 'number' && <span className="text-[#355875]">Total Dr: <strong className="text-[#082f4f]">{formatGHS(preview.totalDebit)}</strong></span>}
            {typeof preview.totalCredit === 'number' && <span className="text-[#355875]">Total Cr: <strong className="text-[#082f4f]">{formatGHS(preview.totalCredit)}</strong></span>}
            {typeof preview.balanced === 'number' && <span>{preview.balanced ? 'Balanced' : 'Out of balance'}</span>}
            {typeof preview.customers === 'number' && <span className="text-[#355875]">Customers: <strong className="text-[#082f4f]">{preview.customers}</strong></span>}
            {typeof preview.vendors === 'number' && <span className="text-[#355875]">Vendors: <strong className="text-[#082f4f]">{preview.vendors}</strong></span>}
          </div>
          {Array.isArray(preview.sample) && preview.sample.length > 0 && (
            <table className="mt-3 w-full text-xs">
              <thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Sample rows</th></tr></thead>
              <tbody>{preview.sample.map((s, i) => <tr key={i} className={rowCls}><td className={cn(tdCls, 'font-mono')}>{s}</td></tr>)}</tbody>
            </table>
          )}
        </Card>
      )}
    </div>
  );
}
