'use client';

import { useCallback, useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, DatabaseBackup, RefreshCw, ShieldCheck } from 'lucide-react';
import { apiFetch } from '@/utils/session';
import { Badge, Card, PageHeader } from './ui';
import type { ReleaseGate } from '@/lib/parallelClose';

type Health = {
  ok: boolean;
  database: string;
  latencyMs: number;
  releaseGates: ReleaseGate[];
  backup: { lastSuccessAt?: string; lastError?: string; file?: string; offsite?: string; offsiteUri?: string; stale: boolean; ageHours: number | null; tableCount?: number; rowCount?: number; sha256?: string };
  events: { id: string; at: string; level: string; event: string; detail?: Record<string, unknown> }[];
};

/** Owner-only operational controls: real backup creation and non-destructive verification. */
export function OperationsDesk({ onOpenParallelClose }: { onOpenParallelClose?: () => void }) {
  const [health, setHealth] = useState<Health | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const load = useCallback(async () => {
    try {
      const res = await apiFetch('/api/ops/health');
      const body = await res.json().catch(() => null);
      if (res.ok && body) setHealth(body as Health);
      else setMessage({ ok: false, text: body?.error || 'Operational health could not be loaded.' });
    } catch { setMessage({ ok: false, text: 'The operations server is unreachable. Refresh to retry.' }); }
  }, []);
  useEffect(() => { const timer = window.setTimeout(() => { void load(); }, 0); return () => window.clearTimeout(timer); }, [load]);

  const runBackup = async () => {
    setBusy(true); setMessage(null);
    try {
      const res = await apiFetch('/api/backups', { method: 'POST' });
      const body = await res.json().catch(() => null);
      if (!res.ok || !body?.ok) { setMessage({ ok: false, text: body?.error || `Backup failed (HTTP ${res.status})` }); return; }
      setMessage({ ok: true, text: `Snapshot created (${body.rowCount} rows in ${body.tableCount} tables). Off-site: ${body.offsite}. The off-site restore still requires the production verification drill.` });
      await load();
    } catch { setMessage({ ok: false, text: 'The server did not confirm this operation. Refresh before retrying.' }); } finally { setBusy(false); }
  };

  const verify = async () => {
    if (!health?.backup.file) return;
    setBusy(true); setMessage(null);
    try {
      const res = await apiFetch('/api/backups', { method: 'PUT', body: JSON.stringify({ file: health.backup.file }) });
      const body = await res.json().catch(() => null);
      setMessage({ ok: Boolean(body?.ok), text: body?.ok ? `Verified ${body.tableCount} tables / ${body.rowCount} rows. No data was restored.` : (body?.error || 'Verification failed') });
    } catch { setMessage({ ok: false, text: 'The server did not confirm this operation. Refresh before retrying.' }); } finally { setBusy(false); }
  };

  return <div className="space-y-5">
    <PageHeader kicker="OPS · Backup, recovery & monitoring" title="Operations & Disaster Recovery" desc="Owner-only operational controls. A backup is not considered complete until the off-site copy and restore verification both succeed.">
      <button onClick={load} className="rounded border border-sky-300 bg-white px-3 py-1.5 text-xs font-bold text-[#082f4f] inline-flex items-center gap-1.5"><RefreshCw className="h-3.5 w-3.5" /> Refresh</button>
      <button onClick={runBackup} disabled={busy} className="rounded bg-[#082f4f] px-3 py-1.5 text-xs font-bold text-white inline-flex items-center gap-1.5 disabled:opacity-50"><DatabaseBackup className="h-3.5 w-3.5" /> {busy ? 'Working…' : 'Back up now'}</button>
    </PageHeader>
    {message && <div role="alert" className={`rounded-xl border p-3 text-xs font-bold ${message.ok ? 'border-emerald-300 bg-emerald-50 text-emerald-900' : 'border-rose-300 bg-rose-50 text-rose-900'}`}>{message.text}</div>}
    <div className="grid gap-4 md:grid-cols-3">
      <Card title="Database health" sub="Live query latency">
        <div className="flex items-center gap-2 text-sm font-bold">{health?.database === 'ok' ? <CheckCircle2 className="h-5 w-5 text-emerald-600" /> : <AlertTriangle className="h-5 w-5 text-rose-600" />}{health?.database ?? 'Checking…'}</div>
        <p className="mt-2 text-xs text-[#355875]">{health?.latencyMs ?? '—'} ms · authenticated owner check</p>
      </Card>
      <Card title="Backup freshness" sub="Scheduled worker + off-site copy">
        {!health ? <Badge>Checking…</Badge> : health.backup.stale ? <Badge tone="red">STALE / NOT VERIFIED</Badge> : <Badge tone="green">Current</Badge>}
        <p className="mt-2 text-xs text-[#355875]">Last success: {health?.backup.lastSuccessAt ?? 'never'}</p>
        <p className="mt-1 text-xs text-[#355875]">Off-site: {health?.backup.offsite ?? 'unknown'}{health?.backup.ageHours != null ? ` · ${health.backup.ageHours.toFixed(1)}h old` : ''}</p>
      </Card>
      <Card title="Restore verification" sub="Non-destructive snapshot check">
        <p className="text-xs text-[#355875]">{health?.backup.tableCount ?? '—'} tables · {health?.backup.rowCount ?? '—'} rows</p>
        <button onClick={verify} disabled={busy || !health?.backup.file} className="mt-3 rounded border border-sky-300 bg-white px-3 py-1.5 text-xs font-bold text-[#082f4f] inline-flex items-center gap-1.5 disabled:opacity-40"><ShieldCheck className="h-3.5 w-3.5" /> Verify latest backup</button>
        <p className="mt-2 text-[10px] text-[#355875]">Full restore drill also runs in CI and with the recovery script.</p>
      </Card>
    </div>
    <Card title="Production release evidence" sub="A local parse is not an off-site recovery test." action={onOpenParallelClose && <button type="button" onClick={onOpenParallelClose} className="rounded border border-sky-300 bg-white px-3 py-1.5 text-xs font-bold text-[#082f4f]">Open Parallel Close</button>}>
      <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-3">{health?.releaseGates.map((gate) => <div key={gate.key} className="rounded-lg border border-sky-100 bg-[#f7fbff] p-3 text-xs">
        <div className="flex flex-wrap items-center justify-between gap-2"><strong className="text-[#082f4f]">{gate.label}</strong><Badge tone={gate.passed ? 'green' : 'amber'}>{gate.passed ? 'Verified' : 'Required'}</Badge></div><p className="mt-1.5 leading-relaxed text-[#355875]">{gate.detail}</p>
      </div>)}</div>
      <p className="mt-3 text-xs text-[#355875]">Operator commands: <code>npx tsx scripts/verify-production.mts</code> and <code>npx tsx scripts/verify-recovery.mts --offsite</code>.</p>
    </Card>
    <Card title="Operational events" sub="Recent backup, recovery and security events (newest first)">
      {health?.events.length ? <div className="overflow-x-auto"><table className="w-full min-w-[680px] text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70 text-left"><th className="p-2">Time</th><th className="p-2">Level</th><th className="p-2">Event</th><th className="p-2">Detail</th></tr></thead><tbody>{health.events.map((event) => <tr key={event.id} className="border-b border-sky-100"><td className="p-2 font-mono text-[#355875]">{event.at.slice(0, 19).replace('T', ' ')}</td><td className="p-2">{event.level === 'error' ? <Badge tone="red">{event.level}</Badge> : event.level === 'warn' ? <Badge tone="amber">{event.level}</Badge> : <Badge tone="green">{event.level}</Badge>}</td><td className="p-2 font-bold">{event.event}</td><td className="p-2 font-mono text-[10px] text-[#355875]">{JSON.stringify(event.detail ?? {})}</td></tr>)}</tbody></table></div> : <p className="text-xs text-[#355875]">No operational events yet. Run a backup to create the first verified event.</p>}
    </Card>
  </div>;
}
