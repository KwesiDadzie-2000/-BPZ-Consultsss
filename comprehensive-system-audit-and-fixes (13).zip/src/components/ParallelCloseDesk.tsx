'use client';

import { useEffect, useState } from 'react';
import { ArrowRight, Check, ClipboardCheck, CloudUpload, Download, FileCheck2, FileText, LockKeyhole, RefreshCw, ShieldCheck, Trash2, UserPlus } from 'lucide-react';
import { apiFetch } from '@/utils/session';
import { localToday } from '@/utils/periods';
import { downloadCsv } from '@/utils/printReport';
import type { ClientEntity } from '@/types/accounting';
import { CLOSE_CHECKS, compareTrial, controlResult, EMPTY_CHECK, EMPTY_WORK, EVIDENCE_FILE_LIMIT,
  moneyDecimal, TRIAL_FILE_LIMIT, type CloseEvidence, type CloseKey, type CutoverView, type CutoverWork, type EvidenceKey } from '@/lib/parallelClose';
import { Badge, Card, PageHeader, Stat, formatGHS, cn, thCls, tdCls } from './ui';

const tabs = [
  { id: 'overview', label: 'Overview' }, { id: 'trial', label: 'Trial balance' }, { id: 'controls', label: 'Control accounts' },
  { id: 'evidence', label: 'Evidence' }, { id: 'review', label: 'Review & go-live' },
] as const;
type Tab = typeof tabs[number]['id'];
const labels = { draft: 'Draft', returned: 'Needs revision', submitted: 'Awaiting review', approved: 'Independently approved', active: 'Live books' };
const input = 'w-full rounded-lg border border-sky-200 bg-white px-3 py-2 text-sm text-[#082f4f] outline-none focus:border-[#006f98] focus:ring-2 focus:ring-sky-100 disabled:bg-slate-100 disabled:text-slate-600';
const secondary = 'inline-flex items-center justify-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 disabled:opacity-40';
const primary = 'inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#104b71] disabled:opacity-40';
const field = 'grid gap-1.5 text-xs font-bold text-[#2d4f6d]';
const box = 'rounded-xl border border-sky-200 bg-[#f7fbff] p-3.5';
const when = (value?: string | null) => value ? new Date(value).toLocaleString('en-GH', { dateStyle: 'medium', timeStyle: 'short' }) : '—';

function previousMonth() {
  const [year, month] = localToday().split('-').map(Number);
  return new Date(Date.UTC(year, month - 2, 1)).toISOString().slice(0, 7);
}
const base64 = (bytes: ArrayBuffer) => {
  const typed = new Uint8Array(bytes);
  let text = '';
  for (let i = 0; i < typed.length; i += 8192) text += String.fromCharCode(...typed.subarray(i, i + 8192));
  return btoa(text);
};

export function ParallelCloseDesk({ client, onActivated, onNavigate }: {
  client: ClientEntity;
  onActivated: (period: string) => void;
  onNavigate: (section: string) => void;
}) {
  const [month, setMonth] = useState(previousMonth);
  const [period, setPeriod] = useState(month);
  const [reload, setReload] = useState(0);
  const [view, setView] = useState<CutoverView | null>(null);
  const [draft, setDraft] = useState<CutoverWork>(EMPTY_WORK);
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ message: string; bad?: boolean } | null>(null);
  const [tab, setTab] = useState<Tab>('overview');
  const [evidenceKey, setEvidenceKey] = useState<EvidenceKey>('opening');
  const [differenceOnly, setDifferenceOnly] = useState(true);
  const [trialPage, setTrialPage] = useState(0);
  const [reviewNotes, setReviewNotes] = useState('');
  const [reviewConfirmed, setReviewConfirmed] = useState(false);
  const [confirmCode, setConfirmCode] = useState('');
  const [invite, setInvite] = useState<{ name: string; username: string; email: string; password: string } | null>(null);
  const url = `/api/parallel-close?clientId=${client.id}&period=${encodeURIComponent(period)}`;
  useEffect(() => {
    const controller = new AbortController();
    let settled = false;
    // A hung or aborted load must never leave the desk stuck on "Loading",
    // because `uploadDisabled` keys off the loaded packet and would otherwise
    // disable every import button on this desk indefinitely. Always finish in
    // a known state (loaded, or an error with a retry).
    const timer = setTimeout(() => { if (!settled) { settled = true; controller.abort(); setNotice({ bad: true, message: 'The close packet took too long to load. Check the connection and retry.' }); } }, 20000);
    void (async () => {
      try {
        const res = await apiFetch(url, { signal: controller.signal });
        const body = await res.json().catch(() => null);
        if (settled) return;
        if (!res.ok || !body?.close) { settled = true; setNotice({ bad: true, message: body?.error ?? `The close packet could not be loaded (HTTP ${res.status}).` }); return; }
        settled = true;
        setView(body.close); setDraft(body.close.packet?.work ?? EMPTY_WORK); setDirty(false); setNotice(null);
      } catch (error) {
        if (settled) return;
        settled = true;
        setNotice({ bad: true, message: error instanceof Error ? error.message : 'Close unavailable. Reload the packet.' });
      } finally {
        clearTimeout(timer);
      }
    })();
    return () => { settled = true; clearTimeout(timer); controller.abort(); };
  }, [url, reload]);

  const resetLoad = () => { setView(null); setNotice(null); setReload((v) => v + 1); };
  const refresh = () => { if (!dirty || window.confirm('Discard your unsaved changes and reload the close packet?')) resetLoad(); };
  const packet = view?.packet;
  const editable = !!view?.permissions.prepare && (!packet || packet.status === 'draft' || packet.status === 'returned');
  const change = (patch: Partial<CutoverWork>) => { setDraft((prev) => ({ ...prev, ...patch })); setDirty(true); };
  type WorkRow = NonNullable<CutoverWork['checks'][CloseKey]>;
  const changeRow = (key: CloseKey, patch: Partial<WorkRow>) => {
    setDraft((prev) => ({ ...prev, checks: { ...prev.checks, [key]: { ...(prev.checks[key] ?? EMPTY_CHECK), ...patch } } })); setDirty(true);
  };
  const post = async (action: string, fields: Record<string, unknown> = {}) => {
    const response = await apiFetch(url, { method: 'POST', body: JSON.stringify({ action, version: packet?.version ?? 0, ...fields }) });
    const data = await response.json().catch(() => null);
    if (!response.ok || !data?.close) throw new Error(data?.error ?? 'The change could not be confirmed. Reload the packet before trying again.');
    setView(data.close); setDraft(data.close.packet?.work ?? EMPTY_WORK); setDirty(false);
    if (action === 'activate') onActivated(period);
  };
  const doWork = async (task: () => Promise<void>, success: string) => {
    if (busy || !view) return;
    setBusy(true); setNotice(null);
    try { await task(); setNotice({ message: success }); }
    catch (error) { setNotice({ bad: true, message: error instanceof Error ? error.message : 'The change could not be saved.' }); }
    finally { setBusy(false); }
  };
  const submitAction = (action: string, success: string, fields: Record<string, unknown> = {}) => void doWork(() => post(action, fields), success);
  const readUpload = (file: File | undefined, key: EvidenceKey) => {
    if (!file) return;
    void doWork(async () => {
      if (file.size > (key === 'legacy_trial' ? TRIAL_FILE_LIMIT : EVIDENCE_FILE_LIMIT)) throw new Error('The file exceeds this evidence category’s size limit.');
      await post('upload', { key, name: file.name, data: base64(await file.arrayBuffer()) });
      setTrialPage(0);
    }, key === 'legacy_trial' ? 'Legacy trial balance imported and compared to the ledger.' : 'Supporting file attached to this month.');
  };
  const getFile = (item: CloseEvidence) => void doWork(async () => {
    const res = await apiFetch(`${url}&file=${encodeURIComponent(item.id)}`);
    if (!res.ok) throw new Error('The requested evidence is no longer available.');
    const blob = URL.createObjectURL(await res.blob());
    const link = document.createElement('a'); link.href = blob; link.download = item.name; link.click();
    window.setTimeout(() => URL.revokeObjectURL(blob), 5_000);
  }, 'Evidence downloaded.');

  const createReviewer = () => {
    if (!invite) return;
    void doWork(async () => {
      const response = await apiFetch('/api/users', { method: 'PUT', body: JSON.stringify({ createCloseReviewer: true, user: { ...invite, clientId: client.id } }) });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data?.ok) throw new Error(data?.error ?? 'The reviewer account could not be confirmed.');
      setInvite(null);
    }, `Reviewer ${invite.username} created for ${client.code}. Share the temporary password privately; this account cannot post or prepare the close.`);
  };

  const ledger = view?.ledger;
  const trial = ledger ? compareTrial(ledger.trial, draft.legacyTrial?.entries ?? []) : null;
  const readyChecks = CLOSE_CHECKS.filter((check) => {
    const item = draft.checks[check.key]; const state = controlResult(check, item);
    return state.ready && (check.kind !== 'amount' || state.bpz === ledger?.anchors[check.key])
      && (check.kind === 'optional' && item?.result === 'not_applicable' || view?.evidence.some((f) => f.key === check.key));
  }).length;
  const gatesPassed = view?.gates.filter((gate) => gate.passed).length ?? 0;
  const matchOnly = differenceOnly && !!draft.legacyTrial;
  const visible = trial?.rows.filter((row) => !matchOnly || row.variance !== 0) ?? [];
  const pages = Math.max(1, Math.ceil(visible.length / 40));
  const page = Math.min(trialPage, pages - 1);
  const money = (n: number | null | undefined) => n == null ? '—' : formatGHS(n / 100);
  const labelFor = (key: EvidenceKey) => key === 'legacy_trial' ? 'Legacy trial balance' : CLOSE_CHECKS.find((c) => c.key === key)?.label ?? key;
  const uploadDisabled = !packet || !editable || busy || dirty;
  const signed = packet?.status === 'approved' || packet?.status === 'active';
  const isDesignated = !!view?.activePeriod;
  const exportSummary = () => {
    if (!view || !packet) return;
    downloadCsv(`${client.code}-parallel-close-${period}.csv`, [
      ['Parallel Close', client.name, period, view.client.currency], ['Status', labels[packet.status]], ['Packet version', packet.version],
      ['Prepared by', packet.preparedBy], ['Submitted by', packet.submittedBy], ['Reviewed by', packet.reviewedBy, packet.reviewedAt],
      ['Review notes', packet.reviewNotes], ['Activated by', packet.activatedBy, packet.activatedAt], ['Legacy source', packet.work.reference],
      ['Legacy CSV hash', packet.work.legacyTrial?.sha256], ['Current ledger hash', view.ledger.hash], ['Seal stale', view.signoffStale ? 'Yes' : 'No'], [],
      ['Control', 'Legacy amount', 'BPZ amount', 'Variance', 'Reference', 'Result', 'Notes'],
      ...CLOSE_CHECKS.map((c) => { const r = packet.work.checks[c.key] ?? EMPTY_CHECK; const check = controlResult(c, r);
        return [c.label, check.legacy === null ? null : check.legacy / 100, check.bpz === null ? null : check.bpz / 100, check.variance === null ? null : check.variance / 100, r.reference, r.result, r.notes]; }), [],
      ['Evidence category', 'File', 'SHA-256', 'Uploaded by'], ...view.evidence.map((e) => [labelFor(e.key), e.name, e.sha256, e.actor]), [],
      ['Audit action', 'Actor', 'At', 'Detail'], ...view.history.map((e) => [e.action, e.actor, e.at, e.detail]),
    ]);
  };

  return <div className="space-y-5">
    <PageHeader kicker={<span className="inline-flex items-center gap-1.5"><ShieldCheck className="h-4 w-4" /> Release controls · {client.code}</span>}
      title="Parallel Close & Go-Live" desc="Reconcile one complete month against the existing books, retain the evidence and obtain independent sign-off before cutover.">
      <button type="button" onClick={refresh} disabled={busy} className={secondary}><RefreshCw className="h-3.5 w-3.5" /> Refresh</button>
      {editable && <button type="button" disabled={busy || !!packet && !dirty} onClick={() => submitAction('save', 'Draft saved on the server.', { work: draft })} className={primary}><Check className="h-3.5 w-3.5" /> {packet ? 'Save draft' : 'Create draft'}</button>}
    </PageHeader>
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-sky-200 bg-white p-3.5">
      <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => {
        e.preventDefault();
        if (!month || busy || dirty && !window.confirm('Discard your unsaved changes and open the selected month?')) return;
        setPeriod(month); setView(null); setNotice(null); setReviewNotes(''); setReviewConfirmed(false); setConfirmCode(''); setInvite(null); setTrialPage(0); setReload((v) => v + 1);
      }}>
        <label className={field}>Pilot month<input className={input} type="month" required max={localToday().slice(0, 7)} value={month} onChange={(e) => setMonth(e.target.value)} /></label>
        <button type="submit" disabled={busy} className={secondary}>Open month</button>
      </form>
      <div className="flex flex-wrap items-center gap-2"><Badge>{period} · {view?.client.currency ?? client.currency}</Badge>
        <Badge tone={packet?.status === 'active' ? 'green' : packet?.status === 'returned' ? 'red' : packet?.status === 'submitted' ? 'amber' : 'fi'}>{packet ? labels[packet.status] : 'No close packet'}</Badge>
        {dirty && <Badge tone="amber">Unsaved changes</Badge>}
        {isDesignated && <Badge tone="green">Live from close {view?.activePeriod}</Badge>}
      </div>
    </div>
    {notice && <div role={notice.bad ? 'alert' : 'status'} className={cn('rounded-xl border px-4 py-3 text-sm', notice.bad ? 'border-rose-300 bg-rose-50 text-rose-950' : 'border-emerald-200 bg-emerald-50 text-emerald-900')}>{notice.message}</div>}
    {!view && <Card title={notice?.bad ? 'Close packet unavailable' : 'Loading close packet'}>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-xs text-[#355875]" role={notice?.bad ? 'alert' : 'status'}>
          {notice?.bad ? (notice.message || 'Refresh to retry.') : 'Reading the posted ledger and release controls…'}
        </p>
        <button type="button" onClick={refresh} className="inline-flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50">
          <RefreshCw className="h-3.5 w-3.5" /> {notice?.bad ? 'Retry load' : 'Refresh'}
        </button>
      </div>
    </Card>}
    {view && <>
      <div role="tablist" aria-label="Parallel close sections" className="flex flex-wrap gap-1 rounded-xl border border-sky-200 bg-white p-1.5">
        {tabs.map((entry) => <button key={entry.id} type="button" id={`close-tab-${entry.id}`} role="tab" aria-controls="close-tab-panel" aria-selected={tab === entry.id} onClick={() => setTab(entry.id)}
          className={cn('rounded-lg px-3 py-2 text-xs font-bold', tab === entry.id ? 'bg-[#082f4f] text-white' : 'text-[#2d4f6d] hover:bg-sky-50')}>{entry.label}</button>)}
      </div>
      <div role="tabpanel" id="close-tab-panel" aria-labelledby={`close-tab-${tab}`} className="space-y-5">
        {tab === 'overview' && <>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <Stat label="Posted journal lines" value={view.ledger.periodLines} sub="Functional currency in the pilot month" />
            <Stat label="Trial balance variances" value={draft.legacyTrial ? trial?.differences ?? 0 : 'Not imported'} sub="Account-by-account at month end" tone={trial?.differences ? 'text-amber-800' : undefined} />
            <Stat label="Controls with evidence" value={`${readyChecks} / ${CLOSE_CHECKS.length}`} sub="Includes qualifying not-applicable reviews" />
            <Stat label="Deployment gates" value={`${gatesPassed} / ${view.gates.length}`} sub="Required only for live designation" />
          </div>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card title="Pilot scope" sub="Use a closed legacy reporting month and its cut-off schedule.">
              <div className="space-y-3">
                <label className={field}>Legacy system / close reference<input className={input} maxLength={220} disabled={!editable || busy} placeholder="Legacy close pack, November…" value={draft.reference} onChange={(e) => change({ reference: e.target.value })} /></label>
                <label className={field}>Scope and cut-off notes<textarea className={input} maxLength={2800} rows={4} disabled={!editable || busy} placeholder="Describe the transactions mirrored this month, checks performed, and the basis of the closing balances." value={draft.notes} onChange={(e) => change({ notes: e.target.value })} /></label>
                <button type="button" onClick={() => setTab('trial')} className={secondary}>Compare trial balance <ArrowRight className="h-3.5 w-3.5" /></button>
              </div>
            </Card>
            <Card title="From pilot to live" sub="Approval of the pilot is not permission to replace live books.">
              <ol className="grid gap-2.5 text-xs leading-relaxed text-[#2d4f6d]">
                <li className={box}><strong className="block text-[#082f4f]">1 · Prepare</strong> Run both systems for a full month, map closing balances and attach the control schedules.</li>
                <li className={box}><strong className="block text-[#082f4f]">2 · Review</strong> A separate checker verifies the source evidence and signs the reconciled packet.</li>
                <li className={box}><strong className="block text-[#082f4f]">3 · Designate</strong> The owner verifies deployment and recovery, then records the decision and locks the signed period and earlier postings.</li>
              </ol>
            </Card>
          </div>
          <Card title="Submission requirements" action={<button type="button" className={secondary} onClick={() => setTab('review')}>Open review</button>}>
            {view.blockers.length ? <ul className="grid list-disc gap-1.5 pl-5 text-xs leading-relaxed text-[#355875]">{view.blockers.map((block) => <li key={block}>{block}</li>)}</ul>
              : <p className="flex items-center gap-2 text-sm font-bold text-emerald-800"><FileCheck2 className="h-4 w-4" /> Saved figures and evidence are ready for review.</p>}
          </Card>
        </>}
        {tab === 'trial' && <Card title="Compare closing trial balances" sub="Use net closing balances by mapped BPZ GL account in the workspace currency. Compare differences to zero to the cent." action={
          <button type="button" className={secondary} disabled={busy || !view.ledger.trial.length} onClick={() => downloadCsv(`${client.code}-${period}-bpz-closing-trial.csv`, [['Account', 'Debit', 'Credit', 'Currency'], ...view.ledger.trial.map((r) => [r.account, r.debit / 100, r.credit / 100, view.client.currency])])}><Download className="h-4 w-4" /> Export BPZ trial</button>}>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className={box}><label className={field}>Import legacy trial CSV<input className={input} disabled={uploadDisabled} type="file" accept=".csv,text/csv" onChange={(e) => { readUpload(e.target.files?.[0], 'legacy_trial'); e.target.value = ''; }} /></label>
              <p className="mt-2 text-xs text-[#355875]">Columns: Account, Debit, Credit, optionally Currency. Use a decimal point and no thousands separator. Maximum 3,000 rows and 384 KB.</p>
              {!packet || dirty ? <p className="mt-1 text-xs font-bold text-amber-900">Save the close draft before importing.</p> : null}
            </div>
            <div className={box}><p className="text-sm font-bold text-[#082f4f]">{draft.legacyTrial?.fileName ?? 'No legacy trial imported'}</p>
              <p className="mt-1 break-all font-mono text-[10px] text-[#355875]">{draft.legacyTrial?.sha256 ?? 'The uploaded original and its SHA-256 will be retained.'}</p>
              <p className="mt-2 text-xs text-[#355875]">Ledger balance: <b>{money(trial?.bpzBalance)}</b> · Legacy balance: <b>{draft.legacyTrial ? money(trial?.legacyBalance) : '—'}</b></p>
            </div>
          </div>
          <div className="my-3 flex flex-wrap items-center justify-between gap-2">
            <label className="flex items-center gap-2 text-xs font-bold text-[#355875]"><input type="checkbox" disabled={!draft.legacyTrial} checked={differenceOnly} onChange={(e) => { setDifferenceOnly(e.target.checked); setTrialPage(0); }} /> Differences only</label>
            {draft.legacyTrial && trial && <button type="button" className={secondary} onClick={() => downloadCsv(`${client.code}-${period}-variance.csv`, [['Account', 'BPZ net', 'Legacy net', 'Variance'], ...trial.rows.map((r) => [r.account, r.bpzNet / 100, r.legacyNet / 100, r.variance / 100])])}><Download className="h-3.5 w-3.5" /> Export variance</button>}
          </div>
          <div className="overflow-x-auto"><table className="w-full min-w-[440px]">
            <thead><tr>{['Account', `BPZ net (${view.client.currency})`, 'Legacy net', 'Variance'].map((h) => <th key={h} className={thCls}>{h}</th>)}</tr></thead>
            <tbody>{visible.slice(page * 40, page * 40 + 40).map((row) => <tr key={row.account} className="border-b border-sky-100"><td className={cn(tdCls, 'font-mono font-bold')}>{row.account}</td><td className={tdCls}>{money(row.bpzNet)}</td><td className={tdCls}>{draft.legacyTrial ? money(row.legacyNet) : '—'}</td><td className={cn(tdCls, row.variance !== 0 && draft.legacyTrial && 'font-bold text-rose-800')}>{draft.legacyTrial ? money(row.variance) : '—'}</td></tr>)}</tbody>
          </table></div>
          {!visible.length && <p className="px-2 py-4 text-sm text-[#355875]">{matchOnly ? 'No account differences.' : 'No closing balances to display.'}</p>}
          {pages > 1 && <div className="mt-3 flex items-center gap-3 text-xs text-[#355875]"><button className={secondary} disabled={!page} onClick={() => setTrialPage(page - 1)}>Previous</button>{page + 1} / {pages}<button className={secondary} disabled={page + 1 >= pages} onClick={() => setTrialPage(page + 1)}>Next</button></div>}
        </Card>}
        {tab === 'controls' && <div className="grid gap-4 xl:grid-cols-2">
          {CLOSE_CHECKS.map((check) => {
            const row = draft.checks[check.key] ?? EMPTY_CHECK;
            const result = controlResult(check, row);
            const anchor = ledger?.anchors[check.key];
            const hasFile = view.evidence.some((f) => f.key === check.key);
            const complete = result.ready && (check.kind !== 'amount' || result.bpz === anchor) && (hasFile || check.kind === 'optional' && row.result === 'not_applicable');
            return <Card key={check.key} title={check.label} sub={check.group} action={<Badge tone={complete ? 'green' : 'amber'}>{complete ? 'Ready' : 'Incomplete'}</Badge>}>
              <p className="mb-3 text-xs leading-relaxed text-[#355875]">{check.detail}</p>
              <div className="space-y-3">
                {check.kind === 'amount' ? <>
                  <div className="grid grid-cols-2 gap-2">
                    <label className={field}>Legacy control ({view.client.currency})<input className={input} inputMode="decimal" maxLength={24} disabled={!editable || busy} value={row.legacy} onChange={(e) => changeRow(check.key, { legacy: e.target.value })} placeholder="0.00" /></label>
                    <label className={field}>BPZ control ({view.client.currency})<input className={input} inputMode="decimal" maxLength={24} disabled={!editable || busy} value={row.bpz} onChange={(e) => changeRow(check.key, { bpz: e.target.value })} placeholder="0.00" /></label>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-[#355875]"><span>Posted control: <strong>{money(anchor)}</strong></span>
                    <button type="button" className={secondary} disabled={!editable || busy || anchor === undefined} onClick={() => changeRow(check.key, { bpz: moneyDecimal(anchor ?? 0) })}>Use posted amount</button>
                    <Badge tone={result.variance === 0 ? 'green' : 'amber'}>Variance {money(result.variance)}</Badge></div>
                </> : <label className={field}>Review result<select className={input} disabled={!editable || busy} value={row.result} onChange={(e) => changeRow(check.key, { result: e.target.value as WorkRow['result'] })}>
                  <option value="pending">Pending</option><option value="verified">Evidence verified</option>{check.kind === 'optional' && <option value="not_applicable">Not applicable · explain below</option>}
                </select></label>}
                <label className={field}>Evidence reference<input className={input} maxLength={200} disabled={!editable || busy} value={row.reference} onChange={(e) => changeRow(check.key, { reference: e.target.value })} placeholder="Schedule, working paper or signed review ID" /></label>
                <label className={field}>Reconciliation notes<textarea className={input} maxLength={1800} rows={2} disabled={!editable || busy} value={row.notes} onChange={(e) => changeRow(check.key, { notes: e.target.value })} placeholder="Explain the tie-out, source adjustments, or why not applicable." /></label>
                <button className={secondary} type="button" onClick={() => { setEvidenceKey(check.key); setTab('evidence'); }}>{hasFile ? 'View supporting file' : 'Attach supporting file'}</button>
              </div>
            </Card>;
          })}
        </div>}
        {tab === 'evidence' && <Card title="Supporting evidence" sub="Use minimized schedules: avoid unnecessary personal, payroll or banking identifiers.">
          <div className={cn(box, 'mb-4 flex flex-wrap gap-3')}><label className={field}>Evidence category<select className={input} value={evidenceKey} disabled={uploadDisabled} onChange={(e) => setEvidenceKey(e.target.value as EvidenceKey)}>{CLOSE_CHECKS.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}</select></label>
            <label className={field}><span className="inline-flex items-center gap-1"><CloudUpload className="h-4 w-4" /> Attach PDF, CSV, text or image (2 MB)</span><input type="file" className={input} accept=".pdf,.csv,.txt,.png,.jpg,.jpeg" disabled={uploadDisabled} onChange={(e) => { readUpload(e.target.files?.[0], evidenceKey); e.target.value = ''; }} /></label>
            {uploadDisabled && <p className="w-full text-xs text-[#355875]">{!packet || dirty ? 'Save the draft before uploading supporting evidence.' : !editable ? 'This packet is locked for review or designation.' : 'An operation is in progress.'}</p>}
          </div>
          {view.evidence.length ? <ul className="divide-y divide-sky-100">{view.evidence.map((file) => <li className="flex flex-wrap items-center justify-between gap-2 py-3" key={file.id}>
            <div className="min-w-0 text-xs text-[#355875]"><p className="inline-flex items-center gap-1 font-bold text-[#082f4f]"><FileText className="h-3.5 w-3.5" /> {file.name}</p><p>{labelFor(file.key)} · {Math.ceil(file.size / 1024)} KB · {file.actor} · {when(file.at)}</p><p className="mt-1 break-all font-mono text-[10px]" title="SHA-256">{file.sha256}</p></div>
            <div className="flex gap-1.5"><button type="button" disabled={busy} className={secondary} onClick={() => getFile(file)}><Download className="h-3.5 w-3.5" /> Download</button>
              {editable && <button type="button" className={secondary} disabled={busy || dirty} aria-label={`Remove ${file.name}`} onClick={() => { if (window.confirm('Remove this file from the draft?')) submitAction('remove', 'Draft evidence removed.', { fileId: file.id }); }}><Trash2 className="h-3.5 w-3.5" /></button>}</div>
          </li>)}</ul> : <p className="text-sm text-[#355875]">No files are attached to this month.</p>}
        </Card>}
        {tab === 'review' && <>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card title={<span className="inline-flex items-center gap-1.5"><ClipboardCheck className="h-4 w-4" /> Independent sign-off</span>}>
              <div className="space-y-3 text-xs text-[#355875]">
                <p>Prepared by <b>{packet?.preparedBy ?? '—'}</b> · Submitted by <b>{packet?.submittedBy ?? '—'}</b></p>
                {packet?.reviewedBy && <p>Reviewed by <b>{packet.reviewedBy}</b> · {when(packet.reviewedAt)}<br />{packet.reviewNotes}</p>}
                {view.signoffStale && <p role="alert" className="rounded-lg bg-rose-50 p-2 font-bold text-rose-900">The posted ledger or packet changed. Reconcile and submit again for independent review.</p>}
                {!packet && <p>Save a draft and complete the trial balance and controls to start the review.</p>}
                {view.permissions.owner && !invite && <button type="button" disabled={busy} onClick={() => setInvite({ name: '', username: '', email: '', password: '' })} className={secondary}><UserPlus className="h-3.5 w-3.5" /> Add close reviewer</button>}
                {view.permissions.owner && invite && <form className={cn(box, 'grid gap-2')} onSubmit={(e) => { e.preventDefault(); createReviewer(); }}>
                  <p className="font-bold text-[#082f4f]">Invite a different individual to review {client.code}</p>
                  <label className={field}>Reviewer full name<input className={input} required maxLength={130} value={invite.name} onChange={(e) => setInvite({ ...invite, name: e.target.value })} /></label>
                  <label className={field}>Reviewer username<input className={input} required minLength={3} maxLength={40} pattern="[a-zA-Z0-9._\-]{3,40}" autoComplete="off" value={invite.username} onChange={(e) => setInvite({ ...invite, username: e.target.value })} /></label>
                  <label className={field}>Reviewer email<input type="email" className={input} required maxLength={150} value={invite.email} onChange={(e) => setInvite({ ...invite, email: e.target.value })} /></label>
                  <label className={field}>Temporary password<input type="password" className={input} required minLength={10} maxLength={128} autoComplete="new-password" value={invite.password} onChange={(e) => setInvite({ ...invite, password: e.target.value })} /></label>
                  <p className="leading-relaxed">The reviewer is scoped to this entity and this desk with no posting or packet preparation rights. Production requires authenticator MFA. Deliver the password through a secure channel.</p>
                  <div className="flex flex-wrap gap-2"><button className={primary} type="submit" disabled={busy}>Create reviewer account</button><button className={secondary} type="button" disabled={busy} onClick={() => setInvite(null)}>Cancel</button></div>
                </form>}
                {editable && <><p>{dirty ? 'Save before submitting.' : view.blockers.length ? `${view.blockers.length} requirements remain. See Overview.` : 'All saved requirements pass.'}</p>
                  <button type="button" className={primary} disabled={!packet || dirty || busy || !!view.blockers.length} onClick={() => submitAction('submit', 'Submitted for an independent checker.')}>Submit for review</button></>}
                {packet && (packet.status === 'submitted' || packet.status === 'approved') && <>
                  <label className={field}>{packet.status === 'approved' ? 'Cutover or revision notes' : 'Review or revision notes'}<textarea className={input} maxLength={1500} rows={3} disabled={busy} value={reviewNotes} onChange={(e) => setReviewNotes(e.target.value)} /></label>
                  {packet.status === 'submitted' && view.permissions.review && <>
                    <label className="flex items-start gap-2"><input type="checkbox" checked={reviewConfirmed} onChange={(e) => setReviewConfirmed(e.target.checked)} /> I checked the source schedules, current statutory/sector assumptions and reconciliations for the full period.</label>
                    <div className="flex flex-wrap gap-2"><button type="button" className={primary} disabled={busy || !reviewConfirmed || reviewNotes.trim().length < 15 || view.signoffStale || !!view.blockers.length} onClick={() => submitAction('approve', 'Independent sign-off recorded.', { confirm: true, reason: reviewNotes })}>Approve pilot month</button>
                      <button type="button" className={secondary} disabled={busy || reviewNotes.trim().length < 10} onClick={() => submitAction('return', 'Returned to the preparer for corrections.', { reason: reviewNotes })}>Return for corrections</button></div>
                  </>}
                  {packet.status === 'submitted' && !view.permissions.review && <p>Approval requires a different authorized checker who did not prepare, edit or submit the packet.</p>}
                  {view.permissions.revise && <button type="button" className={secondary} disabled={busy || reviewNotes.trim().length < 10} onClick={() => submitAction(packet.status === 'approved' ? 'reopen' : 'withdraw', 'Packet reopened for revision.', { reason: reviewNotes })}>{packet.status === 'approved' ? 'Reopen for revision' : 'Withdraw submission'}</button>}
                </>}
              </div>
            </Card>
            <Card title={<span className="inline-flex items-center gap-1.5"><LockKeyhole className="h-4 w-4" /> Production cutover</span>}>
              <ul className="mb-3 grid gap-2 text-xs">{view.gates.map((gate) => <li className={box} key={gate.key}>
                <div className="flex flex-wrap items-center justify-between gap-1"><b className="text-[#082f4f]">{gate.label}</b><Badge tone={gate.passed ? 'green' : 'amber'}>{gate.passed ? 'Verified' : 'Required'}</Badge></div><p className="mt-1 text-[#355875]">{gate.detail}</p>
              </li>)}</ul>
              {packet?.status === 'active' ? <p className="text-xs font-bold text-emerald-800">Live designation recorded by {packet.activatedBy} · {when(packet.activatedAt)}.</p>
                : view.permissions.owner && signed && !isDesignated && <div className="space-y-2"><label className={field}>Type {client.code} to confirm<input className={input} maxLength={24} disabled={busy} value={confirmCode} onChange={(e) => setConfirmCode(e.target.value)} autoComplete="off" /></label>
                  <p className="text-xs text-[#355875]">Use the decision notes in the sign-off card. This permanently protects postings dated through {period} in this workspace.</p>
                  <button type="button" className={primary} disabled={busy || confirmCode.trim() !== client.code || reviewNotes.trim().length < 15 || view.signoffStale || view.gates.some((g) => !g.passed)} onClick={() => { if (window.confirm(`Designate ${client.code} as live and lock postings through ${period}?`)) submitAction('activate', 'Live-book cutover recorded and the signed period locked.', { confirm: confirmCode, reason: reviewNotes }); }}>Designate live books</button></div>}
              {view.permissions.owner && <button className={cn(secondary, 'mt-3')} type="button" disabled={busy} onClick={() => onNavigate('operations')}>Open backup operations <ArrowRight className="h-3 w-3" /></button>}
            </Card>
          </div>
          <Card title="Audit trail" sub="Latest 60 events for the selected month" action={<button type="button" disabled={!packet || busy} className={secondary} onClick={exportSummary}><Download className="h-3.5 w-3.5" /> Export close packet</button>}>
            {view.history.length ? <ol className="grid gap-2">{view.history.map((e, index) => <li key={`${e.at}-${index}`} className={cn(box, 'text-xs text-[#355875]')}><b className="text-[#082f4f]">{e.action.replace('PARALLEL_', '').replaceAll('_', ' ')} · {e.actor}</b><span className="ml-2">{when(e.at)}</span><p className="mt-1 break-words">{e.detail}</p></li>)}</ol> : <p className="text-sm text-[#355875]">No activity has been recorded.</p>}
          </Card>
        </>}
      </div>
    </>}
  </div>;
}
