import { useState } from 'react';
import { KeyRound, Link2, ShieldCheck, UserCheck, Users, XCircle, CheckCircle2, Settings2 } from 'lucide-react';
import type { UserAccount } from '../types/accounting';
import { apiFetch } from '../utils/session';

interface SsoDeskProps {
  onLoginAsSsoUser?: (user: UserAccount) => void;
}

type SsoLink = {
  id: string; issuer: string; subject: string; email: string | null;
  status: string; lastLoginAt: string | null; createdBy: string; username: string;
};
type SsoConfig = {
  enabled: boolean; issuers: string[]; audience: string; secretConfigured: boolean; provisioning: boolean;
};

/**
 * Enterprise SSO (OIDC / SAML-derived JWTs).
 *
 * Honest status: the identity provider AUTHENTICATES; this system AUTHORISES.
 * Every federated sign-in is signature-verified against the allow-listed issuer,
 * subject to audience and expiry checks, and written to the append-only audit
 * log. The local user record owns role, tenant and module access — an assertion
 * can never grant itself more authority than the owner has assigned.
 */
export const SsoDesk: React.FC<SsoDeskProps> = ({ onLoginAsSsoUser }) => {
  const [config, setConfig] = useState<SsoConfig | null>(null);
  const [links, setLinks] = useState<SsoLink[]>([]);
  const [issuer, setIssuer] = useState('');
  const [subject, setSubject] = useState('');
  const [userId, setUserId] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    setBusy(true);
    try {
      const res = await apiFetch('/api/auth/sso');
      const body = await res.json().catch(() => null);
      if (body?.ok) { setConfig(body.sso); setLinks(body.links || []); }
    } catch { setError('SSO status could not be loaded.'); } finally { setBusy(false); }
  };

  const run = async (payload: Record<string, unknown>, okMessage: string) => {
    setFeedback(null); setError(null); setBusy(true);
    try {
      const res = await apiFetch('/api/auth/sso', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload) });
      const body = await res.json().catch(() => null);
      if (!res.ok || !body?.ok) { setError(body?.error || `Request failed (HTTP ${res.status}).`); return; }
      setFeedback(okMessage);
      if (body.links) setLinks(body.links);
    } catch { setError('The request could not reach the server.'); } finally { setBusy(false); }
  };

  return (
    <div className="space-y-6 text-[#0a253e]">
      <div className="rounded-xl border border-sky-300 bg-[#f0f6fc] p-4 text-sm text-[#082f4f] flex items-start gap-2">
        <ShieldCheck className="h-5 w-5 mt-0.5 text-[#006f98] shrink-0" />
        <div>
          <strong>SSO is implemented and enforced here.</strong> The identity provider (Azure AD, Okta, Auth0, Keycloak,
          or any OIDC/SAML-compatible IdP) authenticates the user; this workspace authorises the user. Federation
          events — accepted and refused — are written to the append-only audit log. The setup below configures a
          deployment; the linked identities table is the live record.
        </div>
      </div>

      <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-3">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f] flex items-center gap-2">
          <Settings2 className="h-4 w-4 text-[#006f98]" /> Deployment configuration
        </h3>
        <p className="text-xs leading-relaxed text-[#2d4f6d]">
          Set these in the deployment environment, then reload this desk. Signing in is via{' '}
          <code className="rounded bg-sky-100 px-1.5 py-0.5 font-mono text-[11px]">POST /api/auth/sso</code> with{' '}
          <code className="rounded bg-sky-100 px-1.5 py-0.5 font-mono text-[11px]">{'{"token":"<idp-jwt>"}'}</code>.
        </p>
        <div className="grid gap-2 text-xs text-[#2d4f6d]">
          <div><code className="font-mono">BPZ_SSO_ISSUERS</code> — comma-separated allow-listed issuer URLs (required to enable SSO)</div>
          <div><code className="font-mono">BPZ_SSO_SECRET</code> — HS256 shared secret for signature verification (required)</div>
          <div><code className="font-mono">BPZ_SSO_AUDIENCE</code> — expected audience claim (recommended)</div>
          <div><code className="font-mono">BPZ_SSO_PROVISION=true</code> — allow first-sign-in linking to an existing local user</div>
        </div>
        <button type="button" onClick={() => void load()} disabled={busy}
          className="rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] disabled:opacity-50">
          {busy ? 'Loading…' : 'Load SSO configuration'}
        </button>
        {config && (
          <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-3 text-xs space-y-1">
            <div>Status: <strong>{config.enabled ? 'Enabled' : 'Disabled (no issuers configured)'}</strong></div>
            <div>Trusted issuers: {config.issuers.length ? config.issuers.join(', ') : '—'}</div>
            <div>Audience: {config.audience || '—'}</div>
            <div>Signature key: <strong>{config.secretConfigured ? 'Configured' : 'Missing — signatures cannot be verified'}</strong></div>
            <div>Provisioning: {config.provisioning ? 'On (links first sign-in to an existing local user)' : 'Off (owner links identities explicitly)'}</div>
          </div>
        )}
      </div>

      <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f] flex items-center gap-2 mb-2">
          <Link2 className="h-4 w-4 text-[#006f98]" /> Link an identity to a local user
        </h3>
        <p className="text-xs text-[#2d4f6d] mb-3">
          The IdP authenticates; the local user record owns role, tenant and module access. Linking grants sign-in, not authority.
        </p>
        <div className="grid gap-2 sm:grid-cols-3">
          <input value={issuer} onChange={(e) => setIssuer(e.target.value)} placeholder="Issuer URL (https://…)" className="rounded border border-sky-300 px-2.5 py-1.5 text-xs" />
          <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="IdP subject (sub claim)" className="rounded border border-sky-300 px-2.5 py-1.5 text-xs" />
          <input value={userId} onChange={(e) => setUserId(e.target.value)} placeholder="Local username (e.g. owner)" className="rounded border border-sky-300 px-2.5 py-1.5 text-xs" />
        </div>
        <div className="mt-3 flex gap-2">
          <button type="button" onClick={() => void run({ action: 'link', issuer, subject, userId }, 'Identity linked. The subject can now sign in as that user.')}
            disabled={busy || !issuer.trim() || !subject.trim() || !userId.trim()}
            className="rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white disabled:opacity-50">
            Link identity
          </button>
          <button type="button" onClick={() => void load()} disabled={busy} className="rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50">Refresh list</button>
        </div>
      </div>

      <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f] flex items-center gap-2 mb-3">
          <Users className="h-4 w-4 text-[#006f98]" /> Linked identities
        </h3>
        {links.length === 0 ? (
          <p className="text-xs text-[#355875]">No federated identities linked yet. Use the form above, or enable provisioning.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-sky-200 bg-sky-50/70">
                  <th className="text-left px-3 py-2">Local user</th>
                  <th className="text-left px-3 py-2">Issuer</th>
                  <th className="text-left px-3 py-2">Subject</th>
                  <th className="text-left px-3 py-2">Status</th>
                  <th className="text-left px-3 py-2">Last federated sign-in</th>
                  <th className="text-left px-3 py-2">Action</th>
                </tr>
              </thead>
              <tbody>
                {links.map((l) => (
                  <tr key={l.id} className="border-b border-sky-100">
                    <td className="px-3 py-2 font-bold text-[#082f4f]">{l.username}</td>
                    <td className="px-3 py-2 font-mono text-[11px] truncate max-w-[14ch]" title={l.issuer}>{l.issuer}</td>
                    <td className="px-3 py-2 font-mono text-[11px] truncate max-w-[14ch]" title={l.subject}>{l.subject}</td>
                    <td className="px-3 py-2">
                      {l.status === 'active'
                        ? <span className="rounded bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[10.5px] font-bold border border-emerald-300">Active</span>
                        : <span className="rounded bg-rose-100 text-rose-800 px-2 py-0.5 text-[10.5px] font-bold border border-rose-300">Revoked</span>}
                    </td>
                    <td className="px-3 py-2 text-[#2d4f6d]">{l.lastLoginAt ? new Date(l.lastLoginAt).toLocaleString() : '—'}</td>
                    <td className="px-3 py-2">
                      {l.status === 'active'
                        ? <button type="button" onClick={() => void run({ action: 'revoke', id: l.id }, 'Federated sign-in revoked. Existing sessions must be revoked separately.')}
                            className="inline-flex items-center gap-1 rounded border border-rose-300 px-2 py-1 text-[10.5px] font-bold text-rose-800 hover:bg-rose-50">
                            <XCircle className="h-3 w-3" /> Revoke
                          </button>
                        : <button type="button" onClick={() => void run({ action: 'reinstate', id: l.id }, 'Federated sign-in reinstated.')}
                            className="inline-flex items-center gap-1 rounded border border-emerald-300 px-2 py-1 text-[10.5px] font-bold text-emerald-800 hover:bg-emerald-50">
                            <CheckCircle2 className="h-3 w-3" /> Reinstate
                          </button>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-2">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f] flex items-center gap-2">
          <KeyRound className="h-4 w-4 text-[#006f98]" /> What this system already enforces
        </h3>
        <ul className="space-y-1.5 text-xs text-[#2d4f6d]">
          <li className="flex items-start gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 mt-0.5 shrink-0" /> <strong>MFA</strong> (TOTP / RFC 6238) is enforced for owner and checker accounts via <code className="font-mono">BPZ_ENFORCE_MFA_OWNER</code> / <code className="font-mono">BPZ_ENFORCE_MFA_CHECKERS</code>.</li>
          <li className="flex items-start gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 mt-0.5 shrink-0" /> <strong>Session control</strong> is server-side (HttpOnly cookie, sliding expiry) and revocable — <code className="font-mono">GET/DELETE /api/auth/sessions</code>.</li>
          <li className="flex items-start gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 mt-0.5 shrink-0" /> <strong>Audit logging</strong> is append-only (<code className="font-mono">audit_log</code>); federation events are recorded there too.</li>
          <li className="flex items-start gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 mt-0.5 shrink-0" /> <strong>Role and tenant authority</strong> comes from the local user record, never from the federated assertion.</li>
          <li className="flex items-start gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 mt-0.5 shrink-0" /> <strong>API keys</strong> are hashed, scoped and revocable — see Enterprise Administration → API & Webhooks.</li>
        </ul>
      </div>

      {feedback && (
        <div role="status" className="rounded border border-emerald-300 bg-emerald-50 p-2.5 text-xs font-bold text-emerald-900">{feedback}</div>
      )}
      {error && (
        <div role="alert" className="rounded border border-rose-300 bg-rose-50 p-2.5 text-xs font-bold text-rose-900">{error}</div>
      )}

      {onLoginAsSsoUser && (
        <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs">
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f] flex items-center gap-2 mb-2">
            <UserCheck className="h-4 w-4 text-emerald-700" /> Owner demo sign-in
          </h3>
          <p className="text-xs text-[#2d4f6d]">
            Opens the workspace as the owner for demonstration purposes. In a real federated deployment, sign-in
            happens through the identity provider and the user never sees this button.
          </p>
          <button
            type="button"
            onClick={() => onLoginAsSsoUser({ username: 'owner', name: 'Kwesi Dadzie (Owner)', role: 'owner', makerLimit: 1000000, canCheck: true, email: 'k.dadzie@bpzconsult.com' })}
            className="mt-3 rounded-lg bg-sky-700 px-4 py-2 text-xs font-bold text-white hover:bg-sky-800"
          >
            Owner demo login
          </button>
        </div>
      )}
    </div>
  );
};
