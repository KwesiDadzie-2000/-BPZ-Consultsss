import { useState } from 'react';
import { localToday, postingDateForPeriod } from '../utils/periods';
import type { AccountMaster, ACDOCALine, ClientEntity, UserAccount } from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import { Calculator, Printer } from 'lucide-react';
import { aggregateTrialBalance, computeCit, sectorCitRate } from '../utils/reports';
import { uniqueId } from '../utils/ids';
import { printReport } from '../utils/printReport';
import { toPrintEntity } from '../utils/printEntity';
import { persistentStorage } from '../utils/persistentStorage';
import { refusalReason } from '../utils/postingNotice';

export const TaxFilingScheduleSection = ({ currentClient, currentUser, lines, accounts = [], onAddJournalLines, closedPeriods = [], onOpenSchedules }: {
  currentClient: ClientEntity;
  currentUser?: UserAccount;
  lines: ACDOCALine[];
  accounts?: AccountMaster[];
  onAddJournalLines?: (lines: ACDOCALine[]) => boolean;
  closedPeriods?: readonly string[];
  onOpenSchedules?: () => void;
}) => {
  const [period, setPeriod] = useState(() => localToday().slice(0, 7));
  const [confirmedCredits, setConfirmedCredits] = useState<Record<string, number>>({});
  const postingDate = postingDateForPeriod(period);
  const isPeriodClosed = closedPeriods.includes(period);
  const postedProvision = lines.some((l) => l.clientId === currentClient.id && l.docNo === `CIT-${period}`);
  const [citMsg, setCitMsg] = useState<string | null>(null);
  const entries = lines.filter(l => l.clientId === currentClient.id
    && l.period === period
    && String(l.currency || currentClient.currency).toUpperCase() === currentClient.currency.toUpperCase());
  const totals = (account: string) => entries.filter(l => l.accountNo === account).reduce((n, l) => n + Math.round((l.credit - l.debit) * 100), 0) / 100;
  const output = totals('220000');
  const vatWht = totals('221000');
  const cst = totals('223000');
  const tourism = totals('224000');
  const input = -totals('125000');
  const whtPayable = totals('209000');
  // 115000 may include VAT withholding, which is not automatically a CIT credit.
  const withholdingReceivable = -totals('115000');
  const paye = totals('207000');
  const pension = totals('206000');
  const tier2 = totals('206100');
  const categories = [
    ['Output VAT/NHIL/GETFund (ledger 220000)', output],
    ['VAT withholding payable (ledger 221000)', vatWht],
    ['CST payable (ledger 223000)', cst],
    ['Tourism levy payable (ledger 224000)', tourism],
    ['Input VAT recoverable (ledger 125000)', input],
    ['Net VAT & levies position', output + vatWht + cst + tourism - input],
    ['Supplier WHT payable to GRA (ledger 209000)', whtPayable],
    ['Withholding receivable movement (ledger 115000)', withholdingReceivable],
    ['PAYE payable (ledger 207000)', paye],
    ['SSNIT Tier 1 13.5% payable (ledger 206000)', pension],
    ['Tier 2 pension 5% payable (ledger 206100)', tier2],
  ] as const;

  // PBT excludes the current and deferred income-tax expense already booked.
  const rows = aggregateTrialBalance(entries, accounts);
  const profit = rows.filter(r => r.type === 'Income' || (r.type === 'Expense' && !['730000', '731000'].includes(r.code))).reduce((n, r) => n - (r.dr - r.cr), 0) / 100;
  const { rate, sectorName } = sectorCitRate(currentClient.sector);
  const cit = computeCit(profit, rate, confirmedCredits[period] ?? 0);

  const postCitProvision = () => {
    if (!onAddJournalLines || cit.grossCit <= 0 || !postingDate || isPeriodClosed || postedProvision) return;
    const docNo = `CIT-${period}`;
    const ok = onAddJournalLines([
      { id: `${uniqueId('JL-CIT')}-1`, docNo, period, date: postingDate, module: 'FI', docType: 'JE', accountNo: '730000', accountName: 'Income Tax Expense — Current CIT', costCenter: 'CC-ADM', debit: cit.grossCit, credit: 0, currency: currentClient.currency, description: `CIT provision for ${period} at ${rate}% (${sectorName})`, createdBy: currentUser?.username || 'tax_working_paper', clientId: currentClient.id },
      { id: `${uniqueId('JL-CIT')}-2`, docNo, period, date: postingDate, module: 'FI', docType: 'JE', accountNo: '212000', accountName: 'Corporate Income Tax Payable (CIT)', costCenter: 'CC-ADM', debit: 0, credit: cit.grossCit, currency: currentClient.currency, description: `CIT payable for ${period}`, createdBy: currentUser?.username || 'tax_working_paper', clientId: currentClient.id },
    ]);
    setCitMsg(ok
      ? `CIT provision ${docNo} posted: ${formatGHS(cit.grossCit)} at ${rate}%.`
      : `CIT provision rejected. ${refusalReason(`The period is closed or document ${docNo} already exists.`)}`);
    setTimeout(() => setCitMsg(null), 6000);
  };

  const print = () => printReport({
    kicker: 'Tax working paper', title: 'Statutory ledger reconciliation', subtitle: `Period-specific balances from posted journal entries · ${currentClient.currency}`,
    entity: toPrintEntity(currentClient, persistentStorage.getCompanyProfiles()[currentClient.id]), periodLabel: period, preparedBy: currentUser ? `${currentUser.name} (${currentUser.username})` : 'BPZ Consult',
    stats: [{ label: 'Profit before tax', value: profit }, { label: 'Sector CIT rate', value: `${rate}%` }, { label: 'Gross CIT', value: cit.grossCit }, { label: 'Net CIT payable', value: cit.netPayable }],
    sections: [
      { title: 'Ledger positions', columns: [{ key: 'name', label: 'Account position' }, { key: 'value', label: currentClient.currency, numeric: true, width: '22%' }], rows: categories.map(([name, value]) => ({ name, value })) },
      { title: `Corporate income tax working paper (${sectorName})`, columns: [{ key: 'name', label: 'Line' }, { key: 'value', label: currentClient.currency, numeric: true, width: '22%' }],
        rows: [{ name: 'Period profit before tax', value: profit }, { name: `Taxable profit`, value: cit.taxableProfit }, { name: `Gross CIT at ${rate}%`, value: cit.grossCit }, { name: 'Less: confirmed income-tax credits', value: -cit.whtCredits }, { name: 'Net CIT payable', value: cit.netPayable }], emphasise: (i) => i === 4 },
    ],
    footerNote: 'Not a tax return. Verify rates and reconcile with source documents before filing.',
  });

  const exportCsv = () => {
    const csv = ['Account position,Amount', ...categories.map(([name, value]) => `"${name}",${value}`)].join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    const link = document.createElement('a'); link.href = url; link.download = `${currentClient.code}-${period}-reconciliation-DRAFT.csv`; link.click(); URL.revokeObjectURL(url);
  };
  return <div className="space-y-5">
    <PageHeader kicker="TAX WORKING PAPER" title="Statutory ledger reconciliation" desc="Period-specific amounts from posted journal entries only." />
    <div role="note" className="rounded border border-amber-400 bg-amber-50 p-3 text-sm text-amber-950">Not a tax return. Account balances do not establish tax eligibility, filing status, taxable turnover or statutory due dates. Verify rates and reconcile with source documents before filing.</div>
    <div className="flex flex-wrap gap-3 items-end bg-white border border-sky-200 p-4 rounded-xl">
      <label className="text-xs font-bold">Reporting month<input type="month" max={localToday().slice(0, 7)} value={period} onChange={e => setPeriod(e.target.value)} className="block mt-1 p-2 border border-sky-300 rounded" /></label>
      <button onClick={exportCsv} className="bg-[#082f4f] text-white text-xs font-bold px-4 py-2 rounded">Export reconciliation (CSV)</button>
      <button onClick={print} className="flex items-center gap-1.5 rounded border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50"><Printer className="h-3.5 w-3.5" /> Print working paper</button>
      {onOpenSchedules && <button onClick={onOpenSchedules} className="text-xs underline text-[#082f4f]">Open WHT &amp; VAT schedules</button>}
    </div>
    <Card title={`Ledger positions - ${period}`} sub={`${entries.length} journal lines in this workspace and period`}>
      <table className="w-full text-xs"><thead><tr><th className={thCls}>Account position</th><th className={thCls + ' text-right'}>{currentClient.currency}</th></tr></thead><tbody>{categories.map(([name, value]) => <tr key={name} className={rowCls}><td className="p-3">{name}</td><td className={numCls}>{formatGHS(value)}</td></tr>)}</tbody></table>
    </Card>

    <Card title={`Corporate income tax working paper - ${period}`} sub={`Sector basis: ${sectorName}`} action={
      <button onClick={postCitProvision} disabled={!onAddJournalLines || cit.grossCit <= 0 || !postingDate || isPeriodClosed || postedProvision} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs disabled:opacity-40">
        <Calculator className="h-3.5 w-3.5" />
        <span>Post CIT provision</span>
      </button>
    }>
      <div className="space-y-3 text-xs">
        {citMsg && <div role="status" className="rounded-lg border border-sky-300 bg-sky-50 p-2.5 font-bold text-[#082f4f]">{citMsg}</div>}
        {postedProvision && <p className="font-semibold text-[#355875]">A provision already exists for this period. Correct it through Adjustments, not a second provision.</p>}
        {isPeriodClosed && <p className="font-semibold text-amber-800">This period is closed to new postings.</p>}
        <label className="block font-semibold text-[#355875]">Confirmed income-tax credits ({currentClient.currency})
          <input className="ml-2 w-32 rounded border border-sky-300 px-2 py-1" type="number" min="0" step="0.01" value={confirmedCredits[period] ?? ''}
            onChange={(e) => setConfirmedCredits((prev) => ({ ...prev, [period]: Math.max(0, Number(e.target.value) || 0) }))} />
          <span className="mt-1 block font-normal">Enter only credits verified by certificate. VAT withholding and supplier WHT payable are not assumed to offset CIT. This does not change the gross provision.</span>
        </label>
        <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
          <Stat label="Period profit before tax" value={formatGHS(profit)} sub="Income less expenses, posted lines" />
          <Stat label="Sector CIT rate" value={`${rate}%`} sub={sectorName} />
          <Stat label="Gross CIT" value={formatGHS(cit.grossCit)} sub={`${rate}% of taxable profit`} tone="text-[#082f4f]" />
          <Stat label="Net CIT payable" value={formatGHS(cit.netPayable)} sub={`After WHT credits of ${formatGHS(cit.whtCredits)}`} tone="text-emerald-700" />
        </div>
        <p className="text-[#2d4f6d] leading-relaxed">CIT is computed from posted journal lines at the sector rate for {currentClient.sector}. Only independently confirmed income-tax credit certificates reduce the working-paper CIT payable. GL 209000 is supplier WHT owed; it is not a CIT credit. Posting the provision debits 730000 and credits 212000; it does not file or pay anything.</p>
      </div>
    </Card>
  </div>;
};
