/**
 * In-app setup & guide — the single source of truth for onboarding and
 * module explanations. Rendered by the Setup Guide desk (Overview section).
 * Sources: docs/SETUP_GUIDE.md, docs/API.md, docs/SECURITY.md.
 */

export interface GuideModule {
  id: string;
  name: string;
  group: string;
  what: string;         // one-sentence summary
  treatment?: string;   // accounting treatment / postings
  accounts?: string[];  // key GL accounts
  controls?: string[];  // controls active on the desk
}

export const GUIDE_MODULES: GuideModule[] = [
  { id: 'dashboard', name: 'Command Center', group: 'Overview', what: 'KPIs, balances and alerts for the active workspace.' },
  { id: 'sector_workflow', name: 'Sector Workflow Switcher', group: 'Overview', what: 'Sector-specific workflow guidance for the active entity.' },
  { id: 'company_profile', name: 'Company Profile & Backup', group: 'Overview', what: 'Legal profile (legal name, TIN, VAT, bank) and books backup.' },
  { id: 'opening_balance', name: 'Opening Balances Setup', group: 'Overview', what: 'Manual take-on posting to the opening journal.' },
  { id: 'my_security', name: 'My Account Security (MFA)', group: 'Overview', what: 'Personal TOTP MFA enrollment and session management.' },
  { id: 'data_migration', name: 'Data Migration', group: 'Overview', what: 'CSV import of opening balances, ledger history, parties and banks — validated then committed in one transaction.', treatment: 'Posts immutable opening journals; corrections are reversals.' },
  { id: 'sales', name: 'Sales & Invoicing · O2C', group: 'Trading', what: 'Order → delivery → invoice → receipt for goods and services.', treatment: 'Invoice posts receivable, revenue, output tax; goods invoices also release cost of sales and stock issue in the same document.', accounts: ['110000', '110000', '402000', '220000', '504000'], controls: ['Credit limit enforced', 'Maker-checker', 'VAT/NHIL/GETFund'] },
  { id: 'procurement', name: 'Procurement & P2P', group: 'Trading', what: 'Requisition → purchase order → goods receipt → supplier invoice → payment.', treatment: 'Goods receipt accrues to 204000 GRNI (not payable). Only the matched invoice opens 200000 trade payables — tax recognised only after the invoice is recorded.', accounts: ['120000', '204000', '200000', '125000'], controls: ['Three-way match', 'Price tolerance', 'Credit standing'] },
  { id: 'inventory', name: 'Inventory Command Desk', group: 'Operations', what: 'Stock master, receipts, issues, valuation, NRV and reconciliation.', treatment: 'IAS 2 costing with weighted average/FIFO/specific; receipts at cost; issues at carrying cost; NRV write-down when below cost.', accounts: ['120000', '121000', '122000', '123000'] },
  { id: 'inventory_ledger', name: 'Stock Ledger & Valuation', group: 'Operations', what: 'Perpetual stock movements with GL reconciliation.', treatment: 'Immutable movements; valuation reconciled to the general ledger.' },
  { id: 'boms', name: 'Bill of Materials', group: 'Manufacturing', what: 'BOM definition and standard-cost build-up.' },
  { id: 'production_desk', name: 'Production Desk', group: 'Manufacturing', what: 'Production orders, WIP, material issues and finished-goods receipts.', treatment: 'Cost of work-in-progress and variance reporting (IAS 2).' },
  { id: 'ifrs_desk', name: 'IFRS Desk (Standards + Schedules)', group: 'Finance', what: 'Standards reference, schedule workpapers and IFRS mappings.' },
  { id: 'ifrs_statements', name: 'Financial Statements & IFRS', group: 'Finance', what: 'Primary statements — position, P&L, equity, cash flow, notes.', treatment: 'Non-current/current split (IAS 1.69); IAS 16, IAS 2, IFRS 9/15/16/17, IFRS 10 consolidation.' },
  { id: 'general_ledger', name: 'General Ledger', group: 'Finance', what: 'Full account activity with running balances.' },
  { id: 'coa_master', name: 'Chart of Accounts Master', group: 'Finance', what: 'Firm master chart with custom accounts per entity.' },
  { id: 'universal_journal', name: 'Journals (Universal & Manual)', group: 'Finance', what: 'Manual journals and document corrections.', treatment: 'Multi-document batches; double-entry enforced; closed periods freeze.' },
  { id: 'adjustments', name: 'Adjustment of Accounts', group: 'Finance', what: 'Controlled journal rebuilding and ledger corrections.' },
  { id: 'banking', name: 'Banking & Reconcile', group: 'Treasury', what: 'Treasury records, statement import and matching against the ledger.', treatment: 'Import CSV → auto-match to GL; server-persisted history. No manual bank balance edits (derived from GL).' },
  { id: 'payment_desk', name: 'Payment Desk', group: 'Treasury', what: 'Settle invoices and receipts, record WHT, payment vouchers.', treatment: 'Only invoiced balances can be paid; withholding recognised as statutory payable.' },
  { id: 'ageing', name: 'Ageing Analysis (AR & AP)', group: 'Treasury', what: 'Aging of receivables and payables into buckets.' },
  { id: 'control_accounts', name: 'Control Accounts Reconciliation', group: 'Finance', what: 'GL control vs sub-ledger, per control.', treatment: 'AR 110000 · AP 200000 · GRNI 204000 · inventory · treasury · statutory. Non-zero differences are named reconciling items.' },
  { id: 'expenses', name: 'Expenses & Statutory', group: 'Finance', what: 'Operating expense claims and statutory payables.' },
  { id: 'assets', name: 'Fixed Assets Register', group: 'Operations', what: 'PPE register with depreciation (IAS 16).', accounts: ['130000', '139000', '410000'] },
  { id: 'prepayments', name: 'Prepayments & Deferrals', group: 'Operations', what: 'Spreading costs across periods.' },
  { id: 'project_costing', name: 'Project Costing & Contracts', group: 'Finance', what: 'WIP and job-cost ledgers.' },
  { id: 'tax_schedule', name: 'Tax Desk (Schedules, Returns & Filing)', group: 'Tax', what: 'Ghana statutory schedules — VAT, NHIL, GETFund, CST, tourism levy, WHT — and returns.', controls: ['Gatekeeper: registered invoices'] },
  { id: 'month_end', name: 'Month-End Close', group: 'Finance', what: 'Period freeze checklist and close.' },
  { id: 'parallel_close', name: 'Parallel Close & Go-Live', group: 'Finance', what: 'Parallel-run a month against legacy books before cutover.', controls: ['Evidence', 'Independent sign-off'] },
  { id: 'disclosures', name: 'Notes to Accounts', group: 'Finance', what: 'IFRS disclosures and notes builder.' },
  { id: 'loans_desk', name: 'Loan Amortisation Schedules', group: 'Finance', what: 'Loan schedules with interest/principal split.' },
  { id: 'regulated_industries', name: 'Regulated Industries (IFRS 9/17, Royalties, Levies)', group: 'Finance', what: 'Petroleum/mineral/power regulated-sector treatments.' },
  { id: 'compliance_review', name: 'Compliance Review & Gaps', group: 'Finance', what: 'Gap analysis against IFRS and statutory controls.' },
  { id: 'group_consolidation', name: 'Group Consolidation', group: 'Finance', what: 'IFRS 10 consolidation: control establishment, intercompany eliminations, goodwill (IFRS 3), NCI, FX translation.', treatment: 'Read-only workbench — nothing is posted.' },
  { id: 'hr_desk', name: 'HR Management Desk', group: 'People', what: 'Employees, structure, attendance, requests, tasks.' },
  { id: 'payroll', name: 'Payroll Desk', group: 'People', what: 'PAYE, SSNIT tiers, allowances and deductions; posts payroll to the ledger.', treatment: 'Gross − deductions = net; posted to ledger.' },
  { id: 'performance', name: 'Budgeting, Forecast & Scenarios', group: 'Analytics', what: 'Budgets, forecasts, scenario modelling.' },
  { id: 'analytics', name: 'Data Analytics & CAATs', group: 'Analytics', what: 'Anomaly detection and exceptions hunting over the ledger.' },
  { id: 'crm_desk', name: 'Client Relationship Desk', group: 'CRM', what: 'Leads, contacts, opportunities, activities.' },
  { id: 'business_partners_crm', name: 'Customers & Vendors Master (BP)', group: 'CRM', what: 'Register parties, credit limits & terms, opening balances, credit status.', treatment: 'Credit standing enforced on sales and purchases.' },
  { id: 'clients_management', name: 'Client Workspaces', group: 'CRM', what: 'Owner-only multi-entity setup, passwords, services.' },
  { id: 'advisory', name: 'Advisory & Timesheets', group: 'CRM', what: 'Timesheets and billable engagements for the practice.' },
  { id: 'reports', name: 'Reports Centre', group: 'Reports', what: 'Sales, purchases, inventory, clients, store, production, HR, ageing, financial reports.' },
  { id: 'account_statements', name: 'Statements of Account', group: 'Reports', what: 'Customer/vendor statements of account — journal-backed, printable.' },
  { id: 'user_permissions', name: 'User Access & Restrictions', group: 'Admin', what: 'Roles, module ticks, maker limits.' },
  { id: 'enterprise_sso', name: 'Enterprise SSO (SAML/SCIM)', group: 'Admin', what: 'Single-sign-on integration.' },
  { id: 'tax_settings', name: 'Tax Rates & Levy Settings', group: 'Admin', what: 'Configurable statutory rates (VAT, NHIL, GETFund, CST, tourism, WHT).' },
  { id: 'global_tax', name: 'Global Tax Reference', group: 'Admin', what: 'Reference material for cross-border treatments.' },
  { id: 'soc_dr', name: 'SOC 2 & Disaster Recovery', group: 'Admin', what: 'Controls and DR runbook.' },
  { id: 'operations', name: 'Operations & Backup', group: 'Admin', what: 'Backups, restore, off-site copies, retention.' },
  { id: 'realtime_integrations', name: 'API & Webhooks Hub', group: 'Admin', what: 'Public API keys, integration health, webhook config.' },
];

export const GUIDE_SETUP_STEPS = [
  { step: '1 · Activate the workspace', detail: 'First run asks for the setup token + new owner password (docs/DEPLOYMENT_GUIDE.md step 9).' },
  { step: '2 · Create the client workspace', detail: 'One per legal entity — currency, sector, services and own books.' },
  { step: '3 · Company Profile', detail: 'Legal name, TIN, VAT, fiscal year start, bank details — they appear on invoices and statements.' },
  { step: '4 · Chart of Accounts', detail: 'Firm master ships with ~205 accounts; entities tailor names or add custom accounts.' },
  { step: '5 · Opening balances', detail: 'Use Data Migration for real cutovers; Opening Balances Setup for a single manual take-on.' },
  { step: '6 · Users & permissions', detail: 'Client admins, staff, maker limits and desk ticks.' },
  { step: '7 · Parallel-run and close', detail: 'One full month vs legacy books, sign off, lock the period, designate BPZ as book of record.' },
];

export const GUIDE_CHECKLIST = [
  'Client workspace created with correct currency and fiscal year',
  'Company profile filled (TIN, VAT, bank details)',
  'Opening balances imported and previewed cleanly',
  'Bank accounts registered to 10xxxx GLs',
  'Customers & vendors imported with credit terms',
  'Ledger history imported for the reporting year',
  'Trial balance balances; control accounts reconcile',
  'Balance sheet and P&L agree to legacy system',
  'One month parallel-run closed and signed off',
  'Period locked; BPZ designated book of record',
];
