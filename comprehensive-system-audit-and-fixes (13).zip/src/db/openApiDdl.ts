/**
 * Idempotent DDL for the open-API and integration layer: public developer API
 * keys and the e-invoicing submission queue. Appended to the bootstrap DDL list.
 */
export const OPEN_API_DDL: string[] = [
  // Federated identity links: one external IdP subject maps to one local user.
  // The `issuer` + `subject` pair is the identity; the local user keeps its role,
  // tenant and permissions — the IdP authenticates, this system authorises.
  `CREATE TABLE IF NOT EXISTS "sso_identities" (
    "id" text PRIMARY KEY NOT NULL,
    "issuer" text NOT NULL,
    "subject" text NOT NULL,
    "user_id" text NOT NULL,
    "email" text,
    "status" text DEFAULT 'active' NOT NULL,
    "created_at" timestamp with time zone DEFAULT now() NOT NULL,
    "last_login_at" timestamp with time zone,
    "created_by" text NOT NULL
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "sso_identities_iss_sub_idx" ON "sso_identities" ("issuer","subject")`,
  `CREATE INDEX IF NOT EXISTS "sso_identities_user_idx" ON "sso_identities" ("user_id")`,
  `CREATE TABLE IF NOT EXISTS "api_keys" (
    "id" text PRIMARY KEY NOT NULL,
    "client_id" integer,
    "name" text NOT NULL,
    "prefix" text NOT NULL,
    "key_hash" text NOT NULL,
    "scope" text DEFAULT 'read' NOT NULL,
    "status" text DEFAULT 'active' NOT NULL,
    "created_by" text NOT NULL,
    "created_at" timestamp with time zone DEFAULT now() NOT NULL,
    "last_used_at" timestamp with time zone,
    "expires_at" timestamp with time zone
  )`,
  // A machine credential must carry an explicit posting limit. Default 0 means
  // "cannot post above zero" — API writes are refused until the owner grants a
  // limit, so a leaked key cannot move unlimited money.
  `ALTER TABLE "api_keys" ADD COLUMN IF NOT EXISTS "maker_limit" double precision DEFAULT 0 NOT NULL`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "api_keys_prefix_idx" ON "api_keys" ("prefix")`,
  `CREATE INDEX IF NOT EXISTS "api_keys_client_idx" ON "api_keys" ("client_id")`,
  `CREATE TABLE IF NOT EXISTS "einvoice_queue" (
    "id" text PRIMARY KEY NOT NULL,
    "client_id" integer NOT NULL,
    "invoice_no" text NOT NULL,
    "invoice_id" text NOT NULL,
    "payload" jsonb NOT NULL,
    "status" text DEFAULT 'queued' NOT NULL,
    "external_ref" text,
    "response" jsonb,
    "attempts" integer DEFAULT 0 NOT NULL,
    "last_error" text,
    "created_at" timestamp with time zone DEFAULT now() NOT NULL,
    "submitted_at" timestamp with time zone
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "einvoice_queue_invoice_idx" ON "einvoice_queue" ("client_id","invoice_no")`,
  `CREATE INDEX IF NOT EXISTS "einvoice_queue_status_idx" ON "einvoice_queue" ("status")`,
];
