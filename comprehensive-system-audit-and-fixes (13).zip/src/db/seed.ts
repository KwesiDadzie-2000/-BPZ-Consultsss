import "dotenv/config";
import { db } from "@/db";
import { getProvenance } from "@/lib/releaseReadiness";
import { ensureSchema } from "@/db/bootstrap";
import { seedDemoData } from "@/db/seedData";

/**
 * CLI: `npx tsx src/db/seed.ts` — creates any missing tables, then wipes and
 * reloads the demonstration dataset. The running app performs the same
 * provisioning automatically on first use (see src/db/bootstrap.ts).
 */
async function main() {
  if (process.env.BPZ_BOOTSTRAP_MODE === "production") throw new Error("Demo seed is not allowed in production mode.");
  await ensureSchema();
  if ((await getProvenance(db))?.mode === "production") throw new Error("Demo seeding cannot replace a production-provisioned database.");
  await seedDemoData();
  console.log("BPZ Consult demo data loaded.");
}

main().then(() => process.exit(0)).catch((e) => {
  console.error(e);
  process.exit(1);
});
