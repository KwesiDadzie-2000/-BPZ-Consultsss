import { acquireDistributedRateLimit } from "@/lib/distributedRateLimit";
import { authenticateApiKey, type ApiKeyContext } from "@/lib/apiKeys";

/**
 * Public API authentication + throttling. A request is an API call when it
 * carries an `Authorization: Bearer bpz_…` key. Session cookies do NOT grant
 * API access — an interactive sign-in is never a machine credential.
 */
export function readBearerKey(req: Request): string | null {
  const h = req.headers.get("authorization") || "";
  const m = /^Bearer\s+(bpz_\S+)$/i.exec(h.trim());
  return m ? m[1] : null;
}

export async function requireApiKey(req: Request, write = false): Promise<{ ctx: ApiKeyContext } | { response: Response }> {
  const raw = readBearerKey(req);
  if (!raw) return { response: json({ ok: false, error: "Missing API key. Use Authorization: Bearer bpz_…" }, 401) };
  const ctx = await authenticateApiKey(raw);
  if (!ctx) return { response: json({ ok: false, error: "Invalid, expired or revoked API key." }, 401) };
  if (write && ctx.scope !== "write") return { response: json({ ok: false, error: "This API key is read-only." }, 403) };
  const rl = await acquireDistributedRateLimit(`apikey:${ctx.keyId}`, 60, 1); // 60 requests, refilling 1/second
  if (!rl.allowed) {
    return { response: json({ ok: false, error: "Rate limit exceeded (60 requests/minute per key)." }, 429) };
  }
  return { ctx };
}

export function json(body: unknown, status = 200): Response {
  return Response.json(body, { status, headers: { "cache-control": "no-store" } });
}
