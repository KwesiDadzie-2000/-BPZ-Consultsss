import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { apiKeys } from "@/db/schema";

/**
 * Public developer API keys. Only the scrypt hash is stored — the raw key is
 * returned exactly once at creation and never again. Keys are prefixed
 * `bpz_live_` / `bpz_test_`; the first 16 chars act as the lookup index.
 */
const KEY_LEN = 32;

export interface ApiKeyContext {
  keyId: string;
  clientId: number | null; // null = firm-wide
  scope: "read" | "write";
  name: string;
  /** Posting threshold granted to this key (0 = cannot post). */
  makerLimit: number;
}

function hashKey(raw: string, salt: string): string {
  return `${salt}:${scryptSync(raw, salt, KEY_LEN).toString("hex")}`;
}

export function generateApiKey(env: "live" | "test" = "live"): { raw: string; prefix: string } {
  const raw = `bpz_${env}_${randomBytes(24).toString("base64url")}`;
  return { raw, prefix: raw.slice(0, 16) };
}

export async function createApiKey(input: {
  clientId: number | null; name: string; scope: "read" | "write"; createdBy: string; env?: "live" | "test";
  /** Posting threshold; defaults to 0 (no posting) so a key cannot spend by default. */
  makerLimit?: number;
}): Promise<{ id: string; rawKey: string; prefix: string }> {
  const { raw, prefix } = generateApiKey(input.env);
  const salt = randomBytes(16).toString("hex");
  const id = randomBytes(12).toString("hex");
  await db.insert(apiKeys).values({
    id, clientId: input.clientId, name: input.name, prefix,
    keyHash: hashKey(raw, salt), scope: input.scope, status: "active", createdBy: input.createdBy,
    makerLimit: Number.isFinite(input.makerLimit) && (input.makerLimit as number) >= 0 ? (input.makerLimit as number) : 0,
  });
  return { id, rawKey: raw, prefix };
}

/** Authenticate a raw Bearer key. Returns the scoped context or null. */
export async function authenticateApiKey(raw: string): Promise<ApiKeyContext | null> {
  if (!raw || !raw.startsWith("bpz_")) return null;
  const prefix = raw.slice(0, 16);
  const rows = await db.select().from(apiKeys).where(eq(apiKeys.prefix, prefix)).limit(1);
  const row = rows[0];
  if (!row || row.status !== "active") return null;
  if (row.expiresAt && row.expiresAt.getTime() < Date.now()) return null;
  const [salt] = row.keyHash.split(":");
  const candidate = hashKey(raw, salt);
  const a = Buffer.from(candidate);
  const b = Buffer.from(row.keyHash);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  await db.update(apiKeys).set({ lastUsedAt: new Date() }).where(eq(apiKeys.id, row.id)).catch(() => undefined);
  return { keyId: row.id, clientId: row.clientId, scope: row.scope as "read" | "write", name: row.name, makerLimit: Number(row.makerLimit ?? 0) };
}

export async function revokeApiKey(id: string): Promise<boolean> {
  const rows = await db.update(apiKeys).set({ status: "revoked" }).where(eq(apiKeys.id, id)).returning({ id: apiKeys.id });
  return rows.length > 0;
}

export async function listApiKeys() {
  return db.select({
    id: apiKeys.id, clientId: apiKeys.clientId, name: apiKeys.name, prefix: apiKeys.prefix,
    scope: apiKeys.scope, makerLimit: apiKeys.makerLimit, status: apiKeys.status, createdBy: apiKeys.createdBy,
    createdAt: apiKeys.createdAt, lastUsedAt: apiKeys.lastUsedAt, expiresAt: apiKeys.expiresAt,
  }).from(apiKeys);
}
