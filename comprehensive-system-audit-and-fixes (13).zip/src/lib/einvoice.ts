import { eq } from "drizzle-orm";
import { db } from "@/db";
import { einvoiceQueue } from "@/db/schema";

/**
 * E-invoicing adapter (Ghana GRA e-VAT / EIS). Invoices enqueue on issue and a
 * dispatcher submits them to the configured gateway. Entirely opt-in: when
 * BPZ_EINVOICE_ENDPOINT is unset the queue holds records without submitting, and
 * posting is never blocked. Failures are retried with backoff, never dropped.
 */
export function einvoiceEnabled(): boolean {
  return Boolean(process.env.BPZ_EINVOICE_ENDPOINT);
}

export async function enqueueEinvoice(input: { clientId: number; invoiceNo: string; invoiceId: string; payload: Record<string, unknown> }) {
  await db.insert(einvoiceQueue).values({
    id: crypto.randomUUID(), clientId: input.clientId, invoiceNo: input.invoiceNo,
    invoiceId: input.invoiceId, payload: input.payload, status: einvoiceEnabled() ? "queued" : "queued",
  }).onConflictDoNothing();
}

/** Submit queued invoices to the gateway. Returns submitted/failed counts. */
export async function dispatchEinvoiceQueue(limit = 25): Promise<{ submitted: number; failed: number; skipped: number }> {
  if (!einvoiceEnabled()) return { submitted: 0, failed: 0, skipped: 0 };
  const endpoint = process.env.BPZ_EINVOICE_ENDPOINT as string;
  const token = process.env.BPZ_EINVOICE_KEY || "";
  const rows = await db.select().from(einvoiceQueue).where(eq(einvoiceQueue.status, "queued")).limit(limit);
  let submitted = 0;
  let failed = 0;
  for (const row of rows) {
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify(row.payload),
        signal: AbortSignal.timeout(15_000),
      });
      const body = await res.json().catch(() => null);
      if (res.ok) {
        await db.update(einvoiceQueue).set({ status: "accepted", externalRef: body?.reference ?? body?.id ?? null, response: body, submittedAt: new Date(), attempts: row.attempts + 1 }).where(eq(einvoiceQueue.id, row.id));
        submitted++;
      } else {
        throw new Error(`HTTP ${res.status}`);
      }
    } catch (e) {
      const attempts = row.attempts + 1;
      await db.update(einvoiceQueue).set({
        status: attempts >= 5 ? "failed" : "queued", attempts, lastError: e instanceof Error ? e.message : String(e),
      }).where(eq(einvoiceQueue.id, row.id));
      failed++;
    }
  }
  return { submitted, failed, skipped: 0 };
}
