import { sql } from "drizzle-orm";
import type { db as Db } from "@/db";
import { buildJournalHeader } from "@/lib/journalPosting";
import type { ACDOCALine } from "@/types/accounting";

/**
 * Journal-header repair (idempotent, one-time per database).
 *
 * `journal_headers` is the document-level control record: total debits and
 * credits in minor units plus a content hash. The posting routes write it on
 * every new document, but rows that arrived through the seed or an import can
 * lack it — and a document without its control record cannot be hash-verified.
 *
 * This fills the gap for documents that are already in `journal_lines`, and is
 * safe to run on every boot: it only inserts missing headers and never touches
 * an existing one (which would be rewriting evidence).
 */
type Executor = Pick<typeof Db, "execute">;
type Tx = { execute: Executor["execute"] };

const MAX_DOCUMENTS_PER_RUN = 500;

export async function repairMissingJournalHeaders(tx: Tx): Promise<number> {
  const missing = await tx.execute<{ client_id: number; doc_no: string }>(sql`
    select distinct l.client_id, l.doc_no
      from journal_lines l
     where not exists (
       select 1 from journal_headers h
        where h.client_id = l.client_id and h.doc_no = l.doc_no
     )
     order by l.client_id, l.doc_no
     limit ${MAX_DOCUMENTS_PER_RUN}`);

  let repaired = 0;
  for (const row of missing.rows) {
    const lines = await tx.execute<{
      id: string; doc_no: string; period: string; date: string; module: string; doc_type: string;
      account_no: string; account_name: string; cost_center: string | null; debit: number; credit: number;
      currency: string; description: string; created_by: string; checked_by: string | null;
      is_reversed: boolean; reference: string | null; client_id: number;
    }>(sql`
      select id, doc_no, period, date, module, doc_type, account_no, account_name, cost_center,
             debit, credit, currency, description, created_by, checked_by, is_reversed, reference, client_id
        from journal_lines
       where client_id = ${row.client_id} and doc_no = ${row.doc_no}
       order by id`);

    if (!lines.rows.length) continue;
    const mapped: ACDOCALine[] = lines.rows.map((l) => ({
      id: l.id,
      docNo: l.doc_no,
      period: l.period,
      date: l.date,
      module: l.module as ACDOCALine["module"],
      docType: l.doc_type as ACDOCALine["docType"],
      accountNo: l.account_no,
      accountName: l.account_name,
      costCenter: l.cost_center ?? undefined,
      debit: Number(l.debit),
      credit: Number(l.credit),
      currency: l.currency,
      description: l.description,
      createdBy: l.created_by,
      checkedBy: l.checked_by ?? undefined,
      isReversed: l.is_reversed,
      reference: l.reference ?? undefined,
      clientId: l.client_id,
    }));

    try {
      const header = buildJournalHeader(mapped);
      await tx.execute(sql`
        insert into journal_headers
          (id, client_id, doc_no, period, date, module, doc_type, currency, description,
           debit_total, credit_total, line_count, created_by, checked_by, reference, content_hash)
        values (${header.id}, ${header.clientId}, ${header.docNo}, ${header.period}, ${header.date},
                ${header.module}, ${header.docType}, ${header.currency}, ${header.description},
                ${header.debitTotal}, ${header.creditTotal}, ${header.lineCount}, ${header.createdBy},
                ${header.checkedBy}, ${header.reference}, ${header.contentHash})
        on conflict do nothing`);
      repaired += 1;
    } catch (error) {
      // Never let one unreadable document stop boot; report and continue.
      console.error(`[bpz] journal header repair skipped ${row.client_id}:${row.doc_no}`, error);
    }
  }
  return repaired;
}
