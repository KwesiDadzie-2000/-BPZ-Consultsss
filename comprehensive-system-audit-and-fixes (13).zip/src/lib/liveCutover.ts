import { inArray } from 'drizzle-orm';
import type { db } from '@/db';
import { liveBooks } from '@/db/schema';

export type BookPeriod = { clientId: number; period: string };
type Reader = Pick<typeof db, 'select'>;

/** Called under the shared accounting write lock before a new posting is committed. */
export async function liveBookCutoffError(exec: Reader, proposed: readonly BookPeriod[]): Promise<string | null> {
  if (!proposed.length) return null;
  const rows = await exec.select({ clientId: liveBooks.clientId, period: liveBooks.period }).from(liveBooks)
    .where(inArray(liveBooks.clientId, [...new Set(proposed.map((line) => line.clientId))]));
  const cutoff = new Map(rows.map((row) => [row.clientId, row.period]));
  for (const line of proposed) {
    const closed = cutoff.get(line.clientId);
    if (closed && line.period <= closed) return `Live-book cutover protects all periods through ${closed}. Post a correcting entry in an open later period.`;
  }
  return null;
}
