import type { ACDOCALine } from '@/types/accounting';

/**
 * Client migration from another accounting system (legacy ERP / spreadsheet).
 *
 * Four import families, each validated server-side before anything is written:
 *   1. Opening trial balance  → one balanced journal at the cut-over date.
 *   2. Ledger history         → journal documents (optionally per document).
 *   3. Business partners      → customers/vendors with credit terms.
 *   4. Bank accounts          → treasury records mapped to 10xxxx GLs.
 *
 * NOTHING is posted until the whole file validates. Money is handled in minor
 * units (cents) end to end, so a migration cannot introduce sub-pesewa drift.
 */
const MINOR = (n: number) => Math.round((n + Number.EPSILON) * 100);
const MAJOR = (c: number) => Math.round(c) / 100;
const MAX_ROWS = 20_000;
export const MAX_MIGRATION_BYTES = 5 * 1024 * 1024;

export interface MigrationIssue { row: number; message: string }
export type MigrationPreview =
  | { ok: true; kind: 'opening'; rows: number; totalDebit: number; totalCredit: number; balanced: boolean; sample: string[] }
  | { ok: true; kind: 'ledger'; rows: number; documents: number; totalDebit: number; totalCredit: number; balanced: boolean; sample: string[] }
  | { ok: true; kind: 'partners'; rows: number; customers: number; vendors: number; sample: string[] }
  | { ok: true; kind: 'banks'; rows: number; sample: string[] }
  | { ok: false; errors: MigrationIssue[] };

const unquote = (s: string) => s.trim().replace(/^"([^"\r\n]*)"$/, '$1').trim();
function splitCsv(text: string): string[][] {
  const out: string[][] = [];
  for (const line of text.replace(/^\uFEFF/, '').split(/\r\n|\r|\n/)) {
    if (!line.trim()) continue;
    const row: string[] = [];
    let cell = '';
    let quoted = false;
    for (let i = 0; i < line.length; i += 1) {
      const ch = line[i];
      if (ch === '"') { if (quoted && line[i + 1] === '"') { cell += '"'; i += 1; } else quoted = !quoted; continue; }
      if ((ch === ',' || ch === ';' || ch === '\t') && !quoted) { row.push(cell); cell = ''; continue; }
      cell += ch;
    }
    row.push(cell);
    out.push(row.map(unquote));
  }
  return out;
}
const headerOf = (rows: string[][]) => rows[0]?.map((h) => h.toLowerCase().replace(/[^a-z0-9]/g, '')) ?? [];
function col(headers: string[], names: string[]): number {
  for (const n of names) { const i = headers.indexOf(n); if (i >= 0) return i; }
  return -1;
}
function money(text: string): number | null {
  const v = (text || '').replace(/[^0-9.\-()]/g, '');
  if (!v || v === '-' || v === '.') return 0;
  const neg = /^\(.*\)$/.test(v) || v.startsWith('-');
  const n = Number(v.replace(/[()\-]/g, ''));
  return Number.isFinite(n) ? (neg ? -n : n) : null;
}
const isoDate = (v: string): string | null => {
  const s = (v || '').trim();
  let m = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/.exec(s);
  if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = /^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/.exec(s);
  if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null;
};
const periodOf = (date: string) => date.slice(0, 7);
const ACC = /^\d{6}$/;

/** Opening trial balance: Account, Debit, Credit (optionally Currency). */
export function parseOpeningBalances(csv: string, currency: string): MigrationPreview {
  const rows = splitCsv(csv);
  const errors: MigrationIssue[] = [];
  if (!rows.length) return { ok: false, errors: [{ row: 0, message: 'The file is empty.' }] };
  if (rows.length > MAX_ROWS) return { ok: false, errors: [{ row: 0, message: `Too many rows (max ${MAX_ROWS}).` }] };
  const h = headerOf(rows);
  const iAcc = col(h, ['account', 'accountno', 'glaccount', 'accountcode']);
  const iDr = col(h, ['debit', 'debits', 'dr', 'debitamount']);
  const iCr = col(h, ['credit', 'credits', 'cr', 'creditamount']);
  if (iAcc < 0 || iDr < 0 || iCr < 0) return { ok: false, errors: [{ row: 1, message: 'Header must include Account, Debit and Credit columns.' }] };
  let dr = 0; let cr = 0; const sample: string[] = []; const seen = new Set<string>();
  for (let r = 1; r < rows.length; r += 1) {
    const row = rows[r]; const line = r + 1;
    const account = (row[iAcc] || '').trim();
    if (!ACC.test(account)) { errors.push({ row: line, message: `Account "${account}" must be six digits.` }); continue; }
    if (seen.has(account)) { errors.push({ row: line, message: `Account ${account} appears twice. Consolidate first.` }); continue; }
    const d = money(row[iDr] || ''); const c = money(row[iCr] || '');
    if (d === null || c === null) { errors.push({ row: line, message: 'Debit and Credit must be numbers.' }); continue; }
    const dc = MINOR(Math.abs(d)); const cc = MINOR(Math.abs(c));
    if (dc > 0 && cc > 0) { errors.push({ row: line, message: 'Enter the balance on one side only (0 on the other).' }); continue; }
    seen.add(account); dr += dc; cr += cc;
    if (sample.length < 5) sample.push(`${account}  Dr ${MAJOR(dc).toFixed(2)}  Cr ${MAJOR(cc).toFixed(2)}`);
  }
  if (errors.length) return { ok: false, errors };
  if (dr !== cr) return { ok: false, errors: [{ row: 0, message: `Opening trial balance does not balance: Dr ${MAJOR(dr).toFixed(2)} vs Cr ${MAJOR(cr).toFixed(2)} ${currency}. Difference ${MAJOR(dr - cr).toFixed(2)}.` }] };
  return { ok: true, kind: 'opening', rows: seen.size, totalDebit: MAJOR(dr), totalCredit: MAJOR(cr), balanced: true, sample };
}

/** Ledger history: DocNo, Date, Account, Debit, Credit, Description [, Party]. */
export function parseLedgerHistory(csv: string, currency: string): MigrationPreview {
  const rows = splitCsv(csv);
  const errors: MigrationIssue[] = [];
  if (!rows.length) return { ok: false, errors: [{ row: 0, message: 'The file is empty.' }] };
  if (rows.length > MAX_ROWS) return { ok: false, errors: [{ row: 0, message: `Too many rows (max ${MAX_ROWS}).` }] };
  const h = headerOf(rows);
  const iDoc = col(h, ['document', 'docno', 'documentno', 'voucher', 'reference']);
  const iDate = col(h, ['date', 'transactiondate', 'postingdate']);
  const iAcc = col(h, ['account', 'accountno', 'glaccount', 'accountcode']);
  const iDr = col(h, ['debit', 'debits', 'dr', 'debitamount']);
  const iCr = col(h, ['credit', 'credits', 'cr', 'creditamount']);
  const iDesc = col(h, ['description', 'narrative', 'details', 'memo']);
  const missing = [iDoc < 0 ? 'Document' : '', iDate < 0 ? 'Date' : '', iAcc < 0 ? 'Account' : '', iDr < 0 ? 'Debit' : '', iCr < 0 ? 'Credit' : ''].filter(Boolean);
  if (missing.length) return { ok: false, errors: [{ row: 1, message: `Header is missing: ${missing.join(', ')}.` }] };
  const byDoc = new Map<string, { dr: number; cr: number; date: string; count: number }>();
  const sample: string[] = [];
  let dr = 0; let cr = 0;
  for (let r = 1; r < rows.length; r += 1) {
    const row = rows[r]; const line = r + 1;
    const docNo = (row[iDoc] || '').trim();
    const date = isoDate(row[iDate] || '');
    const account = (row[iAcc] || '').trim();
    const d = money(row[iDr] || ''); const c = money(row[iCr] || '');
    if (!docNo) { errors.push({ row: line, message: 'Document number is required.' }); continue; }
    if (!date) { errors.push({ row: line, message: `Date "${row[iDate]}" is not a valid date.` }); continue; }
    if (!ACC.test(account)) { errors.push({ row: line, message: `Account "${account}" must be six digits.` }); continue; }
    if (d === null || c === null) { errors.push({ row: line, message: 'Debit and Credit must be numbers.' }); continue; }
    const dc = MINOR(Math.abs(d)); const cc = MINOR(Math.abs(c));
    if (dc === 0 && cc === 0) { errors.push({ row: line, message: 'A line must carry a debit or a credit.' }); continue; }
    if (dc > 0 && cc > 0) { errors.push({ row: line, message: 'Enter the amount on one side only.' }); continue; }
    const g = byDoc.get(docNo) ?? { dr: 0, cr: 0, date, count: 0 };
    g.dr += dc; g.cr += cc; g.count += 1; byDoc.set(docNo, g);
    dr += dc; cr += cc;
    if (sample.length < 5) sample.push(`${docNo}  ${date}  ${account}  Dr ${MAJOR(dc).toFixed(2)}  Cr ${MAJOR(cc).toFixed(2)}`);
  }
  if (errors.length) return { ok: false, errors };
  for (const [docNo, g] of byDoc) if (g.dr !== g.cr) errors.push({ row: 0, message: `Document ${docNo} does not balance (Dr ${MAJOR(g.dr).toFixed(2)} vs Cr ${MAJOR(g.cr).toFixed(2)}).` });
  if (errors.length) return { ok: false, errors };
  return { ok: true, kind: 'ledger', rows: dr / 100 > 0 ? rows.length - 1 : 0, documents: byDoc.size, totalDebit: MAJOR(dr), totalCredit: MAJOR(cr), balanced: dr === cr, sample };
}

/** Partners: Code, Name, Type (Customer|Vendor) [, CreditLimit, CreditTermsDays, TIN, Email, Phone]. */
export function parsePartners(csv: string): MigrationPreview {
  const rows = splitCsv(csv);
  const errors: MigrationIssue[] = [];
  if (!rows.length) return { ok: false, errors: [{ row: 0, message: 'The file is empty.' }] };
  const h = headerOf(rows);
  const iCode = col(h, ['code', 'partnercode', 'account']);
  const iName = col(h, ['name', 'partnername', 'customer', 'vendor', 'supplier']);
  const iType = col(h, ['type', 'category', 'kind']);
  const iLimit = col(h, ['creditlimit', 'limit']);
  const iTerms = col(h, ['credittermsdays', 'terms', 'creditterms', 'days']);
  const iStatus = col(h, ['creditstatus', 'status', 'standing']);
  const iTin = col(h, ['tin', 'taxid', 'vat']);
  const iEmail = col(h, ['email']);
  const iPhone = col(h, ['phone', 'telephone', 'mobile']);
  if (iCode < 0 || iName < 0 || iType < 0) return { ok: false, errors: [{ row: 1, message: 'Header must include Code, Name and Type (Customer|Vendor).' }] };
  const seen = new Set<string>(); const sample: string[] = [];
  let customers = 0; let vendors = 0;
  for (let r = 1; r < rows.length; r += 1) {
    const row = rows[r]; const line = r + 1;
    const code = (row[iCode] || '').trim().toUpperCase();
    const name = (row[iName] || '').trim();
    const type = (row[iType] || '').trim().toLowerCase().startsWith('v') ? 'Vendor' : (row[iType] || '').trim().toLowerCase().startsWith('c') ? 'Customer' : '';
    if (!code) { errors.push({ row: line, message: 'Code is required.' }); continue; }
    if (!name) { errors.push({ row: line, message: 'Name is required.' }); continue; }
    if (!type) { errors.push({ row: line, message: 'Type must be Customer or Vendor.' }); continue; }
    if (seen.has(code)) { errors.push({ row: line, message: `Code ${code} is duplicated.` }); continue; }
    const limit = iLimit >= 0 ? money(row[iLimit] || '') : 0;
    const terms = iTerms >= 0 ? Number(row[iTerms] || 0) : 0;
    if (limit === null || (limit as number) < 0) { errors.push({ row: line, message: 'Credit limit must be a non-negative number.' }); continue; }
    if (!Number.isFinite(terms) || terms < 0 || terms > 365) { errors.push({ row: line, message: 'Credit terms must be 0–365 days.' }); continue; }
    seen.add(code);
    if (type === 'Customer') customers += 1; else vendors += 1;
    if (sample.length < 5) sample.push(`${code}  ${name}  ${type}  limit ${MAJOR(MINOR(limit as number)).toFixed(2)}  ${terms}d`);
  }
  if (errors.length) return { ok: false, errors };
  return { ok: true, kind: 'partners', rows: seen.size, customers, vendors, sample };
}

/** Bank accounts: Code, Name, Bank, AccountNo, Currency, GL, OpeningBalance. */
export function parseBanks(csv: string): MigrationPreview {
  const rows = splitCsv(csv);
  const errors: MigrationIssue[] = [];
  if (!rows.length) return { ok: false, errors: [{ row: 0, message: 'The file is empty.' }] };
  const h = headerOf(rows);
  const iCode = col(h, ['code', 'bankcode']);
  const iName = col(h, ['name', 'accountname', 'account']);
  const iBank = col(h, ['bank', 'bankname']);
  const iNo = col(h, ['accountno', 'number', 'account']);
  const iCcy = col(h, ['currency', 'ccy']);
  const iGl = col(h, ['gl', 'glaccount', 'accountno']);
  const iBal = col(h, ['openingbalance', 'balance', 'opening']);
  if (iName < 0 || iGl < 0) return { ok: false, errors: [{ row: 1, message: 'Header must include Name and GL account (a 10xxxx treasury account).' }] };
  const sample: string[] = [];
  for (let r = 1; r < rows.length; r += 1) {
    const row = rows[r]; const line = r + 1;
    const name = (row[iName] || '').trim();
    const gl = (row[iGl] || '').trim();
    if (!name) { errors.push({ row: line, message: 'Name is required.' }); continue; }
    if (!/^10\d{4}$/.test(gl)) { errors.push({ row: line, message: `GL "${gl}" must be a treasury account (10xxxx).` }); continue; }
    const bal = iBal >= 0 ? money(row[iBal] || '') : 0;
    if (bal === null) { errors.push({ row: line, message: 'Opening balance must be a number.' }); continue; }
    if (sample.length < 5) sample.push(`${name}  ${gl}  ${MAJOR(MINOR(bal)).toFixed(2)}`);
  }
  if (errors.length) return { ok: false, errors };
  return { ok: true, kind: 'banks', rows: rows.length - 1, sample };
}

/** Build the opening-balance journal at the cut-over date. */
export function buildOpeningJournal(
  csv: string, currency: string, clientId: number, date: string, actor: string,
): { ok: true; lines: ACDOCALine[] } | { ok: false; errors: MigrationIssue[] } {
  const preview = parseOpeningBalances(csv, currency);
  if (!preview.ok) return preview;
  const rows = splitCsv(csv);
  const h = headerOf(rows);
  const iAcc = col(h, ['account', 'accountno', 'glaccount', 'accountcode']);
  const iDr = col(h, ['debit', 'debits', 'dr', 'debitamount']);
  const iCr = col(h, ['credit', 'credits', 'cr', 'creditamount']);
  const docNo = `OPENING-${date}`;
  const period = periodOf(date);
  const lines: ACDOCALine[] = [];
  for (let r = 1; r < rows.length; r += 1) {
    const row = rows[r]; const account = (row[iAcc] || '').trim();
    const dc = MINOR(Math.abs(money(row[iDr] || '') ?? 0)); const cc = MINOR(Math.abs(money(row[iCr] || '') ?? 0));
    if (dc === 0 && cc === 0) continue;
    lines.push({
      id: `mig-obl-${r}`, docNo, period, date, module: 'FI', docType: 'STAT',
      accountNo: account, accountName: account, debit: MAJOR(dc), credit: MAJOR(cc),
      currency, description: `Opening balance brought forward`, createdBy: actor, clientId,
    });
  }
  return { ok: true, lines };
}

/** Build ledger-history journal lines (one document per document number). */
export function buildLedgerJournal(
  csv: string, currency: string, clientId: number, actor: string,
): { ok: true; lines: ACDOCALine[] } | { ok: false; errors: MigrationIssue[] } {
  const preview = parseLedgerHistory(csv, currency);
  if (!preview.ok) return preview;
  const rows = splitCsv(csv);
  const h = headerOf(rows);
  const iDoc = col(h, ['document', 'docno', 'documentno', 'voucher', 'reference']);
  const iDate = col(h, ['date', 'transactiondate', 'postingdate']);
  const iAcc = col(h, ['account', 'accountno', 'glaccount', 'accountcode']);
  const iDr = col(h, ['debit', 'debits', 'dr', 'debitamount']);
  const iCr = col(h, ['credit', 'credits', 'cr', 'creditamount']);
  const iDesc = col(h, ['description', 'narrative', 'details', 'memo']);
  const lines: ACDOCALine[] = [];
  for (let r = 1; r < rows.length; r += 1) {
    const row = rows[r];
    const docNo = (row[iDoc] || '').trim();
    const date = isoDate(row[iDate] || '') as string;
    const account = (row[iAcc] || '').trim();
    const dc = MINOR(Math.abs(money(row[iDr] || '') ?? 0)); const cc = MINOR(Math.abs(money(row[iCr] || '') ?? 0));
    if (dc === 0 && cc === 0) continue;
    lines.push({
      id: `mig-hist-${r}`, docNo, period: periodOf(date), date, module: 'FI', docType: 'JE',
      accountNo: account, accountName: account, debit: MAJOR(dc), credit: MAJOR(cc),
      currency, description: (iDesc >= 0 ? row[iDesc] || '' : '') || `Migrated ledger line ${docNo}`,
      createdBy: actor, clientId,
    });
  }
  return { ok: true, lines };
}
