import { isValidPeriod } from './journalValidation';

export const CLOSE_CHECKS = [
  { key: 'opening', label: 'Opening balances', detail: 'Agree take-on balances and account mappings to the signed opening trial balance.', group: 'Ledger', kind: 'review' },
  { key: 'bank', label: 'Bank, cash and wallets', detail: 'Agree adjusted closing cash to the bank reconciliations, including outstanding items and foreign-currency schedules.', group: 'Treasury', kind: 'amount' },
  { key: 'receivables', label: 'Receivables', detail: 'Tie the customer ageing, credits and advances to the receivables control and legacy ageing.', group: 'Trade', kind: 'amount' },
  { key: 'payables', label: 'Payables', detail: 'Tie the aged supplier balances, credits and advances to the payables control and legacy ageing.', group: 'Trade', kind: 'amount' },
  { key: 'inventory', label: 'Inventory and WIP', detail: 'Tie carrying values to the signed count, cost layers, production WIP and control accounts.', group: 'Operations', kind: 'amount' },
  { key: 'payroll', label: 'Payroll and contributions', detail: 'Compare the month’s net pay and verify gross pay, deductions, remittances and current rates in the supporting schedule.', group: 'People', kind: 'amount' },
  { key: 'tax', label: 'Tax and statutory returns', detail: 'Compare the month-end tax position. Verify each VAT, levy, WHT, PAYE and CIT balance and current settings separately in the supporting schedule.', group: 'Compliance', kind: 'amount' },
  { key: 'sector', label: 'Sector and financial reporting', detail: 'Reviewer checks sector-specific accounting, statement disclosures, and statutory assumptions for this entity.', group: 'Compliance', kind: 'review' },
  { key: 'consolidation', label: 'Group reporting', detail: 'If applicable, retain approved currency translation, eliminations, goodwill and non-controlling interest workpapers.', group: 'Reporting', kind: 'optional' },
  { key: 'integrations', label: 'Integrations and outputs', detail: 'Verify any enabled mail, identity, webhooks or exports with site-specific evidence. Explain if none are used.', group: 'Deployment', kind: 'optional' },
] as const;

export type CloseKey = typeof CLOSE_CHECKS[number]['key'];
export type CloseStatus = 'draft' | 'submitted' | 'approved' | 'returned' | 'active';
export type CloseCheck = { reference: string; notes: string; legacy: string; bpz: string; result: 'pending' | 'verified' | 'not_applicable' };
export type TrialEntry = { account: string; debit: number; credit: number };
export type LegacyTrial = { fileName: string; sha256: string; entries: TrialEntry[] };
export type CutoverWork = { reference: string; notes: string; checks: Partial<Record<CloseKey, CloseCheck>>; legacyTrial: LegacyTrial | null };
export const EMPTY_CHECK: CloseCheck = { reference: '', notes: '', legacy: '', bpz: '', result: 'pending' };
export const EMPTY_WORK: CutoverWork = { reference: '', notes: '', checks: {}, legacyTrial: null };
export const TRIAL_FILE_LIMIT = 384 * 1024;
export const EVIDENCE_FILE_LIMIT = 2 * 1024 * 1024;
const MAX_CENTS = 100_000_000_000_000;

/** Parse an exact decimal amount; an empty field is never equivalent to zero. */
export function closeCents(value: string): number | null {
  const match = /^([+-]?)(\d{1,13})(?:\.(\d{1,2}))?$/.exec(value.trim());
  if (!match) return null;
  const n = Number(match[2]) * 100 + Number((match[3] ?? '').padEnd(2, '0'));
  return n <= MAX_CENTS ? (match[1] === '-' && n ? -n : n) : null;
}

export function controlResult(def: typeof CLOSE_CHECKS[number], value = EMPTY_CHECK) {
  const legacy = closeCents(value.legacy);
  const bpz = closeCents(value.bpz);
  const variance = legacy !== null && bpz !== null ? bpz - legacy : null;
  const evidence = value.reference.trim().length >= 3 && value.notes.trim().length >= 10;
  const ready = evidence && (def.kind === 'amount' ? variance === 0 : value.result === 'verified' || def.kind === 'optional' && value.result === 'not_applicable');
  return { ready, variance, legacy, bpz, evidence };
}

export const moneyDecimal = (cents: number) => (cents / 100).toFixed(2);

export function periodEnd(period: string) {
  if (!isValidPeriod(period)) throw new Error('Choose an accounting month in YYYY-MM format.');
  const [year, month] = period.split('-').map(Number);
  return `${period}-${String(new Date(Date.UTC(year, month, 0)).getUTCDate()).padStart(2, '0')}`;
}

// Trial-balance rows are simple numeric fields. Quotes around the field are
// allowed independently; an embedded comma or newline is not a valid amount.
const unquote = (s: string) => s.trim().replace(/^"([^"\r\n]*)"$/, '$1').trim();
export function parseLegacyTrial(csv: string, currency: string): TrialEntry[] {
  if (csv.length > TRIAL_FILE_LIMIT) throw new Error('Trial balance file exceeds 384 KB.');
  const rows = csv.replace(/^\uFEFF/, '').split(/\r\n|\r|\n/).map((line, index) => ({ line, index: index + 1 })).filter((r) => r.line.trim());
  if (rows.length < 2 || rows.length > 3001) throw new Error('The trial balance needs a header and between 1 and 3,000 account rows.');
  const delimiters = [',', ';', '\t'];
  const delimiter = delimiters.find((d) => /^account,debit,credit(,currency)?$/.test(rows[0].line.split(d).map((s) => unquote(s).toLowerCase()).join(',')));
  if (!delimiter) throw new Error('Use the columns Account, Debit, Credit (and optionally Currency), in that order.');
  const width = rows[0].line.split(delimiter).length;
  const used = new Set<string>();
  let dr = 0;
  let cr = 0;
  const list = rows.slice(1).map(({ line, index }) => {
    const [account, debitText, creditText, code, ...rest] = line.split(delimiter).map(unquote);
    const debit = closeCents(debitText ?? '');
    const credit = closeCents(creditText ?? '');
    if (rest.length || line.split(delimiter).length !== width || !/^\d{6}$/.test(account) || (width === 4 && code.toUpperCase() !== currency)) {
      throw new Error(`Row ${index}: enter a six-digit BPZ account, two decimal amounts and the workspace currency when supplied.`);
    }
    if (used.has(account)) throw new Error(`Row ${index}: duplicate account ${account}. Consolidate the legacy lines first.`);
    if (debit === null || credit === null || debit < 0 || credit < 0 || (debit > 0 && credit > 0)) {
      throw new Error(`Row ${index}: enter a net closing balance on one side and 0 on the other. Use a decimal point and no thousands separator.`);
    }
    used.add(account);
    dr += debit;
    cr += credit;
    if (!Number.isSafeInteger(dr) || !Number.isSafeInteger(cr)) throw new Error('Trial balance exceeds supported cent precision.');
    return { account, debit, credit };
  });
  return list.sort((a, b) => a.account.localeCompare(b.account));
}

export function compareTrial(bpz: readonly TrialEntry[], legacy: readonly TrialEntry[]) {
  const make = (rows: readonly TrialEntry[]) => new Map(rows.map((r) => [r.account, r]));
  const a = make(bpz);
  const b = make(legacy);
  const accounts = [...new Set([...a.keys(), ...b.keys()])].sort();
  const rows = accounts.map((account) => {
    const live = a.get(account);
    const other = b.get(account);
    const bpzNet = (live?.debit ?? 0) - (live?.credit ?? 0);
    const legacyNet = (other?.debit ?? 0) - (other?.credit ?? 0);
    return { account, bpzNet, legacyNet, variance: bpzNet - legacyNet };
  });
  return { rows, differences: rows.filter((r) => r.variance !== 0).length, bpzBalance: rows.reduce((n, r) => n + r.bpzNet, 0), legacyBalance: rows.reduce((n, r) => n + r.legacyNet, 0) };
}

export type ReleaseGate = { key: string; label: string; passed: boolean; detail: string };
export type EvidenceKey = CloseKey | 'legacy_trial';
export type CloseEvidence = { id: string; key: EvidenceKey; name: string; size: number; sha256: string; actor: string; at: string };
export type CloseLedger = { hash: string; periodLines: number; foreignLines: number; unbalanced: number; trial: TrialEntry[]; anchors: Partial<Record<CloseKey, number>> };
export type ClosePacket = {
  id: string; version: number; status: CloseStatus; work: CutoverWork;
  preparedBy: string; submittedBy: string | null; reviewedBy: string | null; reviewedAt: string | null;
  reviewNotes: string | null; activatedBy: string | null; activatedAt: string | null;
};
export type CutoverView = {
  client: { id: number; name: string; code: string; currency: string; sector: string };
  period: string; packet: ClosePacket | null; ledger: CloseLedger; evidence: CloseEvidence[];
  gates: ReleaseGate[]; blockers: string[]; signoffStale: boolean; activePeriod: string | null;
  permissions: { prepare: boolean; review: boolean; revise: boolean; owner: boolean };
  history: { action: string; actor: string; at: string; detail: string }[];
};