import { createHash, randomUUID } from 'node:crypto';
import { and, desc, eq, like, lte, or, sql } from 'drizzle-orm';
import { db } from '@/db';
import { auditLog, clients, closedPeriods, journalLines, liveBooks, parallelCloseFiles, parallelCloses, systemSettings } from '@/db/schema';
import { hasFirmWideScope, maySeeSection } from '@/utils/access';
import type { ClientEntity, UserAccount } from '@/types/accounting';
import { isValidIsoDate, isValidPeriod } from './journalValidation';
import { CLOSE_CHECKS, compareTrial, controlResult, EMPTY_CHECK, EMPTY_WORK, EVIDENCE_FILE_LIMIT,
  moneyDecimal, parseLegacyTrial, periodEnd, TRIAL_FILE_LIMIT, type CloseCheck, type CloseEvidence, type CloseKey,
  type CloseLedger, type ClosePacket, type CutoverView, type CutoverWork, type EvidenceKey } from './parallelClose';
import { readReleaseGates, seal } from './releaseReadiness';

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
type Entity = typeof clients.$inferSelect;
type Packet = typeof parallelCloses.$inferSelect;
export class CloseError extends Error {
  constructor(message: string, readonly status = 400) { super(message); }
}
const fail = (message: string, status = 400): never => { throw new CloseError(message, status); };
const string = (value: unknown, max: number) => {
  if (typeof value !== 'string' || value.length > max) return fail(`Use text of no more than ${max} characters.`);
  return value.trim();
};
const record = (value: unknown): Record<string, unknown> => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return fail('Expected a close packet object.');
  return value as Record<string, unknown>;
};
const editable = (row: Packet) => row.status === 'draft' || row.status === 'returned';
const keyOf = (value: unknown): EvidenceKey => {
  if (value === 'legacy_trial' || CLOSE_CHECKS.some((c) => c.key === value)) return value as EvidenceKey;
  return fail('Unknown evidence category.');
};
const target = (period: string) => `close:${period}`;

export function validateCloseScope(clientId: unknown, period: unknown) {
  const id = typeof clientId === 'number' ? clientId : typeof clientId === 'string' && /^\d+$/.test(clientId) ? Number(clientId) : 0;
  if (!Number.isSafeInteger(id) || id < 1 || id > 2147483647 || !isValidPeriod(period) || Number(period.slice(0, 4)) < 1900 || periodEnd(period) > '9999-12-31') {
    return fail('Choose a valid workspace and accounting month.');
  }
  if (period > new Date().toISOString().slice(0, 7)) return fail('Future months cannot be used for a parallel close.');
  return { id, period };
}

async function loadEntity(exec: Tx, user: UserAccount, id: number) {
  if (user.status !== 'active' || !hasFirmWideScope(user) && user.clientId !== id) return fail('This close belongs to another workspace or your account is restricted.', 403);
  const [entity] = await exec.select().from(clients).where(eq(clients.id, id)).limit(1);
  if (!entity) return fail('Workspace not found.', 404);
  if (!maySeeSection(user, entity as ClientEntity, 'parallel_close')) return fail('You do not have access to Parallel Close.', 403);
  return entity;
}
const findPacket = async (exec: Tx, id: number, period: string) => (await exec.select().from(parallelCloses)
  .where(and(eq(parallelCloses.clientId, id), eq(parallelCloses.period, period))).limit(1))[0];
const exposedFiles = { id: parallelCloseFiles.id, key: parallelCloseFiles.checkKey, name: parallelCloseFiles.name,
  size: parallelCloseFiles.size, sha256: parallelCloseFiles.sha256, actor: parallelCloseFiles.actor, at: parallelCloseFiles.at };
async function getFiles(exec: Tx, closeId: string): Promise<CloseEvidence[]> {
  const rows = await exec.select(exposedFiles).from(parallelCloseFiles).where(eq(parallelCloseFiles.closeId, closeId)).orderBy(parallelCloseFiles.at, parallelCloseFiles.id);
  return rows.map((r) => ({ ...r, key: r.key as EvidenceKey, at: r.at.toISOString() }));
}

/** The trial uses historical closing net balances; the month cannot pass on a carry-forward alone. */
async function readLedger(exec: Tx, entity: Entity, period: string): Promise<CloseLedger> {
  const end = periodEnd(period);
  const rows = await exec.select().from(journalLines).where(and(eq(journalLines.clientId, entity.id),
    or(lte(journalLines.period, period), lte(journalLines.date, end)))).orderBy(journalLines.id);
  let periodLines = 0;
  let foreignLines = 0;
  let invalid = 0;
  const documents = new Map<string, number>();
  const accountNet = new Map<string, number>();
  let payroll = 0;
  for (const row of rows) {
    if (!isValidIsoDate(row.date) || row.date.slice(0, 7) !== row.period || !/^\d{6}$/.test(row.accountNo)) { invalid++; continue; }
    if (row.currency.toUpperCase() !== entity.currency.toUpperCase()) { foreignLines++; continue; }
    const debit = Math.round(row.debit * 100);
    const credit = Math.round(row.credit * 100);
    if (!Number.isSafeInteger(debit) || !Number.isSafeInteger(credit) || debit < 0 || credit < 0 || (debit > 0) === (credit > 0)
      || Math.abs(row.debit - debit / 100) > 0.000001 || Math.abs(row.credit - credit / 100) > 0.000001) { invalid++; continue; }
    const net = debit - credit;
    const documentId = `${row.period}:${row.docNo}`;
    documents.set(documentId, (documents.get(documentId) ?? 0) + net);
    accountNet.set(row.accountNo, (accountNet.get(row.accountNo) ?? 0) + net);
    if (row.period === period) {
      periodLines++;
      if (row.accountNo === '205000' && row.module === 'HR' && /^PAYROLL-/.test(row.docNo)) payroll += credit;
      if (row.accountNo === '205000' && row.module === 'HR' && row.docType === 'REV' && /^REV-PAYROLL-/.test(row.docNo)) payroll -= debit;
    }
  }
  const trial = [...accountNet.entries()].filter(([, n]) => n !== 0).map(([account, n]) => ({ account, debit: Math.max(n, 0), credit: Math.max(-n, 0) }));
  const debitTotal = trial.reduce((sum, row) => sum + row.debit, 0);
  const creditTotal = trial.reduce((sum, row) => sum + row.credit, 0);
  if (!Number.isSafeInteger(debitTotal) || !Number.isSafeInteger(creditTotal) || !Number.isSafeInteger(payroll)) return fail('The journal exceeds supported cent precision.', 422);
  const netOf = (accounts: string[]) => accounts.reduce((sum, code) => sum + (accountNet.get(code) ?? 0), 0);
  return {
    hash: seal([entity.id, entity.code, entity.currency, entity.sector, period, rows]),
    periodLines, foreignLines, unbalanced: [...documents.values()].filter((n) => n !== 0).length + invalid,
    trial, anchors: {
      bank: trial.filter((row) => /^10\d{4}$/.test(row.account)).reduce((n, row) => n + row.debit - row.credit, 0),
      receivables: netOf(['110000', '111000', '112000']), payables: -netOf(['200000']),
      inventory: netOf(['120000', '121000', '122000', '123000', '124000']), payroll,
      tax: -netOf(['125000', '206000', '206100', '207000', '209000', '212000', '220000', '221000', '223000', '224000', '227000', '228000']),
    },
  };
}

const fingerprint = (work: CutoverWork, ledger: CloseLedger, evidence: CloseEvidence[]) => seal([work, ledger.hash, evidence.map((file) => [file.id, file.key, file.sha256])]);
function packetBlockers(work: CutoverWork, ledger: CloseLedger, evidence: CloseEvidence[], period: string) {
  const errors: string[] = [];
  if (periodEnd(period) >= new Date().toISOString().slice(0, 10)) errors.push('The full pilot month must finish before it can be submitted.');
  if (work.reference.length < 3 || work.notes.length < 20) errors.push('Enter the legacy system reference and describe the full-month scope (at least 20 characters).');
  if (!ledger.periodLines) errors.push('There are no posted functional-currency journal lines in this month.');
  if (ledger.foreignLines) errors.push('Untranslated historical currency lines exist. Resolve them through the supported historical conversion process before sign-off.');
  if (ledger.unbalanced) errors.push(`${ledger.unbalanced} journal documents or lines failed the date, currency or double-entry integrity checks.`);
  if (!work.legacyTrial || !evidence.some((f) => f.key === 'legacy_trial' && f.sha256 === work.legacyTrial?.sha256)) {
    errors.push('Import the signed-off legacy closing trial balance CSV.');
  } else {
    const comparison = compareTrial(ledger.trial, work.legacyTrial.entries);
    if (comparison.differences || comparison.bpzBalance || comparison.legacyBalance) errors.push(`The trial balances do not reconcile (${comparison.differences} account differences). Correct the underlying books or mapping.`);
  }
  for (const check of CLOSE_CHECKS) {
    const saved = work.checks[check.key] ?? EMPTY_CHECK;
    const state = controlResult(check, saved);
    if (!state.ready) errors.push(`${check.label}: enter complete, reconciled results and an evidence reference.`);
    if (check.kind === 'amount' && state.bpz !== ledger.anchors[check.key]) errors.push(`${check.label}: BPZ amount must tie to the posted control (${moneyDecimal(ledger.anchors[check.key] ?? 0)}).`);
    if (!(check.kind === 'optional' && saved.result === 'not_applicable') && !evidence.some((f) => f.key === check.key)) errors.push(`${check.label}: upload its supporting schedule or sign-off.`);
  }
  return errors;
}
function cleanWork(value: unknown, previous: CutoverWork): CutoverWork {
  const input = record(value);
  const supplied = record(input.checks ?? {});
  const checks: CutoverWork['checks'] = {};
  for (const { key } of CLOSE_CHECKS) {
    if (supplied[key] == null) continue;
    const row = record(supplied[key]);
    const result = row.result === 'verified' || row.result === 'not_applicable' ? row.result : 'pending';
    checks[key] = { reference: string(row.reference ?? '', 200), notes: string(row.notes ?? '', 1800),
      legacy: string(row.legacy ?? '', 24), bpz: string(row.bpz ?? '', 24), result } satisfies CloseCheck;
  }
  return { checks, reference: string(input.reference ?? '', 220), notes: string(input.notes ?? '', 2800), legacyTrial: previous.legacyTrial };
}
const actors = (row: Packet) => (Array.isArray(row.actors) ? row.actors : []).filter((v): v is string => typeof v === 'string');
const mayPrepare = (user: UserAccount) => user.role !== 'auditor' && user.permissions?.parallelCloseReviewOnly !== true;
const mayReview = (user: UserAccount, row?: Packet) => !!row && user.role !== 'auditor' && (user.role === 'owner' || user.canCheck === true)
  && user.username !== row.preparedBy && user.username !== row.submittedBy && !actors(row).includes(user.username)
  && (process.env.BPZ_BOOTSTRAP_MODE !== 'production' || user.mfaEnabled === true);
const toPacket = (r: Packet): ClosePacket => ({ id: r.id, version: r.version, status: r.status as ClosePacket['status'],
  work: r.work as CutoverWork, preparedBy: r.preparedBy, submittedBy: r.submittedBy, reviewedBy: r.reviewedBy,
  reviewedAt: r.reviewedAt, reviewNotes: r.reviewNotes, activatedBy: r.activatedBy, activatedAt: r.activatedAt });

export async function getClose(user: UserAccount, id: number, period: string): Promise<CutoverView> {
  return db.transaction(async (tx) => {
    const entity = await loadEntity(tx, user, id);
    const row = await findPacket(tx, id, period);
    const ledger = await readLedger(tx, entity, period);
    const evidence = row ? await getFiles(tx, row.id) : [];
    const work = row ? row.work as CutoverWork : EMPTY_WORK;
    const gates = await readReleaseGates(tx, row?.reviewedHash && row.status !== 'submitted' ? row.reviewedAt : null);
    const [live] = await tx.select({ period: liveBooks.period }).from(liveBooks).where(eq(liveBooks.clientId, id));
    const trail = row ? await tx.select({ action: auditLog.action, actor: auditLog.username, at: auditLog.timestamp, detail: auditLog.details })
      .from(auditLog).where(and(eq(auditLog.clientId, id), eq(auditLog.target, target(period)), like(auditLog.action, 'PARALLEL%'))).orderBy(desc(auditLog.timestamp), desc(auditLog.id)).limit(60) : [];
    return { client: { id, name: entity.name, code: entity.code, sector: entity.sector, currency: entity.currency }, period,
      packet: row ? toPacket(row) : null, ledger, evidence, gates, blockers: packetBlockers(work, ledger, evidence, period),
      signoffStale: !!row?.reviewedHash && row.reviewedHash !== fingerprint(work, ledger, evidence),
      activePeriod: live?.period ?? null, permissions: { prepare: mayPrepare(user), review: mayReview(user, row), revise: !!row && (user.role === 'owner' || user.username === row.preparedBy || user.username === row.submittedBy), owner: user.role === 'owner' }, history: trail };
  }, { isolationLevel: 'repeatable read', accessMode: 'read only' });
}

function upload(input: Record<string, unknown>, key: EvidenceKey) {
  const name = string(input.name, 140).replace(/[\x00-\x1f\x7f/\\]/g, '_');
  const data = typeof input.data === 'string' ? input.data : '';
  if (!name || !data || data.length > Math.ceil(EVIDENCE_FILE_LIMIT / 3) * 4 || !/^[A-Za-z0-9+\/]+={0,2}$/.test(data) || data.length % 4) return fail('Select a supported evidence file no larger than 2 MB.');
  const bytes = Buffer.from(data, 'base64');
  if (!bytes.length || bytes.length > EVIDENCE_FILE_LIMIT) return fail('The file is empty or exceeds 2 MB.');
  let mime = '';
  if (/\.pdf$/i.test(name) && bytes.subarray(0, 5).toString() === '%PDF-') mime = 'application/pdf';
  else if (/\.png$/i.test(name) && bytes.subarray(0, 8).toString('hex') === '89504e470d0a1a0a') mime = 'image/png';
  else if (/\.jpe?g$/i.test(name) && bytes.subarray(0, 3).toString('hex') === 'ffd8ff') mime = 'image/jpeg';
  else if (/\.(txt|csv)$/i.test(name) && !bytes.includes(0) && !bytes.toString('utf8').includes('\ufffd')) mime = /\.csv$/i.test(name) ? 'text/csv' : 'text/plain';
  if (key === 'legacy_trial' && (mime !== 'text/csv' || bytes.length > TRIAL_FILE_LIMIT)) return fail('Import a UTF-8 trial balance CSV no larger than 384 KB.');
  if (!mime) return fail('Evidence must be a PDF, PNG, JPEG, UTF-8 CSV or text file.');
  return { name, mime, bytes, size: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
}

export async function getCloseFile(user: UserAccount, id: number, period: string, fileId: string) {
  return db.transaction(async (tx) => {
    await loadEntity(tx, user, id);
    const row = await findPacket(tx, id, period);
    if (!row) return fail('Evidence file not found.', 404);
    const [file] = await tx.select().from(parallelCloseFiles).where(and(eq(parallelCloseFiles.id, fileId), eq(parallelCloseFiles.closeId, row.id))).limit(1);
    return file ?? fail('Evidence file not found.', 404);
  }, { accessMode: 'read only' });
}

async function audit(tx: Tx, id: number, period: string, actor: UserAccount, action: string, detail: string) {
  await tx.insert(auditLog).values({ id: randomUUID(), timestamp: new Date().toISOString(), userId: actor.username,
    username: actor.username, action: `PARALLEL_${action}`, target: target(period), details: detail, clientId: id });
}

export async function changeClose(user: UserAccount, id: number, period: string, raw: unknown) {
  const input = record(raw);
  const action = string(input.action, 32);
  if (user.role === 'auditor') return fail('This account is read-only.', 403);
  if (!mayPrepare(user) && !['approve', 'return'].includes(action)) return fail('The invited reviewer cannot prepare or change this close packet.', 403);
  const version = input.version;
  if (typeof version !== 'number' || !Number.isSafeInteger(version) || version < 0) return fail('Supply the packet version before saving.');
  const incoming = action === 'upload' ? { key: keyOf(input.key), file: upload(input, keyOf(input.key)) } : null;
  await db.transaction(async (tx) => {
    // Same lock used for ledger posting, state sync and production/trade posting.
    await tx.execute(sql`select pg_advisory_xact_lock(4027332)`);
    const entity = await loadEntity(tx, user, id);
    const row = await findPacket(tx, id, period);
    if (version !== (row?.version ?? 0)) return fail('Another user changed this close packet. Refresh and review the latest version.', 409);
    if (!row) {
      if (action !== 'save') return fail('Save a draft before uploading or submitting.', 409);
      await tx.insert(parallelCloses).values({ id: randomUUID(), clientId: id, period, status: 'draft', version: 1,
        work: cleanWork(input.work, EMPTY_WORK), preparedBy: user.username, actors: [user.username] });
      await audit(tx, id, period, user, 'CREATED', 'Parallel close draft created.');
      return;
    }
    const work = row.work as CutoverWork;
    const editActors = [...new Set([...actors(row), user.username])];
    const update = async (changes: Partial<typeof parallelCloses.$inferInsert>) => {
      await tx.update(parallelCloses).set({ ...changes, version: row.version + 1, updatedAt: new Date() }).where(eq(parallelCloses.id, row.id));
    };
    if (action === 'save' || action === 'upload' || action === 'remove') {
      if (!editable(row)) return fail('Submitted and signed packets are locked. Withdraw or reopen before editing.', 409);
      if (action === 'save') {
        await update({ work: cleanWork(input.work, work), actors: editActors });
        await audit(tx, id, period, user, 'SAVED', `Workpaper saved, version ${row.version + 1}.`);
      } else if (incoming) {
        const evidence = await getFiles(tx, row.id);
        const file = incoming.file;
        const key = incoming.key;
        const old = key === 'legacy_trial' ? evidence.find((f) => f.key === key) : null;
        if (evidence.some((f) => f.key === key && f.sha256 === file.sha256)) return fail('This evidence is already attached.', 409);
        if (evidence.length - Number(!!old) >= 24) return fail('A packet can have at most 24 evidence files.', 409);
        let nextWork = work;
        if (key === 'legacy_trial') {
          try { nextWork = { ...work, legacyTrial: { fileName: file.name, sha256: file.sha256, entries: parseLegacyTrial(file.bytes.toString('utf8'), entity.currency.toUpperCase()) } }; }
          catch (err) { return fail(err instanceof Error ? err.message : 'The trial balance could not be read.'); }
          if (old) await tx.delete(parallelCloseFiles).where(eq(parallelCloseFiles.id, old.id));
        }
        await tx.insert(parallelCloseFiles).values({ ...file, id: randomUUID(), closeId: row.id, checkKey: key, actor: user.username });
        await update({ work: nextWork, actors: editActors });
        await audit(tx, id, period, user, 'EVIDENCE', `Added ${key} evidence, SHA-256 ${file.sha256}${old ? `; replaced ${old.sha256}` : ''}.`);
      } else {
        const fileId = string(input.fileId, 80);
        const [removed] = await tx.delete(parallelCloseFiles).where(and(eq(parallelCloseFiles.id, fileId), eq(parallelCloseFiles.closeId, row.id))).returning({ key: parallelCloseFiles.checkKey, sha: parallelCloseFiles.sha256 });
        if (!removed) return fail('Evidence file not found.', 404);
        await update({ work: removed.key === 'legacy_trial' ? { ...work, legacyTrial: null } : work, actors: editActors });
        await audit(tx, id, period, user, 'EVIDENCE_REMOVED', `Removed draft evidence ${removed.key}, SHA-256 ${removed.sha}.`);
      }
      return;
    }
    if (action === 'withdraw' || action === 'reopen') {
      if (!(user.role === 'owner' || user.username === row.submittedBy || user.username === row.preparedBy)) return fail('Only the preparer, submitter or owner can revise this packet.', 403);
      if (!(action === 'withdraw' && row.status === 'submitted' || action === 'reopen' && row.status === 'approved')) return fail('This packet cannot be revised in its current state.', 409);
      const reason = string(input.reason ?? '', 1500);
      if (reason.length < 10) return fail('Document the reason for revision in at least 10 characters.');
      await update({ status: 'returned', submittedBy: null, reviewedHash: null, reviewedBy: null, reviewedAt: null, reviewNotes: reason });
      await audit(tx, id, period, user, 'REVISED', reason);
      return;
    }
    if (action === 'return' || action === 'approve') {
      if (row.status !== 'submitted') return fail('Only submitted packets can be reviewed.', 409);
      if (!mayReview(user, row)) return fail('An independent authorized checker who did not contribute to this packet must review it.', 403);
    }
    if (action === 'return') {
      const notes = string(input.reason ?? '', 1500);
      if (notes.length < 10) return fail('Explain the required corrections in at least 10 characters.');
      await update({ status: 'returned', reviewNotes: notes, reviewedBy: user.username, reviewedAt: new Date().toISOString(), reviewedHash: null });
      await audit(tx, id, period, user, 'RETURNED', notes);
      return;
    }
    if (!['submit', 'approve', 'activate'].includes(action)) return fail('Unknown close action.');
    if (action === 'submit' && !editable(row)) return fail('Only an editable draft can be submitted.', 409);
      if (action === 'activate' && (user.role !== 'owner' || user.mfaEnabled !== true)) return fail('Only the MFA-enrolled firm owner can designate the live books.', 403);
    if (action === 'activate' && row.status !== 'approved') return fail('Independent sign-off is required before go-live.', 409);
    const ledger = await readLedger(tx, entity, period);
    const files = await getFiles(tx, row.id);
    const current = fingerprint(work, ledger, files);
    if (action !== 'submit' && row.reviewedHash !== current) return fail('The ledger or evidence changed. Revise, reconcile and submit the packet again.', 409);
    const blockers = packetBlockers(work, ledger, files, period);
    if (blockers.length) return fail(blockers.slice(0, 4).join(' '), 409);
    if (action === 'submit') {
      await update({ status: 'submitted', actors: editActors, submittedBy: user.username, reviewedHash: current, reviewedBy: null, reviewedAt: null, reviewNotes: null });
      await audit(tx, id, period, user, 'SUBMITTED', `Submitted version ${row.version + 1}; reconciled ledger and evidence seal ${current}.`);
      return;
    }
    if (action === 'approve') {
      const notes = string(input.reason ?? '', 1500);
      if (notes.length < 15 || input.confirm !== true) return fail('Confirm source evidence review and record sign-off notes (at least 15 characters).');
      await update({ status: 'approved', reviewedBy: user.username, reviewedAt: new Date().toISOString(), reviewNotes: notes });
      await audit(tx, id, period, user, 'APPROVED', `Independent sign-off; seal ${current}. ${notes}`);
      return;
    }
    const gates = await readReleaseGates(tx, row?.reviewedHash && row.status !== 'submitted' ? row.reviewedAt : null);
    if (gates.some((gate) => !gate.passed)) return fail(`Go-live blocked: ${gates.filter((g) => !g.passed).map((g) => g.label).join(', ')}.`, 409);
    const confirmed = string(input.confirm ?? '', 24);
    const notes = string(input.reason ?? '', 1500);
    if (confirmed !== entity.code || notes.length < 15) return fail('Enter the exact workspace code and document your cutover decision.');
    const [already] = await tx.select().from(liveBooks).where(eq(liveBooks.clientId, id)).limit(1);
    if (already) return fail(`This workspace was already designated live at the ${already.period} close.`, 409);
    const at = new Date().toISOString();
    await tx.insert(liveBooks).values({ clientId: id, closeId: row.id, period, activatedBy: user.username, activatedAt: at });
    await tx.insert(closedPeriods).values({ clientId: id, period, closedBy: user.username, closedAt: at })
      .onConflictDoNothing({ target: [closedPeriods.clientId, closedPeriods.period] });
    await tx.insert(systemSettings).values({ key: 'workspace_state_revision', value: { revision: 1 } }).onConflictDoUpdate({
      target: systemSettings.key, set: { value: sql`jsonb_build_object('revision', coalesce((${systemSettings.value}->>'revision')::integer, 0) + 1)`, updatedAt: new Date() },
    });
    await update({ status: 'active', activatedAt: at, activatedBy: user.username });
    await audit(tx, id, period, user, 'LIVE_BOOKS', `Designated live; postings through ${period} frozen. Reviewed seal ${current}. ${notes}`);
  });
}
