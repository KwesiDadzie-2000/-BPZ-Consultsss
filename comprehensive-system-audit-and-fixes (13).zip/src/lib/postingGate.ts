import { eq, inArray } from "drizzle-orm";
import type { db as Db } from "@/db";
import { clients, closedPeriods, users } from "@/db/schema";
import {
  functionalCurrencyMap,
  validateFunctionalCurrency,
  validateMakerChecker,
  validatePostingIdentity,
  type PostingUserRecord,
} from "@/lib/journalValidation";
import { postingUserDirectory, sessionPostingRecord } from "@/lib/postingControls";
import type { ACDOCALine, UserAccount } from "@/types/accounting";

/**
 * THE POSTING GATE — one place every server-side write must pass through.
 *
 * WHY THIS EXISTS
 * ---------------
 * The system advertises three guarantees to clients and auditors:
 *   1. a CLOSED PERIOD cannot receive postings (period lock),
 *   2. a document above a user's MAKER LIMIT needs an independent checker,
 *   3. no user can post as somebody else (posting identity).
 *
 * The original browser-authoritative path enforced all three. When the new
 * server-authoritative write paths (registers, migration, public API) were added,
 * they called `validateJournalLines` only — with an EMPTY closed-period set and
 * with no maker-checker call at all. That silently re-opened the very holes the
 * system claims to close: a closed month could be posted into, and a user with a
 * 25,000 limit could post 5,000,000 through the API. This module closes that
 * permanently by making the controls impossible to forget: there is exactly one
 * function to call, and it fails closed if anything cannot be verified.
 *
 * CONTRACT
 * --------
 * `enforcePostingControls` returns `null` when the batch may post, or an
 * operator-readable refusal string. Callers MUST treat a non-null result as a
 * refusal and write nothing. It never throws for a control failure (that is a
 * refusal, not a fault), and it fails CLOSED on infrastructure errors — a gate
 * that cannot verify the period lock must not allow the posting.
 */
type Executor = Pick<typeof Db, "select">;

export interface PostingActor {
  /** The authenticated user, or a service identity for machine writes. */
  username: string;
  /** Posting threshold in major units of the entity's functional currency. */
  makerLimit: number;
  /** True when this actor can independently check another person's document. */
  canCheck?: boolean;
  /** Set for machine writes: the credential that is posting. */
  serviceCredential?: string;
}

export interface GateInput {
  actor: PostingActor;
  lines: readonly ACDOCALine[];
  /** Full user record when the actor is an interactive session user. */
  sessionUser?: UserAccount;
  /**
   * When false, maker-checker is skipped because the caller has ALREADY proven
   * independent approval through a separate workflow (e.g. an approved approval
   * request). Defaults to true — omitting it does not disable the control.
   */
  enforceMakerChecker?: boolean;
}

export async function enforcePostingControls(exec: Executor, input: GateInput): Promise<string | null> {
  const lines = [...input.lines];
  if (!lines.length) return "A posting batch must contain at least one line.";

  const clientIds = [...new Set(lines.map((l) => l.clientId))];
  if (!clientIds.length || clientIds.some((id) => !Number.isSafeInteger(id) || id <= 0)) {
    return "A posting must belong to a valid entity.";
  }

  let entities: { id: number; currency: string }[];
  let closed: { clientId: number; period: string }[];
  let userRows: (typeof users.$inferSelect)[];
  try {
    [entities, closed, userRows] = await Promise.all([
      exec.select({ id: clients.id, currency: clients.currency }).from(clients).where(inArray(clients.id, clientIds)),
      exec.select({ clientId: closedPeriods.clientId, period: closedPeriods.period }).from(closedPeriods).where(inArray(closedPeriods.clientId, clientIds)),
      exec.select().from(users),
    ]);
  } catch (error) {
    // Fail closed: if the lock state cannot be read, nothing may post.
    console.error("[posting-gate] control lookup failed", error);
    return "Posting controls could not be verified, so nothing was posted. Retry.";
  }

  if (entities.length !== clientIds.length) return "A posting references an entity that does not exist.";

  // ── 1. Closed periods (IAS-style period lock) ─────────────────────────────
  const locked = new Set(closed.map((row) => `${row.clientId}:${row.period}`));
  const frozen = lines.find((line) => locked.has(`${line.clientId}:${line.period}`));
  if (frozen) {
    return `Period ${frozen.period} is closed for this entity, so document ${frozen.docNo} cannot post. `
      + "Reopen the period in Month-End Close, or post in the next open period.";
  }

  // ── 2. Functional currency (IAS 21 — one currency per ledger) ─────────────
  const currencyError = validateFunctionalCurrency(lines, functionalCurrencyMap(entities));
  if (currencyError) return currencyError;

  // ── 3. Posting identity — nobody posts as somebody else ───────────────────
  const directory = postingUserDirectory(userRows);
  if (input.sessionUser) {
    const identityError = validatePostingIdentity(lines, {
      session: sessionPostingRecord(input.sessionUser),
      users: directory,
    });
    if (identityError) return identityError;
  } else {
    // Machine writes: the lines must be attributed to the service identity, and
    // a human `createdBy` on a machine posting would be a forged attribution.
    const forged = lines.find((line) => line.createdBy !== input.actor.username);
    if (forged) {
      return `A machine posting must be attributed to ${input.actor.username}, not "${forged.createdBy}".`;
    }
  }

  // ── 4. Maker–checker / posting limit ──────────────────────────────────────
  if (input.enforceMakerChecker !== false) {
    const makerError = validateMakerChecker(lines, {
      username: input.actor.username,
      makerLimit: input.actor.makerLimit,
      users: directoryWithService(directory, input.actor),
      functionalCurrencies: functionalCurrencyMap(entities),
    });
    if (makerError) {
      return input.actor.serviceCredential
        ? `${makerError} A machine credential cannot obtain independent approval: `
          + `raise the key's posting limit, or route the document through a signed-in user.`
        : makerError;
    }
  }

  return null;
}

/**
 * `validateMakerChecker` resolves the MAKER's own limit from the user directory.
 * A service credential is not an interactive user, so it is injected explicitly —
 * otherwise the lookup falls back to a limit of 0 and every API write would be
 * refused even when the key's limit allows it.
 */
function directoryWithService(
  directory: Map<string, PostingUserRecord>,
  actor: PostingActor,
): Map<string, PostingUserRecord> {
  if (!actor.serviceCredential) return directory;
  const merged = new Map(directory);
  merged.set(actor.username, {
    username: actor.username,
    role: "service",
    makerLimit: actor.makerLimit,
    canCheck: false,
    status: "active",
  } as PostingUserRecord);
  return merged;
}

/**
 * Convenience for interactive session writes: verify the session user may post a
 * batch of this size in this entity, with all controls applied.
 */
export async function enforceSessionPosting(
  exec: Executor,
  user: UserAccount,
  lines: readonly ACDOCALine[],
): Promise<string | null> {
  return enforcePostingControls(exec, {
    actor: { username: user.username, makerLimit: user.makerLimit, canCheck: user.canCheck },
    lines,
    sessionUser: user,
  });
}
