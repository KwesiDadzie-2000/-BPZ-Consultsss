import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  auditLog, businessPartners, chartAccounts, clients, journalHeaders, journalLines, postingEvents, salesInvoices, systemSettings,
} from "@/db/schema";
import { buildJournalHeader, buildPostingEvent } from "@/lib/journalPosting";
import { isValidIsoDate, validateJournalLines } from "@/lib/journalValidation";
import { enforcePostingControls, type PostingActor } from "@/lib/postingGate";
import type { UserAccount } from "@/types/accounting";
import type { ACDOCALine } from "@/types/accounting";

/**
 * Server-authoritative register writes — the architectural fix that removes the
 * browser-authoritative full-state sync as the source of truth for operational
 * registers. Every action runs in ONE database transaction: validate → journal +
 * header + posting event → register row → workspace_state_revision → audit log.
 */
type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

export class RegisterError extends Error {
  status: number;
  constructor(message: string, status = 409) { super(message); this.status = status; }
}

const id = (p: string) => `${p}-${crypto.randomUUID()}`;
const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

async function bumpRevision(tx: Tx): Promise<void> {
  const row = (await tx.select({ value: systemSettings.value }).from(systemSettings).where(eq(systemSettings.key, "workspace_state_revision")).limit(1))[0];
  const next = Number((row?.value as { revision?: number } | undefined)?.revision ?? 0) + 1;
  await tx.insert(systemSettings).values({ key: "workspace_state_revision", value: { revision: next } })
    .onConflictDoUpdate({ target: systemSettings.key, set: { value: { revision: next }, updatedAt: new Date() } });
}

async function postJournal(
  tx: Tx,
  actor: string,
  lines: ACDOCALine[],
  sessionUser?: UserAccount,
  serviceCredential?: string,
  serviceMakerLimit = 0,
): Promise<string> {
  const coa = await tx.select().from(chartAccounts);
  // THE GATE: closed periods, functional currency, posting identity and
  // maker-checker are enforced here for every register write. Skipping this is
  // what allowed a closed period to be posted into from the API.
  const gateError = await enforcePostingControls(tx, {
    actor: sessionUser
      ? { username: sessionUser.username, makerLimit: sessionUser.makerLimit, canCheck: sessionUser.canCheck, serviceCredential }
      : { username: actor, makerLimit: serviceMakerLimit, canCheck: false, serviceCredential: serviceCredential ?? 'service' },
    lines,
    sessionUser,
  });
  if (gateError) throw new RegisterError(gateError, 409);
  const err = validateJournalLines(lines, {
      allowedClientIds: [...new Set(lines.map((l) => l.clientId))],
      closedPeriodKeys: new Set(),
      coaAccountNos: new Set(coa.map((a) => a.accountNo)),
      isAccountPostable: (no) => coa.some((a) => a.accountNo === no && a.active),
    });
  if (err) throw new RegisterError(err);
  await tx.insert(journalLines).values(lines.map((line) => ({
    id: line.id, docNo: line.docNo, period: line.period, date: line.date, module: line.module, docType: line.docType,
    accountNo: line.accountNo, accountName: line.accountName, costCenter: line.costCenter ?? null,
    debit: line.debit, credit: line.credit, currency: line.currency, description: line.description,
    createdBy: line.createdBy, checkedBy: line.checkedBy ?? null, isReversed: line.isReversed ?? false,
    reference: line.reference ?? null, clientId: line.clientId,
  })));
  await tx.insert(journalHeaders).values(buildJournalHeader(lines)).onConflictDoNothing();
  await tx.insert(postingEvents).values(buildPostingEvent(lines, actor)).onConflictDoNothing();
  await tx.insert(auditLog).values({
    id: crypto.randomUUID(), timestamp: new Date().toISOString(), userId: actor, username: actor,
    action: "POST_JOURNAL", target: lines[0].docNo, details: `${lines.length} line(s) via register service`, clientId: lines[0].clientId,
  });
  return lines[0].docNo;
}

/** Register a customer or vendor with credit controls — validated server-side. */
export async function registerPartner(input: {
  clientId: number; code: string; name: string; type: "Vendor" | "Customer"; actor: string;
  tin?: string; email?: string; phone?: string; address?: string; currency?: string;
  creditLimit?: number; creditTermsDays?: number; paymentTerms?: string;
  creditStatus?: "Active" | "On Hold" | "Blocked"; openingBalance?: number;
}) {
  return db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(4027331)`);
    if (!input.name?.trim()) throw new RegisterError("A partner name is required.", 400);
    if (input.creditLimit != null && (!Number.isFinite(input.creditLimit) || input.creditLimit < 0)) throw new RegisterError("Credit limit must be a non-negative number.", 400);
    if (input.creditTermsDays != null && (!Number.isInteger(input.creditTermsDays) || input.creditTermsDays < 0 || input.creditTermsDays > 365)) throw new RegisterError("Credit terms must be 0–365 days.", 400);
    if (input.openingBalance != null && (!Number.isFinite(input.openingBalance) || input.openingBalance < 0)) throw new RegisterError("Opening balance must be non-negative.", 400);
    const code = (input.code || `${input.type === "Vendor" ? "V" : "C"}${Date.now() % 100000}`).toUpperCase();
    const dup = await tx.select({ id: businessPartners.id }).from(businessPartners)
      .where(and(eq(businessPartners.clientId, input.clientId), eq(businessPartners.code, code))).limit(1);
    if (dup.length) throw new RegisterError(`Partner code ${code} already exists in this entity.`);
    const partnerId = id("bp");
    await tx.insert(businessPartners).values({
      id: partnerId, sourceId: partnerId, clientId: input.clientId, code, name: input.name.trim(), type: input.type,
      tin: input.tin?.trim() ?? "", email: input.email?.trim() ?? "", phone: input.phone?.trim() ?? "",
      address: input.address?.trim() ?? "", currency: input.currency || "GHS",
      isVatWithholdingAgent: false, isCstApplicable: false, isTourismLevyApplicable: false,
      creditLimit: input.creditLimit ?? null, creditTermsDays: input.creditTermsDays ?? null,
      paymentTerms: input.paymentTerms ?? null, creditStatus: input.creditStatus ?? "Active",
      openingBalance: input.openingBalance ?? null,
    });
    await bumpRevision(tx);
    return { id: partnerId, code, name: input.name.trim() };
  });
}

/** Issue a sales invoice: journal + invoice register, atomically. */
export async function postSalesInvoice(input: {
  clientId: number; actor: string; customerName: string; revenueStream: string; revenueAccount?: string;
  date: string; netRevenue: number; vatOutput?: number; currency: string; costCenter?: string;
  /** Interactive user when posted from a session; omitted for machine writes. */
  sessionUser?: UserAccount;
  /** Identifier of the API key for machine writes, if any. */
  serviceCredential?: string;
  /** Posting threshold granted to that machine credential. */
  serviceMakerLimit?: number;
}) {
  if (!isValidIsoDate(input.date)) throw new RegisterError("Invoice date must be a valid YYYY-MM-DD.", 400);
  const net = r2(input.netRevenue);
  const vat = r2(input.vatOutput ?? 0);
  const gross = r2(net + vat);
  if (net <= 0 || gross <= 0) throw new RegisterError("Invoice net value must be positive.", 400);
  return db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(4027331)`);
    const docNo = id("INV-API");
    const period = input.date.slice(0, 7);
    const base = { docNo, period, date: input.date, module: "SD" as const, docType: "INV" as const, costCenter: input.costCenter || "CC-SLS", currency: input.currency, createdBy: input.actor, clientId: input.clientId };
    const lines: ACDOCALine[] = [
      { ...base, id: id("jl"), accountNo: "110000", accountName: `Trade Receivables (${input.customerName})`, debit: gross, credit: 0, description: `Sales invoice ${docNo}: ${input.revenueStream}` },
      { ...base, id: id("jl"), accountNo: input.revenueAccount || "400000", accountName: "Revenue", debit: 0, credit: net, description: `Revenue for ${docNo}` },
    ];
    if (vat > 0) lines.push({ ...base, id: id("jl"), accountNo: "220000", accountName: "VAT/NHIL/GETFund Output", debit: 0, credit: vat, description: `Output tax on ${docNo}` });
    await postJournal(tx, input.actor, lines, input.sessionUser, input.serviceCredential, input.serviceMakerLimit);
    await tx.insert(salesInvoices).values({
      id: id("inv"), clientId: input.clientId, invNo: docNo, customerName: input.customerName,
      revenueStream: input.revenueStream, revenueAccount: input.revenueAccount ?? null,
      netRevenue: net, vatOutput: vat, totalReceivable: gross, paidAmount: 0, status: "Open", date: input.date,
    });
    await bumpRevision(tx);
    return { docNo, net, vat, gross };
  });
}
