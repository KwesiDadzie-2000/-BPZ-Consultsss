import { createHash } from 'node:crypto';
import { eq, inArray } from 'drizzle-orm';
import type { db } from '@/db';
import { systemSettings, users } from '@/db/schema';
import type { BackupStatus } from './backupService';
import type { ReleaseGate } from './parallelClose';
import { configuredWorkspaceOrigin } from './workspaceLink';

type ReleaseEnv = Readonly<Record<string, string | undefined>>;
export type ReleaseDb = Pick<typeof db, 'select' | 'insert'>;
export type WorkspaceProvenance = { mode: 'production'; installationId: string; provisionedAt: string };
export type HttpsProof = { scope: string; origin: string; verifiedAt: string };
export type RestoreProof = { scope: string; storage: string; sha256: string; verifiedAt: string; tables: number; rows: number };
export const HTTPS_PROOF_KEY = 'go_live_https_proof';
export const RESTORE_PROOF_KEY = 'go_live_restore_proof';

export const seal = (value: readonly unknown[]) => createHash('sha256').update(JSON.stringify(value)).digest('hex');
export const shaPattern = /^[a-f0-9]{64}$/i;

export function releaseScope(provenance: WorkspaceProvenance | undefined, env: ReleaseEnv = process.env) {
  const origin = configuredWorkspaceOrigin(env.BPZ_PUBLIC_ORIGIN);
  const id = env.BPZ_DEPLOYMENT_ID?.trim() ?? '';
  // A preview, an HTTP localhost origin, or an installation copied from demo is not a release target.
  const host = origin?.startsWith('https://') ? new URL(origin).hostname : '';
  const publicHost = /^(?:[a-z0-9-]+\.)+[a-z]{2,}$/i.test(host) && !/\.(?:local|localhost|test|invalid|example)$/i.test(host);
  const scope = env.BPZ_BOOTSTRAP_MODE === 'production' && provenance?.mode === 'production' && /^[a-f0-9-]{36}$/i.test(provenance.installationId ?? '')
    && origin && publicHost && /^[a-zA-Z0-9_-]{20,100}$/.test(id) && !/^(?:REPLACE_|CHANGE_|YOUR_)/i.test(id) ? seal([origin, id, provenance.installationId]) : null;
  return { origin: publicHost ? origin : null, scope };
}

export function backupStorageScope(env: ReleaseEnv = process.env): string | null {
  const bucket = env.S3_BUCKET?.trim();
  const region = env.S3_REGION?.trim();
  if (!bucket || !region || !env.S3_ACCESS_KEY_ID || !env.S3_SECRET_ACCESS_KEY) return null;
  const endpoint = env.S3_ENDPOINT?.trim() ?? '';
  if (endpoint) {
    try { const url = new URL(endpoint); if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) return null; }
    catch { return null; }
  }
  return seal([bucket, region, endpoint, (env.S3_PREFIX || 'bpz/').replace(/^\/+|\/+$/g, '')]);
}

const recent = (value: string | undefined, ms: number, now: number) => {
  const age = now - Date.parse(value ?? '');
  return Number.isFinite(age) && age >= -60_000 && age < ms;
};

export function evaluateReleaseGates(input: {
  provenance?: WorkspaceProvenance; https?: HttpsProof; restore?: RestoreProof; backup?: BackupStatus; ownerMfa: boolean; approvedAt?: string | null;
}, env: ReleaseEnv = process.env, now = Date.now()): ReleaseGate[] {
  const { scope, origin } = releaseScope(input.provenance, env);
  const storage = backupStorageScope(env);
  const https = input.https;
  const restore = input.restore;
  const routing = !!scope && https?.scope === scope && https?.origin === origin && recent(https.verifiedAt, 7 * 86_400_000, now);
  const mfa = input.ownerMfa && env.BPZ_ENFORCE_MFA_OWNER === 'true' && env.BPZ_ENFORCE_MFA_CHECKERS === 'true';
  const backup = input.backup;
  const backed = !!storage && env.BPZ_BACKUP_SCHEDULE_ENABLED === 'true' && env.BPZ_REQUIRE_OFFSITE_BACKUP === 'true'
    && backup?.offsite === 'uploaded' && backup.storageScope === storage && shaPattern.test(backup.sha256 ?? '')
    && recent(backup.lastSuccessAt, 30 * 3_600_000, now) && !backup.lastError
    && (!input.approvedAt || Date.parse(backup.snapshotAt ?? '') >= Date.parse(input.approvedAt));
  const restored = !!scope && !!storage && restore?.scope === scope && restore?.storage === storage && shaPattern.test(restore.sha256)
    && restore.tables > 0 && restore.rows > 0 && recent(restore.verifiedAt, 30 * 86_400_000, now);
  return [
    { key: 'deployment', label: 'Production workspace', passed: !!scope, detail: scope ? origin! : 'A production-provisioned database, deployment ID and stable HTTPS domain are required.' },
    { key: 'https', label: 'Verified public HTTPS', passed: routing, detail: routing ? `Verified ${https!.verifiedAt.slice(0, 10)}` : 'Run the HTTPS deployment verifier from the production installation (valid for 7 days).' },
    { key: 'owner_mfa', label: 'Owner activated with MFA', passed: mfa, detail: mfa ? 'Owner and checker MFA policy enabled' : 'Activate the owner, enroll an authenticator and enforce MFA for owners and checkers.' },
    { key: 'backup', label: 'Recent off-site snapshot', passed: backed, detail: backed ? `Uploaded ${backup!.lastSuccessAt!.slice(0, 10)}` : input.approvedAt ? 'Create a fresh off-site snapshot after the independent sign-off (must be within 30 hours).' : 'Require scheduled off-site backups to HTTPS storage and upload a successful snapshot within 30 hours.' },
    { key: 'restore', label: 'Off-site restore verified', passed: restored, detail: restored ? `${restore!.tables} tables and ${restore!.rows} rows verified ${restore!.verifiedAt.slice(0, 10)}` : 'Download and restore the snapshot to the disposable recovery database, then verify row contents (valid for 30 days).' },
  ];
}

export async function getProvenance(exec: ReleaseDb) {
  const [row] = await exec.select({ value: systemSettings.value }).from(systemSettings).where(eq(systemSettings.key, 'workspace_provenance'));
  return row?.value as WorkspaceProvenance | undefined;
}

export async function readReleaseGates(exec: ReleaseDb, approvedAt?: string | null) {
  const rows = await exec.select({ key: systemSettings.key, value: systemSettings.value }).from(systemSettings)
    .where(inArray(systemSettings.key, ['workspace_provenance', HTTPS_PROOF_KEY, RESTORE_PROOF_KEY, 'backup_status']));
  const values = new Map(rows.map((r) => [r.key, r.value]));
  const owners = await exec.select({ enabled: users.mfaEnabled, activated: users.passwordHash, status: users.status }).from(users).where(eq(users.role, 'owner'));
  const active = owners.filter((u) => u.status === 'active');
  return evaluateReleaseGates({ provenance: values.get('workspace_provenance') as WorkspaceProvenance | undefined,
    https: values.get(HTTPS_PROOF_KEY) as HttpsProof | undefined, restore: values.get(RESTORE_PROOF_KEY) as RestoreProof | undefined,
    backup: values.get('backup_status') as BackupStatus | undefined, approvedAt, ownerMfa: !!active.length && active.every((u) => u.enabled && !!u.activated) });
}

export async function writeReleaseProof(exec: ReleaseDb, key: typeof HTTPS_PROOF_KEY | typeof RESTORE_PROOF_KEY, value: HttpsProof | RestoreProof) {
  const now = new Date();
  await exec.insert(systemSettings).values({ key, value, updatedAt: now })
    .onConflictDoUpdate({ target: systemSettings.key, set: { value, updatedAt: now } });
}

/** Only the operator CLI calls this against its configured production origin. */
export async function verifyHttpsDeployment(origin: string, scope: string, request = fetch) {
  const opts: RequestInit = { redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(15_000) };
  const health = await request(`${origin}/api/health`, opts);
  const body = await health.json().catch(() => null);
  if (health.status !== 200 || body?.ok !== true || health.headers.get('x-bpz-deployment') !== scope) {
    throw new Error('Public HTTPS health did not identify this configured installation. Check DNS, certificates and reverse proxy before retrying.');
  }
  const home = await request(`${origin}/`, opts);
  if (home.status !== 200 || !/<title>BPZ Consult ERP<\/title>/i.test(await home.text())) throw new Error('The production sign-in page was not served over HTTPS.');
  return { scope, origin, verifiedAt: new Date().toISOString() } satisfies HttpsProof;
}
