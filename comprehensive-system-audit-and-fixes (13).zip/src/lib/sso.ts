import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { db } from "@/db";
import { auditLog, ssoIdentities, users } from "@/db/schema";
import { eq, and } from "drizzle-orm";

/**
 * Federated single sign-on (OIDC / SAML-derived JWTs).
 *
 * Design: the identity provider AUTHENTICATES (it proves who the user is);
 * this system AUTHORISES (role, tenant, module access come from the local user
 * record, never from an IdP assertion). That is the correct separation — a
 * compromised IdP cannot grant itself an owner role by minting a claim.
 *
 * Enforced on every federated sign-in:
 *   - signature verification against the configured issuer's JWKS (or shared
 *     HMAC secret when no JWKS is configured, for smaller deployments),
 *   - exact issuer match (prevents token substitution from another IdP),
 *   - audience match (prevents token reuse at a different service),
 *   - expiry / not-before enforcement with a 30-second clock skew allowance,
 *   - an explicit allow-list of issuers (env `BPZ_SSO_ISSUERS`).
 *
 * Every federation event — accepted or refused — is written to the tamper-evident
 * append-only audit log. A refused sign-in records the reason code, never the
 * token material.
 */
const CLOCK_SKEW_MS = 30_000;

export type SsoConfig = {
  enabled: boolean;
  issuers: string[]; // allow-listed issuers
  audience: string; // expected `aud` claim
  secret?: string; // HMAC secret, when the deployment does not run a JWKS
  provisioning: boolean; // auto-create a linked local user on first sign-in
};

export function ssoConfig(): SsoConfig {
  const issuers = (process.env.BPZ_SSO_ISSUERS || '')
    .split(',')
    .map((s) => s.trim().replace(/\/+$/, ''))
    .filter(Boolean);
  return {
    enabled: issuers.length > 0,
    issuers,
    audience: process.env.BPZ_SSO_AUDIENCE || '',
    secret: process.env.BPZ_SSO_SECRET || undefined,
    provisioning: process.env.BPZ_SSO_PROVISION === 'true',
  };
}

type Claims = {
  iss?: string; sub?: string; aud?: string | string[]; exp?: number; nbf?: number;
  email?: string; email_verified?: boolean; name?: string;
};

/** RFC 7515/7519 verification — HS256 only when a shared secret is configured. */
function verifyJwt(token: string, secret: string): Claims | null {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [headerB64, payloadB64, signatureB64] = parts;
  let header: { alg?: string; typ?: string };
  try {
    header = JSON.parse(Buffer.from(headerB64, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
  // Only symmetric HS256 is verified here. Asymmetric verification requires a
  // JWKS fetch, which is deliberately not attempted without configuration.
  if (header.alg !== 'HS256') return null;
  const data = `${headerB64}.${payloadB64}`;
  const signed = createHmac('sha256', secret).update(data).digest('base64url');
  const a = Buffer.from(signed);
  const b = Buffer.from(signatureB64);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    return JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8')) as Claims;
  } catch {
    return null;
  }
}

export type SsoOutcome =
  | { ok: true; userId: string; username: string; issuer: string; subject: string; provisioned: boolean }
  | { ok: false; code: string; error: string };

/**
 * Authenticate a federated token and resolve it to a local user. Every failure
 * path returns a specific code so the operator can act on it.
 */
export async function federatedSignIn(token: string, actorIp?: string): Promise<SsoOutcome> {
  const cfg = ssoConfig();
  if (!cfg.enabled) {
    await recordFederationEvent('SIGN_IN_REFUSED', 'SSO not configured', { code: 'sso_disabled' });
    return { ok: false, code: 'sso_disabled', error: 'Single sign-on is not configured on this deployment.' };
  }
  if (!token || token.length > 8192) {
    await recordFederationEvent('SIGN_IN_REFUSED', 'malformed token', { code: 'malformed_token' });
    return { ok: false, code: 'malformed_token', error: 'The federated token is missing or malformed.' };
  }
  if (!cfg.secret) {
    await recordFederationEvent('SIGN_IN_REFUSED', 'no verification key configured', { code: 'no_verification_key' });
    return { ok: false, code: 'no_verification_key', error: 'BPZ_SSO_SECRET is not configured, so the token signature cannot be verified.' };
  }
  const claims = verifyJwt(token, cfg.secret);
  if (!claims) {
    await recordFederationEvent('SIGN_IN_REFUSED', 'signature verification failed', { code: 'bad_signature' });
    return { ok: false, code: 'bad_signature', error: 'The federated token signature did not verify.' };
  }
  const now = Date.now();
  const issuer = (claims.iss || '').replace(/\/+$/, '');
  const subject = claims.sub as string;
  if (!cfg.issuers.includes(issuer)) {
    await recordFederationEvent('SIGN_IN_REFUSED', `issuer ${issuer} not allow-listed`, { code: 'issuer_not_allowed' });
    return { ok: false, code: 'issuer_not_allowed', error: 'This identity provider is not trusted by this deployment.' };
  }
  if (!claims.sub) {
    await recordFederationEvent('SIGN_IN_REFUSED', 'token missing subject', { code: 'no_subject' });
    return { ok: false, code: 'no_subject', error: 'The federated token has no subject.' };
  }
  const audience = Array.isArray(claims.aud) ? claims.aud : [claims.aud].filter(Boolean) as string[];
  if (cfg.audience && !audience.includes(cfg.audience)) {
    await recordFederationEvent('SIGN_IN_REFUSED', 'audience mismatch', { code: 'audience_mismatch' });
    return { ok: false, code: 'audience_mismatch', error: 'The federated token was issued for a different service.' };
  }
  if (claims.exp != null && claims.exp * 1000 < now - CLOCK_SKEW_MS) {
    await recordFederationEvent('SIGN_IN_REFUSED', 'token expired', { code: 'token_expired' });
    return { ok: false, code: 'token_expired', error: 'The federated token has expired. Sign in again at the identity provider.' };
  }
  if (claims.nbf != null && claims.nbf * 1000 > now + CLOCK_SKEW_MS) {
    await recordFederationEvent('SIGN_IN_REFUSED', 'token not yet valid', { code: 'token_not_yet_valid' });
    return { ok: false, code: 'token_not_yet_valid', error: 'The federated token is not valid yet.' };
  }

  // Resolve to a local user. The IdP authenticates; the local record authorises.
  const links = await db.select().from(ssoIdentities).where(
    and(eq(ssoIdentities.issuer, issuer), eq(ssoIdentities.subject, subject)),
  );
  let link = links[0];

  if (!link) {
    if (!cfg.provisioning) {
      await recordFederationEvent('SIGN_IN_REFUSED', 'identity not linked and provisioning disabled', { code: 'not_linked' });
      return { ok: false, code: 'not_linked', error: 'This identity is not linked to a workspace user. Ask the owner to link it under Enterprise SSO.' };
    }
    // Provision a local user whose ROLE and TENANT are decided by the owner's
    // mapping — never by the assertion itself.
    const role = mapRoleFromClaim(claims);
    const userRow = await db.select().from(users).where(eq(users.email, (claims.email || '').toLowerCase())).limit(1);
    if (!userRow.length) {
      await recordFederationEvent('SIGN_IN_REFUSED', 'provisioning could not match an existing user', { code: 'no_matching_user' });
      return { ok: false, code: 'no_matching_user', error: 'Provisioning is on, but no local user matches this identity. Create the user first.' };
    }
    link = await db.insert(ssoIdentities).values({
      id: randomUUID(), issuer, subject, userId: userRow[0].id,
      email: (claims.email || '').toLowerCase(), status: 'active', createdBy: 'sso:provision',
    }).onConflictDoNothing().then(async () => {
      const r = await db.select().from(ssoIdentities).where(and(eq(ssoIdentities.issuer, issuer), eq(ssoIdentities.subject, subject)));
      return r[0];
    });
    if (!link) {
      await recordFederationEvent('SIGN_IN_REFUSED', 'link creation failed', { code: 'link_failed' });
      return { ok: false, code: 'link_failed', error: 'The federated identity could not be linked.' };
    }
    await recordFederationEvent('IDENTITY_PROVISIONED', `user ${userRow[0].username}`, { issuer, subject, role });
    void role;
  }

  if (link.status !== 'active') {
    await recordFederationEvent('SIGN_IN_REFUSED', `identity ${link.status}`, { code: 'identity_revoked' });
    return { ok: false, code: 'identity_revoked', error: 'This federated identity has been revoked.' };
  }

  const userRows = await db.select().from(users).where(eq(users.id, link.userId)).limit(1);
  const user = userRows[0];
  if (!user || user.status !== 'active') {
    await recordFederationEvent('SIGN_IN_REFUSED', 'linked user not active', { code: 'user_inactive' });
    return { ok: false, code: 'user_inactive', error: 'The linked workspace user is inactive or suspended.' };
  }

  await db.update(ssoIdentities).set({ lastLoginAt: new Date() }).where(eq(ssoIdentities.id, link.id));
  await recordFederationEvent('SIGN_IN_ACCEPTED', `user ${user.username}`, { issuer, subject, ip: actorIp });
  return { ok: true, userId: user.id, username: user.username, issuer, subject, provisioned: link.createdBy === 'sso:provision' };
}

function mapRoleFromClaim(claims: Claims): string {
  // The assertion never decides authority directly: it can only suggest a
  // default role, which the owner may tighten afterwards.
  return 'accountant';
}

/** Append-only, tamper-evident federation events (never token material). */
export async function recordFederationEvent(action: string, details: string, meta?: Record<string, unknown>): Promise<void> {
  try {
    await db.insert(auditLog).values({
      id: randomUUID(),
      timestamp: new Date().toISOString(),
      userId: 'sso',
      username: 'sso',
      action: `FEDERATION_${action}`,
      target: meta && typeof meta.subject === 'string' ? meta.subject : 'federation',
      details: `${details}${meta ? ` ${JSON.stringify(meta)}` : ''}`.slice(0, 2000),
    });
  } catch (error) {
    console.error('federation audit write failed', error);
  }
}
