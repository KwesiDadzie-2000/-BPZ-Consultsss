import { sql } from "drizzle-orm";
import type { db as Db } from "@/db";
import {
  applyLedgerAuthority,
  deriveTreasuryLedger,
  round2,
  treasuryGlFor,
  type TreasuryRecord,
} from "@/lib/treasuryDerivation";

/**
 * The general ledger is the ONLY authority for treasury balances.
 *
 * A bank / cash / wallet record that owns its treasury GL account (one record
 * per entity · GL · currency) has its balance DERIVED from posted journals on
 * every read (bootstrap) and every write (state sync). A browser therefore can
 * no longer save a bank balance that disagrees with the ledger: a direct edit is
 * simply replaced by the ledger figure. Records that share a GL with another
 * record (legacy set-ups) keep their stored value and are flagged by the
 * Control Accounts desk.
 *
 * The derivation itself lives in `treasuryDerivation.ts` (pure, client-safe) so
 * that the browser and the database compute the figure from the same rules and
 * a workspace sync can never be refused merely because the two sides disagreed
 * about arithmetic.
 */
type Executor = Pick<typeof Db, "execute">;

export type { TreasuryRecord };
export { applyLedgerAuthority, deriveTreasuryLedger, treasuryGlFor, round2 };

/** Ledger balance of every treasury (10xxxx) GL, per entity and currency. */
export async function ledgerTreasuryBalances(exec: Executor, clientIds: number[]): Promise<Map<string, number>> {
  const map = new Map<string, number>();
  if (!clientIds.length) return map;
  const ids = clientIds.filter((n) => Number.isInteger(n)).join(",") || "-1";
  const res = await exec.execute<{ client_id: number; account_no: number | string; currency: string; bal: string | number }>(sql`
    select client_id, account_no, upper(currency) as currency, round(sum(debit - credit)::numeric, 2) as bal
      from journal_lines
     where account_no like '10%' and client_id in (${sql.raw(ids)})
     group by client_id, account_no, upper(currency)`);
  for (const r of res.rows) map.set(`${Number(r.client_id)}:${r.account_no}:${String(r.currency || "").toUpperCase()}`, round2(Number(r.bal)));
  return map;
}

/** Native FX cash is the historical native-currency GL plus linked, posted trade cash.
 * The trade journal is in functional currency, so it is not counted twice here.
 */
export async function resolveTreasuryBalances<T extends TreasuryRecord>(
  exec: Executor,
  rows: T[],
  currencies: readonly { id: number; currency: string }[],
): Promise<T[]> {
  const ledger = await ledgerTreasuryBalances(exec, currencies.map((c) => c.id));
  const home = new Map(currencies.map((c) => [c.id, c.currency.toUpperCase()]));
  const foreign = rows.filter((row) => row.id !== undefined && row.clientId != null && home.has(row.clientId) && home.get(row.clientId) !== row.currency.toUpperCase());
  if (foreign.length) {
    const ids = [...new Set(foreign.flatMap((b) => Number.isSafeInteger(b.id) ? [b.id!] : []))];
    if (ids.length) {
      const native = await exec.execute<{ id: number; client_id: number; currency: string; amount: string | number }>(sql`
        select m.bank_account_id as id, m.client_id, upper(m.currency) as currency,
               round(sum(m.amount)::numeric, 2) as amount
        from trade_cash_movements m
        where m.bank_account_id in (${sql.join(ids.map((id) => sql`${id}`), sql`, `)})
        group by m.bank_account_id, m.client_id, upper(m.currency)`);
      const nativeByBank = new Map(native.rows.map((m) => [`${m.client_id}:${m.id}:${m.currency}`, Number(m.amount)]));
      for (const bank of foreign) {
        const currency = bank.currency.toUpperCase();
        const key = `${bank.clientId}:${treasuryGlFor(bank)}:${currency}`;
        ledger.set(key, round2((ledger.get(key) ?? 0) + (nativeByBank.get(`${bank.clientId}:${bank.id}:${currency}`) ?? 0)));
      }
    }
  }
  return applyLedgerAuthority(rows, ledger);
}
