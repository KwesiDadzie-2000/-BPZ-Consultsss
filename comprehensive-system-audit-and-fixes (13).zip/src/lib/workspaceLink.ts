/** Client invitations must never store a disposable sandbox or reverse-proxy hostname. */
export function workspaceSignInPath(code: string): string {
  return `/?workspace=${encodeURIComponent(code)}`;
}

export function isSandboxHostname(hostname: string): boolean {
  return /(^|\.)e2b\.(app|dev)$/i.test(hostname);
}

/** Validate an explicitly set public origin; don't infer one from request headers. */
export function configuredWorkspaceOrigin(value: string | undefined): string | null {
  if (!value?.trim()) return null;
  try {
    const url = new URL(value.trim());
    const loopback = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
    if (!(url.protocol === 'https:' || (url.protocol === 'http:' && loopback))
      || url.username || url.password || url.pathname !== '/' || url.search || url.hash || isSandboxHostname(url.hostname)) return null;
    return url.origin;
  } catch { return null; }
}

export function workspaceInvitationUrl(code: string, configured: string | undefined): string {
  return `${configuredWorkspaceOrigin(configured) ?? ''}${workspaceSignInPath(code)}`;
}
