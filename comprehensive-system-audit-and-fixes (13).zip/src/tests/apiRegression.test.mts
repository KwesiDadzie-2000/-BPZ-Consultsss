import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import type { ACDOCALine } from '../types/accounting';

// This destructive fixture is deliberately restricted to a disposable local DB.
const url = process.env.BPZ_TEST_DATABASE_URL;
if (!url) throw new Error('Set BPZ_TEST_DATABASE_URL to the disposable local bpz_review_test database.');
const parsed = new URL(url);
if (!['localhost', '127.0.0.1'].includes(parsed.hostname) || parsed.pathname !== '/bpz_review_test') {
  throw new Error('Refusing to run against anything except a local bpz_review_test database.');
}
process.env.DATABASE_URL = url;
process.env.BPZ_SEED_PASSWORD_OWNER = `Review-${randomUUID()}!`;
process.env.BPZ_SEED_PASSWORD_DEMO = `Review-${randomUUID()}!`;

const { pool } = await import('../db');
await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
const login = await import('../app/api/auth/login/route');
const session = await import('../app/api/auth/session/route');
const logout = await import('../app/api/auth/logout/route');
const journal = await import('../app/api/journal/route');
const state = await import('../app/api/state/route');
const bootstrap = await import('../app/api/bootstrap/route');

type Handler = (request: Request) => Promise<Response>;
const call = (handler: Handler, method: string, body?: unknown, token?: string) => handler(new Request('http://localhost/api/test', {
  method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  ...(body === undefined ? {} : { body: JSON.stringify(body) }),
}));
let passed = 0;
let failed = 0;
async function check(title: string, action: () => Promise<void>) {
  try { await action(); passed++; console.log(`PASS ${title}`); }
  catch (error) { failed++; console.error(`FAIL ${title}`, error); }
}
const base: ACDOCALine = {
  id: '', docNo: '', period: '2026-10', date: '2026-10-29', module: 'FI', docType: 'JE',
  accountNo: '100000', accountName: 'Bank', debit: 100, credit: 0, currency: 'GHS',
  description: 'Isolated integration test', createdBy: 'owner', clientId: 2,
};
const pair = (docNo: string, overrides: Partial<ACDOCALine> = {}): ACDOCALine[] => [
  { ...base, ...overrides, docNo, id: `${docNo}-a` },
  { ...base, ...overrides, docNo, id: `${docNo}-b`, accountNo: '400000', debit: 0, credit: overrides.debit || 100 },
];
const auth = await call(login.POST, 'POST', { usernameOrEmail: 'owner', password: process.env.BPZ_SEED_PASSWORD_OWNER });
assert.equal(auth.status, 200, JSON.stringify(await auth.clone().json()));
const { token: owner } = await auth.json();
const demoResponse = await call(login.POST, 'POST', { usernameOrEmail: 'demo', password: process.env.BPZ_SEED_PASSWORD_DEMO });
const { token: demo } = await demoResponse.json();
const workspace = async (token = owner) => {
  const response = await call(bootstrap.GET, 'GET', undefined, token);
  assert.equal(response.status, 200);
  return (await response.json()).state;
};
const original = pair('INTEGRATION-001');

await check('configured server login creates a secure cookie', async () => {
  assert.match(auth.headers.get('set-cookie')!, /HttpOnly/);
  const response = await call(session.GET, 'GET', undefined, owner);
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.user.password, undefined); assert.equal(body.user.passwordHash, undefined);
});
await check('public legacy seed credentials no longer authenticate', async () => {
  assert.equal((await call(login.POST, 'POST', { usernameOrEmail: 'owner', password: 'BpzOwner2026!' })).status, 401);
});
await check('unauthenticated journal writes are rejected', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: original })).status, 401);
});
await check('balanced owner journal posts', async () => {
  const response = await call(journal.POST, 'POST', { lines: original }, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
});
await check('journal replay is idempotent', async () => {
  const response = await call(journal.POST, 'POST', { lines: original }, owner);
  assert.equal(response.status, 200); assert.equal((await response.json()).idempotent, true);
});
await check('same document with changed amounts is refused', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: original.map((line) => ({ ...line, debit: line.debit * 2, credit: line.credit * 2 })) }, owner)).status, 409);
});
await check('posting date and accounting period must agree', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: pair('INTEGRATION-DATE', { period: '2026-09' }) }, owner)).status, 409);
});
await check('maker cannot forge an authorised checker approval', async () => {
  const lines = pair('INTEGRATION-SPOOF', { createdBy: 'demo', checkedBy: 'checker_kofi', debit: 90000 });
  assert.equal((await call(journal.POST, 'POST', { lines }, demo)).status, 403);
});
await check('authenticated independent checker can post on behalf of maker', async () => {
  const lines = pair('INTEGRATION-APPROVED', { createdBy: 'demo', checkedBy: 'owner', debit: 90000 });
  const response = await call(journal.POST, 'POST', { lines }, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
});
await check('cross-tenant posting is blocked', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: pair('INTEGRATION-TENANT', { createdBy: 'demo', clientId: 3 }) }, demo)).status, 403);
});
await check('unchanged full-state sync succeeds', async () => {
  const response = await call(state.PUT, 'PUT', await workspace(), owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
});
await check('sync cannot modify posted journal amounts', async () => {
  const snapshot = await workspace();
  snapshot.journalLines = snapshot.journalLines.map((line: ACDOCALine) => line.docNo === 'INTEGRATION-001' ? { ...line, debit: line.debit * 2, credit: line.credit * 2 } : line);
  assert.equal((await call(state.PUT, 'PUT', snapshot, owner)).status, 409);
  const persisted = (await workspace()).journalLines.find((line: ACDOCALine) => line.id === original[0].id);
  assert.equal(persisted.debit, 100);
});
await check('omitting journals from sync cannot delete them', async () => {
  const snapshot = await workspace(); const count = snapshot.journalLines.length;
  snapshot.journalLines = [];
  const response = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
  assert.equal((await workspace()).journalLines.length, count);
});
await check('direct PATCH cannot rewrite accounting history', async () => {
  assert.equal((await call(journal.PATCH, 'PATCH', { clientId: 2, docNo: original[0].docNo, lines: original }, owner)).status, 409);
});
await check('direct DELETE cannot erase accounting history', async () => {
  assert.equal((await call(journal.DELETE, 'DELETE', { clientId: 2, docNo: original[0].docNo }, owner)).status, 409);
});
await check('staff cannot change period locks through state sync', async () => {
  const snapshot = await workspace(demo); snapshot.closedPeriods.push({ clientId: 2, period: '2026-11' });
  const response = await call(state.PUT, 'PUT', snapshot, demo);
  assert.ok(response.status === 403 || response.status === 409, JSON.stringify(await response.json()));
});
await check('null state payload returns a controlled 400', async () => {
  assert.equal((await call(state.PUT, 'PUT', null, owner)).status, 400);
});
await check('an authenticated reviewer can persist a rejection decision', async () => {
  const snapshot = await workspace();
  const request = snapshot.approvalRequests.find((row: { status: string }) => row.status === 'pending');
  assert.ok(request);
  request.status = 'rejected'; request.reviewedBy = 'owner'; request.rejectionReason = 'Review regression';
  const response = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
  const stored = (await workspace()).approvalRequests.find((row: { id: string }) => row.id === request.id);
  assert.equal(stored.status, 'rejected'); assert.equal(stored.reviewedBy, 'owner');
});
await check('invalid journal payload returns a controlled 400', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: [null] }, owner)).status, 400);
});
await check('concurrent journal and stale state sync retain both documents', async () => {
  const snapshot = await workspace(); snapshot.journalLines.push(...pair('INTEGRATION-CONCURRENT-SYNC'));
  const responses = await Promise.all([
    call(state.PUT, 'PUT', snapshot, owner),
    call(journal.POST, 'POST', { lines: pair('INTEGRATION-CONCURRENT-POST') }, owner),
  ]);
  for (const response of responses) assert.equal(response.status, 200, JSON.stringify(await response.json()));
  const posted = (await workspace()).journalLines;
  assert.equal(posted.filter((line: ACDOCALine) => line.docNo.startsWith('INTEGRATION-CONCURRENT')).length, 4);
});
await check('an unversioned browser snapshot is rejected without touching the books', async () => {
  const snapshot = await workspace();
  delete snapshot.stateRevision;
  assert.equal((await call(state.PUT, 'PUT', snapshot, owner)).status, 428);
});
await check('a second tab with a stale revision cannot overwrite the first tab', async () => {
  const first = await workspace();
  const second = await workspace();
  const ok = await call(state.PUT, 'PUT', first, owner);
  assert.equal(ok.status, 200, JSON.stringify(await ok.json()));
  second.salesInvoices[0].paidAmount = second.salesInvoices[0].totalReceivable;
  const stale = await call(state.PUT, 'PUT', second, owner);
  assert.equal(stale.status, 409);
  assert.match(JSON.stringify(await stale.json()), /revision/);
});
await check('quick bill and goods invoice fields survive two snapshot round trips', async () => {
  const snapshot = await workspace();
  snapshot.journalLines = [];
  const po = { ...snapshot.purchaseOrders[0], id: 'AUDIT-BILL-FIELDS', poNo: 'AUDIT-BILL-FIELDS', status: 'Open', paidAmount: 0, itemCode: 'AUDIT-ITEM', inwardFreight: 41.25 };
  const fields = { revenueAccount: '402000', revenueAccountName: 'Merchandise', itemType: 'goods', itemCode: 'AUDIT-ITEM', quantity: 2.5,
    unitSellingPrice: 90, unitCost: 35, cogsAmount: 87.5, returnToStock: false };
  const invoice = { ...snapshot.salesInvoices[0], ...fields, id: 'AUDIT-SALE-FIELDS', invNo: 'AUDIT-SALE-FIELDS', status: 'Draft', paidAmount: 0 };
  snapshot.purchaseOrders.push(po);
  snapshot.salesInvoices.push(invoice);
  const saved = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(saved.status, 200, JSON.stringify(await saved.clone().json()));
  const second = await workspace();
  second.journalLines = [];
  assert.equal((await call(state.PUT, 'PUT', second, owner)).status, 200);
  const reloaded = await workspace();
  assert.equal(reloaded.purchaseOrders.find((row: typeof po) => row.id === po.id).itemCode, po.itemCode);
  assert.equal(reloaded.purchaseOrders.find((row: typeof po) => row.id === po.id).inwardFreight, 41.25);
  const stored = reloaded.salesInvoices.find((row: typeof invoice) => row.id === invoice.id);
  for (const [key, value] of Object.entries(fields)) assert.equal(stored[key], value, key);
});
await check('a non-owner stale bank balance is corrected without refusing the workspace', async () => {
  const snapshot = await workspace(demo);
  snapshot.journalLines = [];
  const bank = snapshot.bankAccounts.find((row: { code: string }) => row.code === 'BNK-01');
  assert.ok(bank);
  const actual = bank.balance;
  bank.balance = 20_000;
  const response = await call(state.PUT, 'PUT', snapshot, demo);
  assert.equal(response.status, 200, JSON.stringify(await response.clone().json()));
  assert.ok((await response.json()).warnings.some((msg: string) => msg.includes('BNK-01')));
  assert.equal((await workspace(demo)).bankAccounts.find((row: { id: number }) => row.id === bank.id).balance, actual);
});
await check('malformed snapshot arrays report 400 and leave the revision unchanged', async () => {
  const snapshot = await workspace();
  for (const input of [{ ...snapshot, bankAccounts: [null] }, { ...snapshot, stockItems: 'not an array' }, { ...snapshot, companyProfiles: { '2': null } }]) {
    assert.equal((await call(state.PUT, 'PUT', input, owner)).status, 400);
  }
  assert.equal((await workspace()).stateRevision, snapshot.stateRevision);
});

const trade = await import('../app/api/trade/route');
const tradeRequest = async (action: string, body: Record<string, unknown>, expected = 200) => {
  const response = await call(trade.POST, 'POST', { action, clientId: 2, idempotencyKey: randomUUID(), date: '2026-10-29', ...body }, owner);
  const json = await response.json();
  assert.equal(response.status, expected, JSON.stringify(json));
  return json;
};
const loadTrade = async () => {
  const result = await trade.GET(new Request('http://localhost/api/trade?clientId=2', { headers: { Authorization: `Bearer ${owner}` } }));
  assert.equal(result.status, 200);
  return await result.json();
};
const tradeLine = async (docId: string) => (await loadTrade()).documents.find((doc: { id: string }) => doc.id === docId).lines[0].id as string;
const taxFree = { vatRate: 0, levyRate: 0 };
const draft = (docType: string, body: Record<string, unknown>, expected = 200) => tradeRequest('create_document', { docType, tax: taxFree, ...body }, expected);
const approve = async (doc: { documentId: string; version: number }) => tradeRequest('submit_document', { documentId: doc.documentId, expectedVersion: doc.version });
const postTrade = async (doc: { documentId: string; version: number }, expected = 200) => tradeRequest('post_document', { documentId: doc.documentId, expectedVersion: doc.version }, expected);
const tradeBank = async (currency = 'GHS') => (await workspace()).bankAccounts.find((bank: { clientId: number; currency: string; glAccount: string }) => bank.clientId === 2 && bank.currency === currency && bank.glAccount === (currency === 'GHS' ? '100000' : '101000'));

await check('trade supplier payment uses posted GL cash even when its stored bank cache is stale', async () => {
  const bank = await tradeBank(); assert.ok(bank.balance > 500);
  await pool.query('update bank_accounts set balance = 1 where id = $1', [bank.id]);
  const paid = await tradeRequest('create_payment', { paymentType: 'supplier_payment', partyName: 'Audit Supplier', bankAccountId: bank.id, amount: 100 });
  assert.ok(paid.journalNo);
  assert.equal((await tradeBank()).balance, bank.balance - 100);
  const cashbook = (await loadTrade()).bankAccounts.find((r: { id: number }) => r.id === bank.id);
  assert.equal(cashbook.balance, bank.balance - 100);
  await tradeRequest('reverse_payment', { paymentId: paid.paymentId, reason: 'Audit voucher' });
  assert.equal((await tradeBank()).balance, bank.balance);
});
await check('foreign trade receipts and reversals maintain native cash after bootstrap and sync', async () => {
  const bank = await tradeBank('USD'); assert.ok(bank);
  const receipt = await tradeRequest('create_payment', { paymentType: 'customer_advance', partyName: 'Audit Export Customer', bankAccountId: bank.id, currency: 'USD', exchangeRate: 12.5, amount: 100 });
  assert.equal((await tradeBank('USD')).balance, bank.balance + 100);
  const snapshot = await workspace(); snapshot.journalLines = [];
  assert.equal((await call(state.PUT, 'PUT', snapshot, owner)).status, 200);
  assert.equal((await tradeBank('USD')).balance, bank.balance + 100);
  await tradeRequest('reverse_payment', { paymentId: receipt.paymentId, reason: 'Native cash reversal regression' });
  assert.equal((await tradeBank('USD')).balance, bank.balance);
});
await check('sales order-to-cash posts service completion, invoice, and receipt atomically', async () => {
  const partyName = 'Audit Services Customer';
  const inv = await draft('sales_invoice', { partyName, data: { serviceEvidence: 'AUD-ACCEPTANCE' }, lines: [{ itemType: 'service', quantity: 1, unitPrice: 450, revenueAccount: '401000', description: 'Accept completed service', data: { serviceEvidence: 'AUD-ACCEPTANCE' } }] });
  const posted = await postTrade(await approve(inv));
  assert.equal(posted.status, 'Open');
  const bank = await tradeBank();
  await tradeRequest('create_payment', { paymentType: 'customer_receipt', partyName, bankAccountId: bank.id, amount: 450, allocations: [{ documentId: inv.documentId, amount: 450 }] });
  const settled = (await loadTrade()).documents.find((doc: { id: string }) => doc.id === inv.documentId);
  assert.equal(settled.status, 'Paid'); assert.equal(settled.openBalance, 0);
  assert.equal((await tradeBank()).balance, bank.balance + 450);
});
await check('posted credit limits are rechecked for service invoices, while ordinary registration stays intact', async () => {
  const snapshot = await workspace(); snapshot.journalLines = [];
  const name = 'Audit Credit Customer';
  snapshot.businessPartners.push({ id: 'AUDIT-CREDIT', clientId: 2, code: 'C-AUDIT', name, type: 'Customer', tin: '', email: '', phone: '', address: '', currency: 'GHS',
    isVatWithholdingAgent: false, isCstApplicable: false, isTourismLevyApplicable: false, creditLimit: 125, creditStatus: 'Active', creditTermsDays: 20 });
  const saved = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(saved.status, 200, JSON.stringify(await saved.json()));
  const make = (unitPrice: number) => draft('sales_invoice', { partyName: name, partyId: 'AUDIT-CREDIT', data: { serviceEvidence: 'ACCEPTED' },
    lines: [{ itemType: 'service', quantity: 1, unitPrice, revenueAccount: '401000', data: { serviceEvidence: 'ACCEPTED' } }] });
  const first = await make(100);
  await postTrade(await approve(first));
  const additional = await make(30);
  assert.match((await postTrade(await approve(additional), 409)).error, /Insufficient approved credit/);
  assert.equal((await workspace()).businessPartners.find((p: { id: string }) => p.id === 'AUDIT-CREDIT').creditTermsDays, 20);
});
await check('FX advance allocations clear AR at invoice rate and advances at receipt rate, including partial retries', async () => {
  const partyName = 'Audit FX Advance';
  const sale = await draft('sales_invoice', { partyName, currency: 'USD', exchangeRate: 12, data: { serviceEvidence: 'AUD-ACCEPT' },
    lines: [{ itemType: 'service', quantity: 1, unitPrice: 100, revenueAccount: '401000', data: { serviceEvidence: 'AUD-ACCEPT' } }] });
  await postTrade(await approve(sale));
  const bank = await tradeBank('USD');
  const advance = await tradeRequest('create_payment', { paymentType: 'customer_advance', partyName, currency: 'USD', exchangeRate: 13, bankAccountId: bank.id, amount: 100 });
  for (const amount of [40, 60]) await tradeRequest('allocate_source', { sourceType: 'payment', sourceId: advance.paymentId, allocations: [{ documentId: sale.documentId, amount }] });
  const result = (await loadTrade()).documents.find((doc: { id: string }) => doc.id === sale.documentId);
  assert.equal(result.openBalance, 0);
  const records = (await workspace()).journalLines.filter((line: ACDOCALine) => line.reference === advance.paymentNo);
  const net = (account: string) => records.filter((line: ACDOCALine) => line.accountNo === account).reduce((sum: number, line: ACDOCALine) => sum + line.debit - line.credit, 0);
  assert.equal(net('225000'), 0);
  assert.equal(net('110000'), -1200);
  assert.equal(net('491000'), -100);
  const reversed = await tradeRequest('reverse_payment', { paymentId: advance.paymentId, reason: 'Verify linked allocation reversal' });
  assert.equal((await tradeBank('USD')).balance, bank.balance);
  assert.equal((await loadTrade()).documents.find((doc: { id: string }) => doc.id === sale.documentId).openBalance, 100);
  await tradeRequest('reverse_payment', { paymentId: reversed.reversalId, reason: 'Already a reversal' }, 409);
});

await check('procure-to-pay caps linked invoice quantities and price-only credits preserve stock', async () => {
  const partyName = 'Audit Parts Vendor';
  const item = (await workspace()).stockItems.find((stock: { clientId: number; glAccount: string }) => stock.clientId === 2 && stock.glAccount === '120000');
  assert.ok(item); const itemCode = item.itemCode;
  const order = await approve(await draft('purchase_order', { partyName, lines: [{ itemType: 'stock', itemCode, description: 'Audit purchase', quantity: 4, unitPrice: 10, inventoryAccount: '120000' }] }));
  const poLine = await tradeLine(order.documentId);
  const receipt = await draft('goods_receipt', { partyName, sourceDocumentId: order.documentId, lines: [{ sourceLineId: poLine, quantity: 4 }] });
  await postTrade(await approve(receipt));
  const source = await tradeLine(receipt.documentId);
  const reversedParty = await draft('supplier_invoice', { partyName: 'Different Supplier', externalRef: 'AUD-WRONG-PARTY', lines: [{ sourceLineId: source, quantity: 1 }] }, 409);
  assert.match(reversedParty.error, /same trading party/);
  const excess = await draft('supplier_invoice', { partyName, externalRef: 'AUD-QTY-OVER', lines: [{ sourceLineId: source, quantity: 3 }, { sourceLineId: source, quantity: 2 }] });
  assert.match((await postTrade(await approve(excess), 409)).error, /source quantity/);
  const invoice = await draft('supplier_invoice', { partyName, externalRef: 'AUD-VALID-BILL', lines: [{ sourceLineId: source, quantity: 4 }] });
  await postTrade(await approve(invoice));
  const before = (await workspace()).stockItems.find((stock: { id: string }) => stock.id === item.id);
  const credit = await draft('supplier_credit_note', { partyName, sourceDocumentId: invoice.documentId, sourceRef: invoice.docNo,
    lines: [{ sourceLineId: await tradeLine(invoice.documentId), creditAmount: 7, data: { priceOnly: true } }] });
  await postTrade(await approve(credit));
  const after = (await workspace()).stockItems.find((stock: { id: string }) => stock.id === item.id);
  assert.deepEqual([after.quantityOnHand, after.totalValue], [before.quantityOnHand, before.totalValue]);
  assert.equal((await loadTrade()).documents.find((doc: { id: string }) => doc.id === invoice.documentId).openBalance, 33);
});

await check('a forged customer receipt cannot mark an invoice as paid', async () => {
  const snapshot = await workspace();
  const inv = snapshot.salesInvoices.find((i: { status: string }) => i.status === 'Open');
  assert.ok(inv);
  const original = inv.paidAmount;
  inv.paidAmount = inv.totalReceivable;
  inv.status = 'Paid';
  const response = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(response.status, 409, JSON.stringify(await response.clone().json()));
  assert.match(JSON.stringify(await response.json()), /posted settlement journals/);
  assert.equal((await workspace()).salesInvoices.find((i: { id: string }) => i.id === inv.id).paidAmount, original);
});
await check('a forged supplier settlement cannot mark a PO Paid', async () => {
  const snapshot = await workspace();
  const po = snapshot.purchaseOrders.find((p: { status: string }) => p.status === 'Invoiced');
  assert.ok(po);
  const original = po.paidAmount;
  po.paidAmount = po.totalAmount;
  po.status = 'Paid';
  const response = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(response.status, 409, JSON.stringify(await response.clone().json()));
  assert.equal((await workspace()).purchaseOrders.find((p: { id: string }) => p.id === po.id).paidAmount, original);
});
await check('inventories cannot be inflated or stock movements erased by browser sync', async () => {
  const snapshot = await workspace();
  assert.ok(snapshot.stockItems.length && snapshot.stockMovements.length);
  const id = snapshot.stockItems[0].id;
  const original = snapshot.stockItems[0].quantityOnHand;
  snapshot.stockItems[0].quantityOnHand = original + 500;
  assert.equal((await call(state.PUT, 'PUT', snapshot, owner)).status, 409);
  const erased = await workspace();
  erased.stockMovements = [];
  assert.equal((await call(state.PUT, 'PUT', erased, owner)).status, 409);
  assert.equal((await workspace()).stockItems.find((i: { id: string }) => i.id === id).quantityOnHand, original);
});
await check('a checker cannot approve a journal that was never posted', async () => {
  const makerSnapshot = await workspace(demo);
  const docNo = 'UNPOSTED-APPROVAL-CONTROL';
  const pending = {
    id: randomUUID(), clientId: 2, clientCode: 'CLI-001', clientName: 'Gold Coast Mines Ltd',
    docNo, docType: 'JE', amount: 100, requestedBy: 'John Boateng (demo)',
    requestedAt: new Date().toISOString(), description: 'Unposted journal approval test',
    reasonForApproval: 'Independent checker test', status: 'pending',
    payload: { lines: pair(docNo, { createdBy: 'demo' }) },
  };
  makerSnapshot.approvalRequests.push(pending);
  const queued = await call(state.PUT, 'PUT', makerSnapshot, demo);
  assert.equal(queued.status, 200, JSON.stringify(await queued.clone().json()));
  const checkerSnapshot = await workspace();
  const found = checkerSnapshot.approvalRequests.find((r: { id: string }) => r.id === pending.id);
  assert.ok(found);
  found.status = 'approved'; found.reviewedBy = 'owner';
  const response = await call(state.PUT, 'PUT', checkerSnapshot, owner);
  assert.equal(response.status, 409, JSON.stringify(await response.clone().json()));
  assert.match(JSON.stringify(await response.json()), /no posted journal/);
  assert.equal((await workspace()).approvalRequests.find((r: { id: string }) => r.id === pending.id).status, 'pending');
});
await check('a sales-only client cannot read payroll/treasury or delete those registers in a sync', async () => {
  await pool.query('UPDATE users SET permissions = $1 WHERE username = $2', [JSON.stringify({
    canPostJournals: true, canRunPayroll: false, allowedModules: ['sales'],
  }), 'demo']);
  const scoped = await workspace(demo);
  assert.ok(!scoped.bankAccounts.length && !scoped.employees.length && !scoped.payrollRecords.length);
  assert.ok(scoped.stockItems.length, 'sales may see stock available for sale');
  const bankCount = Number((await pool.query('select count(*) as n from bank_accounts where client_id=2')).rows[0].n);
  const employeeCount = Number((await pool.query('select count(*) as n from employees where client_id=2')).rows[0].n);
  const response = await call(state.PUT, 'PUT', scoped, demo);
  assert.equal(response.status, 200, JSON.stringify(await response.clone().json()));
  assert.equal(Number((await pool.query('select count(*) as n from bank_accounts where client_id=2')).rows[0].n), bankCount);
  assert.equal(Number((await pool.query('select count(*) as n from employees where client_id=2')).rows[0].n), employeeCount);
  const forged = await workspace(demo);
  forged.bankAccounts.push({ id: 9999, clientId: 2, code: 'EVIL', name: 'Forged', bankName: 'X', accountNo: '1', currency: 'GHS', balance: 1 });
  assert.equal((await call(state.PUT, 'PUT', forged, demo)).status, 403);
});
await check('sales-only trade users can read their desk but not banking, procurement or integration data', async () => {
  const req = (params: string) => new Request(`http://localhost/api/trade?clientId=2&${params}`, { headers: { Authorization: `Bearer ${demo}` } });
  const sales = await trade.GET(req('scope=o2c'));
  assert.equal(sales.status, 200);
  const data = await sales.json();
  assert.ok(!data.bankAccounts.length && !data.cashMovements.length);
  assert.equal((await trade.GET(req('scope=p2p'))).status, 403);
  assert.equal((await trade.GET(req('view=outbox'))).status, 403);
  assert.equal((await call(trade.POST, 'POST', { action: 'create_payment', clientId: 2, idempotencyKey: randomUUID(), paymentType: 'supplier_payment' }, demo)).status, 403);
});
await check('a foreign-currency journal is refused until translated', async () => {
  const usd = pair('INTEGRATION-FX-UNTRANSLATED').map((line) => ({ ...line, currency: 'USD' }));
  const response = await call(journal.POST, 'POST', { lines: usd }, owner);
  assert.equal(response.status, 409, JSON.stringify(await response.clone().json()));
  assert.match(JSON.stringify(await response.json()), /reports in GHS/);
  // The same document translated into the functional currency posts normally.
  const ghs = pair('INTEGRATION-FX-TRANSLATED').map((line) => ({ ...line, currency: 'GHS' }));
  assert.equal((await call(journal.POST, 'POST', { lines: ghs }, owner)).status, 200);
});
await check('supporting evidence is stored server-side, tenant-scoped and audited', async () => {
  const attachments = await import('../app/api/attachments/route');
  const request = (method: string, qs: string, body: unknown, token: string) => new Request(`http://localhost/api/attachments${qs}`, {
    method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const png = Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex').toString('base64');
  const upload = await attachments.POST(request('POST', '?clientId=2', {
    docId: 'INTEGRATION-001', docNo: 'INTEGRATION-001', name: 'delivery-note.png', mime: 'image/png', dataBase64: png,
  }, owner));
  assert.equal(upload.status, 201, JSON.stringify(await upload.clone().json()));
  const { id } = await upload.json();

  // The owner's upload is visible to a reviewer in a different browser session.
  const list = await attachments.GET(request('GET', '?clientId=2&docId=INTEGRATION-001', undefined, owner));
  const listed = await list.json();
  assert.equal(list.status, 200);
  assert.ok(listed.attachments.some((a: { id: string; name: string }) => a.id === id && a.name === 'delivery-note.png'));

  // The bytes come back intact, with a download-safe content type.
  const download = await attachments.GET(request('GET', `?clientId=2&id=${id}`, undefined, owner));
  assert.equal(download.status, 200);
  assert.equal(download.headers.get('content-type'), 'image/png');
  assert.ok((await download.arrayBuffer()).byteLength > 8);

  // Another tenant cannot read it, and a mismatched entity id cannot reach it.
  assert.equal((await attachments.GET(request('GET', `?clientId=3&id=${id}`, undefined, demo))).status, 403);
  assert.equal((await attachments.GET(request('GET', `?clientId=3&docId=INTEGRATION-001`, undefined, demo))).status, 403);

  // Executables are refused as evidence.
  const bad = await attachments.POST(request('POST', '?clientId=2', {
    docId: 'INTEGRATION-001', docNo: 'INTEGRATION-001', name: 'payload.exe', mime: 'application/x-msdownload', dataBase64: png,
  }, owner));
  assert.equal(bad.status, 415);

  // Auditors may read evidence but never delete it.
  await pool.query("UPDATE users SET role='auditor' WHERE username='demo'");
  const auditRead = await attachments.GET(request('GET', '?clientId=2&docId=INTEGRATION-001', undefined, demo));
  assert.equal(auditRead.status, 200);
  const auditDelete = await attachments.DELETE(request('DELETE', `?clientId=2&id=${id}`, undefined, demo));
  assert.equal(auditDelete.status, 403);
  await pool.query("UPDATE users SET role='accountant' WHERE username='demo'");

  // The uploader/owner can remove it, and the removal is audited.
  assert.equal((await attachments.DELETE(request('DELETE', `?clientId=2&id=${id}`, undefined, owner))).status, 200);
  const after = await attachments.GET(request('GET', '?clientId=2&docId=INTEGRATION-001', undefined, owner));
  assert.ok(!(await after.json()).attachments.some((a: { id: string }) => a.id === id));
});
await check('distributed rate limiting is shared and exact under parallel requests', async () => {
  const { acquireDistributedRateLimit } = await import('../lib/distributedRateLimit');
  const key = `regression-${Date.now()}`;
  const results = await Promise.all(Array.from({ length: 12 }, () => acquireDistributedRateLimit(key, 3, 0)));
  assert.equal(results.filter((r) => r.allowed).length, 3, 'exactly three requests should acquire the shared bucket');
  assert.ok(results.some((r) => !r.allowed && r.retryAfterSeconds > 0));
});
await check('owner backup creation and read-only verification work, clients are refused', async () => {
  const backups = await import('../app/api/backups/route');
  const request = (method: string, body: unknown, token: string) => new Request('http://localhost/api/backups', {
    method, headers: { 'content-type': 'application/json', Authorization: `Bearer ${token}` },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const created = await backups.POST(request('POST', undefined, owner));
  assert.equal(created.status, 201, JSON.stringify(await created.clone().json()));
  const result = await created.json();
  assert.ok(result.file && result.tableCount > 0 && result.rowCount > 0);
  const verification = await backups.PUT(request('PUT', { file: result.file }, owner));
  assert.equal(verification.status, 200, JSON.stringify(await verification.clone().json()));
  assert.equal((await verification.json()).restored, false);
  const refused = await backups.POST(request('POST', undefined, demo));
  assert.equal(refused.status, 403);
});
await check('off-site S3 bytes and full disposable restore verify through the real S3 client', async () => {
  const http = await import('node:http');
  const { createBackup, downloadOffsiteBackup, readBackupFile } = await import('../lib/backupService');
  const { readFile } = await import('node:fs/promises');
  let captured = Buffer.alloc(0);
  let requestPath = '';
  const server = http.createServer((req, res) => {
    if (req.method === 'PUT') {
      requestPath = req.url || '';
      const chunks: Buffer[] = [];
      req.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
      req.on('end', () => { captured = Buffer.concat(chunks); res.writeHead(200); res.end(); });
    } else {
      res.writeHead(200, { 'content-type': 'application/gzip', 'content-length': String(captured.length) });
      res.end(captured);
    }
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  const address = server.address();
  if (!address || typeof address !== 'object') throw new Error('S3 stub did not bind');
  const previous = { ...process.env };
  try {
    process.env.S3_BUCKET = 'bpz-test-backups';
    process.env.S3_REGION = 'us-east-1';
    process.env.S3_ENDPOINT = `http://127.0.0.1:${address.port}`;
    process.env.S3_FORCE_PATH_STYLE = 'true';
    process.env.S3_ACCESS_KEY_ID = 'test';
    process.env.S3_SECRET_ACCESS_KEY = 'test';
    process.env.S3_PREFIX = 'bpz/';
    process.env.BPZ_REQUIRE_OFFSITE_BACKUP = 'true';
    process.env.BPZ_BACKUP_DIR = '/tmp/bpz-offsite-backup';
    const result = await createBackup();
    assert.equal(result.offsite, 'uploaded');
    assert.ok(requestPath.includes('/bpz-test-backups/bpz/'));
    assert.equal(captured[0], 0x1f);
    assert.equal(captured[1], 0x8b);
    await (await import('node:fs/promises')).rm('/tmp/bpz-offsite-restored.json.gz', { force: true });
    await downloadOffsiteBackup(result.offsiteUri!, '/tmp/bpz-offsite-restored.json.gz');
    const restored = await readFile('/tmp/bpz-offsite-restored.json.gz');
    assert.ok(restored.equals(captured));
    const payload = await readBackupFile('/tmp/bpz-offsite-restored.json.gz');
    assert.equal(payload.app, 'bpz-consult-erp');
    const { execFile } = await import('node:child_process');
    const { promisify } = await import('node:util');
    const proof = await promisify(execFile)(process.execPath, ['node_modules/tsx/dist/cli.mjs', 'scripts/verify-recovery.mts', '--offsite'], {
      env: { ...process.env, BPZ_BACKUP_SCHEDULE_ENABLED: 'false' }, timeout: 90_000,
    });
    assert.match(proof.stdout, /RECOVERY VERIFIED \(off-site download\): .* rows matched by count and content/);
    assert.match(proof.stdout, /No production go-live proof was recorded/);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    for (const key of ['S3_BUCKET','S3_REGION','S3_ENDPOINT','S3_FORCE_PATH_STYLE','S3_ACCESS_KEY_ID','S3_SECRET_ACCESS_KEY','S3_PREFIX','BPZ_REQUIRE_OFFSITE_BACKUP','BPZ_BACKUP_DIR']) {
      if (previous[key] === undefined) delete process.env[key]; else process.env[key] = previous[key];
    }
  }
});
await check('enforced owner MFA uses pending enrolment and then requires TOTP', async () => {
  const mfa = await import('../app/api/auth/mfa/route');
  const loginRoute = await import('../app/api/auth/login/route');
  const { totpAt } = await import('../lib/totp');
  process.env.BPZ_ENFORCE_MFA_OWNER = 'true';
  try {
    const begin = await mfa.POST(new Request('http://localhost/api/auth/mfa', {
      method: 'POST', headers: { 'content-type': 'application/json', Authorization: `Bearer ${owner}` }, body: JSON.stringify({ action: 'begin' }),
    }));
    const enrollment = await begin.json();
    assert.ok(enrollment.secret);
    const confirm = await mfa.POST(new Request('http://localhost/api/auth/mfa', {
      method: 'POST', headers: { 'content-type': 'application/json', Authorization: `Bearer ${owner}` }, body: JSON.stringify({ action: 'confirm', code: totpAt(enrollment.secret, Date.now()) }),
    }));
    assert.equal(confirm.status, 200, JSON.stringify(await confirm.clone().json()));
    const blocked = await loginRoute.POST(new Request('http://localhost/api/auth/login', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ usernameOrEmail: 'owner', password: process.env.BPZ_SEED_PASSWORD_OWNER }),
    }));
    assert.equal(blocked.status, 401);
    assert.equal((await blocked.json()).mfaRequired, true);
    const accepted = await loginRoute.POST(new Request('http://localhost/api/auth/login', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ usernameOrEmail: 'owner', password: process.env.BPZ_SEED_PASSWORD_OWNER, otp: totpAt(enrollment.secret, Date.now()) }),
    }));
    assert.equal(accepted.status, 200, JSON.stringify(await accepted.clone().json()));
  } finally {
    delete process.env.BPZ_ENFORCE_MFA_OWNER;
    await pool.query("update users set mfa_enabled = false, mfa_secret = null, mfa_pending_secret = null where username = 'owner'");
  }
});
await check('an unenrolled checker can enrol with a limited grant, never a workspace session', async () => {
  const mfa = await import('../app/api/auth/mfa/route');
  const loginRoute = await import('../app/api/auth/login/route');
  const { totpAt } = await import('../lib/totp');
  const checkerPassword = `Checker-${randomUUID()}!`;
  await pool.query("update users set password_hash = null, password_salt = null where username = 'checker_kofi'");
  const { hashPassword, newSalt } = await import('../lib/password');
  const checkerSalt = newSalt();
  await pool.query("update users set password_hash = $1, password_salt = $2 where username = 'checker_kofi'", [await hashPassword(checkerPassword, checkerSalt), checkerSalt]);
  process.env.BPZ_ENFORCE_MFA_CHECKERS = 'true';
  try {
    const blocked = await loginRoute.POST(new Request('http://localhost/api/auth/login', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ usernameOrEmail: 'checker_kofi', password: checkerPassword }),
    }));
    assert.equal(blocked.status, 401, JSON.stringify(await blocked.clone().json()));
    const challenge = await blocked.json();
    assert.ok(challenge.enrollToken && challenge.secret, 'a 15-minute enrolment grant must be issued');
    const journalResponse = await journal.POST(new Request('http://localhost/api/journal', {
      method: 'POST', headers: { 'content-type': 'application/json', Authorization: `Bearer ${challenge.enrollToken}` }, body: JSON.stringify({ lines: pair('MFA-GRANT-CANNOT-POST') }),
    }));
    assert.equal(journalResponse.status, 401, 'the enrolment grant must not act as a session');
    const confirmed = await mfa.POST(new Request('http://localhost/api/auth/mfa', {
      method: 'POST', headers: { 'content-type': 'application/json', Authorization: `Bearer ${challenge.enrollToken}` },
      body: JSON.stringify({ action: 'confirm', code: totpAt(challenge.secret, Date.now()) }),
    }));
    assert.equal(confirmed.status, 200, JSON.stringify(await confirmed.clone().json()));
    const accepted = await loginRoute.POST(new Request('http://localhost/api/auth/login', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ usernameOrEmail: 'checker_kofi', password: checkerPassword, otp: totpAt(challenge.secret, Date.now()) }),
    }));
    assert.equal(accepted.status, 200, JSON.stringify(await accepted.clone().json()));
  } finally {
    delete process.env.BPZ_ENFORCE_MFA_CHECKERS;
    await pool.query("update users set mfa_enabled = false, mfa_secret = null, mfa_pending_secret = null where username = 'checker_kofi'");
    await pool.query("delete from bpz_mfa_enrollments where user_id = 'checker_kofi'");
  }
});
await check('warehouse → supplier invoice → payment is atomic evidence, never an AP at receipt', async () => {
  const { buildReceiptJournal, buildSupplierInvoiceJournal } = await import('../utils/receiptAccounting');
  const { applyReceipt, buildMovement } = await import('../utils/trading');
  const before = await workspace();
  const stock = before.stockItems.find((item: { clientId: number; glAccount: string }) => item.clientId === 2 && item.glAccount === '120000');
  const vendor = before.businessPartners.find((partner: { clientId: number; type: string }) => partner.clientId === 2 && partner.type === 'Vendor');
  assert.ok(stock && vendor);
  const tag = randomUUID().slice(0, 8).toUpperCase();
  const po = { id: `REC-${tag}`, clientId: 2, poNo: `PO-WH-${tag}`, vendorName: vendor.name,
    itemType: 'material', itemDescription: stock.description, itemCode: stock.itemCode,
    qty: 2, unitPrice: 10, netAmount: 20, vatRecoverable: 4, totalAmount: 24,
    paidAmount: 0, status: 'Open', date: '2026-10-29', currency: 'GHS',
    glAccount: '120000', glAccountName: 'Inventories', costCenter: 'CC-OPS', costCenterName: 'Operations' };
  const created = await call(state.PUT, 'PUT', { ...before, purchaseOrders: [...before.purchaseOrders, po] }, owner);
  assert.equal(created.status, 200, JSON.stringify(await created.clone().json()));
  const context = { clientId: 2, currency: 'GHS', username: 'owner', date: '2026-10-29' };
  const receipt = buildReceiptJournal(po, context);
  const postedReceipt = await call(journal.POST, 'POST', { lines: receipt }, owner);
  assert.equal(postedReceipt.status, 200, JSON.stringify(await postedReceipt.clone().json()));
  const afterReceipt = await workspace();
  const result = applyReceipt(stock, 2, 10);
  assert.ok(!result.error);
  const movement = buildMovement({ clientId: 2, date: context.date, item: stock, type: 'Receipt', quantity: 2, unitCost: 10,
    totalValue: 20, docNo: po.poNo, reference: po.vendorName, note: 'Invoice pending' });
  const receiptRegister = await call(state.PUT, 'PUT', { ...afterReceipt,
    stockItems: afterReceipt.stockItems.map((item: { id: string }) => item.id === stock.id ? result.item : item),
    stockMovements: [...afterReceipt.stockMovements, movement],
    purchaseOrders: afterReceipt.purchaseOrders.map((order: { id: string }) => order.id === po.id ? { ...order, status: 'Goods Received' } : order) }, owner);
  assert.equal(receiptRegister.status, 200, JSON.stringify(await receiptRegister.clone().json()));
  const net = (account: string) => pool.query('select round(sum(debit-credit)::numeric,2)::text as amount from journal_lines where client_id=2 and doc_no=$1 and account_no=$2', [po.poNo, account]).then((r) => Number(r.rows[0].amount || 0));
  assert.equal(await net('120000'), 20);
  assert.equal(await net('204000'), -20);
  assert.equal(await net('200000'), 0, 'a GRN must not create an invoiced payable');
  assert.equal(await net('125000'), 0, 'no input tax is claimed before the bill');
  const preInvoice = await workspace();
  const forged = await call(state.PUT, 'PUT', { ...preInvoice,
    purchaseOrders: preInvoice.purchaseOrders.map((order: { id: string }) => order.id === po.id ? { ...order, status: 'Invoiced' } : order) }, owner);
  assert.equal(forged.status, 409, 'a browser cannot claim a supplier invoice without its posted journal');
  const bill = buildSupplierInvoiceJournal(po, context, `SUP-${tag}`);
  const postedBill = await call(journal.POST, 'POST', { lines: bill }, owner);
  assert.equal(postedBill.status, 200, JSON.stringify(await postedBill.clone().json()));
  const afterBill = await workspace();
  const invoiced = await call(state.PUT, 'PUT', { ...afterBill,
    purchaseOrders: afterBill.purchaseOrders.map((order: { id: string }) => order.id === po.id ? { ...order, status: 'Invoiced' } : order) }, owner);
  assert.equal(invoiced.status, 200, JSON.stringify(await invoiced.clone().json()));
  const all = await pool.query("select account_no, round(sum(debit-credit)::numeric,2)::text as amount from journal_lines where client_id=2 and doc_no in ($1,$2) group by account_no", [po.poNo, `BILL-${po.poNo}`]);
  const byAccount = (n: string) => Number(all.rows.find((row) => row.account_no === n)?.amount || 0);
  assert.equal(byAccount('204000'), 0);
  assert.equal(byAccount('200000'), -24);
  assert.equal(byAccount('125000'), 4);
  const statements = await import('../app/api/account-statements/route');
  const query = new URLSearchParams({ entityId: '2', kind: 'vendor', partyId: vendor.id, from: '2026-10-01', to: '2026-10-31' });
  const statementReq = (token?: string) => new Request(`http://localhost/api/account-statements?${query}`, token ? { headers: { Authorization: `Bearer ${token}` } } : undefined);
  assert.equal((await statements.GET(statementReq())).status, 401);
  assert.equal((await statements.GET(statementReq(demo))).status, 403);
  const reportResponse = await statements.GET(statementReq(owner));
  assert.equal(reportResponse.status, 200, JSON.stringify(await reportResponse.clone().json()));
  const report = await reportResponse.json();
  assert.ok(report.rows.some((row: { document: string; credit: number }) => row.document === po.poNo && row.credit === 24));
  assert.ok(!report.rows.some((row: { document: string; account: string }) => row.document === po.poNo && row.account === '204000'));
  const paymentNo = `PAY-${tag}`;
  const paymentLines = [
    { ...base, id: `${paymentNo}-1`, docNo: paymentNo, reference: po.poNo, accountNo: '200000', accountName: `Trade Payables (${po.vendorName})`, debit: 24, credit: 0 },
    { ...base, id: `${paymentNo}-2`, docNo: paymentNo, reference: po.poNo, accountNo: '100000', accountName: 'Cash at Bank', debit: 0, credit: 24 },
  ];
  const paid = await call(journal.POST, 'POST', { lines: paymentLines }, owner);
  assert.equal(paid.status, 200, JSON.stringify(await paid.clone().json()));
  const last = await workspace();
  const settled = await call(state.PUT, 'PUT', { ...last,
    purchaseOrders: last.purchaseOrders.map((order: { id: string }) => order.id === po.id ? { ...order, status: 'Paid', paidAmount: 24 } : order) }, owner);
  assert.equal(settled.status, 200, JSON.stringify(await settled.clone().json()));
  const finalReport = await (await statements.GET(statementReq(owner))).json();
  const tagged = finalReport.rows.filter((row: { journal: string }) => [po.poNo, `BILL-${po.poNo}`, paymentNo].includes(row.journal));
  assert.equal(tagged.reduce((balance: number, row: { debit: number; credit: number }) => balance + row.credit - row.debit, 0), 0);
});

await check('account statements and change markers isolate other clients across laptops', async () => {
  const statements = await import('../app/api/account-statements/route');
  const version = await import('../app/api/workspace-version/route');
  const query = (entity: number, kind: string, partyId: string) => new Request(`http://localhost/api/account-statements?entityId=${entity}&kind=${kind}&partyId=${encodeURIComponent(partyId)}&from=2026-01-01&to=2026-12-31`,
    { headers: { Authorization: `Bearer ${owner}` } });
  const firm = await (await workspace()).clients.find((c: { isParent: boolean }) => c.isParent);
  assert.ok(firm);
  const clientStatement = await statements.GET(query(firm.id, 'client', '2'));
  assert.equal(clientStatement.status, 200);
  assert.equal((await clientStatement.json()).entity.id, firm.id);
  assert.equal((await statements.GET(query(2, 'client', '3'))).status, 400);
  const mark = (entity: number, token: string) => version.GET(new Request(`http://localhost/api/workspace-version?entity=${entity}`,
    { headers: { Authorization: `Bearer ${token}` } }));
  assert.equal((await mark(3, demo)).status, 403);
  const first = await (await mark(2, owner)).json();
  const doc = pair(`SECOND-LAPTOP-${randomUUID().slice(0, 8)}`);
  assert.equal((await call(journal.POST, 'POST', { lines: doc }, owner)).status, 200);
  const second = await (await mark(2, demo)).json();
  assert.notEqual(first.marker, second.marker, 'other laptop must detect a newly posted journal');
  assert.equal((await mark(2, owner)).status, 200);
});

await check('withdrawn journal permission is enforced server-side', async () => {
  await pool.query('UPDATE users SET permissions = $1 WHERE username = $2', [JSON.stringify({ canPostJournals: false, allowedModules: ['sales'] }), 'demo']);
  assert.equal((await call(journal.POST, 'POST', { lines: pair('INTEGRATION-RESTRICTED', { createdBy: 'demo' }) }, demo)).status, 403);
});
await check('logout revokes the server session', async () => {
  assert.equal((await call(logout.POST, 'POST', {}, owner)).status, 200);
  assert.equal((await call(session.GET, 'GET', undefined, owner)).status, 401);
});

await pool.end();
console.log(`\nAPI regressions: ${passed} passed, ${failed} failed.`);
if (failed) process.exitCode = 1;