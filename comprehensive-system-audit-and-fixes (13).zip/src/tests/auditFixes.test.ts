import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseStatementReport,
  parseStatementDate,
  parseStatementAmount,
  matchStatementLines,
} from '../utils/reports';
import { applyLedgerAuthority, deriveTreasuryLedger } from '../lib/treasuryDerivation';
import { prepareBusinessPartnersForStorage } from '../lib/businessPartnerSync';
import { buildCreditNoteEntries, buildDisposalEntries, ppeAccountForClass, buildCashFlow } from '../utils/reports';
import type { ACDOCALine } from '../types/accounting';

const line = (over: Partial<ACDOCALine>): ACDOCALine => ({
  id: 'x', docNo: 'D1', period: '2026-03', date: '2026-03-10', module: 'FI', docType: 'JE',
  accountNo: '100000', accountName: 'Cash', costCenter: 'CC-ADM', debit: 0, credit: 0,
  currency: 'GHS', description: '', createdBy: 'owner', clientId: 2, ...over,
});

/* ------------------------------- statement import ------------------------------ */

test('statement parser accepts DD/MM/YYYY, quoted narrations, thousands separators and totals rows', () => {
  const csv = [
    'Date,Description,Debit,Credit,Balance',
    '05/03/2026,"POS withdrawal, Accra","1,234.50",,10000.00',
    '12 MAR 2026,"Salary batch","GHS 5,000.00",,"4,234.50"',
    '2026-03-20,"Customer transfer",,2000.00,6234.50',
    'Total,,6234.50,2000.00,',
  ].join('\n');
  const report = parseStatementReport(csv);
  assert.equal(report.lines.length, 3, 'totals row must be skipped');
  assert.equal(report.skippedRows, 1);
  assert.equal(report.lines[0].date, '2026-03-05');
  assert.equal(report.lines[0].debit, 1234.5);
  assert.equal(report.lines[1].date, '2026-03-12');
  assert.equal(report.lines[1].debit, 5000);
  assert.equal(report.lines[2].date, '2026-03-20');
  assert.equal(report.lines[2].credit, 2000);
  assert.equal(report.totals.out, 6234.5);
  assert.equal(report.totals.in, 2000);
  assert.equal(report.totals.net, -4234.5);
  assert.equal(report.headerDetected, true);
  assert.equal(report.delimiter, ',');
});

test('statement parser accepts a single signed Amount column and semicolon delimiter', () => {
  const csv = 'Value Date;Narrative;Amount\n12/03/2026;Rent paid;-450.00\n15/03/2026;Client paid;1200.00';
  const report = parseStatementReport(csv);
  assert.equal(report.delimiter, ';');
  assert.equal(report.lines.length, 2);
  assert.equal(report.lines[0].debit, 450);
  assert.equal(report.lines[0].credit, 0);
  assert.equal(report.lines[1].credit, 1200);
});

test('statement parser reports skipped rows with reasons instead of returning zero lines silently', () => {
  const csv = 'Date,Description,Debit,Credit\nnot-a-date,Bad row,10,0\n2026-03-01,Good,10,0';
  const report = parseStatementReport(csv);
  assert.equal(report.lines.length, 1);
  assert.equal(report.skippedRows, 1);
  assert.ok(report.skippedSamples[0].includes('Row 2'));
});

test('parseStatementDate handles ISO, day-first, month-name and two-digit years', () => {
  assert.equal(parseStatementDate('2026-03-12'), '2026-03-12');
  assert.equal(parseStatementDate('12/03/2026'), '2026-03-12');
  assert.equal(parseStatementDate('31/12/26'), '2026-12-31');
  assert.equal(parseStatementDate('12 MAR 2026'), '2026-03-12');
  assert.equal(parseStatementDate('Mar 12, 2026'), '2026-03-12');
  assert.equal(parseStatementDate('13/03/2026'), '2026-03-13'); // day > 12 → day-first
  assert.equal(parseStatementDate('03/25/2026'), '2026-03-25'); // month > 12 → month-first
  assert.equal(parseStatementDate('garbage'), null);
});

test('parseStatementAmount handles symbols, brackets, European separators', () => {
  assert.equal(parseStatementAmount('GHS 1,234.50'), 1234.5);
  assert.equal(parseStatementAmount('(450.00)'), -450);
  assert.equal(parseStatementAmount('450.00-'), -450);
  assert.equal(parseStatementAmount('1.234,56'), 1234.56);
  assert.equal(parseStatementAmount('1,234.56'), 1234.56);
  assert.equal(parseStatementAmount('₵2,000'), 2000);
  assert.equal(parseStatementAmount('abc'), null);
  assert.equal(parseStatementAmount(''), 0);
});

test('statement matching pairs money-out with journal CREDIT on an asset GL', () => {
  const journal = [
    line({ id: 'a', debit: 5000, credit: 0, date: '2026-03-10' }),   // cash in
    line({ id: 'b', debit: 0, credit: 1200, date: '2026-03-11' }),  // cash out
  ];
  const statement = [
    { date: '2026-03-10', description: 'in', debit: 0, credit: 5000 },
    { date: '2026-03-12', description: 'out', debit: 1200, credit: 0 },
  ];
  const matches = matchStatementLines(statement, journal, '100000');
  assert.equal(matches[0].matched, true);
  assert.equal(matches[0].matchedDocNo, 'D1');
  assert.equal(matches[1].matched, true, 'money out must match the journal credit');
  assert.equal(matches[1].net, -1200);
});

/* ------------------------------- treasury derivation ------------------------------ */

test('client and server treasury derivations agree on the same journal', () => {
  const journal = [
    line({ id: '1', accountNo: '100000', debit: 840000, currency: 'GHS' }),
    line({ id: '2', accountNo: '100000', debit: 1550000, credit: 0, currency: 'GHS' }),
    line({ id: '3', accountNo: '100000', debit: 0, credit: 120000, currency: 'GHS' }),
    line({ id: '4', accountNo: '101000', debit: 185000, currency: 'USD' }),
  ];
  const ledger = deriveTreasuryLedger(journal);
  assert.equal(ledger.get('2:100000:GHS'), 2270000);
  assert.equal(ledger.get('2:101000:USD'), 185000);

  const records = [
    { id: 1, clientId: 2, glAccount: '100000', currency: 'GHS', balance: 999999 },
    { id: 2, clientId: 2, glAccount: '101000', currency: 'USD', balance: 1 },
  ];
  const out = applyLedgerAuthority(records, ledger);
  assert.equal(out[0].balance, 2270000, 'stale browser balance is replaced by the ledger figure');
  assert.equal(out[1].balance, 185000);
});

/* ------------------------------- partner credit registration ------------------------------ */

test('partner sync validates credit limit, terms, status and opening balance', () => {
  const ok = prepareBusinessPartnersForStorage([
    { id: '1', code: 'C001', name: 'Acme', type: 'Customer', tin: '', email: '', phone: '', address: '', currency: 'GHS', isVatWithholdingAgent: false, isCstApplicable: false, isTourismLevyApplicable: false, creditLimit: 50000, creditTermsDays: 45, paymentTerms: 'Net 45', creditStatus: 'Active', openingBalance: 1000 },
  ], 2);
  assert.equal(ok.ok, true);
  if (ok.ok) {
    assert.equal(ok.rows[0].creditLimit, 50000);
    assert.equal(ok.rows[0].creditTermsDays, 45);
    assert.equal(ok.rows[0].creditStatus, 'Active');
    assert.equal(ok.rows[0].openingBalance, 1000);
  }

  const badLimit = prepareBusinessPartnersForStorage([
    { id: '1', code: 'C001', name: 'Acme', type: 'Customer', tin: '', email: '', phone: '', address: '', currency: 'GHS', isVatWithholdingAgent: false, isCstApplicable: false, isTourismLevyApplicable: false, creditLimit: -5 },
  ], 2);
  assert.equal(badLimit.ok, false);

  const badTerms = prepareBusinessPartnersForStorage([
    { id: '1', code: 'C001', name: 'Acme', type: 'Customer', tin: '', email: '', phone: '', address: '', currency: 'GHS', isVatWithholdingAgent: false, isCstApplicable: false, isTourismLevyApplicable: false, creditTermsDays: 999 },
  ], 2);
  assert.equal(badTerms.ok, false);

  const badStatus = prepareBusinessPartnersForStorage([
    { id: '1', code: 'C001', name: 'Acme', type: 'Customer', tin: '', email: '', phone: '', address: '', currency: 'GHS', isVatWithholdingAgent: false, isCstApplicable: false, isTourismLevyApplicable: false, creditStatus: 'Whatever' },
  ], 2);
  assert.equal(badStatus.ok, false);
});

/* ------------------------------- credit note / disposal integrity ------------------------------ */

test('credit note splits paid vs unpaid between 110000 and 217000 and reverses the exact revenue account', () => {
  const entries = buildCreditNoteEntries({
    invNo: 'INV-2026-001', customerName: 'Zurich Gold', revenueStream: 'Gold sale',
    revenueAccount: '403000', revenueAccountName: 'Export Sales', netRevenue: 1000, vatOutput: 200,
    totalReceivable: 1200, paidAmount: 500,
  }, '2026-03-31', 'GHS', 2, 'owner');
  const dr = entries.reduce((n, l) => n + l.debit, 0);
  const cr = entries.reduce((n, l) => n + l.credit, 0);
  assert.equal(Math.round(dr * 100), Math.round(cr * 100), 'must balance');
  const rev = entries.find((l) => l.debit > 0)!;
  assert.equal(rev.accountNo, '403000');
  const ar = entries.find((l) => l.accountNo === '110000')!;
  const deposit = entries.find((l) => l.accountNo === '217000')!;
  assert.equal(ar.credit, 700);
  assert.equal(deposit.credit, 500);
});

test('disposal uses the asset class cost account and stays balanced', () => {
  assert.equal(ppeAccountForClass('Plant & Machinery'), '132000');
  assert.equal(ppeAccountForClass('Vehicles'), '133000');
  const entries = buildDisposalEntries(
    { assetTag: 'AST-002', name: 'Truck', cost: 380000, accumDep: 100000, classCode: 'Vehicles' },
    300000, '2026-03-31', 'GHS', 2, 'owner',
  );
  const dr = entries.reduce((n, l) => n + l.debit, 0);
  const cr = entries.reduce((n, l) => n + l.credit, 0);
  assert.equal(Math.round(dr * 100), Math.round(cr * 100));
  const cost = entries.find((l) => l.credit > 0 && l.accountNo.startsWith('13'))!;
  assert.equal(cost.accountNo, '133000');
});


test('statement recognises a later semicolon header and reports original row numbers', () => {
  const r = parseStatementReport('Bank export for testing\r\nAccount: 1\r\n\r\nValue Date;Narrative;Withdrawal;Deposit\r\n29/02/2024;"Card, Accra";1.200,50;\r\n31/02/2024;Impossible;;42\r\n01/03/2024;Invalid;10;20\r\n02/03/2024;Total Ghana;8;\r\n');
  assert.equal(r.delimiter, ';');
  assert.equal(r.headerDetected, true);
  assert.deepEqual(r.lines.map((row) => row.row), [5, 8]);
  assert.deepEqual(r.totals, { out: 1208.5, in: 0, net: -1208.5 });
  assert.match(r.skippedSamples.join('; '), /Row 6.*date.*Row 7.*both debit and credit/);
});

test('statement refuses malformed amounts and shifted CSV fields without inventing cash', () => {
  const r = parseStatementReport('Date,Description,Debit,Credit\n2026-02-05,unquoted thousands,1,200.50,\n2026-02-06,garbage,GHS12bad20,\n2026-02-07,valid,300,-\n2026-02-08,"broken,100,');
  assert.equal(r.lines.length, 1);
  assert.equal(r.lines[0].debit, 300);
  assert.equal(r.skippedRows, 3);
  assert.equal(parseStatementAmount('12,34,500.90'), null);
  assert.equal(parseStatementDate('29/02/2025'), null);
  assert.equal(parseStatementDate('03/08/2026', 'month-first'), '2026-03-08');
  assert.equal(parseStatementDate('03/08/2026'), '2026-08-03');
});

test('match limits a GL line to one statement row; same-day ties need manual review', () => {
  const original = [line({ id: 'a', docNo: 'BANK-1', debit: 100 }), line({ id: 'b', docNo: 'BANK-2', debit: 100 })];
  const cash = { date: '2026-03-10', description: 'Cash in', debit: 0, credit: 100 };
  const [tied] = matchStatementLines([cash], original, '100000');
  assert.deepEqual([tied.matched, tied.ambiguous], [false, true]);
  const exact = matchStatementLines([cash, { ...cash, reference: 'BANK-2' }, cash], original, '100000');
  assert.deepEqual(exact.map((m) => m.matchedLineId), ['a', 'b', undefined]);
  assert.equal(matchStatementLines([cash], [line({ debit: 100, isReversed: true })], '100000')[0].matched, false);
});

test('large bank analysis matches 12000 rows without a scan of the whole ledger per row', () => {
  const docs = Array.from({ length: 12_000 }, (_, index) => line({ id: `row-${index}`, docNo: `BK-${index}`, debit: 24 }));
  const csv = 'Date,Description,Amount,Reference\n' + docs.map((d) => `${d.date},Receipt,24,${d.docNo}`).join('\n');
  const report = parseStatementReport(csv);
  assert.equal(report.lines.length, docs.length);
  const matches = matchStatementLines(report.lines, docs, '100000');
  assert.equal(matches.filter((r) => r.matched).length, docs.length);
  assert.equal(new Set(matches.map((r) => r.matchedLineId)).size, docs.length);
});

test('selected accounting periods produce valid in-period dates', async () => {
  const { postingDateForPeriod } = await import('../utils/periods');
  assert.equal(postingDateForPeriod('2024-02', '2024-04-01'), '2024-02-29');
  assert.equal(postingDateForPeriod('2024-04', '2024-04-01'), '2024-04-01');
  assert.equal(postingDateForPeriod('2024-05', '2024-04-01'), null);
  assert.equal(postingDateForPeriod('2024-17', '2024-04-01'), null);
});

test('client invitations are portable, with no sandbox or credential-bearing URL', async () => {
  const { workspaceInvitationUrl } = await import('../lib/workspaceLink');
  assert.equal(workspaceInvitationUrl('CLI-1', 'https://erp.example.org'), 'https://erp.example.org/?workspace=CLI-1');
  assert.equal(workspaceInvitationUrl('CLI-1', 'https://3000-sandbox.e2b.app'), '/?workspace=CLI-1');
  assert.equal(workspaceInvitationUrl('CLI 1/2', 'https://u:p@erp.example.org'), '/?workspace=CLI%201%2F2');
  assert.equal(workspaceInvitationUrl('CLI-1', 'https://erp.example.org/old'), '/?workspace=CLI-1');
});

test('fixed-asset disposal and stock returns retain the original asset GL', async () => {
  const { postedPpeCostAccount } = await import('../utils/reports');
  const { buildReturnInEntries } = await import('../utils/trading');
  const asset = { assetTag: 'AST-01', classCode: 'Vehicles' };
  assert.equal(postedPpeCostAccount(asset, [line({ accountNo: '130000', debit: 120, description: 'Acquisition of AST-01' })], 2), '130000');
  assert.equal(postedPpeCostAccount(asset, [], 2), '133000');
  const entries = buildReturnInEntries({ docNo: 'CN-TEST', date: '2026-03-10', currency: 'GHS', clientId: 2, createdBy: 'owner', costCenter: 'CC-SLS' }, 99, 'FIN-1', '121000');
  assert.deepEqual(entries.map((l) => [l.accountNo, l.debit, l.credit, l.module, l.docType]), [['121000', 99, 0, 'SD', 'REV'], ['504000', 0, 99, 'SD', 'REV']]);
});

test('cash flow includes GRNI (204000) and customer contract liabilities (225000) in operating working capital', () => {
  const lines = [
    { id: 'a', docNo: 'R-1', period: '2026-01', date: '2026-01-02', module: 'MM' as const, docType: 'PO' as const, accountNo: '120000', accountName: 'Inventory', debit: 400, credit: 0, currency: 'GHS', description: 'goods', createdBy: 'u', clientId: 2 },
    { id: 'b', docNo: 'R-1', period: '2026-01', date: '2026-01-02', module: 'MM' as const, docType: 'PO' as const, accountNo: '204000', accountName: 'GRNI', debit: 0, credit: 400, currency: 'GHS', description: 'unpaid receipt', createdBy: 'u', clientId: 2 },
    { id: 'c', docNo: 'S-1', period: '2026-01', date: '2026-01-05', module: 'SD' as const, docType: 'INV' as const, accountNo: '100000', accountName: 'Bank', debit: 250, credit: 0, currency: 'GHS', description: 'advance received', createdBy: 'u', clientId: 2 },
    { id: 'd', docNo: 'S-1', period: '2026-01', date: '2026-01-05', module: 'SD' as const, docType: 'INV' as const, accountNo: '225000', accountName: 'Contract Liabilities', debit: 0, credit: 250, currency: 'GHS', description: 'advance received', createdBy: 'u', clientId: 2 },
  ];
  const accounts = [
    { accountNo: '100000', name: 'Bank', type: 'Asset' as const, category: 'Current Assets', active: true, isCustom: false },
    { accountNo: '102000', name: 'Cash', type: 'Asset' as const, category: 'Current Assets', active: true, isCustom: false },
    { accountNo: '120000', name: 'Inventory', type: 'Asset' as const, category: 'Current Assets', active: true, isCustom: false },
    { accountNo: '204000', name: 'GRNI', type: 'Liability' as const, category: 'Current Liabilities', active: true, isCustom: false },
    { accountNo: '225000', name: 'Contract Liabilities', type: 'Liability' as const, category: 'Current Liabilities', active: true, isCustom: false },
    { accountNo: '400000', name: 'Revenue', type: 'Income' as const, category: 'Revenue', active: true, isCustom: false },
  ];
  const cf = buildCashFlow(lines, accounts, '2026-01', '2026-01-31');
  // Non-cash purchase cancels out within operating WC; advance received is operating inflow.
  assert.equal(cf.residual, 0);
  assert.ok(cf.operating > 0, 'advance cash inflow must be reflected in operating');
  assert.equal(Math.round(cf.deltaPayables * 100) / 100, 650);
  assert.equal(Math.round(cf.deltaInventory * 100) / 100, 400);
});
