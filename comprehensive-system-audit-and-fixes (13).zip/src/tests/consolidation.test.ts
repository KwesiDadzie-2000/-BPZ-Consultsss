import assert from 'node:assert/strict';
import { test } from 'node:test';
import { consolidateGroup } from '../utils/consolidation';
import type { ACDOCALine, AccountMaster, ClientEntity } from '../types/accounting';

const accounts: AccountMaster[] = [
  { accountNo: '100000', name: 'Cash at Bank', type: 'Asset', category: 'Cash', active: true },
  { accountNo: '110000', name: 'Trade Receivables', type: 'Asset', category: 'Receivables', active: true },
  { accountNo: '120000', name: 'Inventory', type: 'Asset', category: 'Inventories', active: true },
  { accountNo: '200000', name: 'Trade Payables', type: 'Liability', category: 'Payables', active: true },
  { accountNo: '300000', name: 'Share Capital', type: 'Equity', category: 'Equity', active: true },
];

const client = (id: number, name: string, code: string, currency = 'GHS', isParent = false): ClientEntity => ({
  id, name, code, currency, sector: 'Petroleum', jurisdiction: 'GH', regNumber: `REG-${id}`, isParent,
});

const line = (accountNo: string, accountName: string, debit: number, credit: number, clientId: number, docNo: string, description = ''): ACDOCALine => ({
  id: `${docNo}-${accountNo}-${clientId}`, docNo, period: '2026-01', date: '2026-01-15', module: 'FI', docType: 'JE',
  accountNo, accountName, debit, credit, currency: 'GHS', description: description || accountName, createdBy: 'owner', clientId,
});

test('same-currency consolidation foots across parent + subsidiary', () => {
  const parent = client(1, 'Firm HQ', 'HQ', 'GHS', true);
  const sub = client(2, 'Sub Ltd', 'SUB', 'GHS');
  const parentLines = [
    line('100000', 'Cash at Bank', 500, 0, 1, 'J1'), line('300000', 'Share Capital', 0, 500, 1, 'J1'),
    line('110000', 'Trade Receivables (Acme Ltd)', 1200, 0, 1, 'J2'), line('400000', 'Revenue', 0, 1200, 1, 'J2'),
  ];
  const subLines = [
    line('100000', 'Cash at Bank', 800, 0, 2, 'J3'), line('300000', 'Share Capital', 0, 800, 2, 'J3'),
    line('200000', 'Trade Payables (Acme Ltd)', 0, 1000, 2, 'J4'), line('400000', 'Revenue', 0, 1000, 2, 'J4'),
  ];
  const result = consolidateGroup({
    parent, accounts,
    entities: [
      { client: parent, input: { id: 1, holdPct: 100, exchangeRate: 1 }, lines: parentLines },
      { client: sub, input: { id: 2, holdPct: 100, exchangeRate: 1, investment: 1500 }, lines: subLines },
    ],
  });
  assert.equal(result.errors.length, 0);
  // No intercompany elimination: 1200 AR vs 1000 AP — equal entity pair means eliminate min(1200,1000)=1000.
  const eliminationTotal = result.totals.eliminations;
  assert.equal(eliminationTotal, 1000, `elimination should equal min(AR, AP): got ${eliminationTotal}`);
  // Assets = parent 1700 + sub 800 + goodwill(1500-800=700) - eliminate parent AR 1000 - sub AP 1000
  // net assets: parent(500+1200-1000=700) + sub(800+0=800 - 1000 AP eliminated?) careful:
  // consolidated AR = 1200 - 1000 = 200; consolidated AP = 1000 - 1000 = 0
  // assets = 500+200+700(goodwill)+800 = 2200? Let's estimate via totals below.
  const { assets, liabilities, equity, goodwill, nci, parentRetained, eliminations } = result.totals;
  // NAV of subsidiary = assets 800 − liabilities 1000 = −200. goodwill = 1500 − 100% × (−200) = 1700.
  assert.equal(goodwill, 1700, `goodwill = investment(1500) − NAV(−200) = 1700, got ${goodwill}`);
  assert.equal(nci, 0, 'NCI = 0% paid, hold 100% → NCI = 0');
  assert.ok(eliminations === 1000);
  // Foot: assets = retained + NCI + liabilities
  assert.ok(Math.abs(assets - (parentRetained + nci + liabilities)) < 0.02, `foot check failed: ${assets} vs ${parentRetained}+${nci}+${liabilities}`);
  assert.ok(Math.abs((parentRetained + nci) - equity) < 0.02, 'equity identity');
  // consolidated 110000
  const ar = result.rows.find((r) => r.account === '110000');
  assert.equal(ar?.consolidated, 20000, 'AR consolidated to 1200 − 1000 eliminated = 200');
  const ap = result.rows.find((r) => r.account === '200000');
  assert.equal(ap?.consolidated, 0, 'AP consolidated to 1000 − 1000 eliminated = 0');
});

test('control establishment fails below 50% hold — entity excluded, error recorded', () => {
  const parent = client(1, 'Firm HQ', 'HQ', 'GHS', true);
  const sub = client(2, 'Sub Ltd', 'SUB', 'GHS');
  const lines = [
    line('100000', 'Cash at Bank', 100, 0, 2, 'J1'),
    line('300000', 'Share Capital', 0, 100, 2, 'J1'),
    line('400000', 'Revenue', 0, 100, 2, 'J1'),
  ];
  const result = consolidateGroup({
    parent, accounts,
    entities: [
      { client: parent, input: { id: 1, holdPct: 100, exchangeRate: 1 }, lines: parentLines() },
      { client: sub, input: { id: 2, holdPct: 40, exchangeRate: 1 }, lines },
    ],
  });
  assert.equal(result.entities.find((e) => e.id === 2)?.included, false);
  assert.ok(result.errors.some((e) => e.includes('40%')));
});

function parentLines() {
  return [
    line('100000', 'Cash at Bank', 500, 0, 1, 'J1'),
    line('300000', 'Share Capital', 0, 500, 1, 'J1'),
  ];
}

test('NCI accrues with 60% hold: NCI = 40% × (NAV + goodwill)', () => {
  const parent = client(1, 'Firm HQ', 'HQ', 'GHS', true);
  const sub = client(2, 'Sub Ltd', 'SUB', 'GHS');
  const lines = [
    line('100000', 'Cash at Bank', 1000, 0, 2, 'J1'),
    line('300000', 'Share Capital', 0, 1000, 2, 'J1'),
  ];
  const invest = 1400;
  const result = consolidateGroup({
    parent, accounts,
    entities: [
      { client: parent, input: { id: 1, holdPct: 100, exchangeRate: 1 }, lines: parentLines() },
      { client: sub, input: { id: 2, holdPct: 60, exchangeRate: 1, investment: invest }, lines },
    ],
  });
  // NAV = 1000; hold 60% → goodwill = max(0, 1400 − 0.6×1000) = 800
  const goodwill = result.entities.find((e) => e.id === 2)!.goodwill;
  assert.equal(goodwill, 800, `goodwill should be 800: got ${goodwill}`);
  // NCI = 40% × (1000 + 800) = 720
  assert.equal(result.entities.find((e) => e.id === 2)!.nCi, 720);
  assert.equal(result.totals.nci, 720);
});

test('foreign subsidiary translates at closing rate', () => {
  const parent = client(1, 'Firm HQ', 'HQ', 'GHS', true);
  const sub = client(2, 'UK Sub Ltd', 'SUB', 'GBP');
  const lines = [
    line('100000', 'Cash at Bank', 600, 0, 2, 'J1'),
    line('300000', 'Share Capital', 0, 600, 2, 'J1'),
  ];
  // 1 GBP = 15 GHS
  const result = consolidateGroup({
    parent, accounts,
    entities: [
      { client: parent, input: { id: 1, holdPct: 100, exchangeRate: 1 }, lines: parentLines() },
      { client: sub, input: { id: 2, holdPct: 100, exchangeRate: 15 }, lines },
    ],
  });
  const totals = result.totals;
  // Sub assets 600 GBP × 15 = 9000 GHS
  assert.equal(result.entities.find((e) => e.id === 2)!.assets, 9000);
  assert.equal(totals.assets, 500 + 9000, 'assets consolidated in parent currency');
});

test('equity-method/uncontrolled subs and over-100% control are excluded', () => {
  const parent = client(1, 'Firm HQ', 'HQ', 'GHS', true);
  const sub = client(2, 'Tiny Sub', 'SUB', 'GHS');
  const result = consolidateGroup({
    parent, accounts,
    entities: [
      { client: parent, input: { id: 1, holdPct: 100, exchangeRate: 1 }, lines: parentLines() },
      { client: sub, input: { id: 2, holdPct: 25, exchangeRate: 1 }, lines: [] },
    ],
  });
  assert.equal(result.entities.find((e) => e.id === 2)?.included, false);
  assert.ok(result.errors.some((e) => e.includes('25%')));
});
test('goodwill appears as a row so the working paper foots to total assets', () => {
  const parent = client(1, 'Firm HQ', 'HQ', 'GHS', true);
  const sub = client(2, 'Sub Ltd', 'SUB', 'GHS');
  const lines = [
    line('100000', 'Cash at Bank', 800, 0, 2, 'J1'), line('300000', 'Share Capital', 0, 800, 2, 'J1'),
  ];
  const result = consolidateGroup({
    parent, accounts,
    entities: [
      { client: parent, input: { id: 1, holdPct: 100, exchangeRate: 1 }, lines: parentLines() },
      { client: sub, input: { id: 2, holdPct: 100, exchangeRate: 1, investment: 1200 }, lines },
    ],
  });
  const goodwillRow = result.rows.find((r) => r.account === '199900');
  assert.ok(goodwillRow, 'goodwill must be a row in the consolidated trial balance');
  assert.equal(goodwillRow!.consolidated, 40000, 'goodwill = (1200 − 800) × 100 in minor units');
  // Sum of asset rows (minor) must equal total assets (major).
  const assetRowsMinor = result.rows.filter((r) => r.type === 'Asset').reduce((n, r) => n + r.consolidated, 0);
  assert.ok(Math.abs(assetRowsMinor / 100 - result.totals.assets) < 0.02,
    `row sum ${assetRowsMinor / 100} must equal total assets ${result.totals.assets}`);
});
