import assert from 'node:assert/strict';
import { test } from 'node:test';
import { buildLedgerJournal, buildOpeningJournal, parseBanks, parseLedgerHistory, parseOpeningBalances, parsePartners } from '../lib/migration';

test('opening balances: balanced file validates and builds one journal', () => {
  const csv = ['Account,Debit,Credit', '100000,250000,0', '120000,180000,0', '200000,0,90000', '309000,0,340000'].join('\n');
  const preview = parseOpeningBalances(csv, 'GHS');
  assert.equal(preview.ok, true);
  if (preview.ok) {
    assert.equal(preview.kind, 'opening');
    assert.equal(preview.rows, 4);
    assert.equal(preview.totalDebit, 430000);
    assert.equal(preview.totalCredit, 430000);
    assert.equal(preview.balanced, true);
  }
  const built = buildOpeningJournal(csv, 'GHS', 2, '2026-01-01', 'owner');
  assert.equal(built.ok, true);
  if (built.ok) assert.equal(built.lines.length, 4);
});

test('opening balances: out-of-balance file is refused with a clear diff', () => {
  const csv = ['Account,Debit,Credit', '100000,100,0', '200000,0,90'].join('\n');
  const preview = parseOpeningBalances(csv, 'GHS');
  assert.equal(preview.ok, false);
  if (!preview.ok) assert.match(preview.errors.map((e) => e.message).join(' '), /does not balance/);
});

test('opening balances: both-sides and bad-account rows are rejected', () => {
  const both = ['Account,Debit,Credit', '100000,50,50'].join('\n');
  assert.equal(parseOpeningBalances(both, 'GHS').ok, false);
  const badAcc = ['Account,Debit,Credit', '12345,50,0', '200000,0,50'].join('\n');
  assert.equal(parseOpeningBalances(badAcc, 'GHS').ok, false);
});

test('ledger history: each document must balance; dates and accounts validated', () => {
  const good = ['Document,Date,Account,Debit,Credit,Description', 'JV-1,2026-01-15,621000,1000,0,Fees', 'JV-1,2026-01-15,100000,0,1000,Fees'].join('\n');
  const preview = parseLedgerHistory(good, 'GHS');
  assert.equal(preview.ok, true);
  if (preview.ok && preview.kind === 'ledger') { assert.equal(preview.documents, 1); assert.equal(preview.balanced, true); }
  const built = buildLedgerJournal(good, 'GHS', 2, 'owner');
  assert.equal(built.ok, true);
  if (built.ok) assert.equal(built.lines.length, 2);

  const unbalanced = ['Document,Date,Account,Debit,Credit', 'JV-2,2026-01-15,621000,1000,0'].join('\n');
  const bad = parseLedgerHistory(unbalanced, 'GHS');
  assert.equal(bad.ok, false);
  if (!bad.ok) assert.match(bad.errors.map((e) => e.message).join(' '), /does not balance/);

  const badDate = ['Document,Date,Account,Debit,Credit', 'JV-3,not-a-date,621000,10,0', 'JV-3,not-a-date,100000,0,10'].join('\n');
  assert.equal(parseLedgerHistory(badDate, 'GHS').ok, false);
});

test('partners: customers and vendors parse with credit terms; bad type refused', () => {
  const csv = ['Code,Name,Type,CreditLimit,CreditTermsDays', 'C001,Accra Retail,Customer,50000,30', 'V001,SteelMasters,Vendor,0,0'].join('\n');
  const preview = parsePartners(csv);
  assert.equal(preview.ok, true);
  if (preview.ok && preview.kind === 'partners') { assert.equal(preview.customers, 1); assert.equal(preview.vendors, 1); }
  const bad = ['Code,Name,Type', 'X001,No Type,Mystery'].join('\n');
  assert.equal(parsePartners(bad).ok, false);
});

test('banks: GL must be a 10xxxx treasury account', () => {
  const good = ['Code,Name,GL,OpeningBalance', 'BNK-01,Operating,100000,250000'].join('\n');
  assert.equal(parseBanks(good).ok, true);
  const bad = ['Code,Name,GL,OpeningBalance', 'BNK-01,Operating,200000,250000'].join('\n');
  assert.equal(parseBanks(bad).ok, false);
});

test('migration is idempotent-safe: it builds fresh journal ids per run', () => {
  const csv = ['Account,Debit,Credit', '100000,100,0', '200000,0,100'].join('\n');
  const a = buildOpeningJournal(csv, 'GHS', 2, '2026-01-01', 'owner');
  const b = buildOpeningJournal(csv, 'GHS', 2, '2026-01-01', 'owner');
  assert.equal(a.ok && b.ok, true);
  if (a.ok && b.ok) {
    assert.deepEqual(a.lines.map((l) => l.id), b.lines.map((l) => l.id), 'same ids → replay is idempotent');
    assert.equal(a.lines[0].docNo, 'OPENING-2026-01-01');
  }
});
