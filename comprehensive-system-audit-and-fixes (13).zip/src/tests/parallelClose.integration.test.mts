import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { eq, and } from 'drizzle-orm';
import { CLOSE_CHECKS, moneyDecimal } from '../lib/parallelClose';
import type { CutoverView, CutoverWork } from '../lib/parallelClose';
import type { ACDOCALine } from '../types/accounting';

const url = new URL(process.env.BPZ_CUTOVER_DATABASE_URL ?? 'postgresql://postgres:postgres@127.0.0.1:5432/bpz_cutover_test');
if (!['localhost', '127.0.0.1'].includes(url.hostname) || url.pathname !== '/bpz_cutover_test') {
  throw new Error('The cutover suite only resets the disposable local bpz_cutover_test database.');
}
process.env.DATABASE_URL = url.href;
process.env.BPZ_BOOTSTRAP_MODE = 'production';
process.env.BPZ_OWNER_EMAIL = 'cutover-owner@example.invalid';
process.env.BPZ_SETUP_TOKEN = randomUUID();
process.env.BPZ_REQUIRE_PROVENANCE = 'true';
process.env.BPZ_BACKUP_SCHEDULE_ENABLED = 'false';
process.env.BPZ_ENFORCE_MFA_OWNER = 'false';
process.env.BPZ_ENFORCE_MFA_CHECKERS = 'false';
process.env.BPZ_PUBLIC_ORIGIN = 'https://erp.bpz-release.invalid';
process.env.BPZ_DEPLOYMENT_ID = randomUUID();

const { db, pool } = await import('../db');
const { ensureDatabaseReady } = await import('../db/bootstrap');
const schema = await import('../db/schema');
const route = await import('../app/api/parallel-close/route');
const journals = await import('../app/api/journal/route');
const bootstrap = await import('../app/api/bootstrap/route');
const sync = await import('../app/api/state/route');
const health = await import('../app/api/health/route');
const trade = await import('../app/api/trade/route');
const { createSession } = await import('../lib/auth');
const { hashPassword, newSalt } = await import('../lib/password');
const { backupStorageScope, getProvenance, writeReleaseProof, releaseScope, HTTPS_PROOF_KEY, RESTORE_PROOF_KEY } = await import('../lib/releaseReadiness');
const period = '2025-03';
const path = '/api/parallel-close';
const site = 'http://localhost';
let pass = 0;
const passCase = (name: string) => { pass++; console.log(`PASS ${name}`); };
const req = (method: string, pathname: string, token?: string, body?: unknown) => new Request(`${site}${pathname}`, {
  method, headers: { 'content-type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
});
const data = (s: string) => Buffer.from(s).toString('base64');

try {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await ensureDatabaseReady();
  const id = 1;
  const scope = `${path}?clientId=${id}&period=${period}`;
  assert.equal((await route.GET(req('GET', scope))).status, 401);
  const owner = await createSession('owner');
  const ownerSalt = newSalt();
  await db.update(schema.users).set({ mfaEnabled: true, passwordSalt: ownerSalt, passwordHash: await hashPassword(randomUUID(), ownerSalt) }).where(eq(schema.users.id, 'owner'));
  await db.insert(schema.clients).values({ id: 2, name: 'Other Entity', code: 'OTHER', currency: 'GHS', jurisdiction: 'GH', sector: 'Services', regNumber: 'T-OTHER' });
  const addUser = async (name: string, clientId: number, role: 'manager' | 'accountant' | 'auditor', canCheck: boolean) => {
    await db.insert(schema.users).values({ id: name, username: name, email: `${name}@example.invalid`, name, status: 'active', role, clientId, canCheck,
      makerLimit: 100000, mfaEnabled: canCheck, permissions: { allowedModules: ['parallel_close'] } });
    return createSession(name);
  };
  const maker = await addUser('close_maker', 1, 'accountant', false);
  const checker = await addUser('close_checker', 1, 'manager', true);
  const contributor = await addUser('other_editor', 1, 'manager', true);
  const outside = await addUser('other_tenant', 2, 'manager', true);
  const auditor = await addUser('close_auditor', 1, 'auditor', false);
  assert.equal((await route.GET(req('GET', scope, outside))).status, 403);
  assert.equal((await route.POST(req('POST', scope, auditor, { action: 'save', version: 0, work: {} }))).status, 403);
  passCase('unauthenticated, cross-tenant and auditor write controls');

  const get = async (user = maker) => {
    const response = await route.GET(req('GET', scope, user));
    assert.equal(response.status, 200, await response.clone().text());
    return (await response.json()).close as CutoverView;
  };
  let close = await get();
  const change = async (actor: string, action: string, payload: Record<string, unknown> = {}, status = 200) => {
    const response = await route.POST(req('POST', scope, actor, { action, version: close.packet?.version ?? 0, ...payload }));
    assert.equal(response.status, status, await response.clone().text());
    const body = await response.json();
    if (response.ok) close = body.close as CutoverView;
    return body;
  };
  const post = async (doc: string, month: string, want = 200) => {
    const base = { docNo: doc, period: month, date: `${month}-12`, module: 'FI' as const, docType: 'JE' as const, accountName: 'Account', currency: 'GHS', description: 'Parallel close fixture', createdBy: 'owner', clientId: 1 };
    const lines: ACDOCALine[] = [
      { ...base, id: `${doc}-1`, accountNo: '100000', debit: 125, credit: 0 },
      { ...base, id: `${doc}-2`, accountNo: '400000', debit: 0, credit: 125 },
    ];
    const response = await journals.POST(req('POST', '/api/journal', owner, { lines }));
    assert.equal(response.status, want, await response.clone().text());
    return lines;
  };

  let work: CutoverWork = { reference: 'Legacy close pack TB-2025-03', notes: 'All source transactions for the completed pilot month were mirrored and the cut-off compared.', checks: {}, legacyTrial: null };
  await change(maker, 'save', { work });
  assert.equal(close.packet?.status, 'draft');
  await change(maker, 'submit', {}, 409);
  await change(maker, 'save', { work, version: 0 }, 409);
  await post('PC-BASE', period);
  close = await get();
  assert.equal(close.ledger.periodLines, 2);
  assert.equal(close.ledger.anchors.bank, 12500);
  passCase('draft versioning and rejection of incomplete month packs');

  const importTrial = async () => {
    const text = 'Account,Debit,Credit,Currency\n' + close.ledger.trial.map((r) => `${r.account},${moneyDecimal(r.debit)},${moneyDecimal(r.credit)},GHS`).join('\n');
    await change(maker, 'upload', { key: 'legacy_trial', name: 'trial-2025-03.csv', data: data(text) });
  };
  await change(maker, 'upload', { key: 'legacy_trial', name: 'bad.csv', data: data('Account,Debit,Credit\n100000,wrong,0') }, 400);
  await importTrial();
  const file = close.evidence.find((e) => e.key === 'legacy_trial')!;
  const uploaded = await route.GET(req('GET', `${scope}&file=${file.id}`, checker));
  assert.equal(uploaded.status, 200);
  assert.match(uploaded.headers.get('content-disposition') ?? '', /^attachment/);
  assert.match(await uploaded.text(), /100000,125\.00,0\.00,GHS/);
  assert.equal((await route.GET(req('GET', `${scope}&file=${file.id}`, outside))).status, 403);
  for (const row of CLOSE_CHECKS) {
    const amount = moneyDecimal(close.ledger.anchors[row.key] ?? 0);
    work.checks[row.key] = { reference: `${row.key.toUpperCase()}-REF`, notes: 'Signed source verified against period close.', legacy: amount, bpz: amount,
      result: row.kind === 'optional' ? 'not_applicable' : 'verified' };
    if (row.kind !== 'optional') await change(maker, 'upload', { key: row.key, name: `${row.key}.txt`, data: data('Reviewed source schedule for this control.') });
  }
  passCase('legacy comparison, private file download and required supporting evidence');

  work.checks.bank = { ...work.checks.bank!, legacy: '125.01', bpz: '125.01' };
  await change(contributor, 'save', { work });
  assert.ok(close.blockers.some((b) => b.includes('must tie to the posted control')));
  await change(maker, 'submit', {}, 409);
  work.checks.bank = { ...work.checks.bank!, legacy: '125.00', bpz: '125.00' };
  await change(maker, 'save', { work });
  assert.deepEqual(close.blockers, []);
  await change(maker, 'submit');
  const sign = { confirm: true, reason: 'I independently examined the source records and matched each requested reconciliation.' };
  await change(contributor, 'approve', sign, 403);
  await change(maker, 'approve', sign, 403);
  await change(maker, 'remove', { fileId: file.id }, 409);
  await post('PC-CHANGED', period);
  close = await get();
  assert.equal(close.signoffStale, true);
  await change(checker, 'approve', sign, 409);
  await change(checker, 'return', { reason: 'New journals changed the ledger after submission.' });
  await importTrial();
  work.checks.bank = { ...work.checks.bank!, legacy: '250.00', bpz: '250.00' };
  await change(maker, 'save', { work });
  await change(maker, 'submit');
  await change(checker, 'approve', sign);
  assert.equal(close.packet?.status, 'approved');
  assert.equal(close.packet?.reviewedBy, 'close_checker');
  passCase('ledger tie-out, fresh review, locked submissions and independent maker/checker');

  const decision = { confirm: close.client.code, reason: 'The parallel close and cutover decision were acknowledged by the owner.' };
  await change(checker, 'activate', decision, 403);
  assert.match((await change(owner, 'activate', decision, 409)).error, /Go-live blocked/);
  process.env.BPZ_PUBLIC_ORIGIN = 'https://release.example.org';
  process.env.BPZ_ENFORCE_MFA_OWNER = 'true';
  process.env.BPZ_ENFORCE_MFA_CHECKERS = 'true';
  process.env.BPZ_BACKUP_SCHEDULE_ENABLED = 'true';
  process.env.BPZ_REQUIRE_OFFSITE_BACKUP = 'true';
  process.env.S3_BUCKET = 'cutover-fixture'; process.env.S3_REGION = 'us-east-1';
  process.env.S3_ACCESS_KEY_ID = 'fixture'; process.env.S3_SECRET_ACCESS_KEY = 'fixture';
  const { scope: installation, origin } = releaseScope(await getProvenance(db));
  const storage = backupStorageScope();
  assert.ok(installation && origin && storage);
  const now = new Date().toISOString();
  const sha256 = '1'.repeat(64);
  await writeReleaseProof(db, HTTPS_PROOF_KEY, { scope: installation, origin, verifiedAt: now });
  await db.insert(schema.systemSettings).values({ key: 'backup_status', value: { offsite: 'uploaded', lastSuccessAt: now, snapshotAt: now, storageScope: storage, sha256 } });
  // Do not start the real scheduled background worker in this direct API test.
  const { changeClose } = await import('../lib/parallelCloseService');
  const sessionOwner = { role: 'owner' as const, username: 'owner', status: 'active' as const, mfaEnabled: true, name: 'Owner', email: 'owner@example.invalid', makerLimit: 10000, canCheck: true };
  await assert.rejects(() => changeClose(sessionOwner, id, period, { ...decision, action: 'activate', version: close.packet?.version }), /Off-site restore verified/);
  await writeReleaseProof(db, RESTORE_PROOF_KEY, { scope: installation, storage, verifiedAt: now, tables: 48, rows: 200, sha256 });
  await assert.rejects(() => changeClose(sessionOwner, id, period, { ...decision, confirm: 'WRONG', action: 'activate', version: close.packet?.version }), /exact workspace code/);
  await changeClose(sessionOwner, id, period, { ...decision, action: 'activate', version: close.packet?.version });
  process.env.BPZ_BACKUP_SCHEDULE_ENABLED = 'false';
  close = await get(owner);
  assert.equal(close.packet?.status, 'active');
  assert.equal(close.activePeriod, period);
  assert.ok(close.history.some((e) => e.action === 'PARALLEL_LIVE_BOOKS'));
  assert.equal((await health.GET()).headers.get('x-bpz-deployment'), installation);
  passCase('synthesized release evidence gates owner decision in the isolated fixture');

  await post('PC-EARLIER', '2025-02', 409);
  await post('PC-FUTURE', '2025-04');
  const snapshot = await bootstrap.GET(req('GET', '/api/bootstrap?entity=1', owner));
  const state = (await snapshot.json()).state;
  assert.equal(state.clients[0].liveCutoverPeriod, period);
  assert.ok(state.closedPeriods.some((row: { clientId: number; period: string }) => row.clientId === 1 && row.period === period));
  let res = await sync.PUT(req('PUT', '/api/state', owner, { ...state, journalLines: [], closedPeriods: [] }));
  assert.equal(res.status, 409, await res.clone().text());
  assert.match((await res.json()).error, /Live-book cutover/);
  await db.insert(schema.bankAccounts).values({ id: 10, clientId: 1, code: 'CUT-BANK', name: 'Fixture bank', bankName: 'Fixture', accountNo: '000', currency: 'GHS', balance: 0, glAccount: '100000' });
  res = await trade.POST(req('POST', '/api/trade', owner, { action: 'create_payment', clientId: 1, idempotencyKey: randomUUID(), bankAccountId: 10, date: '2025-01-10', paymentType: 'customer_advance', partyName: 'Fixture payer', amount: 5 }));
  assert.equal(res.status, 409, await res.clone().text());
  assert.match((await res.json()).error, /Live-book cutover/);
  assert.equal((await db.select().from(schema.liveBooks).where(and(eq(schema.liveBooks.clientId, 1), eq(schema.liveBooks.period, period)))).length, 1);
  passCase('persistent live status, no historical journal or trade posting, no reopen, and later postings work');
  console.log(`Parallel close API: ${pass} workflow groups passed.`);
} finally { await pool.end(); }
