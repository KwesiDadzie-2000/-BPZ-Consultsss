import test from 'node:test';
import assert from 'node:assert/strict';
import { closeCents, parseLegacyTrial, compareTrial, CLOSE_CHECKS, controlResult, EMPTY_CHECK, periodEnd } from '../lib/parallelClose';
import { backupStorageScope, evaluateReleaseGates, releaseScope, verifyHttpsDeployment, type WorkspaceProvenance } from '../lib/releaseReadiness';

test('legacy closing trial parses quoted, BOM and semicolon exports as exact cents', () => {
  assert.deepEqual(parseLegacyTrial('\uFEFF"Account";"Debit";"Credit";"Currency"\r\n100000;45.09;0;GHS\r\n400000;0;45.09;GHS', 'GHS'), [
    { account: '100000', debit: 4509, credit: 0 }, { account: '400000', debit: 0, credit: 4509 },
  ]);
  assert.equal(closeCents('-0.01'), -1);
  assert.equal(closeCents(' 0.00 '), 0);
  for (const input of ['', '1,000.00', '1.123', '=7', '1e2', '90000000000000000000']) assert.equal(closeCents(input), null);
});

test('formats, duplicate accounts, mixed currencies and debit/credit ambiguity are refused', () => {
  for (const csv of [
    'Account,DR,CR\n100000,1,0', 'Account,Debit,Credit\n100000,1,0\n100000,0,1',
    'Account,Debit,Credit,Currency\n100000,0,1,USD', 'Account,Debit,Credit\n100000,1,4',
    'Account,Debit,Credit\n100000,,1', 'Account,Debit,Credit\n1000;5,12,0',
  ]) assert.throws(() => parseLegacyTrial(csv, 'GHS'));
});

test('equal total does not mask different accounts, wrong signs or missing schedules', () => {
  const original = parseLegacyTrial('Account,Debit,Credit\n100000,100.00,0\n400000,0,100.00', 'GHS');
  const mapped = parseLegacyTrial('Account,Debit,Credit\n100000,100.00,0\n410000,0,100.00', 'GHS');
  const compared = compareTrial(original, mapped);
  assert.equal(compared.bpzBalance, 0);
  assert.equal(compared.legacyBalance, 0);
  assert.equal(compared.differences, 2);
  const bank = CLOSE_CHECKS.find((c) => c.key === 'bank')!;
  assert.equal(controlResult(bank, { ...EMPTY_CHECK, reference: 'BANK-1', notes: 'Reconciled with source.' }).ready, false);
  assert.equal(controlResult(bank, { ...EMPTY_CHECK, reference: 'BANK-1', notes: 'Reconciled with source.', legacy: '0', bpz: '0' }).ready, true);
  assert.equal(periodEnd('2024-02'), '2024-02-29');
  assert.throws(() => periodEnd('2024-13'));
});

const now = Date.parse('2026-11-20T12:00:00Z');
const provenance: WorkspaceProvenance = { mode: 'production', installationId: '34d03c38-e197-432a-8b31-51e54de50a47', provisionedAt: '2025-01-01' };
const env = { BPZ_PUBLIC_ORIGIN: 'https://erp.example.org', BPZ_BOOTSTRAP_MODE: 'production', BPZ_DEPLOYMENT_ID: 'a-deployment-test-identifier',
  BPZ_ENFORCE_MFA_OWNER: 'true', BPZ_ENFORCE_MFA_CHECKERS: 'true', BPZ_BACKUP_SCHEDULE_ENABLED: 'true', BPZ_REQUIRE_OFFSITE_BACKUP: 'true',
  S3_BUCKET: 'private-example', S3_REGION: 'eu-west-1', S3_ACCESS_KEY_ID: 'test', S3_SECRET_ACCESS_KEY: 'test' };

test('production evidence is installation-bound and expires; preview and demo cannot go live', () => {
  const { scope, origin } = releaseScope(provenance, env);
  const storage = backupStorageScope(env);
  assert.ok(scope && origin && storage);
  const sha256 = 'a'.repeat(64);
  const verifiedAt = new Date(now - 6000).toISOString();
  const proofs = { provenance, ownerMfa: true, https: { scope, origin, verifiedAt },
    restore: { scope, storage, sha256, verifiedAt, tables: 50, rows: 410 },
    backup: { offsite: 'uploaded' as const, storageScope: storage, lastSuccessAt: verifiedAt, sha256 } };
  assert.ok(evaluateReleaseGates(proofs, env, now).every((gate) => gate.passed));
  assert.equal(evaluateReleaseGates({ ...proofs, approvedAt: verifiedAt }, env, now).find((g) => g.key === 'backup')?.passed, false);
  assert.equal(evaluateReleaseGates({ ...proofs, approvedAt: verifiedAt, backup: { ...proofs.backup, snapshotAt: verifiedAt } }, env, now).find((g) => g.key === 'backup')?.passed, true);
  assert.equal(releaseScope(undefined, env).scope, null);
  assert.equal(releaseScope(provenance, { ...env, BPZ_PUBLIC_ORIGIN: 'https://3000-test.e2b.app' }).scope, null);
  assert.equal(releaseScope(provenance, { ...env, BPZ_PUBLIC_ORIGIN: 'http://localhost' }).scope, null);
  for (const [key, changedEnv] of [['https', { ...env, BPZ_DEPLOYMENT_ID: 'different-installation-identifier' }],
    ['backup', { ...env, S3_BUCKET: 'moved-storage' }], ['restore', { ...env, S3_ENDPOINT: 'http://localhost:2194' }]] as const) {
    assert.equal(evaluateReleaseGates(proofs, changedEnv, now).find((gate) => gate.key === key)?.passed, false);
  }
  assert.equal(evaluateReleaseGates(proofs, env, now + 31 * 86_400_000).find((gate) => gate.key === 'restore')?.passed, false);
});

test('HTTPS verifier requires the right installation and a live sign-in page', async () => {
  const origin = 'https://erp.example.org';
  const scope = 'b'.repeat(64);
  const fake: typeof fetch = async (request, opts) => {
    assert.equal(opts?.redirect, 'error');
    return String(request).endsWith('/api/health') ? Response.json({ ok: true }, { headers: { 'x-bpz-deployment': scope } })
      : new Response('<title>BPZ Consult ERP</title>');
  };
  assert.equal((await verifyHttpsDeployment(origin, scope, fake)).scope, scope);
  await assert.rejects(() => verifyHttpsDeployment(origin, 'different', fake), /identify/);
  const blocked: typeof fetch = async () => new Response('Gateway refused', { status: 403 });
  await assert.rejects(() => verifyHttpsDeployment(origin, scope, blocked), /identify/);
});
