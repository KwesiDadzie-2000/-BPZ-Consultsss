import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";

/**
 * Posting-gate integration tests (destructive; disposable local DB only).
 *
 * These lock in the three guarantees the system advertises to clients and
 * auditors, on the NEW server-authoritative write paths as well as the old one:
 *   1. a CLOSED PERIOD cannot receive a posting,
 *   2. a document above the MAKER LIMIT cannot post without an independent checker,
 *   3. a machine credential cannot post above its granted limit.
 *
 * They exist because those controls were silently bypassed when the new write
 * paths were introduced — `closedPeriodKeys: new Set()` and no maker-checker
 * call — which let a closed month be posted into and a 5,000,000 invoice
 * through a 25,000 limit. A regression here is a control failure, not a bug.
 */
const url = process.env.BPZ_TEST_DATABASE_URL;
if (!url) throw new Error("Set BPZ_TEST_DATABASE_URL to the disposable local bpz_review_test database.");
const parsed = new URL(url);
if (!["localhost", "127.0.0.1"].includes(parsed.hostname) || parsed.pathname !== "/bpz_review_test") {
  throw new Error("Refusing to run against anything except a local bpz_review_test database.");
}
process.env.DATABASE_URL = url;
process.env.BPZ_SEED_PASSWORD_OWNER = `Gate-${randomUUID()}!`;
process.env.BPZ_SEED_PASSWORD_DEMO = `Gate-${randomUUID()}!`;

const { pool } = await import("../db");
await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");

const login = await import("../app/api/auth/login/route");
const registers = await import("../app/api/registers/route");
const migrate = await import("../app/api/migrate/route");
const apikeys = await import("../app/api/apikeys/route");
const v1invoices = await import("../app/api/v1/invoices/route");

let passed = 0;
let failed = 0;
async function check(title: string, action: () => Promise<void>) {
  try { await action(); passed++; console.log(`PASS ${title}`); }
  catch (e) { failed++; console.error(`FAIL ${title}`, e); }
}
const req = (path: string, method: string, body: unknown, token?: string) =>
  new Request(`http://localhost${path}`, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });

const ownerAuth = await login.POST(req("/api/auth/login", "POST", { usernameOrEmail: "owner", password: process.env.BPZ_SEED_PASSWORD_OWNER }));
const { token: owner } = await ownerAuth.json();
const demoAuth = await login.POST(req("/api/auth/login", "POST", { usernameOrEmail: "demo", password: process.env.BPZ_SEED_PASSWORD_DEMO }));
const { token: demo } = await demoAuth.json();

const invoice = (date: string, netRevenue: number) => ({
  action: "post_sales_invoice", clientId: 2, customerName: "Gate Test Customer",
  revenueStream: "GATE", netRevenue, vatOutput: 0, date, currency: "GHS",
});

await check("baseline: an open-period invoice within the owner's limit posts", async () => {
  const res = await registers.POST(req("/api/registers", "POST", invoice("2026-05-10", 1000), owner));
  assert.equal(res.status, 200, JSON.stringify(await res.clone().json()));
});

await check("CLOSED PERIOD: a register invoice into a locked month is refused", async () => {
  await pool.query("insert into closed_periods (client_id, period, closed_at, closed_by) values (2,'2026-03',now()::text,'owner') on conflict do nothing");
  const res = await registers.POST(req("/api/registers", "POST", invoice("2026-03-15", 500), owner));
  assert.equal(res.status, 409, JSON.stringify(await res.clone().json()));
  assert.match((await res.json()).error, /closed/i);
  // The seed already contains March activity, so assert on THIS posting, not the period.
  const rows = await pool.query("select count(*)::int n from journal_lines where client_id=2 and period='2026-03' and description like '%Gate Test Customer%'");
  assert.equal(rows.rows[0].n, 0, "the refused invoice must not reach the locked period");
});

await check("CLOSED PERIOD: migration cannot back-door a locked month", async () => {
  const csv = "Document,Date,Account,Debit,Credit,Description\nGATE-MIG,2026-03-20,621000,5000,0,x\nGATE-MIG,2026-03-20,100000,0,5000,x";
  const res = await migrate.POST(req("/api/migrate", "POST", { kind: "ledger", clientId: 2, content: csv, mode: "commit" }, owner));
  assert.equal(res.status, 409, JSON.stringify(await res.clone().json()));
  const rows = await pool.query("select count(*)::int n from journal_lines where doc_no='GATE-MIG'");
  assert.equal(rows.rows[0].n, 0, "migration must not write into a locked period");
});

await check("MAKER LIMIT: a user over their limit is refused", async () => {
  const res = await registers.POST(req("/api/registers", "POST", invoice("2026-05-11", 5_000_000), demo));
  assert.equal(res.status, 409, JSON.stringify(await res.clone().json()));
  assert.match((await res.json()).error, /maker limit|checker/i);
});

await check("MAKER LIMIT: the same user may still post within their limit", async () => {
  const res = await registers.POST(req("/api/registers", "POST", invoice("2026-05-12", 1000), demo));
  assert.equal(res.status, 200, JSON.stringify(await res.clone().json()));
});

await check("MACHINE CREDENTIAL: a new write key defaults to no posting authority", async () => {
  const created = await apikeys.POST(req("/api/apikeys", "POST", { name: "gate-key", scope: "write" }, owner));
  assert.equal(created.status, 200);
  const { key } = await created.json();
  const res = await v1invoices.POST(req("/api/v1/invoices", "POST", {
    clientId: 2, customerName: "API Customer", description: "x", netRevenue: 999_999, date: "2026-05-13", currency: "GHS",
  }, key));
  assert.equal(res.status, 409, JSON.stringify(await res.clone().json()));
  const rows = await pool.query("select count(*)::int n from sales_invoices where customer_name='API Customer'");
  assert.equal(rows.rows[0].n, 0, "a zero-limit key must not post anything");
});

await check("MACHINE CREDENTIAL: an API key is also blocked from a closed period", async () => {
  const created = await apikeys.POST(req("/api/apikeys", "POST", { name: "gate-key-closed", scope: "write", makerLimit: 1_000_000 }, owner));
  const { key } = await created.json();
  const res = await v1invoices.POST(req("/api/v1/invoices", "POST", {
    clientId: 2, customerName: "API Closed", description: "x", netRevenue: 10, date: "2026-03-05", currency: "GHS",
  }, key));
  assert.equal(res.status, 409, JSON.stringify(await res.clone().json()));
  assert.match((await res.json()).error, /closed/i);
});

await check("MACHINE CREDENTIAL: an explicitly granted key may post within its limit", async () => {
  const created = await apikeys.POST(req("/api/apikeys", "POST", { name: "gate-key-ok", scope: "write", makerLimit: 50_000 }, owner));
  const { key } = await created.json();
  const res = await v1invoices.POST(req("/api/v1/invoices", "POST", {
    clientId: 2, customerName: "API Allowed", description: "x", netRevenue: 25_000, date: "2026-05-14", currency: "GHS",
  }, key));
  assert.equal(res.status, 201, JSON.stringify(await res.clone().json()));
  const over = await v1invoices.POST(req("/api/v1/invoices", "POST", {
    clientId: 2, customerName: "API Over", description: "x", netRevenue: 60_000, date: "2026-05-15", currency: "GHS",
  }, key));
  assert.equal(over.status, 409, "a key cannot exceed its own granted limit");
});

await check("the ledger still balances after every refused and accepted posting", async () => {
  const res = await pool.query("select round(sum(debit)::numeric,2) d, round(sum(credit)::numeric,2) c from journal_lines");
  assert.equal(res.rows[0].d, res.rows[0].c, "refusals must not corrupt double entry");
});

await pool.end();
console.log(`\nPosting gate: ${passed} passed, ${failed} failed.`);
if (failed) process.exitCode = 1;
