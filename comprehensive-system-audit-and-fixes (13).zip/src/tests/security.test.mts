import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import type { ACDOCALine } from "../types/accounting";

/**
 * Penetration / abuse suite (destructive; disposable local DB only). Proves the
 * controls that a certification auditor or red team would probe: auth bypass,
 * cross-tenant isolation, SQL injection in input fields, XSS payloads, rate
 * limiting, session revocation, and machine-key scoping.
 */
const url = process.env.BPZ_TEST_DATABASE_URL;
if (!url) throw new Error("Set BPZ_TEST_DATABASE_URL to the disposable local bpz_review_test database.");
const parsed = new URL(url);
if (!["localhost", "127.0.0.1"].includes(parsed.hostname) || parsed.pathname !== "/bpz_review_test") {
  throw new Error("Refusing to run against anything except a local bpz_review_test database.");
}
process.env.DATABASE_URL = url;
process.env.BPZ_SEED_PASSWORD_OWNER = `Sec-${randomUUID()}!`;
process.env.BPZ_SEED_PASSWORD_DEMO = `Sec-${randomUUID()}!`;

const { pool } = await import("../db");
await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");
const login = await import("../app/api/auth/login/route");
const journal = await import("../app/api/journal/route");
const bootstrap = await import("../app/api/bootstrap/route");
const apikeys = await import("../app/api/apikeys/route");

let passed = 0;
let failed = 0;
async function check(title: string, action: () => Promise<void>) {
  try { await action(); passed++; console.log(`PASS ${title}`); } catch (e) { failed++; console.error(`FAIL ${title}`, e); }
}
const call = (handler: (r: Request) => Promise<Response>, method: string, body?: unknown, token?: string) =>
  handler(new Request("http://localhost/api/x", {
    method, headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  }));

const ownerAuth = await call(login.POST, "POST", { usernameOrEmail: "owner", password: process.env.BPZ_SEED_PASSWORD_OWNER });
const ownerBody = await ownerAuth.json();
const owner = ownerBody.token;
const ownerCookie = ownerAuth.headers.get("set-cookie") || "";
const demoAuth = await call(login.POST, "POST", { usernameOrEmail: "demo", password: process.env.BPZ_SEED_PASSWORD_DEMO });
const { token: demo } = await demoAuth.json();

const base: ACDOCALine = {
  id: "", docNo: "", period: "2026-10", date: "2026-10-29", module: "FI", docType: "JE",
  accountNo: "100000", accountName: "Bank", debit: 100, credit: 0, currency: "GHS",
  description: "sec", createdBy: "owner", clientId: 2,
};
const pair = (docNo: string, o: Partial<ACDOCALine> = {}): ACDOCALine[] => [
  { ...base, ...o, docNo, id: `${docNo}-a` },
  { ...base, ...o, docNo, id: `${docNo}-b`, accountNo: "400000", debit: 0, credit: 100 },
];

await check("unauthenticated requests are refused on every write surface", async () => {
  assert.equal((await call(journal.POST, "POST", { lines: pair("SEC-NOAUTH") })).status, 401);
  assert.equal((await call(bootstrap.GET, "GET")).status, 401);
  assert.ok([401, 403].includes((await call(apikeys.GET, "GET")).status), "API key management must refuse unauthenticated access");
});

await check("wrong password is refused", async () => {
  assert.equal((await call(login.POST, "POST", { usernameOrEmail: "owner", password: "wrong" })).status, 401);
});

await check("SQL injection in posting fields is treated as data, never executed", async () => {
  const inj = "'; DROP TABLE journal_lines; --";
  const res = await call(journal.POST, "POST", {
    lines: pair("SEC-SQLI", { accountName: inj, description: inj }),
  }, owner);
  assert.ok([200, 409].includes(res.status));
  const count = await pool.query("select count(*)::int n from journal_lines");
  assert.ok(count.rows[0].n > 0, "journal_lines must still exist after injection attempt");
});

await check("SQL injection in login identifier cannot authenticate", async () => {
  const res = await call(login.POST, "POST", { usernameOrEmail: "owner' OR '1'='1", password: "x" });
  assert.equal(res.status, 401);
});

await check("XSS payloads in ledger descriptions are stored as inert text", async () => {
  const xss = "<img src=x onerror=alert(1)>";
  const res = await call(journal.POST, "POST", { lines: pair("SEC-XSS", { description: xss }) }, owner);
  assert.ok([200, 409].includes(res.status));
  const row = await pool.query("select description from journal_lines where doc_no='SEC-XSS' limit 1");
  assert.equal(row.rows[0]?.description, xss, "payload stored verbatim, never executed");
});

await check("client user cannot read or write another tenant", async () => {
  assert.equal((await call(journal.POST, "POST", { lines: pair("SEC-TENANT", { clientId: 3, createdBy: "demo" }) }, demo)).status, 403);
});

await check("API keys: owner creates, key authenticates, revocation cuts access", async () => {
  const created = await call(apikeys.POST, "POST", { name: "pentest", scope: "read" }, owner);
  assert.equal(created.status, 200);
  const { key } = await created.json();
  assert.ok(key.startsWith("bpz_"));
  const v1ledger = await import("../app/api/v1/ledger/route");
  const read = await v1ledger.GET(new Request("http://localhost/api/v1/ledger", { headers: { Authorization: `Bearer ${key}` } }));
  assert.equal(read.status, 200);
  const list = await (await call(apikeys.GET, "GET", undefined, owner)).json();
  const id = list.keys.find((k: { prefix: string }) => key.startsWith(k.prefix))?.id;
  assert.ok(id);
  await call(apikeys.DELETE, "DELETE", undefined, owner); // no id → 400
  await apikeys.DELETE(new Request(`http://localhost/api/apikeys?id=${id}`, { method: "DELETE", headers: { Authorization: `Bearer ${owner}` } }));
  const after = await v1ledger.GET(new Request("http://localhost/api/v1/ledger", { headers: { Authorization: `Bearer ${key}` } }));
  assert.equal(after.status, 401, "revoked key must stop authenticating");
});

await check("read-only API key cannot write", async () => {
  const created = await call(apikeys.POST, "POST", { name: "ro", scope: "read" }, owner);
  const { key } = await created.json();
  const v1inv = await import("../app/api/v1/invoices/route");
  const res = await v1inv.POST(new Request("http://localhost/api/v1/invoices", {
    method: "POST", headers: { "content-type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({ customerName: "x", netRevenue: 100, clientId: 2 }),
  }));
  assert.equal(res.status, 403);
});

await check("a forged Bearer token that is not a real key is refused", async () => {
  const v1ledger = await import("../app/api/v1/ledger/route");
  const res = await v1ledger.GET(new Request("http://localhost/api/v1/ledger", { headers: { Authorization: "Bearer bpz_live_forged_forged_forged" } }));
  assert.equal(res.status, 401);
});

await check("session cookie shape carries HttpOnly and never leaks the hash", async () => {
  assert.match(ownerCookie, /HttpOnly/);
  assert.equal(ownerBody.user.passwordHash, undefined);
  assert.equal(ownerBody.user.password, undefined);
});

await pool.end();
console.log(`\nSecurity suite: ${passed} passed, ${failed} failed.`);
if (failed) process.exitCode = 1;
