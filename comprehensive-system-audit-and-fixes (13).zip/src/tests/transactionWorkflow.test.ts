import assert from 'node:assert/strict';
import { test } from 'node:test';
import { buildReceiptJournal, buildSupplierInvoiceJournal, hasUninvoicedReceipt } from '../utils/receiptAccounting';
import { buildAccountStatement, samePartyName } from '../utils/accountStatement';
import { registerSettlementError } from '../lib/registerIntegrity';
import { reconcileControlAccounts } from '../utils/controlAccounts';
import type { ACDOCALine, PurchaseOrder } from '../types/accounting';

const po: PurchaseOrder = {
  id: 'purchase-1', clientId: 2, poNo: 'PO-WH-001', vendorName: 'Supplier One Ltd',
  itemType: 'material', itemDescription: 'Raw material', itemCode: 'RM-1',
  qty: 5, unitPrice: 20, netAmount: 100, vatRecoverable: 20, totalAmount: 120,
  paidAmount: 0, status: 'Open', date: '2026-11-01', currency: 'GHS',
  glAccount: '120000', glAccountName: 'Stock', costCenter: 'CC-OPS', costCenterName: 'Operations',
};
const ctx = { clientId: 2, currency: 'GHS', username: 'owner', date: '2026-11-02' };
const money = (rows: ACDOCALine[], account: string) => rows.filter((line) => line.accountNo === account)
  .reduce((sum, line) => sum + Math.round((line.debit - line.credit) * 100), 0) / 100;

// Simulate warehouse → invoice → settlement; never claim invoice tax at GRN.
test('warehouse receipt recognises inventory and GRNI, NOT AP, tax, revenue or cash', () => {
  const lines = buildReceiptJournal(po, ctx);
  assert.equal(money(lines, '120000'), 100);
  assert.equal(money(lines, '204000'), -100);
  for (const account of ['200000', '125000', '100000', '400000']) assert.equal(money(lines, account), 0);
  assert.equal(lines.reduce((n, line) => n + line.debit - line.credit, 0), 0);
  assert.ok(lines.every((line) => line.clientId === 2 && line.docNo === po.poNo));
  assert.equal(hasUninvoicedReceipt(po, lines), true);
  assert.equal(hasUninvoicedReceipt({ ...po, clientId: 3 }, lines), false);
});

test('supplier invoice clears GRNI, claims only supported input VAT and opens AP', () => {
  const receipt = buildReceiptJournal(po, ctx);
  const bill = buildSupplierInvoiceJournal(po, { ...ctx, date: '2026-11-08' }, 'SUP-2026-31');
  assert.equal(money(bill, '204000'), 100);
  assert.equal(money(bill, '125000'), 20);
  assert.equal(money(bill, '200000'), -120);
  assert.equal(money([...receipt, ...bill], '204000'), 0);
  assert.equal(money([...receipt, ...bill], '200000'), -120);
  assert.equal(hasUninvoicedReceipt(po, [...receipt, ...bill]), false);
  assert.ok(bill.every((line) => line.reference === po.poNo && line.docNo === `BILL-${po.poNo}`));
  const exempt = buildSupplierInvoiceJournal({ ...po, vatRecoverable: 0, totalAmount: 100 }, ctx, 'NON-VAT-01');
  assert.equal(money(exempt, '125000'), 0);
  assert.equal(money(exempt, '200000'), -100);
  assert.throws(() => buildSupplierInvoiceJournal({ ...po, totalAmount: 110 }, ctx, 'BAD'), /do not agree/);
  assert.throws(() => buildSupplierInvoiceJournal(po, ctx, ' '), /reference is required/);
});

test('server register refuses unbilled receipts posing as supplier invoices', () => {
  const receipt = buildReceiptJournal(po, ctx);
  assert.equal(registerSettlementError([], [{ ...po, status: 'Goods Received' }], receipt, 'purchase order'), null);
  assert.match(registerSettlementError([], [{ ...po, status: 'Invoiced' }], receipt, 'purchase order') || '', /supplier invoice/);
  const postedBill = buildSupplierInvoiceJournal(po, ctx, 'SUP-31');
  assert.equal(registerSettlementError([{ ...po, status: 'Goods Received' }], [{ ...po, status: 'Invoiced' }], [...receipt, ...postedBill], 'purchase order'), null);
  // Supplier credits/payments debit AP, but the ORIGINAL invoice remains valid.
  const settled: ACDOCALine[] = [{ ...postedBill[0], id: 'credit', docNo: 'CN-1', reference: po.poNo, accountNo: '200000', debit: 20, credit: 0 },
    { ...postedBill[0], id: 'payment', docNo: 'PAY-1', reference: po.poNo, accountNo: '200000', debit: 100, credit: 0 }];
  assert.equal(registerSettlementError([{ ...po, status: 'Invoiced' }], [{ ...po, status: 'Paid', paidAmount: 120 }], [...receipt, ...postedBill, ...settled], 'purchase order'), null);
});

const gl = (over: Partial<ACDOCALine>): ACDOCALine => ({
  id: 'id', docNo: 'doc', period: '2026-11', date: '2026-11-01', module: 'MM', docType: 'PO',
  accountNo: '200000', accountName: 'Trade Payables (Supplier One Ltd)',
  debit: 0, credit: 0, currency: 'GHS', description: 'Posted', createdBy: 'owner', clientId: 2,
  ...over,
});

test('vendor statement excludes GRNI, uses posted AP, opens by date and segregates suppliers', () => {
  const lines = [
    gl({ id: 'r', docNo: po.poNo, accountNo: '204000', debit: 0, credit: 100, date: '2026-11-02' }),
    gl({ id: 'invoice', docNo: `BILL-${po.poNo}`, reference: po.poNo, credit: 120, date: '2026-11-08' }),
    gl({ id: 'other', docNo: 'BILL-OTHER', accountName: 'Trade Payables (Supplier One Ltd 2)', credit: 500, date: '2026-11-10' }),
    gl({ id: 'paid', docNo: 'PAY-1', accountName: 'Trade Payables & Supplier Balances', reference: po.poNo, debit: 70, date: '2026-11-12' }),
  ];
  const statement = buildAccountStatement({ side: 'vendor', party: { name: po.vendorName, code: 'V001', ids: [] },
    from: '2026-11-10', to: '2026-11-30', currency: 'GHS', lines, documents: [], payments: [], invoices: [], orders: [po] });
  assert.equal(statement.opening, 120);
  assert.equal(statement.closing, 50);
  assert.deepEqual(statement.rows.map((row) => row.id), ['paid']);
  assert.equal(statement.rows[0].balance, 50);
  assert.equal(samePartyName(' Supplier  One  Ltd ', po.vendorName), true);
  assert.equal(samePartyName('Supplier One Ltd 2', po.vendorName), false);
});

test('customer statement includes invoice, applied receipt, advance, reversals and no foreign records', () => {
  const input = {
    side: 'customer' as const,
    party: { name: 'Retail Ghana Ltd', code: 'C001', ids: ['cust-1'] },
    from: '2026-11-01', to: '2026-11-30', currency: 'GHS',
    lines: [
      gl({ id: 'sale', docNo: 'INV-1', accountNo: '110000', accountName: 'Trade Receivables (Retail Ghana Ltd)', debit: 240, credit: 0, date: '2026-11-02' }),
      gl({ id: 'receipt', docNo: 'PMT-1', reference: 'PMT-1', accountNo: '110000', accountName: 'Trade & Other Receivables', debit: 0, credit: 100, date: '2026-11-03' }),
      gl({ id: 'advance', docNo: 'ADV-1', reference: 'ADV-1', accountNo: '225000', debit: 0, credit: 30, date: '2026-11-04' }),
      gl({ id: 'reversal', docNo: 'REV-1', reference: 'REV-1', accountNo: '110000', debit: 100, credit: 0, date: '2026-11-05' }),
      gl({ id: 'wrong-currency', docNo: 'INV-USD', accountNo: '110000', accountName: 'Trade Receivables (Retail Ghana Ltd)', debit: 100, currency: 'USD' }),
      gl({ id: 'other-customer', docNo: 'INV-2', accountNo: '110000', accountName: 'Trade Receivables (Retail Ghana Ltd 2)', debit: 500 }),
    ],
    documents: [{ id: 'inv', docNo: 'INV-1', docType: 'sales_invoice', partyId: 'cust-1', partyName: 'Retail Ghana Ltd', postedAt: '2026-11-02' }],
    payments: [
      { id: 'p1', paymentNo: 'PMT-1', paymentType: 'customer_receipt', partyId: 'cust-1', partyName: 'Retail Ghana Ltd', reversalOf: null },
      { id: 'p2', paymentNo: 'ADV-1', paymentType: 'customer_advance', partyId: 'cust-1', partyName: 'Retail Ghana Ltd', reversalOf: null },
      { id: 'p3', paymentNo: 'REV-1', paymentType: 'reversal', partyId: 'cust-1', partyName: 'Retail Ghana Ltd', reversalOf: 'p1' },
    ],
    invoices: [], orders: [],
  };
  const result = buildAccountStatement(input);
  assert.deepEqual(result.rows.map((row) => row.id), ['sale', 'receipt', 'advance', 'reversal']);
  assert.equal(result.closing, 210);
  assert.equal(result.totalDebit, 340);
  assert.equal(result.totalCredit, 130);
  assert.equal(buildAccountStatement({ ...input, from: '2026-11-04' }).opening, 140);
  assert.equal(buildAccountStatement({ ...input, from: '2026-11-04', to: '2026-11-04' }).closing, 110);
});

test('GRNI control agrees after receipt and clears after the supplier invoice', () => {
  const cid = 12;
  const order = { ...po, clientId: cid, status: 'Goods Received' as const };
  const receipt = buildReceiptJournal(order, { ...ctx, clientId: cid });
  const afterReceipt = reconcileControlAccounts({
    clientId: cid, lines: receipt, invoices: [], orders: [order], stockItems: [], bankAccounts: [],
    assets: [], prepayments: [], prepaymentSchedules: [], payrollRecords: [], partners: [], taxEntries: [],
  });
  const grni = afterReceipt.find((row) => row.key === 'grni')!;
  const ap = afterReceipt.find((row) => row.key === 'payables');
  assert.equal(grni.status, 'reconciled');
  assert.equal(grni.gl, 100);
  assert.equal(grni.subLedger, 100);
  assert.ok(!ap || Math.abs(ap.gl) < 0.005);
  const bill = buildSupplierInvoiceJournal(order, { ...ctx, clientId: cid }, 'SUP-CTRL');
  const afterBill = reconcileControlAccounts({
    clientId: cid, lines: [...receipt, ...bill], invoices: [], orders: [{ ...order, status: 'Invoiced' }],
    stockItems: [], bankAccounts: [], assets: [], prepayments: [], prepaymentSchedules: [], payrollRecords: [], partners: [], taxEntries: [],
  });
  const grniAfter = afterBill.find((row) => row.key === 'grni');
  const apAfter = afterBill.find((row) => row.key === 'payables')!;
  assert.ok(!grniAfter || grniAfter.status === 'clear' || Math.abs(grniAfter.gl) < 0.005);
  assert.equal(apAfter.status, 'reconciled');
  assert.equal(apAfter.gl, 120);
});

test('cross-entity receipts and unmatched references do not leak into vendor accounts', () => {
  const statement = buildAccountStatement({ side: 'vendor', party: { name: po.vendorName, code: 'V001', ids: [] },
    from: '2026-11-01', to: '2026-11-30', currency: 'GHS',
    lines: [gl({ id: 'other', docNo: 'PO-OTHER', accountName: 'Trade Payables (Other Supplier)', credit: 1000, clientId: 3 }),
      gl({ id: 'unknown', docNo: 'UNLINKED', accountName: 'Trade Payables', credit: 200 })],
    documents: [], payments: [], invoices: [], orders: [po] });
  assert.equal(statement.closing, 0);
  assert.equal(statement.rows.length, 0);
  assert.ok(statement.unattributedCount >= 1);
});
