import type { ACDOCALine, PurchaseOrder, SalesInvoice } from '../types/accounting';

export type StatementSide = 'customer' | 'vendor';
export interface StatementParty { name: string; code: string; ids: string[] }
export interface StatementTradeDocument {
  id: string; docNo: string; docType: string; partyId: string | null; partyName: string; postedAt: Date | string | null;
}
export interface StatementPayment {
  id: string; paymentNo: string; paymentType: string; partyId: string | null; partyName: string; reversalOf: string | null;
}
export interface StatementRow {
  id: string; date: string; document: string; journal: string; description: string; account: string;
  debit: number; credit: number; balance: number;
}
export interface AccountStatement {
  opening: number; closing: number; totalDebit: number; totalCredit: number; rows: StatementRow[];
  /** Whole control-account lines that could not be attributed safely to any party. */
  unattributedCount: number;
}

const clean = (s: string | null | undefined) => (s || '').trim().replace(/\s+/g, ' ').toLocaleLowerCase();
const cents = (n: number) => Math.round((Number(n) || 0) * 100);
const money = (n: number) => n / 100;

/** Exact name only — never match "ABC Ltd" to "ABC Ltd 2". */
export function samePartyName(a: string | null | undefined, b: string | null | undefined): boolean {
  return !!clean(a) && clean(a) === clean(b);
}

/**
 * Build a journal-backed statement. Positive balance means the customer owes
 * the entity, or the entity owes the vendor. Credits/advances can yield a
 * negative balance. Amounts are in the entity's functional currency: the GL
 * contains translated posted values, never a sum of unrelated currencies.
 *
 * Source identities are joined by exact document references. For older quick
 * journals we use the party printed inside the control account's name, or the
 * linked quick invoice/PO number. Never infer a party by substring. Reversal
 * lines are included rather than filtering the original journal away.
 */
export function buildAccountStatement(input: {
  side: StatementSide;
  party: StatementParty;
  from: string;
  to: string;
  currency: string;
  lines: readonly ACDOCALine[];
  documents: readonly StatementTradeDocument[];
  payments: readonly StatementPayment[];
  invoices: readonly SalesInvoice[];
  orders: readonly PurchaseOrder[];
}): AccountStatement {
  const { side, party } = input;
  const ids = new Set(party.ids.filter(Boolean));
  const partyMatches = (row: { partyId: string | null; partyName: string }) =>
    row.partyId ? ids.has(row.partyId) : samePartyName(row.partyName, party.name);
  const customerTypes = new Set(['sales_invoice', 'customer_credit_note', 'customer_debit_note']);
  const vendorTypes = new Set(['supplier_invoice', 'supplier_credit_note', 'supplier_debit_note']);
  const sources = new Set<string>();
  const paymentSources = new Set<string>();
  for (const doc of input.documents) {
    if (!doc.postedAt || !(side === 'customer' ? customerTypes : vendorTypes).has(doc.docType)) continue;
    if (partyMatches(doc)) sources.add(doc.docNo);
  }
  const byPaymentId = new Map(input.payments.map((payment) => [payment.id, payment]));
  for (const payment of input.payments) {
    const original = payment.paymentType === 'reversal' && payment.reversalOf ? byPaymentId.get(payment.reversalOf) : payment;
    if (!original) continue;
    const rightSide = side === 'vendor' ? original.paymentType === 'supplier_payment'
      : original.paymentType === 'customer_receipt' || original.paymentType === 'customer_advance';
    if (rightSide && partyMatches(original)) { sources.add(payment.paymentNo); paymentSources.add(payment.paymentNo); }
  }
  if (side === 'customer') {
    for (const invoice of input.invoices) if (samePartyName(invoice.customerName, party.name)) sources.add(invoice.invNo);
  } else {
    for (const order of input.orders) if (samePartyName(order.vendorName, party.name)) sources.add(order.poNo);
  }
  const control = side === 'customer' ? '110000' : '200000';
  const advance = side === 'customer' ? '225000' : '116000';
  const relevant = input.lines.filter((line) => {
    if (line.date > input.to || line.currency.toUpperCase() !== input.currency.toUpperCase()) return false;
    if (line.accountNo !== control && line.accountNo !== advance) return false;
    const refs = [line.docNo, line.reference || ''];
    if (refs.some((ref) => sources.has(ref))) {
      // 116000/225000 are broader control accounts; include them only when
      // explicitly linked to a trading payment, not a generic prepayment.
      return line.accountNo === control || refs.some((ref) => paymentSources.has(ref));
    }
    if (line.accountNo !== control) return false;
    const match = line.accountName.match(/^(?:trade\s+(?:and\s+other\s+)?(?:receivables|payables)|accounts?\s+(?:receivable|payable))\s*\((.+)\)$/i);
    return !!match && samePartyName(match[1], party.name);
  });
  relevant.sort((a, b) => a.date.localeCompare(b.date) || a.docNo.localeCompare(b.docNo) || a.id.localeCompare(b.id));
  const signed = (line: ACDOCALine) => side === 'customer'
    ? cents(line.debit) - cents(line.credit)
    : cents(line.credit) - cents(line.debit);
  let balance = relevant.filter((line) => line.date < input.from).reduce((sum, line) => sum + signed(line), 0);
  const opening = balance;
  let totalDebit = 0;
  let totalCredit = 0;
  const rows: StatementRow[] = [];
  for (const line of relevant) {
    if (line.date < input.from) continue;
    totalDebit += cents(line.debit);
    totalCredit += cents(line.credit);
    balance += signed(line);
    rows.push({
      id: line.id, date: line.date, document: line.reference || line.docNo,
      journal: line.docNo, description: line.description, account: line.accountNo,
      debit: money(cents(line.debit)), credit: money(cents(line.credit)), balance: money(balance),
    });
  }
  // Do not assign an unattributed control line to a customer or vendor merely
  // to make the control account reconcile. Surface that uncertainty instead.
  const documentRefs = new Set(input.documents.map((doc) => doc.docNo));
  const paymentRefs = new Set(input.payments.map((payment) => payment.paymentNo));
  const quickRefs = new Set(side === 'customer' ? input.invoices.map((row) => row.invNo) : input.orders.map((row) => row.poNo));
  const unattributedCount = input.lines.filter((line) => line.accountNo === control && line.date <= input.to
    && line.currency.toUpperCase() === input.currency.toUpperCase()
    && !documentRefs.has(line.reference || '') && !paymentRefs.has(line.reference || '')
    && !quickRefs.has(line.docNo) && !quickRefs.has(line.reference || '')
    && !/^(?:trade\s+(?:and\s+other\s+)?(?:receivables|payables)|accounts?\s+(?:receivable|payable))\s*\(.+\)$/i.test(line.accountName)).length;
  return { opening: money(opening), closing: money(balance), totalDebit: money(totalDebit), totalCredit: money(totalCredit), rows, unattributedCount };
}
