import type { ACDOCALine } from '../types/accounting';
import { isValidIsoDate } from '../lib/journalValidation';

/** In a bank statement debit means money OUT, credit means money IN (opposite the asset GL). */
export interface StatementLine {
  date: string;
  description: string;
  debit: number;
  credit: number;
  balance?: number;
  reference?: string;
  row?: number;
}

export interface StatementMatchResult {
  line: StatementLine;
  matched: boolean;
  matchedDocNo?: string;
  matchedLineId?: string;
  days?: number;
  net: number;
  ambiguous?: boolean;
}

export type StatementConvention = 'debit-is-out' | 'debit-is-in';
export type StatementDateOrder = 'day-first' | 'month-first';
type Columns = Record<'date' | 'description' | 'debit' | 'credit' | 'amount' | 'balance' | 'reference', number>;
export interface StatementImportReport {
  lines: StatementLine[];
  totalRows: number;
  skippedRows: number;
  skippedSamples: string[];
  delimiter: string;
  headerDetected: boolean;
  columns: Columns;
  convention: StatementConvention;
  totals: { out: number; in: number; net: number };
  warnings: string[];
}

export const MAX_STATEMENT_BYTES = 5 * 1024 * 1024;
const MAX_ROWS = 20_000;
const DAY_MS = 86_400_000;
const dateNumber = (date: string) => Date.parse(`${date}T00:00:00Z`) / DAY_MS;
const pad2 = (n: number) => String(n).padStart(2, '0');
const minor = (n: number) => Math.round(n * 100);
const months = 'jan feb mar apr may jun jul aug sep oct nov dec'.split(' ');
const iso = (year: number, month: number, day: number) => {
  if (year < 100) year += year < 70 ? 2000 : 1900;
  if (year < 1900 || year > 2999) return null;
  const date = `${year}-${pad2(month)}-${pad2(day)}`;
  return isValidIsoDate(date) ? date : null;
};
export function parseStatementDate(raw: string, order: StatementDateOrder = 'day-first'): string | null {
  const value = raw.trim();
  const ymd = value.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?)?$/);
  if (ymd) return iso(+ymd[1], +ymd[2], +ymd[3]);
  const named = value.match(/^(\d{1,2})[-/.\s]+([A-Za-z]{3,9})[-/.\s]+(\d{2}|\d{4})$/)
    || value.match(/^([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{2}|\d{4})$/);
  if (named) {
    const dayFirst = /^\d/.test(named[1]);
    const month = months.indexOf(named[dayFirst ? 2 : 1].slice(0, 3).toLowerCase()) + 1;
    return iso(+named[3], month, +named[dayFirst ? 1 : 2]);
  }
  const short = value.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2}|\d{4})$/);
  if (!short) return null;
  const [, a, b, year] = short.map(Number);
  const firstIsMonth = b > 12 || (a <= 12 && order === 'month-first');
  return firstIsMonth ? iso(year, a, b) : iso(year, b, a);
}

const currency = '(?:GH[₵¢]|GHS|GHC|USD|EUR|GBP|NGN|ZAR|KES|TZS|XOF|XAF|AUD|CAD|JPY|CHF|[$£€₵¢₦])';
const currencyStart = new RegExp(`^${currency}\\s*`, 'i');
const currencyEnd = new RegExp(`\\s*${currency}$`, 'i');

/** Parse a monetary cell without silently stripping unknown text or shifting columns. */
export function parseStatementAmount(raw: string): number | null {
  let value = raw.trim().replace(/\u2212/g, '-').replace(/[\u00a0\u202f]/g, ' ');
  if (!value || /^[-–—]$/.test(value)) return 0;
  let sign: number | undefined;
  if (value.startsWith('(') && value.endsWith(')')) { sign = -1; value = value.slice(1, -1).trim(); }
  const suffix = value.match(/\s*(DR|CR)$/i);
  if (suffix) {
    if (sign !== undefined) return null;
    sign = suffix[1].toUpperCase() === 'DR' ? -1 : 1;
    value = value.slice(0, -suffix[0].length);
  }
  value = value.replace(currencyStart, '').replace(currencyEnd, '');
  const marker = value.match(/^[+-]|[+-]$/);
  if (marker) {
    if (sign !== undefined) return null;
    sign = marker[0] === '-' ? -1 : 1;
    value = value.replace(/^[+-]|[+-]$/, '').trim().replace(currencyStart, '').replace(currencyEnd, '');
  }
  if (/^\d{1,3}( \d{3})+([.,]\d{1,2})?$/.test(value)) value = value.replace(/ /g, '');
  if (/^\d{1,3}(,\d{3})+(\.\d{1,2})?$/.test(value)) value = value.replace(/,/g, '');
  else if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(value)) value = value.replace(/\./g, '').replace(',', '.');
  else if (/^\d+,\d{1,2}$/.test(value)) value = value.replace(',', '.');
  if (!/^\d+(\.\d{1,2})?$/.test(value)) return null;
  const cents = minor(Number(value));
  return Number.isSafeInteger(cents) ? ((sign ?? 1) * cents) / 100 : null;
}

const aliases: Record<keyof Columns, readonly string[]> = {
  date: ['value date', 'valuedate', 'date', 'transaction date', 'txn date', 'posting date', 'posted date', 'booking date', 'booked'],
  description: ['description', 'details', 'detail', 'narrative', 'narration', 'remarks', 'memo', 'transaction', 'particulars', 'info'],
  debit: ['debit', 'withdrawal', 'withdrawals', 'money out', 'paid out', 'out', 'dr', 'debits', 'withdrawal amount', 'debit amount'],
  credit: ['credit', 'deposit', 'deposits', 'money in', 'paid in', 'in', 'cr', 'credits', 'deposit amount', 'credit amount'],
  amount: ['amount', 'value', 'transaction amount', 'amt', 'sum'],
  balance: ['balance', 'running balance', 'closing balance', 'book balance', 'available balance'],
  reference: ['reference', 'reference no', 'ref', 'cheque', 'check', 'cheque no', 'transaction id', 'txn id', 'voucher', 'doc no'],
};
const blankColumns = (): Columns => ({ date: -1, description: -1, debit: -1, credit: -1, amount: -1, balance: -1, reference: -1 });
const fields = Object.keys(aliases) as (keyof Columns)[];
const footer = /^(?:grand total|total|totals|subtotal|opening balance|closing balance|brought forward|carried forward|balance [bc]\/f|[bc]\/f|running balance)\s*:?$/i;
const delimiters = [',', ';', '\t', '|'] as const;

interface CsvRow { fields: string[]; row: number; malformed: boolean }
function readRows(text: string, delimiter: string, limit: number): CsvRow[] {
  const rows: CsvRow[] = [];
  let cells: string[] = [];
  let field = '';
  let quoted = false;
  let closed = false;
  let malformed = false;
  let row = 1;
  let physical = 1;
  const push = () => {
    cells.push(field);
    if (malformed || cells.some((cell) => cell.trim())) rows.push({ fields: cells, row, malformed });
    cells = []; field = ''; closed = false; malformed = false;
  };
  for (let i = 0; i < text.length && rows.length < limit; i++) {
    const c = text[i];
    if (c === '\r' || c === '\n') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      physical++;
      if (quoted) field += '\n';
      else { push(); row = physical; }
    } else if (quoted) {
      if (c !== '"') field += c;
      else if (text[i + 1] === '"') { field += '"'; i++; }
      else { quoted = false; closed = true; }
    } else if (c === delimiter) {
      cells.push(field); field = ''; closed = false;
    } else if (c === '"') {
      if (field.trim() || closed) malformed = true;
      else { field = ''; quoted = true; }
    } else if (closed) {
      if (c !== ' ' && c !== '\t') malformed = true;
    } else field += c;
  }
  if (rows.length < limit) { malformed ||= quoted; push(); }
  return rows;
}

function mapHeader(cells: string[]): Columns {
  const normal = cells.map((c) => c.trim().toLowerCase().replace(/\s*\([a-z]{3}\)$/, '').replace(/[_-]+/g, ' ').replace(/\s+/g, ' '));
  const mapped = blankColumns();
  for (const field of fields) {
    for (const alias of aliases[field]) {
      const i = normal.indexOf(alias);
      if (i >= 0) { mapped[field] = i; break; }
    }
  }
  return mapped;
}

export function parseStatementReport(text: string, options: { convention?: StatementConvention; dateOrder?: StatementDateOrder } = {}): StatementImportReport {
  const convention = options.convention ?? 'debit-is-out';
  const source = text.replace(/^\uFEFF/, '');
  const probes = delimiters.map((delimiter) => {
    const sample = readRows(source.slice(0, 65_536), delimiter, 35);
    const header = sample.findIndex((r) => {
      const m = mapHeader(r.fields);
      return !r.malformed && m.date >= 0 && (m.debit >= 0 || m.credit >= 0 || m.amount >= 0);
    });
    const width = sample.find((r) => r.fields.length >= 3 && parseStatementDate(r.fields[0], options.dateOrder))?.fields.length ?? 0;
    const score = header >= 0 ? 100 + fields.filter((f) => mapHeader(sample[header].fields)[f] >= 0).length
      : sample.filter((r) => !r.malformed && r.fields.length === width && width >= 3 && parseStatementDate(r.fields[0], options.dateOrder)).length;
    return { delimiter, header, width, score };
  });
  const { delimiter, header, width } = probes.sort((a, b) => b.score - a.score)[0];
  const report: StatementImportReport = { lines: [], totalRows: 0, skippedRows: 0, skippedSamples: [], delimiter,
    headerDetected: header >= 0, columns: blankColumns(), convention, totals: { out: 0, in: 0, net: 0 }, warnings: [] };
  if (source.length > MAX_STATEMENT_BYTES) { report.warnings.push('Choose an export no larger than 5 MB.'); return report; }
  const rows = readRows(source, delimiter, MAX_ROWS + 36).slice(header + 1);
  const headerCells = header >= 0 ? readRows(source, delimiter, header + 1)[header].fields : null;
  const expectedWidth = headerCells?.length ?? width;
  report.columns = headerCells ? mapHeader(headerCells) : { ...blankColumns(), date: 0, description: 1,
    ...(width === 3 ? { amount: 2 } : { debit: 2, credit: 3 }), ...(width === 5 ? { balance: 4 } : {}) };
  if (!headerCells) report.warnings.push('No header recognised. Use Date, Description, Debit, Credit (optional Balance), or Date, Description, Amount.');
  const col = report.columns;
  const explicitMoneyOut = col.debit >= 0 && !['debit', 'debit amount', 'dr', 'debits'].includes((headerCells?.[col.debit] ?? '').trim().toLowerCase().replace(/\s*\([a-z]{3}\)$/i, ''));
  const explicitMoneyIn = col.credit >= 0 && !['credit', 'credit amount', 'cr', 'credits'].includes((headerCells?.[col.credit] ?? '').trim().toLowerCase().replace(/\s*\([a-z]{3}\)$/i, ''));
  const flip = convention === 'debit-is-in' && (col.amount >= 0 || !headerCells || (!explicitMoneyOut && !explicitMoneyIn));
  if (convention === 'debit-is-in' && !flip) report.warnings.push('Deposit / withdrawal labels are explicit; their directions have not been flipped.');
  if (rows.length > MAX_ROWS) { report.warnings.push('This statement exceeds 20,000 rows. Split the export by date and import each part separately.'); return report; }
  let inMinor = 0;
  let outMinor = 0;
  for (const { fields: cells, row, malformed } of rows) {
    report.totalRows++;
    const cell = (index: number) => (cells[index] ?? '').trim();
    const skip = (reason?: string) => {
      report.skippedRows++;
      if (reason && report.skippedSamples.length < 5) report.skippedSamples.push(`Row ${row}: ${reason}`);
    };
    const date = parseStatementDate(cell(col.date), options.dateOrder);
    if (footer.test(cell(col.description)) || (!date && (footer.test(cell(col.date)) || /^sep=[,;|\t]$/i.test(cells.join(delimiter).trim())))) { skip(); continue; }
    if (malformed || cells.length !== expectedWidth || expectedWidth < 3 && !headerCells || !headerCells && expectedWidth > 5) { skip('unexpected columns or invalid quotes; quote values containing the delimiter'); continue; }
    if (!date) { skip('unreadable or impossible date'); continue; }
    let out: number;
    let inflow: number;
    if (col.amount >= 0 && col.debit < 0 && col.credit < 0) {
      const amount = parseStatementAmount(cell(col.amount));
      if (amount === null) { skip('unreadable amount'); continue; }
      out = Math.max(0, -amount); inflow = Math.max(0, amount);
    } else {
      const debit = parseStatementAmount(cell(col.debit));
      const credit = parseStatementAmount(cell(col.credit));
      if (debit === null || credit === null) { skip('unreadable debit or credit'); continue; }
      out = Math.abs(debit); inflow = Math.abs(credit);
    }
    if (out && inflow) { skip('both debit and credit are populated'); continue; }
    if (!out && !inflow) { skip(); continue; }
    if (flip) [out, inflow] = [inflow, out];
    if (!Number.isSafeInteger(inMinor + minor(inflow)) || !Number.isSafeInteger(outMinor + minor(out))) {
      report.warnings.push('Statement totals exceed supported monetary precision. Split the file and check its amounts.');
      report.lines = []; return report;
    }
    const balance = cell(col.balance) ? parseStatementAmount(cell(col.balance)) ?? undefined : undefined;
    const reference = cell(col.reference) || undefined;
    report.lines.push({ date, description: cell(col.description) || reference || '(no description)', debit: out, credit: inflow, balance, reference, row });
    inMinor += minor(inflow); outMinor += minor(out);
  }
  report.totals = { in: inMinor / 100, out: outMinor / 100, net: (inMinor - outMinor) / 100 };
  if (!report.lines.length) report.warnings.push('No usable transactions. Export CSV or delimited text from the bank; PDF and Excel workbooks cannot be imported here.');
  return report;
}

export function parseStatementCsv(text: string, options: { convention?: StatementConvention; dateOrder?: StatementDateOrder } = {}): StatementLine[] {
  return parseStatementReport(text, options).lines;
}

// Index by day, amount and direction so reconciliation does not rescan the ledger for every row.
export function matchStatementLines(statement: readonly StatementLine[], journal: readonly ACDOCALine[], gl: string, windowDays = 5): StatementMatchResult[] {
  const limit = Number.isFinite(windowDays) ? Math.max(0, Math.min(31, Math.trunc(windowDays))) : 5;
  const base = new Map<string, Set<ACDOCALine>>();
  const byReference = new Map<string, Set<ACDOCALine>>();
  const norm = (v?: string | null) => v?.trim().toUpperCase() || '';
  const available = new Map<ACDOCALine, Set<ACDOCALine>[]>();
  const add = (index: Map<string, Set<ACDOCALine>>, key: string, row: ACDOCALine) => {
    let set = index.get(key);
    if (!set) { set = new Set(); index.set(key, set); }
    set.add(row);
    available.get(row)!.push(set);
  };
  for (const row of journal) {
    if (row.accountNo !== gl || row.isReversed || !isValidIsoDate(row.date) || (row.debit > 0) === (row.credit > 0)) continue;
    const amount = minor(row.debit - row.credit);
    if (!Number.isSafeInteger(amount) || !amount) continue;
    const key = `${amount}:${dateNumber(row.date)}`;
    available.set(row, []);
    add(base, key, row);
    for (const ref of new Set([norm(row.docNo), norm(row.reference)])) if (ref) add(byReference, `${key}:${ref}`, row);
  }
  const results: StatementMatchResult[] = statement.map((line) => ({ line, matched: false, net: (minor(line.credit) - minor(line.debit)) / 100 }));
  const search = (result: StatementMatchResult, reference: string) => {
    const { line } = result;
    if (result.matched || line.credit > 0 && line.debit > 0 || !result.net || !isValidIsoDate(line.date)) return;
    const day = dateNumber(line.date);
    const candidates = reference ? byReference : base;
    const amount = minor(result.net);
    for (let offset = 0; offset <= limit; offset++) {
      const keys = offset === 0 ? [day] : [day - offset, day + offset];
      const buckets = keys.map((d) => candidates.get(`${amount}:${d}${reference ? `:${reference}` : ''}`));
      const count = buckets.reduce((n, b) => n + (b?.size ?? 0), 0);
      if (!count) continue;
      if (count > 1) { result.ambiguous = true; return; }
      const match = buckets.find((b) => b?.size)?.values().next().value;
      if (!match) return;
      Object.assign(result, { matched: true, ambiguous: false, matchedDocNo: match.docNo, matchedLineId: match.id, days: offset });
      for (const bucket of available.get(match) ?? []) bucket.delete(match);
      return;
    }
  };
  // Explicit references get first choice, before generic amount/date matches consume a journal line.
  for (const record of results) if (record.line.reference) search(record, norm(record.line.reference));
  for (const record of results) if (!record.ambiguous) search(record, '');
  return results;
}
