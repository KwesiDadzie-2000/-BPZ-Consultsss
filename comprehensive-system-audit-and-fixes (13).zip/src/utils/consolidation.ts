import { aggregateTrialBalance } from './reports';
import type { ACDOCALine, AccountMaster, ClientEntity } from '../types/accounting';
import { isDebitNormal } from './ledger';

/**
 * IFRS 10 group consolidation engine (pro-forma working paper).
 *
 * The desk is an OWNER-ONLY analysis, not a posting engine. Every number is
 * derived from posted journal lines plus explicit owner inputs (hold %,
 * investment, exchange rate) — never fabricated accounting facts.
 *
 * Units: trial-balance aggregation works in MINOR units (cents), exactly like
 * the rest of the reporting engine. Owner inputs (investment) are entered in
 * major units and converted internally.
 *
 * Pipeline (documented on the desk and in docs/SETUP_GUIDE.md):
 *   1. Control establishment: hold % > 50 % ⇒ full consolidation (100 %);
 *      ≤ 50 % ⇒ excluded from consolidation (equity-method only).
 *   2. Translation: subsidiary lines are translated to the parent's
 *      functional currency at the closing rate (IAS 21 / IFRS 21). P&L use of
 *      the average rate is NOT modelled — stated as a limitation.
 *   3. Intercompany elimination: 110000 (parent AR) matched by exact party
 *      against 200000 (subsidiary AP); eliminate min(AR, AP) per controlled sub.
 *   4. Goodwill (IFRS 3, pragmatic formula): max(0, investment − hold% × NAV).
 *   5. NCI (IFRS 10): NCI% × (subsidiary NAV + goodwill).
 *   6. Totals foot: consolidated assets = parent-retained equity + NCI + liabilities.
 */

export type GroupInput = {
  id: number; // client id
  holdPct: number; // % of voting rights held by the parent (0–100)
  exchangeRate: number; // parent currency per 1 subsidiary unit (1 = same currency)
  investment?: number; // parent's investment cost (MAJOR parent currency)
};

export interface ConsolidatedRow {
  account: string;
  name: string;
  type: 'Asset' | 'Liability' | 'Equity' | 'Income' | 'Expense';
  parent: number; // MINOR parent currency
  subsidiary: number; // MINOR parent currency (translated)
  consolidated: number; // MINOR parent currency
}

export interface EliminationPair {
  parentId: number;
  subsidiaryId: number;
  party: string;
  ar: number; // MINOR parent currency
  ap: number; // MINOR parent currency
  eliminated: number; // MINOR parent currency
}

export interface EntityConsolidation {
  id: number;
  name: string;
  code: string;
  currency: string;
  holding: number;
  nCiPct: number;
  rate: number;
  included: boolean;
  reason: string;
  assets: number; // MAJOR parent currency
  liabilities: number; // MAJOR parent currency
  equity: number; // MAJOR parent currency (= assets − liabilities; subsidiary NAV)
  goodwill: number; // MAJOR parent currency
  nCi: number; // MAJOR parent currency
}

export interface ConsolidationTotals {
  assets: number; // MAJOR parent currency
  liabilities: number;
  equity: number; // group equity incl NCI
  goodwill: number;
  nci: number;
  parentRetained: number; // group equity − NCI
  eliminations: number; // total intercompany AR/AP eliminated (MAJOR)
}

export interface ConsolidationResult {
  parentCurrency: string;
  parentCode: string;
  parentName: string;
  rows: ConsolidatedRow[];
  entities: EntityConsolidation[];
  eliminations: EliminationPair[];
  errors: string[];
  totals: ConsolidationTotals;
  balanced: boolean;
  method: string;
}

const MINOR = (n: number) => Math.round(n * 100);
const MAJOR = (c: number) => Math.round(c) / 100;

function partyFromName(accountName: string): string | null {
  const m = accountName.match(/\((.+)\)\s*$/);
  return m ? m[1].trim() : null;
}

function trialRows(lines: ACDOCALine[], accounts: AccountMaster[]) {
  const map = new Map<string, { code: string; name: string; type: 'Asset' | 'Liability' | 'Equity' | 'Income' | 'Expense'; net: number }>();
  for (const row of aggregateTrialBalance(lines, accounts)) {
    map.set(row.code, { code: row.code, name: row.name, type: row.type as never, net: row.dr - row.cr });
  }
  return map;
}

function translateLines(lines: ACDOCALine[], rate: number): ACDOCALine[] {
  return lines.map((l) => ({
    ...l,
    debit: Math.round(l.debit * rate * 100) / 100,
    credit: Math.round(l.credit * rate * 100) / 100,
    currency: 'parent',
  }));
}

/** Parent AR (110000) vs subsidiary AP (200000) matched by exact party name. ALL values in MINOR units of the parent currency. */
function intercompanyEliminations(parentLines: ACDOCALine[], subLines: ACDOCALine[]): EliminationPair[] {
  const ar = new Map<string, number>();
  const ap = new Map<string, number>();
  for (const line of parentLines) {
    if (line.accountNo !== '110000') continue;
    const party = partyFromName(line.accountName);
    if (!party) continue;
    ar.set(party, (ar.get(party) ?? 0) + MINOR(line.debit) - MINOR(line.credit));
  }
  for (const line of subLines) {
    if (line.accountNo !== '200000') continue;
    const party = partyFromName(line.accountName);
    if (!party) continue;
    ap.set(party, (ap.get(party) ?? 0) + MINOR(line.credit) - MINOR(line.debit));
  }
  const out: EliminationPair[] = [];
  for (const party of new Set([...ar.keys(), ...ap.keys()])) {
    const arVal = ar.get(party) ?? 0;
    const apVal = ap.get(party) ?? 0;
    const eliminated = Math.min(Math.max(0, arVal), Math.max(0, apVal));
    if (eliminated > 0) out.push({ parentId: 0, subsidiaryId: 0, party, ar: arVal, ap: apVal, eliminated });
  }
  return out;
}

export function parentOf(clients: ClientEntity[]): ClientEntity | null {
  return clients.find((c) => c.isParent) ?? null;
}

export function consolidateGroup(input: {
  parent: ClientEntity;
  entities: Array<{ client: ClientEntity; input: GroupInput; lines: ACDOCALine[] }>;
  accounts: AccountMaster[];
}): ConsolidationResult {
  const { parent, entities, accounts } = input;
  const errors: string[] = [];
  const parentCurrency = parent.currency.toUpperCase();
  const parentLines = entities.find((e) => e.client.id === parent.id)?.lines ?? [];
  const parentTrial = aggregateTrialBalance(parentLines, accounts);

  // ─── Per-subsidiary processing ──────────────────────────────────────────
  const subs: Array<{
    client: ClientEntity; input: GroupInput; lines: ACDOCALine[];
    included: boolean; reason: string; assets: number; liabilities: number; equity: number; nav: number;
    goodwill: number; nci: number; elimination: number;
  }> = [];
  const eliminations: EliminationPair[] = [];

  for (const { client, input: g, lines: rawLines } of entities) {
    if (client.id === parent.id) continue;
    const holding = g.holdPct;
    const nCiPct = Math.max(0, 100 - holding);
    const controlled = holding > 50;
    if (!controlled) {
      errors.push(`${client.code} (${client.name}): hold ${holding}% — below 50% control, excluded from consolidation (equity-method only).`);
      subs.push({ client, input: g, lines: rawLines, included: false, reason: `Hold ${holding}% (<50% control)`, assets: 0, liabilities: 0, equity: 0, nav: 0, goodwill: 0, nci: 0, elimination: 0 });
      continue;
    }
    if (client.currency.toUpperCase() !== parent.currency.toUpperCase() && (!Number.isFinite(g.exchangeRate) || g.exchangeRate <= 0)) {
      errors.push(`${client.code} (${client.name}): enter a closing exchange rate to translate ${client.currency} — this subsidiary is excluded from consolidated totals until a rate is supplied.`);
      subs.push({ client, input: g, lines: rawLines, included: false, reason: 'Exchange rate not set', assets: 0, liabilities: 0, equity: 0, nav: 0, goodwill: 0, nci: 0, elimination: 0 });
      continue;
    }
    const lines = g.exchangeRate !== 1 ? translateLines(rawLines, g.exchangeRate) : rawLines;
    const subTrial = aggregateTrialBalance(lines, accounts);
    let assets = 0;
    let liabilities = 0;
    for (const row of subTrial) {
      const net = row.dr - row.cr;
      if (row.type === 'Asset') assets += net;
      else if (row.type === 'Liability') liabilities += -net;
    }
    const equity = assets - liabilities; // subsidiary NAV
    const nav = equity;
    // Intercompany elimination vs parent (parent AR vs this subsidiary AP).
    const pairs = intercompanyEliminations(parentLines, lines);
    const elim = pairs.reduce((n, p) => n + p.eliminated, 0);
    for (const p of pairs) eliminations.push({ ...p, parentId: parent.id, subsidiaryId: client.id });
    // Goodwill (IFRS 3, pragmatic formula): investment − hold% × NAV. Inputs in MAJOR.
    const goodwill = g.investment != null && Number.isFinite(g.investment)
      ? Math.max(0, MINOR(g.investment) - Math.round((holding / 100) * nav))
      : 0;
    // NCI (IFRS 10): NCI% × (NAV + goodwill).
    const nCi = Math.max(0, Math.round(((nav + goodwill) * (nCiPct / 100))));
    subs.push({ client, input: g, lines, included: true, reason: '', assets, liabilities, equity, nav, goodwill, nci: nCi, elimination: elim });
  }

  const included = subs.filter((e) => e.included);
  const eliminationTotal = included.reduce((n, e) => n + e.elimination, 0);

  // ─── Trial balance aggregation ───────────────────────────────────────────
  const rowsByAccount = new Map<string, ConsolidatedRow>();
  for (const row of parentTrial) {
    rowsByAccount.set(row.code, { account: row.code, name: row.name, type: row.type, parent: row.dr - row.cr, subsidiary: 0, consolidated: 0 });
  }
  // Parent AR (110000) reduced by eliminations against every included sub.
  const arRow = rowsByAccount.get('110000');
  if (arRow) arRow.parent -= eliminationTotal;

  for (const e of included) {
    const subTrial = aggregateTrialBalance(e.lines, accounts);
    for (const row of subTrial) {
      const net = row.dr - row.cr;
      const existing = rowsByAccount.get(row.code);
      if (existing) existing.subsidiary += net;
      else rowsByAccount.set(row.code, { account: row.code, name: row.name, type: row.type as never, parent: 0, subsidiary: net, consolidated: 0 });
    }
    // Reduce this sub's AP (200000) contribution by its elimination:
    // elimination reduces the credit balance, i.e. it adds back the debit net.
    if (e.elimination > 0) {
      const apRow = rowsByAccount.get('200000');
      if (apRow) apRow.subsidiary += e.elimination;
    }
  }

  // Goodwill (IFRS 3) is an asset with no ledger account of its own in either
  // entity's books — it exists only on consolidation. It must still appear as a
  // row so the working paper foots to the summary: a reader summing the table
  // must reach the same total assets as the headline figures.
  const goodwillBeforeRows = included.reduce((n, e) => n + e.goodwill, 0);
  if (goodwillBeforeRows > 0) {
    rowsByAccount.set('199900', {
      account: '199900', name: 'Goodwill on consolidation (IFRS 3)', type: 'Asset',
      parent: 0, subsidiary: goodwillBeforeRows, consolidated: goodwillBeforeRows,
    });
  }
  const rows: ConsolidatedRow[] = [...rowsByAccount.values()].map((row) => ({ ...row, consolidated: row.parent + row.subsidiary }));

  // ─── Totals ──────────────────────────────────────────────────────────────
  let assets = 0;
  let liabilities = 0;
  for (const row of rows) {
    if (row.type === 'Asset') assets += row.consolidated;
    else if (row.type === 'Liability') liabilities += -row.consolidated;
  }
  const goodwillTotal = included.reduce((n, e) => n + e.goodwill, 0);
  const nciTotal = included.reduce((n, e) => n + e.nci, 0);
  const groupEquity = assets - liabilities; // group equity incl NCI
  const parentRetained = groupEquity - nciTotal;
  const balanced = Math.abs(assets - (groupEquity + liabilities)) < 0.02;

  // Entity summaries (parent + all subs).
  const entitiesOut: EntityConsolidation[] = entities.map(({ client }) => {
    if (client.id === parent.id) {
      let pAssets = 0;
      let pLiabilities = 0;
      for (const row of aggregateTrialBalance(parentLines, accounts)) {
        const net = row.dr - row.cr;
        if (row.type === 'Asset') pAssets += net;
        else if (row.type === 'Liability') pLiabilities += isDebitNormal('Liability') ? -net : net;
      }
      const equityVal = pAssets - pLiabilities;
      return { id: client.id, name: client.name, code: client.code, currency: client.currency, holding: 100, nCiPct: 0, rate: 1, included: true, reason: '', assets: MAJOR(pAssets), liabilities: MAJOR(pLiabilities), equity: MAJOR(equityVal), goodwill: 0, nCi: 0 };
    }
    const matched = subs.find((s) => s.client.id === client.id);
    if (!matched) {
      return { id: client.id, name: client.name, code: client.code, currency: client.currency, holding: 0, nCiPct: 100, rate: 1, included: false, reason: 'Not in scope', assets: 0, liabilities: 0, equity: 0, goodwill: 0, nCi: 0 };
    }
    return {
      id: client.id, name: client.name, code: client.code, currency: client.currency,
      holding: matched.input.holdPct, nCiPct: Math.max(0, 100 - matched.input.holdPct), rate: matched.input.exchangeRate,
      included: matched.included, reason: matched.reason,
      assets: MAJOR(matched.assets), liabilities: MAJOR(matched.liabilities), equity: MAJOR(matched.equity),
      goodwill: MAJOR(matched.goodwill), nCi: MAJOR(matched.nci),
    };
  });

  return {
    parentCurrency,
    parentCode: parent.code,
    parentName: parent.name,
    rows,
    entities: entitiesOut,
    eliminations,
    errors,
    totals: {
      assets: MAJOR(assets),
      liabilities: MAJOR(liabilities),
      equity: MAJOR(groupEquity),
      goodwill: MAJOR(goodwillTotal),
      nci: MAJOR(nciTotal),
      parentRetained: MAJOR(parentRetained),
      eliminations: MAJOR(eliminationTotal),
    },
    balanced,
    method: 'IFRS 10 pro-forma: full consolidation of controlled subsidiaries (hold > 50%); trial-balance aggregation; intercompany elimination of name-matched AR/AP (110000 vs 200000); goodwill = max(0, investment − hold% × NAV); NCI = NCI% × (NAV + goodwill); balance-sheet translation at closing rate (IAS 21) — P&L average rate not modelled.',
  };
}

