import type { ACDOCALine, PurchaseOrder } from '../types/accounting';
import { uniqueId } from './ids';

/**
 * Receipt and invoice are distinct accounting events. When control of purchased
 * goods/services transfers, recognise the asset/expense and an accrued GRNI
 * liability. A matched supplier invoice clears GRNI, recognises recoverable
 * input tax, and creates the invoiced trade payable. Neither event is a payment.
 */
export const GRNI_ACCOUNT = '204000';
export const TRADE_PAYABLES_ACCOUNT = '200000';

export type ReceiptContext = { clientId: number; currency: string; username: string; date: string };

function common(ctx: ReceiptContext, docNo: string, reference: string) {
  return {
    docNo, reference, period: ctx.date.slice(0, 7), date: ctx.date,
    module: 'MM' as const, docType: 'PO' as const, currency: ctx.currency,
    createdBy: ctx.username, clientId: ctx.clientId,
  };
}

const amount = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;

/** Legacy quick orders and warehouse receipts share this exact journal policy. */
export function buildReceiptJournal(
  po: PurchaseOrder, ctx: ReceiptContext, inventoryAccount?: { number: string; name: string },
): ACDOCALine[] {
  const net = amount(po.netAmount ?? po.qty * po.unitPrice);
  if (!Number.isFinite(net) || net <= 0) throw new Error('Receipt value must be positive.');
  const base = common(ctx, po.poNo, po.poNo);
  return [
    {
      ...base, id: uniqueId('JL-GRN'), accountNo: inventoryAccount?.number || po.glAccount,
      accountName: inventoryAccount?.name || po.glAccountName, costCenter: po.costCenter,
      debit: net, credit: 0, description: `Receipt of ${po.itemDescription} · ${po.vendorName}`,
    },
    {
      ...base, id: uniqueId('JL-GRN'), accountNo: GRNI_ACCOUNT,
      accountName: 'Goods Received Not Invoiced (GRNI) Clearing', costCenter: po.costCenter,
      debit: 0, credit: net, description: `Uninvoiced receipt ${po.poNo} · ${po.vendorName}`,
    },
  ];
}

/** Post only after the supplier invoice has been checked against its receipt. */
export function buildSupplierInvoiceJournal(po: PurchaseOrder, ctx: ReceiptContext, invoiceReference: string): ACDOCALine[] {
  const ref = invoiceReference.trim();
  if (!ref) throw new Error('A supplier invoice reference is required.');
  const net = amount(po.netAmount ?? po.qty * po.unitPrice);
  const tax = amount(po.vatRecoverable || 0);
  const gross = amount(po.totalAmount);
  if (![net, tax, gross].every(Number.isFinite) || net <= 0 || tax < 0 || Math.abs(gross - amount(net + tax)) > 0.009) {
    throw new Error('Invoice net, input tax and gross do not agree. Review the supplier invoice.');
  }
  const base = common(ctx, `BILL-${po.poNo}`, po.poNo);
  const entries: ACDOCALine[] = [{
    ...base, id: uniqueId('JL-BILL'), accountNo: GRNI_ACCOUNT,
    accountName: 'Goods Received Not Invoiced (GRNI) Clearing', costCenter: po.costCenter,
    debit: net, credit: 0, description: `Clear receipt ${po.poNo} · supplier invoice ${ref}`,
  }];
  if (tax > 0) entries.push({
    ...base, id: uniqueId('JL-BILL'), accountNo: '125000', accountName: 'VAT Input Tax Recoverable',
    costCenter: po.costCenter, debit: tax, credit: 0,
    description: `Input tax on supplier invoice ${ref} · ${po.poNo}`,
  });
  entries.push({
    ...base, id: uniqueId('JL-BILL'), accountNo: TRADE_PAYABLES_ACCOUNT,
    accountName: `Trade Payables (${po.vendorName})`, costCenter: po.costCenter,
    debit: 0, credit: gross, description: `Supplier invoice ${ref} · ${po.poNo} · ${po.vendorName}`,
  });
  return entries;
}

/** True only if this order has a real posted GRNI receipt awaiting clearance. */
export function hasUninvoicedReceipt(po: PurchaseOrder, lines: readonly ACDOCALine[]): boolean {
  const related = lines.filter((line) => line.clientId === po.clientId && line.accountNo === GRNI_ACCOUNT
    && (line.docNo === po.poNo || line.reference === po.poNo));
  const balance = related.reduce((sum, line) => sum + Math.round(line.credit * 100) - Math.round(line.debit * 100), 0);
  return balance === Math.round((po.netAmount ?? po.qty * po.unitPrice) * 100) && balance > 0;
}
