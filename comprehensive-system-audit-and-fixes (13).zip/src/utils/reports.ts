import type { ACDOCALine, AccountMaster } from '../types/accounting';
import { GHANA_ECONOMY_SECTORS } from '../data/ghanaSectors';
import { docSuffix, uniqueId } from './ids';

/**
 * Shared, ledger-derived reporting engine for the BPZ Consult ERP.
 * Every figure is computed strictly from posted journal lines — no hard-coded amounts.
 */

export const CASH_ACCOUNTS = ['100000', '101000', '102000', '103000', '104000'];

/** Non-cash expenses added back in the IAS 7 indirect operating section. */
const ADD_BACK_EXPENSE = ['600000', '610000', '611000', '612000', '680000', '690000', '698000', '731000'];
/** Non-cash credit movements added back (provision increases). */
const ADD_BACK_CREDIT = ['240000', '270000', '271000'];
/** Gains on disposal removed from operating (presented in investing). */
const REMOVE_GAIN = ['492000'];
/** Working-capital asset groups (debit-normal). */
const RECEIVABLE_ACCOUNTS = ['110000', '111000', '112000', '113000', '114000', '115000', '118000', '141000'];
const INVENTORY_ACCOUNTS = ['120000', '121000', '122000', '123000', '124000'];
const PREPAID_ACCOUNTS = ['116000'];
/** Working-capital liability groups (credit-normal). */
const PAYABLE_ACCOUNTS = ['200000', '201000', '202000', '203000', '204000', '205000', '206000', '206100', '207000', '208000', '209000', '212000', '220000', '221000', '223000', '224000', '225000', '228000'];
/** Investing (debit-normal non-current assets). */
const INVESTING_ACCOUNTS = ['130000', '131000', '132000', '133000', '134000', '135000', '136000', '142000', '143000', '144000', '150000', '152000', '160000', '161000', '162000', '180000'];
/** Financing (credit-normal borrowings, leases, equity, dividends payable). */
const FINANCING_ACCOUNTS = ['210000', '211000', '226000', '230000', '250000', '300000', '301000', '311000', '313000'];

const toMinor = (n: number) => Math.round(n * 100);
const toMajor = (minor: number) => Math.round(minor) / 100;
const inCents = (n: number) => Math.round(n * 100) / 100; // round to 2dp in major units

export const classifyAccount = (accounts: AccountMaster[], code: string): AccountMaster['type'] => {
  const master = accounts.find((a) => a.accountNo === code);
  if (master) return master.type;
  return code.startsWith('1') ? 'Asset'
    : code.startsWith('2') ? 'Liability'
    : code.startsWith('3') ? 'Equity'
    : code.startsWith('4') ? 'Income' : 'Expense';
};

export interface TbRow {
  code: string;
  name: string;
  type: AccountMaster['type'];
  dr: number;
  cr: number;
}

/** Aggregates journal lines into trial-balance rows in integer minor units. */
export function aggregateTrialBalance(lines: ACDOCALine[], accounts: AccountMaster[]): TbRow[] {
  const map = new Map<string, TbRow>();
  for (const l of lines) {
    const row = map.get(l.accountNo) ?? {
      code: l.accountNo,
      name: accounts.find((a) => a.accountNo === l.accountNo)?.name || l.accountName,
      type: classifyAccount(accounts, l.accountNo),
      dr: 0,
      cr: 0,
    };
    row.dr += toMinor(l.debit);
    row.cr += toMinor(l.credit);
    map.set(l.accountNo, row);
  }
  return [...map.values()].sort((a, b) => a.code.localeCompare(b.code));
}

const netDrCr = (lines: ACDOCALine[], accountNos: string[]): number =>
  toMajor(lines.filter((l) => accountNos.includes(l.accountNo)).reduce((n, l) => n + toMinor(l.debit) - toMinor(l.credit), 0));

const netCrDr = (lines: ACDOCALine[], accountNos: string[]): number =>
  toMajor(lines.filter((l) => accountNos.includes(l.accountNo)).reduce((n, l) => n + toMinor(l.credit) - toMinor(l.debit), 0));

const profitOf = (lines: ACDOCALine[], accounts: AccountMaster[]): number => {
  const rows = aggregateTrialBalance(lines, accounts);
  // Profit = income - expenses = -(sum of P&L debit-minus-credit), rows are in minor units.
  return toMajor(rows
    .filter((r) => r.type === 'Income' || r.type === 'Expense')
    .reduce((n, r) => n - (r.dr - r.cr), 0));
};

export interface CashFlowStatement {
  profitBeforeTax: number;
  addBacks: number;
  removeGains: number;
  deltaReceivables: number;
  deltaInventory: number;
  deltaPrepaids: number;
  deltaPayables: number;
  operating: number;
  investing: number;
  financing: number;
  netChange: number;
  openingCash: number;
  closingCash: number;
  cashMovement: number;
  residual: number;
}

/**
 * IAS 7 indirect-method statement of cash flows derived from the posted journal.
 * `residual` must equal zero — it proves the classification covers every movement.
 */
export function buildCashFlow(lines: ACDOCALine[], accounts: AccountMaster[], from: string, through: string): CashFlowStatement {
  const scoped = lines.filter((l) => l.date <= through);
  // Opening take-on documents (OB-* / OPENING-*) establish the position at the
  // cut-over; they are NOT period activity. A migrated client's first-period
  // cash flow used to present the entire opening balance sheet as financing and
  // investing flows. Including the take-on in `prior` makes every delta
  // (closing − opening) equal the genuine period movement, and makes opening
  // cash equal the migrated opening balance — which is what IAS 7 requires.
  const isOpeningTakeOn = (l: ACDOCALine) => /^(OB-|OPENING-)/i.test(l.docNo);
  const prior = scoped.filter((l) => l.date < from || isOpeningTakeOn(l));
  const movement = scoped.filter((l) => l.date >= from && !isOpeningTakeOn(l));

  const profitBeforeTax = profitOf(movement, accounts);
  const addBacks = netDrCr(movement, ADD_BACK_EXPENSE) + netCrDr(movement, ADD_BACK_CREDIT);
  const removeGains = netCrDr(movement, REMOVE_GAIN);

  // Working-capital movements = closing balance minus opening balance per group.
  const deltaOf = (group: string[], crNormal: boolean) => {
    const closing = crNormal ? netCrDr(scoped, group) : netDrCr(scoped, group);
    const opening = crNormal ? netCrDr(prior, group) : netDrCr(prior, group);
    return inCents(closing - opening);
  };
  const dReceivables = deltaOf(RECEIVABLE_ACCOUNTS, false);
  const dInventory = deltaOf(INVENTORY_ACCOUNTS, false);
  const dPrepaids = deltaOf(PREPAID_ACCOUNTS, false);
  const dPayables = deltaOf(PAYABLE_ACCOUNTS, true);

  const operating = inCents(profitBeforeTax + addBacks - removeGains - dReceivables - dInventory - dPrepaids + dPayables);
  const investing = inCents(-deltaOf(INVESTING_ACCOUNTS, false));
  const financing = inCents(deltaOf(FINANCING_ACCOUNTS, true));
  const netChange = inCents(operating + investing + financing);

  const openingCash = netDrCr(prior, CASH_ACCOUNTS);
  const closingCash = netDrCr(scoped, CASH_ACCOUNTS);
  const cashMovement = inCents(closingCash - openingCash);
  const residual = inCents(cashMovement - netChange);
  return {
    profitBeforeTax, addBacks, removeGains,
    deltaReceivables: dReceivables, deltaInventory: dInventory, deltaPrepaids: dPrepaids, deltaPayables: dPayables,
    operating, investing, financing, netChange,
    openingCash, closingCash, cashMovement, residual,
  };
}

export interface AgingBuckets {
  current: number;
  days31to60: number;
  days61to90: number;
  over90: number;
  total: number;
  overdueCount: number;
}

const dayMs = 86400000;
/** Ages open items into 30-day buckets as at a date (30-day credit terms assumed). */
export function ageIntoBuckets(asOf: string, items: { date: string; amount: number }[]): AgingBuckets {
  const asOfMs = new Date(`${asOf}T00:00:00.000Z`).getTime();
  const buckets = { current: 0, days31to60: 0, days61to90: 0, over90: 0, total: 0, overdueCount: 0 };
  for (const item of items) {
    const age = Math.max(0, Math.floor((asOfMs - new Date(`${item.date}T00:00:00.000Z`).getTime()) / dayMs));
    buckets.total = inCents(buckets.total + item.amount);
    if (age > 90) buckets.over90 = inCents(buckets.over90 + item.amount);
    else if (age > 60) buckets.days61to90 = inCents(buckets.days61to90 + item.amount);
    else if (age > 30) buckets.days31to60 = inCents(buckets.days31to60 + item.amount);
    else buckets.current = inCents(buckets.current + item.amount);
    if (age > 30) buckets.overdueCount += 1;
  }
  return buckets;
}

/** Maps a client sector description to the CIT rate of the matching Ghanaian sector. */
export function sectorCitRate(sector: string): { rate: number; sectorName: string } {
  const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter((w) => w.length > 3 && !['with', 'from', 'other'].includes(w));
  const clientWords = new Set(normalize(sector));
  let best: { rate: number; sectorName: string; score: number } = { rate: 25, sectorName: 'General commerce & services (standard CIT)', score: 0 };
  for (const def of GHANA_ECONOMY_SECTORS) {
    const score = normalize(def.name).filter((w) => clientWords.has(w)).length;
    if (score > best.score) best = { rate: def.citRate, sectorName: def.name, score };
  }
  return { rate: best.rate, sectorName: best.sectorName };
}

/** CIT working paper: gross CIT on taxable profit less WHT credits already withheld. */
export function computeCit(profitBeforeTax: number, citRatePct: number, whtCredits: number) {
  const taxableProfit = Math.max(0, inCents(profitBeforeTax));
  const grossCit = inCents(taxableProfit * citRatePct / 100);
  const netPayable = inCents(Math.max(0, grossCit - Math.max(0, whtCredits)));
  return { taxableProfit, citRatePct, grossCit, whtCredits: Math.max(0, inCents(whtCredits)), netPayable };
}

export interface FxRevaluationRow {
  accountNo: string;
  accountName: string;
  fcyBalance: number;
  bookRate: number;
  closingRate: number;
  revaluedGhs: number;
  gainLoss: number; // positive = gain
}

/**
 * IAS 21 unrealised FX revaluation of foreign-currency monetary items in the journal.
 * gain/loss (GHS) = FCY net balance x (closing rate - book rate).
 */
/**
 * IAS 21.23: only MONETARY items are retranslated at the closing rate. Property,
 * plant and equipment (13xxxx), inventories (12xxxx), right-of-use and intangible
 * assets (15xxxx), equity and the income statement are measured at historical
 * cost or fair value and are never retranslated — an "unrealised FX gain" booked
 * to PPE cost is a misstatement, not a valuation. Unknown accounts are skipped:
 * the engine must never invent a revaluation on an account it cannot classify.
 */
const FX_NON_MONETARY_TYPES = new Set(['Income', 'Expense', 'Equity']);
const FX_NON_MONETARY_PREFIXES = ['12', '13', '15'];
export function isMonetaryForFx(account: AccountMaster | undefined): boolean {
  if (!account) return false;
  if (FX_NON_MONETARY_TYPES.has(account.type)) return false;
  if (FX_NON_MONETARY_PREFIXES.includes(account.accountNo.slice(0, 2))) return false;
  return account.type === 'Asset' || account.type === 'Liability';
}

export function buildFxRevaluation(
  lines: ACDOCALine[],
  accounts: AccountMaster[],
  ccy: string,
  bookRate: number,
  closingRate: number
): FxRevaluationRow[] {
  const fcyLines = lines.filter((l) => l.currency === ccy);
  const byAccount = new Map<string, number>();
  for (const l of fcyLines) {
    if (!isMonetaryForFx(accounts.find((a) => a.accountNo === l.accountNo))) continue;
    byAccount.set(l.accountNo, inCents((byAccount.get(l.accountNo) ?? 0) + l.debit - l.credit));
  }
  const rows: FxRevaluationRow[] = [];
  for (const [accountNo, fcyBalance] of [...byAccount.entries()].sort()) {
    if (Math.abs(fcyBalance) < 0.005) continue;
    const gainLoss = inCents(fcyBalance * (closingRate - bookRate));
    rows.push({
      accountNo,
      accountName: accounts.find((a) => a.accountNo === accountNo)?.name || accountNo,
      fcyBalance,
      bookRate,
      closingRate,
      revaluedGhs: inCents(fcyBalance * closingRate),
      gainLoss,
    });
  }
  return rows;
}

// Kept as public exports for existing report and banking consumers.
export { matchStatementLines, parseStatementAmount, parseStatementCsv, parseStatementDate, parseStatementReport } from './bankStatement';
export type { StatementConvention, StatementDateOrder, StatementImportReport, StatementLine, StatementMatchResult } from './bankStatement';

/** Builds the balanced disposal journal for a fixed asset (IAS 16 derecognition). */
export function ppeAccountForClass(classCode?: string): string {
  const c = String(classCode || '').toUpperCase();
  if (c.includes('LAND') || c.includes('BLDG') || c.includes('BUILD')) return '131000';
  if (c.includes('PLANT') || c.includes('MACH')) return '132000';
  if (c.includes('VEH') || c.includes('FLEET') || c.includes('TRUCK')) return '133000';
  if (c.includes('OFF') || c.includes('FURN')) return '134000';
  if (c.includes('IT') || c.includes('COMP')) return '135000';
  if (c.includes('INFRA') || c.includes('SUB') || c.includes('SITE')) return '136000';
  return '130000';
}

/** Keep a legacy 130000 acquisition on that GL instead of guessing from its class. */
export function postedPpeCostAccount(asset: { assetTag: string; classCode?: string }, journal: readonly ACDOCALine[], clientId: number): string {
  const tag = asset.assetTag.trim().toLowerCase();
  const line = journal.find((row) => row.clientId === clientId && row.debit > 0 && /^13[0-6]\d{3}$/.test(row.accountNo)
    && (row.reference?.trim().toLowerCase() === tag || row.description.trim().toLowerCase() === `acquisition of ${tag}`
      || (row.docNo.startsWith('OB-') && row.description.toLowerCase().includes(`(${tag})`))));
  return line?.accountNo ?? ppeAccountForClass(asset.classCode);
}

export function buildDisposalEntries(
  asset: { assetTag: string; name: string; cost: number; accumDep: number; classCode?: string },
  proceeds: number,
  date: string,
  currency: string,
  clientId: number,
  createdBy: string,
  options?: { costAccountNo?: string; bankAccountNo?: string; bankAccountName?: string },
): ACDOCALine[] {
  const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
  const period = date.slice(0, 7);
  const docNo = `DISP-${asset.assetTag}-${docSuffix()}`;
  const nbv = round2(asset.cost - asset.accumDep);
  const gain = round2(proceeds - nbv);
  const costAcc = options?.costAccountNo || ppeAccountForClass(asset.classCode);
  const bankAcc = options?.bankAccountNo || '100000';
  const bankName = options?.bankAccountName || 'Cash at Bank (Operating)';
  const entries: ACDOCALine[] = [
    { id: `${uniqueId('JL-DISP')}-1`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: bankAcc, accountName: bankName, costCenter: 'CC-OPS', debit: round2(proceeds), credit: 0, currency, description: `Disposal proceeds ${asset.assetTag}`, createdBy, clientId },
    { id: `${uniqueId('JL-DISP')}-2`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: costAcc, accountName: `PPE — ${asset.name}`, costCenter: 'CC-OPS', debit: 0, credit: round2(asset.cost), currency, description: `Cost of disposed asset ${asset.assetTag}`, createdBy, clientId },
  ];
  if (asset.accumDep > 0) entries.push({ id: `${uniqueId('JL-DISP')}-3`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '139000', accountName: 'Accumulated Depreciation — PPE', costCenter: 'CC-OPS', debit: round2(asset.accumDep), credit: 0, currency, description: `Accumulated depreciation reversal ${asset.assetTag}`, createdBy, clientId });
  if (gain > 0) entries.push({ id: `${uniqueId('JL-DISP')}-4`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '492000', accountName: 'Gain on Disposal of PPE', costCenter: 'CC-OPS', debit: 0, credit: gain, currency, description: `Gain on disposal ${asset.assetTag}`, createdBy, clientId });
  if (gain < 0) entries.push({ id: `${uniqueId('JL-DISP')}-4`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '698000', accountName: 'Loss on Disposal of PPE', costCenter: 'CC-OPS', debit: round2(-gain), credit: 0, currency, description: `Loss on disposal ${asset.assetTag}`, createdBy, clientId });
  return entries;
}

/** Builds the balanced debit-note (purchase return) journal reversing a purchase order. */
export function buildDebitNoteEntries(
  po: { poNo: string; vendorName: string; glAccount: string; glAccountName: string; costCenter: string; netAmount?: number; qty: number; unitPrice: number; vatRecoverable: number; totalAmount: number },
  date: string,
  currency: string,
  clientId: number,
  createdBy: string
): ACDOCALine[] {
  const period = date.slice(0, 7);
  const docNo = `DN-${po.poNo.replace('PO-', '')}-${docSuffix()}`;
  const net = po.netAmount ?? Math.round((po.qty * po.unitPrice) * 100) / 100;
  const entries: ACDOCALine[] = [
    { id: `${uniqueId('JL-DN')}-1`, docNo, period, date, module: 'MM', docType: 'REV', accountNo: '200000', accountName: `Trade Payables (${po.vendorName})`, costCenter: po.costCenter, debit: po.totalAmount, credit: 0, currency, description: `Debit note for ${po.poNo} — payable reversal`, createdBy, clientId },
    { id: `${uniqueId('JL-DN')}-2`, docNo, period, date, module: 'MM', docType: 'REV', accountNo: po.glAccount, accountName: po.glAccountName, costCenter: po.costCenter, debit: 0, credit: net, currency, description: `Debit note for ${po.poNo} — ${po.glAccountName} reversal`, createdBy, clientId },
  ];
  if (po.vatRecoverable > 0) entries.push({ id: `${uniqueId('JL-DN')}-3`, docNo, period, date, module: 'MM', docType: 'REV', accountNo: '125000', accountName: 'VAT Input Tax Recoverable', costCenter: po.costCenter, debit: 0, credit: po.vatRecoverable, currency, description: `Input VAT reversal on ${po.poNo}`, createdBy, clientId });
  return entries.map((entry) => ({ ...entry, reference: po.poNo }));
}

export interface CostCentreRow {
  code: string;
  income: number;
  expense: number;
  net: number;
}

export interface CostCentreReport {
  rows: CostCentreRow[];
  totalIncome: number;
  totalExpense: number;
  totalNet: number;
  profit: number;
  residual: number;
}

/** P&L by cost centre for the entity's movement window, derived from posted lines. */
export function buildCostCentreReport(lines: ACDOCALine[], accounts: AccountMaster[], from: string, through: string): CostCentreReport {
  const scoped = lines.filter((l) => l.date >= from && l.date <= through);
  const rows = aggregateTrialBalance(scoped, accounts).filter((r) => r.type === 'Income' || r.type === 'Expense');
  const byCc = new Map<string, CostCentreRow>();
  for (const l of scoped) {
    const type = classifyAccount(accounts, l.accountNo);
    if (type !== 'Income' && type !== 'Expense') continue;
    const code = l.costCenter || 'UNASSIGNED';
    const row = byCc.get(code) ?? { code, income: 0, expense: 0, net: 0 };
    const amount = Math.round((l.credit - l.debit) * 100) / 100;
    if (type === 'Income') row.income = Math.round((row.income + amount) * 100) / 100;
    else row.expense = Math.round((row.expense - amount) * 100) / 100;
    row.net = Math.round((row.income - row.expense) * 100) / 100;
    byCc.set(code, row);
  }
  const sorted = [...byCc.values()].sort((a, b) => a.code.localeCompare(b.code));
  const totalIncome = Math.round(sorted.reduce((n, r) => n + r.income, 0) * 100) / 100;
  const totalExpense = Math.round(sorted.reduce((n, r) => n + r.expense, 0) * 100) / 100;
  const totalNet = Math.round((totalIncome - totalExpense) * 100) / 100;
  const profit = rows.reduce((n, r) => n - (r.dr - r.cr), 0) / 100;
  return { rows: sorted, totalIncome, totalExpense, totalNet, profit, residual: Math.round((totalNet - profit) * 100) / 100 };
}

/**
 * Builds the balanced credit-note (sales return) journal reversing an invoice.
 * Reverses the exact revenue account originally credited, and splits the
 * credit between Trade Receivables (for the unpaid balance) and Customer
 * Deposits / Credit Payable 217000 (for any portion already collected) so the
 * Trade Receivables control account stays reconciled.
 */
export function buildCreditNoteEntries(
  inv: {
    invNo: string;
    customerName: string;
    revenueStream: string;
    revenueAccount?: string;
    revenueAccountName?: string;
    netRevenue: number;
    vatOutput: number;
    cstAmount?: number;
    tourismLevyAmount?: number;
    totalReceivable: number;
    paidAmount?: number;
  },
  date: string,
  currency: string,
  clientId: number,
  createdBy: string
): ACDOCALine[] {
  const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
  const period = date.slice(0, 7);
  const docNo = `CN-${inv.invNo.replace('INV-', '')}-${docSuffix()}`;
  const paid = Math.min(r2(inv.totalReceivable), Math.max(0, r2(inv.paidAmount ?? 0)));
  const unpaid = r2(inv.totalReceivable - paid);
  const revAcc = inv.revenueAccount || '400000';
  const revName = inv.revenueAccountName || 'Revenue from Contracts with Customers';
  const entries: ACDOCALine[] = [
    { id: `${uniqueId('JL-CN')}-1`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: revAcc, accountName: revName, costCenter: 'CC-SLS', debit: inv.netRevenue, credit: 0, currency, description: `Credit note for ${inv.invNo} — revenue reversal`, createdBy, clientId },
  ];
  if (unpaid > 0.004) {
    entries.push({ id: `${uniqueId('JL-CN')}-2`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '110000', accountName: `Trade Receivables (${inv.customerName})`, costCenter: 'CC-SLS', debit: 0, credit: unpaid, currency, description: `Credit note for ${inv.invNo} (${inv.revenueStream})`, createdBy, clientId });
  }
  if (paid > 0.004) {
    entries.push({ id: `${uniqueId('JL-CN')}-2b`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '217000', accountName: `Customer Credit & Refundable Deposits (${inv.customerName})`, costCenter: 'CC-SLS', debit: 0, credit: paid, currency, description: `Customer credit refundable for settled ${inv.invNo}`, createdBy, clientId });
  }
  if (inv.vatOutput > 0) entries.push({ id: `${uniqueId('JL-CN')}-3`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '220000', accountName: 'VAT/NHIL/GETFund Output Liability', costCenter: 'CC-SLS', debit: inv.vatOutput, credit: 0, currency, description: `Output VAT reversal on ${inv.invNo}`, createdBy, clientId });
  if ((inv.cstAmount || 0) > 0) entries.push({ id: `${uniqueId('JL-CN')}-4`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '223000', accountName: 'Communication Service Tax Payable', costCenter: 'CC-SLS', debit: inv.cstAmount || 0, credit: 0, currency, description: `CST reversal on ${inv.invNo}`, createdBy, clientId });
  if ((inv.tourismLevyAmount || 0) > 0) entries.push({ id: `${uniqueId('JL-CN')}-5`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '224000', accountName: 'Tourism Levy Payable', costCenter: 'CC-SLS', debit: inv.tourismLevyAmount || 0, credit: 0, currency, description: `Tourism levy reversal on ${inv.invNo}`, createdBy, clientId });
  return entries.map((entry) => ({ ...entry, reference: inv.invNo }));
}

/**
 * IAS 21 exposure measured from the REGISTERS, not from ledger lines.
 *
 * The ledger is kept in the entity's functional currency (foreign documents are
 * translated at posting), so a revaluation computed from `journal_lines` would
 * always be empty. Monetary exposure lives in the operational registers instead:
 * foreign-currency bank/wallet balances, open customer receivables and open
 * supplier payables. Non-monetary items (inventory, PPE, equity) are excluded —
 * they are measured at historical cost and are never retranslated (IAS 21.23).
 */
export function fxExposureFromRegisters(input: {
  clientId: number;
  currency: string;
  bookRate: number;
  closingRate: number;
  bankAccounts: readonly { clientId?: number | null; currency: string; glAccount?: string | null; kind?: string | null; name: string; balance: number }[];
  invoices: readonly { clientId?: number | null; currency?: string | null; totalReceivable: number; paidAmount?: number; status: string; invNo: string }[];
  purchaseOrders: readonly { clientId?: number | null; currency?: string | null; totalAmount: number; paidAmount?: number; status: string; poNo: string }[];
}): FxRevaluationRow[] {
  const ccy = input.currency.toUpperCase();
  // Rate movement per one unit of foreign currency. (This used to be written
  // `(closingRate - bookRate) / 100 ** 0` — a division by 1 that read as if the
  // difference were being converted to a percentage and hid the arithmetic.)
  const fx = input.closingRate - input.bookRate;
  const rows: FxRevaluationRow[] = [];
  const push = (accountNo: string, accountName: string, fcyBalance: number) => {
    if (Math.abs(fcyBalance) < 0.005) return;
    rows.push({
      accountNo,
      accountName,
      fcyBalance: inCents(fcyBalance),
      bookRate: input.bookRate,
      closingRate: input.closingRate,
      revaluedGhs: inCents(fcyBalance * input.closingRate),
      gainLoss: inCents(fcyBalance * fx),
    });
  };
  for (const bank of input.bankAccounts) {
    if ((bank.clientId ?? input.clientId) !== input.clientId) continue;
    if (String(bank.currency).toUpperCase() !== ccy) continue;
    push(bank.glAccount || (bank.kind === 'cash' ? '102000' : '100000'), `Treasury — ${bank.name}`, bank.balance);
  }
  const openInvoices = input.invoices.filter((i) => (i.clientId ?? input.clientId) === input.clientId
    && String(i.currency ?? '').toUpperCase() === ccy && i.status !== 'Draft' && i.status !== 'Credited');
  push('110000', `Trade receivables (${openInvoices.length} open invoice${openInvoices.length === 1 ? '' : 's'})`,
    openInvoices.reduce((s, i) => s + (i.totalReceivable - (i.paidAmount ?? 0)), 0));
  const openOrders = input.purchaseOrders.filter((o) => (o.clientId ?? input.clientId) === input.clientId
    && String(o.currency ?? '').toUpperCase() === ccy && o.status !== 'Debited');
  push('200000', `Trade payables (${openOrders.length} open bill${openOrders.length === 1 ? '' : 's'})`,
    -openOrders.reduce((s, o) => s + (o.totalAmount - (o.paidAmount ?? 0)), 0));
  return rows;
}
