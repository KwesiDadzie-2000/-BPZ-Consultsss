import { expect, type Page } from '@playwright/test';

export const OWNER_USER = 'owner';
export const OWNER_PASS = 'E2eOwner#2026!Secure';
export const DEMO_USER = 'demo';
export const DEMO_PASS = 'E2eDemo#2026!Secure';

/** Signs in through the real login form and waits for the workspace shell. */
export async function signIn(page: Page, username: string, password: string): Promise<void> {
  await page.goto('/', { waitUntil: 'domcontentloaded' });
  await page.getByPlaceholder('Username or email').fill(username);
  await page.getByPlaceholder('Enter password').fill(password);
  await page.getByRole('button', { name: 'Sign In', exact: true }).click();
  // The workspace shell is identifiable by its navigation landmark.
  await expect(page.getByRole('navigation', { name: 'Module categories' })).toBeVisible({ timeout: 30_000 });
}

/**
 * Opens a desk from the sidebar, expanding its category if needed, and waits
 * until the desk reports itself as the current page.
 */
export async function openDesk(page: Page, groupId: string, deskLabel: string): Promise<void> {
  const container = page.locator(`#nav-group-${groupId}`);
  if (!(await container.count())) {
    await page.locator(`button[aria-controls="nav-group-${groupId}"]`).click();
  }
  const desk = page.getByRole('button', { name: deskLabel, exact: false }).first();
  await desk.click();
  await expect(desk).toHaveAttribute('aria-current', 'page');
  // The workspace runs a debounced state sync, so `networkidle` would never
  // settle; a fixed beat lets the desk render its own data instead.
  await page.waitForTimeout(400);
}

/**
 * Collects uncaught exceptions and console errors so a journey can assert the
 * screen stayed clean.
 *
 * A 401 resource is expected: the app probes the session before sign-in and the
 * server correctly refuses it, so it is excluded. Anything else — a 500, a
 * bundle that failed to load, a thrown exception — is recorded.
 */
export function trackPageErrors(page: Page): string[] {
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(String(error.message || error)));
  page.on('console', (message) => {
    if (message.type() !== 'error') return;
    const text = message.text();
    if (/status of 401/.test(text)) return;
    const url = message.location()?.url ?? '';
    errors.push(url ? `${text} (${url})` : text);
  });
  return errors;
}
