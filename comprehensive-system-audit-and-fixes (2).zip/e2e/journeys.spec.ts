import { expect, test } from '@playwright/test';
import {
  DEMO_PASS,
  DEMO_USER,
  OWNER_PASS,
  OWNER_USER,
  openDesk,
  signIn,
  trackPageErrors,
} from './helpers';

/** Representative desk from every navigation group (11 groups, 62 desks total). */
const DESKS: Array<[groupId: string, deskLabel: string]> = [
  ['overview', 'Command Center'],
  ['overview', 'Opening Balances Setup'],
  ['sales', 'Sales & Invoicing · O2C'],
  ['procurement', 'Procurement & P2P'],
  ['inventory', 'Inventory Command Desk'],
  ['production', 'Production Desk'],
  ['finance', 'General Ledger'],
  ['finance', 'Journals (Universal & Manual)'],
  ['finance', 'Banking & Reconcile'],
  ['finance', 'Ageing Analysis (AR & AP)'],
  ['finance', 'Control Accounts Reconciliation'],
  ['finance', 'Month-End Close'],
  ['hr', 'HR Management Desk'],
  ['hr', 'Payroll Desk'],
  ['performance', 'Budgeting, Forecast & Scenarios'],
  ['crm', 'Client Relationship Desk'],
  ['crm', 'Client Master File'],
  ['reports', 'Reports Centre'],
  ['admin', 'User Access & Restrictions'],
];

test('owner can open a desk from every group with no page error', async ({ page }) => {
  const errors = trackPageErrors(page);
  await signIn(page, OWNER_USER, OWNER_PASS);

  for (const [groupId, deskLabel] of DESKS) {
    await openDesk(page, groupId, deskLabel);
    // The active desk is marked for assistive tech, proving it really mounted.
    await expect(page.getByRole('button', { name: deskLabel, exact: false }).first())
      .toHaveAttribute('aria-current', 'page');
  }

  expect(errors, `uncaught errors during navigation:\n${errors.join('\n')}`).toEqual([]);
});

test('Banking: importing a bank statement produces a system analysis', async ({ page }) => {
  const errors = trackPageErrors(page);
  await signIn(page, OWNER_USER, OWNER_PASS);
  await openDesk(page, 'finance', 'Banking & Reconcile');

  const csv = [
    'Value Date,Narrative,Withdrawal,Deposit,Running Balance',
    '12/03/2026,"Payment to supplier, ref 88",1500.00,,18500.00',
    '13/03/2026,"Customer receipt, ref 89",,2000.00,20500.00',
    '14/03/2026,"Bank service charge",25.00,,20475.00',
    'Total,,1525.00,2000.00,20475.00',
  ].join('\n');

  await page.locator('input[type="file"]').first().setInputFiles({
    name: 'statement.csv',
    mimeType: 'text/csv',
    buffer: Buffer.from(csv),
  });

  await expect(page.getByText(/System analysis —/)).toBeVisible();
  await expect(page.getByText(/Rows read/)).toBeVisible();
  // The totals row must not be imported as a transaction.
  await expect(page.getByText(/Statement lines:\s*3/)).toBeVisible();
  // The variance summary must be present and numeric.
  await expect(page.getByText(/Statement movement/)).toBeVisible();

  expect(errors, errors.join('\n')).toEqual([]);
});

test('Client Master File: a customer can be registered on credit and appears in the directory', async ({ page }) => {
  const errors = trackPageErrors(page);
  await signIn(page, OWNER_USER, OWNER_PASS);
  await openDesk(page, 'crm', 'Client Master File');

  const name = 'E2E Retail Ghana Ltd';
  await page.getByRole('button', { name: 'Add Business Partner', exact: false }).click();

  const modal = page.locator('form').filter({ hasText: 'Add New Business Partner' });
  await expect(modal).toBeVisible();
  await modal.locator('select').first().selectOption({ label: 'Customer / Client (AR)' });
  // This field's label sits beside the input rather than wrapping it, so the
  // accessible name is not derived from it — the placeholder identifies it.
  await modal.getByPlaceholder('e.g. Takoradi Power Solutions Ltd').fill(name);
  await modal.getByLabel(/Credit limit/).fill('45000');
  await modal.getByLabel(/Credit terms/).fill('45');
  await modal.getByRole('button', { name: 'Save Partner', exact: true }).click();

  await expect(page.getByText(name)).toBeVisible();
  await expect(page.getByText(/Limit GHS\s?45,000.00|Limit .*45,000/).first()).toBeVisible();
  // The row must also show its credit standing, not just its name.
  await expect(page.getByText('Active').first()).toBeVisible();
  // A registration that failed would raise a System Notice — assert none did.
  await expect(page.getByText(/was not registered/)).toHaveCount(0);

  expect(errors, errors.join('\n')).toEqual([]);
});

test('partner registration is refused without a session', async ({ request }) => {
  const response = await request.post('/api/partners', {
    data: {
      clientId: 2,
      partner: {
        id: 'FORGED', code: 'FORGED', name: 'Forged Ltd', type: 'Customer',
        tin: '', email: '', phone: '', address: '', currency: 'GHS',
        isVatWithholdingAgent: false, isCstApplicable: false, isTourismLevyApplicable: false,
        creditLimit: 10_000_000, creditStatus: 'Active',
      },
    },
  });
  expect(response.status()).toBe(401);
  expect(await response.text()).not.toMatch(/FORGED/);
});

test('a negative credit limit is rejected by the server', async ({ page }) => {
  await signIn(page, OWNER_USER, OWNER_PASS);
  await openDesk(page, 'crm', 'Client Master File');
  await page.getByRole('button', { name: 'Add Business Partner', exact: false }).click();
  const modal = page.locator('form').filter({ hasText: 'Add New Business Partner' });
  await modal.getByPlaceholder('e.g. Takoradi Power Solutions Ltd').fill('E2E Negative Limit Ltd');
  // The form clamps at 0; drive the API directly to prove the server refuses it.
  const result = await page.evaluate(async () => {
    const res = await fetch('/api/partners', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        clientId: 2,
        partner: {
          id: 'NEG', code: 'CNEG', name: 'Negative Limit Ltd', type: 'Customer',
          tin: '', email: '', phone: '', address: '', currency: 'GHS',
          isVatWithholdingAgent: false, isCstApplicable: false, isTourismLevyApplicable: false,
          creditLimit: -1,
        },
      }),
    });
    return { status: res.status, body: await res.text() };
  });
  expect(result.status).toBe(400);
  expect(result.body).toMatch(/credit limit/i);
});

test('a client-level accountant does not see owner-only administration', async ({ page }) => {
  await signIn(page, DEMO_USER, DEMO_PASS);
  await expect(page.getByRole('button', { name: 'Command Center', exact: false })).toBeVisible();
  await expect(page.locator('button[aria-controls="nav-group-admin"]')).toHaveCount(0);
});
