import { defineConfig, devices } from '@playwright/test';

/**
 * End-to-end journey tests — one journey per desk group, driven through a real
 * browser against a real production build and a real PostgreSQL database.
 *
 * These complement (they do not replace) the unit and API suites: those prove
 * the arithmetic, the permissions and the endpoints; these prove that the
 * screens render, the controls are wired, and a user can actually complete the
 * flows the app advertises. Run with:
 *
 *   PGPASSWORD=postgres createdb -h 127.0.0.1 -U postgres bpz_e2e   # once
 *   npx playwright test
 *
 * The server is started by Playwright on its own port against a DISPOSABLE
 * database, so an E2E run can never touch the working workspace.
 */
const PORT = 3210;

export default defineConfig({
  testDir: './e2e',
  timeout: 90_000,
  expect: { timeout: 15_000 },
  // The journeys share one workspace database, so they must run in order.
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [['list']],
  outputDir: './e2e-results',
  use: {
    baseURL: `http://127.0.0.1:${PORT}`,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'off',
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: `npm run build && npx next start -p ${PORT}`,
    url: `http://127.0.0.1:${PORT}/api/health`,
    timeout: 300_000,
    reuseExistingServer: false,
    env: {
      DATABASE_URL: 'postgresql://postgres:postgres@127.0.0.1:5432/bpz_e2e',
      BPZ_SEED_PASSWORD_OWNER: 'E2eOwner#2026!Secure',
      BPZ_SEED_PASSWORD_DEMO: 'E2eDemo#2026!Secure',
    },
  },
});
