#!/usr/bin/env node
/**
 * Production preflight gate — run BEFORE starting the service:
 *
 *   node scripts/preflight.mjs --production
 *
 * It verifies the things that silently break a go-live: a demo bootstrap mode,
 * a missing/weak setup token, an app connecting as the database superuser,
 * backups that claim to be off-site with no bucket configured, MFA policy
 * switched off, and a database that already contains demonstration accounts.
 *
 * Exit code 0 = safe to start. Exit code 1 = at least one FAIL; WARN lines are
 * judgement calls for the operator, not blockers. Without --production only the
 * environment-shape checks run (useful in CI against a throwaway database).
 */
import { existsSync, accessSync, constants } from 'node:fs';

try { process.loadEnvFile(process.env.BPZ_ENV_FILE || '.env'); } catch { /* env may come from systemd/compose */ }

const production = process.argv.includes('--production');
let fails = 0;
let warns = 0;
const fail = (msg) => { fails += 1; console.log(`FAIL  ${msg}`); };
const warn = (msg) => { warns += 1; console.log(`WARN  ${msg}`); };
const pass = (msg) => console.log(`PASS  ${msg}`);

const env = (key) => (process.env[key] ?? '').trim();

// --- Runtime -----------------------------------------------------------------
const major = Number(process.versions.node.split('.')[0]);
if (major >= 20) pass(`Node ${process.versions.node}`);
else fail(`Node >= 20 required, found ${process.versions.node}`);

// --- Bootstrap mode ------------------------------------------------------------
if (production) {
  if (env('BPZ_BOOTSTRAP_MODE') === 'production') pass('BPZ_BOOTSTRAP_MODE=production');
  else fail('BPZ_BOOTSTRAP_MODE must be "production" — any other value seeds DEMONSTRATION books on an empty database.');
  if (env('NODE_ENV') === 'production') pass('NODE_ENV=production');
  else warn('NODE_ENV is not "production".');
}

// --- Owner activation ----------------------------------------------------------
if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(env('BPZ_OWNER_EMAIL'))) pass('BPZ_OWNER_EMAIL is set');
else fail('BPZ_OWNER_EMAIL is missing or not an email address.');

const token = env('BPZ_SETUP_TOKEN');
if (token.length >= 24) pass('BPZ_SETUP_TOKEN length OK');
else fail('BPZ_SETUP_TOKEN must be at least 24 random characters (openssl rand -hex 32).');
if (/REPLACE|CHANGE|example|your-/i.test(token)) fail('BPZ_SETUP_TOKEN still contains a placeholder value.');
if (env('BPZ_SEED_PASSWORD_OWNER') || env('BPZ_SEED_PASSWORD_DEMO')) {
  fail('BPZ_SEED_PASSWORD_* is set — demo seed passwords must never exist on a production server.');
}

// --- Database ------------------------------------------------------------------
let dbUrl = null;
try { dbUrl = new URL(env('DATABASE_URL')); } catch { /* handled below */ }
if (!dbUrl || !/^postgres(ql)?:$/.test(dbUrl.protocol)) {
  fail('DATABASE_URL is missing or is not a PostgreSQL URL.');
} else {
  pass(`DATABASE_URL targets ${dbUrl.hostname}:${dbUrl.port || 5432}${dbUrl.pathname}`);
  if (decodeURIComponent(dbUrl.username) === 'postgres') {
    warn('The app connects as the postgres SUPERUSER. Create a dedicated bpz_app user (guide step 4).');
  }
  if (production && /sandbox|preview|demo|test/i.test(dbUrl.pathname)) {
    fail(`Database name "${dbUrl.pathname.slice(1)}" looks like a preview/test database. Production needs its own empty database.`);
  }
}

// --- Backups -------------------------------------------------------------------
if (env('BPZ_REQUIRE_OFFSITE_BACKUP') === 'true') {
  if (env('S3_BUCKET') && env('S3_ACCESS_KEY_ID') && env('S3_SECRET_ACCESS_KEY')) pass('Off-site backup target configured');
  else fail('BPZ_REQUIRE_OFFSITE_BACKUP=true but S3_BUCKET / S3_ACCESS_KEY_ID / S3_SECRET_ACCESS_KEY are incomplete.');
} else if (production) {
  warn('BPZ_REQUIRE_OFFSITE_BACKUP is not true — backups on the same server are not disaster recovery.');
}
const backupDir = env('BPZ_BACKUP_DIR');
if (backupDir) {
  if (existsSync(backupDir)) {
    try { accessSync(backupDir, constants.W_OK); pass(`BPZ_BACKUP_DIR writable (${backupDir})`); }
    catch { fail(`BPZ_BACKUP_DIR ${backupDir} exists but is not writable by this user.`); }
  } else warn(`BPZ_BACKUP_DIR ${backupDir} does not exist yet (create it before the first scheduled backup).`);
} else if (production) warn('BPZ_BACKUP_DIR not set — backups will land in ./backups relative to the working directory.');

// --- Security policy -------------------------------------------------------------
for (const key of ['BPZ_ENFORCE_MFA_OWNER', 'BPZ_ENFORCE_MFA_CHECKERS']) {
  if (env(key) === 'true') pass(`${key}=true`);
  else if (production) warn(`${key} is not true — required by the runbook for owner/checker accounts.`);
}
if (production && !env('BPZ_CSP_FRAME_ANCESTORS')) {
  warn('BPZ_CSP_FRAME_ANCESTORS not set — set it to \'none\' at the app or edge (guide step 8 does it in Caddy).');
}

// --- Live database checks (best effort) ------------------------------------------
if (dbUrl) {
  try {
    const { Client } = await import('pg');
    const client = new Client({ connectionString: env('DATABASE_URL'), connectionTimeoutMillis: 5000 });
    await client.connect();
    await client.query('select 1');
    pass('Database reachable');
    const users = await client.query('select username from users').catch(() => ({ rows: [] }));
    if (users.rows.length) {
      const demo = users.rows.map((r) => r.username).filter((u) => ['demo', 'agro_accountant'].includes(u));
      if (production && demo.length) fail(`Database contains demonstration accounts: ${demo.join(', ')}. This is not a clean production database.`);
      const pending = await client.query("select value from system_settings where key = 'owner_activation'").catch(() => ({ rows: [] }));
      if (pending.rows[0]?.value?.pending) warn('Owner activation is still PENDING — complete step 9 of the guide before announcing go-live.');
      else if (production) pass(`Database has ${users.rows.length} user(s), owner activated`);
    } else if (production) {
      pass('Database schema not seeded yet (first start will provision it in production mode)');
    }
    await client.end();
  } catch (error) {
    fail(`Database connection failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}

console.log(`\n${fails} failure(s), ${warns} warning(s)${production ? ' [production gate]' : ''}`);
process.exit(fails ? 1 : 0);
