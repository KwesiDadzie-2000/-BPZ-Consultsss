import { useState, useEffect, useRef, useCallback } from 'react';
import { Menu } from 'lucide-react';
import { LoginScreen, clearSession } from './components/LoginScreen';
import { AccountingHeader } from './components/AccountingHeader';
import { AccountingSidebar } from './components/AccountingSidebar';
import { AccountingDashboard } from './components/AccountingDashboard';
import { ProcurementSection } from './components/ProcurementSection';
import { SalesSection } from './components/SalesSection';
import { PayrollSection } from './components/PayrollSection';
import { BankingSection } from './components/BankingSection';
import { ManualJournalSection } from './components/ManualJournalSection';
import { FinancialStatementsSection } from './components/FinancialStatementsSection';
import { ComplianceReviewDesk } from './components/ComplianceReviewDesk';
import { ModulePrintButton } from './components/ModulePrintButton';
import { FixedAssetsSection } from './components/FixedAssetsSection';
import { ExpensesSection } from './components/ExpensesSection';
import { PaymentDeskSection } from './components/PaymentDeskSection';
import { ClientsManagementSection } from './components/ClientsManagementSection';
import { AdvisorySection } from './components/AdvisorySection';
import { MonthEndSection } from './components/MonthEndSection';
import { LoansAmortisationDesk, type DebtServiceRequest } from './components/LoansAmortisationDesk';
import { buildDebtServiceAccrualJournal, buildDebtServicePaymentJournal, normalizeJournalAmounts } from './utils/loans';
import { ProjectCostingDesk } from './components/ProjectCostingDesk';
import { RegulatedIndustriesDesk } from './components/RegulatedIndustriesDesk';
import { MySecurityDesk } from './components/MySecurityDesk';
import { CompanyProfileSection } from './components/CompanyProfileSection';
import { ChartOfAccountsSection, type AccountScope } from './components/ChartOfAccountsSection';
import { GeneralLedgerSection } from './components/GeneralLedgerSection';
import { TaxSchedulesSection } from './components/TaxSchedulesSection';
import type { ResetAccountsOptions } from './components/CompanyProfileSection';
import { BusinessPartnersSection } from './components/BusinessPartnersSection';
import { OpeningBalanceSection } from './components/OpeningBalanceSection';
import { applyLedgerAuthority, deriveTreasuryLedger } from './lib/treasuryDerivation';
import { TaxFilingScheduleSection } from './components/TaxFilingScheduleSection';
import { TaxSettingsDesk } from './components/TaxSettingsDesk';
import { TaxDesk } from './components/TaxDesk';
import { PrepaymentsSection } from './components/PrepaymentsSection';
import { AdjustmentsDesk } from './components/AdjustmentsDesk';
import { IfrsDesk } from './components/IfrsDesk';
import { HrManagementDesk } from './components/HrManagementDesk';
import { CrmDesk } from './components/CrmDesk';
import { ReportsHub } from './components/ReportsHub';
import { InventoryWorkspace } from './components/InventoryWorkspace';
import { AgeingAnalysisDesk } from './components/AgeingAnalysisDesk';
import { BomDesk } from './components/BomDesk';
import { ProductionDesk } from './components/ProductionDesk';
import { SectorWorkflowDesk } from './components/SectorWorkflowDesk';
import { profileForClientSector } from './data/sectorProfiles';
import { PerformanceManagementDesk } from './components/PerformanceManagementDesk';
import { DataAnalyticsDesk } from './components/DataAnalyticsDesk';
import { localPeriod, localToday } from './utils/periods';
import { ModuleErrorBoundary } from './components/ModuleErrorBoundary';
import { persistentStorage } from './utils/persistentStorage';
import { chartEditDenialReason, hasFirmWideScope, mayEditChartOfAccounts, maySeeSection } from './utils/access';
import { fundingAccountFor as resolveFunding, paymentAccountFor, type PaymentMethod } from './utils/treasury';
import { deriveExpenseBills, liabilityBalance, EXPENSE_PAYABLE_ACCOUNT, type ExpenseBill, type StatutoryPayableRow, type PaymentResult, type PaymentExtras, type PaymentPayee, payeeSuffix, whtSuffix } from './utils/payables';
import { computeCustomerVatWithholding } from './utils/transactionMath';
import { buildCreditNoteEntries, buildDebitNoteEntries } from './utils/reports';
import { buildReversalLines, buildYearEndCloseEntries, checkReversal } from './utils/journalControls';
import { translateToFunctional, setActiveCurrency } from './utils/currency';
import { setLastPostingRefusal } from './utils/postingNotice';
import {
  apiFetch,
  apiFetchVerified,
  clearSessionStore,
  confirmSessionLost,
  probeSession,
  broadcastSessionChange,
} from './utils/session';

// Enterprise owner-only administration components
import { DisclosureNotesDesk } from './components/DisclosureNotesDesk';
import { ConsolidationDesk } from './components/ConsolidationDesk';
import { SsoDesk } from './components/SsoDesk';
import { GlobalTaxDesk } from './components/GlobalTaxDesk';
import { SocBackupDesk } from './components/SocBackupDesk';
import { OperationsDesk } from './components/OperationsDesk';
import { IntegrationsDesk } from './components/IntegrationsDesk';
import { UserPermissionsDesk } from './components/UserPermissionsDesk';
import { ApprovalsModal } from './components/ApprovalsModal';

import {
  INITIAL_CLIENTS,
  INITIAL_CHART_OF_ACCOUNTS,
} from './data/accountingSeed';
import {
  applyIssue,
  applyReceipt,
  inventoryAccountName,
  applyLandedCost,
  buildCogsEntries,
  buildFreightEntries,
  buildMovement,
  buildReturnInEntries,
  type CostMethod,
} from './utils/trading';
import {
  ClientEntity,
  UserAccount,
  ACDOCALine,
  PurchaseOrder,
  SalesInvoice,
  EmployeeProfile,
  DisclosureNote,
  BankAccount,
  AccountMaster,
  BusinessPartner,
  MonthlyPayrollRecord,
  PaymentSettlementMeta,
  TaxScheduleEntry,
  StockItem,
  StockMovement,
  FixedAsset,
} from './types/accounting';
import { docSuffix, uniqueId } from './utils/ids';
import { isLocalReview } from './preview/config';
import { dashboardModel } from './utils/dashboardModel';
import { taxConfigStore } from './utils/taxConfig';
import { ControlAccountsDesk } from './components/ControlAccountsDesk';
import { reconcileControlAccounts, controlAccountSummary } from './utils/controlAccounts';
import { validateJournalLines, validatePostingIdentity, validateMakerChecker } from './lib/journalValidation';
import { browserPostingDirectory, sessionPostingRecord } from './lib/postingControls';

/**
 * Shown while the server is being asked "who is signed in?". Rendering the
 * login form during that window is precisely the "signed in, then instantly
 * back at the login portal" flash that was reported.
 */
function RestoringSession() {
  return (
    <div className="min-h-screen bg-[#f0f6fc] text-[#0a253e] flex items-center justify-center font-sans">
      <div className="flex flex-col items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#f5b719] font-black text-[#082f4f] text-lg shadow-md">
          BPZ
        </span>
        <div className="text-xs font-bold uppercase tracking-widest text-[#355875]">Opening your secure session…</div>
      </div>
    </div>
  );
}

/** Workspace code from a `?workspace=CODE` sign-in link, if the page was opened from one. */
function readWorkspaceParam(): string | null {
  try {
    const value = new URLSearchParams(globalThis.location?.search ?? '').get('workspace');
    return value && value.trim() ? value.trim().toUpperCase() : null;
  } catch {
    return null;
  }
}

/** Non-owners only ever see their own entity; the Firm Owner and firm-wide partners see all. */
function scopeClients(list: ClientEntity[], user: UserAccount): ClientEntity[] {
  if (hasFirmWideScope(user)) return list;
  return list.filter((c) => c.id === user.clientId);
}

export function App() {
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [workspaceCode, setWorkspaceCode] = useState<string | null>(() => readWorkspaceParam());
  const [signInNotice, setSignInNotice] = useState<string | null>(null);
  const [restoring, setRestoring] = useState(true);

  /**
   * Restore the session ONCE, before the login form is ever considered.
   *
   * The server is asked even when JavaScript holds no token, because the
   * HttpOnly session cookie (set at sign-in) needs no storage at all — that is
   * what keeps a signed-in user signed in across reloads, new tabs, restored
   * tabs, blocked site data and proxies that strip `Authorization` headers.
   */
  useEffect(() => {
    let cancelled = false;
    const restore = async () => {
      if (workspaceCode) {
        // A sign-in link always starts at the sign-in form. Any session already in this
        // browser (for example the firm owner's) is ended first, so opening a client's
        // link can never drop the user into somebody else's workspace.
        clearSession();
        if (!cancelled) setRestoring(false);
        return;
      }
      const probe = await Promise.race([
        probeSession(),
        new Promise<null>((resolve) => setTimeout(() => resolve(null), 8000)),
      ]);
      if (cancelled) return;
      if (probe && probe.user) {
        setSignInNotice(null);
        const probedUser = probe.user as UserAccount;
        persistentStorage.adoptUser(probedUser.username);
        persistentStorage.upsertUserAccount(probedUser);
        setCurrentUser(probedUser);
      } else if (probe === null || probe?.unreachable) {
        // The server could not be reached. If this browser still holds a token
        // and a cached identity, keep the user in their books (browser-side
        // copy, sync resumes when the server returns) instead of locking them
        // out at the door — an outage is not a sign-out.
        setSignInNotice('The sign-in service could not be reached. Reconnect and sign in to verify your access; a cached identity cannot authorise access to client records.');
      }
      setRestoring(false);
    };
    void restore();
    return () => { cancelled = true; };
  }, []);

  // Tabs must agree: signing out (or being signed out) anywhere signs out here.
  useEffect(() => {
    const onStorage = (event: StorageEvent) => {
      if (event.key !== 'bpz_session_signal_v1') return;
      const value = typeof event.newValue === 'string' ? event.newValue : '';
      if (value.startsWith('out:')) {
        clearSessionStore();
        setCurrentUser(null);
        setRestoring(false);
      }
    };
    try { globalThis.addEventListener?.('storage', onStorage); } catch { /* ignore */ }
    return () => { try { globalThis.removeEventListener?.('storage', onStorage); } catch { /* ignore */ } };
  }, []);

  if (restoring) return <RestoringSession />;

  if (!currentUser) {
    return (
      <LoginScreen
        notice={signInNotice}
        workspaceCode={workspaceCode}
        onLogin={(user, workspace, assignedClient) => {
          setSignInNotice(null);
          // Purge the previous user's cached data before anything renders.
          persistentStorage.adoptUser(user.username);
          persistentStorage.upsertUserAccount(user);
          if (assignedClient) {
            persistentStorage.saveClients([assignedClient]);
            persistentStorage.saveCurrentClientId(assignedClient.id);
          } else if (workspace && user.role === 'owner') {
            persistentStorage.saveCurrentClientId(workspace.id);
          }
          if (workspaceCode) {
            // The link has been used: drop it from the address bar so a refresh restores normally.
            try { window.history.replaceState(null, '', window.location.pathname); } catch { /* ignore */ }
          }
          setWorkspaceCode(null);
          setCurrentUser(user);
        }}
      />
    );
  }

  return (
    <AccountingWorkspace
      key={currentUser.username}
      currentUser={currentUser}
      onSwitchUser={setCurrentUser}
      onSignOut={() => { clearSession(); setCurrentUser(null); }}
      onSessionExpired={() => {
        // Reached only after the server has CONFIRMED (twice) that the session
        // is gone - see confirmSessionLost(). A transient 401, a cold serverless
        // instance or a stripped Authorization header no longer throws a
        // signed-in user back to the login portal.
        clearSessionStore();
        broadcastSessionChange(false);
        setSignInNotice('Your secure session ended, so the workspace stopped syncing to the firm\u2019s server. Everything you entered is still saved in this browser — sign in again to resume syncing.');
        setCurrentUser(null);
      }}
    />
  );
}

function AccountingWorkspace({
  currentUser,
  onSwitchUser,
  onSignOut,
  onSessionExpired,
}: {
  currentUser: UserAccount;
  onSwitchUser: (user: UserAccount) => void;
  onSignOut: () => void;
  onSessionExpired: () => void;
}) {
  const [clients, setClients] = useState<ClientEntity[]>(() => scopeClients(persistentStorage.getClients(), currentUser));
  const [currentClientId, setCurrentClientId] = useState<number>(() =>
    currentUser.role !== 'owner' && currentUser.clientId ? currentUser.clientId : persistentStorage.getCurrentClientId()
  );
  // Entity isolation: a non-owner user is hard-bound to their own entity. If their
  // assigned entity no longer exists, `workspaceMissing` blocks the render below so
  // they see nothing rather than another client's books.
  const resolvedClient = currentUser.role !== 'owner' && currentUser.clientId
    ? clients.find((c) => c.id === currentUser.clientId)
    : clients.find((c) => c.id === currentClientId) || clients[0];
  const workspaceMissing = !resolvedClient;
  const currentClient = resolvedClient || INITIAL_CLIENTS[1];
  // Publish the entity's functional currency before any desk renders, so every
  // amount is labelled with THIS entity's symbol rather than a hard-coded cedi sign.
  setActiveCurrency(currentClient.currency);
  const [activeSection, setActiveSectionRaw] = useState<string>('dashboard');
  // Mobile navigation drawer + the independently scrolling content pane.
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const mainRef = useRef<HTMLElement | null>(null);
  // Documents the server has confirmed (bootstrap, accepted POST or sync). The
  // full-state sync sends only journal documents NOT in this set: posted journals
  // are append-only, so resending the whole history on every edit (tens of MB
  // for a multi-entity practice) bought nothing and grew without bound.
  const serverDocKeys = useRef<Set<string>>(new Set());
  const pendingDocKeys = useRef<Set<string>>(new Set());
  const stateRevision = useRef<number>(0);
  const syncConflicted = useRef(false);
  const docKey = (l: { clientId: number; docNo: string }) => `${l.clientId}:${l.docNo}`;
  // Entities whose journal has been loaded from the server in this session ('all' = every entity).
  const loadedEntities = useRef<Set<number | 'all'>>(new Set());
  // Every navigation (sidebar, dashboard tiles, in-page links) closes the drawer and
  // returns the content pane to the top, so the click is always visibly acknowledged
  // instead of leaving the user scrolled to the bottom of the previous page.
  const setActiveSection = useCallback((section: string) => {
    setActiveSectionRaw(section);
    setMobileNavOpen(false);
    requestAnimationFrame(() => {
      mainRef.current?.scrollTo({ top: 0, behavior: 'auto' });
      if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'auto' });
    });
  }, []);
  useEffect(() => {
    if (!mobileNavOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setMobileNavOpen(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [mobileNavOpen]);
  // Visible audit of anything that failed server-side — nothing fails silently.
  const [systemNotices, setSystemNotices] = useState<string[]>([]);
  const [lastPostingNotice, setLastPostingNotice] = useState<string | null>(null);
  // The most recent refusal is ALSO kept in a ref: a desk that calls the posting
  // service reads the reason synchronously in the same event handler. Reading it
  // from the `lastPostingNotice` prop gave the desk the PREVIOUS render's value —
  // an empty or stale reason ("check the System Notices bar") for a fresh refusal.
  const lastPostingNoticeRef = useRef<string | null>(null);
  const getPostingNotice = useCallback(() => lastPostingNoticeRef.current, []);
  const pushNotice = (msg: string) => {
    lastPostingNoticeRef.current = msg;
    setLastPostingRefusal(msg);
    setLastPostingNotice(msg);
    // Each notice carries the time it was raised. Notices stay until dismissed, and
    // an untimed one read as a CURRENT failure on every page visited afterwards.
    const raisedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setSystemNotices((prev) => (prev.some((entry) => entry.endsWith(msg)) ? prev : [...prev.slice(-4), `${raisedAt} — ${msg}`]));
  };
  useEffect(() => {
    const onWarning = (event: Event) => pushNotice((event as CustomEvent<string>).detail);
    window.addEventListener('bpz-storage-warning', onWarning);
    return () => window.removeEventListener('bpz-storage-warning', onWarning);
  }, []);

  // Shared reactive accounting data from backend
  const [lines, setLines] = useState<ACDOCALine[]>(() => persistentStorage.getJournalLines());
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => persistentStorage.getBankAccounts());
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(() => persistentStorage.getPurchaseOrders());
  const [salesInvoices, setSalesInvoices] = useState<SalesInvoice[]>(() => persistentStorage.getSalesInvoices());
  const [employees, setEmployees] = useState<EmployeeProfile[]>(() => persistentStorage.getEmployees());
  const [notes, setNotes] = useState<DisclosureNote[]>(() => persistentStorage.getDisclosureNotes());
  // Closed fiscal periods per entity — each entity's books freeze independently.
  const [closedPeriodsMap, setClosedPeriodsMap] = useState<Record<number, string[]>>(() => persistentStorage.getClosedPeriods());
  const closedPeriods = closedPeriodsMap[currentClient.id] || [];
  // "Is the current month closed" for this entity (drives the desk-level posting guards).
  // Local calendar month (was the UTC month, wrong around midnight / month-end outside UTC).
  const isPeriodClosed = closedPeriods.includes(localPeriod());
  const [chartOfAccounts, setChartOfAccounts] = useState<AccountMaster[]>(() => {
    const stored = persistentStorage.getChartOfAccounts();
    const storedNos = new Set(stored.map((a) => a.accountNo));
    const missing = INITIAL_CHART_OF_ACCOUNTS.filter((a) => !storedNos.has(a.accountNo));
    return missing.length ? [...stored, ...missing] : stored;
  });
  const [businessPartners, setBusinessPartners] = useState<BusinessPartner[]>(() => persistentStorage.getBusinessPartners());
  // Perpetual inventory (item master + movement history) and the tax-aware asset register.
  const [stockItems, setStockItems] = useState<StockItem[]>(() => persistentStorage.getStockItems());
  const [stockMovements, setStockMovements] = useState<StockMovement[]>(() => persistentStorage.getStockMovements());
  const [fixedAssets, setFixedAssets] = useState<FixedAsset[]>(() => persistentStorage.getAssets());
  // Statutory schedule edits & manual additions (WHT / VAT schedules), tenant-scoped.
  const [taxScheduleEntries, setTaxScheduleEntries] = useState<TaxScheduleEntry[]>(() => persistentStorage.getTaxScheduleEntries());
  // Live server-sync state shown in the header (replaces the permanent "workspace notice" banner).
  const [syncStatus, setSyncStatus] = useState<{ state: 'idle' | 'syncing' | 'synced' | 'offline' | 'rejected' | 'paused'; at?: string; detail?: string }>({ state: 'idle' });
  // Untagged legacy sample rows belong only to the original demonstration client.
  const ownedByCurrent = (row: { clientId?: number }) => (row.clientId ?? INITIAL_CLIENTS[1].id) === currentClient.id;
  const visibleBanks = bankAccounts.filter(ownedByCurrent);
  const visibleOrders = purchaseOrders.filter(ownedByCurrent);
  const visibleInvoices = salesInvoices.filter(ownedByCurrent);
  const visibleEmployees = employees.filter(ownedByCurrent);
  const visiblePartners = businessPartners.filter(ownedByCurrent);
  const visibleStockItems = stockItems.filter((i) => i.clientId === currentClient.id);
  const visibleStockMovements = stockMovements.filter((m) => m.clientId === currentClient.id);
  const visibleAssets = fixedAssets.filter(ownedByCurrent);
  // Chart of accounts is NOT pooled: every entity sees the firm master chart
  // (accounts with no owner) plus only its OWN custom accounts. Accounts created
  // inside another client's workspace never leak into this one.
  // An entity-owned row that shares a number with a firm master account is that
  // entity's TAILORED version of the account and shadows the master here only.
  const visibleAccounts = (() => {
    const own = chartOfAccounts.filter((a) => a.clientId === currentClient.id);
    const ownNos = new Set(own.map((a) => a.accountNo));
    return [...chartOfAccounts.filter((a) => a.clientId == null && !ownNos.has(a.accountNo)), ...own].sort((a, b) => a.accountNo.localeCompare(b.accountNo));
  })();
  const currentProfile = persistentStorage.getCompanyProfiles()[currentClient.id];
  const [isApprovalsModalOpen, setIsApprovalsModalOpen] = useState(false);
  // Approvals are entity-scoped: the header badge counts only the ACTIVE
  // workspace's pending requests, so opening one client never surfaces another
  // entity's documents at the top of the screen.
  const [approvalRevision, setApprovalRevision] = useState(0);
  const refreshApprovalsCount = () => {
    setApprovalRevision((revision) => revision + 1);
  };
  const approvalsCount = persistentStorage
    .getApprovalRequests()
    .filter((r) => r.status === 'pending' && r.clientId === currentClient.id).length;

  useEffect(() => { if (clients.length > 0) persistentStorage.saveClients(clients); }, [clients]);
  useEffect(() => { persistentStorage.saveCurrentClientId(currentClientId); }, [currentClientId]);
  useEffect(() => { persistentStorage.saveJournalLines(lines); }, [lines]);
  useEffect(() => { persistentStorage.saveBankAccounts(bankAccounts); }, [bankAccounts]);
  useEffect(() => { persistentStorage.savePurchaseOrders(purchaseOrders); }, [purchaseOrders]);
  useEffect(() => { persistentStorage.saveSalesInvoices(salesInvoices); }, [salesInvoices]);
  useEffect(() => { persistentStorage.saveEmployees(employees); }, [employees]);
  useEffect(() => { persistentStorage.saveDisclosureNotes(notes); }, [notes]);
  useEffect(() => { persistentStorage.saveClosedPeriods(closedPeriodsMap); }, [closedPeriodsMap]);
  useEffect(() => { persistentStorage.saveChartOfAccounts(chartOfAccounts); }, [chartOfAccounts]);
  useEffect(() => { persistentStorage.saveBusinessPartners(businessPartners); }, [businessPartners]);
  useEffect(() => { persistentStorage.saveTaxScheduleEntries(taxScheduleEntries); }, [taxScheduleEntries]);
  useEffect(() => { persistentStorage.saveStockItems(stockItems); }, [stockItems]);
  useEffect(() => { persistentStorage.saveStockMovements(stockMovements); }, [stockMovements]);
  useEffect(() => { persistentStorage.saveAssets(fixedAssets); }, [fixedAssets]);

  // Hydrate from the server (authoritative, tenant-scoped) once per session.
  const [hydrated, setHydrated] = useState(false);
  // Server sync is only allowed once THIS session has loaded the authoritative
  // server state. Previously a failed /api/bootstrap (network error, 5xx) still
  // set `hydrated`, and the debounced sync then PUT this browser's stale
  // localStorage copy — which, for the owner, replaced every table on the server.
  const [serverStateLoaded, setServerStateLoaded] = useState(false);

  // The general ledger is the ONLY authority for a treasury balance: it is a
  // derived cache of posted journals, not a number a desk may set. Recompute it
  // here so the balance shown, the balance synced and the balance stored can
  // never disagree — which is what used to make the server refuse the whole
  // workspace sync ("Treasury record BNK-01 balance 20000.00 does not agree with
  // the ledger (40000.00). Cash moves only through posted journals."). Opening
  // balances, IAS 21 FX revaluations, asset disposals, manual journals and trade
  // postings all move cash through the ledger without touching the treasury
  // record, so this one derivation replaces the hand-maintained `balance ± delta`
  // arithmetic scattered across the payment, sales and procurement handlers.
  useEffect(() => {
    if (!hydrated || !serverStateLoaded) return;
    const loaded = loadedEntities.current;
    // A firm-wide user may have pulled only some entities' journals. Never derive
    // a balance for an entity whose journal has not been loaded — that would
    // display and then sync a false zero.
    const authoritative = applyLedgerAuthority(bankAccounts, deriveTreasuryLedger(lines));
    let changed = false;
    const next = bankAccounts.map((b, i) => {
      const eligible = b.clientId != null && (loaded.has('all') || loaded.has(b.clientId));
      if (!eligible) return b;
      const derived = authoritative[i];
      if (derived === b || Math.abs((derived.balance ?? 0) - (b.balance ?? 0)) < 0.005) return b;
      changed = true;
      return derived;
    });
    if (changed) setBankAccounts(next);
  }, [lines, bankAccounts, hydrated, serverStateLoaded]);

  const handleRefreshAllData = () => {
    setClients(scopeClients(persistentStorage.getClients(), currentUser));
    setCurrentClientId(
      currentUser.role !== 'owner' && currentUser.clientId ? currentUser.clientId : persistentStorage.getCurrentClientId()
    );
    setLines(persistentStorage.getJournalLines());
    setBankAccounts(persistentStorage.getBankAccounts());
    setPurchaseOrders(persistentStorage.getPurchaseOrders());
    setSalesInvoices(persistentStorage.getSalesInvoices());
    setEmployees(persistentStorage.getEmployees());
    setNotes(persistentStorage.getDisclosureNotes());
    setChartOfAccounts(persistentStorage.getChartOfAccounts());
    setBusinessPartners(persistentStorage.getBusinessPartners());
    setClosedPeriodsMap(persistentStorage.getClosedPeriods());
    setTaxScheduleEntries(persistentStorage.getTaxScheduleEntries());
    setStockItems(persistentStorage.getStockItems());
    setStockMovements(persistentStorage.getStockMovements());
    setFixedAssets(persistentStorage.getAssets());
  };

  // Applies an authoritative /api/bootstrap payload to the browser copy and the
  // React state. Used by the initial hydration AND after every server-side
  // P2P / O2C posting (which writes journal lines, stock and bank balances on
  // the server directly) so the legacy desks never hold — or sync back — a
  // stale copy of those tables.
  const applyServerState = (b: { ok?: boolean; state?: any } | null): boolean => {
      if (!b?.ok || !b.state) {
        pushNotice('The server workspace response could not be understood — server sync is paused so nothing is overwritten. Reload the page to retry.');
        return false;
      }
      const s = b.state;
      stateRevision.current = Number(s.stateRevision ?? 0);
      syncConflicted.current = false;
      persistentStorage.saveClients(s.clients || []);
      // Journals arrive per entity for firm-wide users. A scoped load replaces only
      // that entity's journal and keeps entities already loaded this session.
      const incoming: ACDOCALine[] = s.journalLines || [];
      let journal: ACDOCALine[];
      if (typeof s.journalScope === 'number') {
        const scope = s.journalScope as number;
        journal = [...persistentStorage.getJournalLines().filter((l) => l.clientId !== scope && loadedEntities.current.has(l.clientId)), ...incoming];
        loadedEntities.current.add(scope);
      } else {
        journal = incoming;
        loadedEntities.current = new Set<number | 'all'>(['all', ...(s.clients || []).map((c: { id: number }) => c.id)]);
      }
      persistentStorage.saveJournalLines(journal);
      serverDocKeys.current = new Set(journal.map(docKey));
      persistentStorage.saveBankAccounts(s.bankAccounts || []);
      persistentStorage.savePurchaseOrders(s.purchaseOrders || []);
      persistentStorage.saveSalesInvoices(s.salesInvoices || []);
      persistentStorage.saveEmployees(s.employees || []);
      persistentStorage.saveBusinessPartners(s.businessPartners || []);
      persistentStorage.savePayrollRecords(s.payrollRecords || []);
      persistentStorage.saveApprovalRequests(s.approvalRequests || []);
      persistentStorage.savePrepayments(s.prepaymentRecords || []);
      persistentStorage.savePrepaymentSchedules(s.prepaymentSchedules || []);
      persistentStorage.saveCompanyProfiles(s.companyProfiles || {});
      persistentStorage.saveChartOfAccounts(s.chartOfAccounts || []);
      persistentStorage.saveDisclosureNotes(s.disclosureNotes || []);
      persistentStorage.saveTaxScheduleEntries(s.taxScheduleEntries || []);
      void taxConfigStore.fetchFromServer();
      if (s.stockItems) persistentStorage.saveStockItems(s.stockItems);
      if (s.stockMovements) persistentStorage.saveStockMovements(s.stockMovements);
      if (s.fixedAssets) persistentStorage.saveAssets(s.fixedAssets);
      const closedMap: Record<number, string[]> = {};
      for (const c of s.closedPeriods || []) {
        (closedMap[c.clientId] ||= []).push(c.period);
      }
      persistentStorage.saveClosedPeriods(closedMap);
      if (Array.isArray(s.users)) {
        const cachedDirectory = new Map(persistentStorage.getUserAccounts().map((u: UserAccount) => [u.username, u]));
        for (const row of s.users as UserAccount[]) cachedDirectory.set(row.username, row);
        cachedDirectory.set(currentUser.username, currentUser);
        persistentStorage.saveUserAccounts([...cachedDirectory.values()]);
      }
      handleRefreshAllData();
      setServerStateLoaded(true);
      return true;
  };

  // Re-pull the server workspace after a server-authoritative posting. The trade
  // desks await this before re-enabling, so the ledger, inventory and banking
  // desks show the new journal/stock/cash immediately and the next debounced
  // full-state sync carries the server's own rows instead of overwriting them.
  const pullServerState = async (scope: number | 'all' = currentClient.id): Promise<void> => {
    const { response, sessionLost } = await apiFetchVerified(`/api/bootstrap?entity=${scope}`);
    if (sessionLost) { onSessionExpired(); return; }
    if (!response) { pushNotice('The posting was committed on the server, but the workspace could not be re-loaded — reload the page to see the updated ledger.'); return; }
    if (!response.ok) { pushNotice(`The posting was committed on the server, but the workspace re-load failed (HTTP ${response.status}) — reload the page to see the updated ledger.`); return; }
    const body = await response.json().catch(() => null);
    applyServerState(body);
  };

  // Resilient load: retries, and only a CONFIRMED dead session signs the user out.
  useEffect(() => {
    if (hydrated) return;
    let cancelled = false;
    const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

    const run = async () => {
      // The server is ALWAYS asked, even when no token is readable from
      // JavaScript storage: the HttpOnly session cookie carries the session on
      // its own. Skipping this call used to strand such users on a browser-only
      // copy that never synced.
      for (let attempt = 0; attempt < 3; attempt += 1) {
        try {
          const r = await apiFetch(`/api/bootstrap?entity=${persistentStorage.getCurrentClientId()}`);
          if (r.status === 401 || r.status === 403) {
            // Believe a rejection only once the server confirms it twice. A lone
            // 401 — stripped Authorization header, cached proxy response, cold
            // serverless instance — used to bounce the user to the login portal
            // a moment after a successful sign-in.
            const lost = await confirmSessionLost();
            if (cancelled) return;
            if (lost) { onSessionExpired(); return; }
            if (attempt < 2) { await sleep(600); continue; }
            pushNotice('The workspace load was rejected by the server, but your session is still valid — server sync is paused. Reload the page to retry.');
            return;
          }
          if (!r.ok) {
            const detail = await r.json().catch(() => null);
            if (cancelled) return;
            pushNotice(`The server workspace could not be loaded (HTTP ${r.status}${detail?.error ? `: ${detail.error}` : ''}) — server sync is paused so nothing is overwritten. Reload the page to retry.`);
            return;
          }
          const body = await r.json().catch(() => null);
          if (cancelled) return;
          applyServerState(body);
          return;
        } catch {
          if (cancelled) return;
          if (attempt < 2) { await sleep(800); continue; }
          pushNotice('The server could not be reached — server sync is paused so nothing is overwritten. Reload the page to retry.');
          return;
        }
      }
    };

    void run().finally(() => { if (!cancelled) setHydrated(true); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated]);

  // Load an entity's journal the first time a firm-wide user opens it, and every
  // entity's journal only when Group Consolidation actually needs them.
  useEffect(() => {
    if (!serverStateLoaded || loadedEntities.current.has('all')) return;
    const timer = window.setTimeout(() => {
      if (activeSection === 'group_consolidation') { void pullServerState('all'); return; }
      if (!loadedEntities.current.has(currentClient.id)) void pullServerState(currentClient.id);
    }, 0);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [serverStateLoaded, currentClient.id, activeSection]);

  // Debounced full-state sync to the server (authoritative, validated, transactional).
  useEffect(() => {
    if (!hydrated || !serverStateLoaded || currentUser.role === 'auditor' || currentUser.status !== 'active') return;
    const t = setTimeout(() => {
      if (syncConflicted.current || pendingDocKeys.current.size > 0) return;
      // No `getSessionToken()` guard: the HttpOnly cookie authenticates the PUT
      // even when JavaScript storage holds no token, so a blocked/cleared store
      // used to switch server sync off silently and permanently.
      const unsyncedLines = lines.filter((l) => !serverDocKeys.current.has(docKey(l)));
      const payload = {
        stateRevision: stateRevision.current,
        clients,
        journalLines: unsyncedLines,
        bankAccounts,
        purchaseOrders,
        salesInvoices,
        employees,
        businessPartners,
        payrollRecords: persistentStorage.getPayrollRecords(),
        prepaymentRecords: persistentStorage.getPrepayments(),
        prepaymentSchedules: persistentStorage.getPrepaymentSchedules(),
        approvalRequests: persistentStorage.getApprovalRequests(),
        companyProfiles: persistentStorage.getCompanyProfiles(),
        chartOfAccounts,
        disclosureNotes: notes,
        closedPeriods: Object.entries(closedPeriodsMap).flatMap(([clientId, periods]) =>
          periods.map((period) => ({ clientId: Number(clientId), period }))
        ),
        taxScheduleEntries,
        stockItems,
        stockMovements,
        fixedAssets,
      };
      setSyncStatus((prev) => ({ ...prev, state: 'syncing' }));
      void (async () => {
        // A 401 here is VERIFIED (and the PUT retried once) before anybody is
        // signed out — this call fired ~800 ms after sign-in and was the second
        // path that dropped users back onto the login portal.
        const { response, sessionLost } = await apiFetchVerified('/api/state', {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
        if (sessionLost) { onSessionExpired(); return; }
        if (!response) {
          setSyncStatus({ state: 'offline', at: new Date().toISOString(), detail: 'The server could not be reached — changes are saved in this browser and sync on the next connection.' });
          pushNotice('Workspace sync failed — the server could not be reached. Changes remain in this browser.');
          return;
        }
        if (response.ok) {
          for (const line of unsyncedLines) serverDocKeys.current.add(docKey(line));
          setSyncStatus({ state: 'synced', at: new Date().toISOString() });
          // The server resolves duplicate document numbers instead of rejecting
          // the sync — surface exactly what it decided, so nothing is silent.
          const okBody = await response.json().catch(() => null);
          if (Number.isSafeInteger(okBody?.stateRevision)) stateRevision.current = okBody.stateRevision;
          const serverWarnings: unknown[] = Array.isArray(okBody?.warnings) ? okBody.warnings : [];
          for (const w of serverWarnings) if (typeof w === 'string') pushNotice(w);
          return;
        }
        const b = await response.json().catch(() => null);
        const serverError = b?.error || `HTTP ${response.status}`;
        if (response.status === 409 && String(serverError).includes('revision')) {
          syncConflicted.current = true;
          pushNotice('Another tab changed these books. Automatic sync is paused to prevent losing work. Reload the workspace to see the latest server records.');
        }
        setSyncStatus({ state: 'rejected', at: new Date().toISOString(), detail: serverError });
        pushNotice(`Workspace sync was NOT accepted by the server: ${serverError}`);
        console.warn('Server rejected state sync:', serverError);
      })();
    }, 800);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, serverStateLoaded, clients, lines, bankAccounts, purchaseOrders, salesInvoices, employees, notes, chartOfAccounts, businessPartners, closedPeriodsMap, taxScheduleEntries, stockItems, stockMovements, fixedAssets, approvalRevision]);

  // Once hydration finished without an authoritative server copy, sync is paused on purpose.
  useEffect(() => {
    const timer = window.setTimeout(() => {
      if (hydrated && !serverStateLoaded) setSyncStatus({ state: 'paused', detail: 'The server workspace could not be loaded, so nothing is overwritten. Reload the page to retry.' });
      else if (hydrated && serverStateLoaded) setSyncStatus((prev) => (prev.state === 'paused' || prev.state === 'idle' ? { state: 'synced', at: new Date().toISOString() } : prev));
    }, 0);
    return () => window.clearTimeout(timer);
  }, [hydrated, serverStateLoaded]);

  const isOwner = currentUser.role === 'owner';

  // Control account reconciliation: every GL control vs its sub-ledger, recomputed
  // from the live workspace — drives the Control Accounts desk and the month-end gate.
  const controlAccountRows = reconcileControlAccounts({
    clientId: currentClient.id,
    lines,
    invoices: visibleInvoices,
    orders: visibleOrders,
    stockItems: visibleStockItems,
    bankAccounts: visibleBanks,
    assets: visibleAssets,
    prepayments: persistentStorage.getPrepayments(),
    prepaymentSchedules: persistentStorage.getPrepaymentSchedules(),
    payrollRecords: persistentStorage.getPayrollRecords(),
    partners: persistentStorage.getBusinessPartners(),
    taxEntries: taxScheduleEntries,
  });
  const controlRecoExceptions = controlAccountSummary(controlAccountRows).exceptions;

  // Double-entry validation
  const clientLines = lines.filter((l) => l.clientId === currentClient.id);
  const isBalanced = dashboardModel(lines, currentClient).isBalanced;
  const uniqueDocs = new Set(clientLines.map((l) => l.docNo)).size;

  const handleAddJournalLines = (incoming: ACDOCALine[], docCurrency?: string, expectedClientId?: number, onRejected?: () => void): boolean => {
    if (!incoming.length) return false;
    // Defensive money normalisation: computed schedules (loans, amortisation,
    // depreciation runs) must never reach the ledger with sub-pesewa floats; each
    // line is rounded to 2dp and any pesewa residue is settled on the largest line.
    // Legs that round to zero on BOTH sides carry no accounting information but are
    // refused by the posting controls, so one empty component (no principal on an
    // interest-only instalment, no levy on an exempt sale, a nil payroll deduction)
    // used to sink the whole document. They are dropped before validation.
    const newLines = normalizeJournalAmounts(incoming)
      .filter((l) => Math.round(l.debit * 100) !== 0 || Math.round(l.credit * 100) !== 0);
    if (!newLines.length) { pushNotice(`Document ${incoming[0]?.docNo || 'JOURNAL'} was not posted: every line has a zero amount.`); return false; }
    setLastPostingNotice(null);
    lastPostingNoticeRef.current = null;
    setLastPostingRefusal(null);
    const docLabel = newLines[0]?.docNo || 'JOURNAL';
    // Every refusal names its exact control. These branches used to `return false`
    // with no notice at all, leaving the desk to guess ("the period may be closed,
    // the accounts may be invalid, or the document already exists").
    const refuse = (reason: string): false => { pushNotice(reason); return false; };
    const directory = browserPostingDirectory(persistentStorage.getUserAccounts(), currentUser);
    const validationError = validateJournalLines(newLines, {
      allowedClientIds: [expectedClientId ?? currentClient.id],
      closedPeriodKeys: new Set(Object.entries(closedPeriodsMap).flatMap(([id, periods]) => periods.map((period) => `${id}:${period}`))),
      coaAccountNos: new Set(chartOfAccounts.map((account) => account.accountNo)),
      isAccountPostable: (number, id) => (chartOfAccounts.find((account) => account.accountNo === number && account.clientId === id)
        || chartOfAccounts.find((account) => account.accountNo === number && account.clientId == null))?.active === true,
    }) || validatePostingIdentity(newLines, { session: sessionPostingRecord(currentUser), users: directory })
      || validateMakerChecker(newLines, { username: currentUser.username, makerLimit: currentUser.makerLimit, users: directory });
    if (validationError) return refuse(validationError);
    // Per-entity, per-period freeze: no posting into a closed period.
    const frozenLine = newLines.find((l) => (closedPeriodsMap[l.clientId] || []).includes(l.period));
    if (frozenLine) return refuse(`Document ${docLabel} was not posted: period ${frozenLine.period} is closed and frozen for this entity. Reopen it in Month-End Close or choose an open posting date.`);
    // The owner may post into another entity (e.g. approving a client's queued
    // document while working in a different workspace) — the expected client is
    // therefore parameterised; its functional currency is the default.
    const expectedClient = clients.find((c) => c.id === (expectedClientId ?? currentClient.id)) || currentClient;
    // Every posted line must belong to that entity, carry the document currency,
    // and reference an account that exists in the chart of accounts.
    const expectedCurrency = docCurrency || expectedClient.currency;
    // The ledger holds ONE currency per entity (IAS 21). A desk that raises a
    // foreign-currency document must translate it with an explicit rate; posting
    // the foreign amount straight into the ledger would add unlike currencies.
    if (expectedCurrency !== expectedClient.currency) {
      pushNotice(`${expectedCurrency} document ${newLines[0]?.docNo ?? ''} was not posted: ${expectedClient.code} reports in ${expectedClient.currency}. Capture the ${expectedCurrency} → ${expectedClient.currency} rate and post it through Journals (Manual) so the ledger stays in one currency.`);
      return false;
    }
    const knownAccounts = new Set(
      chartOfAccounts.filter((a) => a.clientId == null || a.clientId === expectedClient.id).map((a) => a.accountNo)
    );
    if (newLines.some((l) => l.clientId !== expectedClient.id)) return refuse(`Document ${docLabel} was not posted: it contains lines for a different entity than ${expectedClient.code}.`);
    const strayCurrency = newLines.find((l) => l.currency !== expectedCurrency);
    if (strayCurrency) return refuse(`Document ${docLabel} was not posted: a line is denominated in ${strayCurrency.currency} but the document currency is ${expectedCurrency}.`);
    const unknownAccount = newLines.find((l) => !knownAccounts.has(l.accountNo));
    if (unknownAccount) return refuse(`Document ${docLabel} was not posted: account ${unknownAccount.accountNo} is not in ${expectedClient.code}'s chart of accounts.`);
    if (newLines.some((l) => !Number.isFinite(l.debit) || !Number.isFinite(l.credit) || l.debit < 0 || l.credit < 0)) return refuse(`Document ${docLabel} was not posted: it contains a negative or non-numeric amount.`);
    // Document integrity (mirrors the server posting service): one-sided, non-zero
    // lines; one period and one posting date per document; at least two lines.
    if (newLines.some((l) => (Math.round(l.debit * 100) > 0 && Math.round(l.credit * 100) > 0) || (Math.round(l.debit * 100) === 0 && Math.round(l.credit * 100) === 0))) return refuse(`Document ${docLabel} was not posted: every line must carry either a debit or a credit (not both, and not zero).`);
    // One period/date per DOCUMENT (a batch may legitimately carry several documents).
    const headers = new Map<string, string>();
    for (const l of newLines) {
      const header = `${l.period}|${l.date}`;
      const seen = headers.get(l.docNo);
      if (seen !== undefined && seen !== header) return refuse(`Document ${l.docNo} was not posted: its lines mix posting dates or accounting periods.`);
      headers.set(l.docNo, header);
    }
    if (newLines.length < 2) return refuse(`Document ${docLabel} was not posted: double entry needs at least two lines.`);
    const debits = newLines.reduce((n, l) => n + Math.round(l.debit * 100), 0);
    const credits = newLines.reduce((n, l) => n + Math.round(l.credit * 100), 0);
    if (debits !== credits || debits <= 0) return refuse(`Document ${docLabel} was not posted: it does not balance (Dr ${(debits / 100).toFixed(2)} vs Cr ${(credits / 100).toFixed(2)} ${expectedCurrency}).`);
    const duplicate = newLines.find((l) => lines.some((existing) => existing.clientId === l.clientId && existing.docNo === l.docNo));
    if (duplicate) return refuse(`Document ${duplicate.docNo} was not posted: that document number already exists in ${expectedClient.code}'s books. Nothing was changed — post it under a new document number.`);
    for (const line of newLines) pendingDocKeys.current.add(docKey(line));
    setLines(previous => [...previous, ...newLines]);
    // Never let a pending local journal or its register side effects reach the
    // snapshot endpoint before the immutable posting service confirms it.
    void (async () => {
      let confirmed = false;
      let sessionLost = false;
      try {
        const result = await apiFetchVerified('/api/journal', {
          method: 'POST', body: JSON.stringify({ lines: newLines }),
        });
        sessionLost = result.sessionLost;
        if (result.response?.ok) {
          confirmed = true;
          for (const line of newLines) serverDocKeys.current.add(docKey(line));
        } else {
          const body = await result.response?.json().catch(() => null);
          const detail = body?.error ?? (result.response ? `HTTP ${result.response.status}` : 'server unreachable');
          // A response from the posting service is a DEFINITIVE answer: the document
          // was refused and nothing was committed. Only a missing response (network
          // failure) leaves the outcome uncertain and warrants "reload to verify".
          pushNotice(result.response
            ? `Document ${docLabel} was REJECTED by the server and removed from this workspace: ${detail}`
            : `Document ${docLabel} was NOT confirmed by the server (${detail}). Reload before retrying; it may have been committed before the connection failed.`);
        }
      } catch (cause) {
        pushNotice(`Document ${newLines[0]?.docNo || 'JOURNAL'} was NOT confirmed: ${cause instanceof Error ? cause.message : 'network error'}. Reload to verify before retrying.`);
      } finally {
        for (const line of newLines) pendingDocKeys.current.delete(docKey(line));
        if (confirmed) {
          // Re-trigger snapshot sync for document registers only after the journal
          // has committed; no simultaneous partial settlement or stock writes.
          setLines((previous) => [...previous]);
        } else {
          const ids = new Set(newLines.map((line) => line.id));
          setLines((previous) => previous.filter((line) => !ids.has(line.id)));
          onRejected?.();
          if (sessionLost) onSessionExpired();
          else void pullServerState(expectedClientId ?? currentClient.id);
        }
      }
    })();
    return true;
  };

  const periodFrom = (date: string) => date.slice(0, 7);
  const postDate = () => localToday();
  // Payment references must be unique per entity; partial settlements reuse the
  // same base reference, so a suffix is appended when it is already posted.
  const uniqueDocNo = (base: string, clientId: number) =>
    lines.some((l) => l.clientId === clientId && l.docNo === base) ? `${base}-${docSuffix()}` : base;

  // Queue an above-maker-limit payment for independent approval. The proposed
  // journal AND its settlement side effects travel with the request, so approval
  // actually effects the payment (treasury movement + document settlement).
  const queuePaymentApproval = (
    docNo: string,
    description: string,
    amount: number,
    entries: ACDOCALine[],
    settlement: PaymentSettlementMeta,
  ): PaymentResult => {
    persistentStorage.addApprovalRequest({
      id: `${uniqueId('APP-PAY')}`, clientId: currentClient.id, clientCode: currentClient.code, clientName: currentClient.name,
      docNo, docType: 'PAY', amount,
      requestedBy: `${currentUser.name} (${currentUser.username})`, requestedAt: new Date().toISOString(),
      description,
      reasonForApproval: `Amount ${amount.toFixed(2)} exceeds maker limit ${currentUser.makerLimit.toFixed(2)}. On approval the payment is posted and effected automatically.`,
      status: 'pending', payload: { lines: entries, settlement },
    });
    refreshApprovalsCount();
    return 'queued';
  };

  // Receive an approved PO and post the selected material/service GL, VAT and payable.
  // Honours the vendor's VAT treatment: non-VAT / zero-rated bills post no input VAT line.
  const handlePostPOToJournal = (po: PurchaseOrder): boolean => {
    const date = postDate();
    const period = periodFrom(date);
    const net = po.netAmount ?? Math.round(po.qty * po.unitPrice * 100) / 100;
    const poCurrency = po.currency || currentClient.currency;
    const debitAccount = po.glAccount || (po.itemType === 'material' ? '120000' : '621000');
    const debitName = po.glAccountName || (po.itemType === 'material' ? 'Inventories — Raw Materials & Spares' : 'Contracted Services & Subcontractor Costs');
    const docNo = po.poNo;
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo, period, date, module: 'MM', docType: 'PO', accountNo: debitAccount, accountName: debitName, costCenter: po.costCenter, debit: net, credit: 0, currency: poCurrency, description: `${po.itemType} receipt: ${po.itemDescription}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL')}-3`, docNo, period, date, module: 'MM', docType: 'PO', accountNo: '200000', accountName: `Trade Payables (${po.vendorName})`, costCenter: po.costCenter, debit: 0, credit: po.totalAmount, currency: poCurrency, description: `Supplier payable for ${po.poNo}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    // Input VAT line only when the vendor's bill actually carries VAT.
    if (po.vatRecoverable > 0) {
      entries.splice(1, 0, { id: `${uniqueId('JL')}-2`, docNo, period, date, module: 'MM', docType: 'PO', accountNo: '125000', accountName: 'VAT Input Tax Recoverable', costCenter: po.costCenter, debit: po.vatRecoverable, credit: 0, currency: poCurrency, description: `Input VAT on ${po.poNo}`, createdBy: currentUser.username, clientId: currentClient.id });
    }
    // Trading goods: the receipt is recognised in the perpetual item master and
    // any inward freight is capitalised into the cost of the goods (IAS 2.11).
    const stockItem = po.itemCode
      ? stockItems.find((i) => i.clientId === currentClient.id && i.itemCode === po.itemCode)
      : undefined;
    const freight = Math.round((po.inwardFreight || 0) * 100) / 100;
    if (po.itemCode && !stockItem) { pushNotice(`${po.poNo} was not received: stock item ${po.itemCode} no longer exists in this entity's inventory master.`); return false; }
    if (stockItem) {
      // The inventory debit must hit the item's control account so the
      // valuation report and the ledger stay reconciled.
      const control = stockItem.glAccount || '120000';
      entries[0] = { ...entries[0], accountNo: control, accountName: inventoryAccountName(control) };
    }
    const result = handleAddJournalLines(entries, poCurrency);
    if (result && stockItem) {
      const receipt = applyReceipt(stockItem, po.qty, po.unitPrice);
      let nextItem = receipt.item;
      const movements = [buildMovement({
        clientId: currentClient.id, date, item: stockItem, type: 'Receipt', quantity: po.qty,
        unitCost: po.unitPrice, totalValue: receipt.cost, docNo: po.poNo, reference: po.vendorName,
        note: 'Goods received against purchase order',
      })];
      if (freight > 0) {
        const freightDoc = `${po.poNo}-FRT`;
        const landed = applyLandedCost(nextItem, freight);
        const freightPosted = handleAddJournalLines(
          buildFreightEntries(
            { docNo: freightDoc, date, currency: poCurrency, clientId: currentClient.id, createdBy: currentUser.username, costCenter: po.costCenter },
            freight,
            po.itemCode || stockItem.itemCode,
          ),
          poCurrency,
        );
        if (freightPosted && !landed.error) {
          nextItem = landed.item;
          movements.push(buildMovement({
            clientId: currentClient.id, date, item: nextItem, type: 'Freight', quantity: 0,
            unitCost: 0, totalValue: freight, docNo: freightDoc, reference: po.vendorName,
            note: 'Inward freight capitalised into inventory cost',
          }));
          const funding = bankAccounts.find((b) => b.glAccount === '100000' && b.clientId === currentClient.id)
            || bankAccounts.find((b) => b.clientId === currentClient.id && b.kind !== 'cash');
          if (funding) setBankAccounts((prev) => prev.map((b) => (b.id === funding.id ? { ...b, balance: Math.round((b.balance - freight) * 100) / 100 } : b)));
        }
      }
      setStockItems((prev) => prev.map((i) => (i.id === stockItem.id ? nextItem : i)));
      setStockMovements((prev) => [...prev, ...movements]);
    }
    if (result) setPurchaseOrders(previous => previous.map(p => p.id === po.id ? { ...p, status: 'Invoiced', paidAmount: p.paidAmount || 0 } : p));
    return result;
  };

  // Debit note (purchase return): reverses the payable, the GL charge and input VAT.
  // Posted in the ORDER's currency (a USD bill reversed in GHS used to be refused
  // or, worse, mis-stated), and stocked goods are issued back out of inventory so
  // the perpetual item master agrees with the ledger.
  const handleIssueDebitNote = (po: PurchaseOrder): boolean => {
    if (isPeriodClosed) { pushNotice(`Not posted: the current period is closed and frozen for ${currentClient.code}. Reopen it in Month-End Close or post in the next open period.`); return false; }
    if (po.status === 'Paid' || po.status === 'Debited') { pushNotice(`Debit note for ${po.poNo} refused: the bill is already ${po.status === 'Paid' ? 'paid' : 'debited'}.`); return false; }
    if ((po.paidAmount || 0) > 0.009) { pushNotice(`Debit note for ${po.poNo} refused: the bill is partly paid — correct it at the Payment Desk / P2P desk.`); return false; } // partly paid bills are corrected at the Payment Desk / P2P desk
    const date = postDate();
    const poCurrency = po.currency || currentClient.currency;
    const entries = buildDebitNoteEntries(po, date, poCurrency, currentClient.id, currentUser.username);
    // Only a RECEIVED (posted) order has stock to return; an open order was never received.
    const item = po.status !== 'Open' && po.itemCode
      ? stockItems.find((i) => i.clientId === currentClient.id && i.itemCode === po.itemCode)
      : undefined;
    let issue: ReturnType<typeof applyIssue> | null = null;
    if (item) {
      if (item.quantityOnHand + 0.0005 < po.qty) { pushNotice(`Debit note for ${po.poNo} refused: only ${item.quantityOnHand} ${item.uom} of ${item.itemCode} remain in stock, so ${po.qty} cannot be returned to the supplier.`); return false; }
      issue = applyIssue(item, po.qty, stockMovements, (item.costMethod as CostMethod) || 'weighted_average');
      if (issue.error) { pushNotice(`Debit note for ${po.poNo} refused: ${issue.error}`); return false; }
      // The stock leaves at carrying value; the inventory credit on the note is the
      // purchase cost, so any difference is a purchase price variance (520000).
      const control = item.glAccount || '120000';
      const net = po.netAmount ?? Math.round(po.qty * po.unitPrice * 100) / 100;
      const variance = Math.round((net - issue.cost) * 100) / 100;
      entries[1] = { ...entries[1], accountNo: control, credit: issue.cost };
      if (Math.abs(variance) >= 0.01) {
        entries.push({ ...entries[1], id: `${uniqueId('JL-DN')}-v`, accountNo: '520000', accountName: 'Purchase Price & Landed Cost Variances', debit: variance < 0 ? -variance : 0, credit: variance > 0 ? variance : 0, description: `Debit note for ${po.poNo} — carrying value vs purchase cost difference` });
      }
    }
    const result = handleAddJournalLines(entries, poCurrency);
    if (result) {
      if (item && issue) {
        setStockItems((prev) => prev.map((i) => (i.id === item.id ? issue!.item : i)));
        setStockMovements((prev) => [...prev, buildMovement({
          clientId: currentClient.id, date, item, type: 'ReturnOut', quantity: po.qty,
          unitCost: issue!.unitCost, totalValue: issue!.cost, docNo: entries[0].docNo, reference: po.vendorName,
          note: 'Goods returned to supplier under debit note',
        })]);
      }
      setPurchaseOrders(previous => previous.map(p => p.id === po.id ? { ...p, status: 'Debited', paidAmount: 0 } : p));
    }
    return result;
  };

  // Credit note (sales return): reverses revenue, output VAT and sector levies against the receivable.
  const handleIssueCreditNote = (inv: SalesInvoice): boolean => {
    if (isPeriodClosed) { pushNotice(`Not posted: the current period is closed and frozen for ${currentClient.code}. Reopen it in Month-End Close or post in the next open period.`); return false; }
    if (inv.status === 'Draft' || inv.status === 'Credited') { pushNotice(`Credit note for ${inv.invNo} refused: the invoice is ${inv.status === 'Draft' ? 'still a draft (never posted)' : 'already credited'}.`); return false; }
    const date = postDate();
    const entries = buildCreditNoteEntries(inv, date, currentClient.currency, currentClient.id, currentUser.username);
    // Saleable goods taken back into stock reverse the cost of sales only to the
    // extent the goods are recoverable (IAS 2 / IFRS 15 returns).
    const item = inv.returnToStock && inv.itemType === 'goods' && inv.itemCode
      ? stockItems.find((i) => i.clientId === currentClient.id && i.itemCode === inv.itemCode)
      : undefined;
    const recoverableCost = item ? Math.round((inv.cogsAmount || 0) * 100) / 100 : 0;
    if (item && recoverableCost > 0) {
      entries.push(
        ...buildReturnInEntries(
          { docNo: entries[0].docNo, date, currency: currentClient.currency, clientId: currentClient.id, createdBy: currentUser.username, costCenter: 'CC-SLS' },
          recoverableCost,
          item.itemCode,
        ),
      );
    }
    const result = handleAddJournalLines(entries);
    if (result) {
      if (item && recoverableCost > 0) {
        const returned = applyReceipt(item, inv.quantity || 0, (inv.quantity || 0) > 0 ? recoverableCost / (inv.quantity || 1) : 0);
        setStockItems((prev) => prev.map((i) => (i.id === item.id ? returned.item : i)));
        setStockMovements((prev) => [...prev, buildMovement({
          clientId: currentClient.id, date, item, type: 'ReturnIn', quantity: inv.quantity || 0,
          unitCost: (inv.quantity || 0) > 0 ? recoverableCost / (inv.quantity || 1) : 0, totalValue: recoverableCost,
          docNo: entries[0].docNo, reference: inv.customerName, note: 'Customer return restored to stock',
        })]);
      }
      setSalesInvoices(previous => previous.map(i => i.id === inv.id ? { ...i, status: 'Credited' } : i));
    }
    return result;
  };

  // Issue sales invoice: Dr trade receivable / Cr revenue and configured statutory liabilities.
  const handlePostSalesToJournal = (inv: SalesInvoice): boolean => {
    // Credit control: a REGISTERED customer's standing governs whether a sale
    // may be issued on credit. A customer placed On Hold or Blocked on the
    // Business Partners master may not take further credit, and no invoice may
    // be issued that pushes the customer's exposure beyond the approved limit.
    // A customer with no registered limit is cash-on-delivery — registering one
    // with a limit is how credit is granted.
    const customer = visiblePartners.find(
      (p) => p.type === 'Customer' && p.name.trim().toLowerCase() === inv.customerName.trim().toLowerCase(),
    );
    if (customer) {
      const standing = customer.creditStatus || 'Active';
      if (standing !== 'Active') {
        pushNotice(`Invoice ${inv.invNo} was not posted: ${customer.name} is "${standing}" on the Business Partners master, so no new credit may be issued. Clear the hold on the Client Master File first.`);
        return false;
      }
      const limit = customer.creditLimit ?? 0;
      if (limit > 0) {
        const openExposure = (customer.openingBalance ?? 0) + visibleInvoices
          .filter((i) => i.customerName === inv.customerName && (i.status === 'Open' || i.status === 'Partial'))
          .reduce((n, i) => n + Math.max(0, i.totalReceivable - (i.paidAmount || 0)), 0);
        if (openExposure + inv.totalReceivable > limit + 0.009) {
          pushNotice(`Invoice ${inv.invNo} was not posted: it would take ${customer.name} to ${(openExposure + inv.totalReceivable).toFixed(2)} against an approved credit limit of ${limit.toFixed(2)}. Raise the limit on the Client Master File or collect payment first.`);
          return false;
        }
      }
    }
    const date = postDate();
    const period = periodFrom(date);
    // Revenue is credited to the EXACT account chosen on the invoice; the
    // account must exist in this entity's chart before the document posts.
    const chosen = inv.revenueAccount
      ? visibleAccounts.find((a) => a.accountNo === inv.revenueAccount && a.active)
      : undefined;
    if (inv.revenueAccount && !chosen) { pushNotice(`Invoice ${inv.invNo} was not posted: revenue account ${inv.revenueAccount} is missing or inactive in this entity's chart of accounts.`); return false; }
    const revenueAccountNo = chosen?.accountNo || '400000';
    const revenueAccountName = chosen?.name || 'Revenue from Contracts with Customers';
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo: inv.invNo, period, date, module: 'SD', docType: 'INV', accountNo: '110000', accountName: `Trade Receivables (${inv.customerName})`, costCenter: 'CC-SLS', debit: inv.totalReceivable, credit: 0, currency: currentClient.currency, description: `Sales invoice ${inv.invNo}: ${inv.revenueStream}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL')}-2`, docNo: inv.invNo, period, date, module: 'SD', docType: 'INV', accountNo: revenueAccountNo, accountName: revenueAccountName, costCenter: 'CC-SLS', debit: 0, credit: inv.netRevenue, currency: currentClient.currency, description: `Revenue recognition for ${inv.invNo}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    if (inv.vatOutput > 0) entries.push({ id: `${uniqueId('JL')}-3`, docNo: inv.invNo, period, date, module: 'SD', docType: 'INV', accountNo: '220000', accountName: 'VAT/NHIL/GETFund Output Liability', costCenter: 'CC-SLS', debit: 0, credit: inv.vatOutput, currency: currentClient.currency, description: `VAT stack on ${inv.invNo}`, createdBy: currentUser.username, clientId: currentClient.id });
    if ((inv.cstAmount || 0) > 0) {
      entries.push({
        id: `${uniqueId('JL')}-4`, docNo: inv.invNo, period, date, module: 'SD', docType: 'INV',
        accountNo: '223000', accountName: 'Communication Service Tax Payable', costCenter: 'CC-SLS',
        debit: 0, credit: inv.cstAmount || 0, currency: currentClient.currency,
        description: `CST on ${inv.invNo}`, createdBy: currentUser.username, clientId: currentClient.id,
      });
    }
    if ((inv.tourismLevyAmount || 0) > 0) {
      entries.push({
        id: `${uniqueId('JL')}-5`, docNo: inv.invNo, period, date, module: 'SD', docType: 'INV',
        accountNo: '224000', accountName: 'Tourism Levy Payable', costCenter: 'CC-SLS',
        debit: 0, credit: inv.tourismLevyAmount || 0, currency: currentClient.currency,
        description: `Tourism levy on ${inv.invNo}`, createdBy: currentUser.username, clientId: currentClient.id,
      });
    }
    // Perpetual inventory: goods invoices release the carrying cost of the
    // stock sold in the SAME document, so revenue and its cost always match.
    const item = inv.itemType === 'goods' && inv.itemCode
      ? stockItems.find((i) => i.clientId === currentClient.id && i.itemCode === inv.itemCode)
      : undefined;
    let issue: ReturnType<typeof applyIssue> | null = null;
    if (inv.itemType === 'goods' && inv.itemCode) {
      if (!item) { pushNotice(`Invoice ${inv.invNo} was not posted: stock item ${inv.itemCode} is not in this entity's inventory master.`); return false; }
      issue = applyIssue(item, inv.quantity || 0, stockMovements, (item.costMethod as CostMethod) || 'weighted_average');
      if (issue.error) { pushNotice(`Invoice ${inv.invNo} was not posted: ${issue.error}`); return false; }
      entries.push(
        ...buildCogsEntries(
          { docNo: inv.invNo, date, currency: currentClient.currency, clientId: currentClient.id, createdBy: currentUser.username, costCenter: 'CC-SLS' },
          issue.cost,
          inv.itemCode,
          item.glAccount || undefined,
        ),
      );
    }
    const posted = handleAddJournalLines(entries);
    if (posted) {
      if (item && issue) {
        const movement = buildMovement({
          clientId: currentClient.id, date, item, type: 'Issue', quantity: inv.quantity || 0,
          unitCost: issue.unitCost, totalValue: issue.cost, docNo: inv.invNo, reference: inv.customerName,
          note: 'Stock issued against sales invoice',
        });
        setStockItems((prev) => prev.map((i) => (i.id === item.id ? issue!.item : i)));
        setStockMovements((prev) => [...prev, movement]);
      }
      setSalesInvoices(previous => previous.map(i => i.id === inv.id ? {
        ...i,
        status: i.paidAmount > 0 ? 'Partial' : 'Open',
        unitCost: issue ? issue.unitCost : i.unitCost,
        cogsAmount: issue ? issue.cost : i.cogsAmount,
      } : i));
    }
    return posted;
  };

  // Treasury routing (bank vs cash float vs mobile money) shared with the Payment Desk.
  const fundingAccountFor = (method: PaymentMethod, bank: BankAccount): BankAccount => resolveFunding(method, bank, bankAccounts);
  const aboveMakerLimit = (amount: number) => currentUser.makerLimit > 0 && amount > currentUser.makerLimit;
  const round2 = (n: number) => Math.round(n * 100) / 100;

  const handleSettleSupplierInvoice = (input: {
    po: PurchaseOrder; grossAmount: number; whtRate: number; vatWithheld: number; bankId: number;
    method: PaymentMethod; reference: string;
  } & PaymentExtras): PaymentResult => {
    const { po, grossAmount, whtRate, vatWithheld, bankId, method, reference, payee, whtNote } = input;
    const date = postDate();
    const period = periodFrom(date);
    if (isPeriodClosed) { pushNotice(`Not posted: the current period is closed and frozen for ${currentClient.code}. Reopen it in Month-End Close or post in the next open period.`); return 'failed'; }
    const bank = bankAccounts.find(b => b.id === bankId);
    const outstanding = po.totalAmount - (po.paidAmount || 0);
    if (!bank || grossAmount <= 0 || grossAmount > outstanding + 0.009) { pushNotice(!bank ? 'Payment refused: select the treasury account (bank, cash or mobile money) to pay from.' : grossAmount <= 0 ? 'Payment refused: the amount must be greater than zero.' : `Payment refused: ${grossAmount.toFixed(2)} exceeds the outstanding balance of ${outstanding.toFixed(2)}.`); return 'failed'; }
    // Settlements are posted in the purchase order's own currency.
    const payCurrency = po.currency || currentClient.currency;
    // WHT is charged on the consideration exclusive of VAT and levies (the PO net amount).
    const taxBase = po.totalAmount ? grossAmount * (((po.netAmount ?? po.qty * po.unitPrice) / po.totalAmount)) : 0;
    const incomeWht = Math.round(taxBase * whtRate) / 100;
    const cashPaid = round2(grossAmount - incomeWht - vatWithheld);
    // Draw funds from the treasury record matching the method and the PO currency.
    const selectedFunding = fundingAccountFor(method, bank);
    // The currency fallback must stay inside THIS entity's treasury — it used to
    // pick the first matching-currency account of ANY client.
    const funding = selectedFunding.currency === payCurrency
      ? selectedFunding
      : bankAccounts.find((b) => (b.clientId ?? INITIAL_CLIENTS[1].id) === currentClient.id && b.currency === payCurrency) || selectedFunding;
    if (cashPaid < 0 || funding.balance + 0.009 < cashPaid) { pushNotice(cashPaid < 0 ? 'Payment refused: the withholding deductions exceed the amount being paid.' : `Payment refused: ${funding.name} holds ${funding.currency} ${funding.balance.toFixed(2)}, which does not cover the ${cashPaid.toFixed(2)} being paid.`); return 'failed'; }
    // A foreign-currency bill can only be paid from a treasury account held in
    // that currency; silently crediting a GHS account with USD mis-states both.
    if (funding.currency !== payCurrency) { pushNotice(`No ${payCurrency} treasury account exists for ${currentClient.code} — add one in Banking before settling ${po.poNo}.`); return 'failed'; }
    const paymentGl = paymentAccountFor(method, funding);
    const docNo = uniqueDocNo(reference || `PAY-${po.poNo.replace('PO-', '')}`, currentClient.id);
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: '200000', accountName: `Trade Payables (${po.vendorName})`, costCenter: po.costCenter, debit: grossAmount, credit: 0, currency: payCurrency, description: `Settlement of ${po.poNo}${payeeSuffix(payee)}`, createdBy: currentUser.username, clientId: currentClient.id },
      {
        id: `${uniqueId('JL')}-2`, docNo, period, date, module: 'FI', docType: 'PAY',
        accountNo: paymentGl.no, accountName: paymentGl.name, costCenter: po.costCenter,
        debit: 0, credit: cashPaid, currency: payCurrency,
        description: `${method.replace('_', ' ')} payment for ${po.poNo}${payeeSuffix(payee)}${whtSuffix(whtRate > 0, whtRate, whtNote)}`,
        createdBy: currentUser.username, clientId: currentClient.id,
      },
    ];
    if (incomeWht > 0) entries.push({ id: `${uniqueId('JL')}-3`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: '209000', accountName: 'Income Withholding Tax Payable', costCenter: po.costCenter, debit: 0, credit: incomeWht, currency: payCurrency, description: `Income WHT ${whtRate}% on ${po.poNo}`, createdBy: currentUser.username, clientId: currentClient.id });
    if (vatWithheld > 0) entries.push({ id: `${uniqueId('JL')}-4`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: '221000', accountName: 'VAT Withholding Payable', costCenter: po.costCenter, debit: 0, credit: vatWithheld, currency: payCurrency, description: `VAT withholding on ${po.poNo}`, createdBy: currentUser.username, clientId: currentClient.id });
    if (aboveMakerLimit(grossAmount)) {
      return queuePaymentApproval(docNo, `Supplier settlement: ${po.vendorName} (${po.poNo})${payeeSuffix(payee)}`, grossAmount, entries,
        { kind: 'supplier', clientId: currentClient.id, targetId: po.id, settleAmount: grossAmount, cashDelta: -cashPaid, bankId: funding.id });
    }
    const prevPaid = po.paidAmount || 0;
    const prevStatus = po.status;
    const result = handleAddJournalLines(entries, payCurrency, currentClient.id, () => {
      // Only the PO state was optimistically set above; the bank balance is
      // derived from posted journal lines, so it does not need a rollback here.
      setPurchaseOrders(previous => previous.map(p => p.id === po.id ? { ...p, paidAmount: prevPaid, status: prevStatus } : p));
    });
    if (!result) return 'failed';
    const paidAmount = Math.min(po.totalAmount, prevPaid + grossAmount);
    setPurchaseOrders(previous => previous.map(p => p.id === po.id ? { ...p, paidAmount, status: paidAmount + 0.009 >= p.totalAmount ? 'Paid' : 'Invoiced' } : p));
    if (funding.currency === payCurrency) setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance - cashPaid) } : b));
    return 'posted';
  };

  const handleReceiveCustomerPayment = (input: {
    invoice: SalesInvoice; amount: number; bankId: number; method: PaymentMethod; reference: string;
  }): PaymentResult => {
    const { invoice, amount, bankId, method, reference } = input;
    const date = postDate();
    const period = periodFrom(date);
    if (isPeriodClosed) { pushNotice(`Not posted: the current period is closed and frozen for ${currentClient.code}. Reopen it in Month-End Close or post in the next open period.`); return 'failed'; }
    const bank = bankAccounts.find(b => b.id === bankId);
    const outstanding = invoice.totalReceivable - invoice.paidAmount;
    if (!bank || amount <= 0 || amount > outstanding + 0.009) { pushNotice(!bank ? 'Payment refused: select the treasury account (bank, cash or mobile money) to pay from.' : amount <= 0 ? 'Payment refused: the amount must be greater than zero.' : `Payment refused: ${amount.toFixed(2)} exceeds the outstanding balance of ${outstanding.toFixed(2)}.`); return 'failed'; }
    // Receipts land in the treasury record matching the method (bank, cash float or mobile money).
    const funding = fundingAccountFor(method, bank);
    const receiptGl = paymentAccountFor(method, funding);
    const docNo = uniqueDocNo(reference || `REC-${invoice.invNo.replace('INV-', '')}`, currentClient.id);
    // Appointed VAT-withholding customers deduct 7% of the taxable value at source;
    // the withheld amount settles the receivable via the WHT receivable account (115000).
    const wht = computeCustomerVatWithholding(invoice.vatWithheldByCustomer || 0, invoice.totalReceivable, outstanding, amount);
    const settleTotal = round2(amount + wht);
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: receiptGl.no, accountName: receiptGl.name, costCenter: 'CC-SLS', debit: amount, credit: 0, currency: currentClient.currency, description: `${method.replace('_', ' ')} receipt for ${invoice.invNo}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL')}-2`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: '110000', accountName: `Trade Receivables (${invoice.customerName})`, costCenter: 'CC-SLS', debit: 0, credit: settleTotal, currency: currentClient.currency, description: `Partial/full receipt for ${invoice.invNo}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    if (wht > 0) {
      entries.push({
        id: `${uniqueId('JL')}-3`, docNo, period, date, module: 'FI', docType: 'PAY',
        accountNo: '115000', accountName: 'Withholding Tax Receivable — GRA Credit Notes',
        costCenter: 'CC-SLS', debit: wht, credit: 0, currency: currentClient.currency,
        description: `VAT withheld at source by ${invoice.customerName} on ${invoice.invNo}`,
        createdBy: currentUser.username, clientId: currentClient.id,
      });
    }
    if (aboveMakerLimit(amount)) {
      return queuePaymentApproval(docNo, `Customer receipt: ${invoice.customerName} (${invoice.invNo})`, amount, entries,
        { kind: 'customer', clientId: currentClient.id, targetId: invoice.id, settleAmount: settleTotal, cashDelta: amount, bankId: funding.id });
    }
    const prevPaid = invoice.paidAmount;
    const prevStatus = invoice.status;
    const result = handleAddJournalLines(entries, currentClient.currency, currentClient.id, () => {
      // Only the invoice state was optimistically set above; treasury balances
      // are derived from the posted ledger so no rollback is needed here.
      setSalesInvoices(previous => previous.map(i => i.id === invoice.id ? { ...i, paidAmount: prevPaid, status: prevStatus } : i));
    });
    if (!result) return 'failed';
    const paidAmount = Math.min(invoice.totalReceivable, prevPaid + settleTotal);
    setSalesInvoices(previous => previous.map(i => i.id === invoice.id ? { ...i, paidAmount, status: paidAmount + 0.009 >= i.totalReceivable ? 'Paid' : 'Partial' } : i));
    setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance + amount) } : b));
    return 'posted';
  };

  /**
   * Debt service from the Loan Amortisation desk. The operator decides: PAY —
   * posted immediately and the chosen treasury record is settled (or queued for
   * maker-checker approval above the limit); ACCRUE — the instalment becomes an
   * accrued payable (202000 / EXPB- register) that ages in payables and is
   * settled later at the Payment Desk. Both legs are balanced 2dp documents.
   */
  const handlePostDebtService = (req: DebtServiceRequest): PaymentResult => {
    const { facility, row, mode, bankId, method } = req;
    const date = postDate();
    if (isPeriodClosed) { pushNotice(`Not posted: the current period is closed and frozen for ${currentClient.code}. Reopen it in Month-End Close or post in the next open period.`); return 'failed'; }
    const spec = {
      facility, row, clientId: currentClient.id, currency: currentClient.currency, date,
      username: currentUser.username, canCheck: currentUser.canCheck,
      treasuryAccountNo: '', treasuryAccountName: '',
    };
    if (mode === 'accrue') {
      const entries = buildDebtServiceAccrualJournal(spec);
      const result = handleAddJournalLines(entries);
      return result ? 'posted' : 'failed';
    }
    // Pay: settle from treasury in one atomic posting + balance movement.
    const bank = bankAccounts.find((b) => b.id === bankId);
    if (!bank) { pushNotice('Payment refused: select the treasury account (bank, cash or mobile money) to pay from.'); return 'failed'; }
    const total = row.totalPayment;
    const funding = fundingAccountFor(method ?? 'bank_transfer', bank);
    if (funding.currency !== currentClient.currency) {
      pushNotice(`Instalment ${row.periodNum} on ${facility.code}: choose a ${currentClient.currency} treasury record — the facility settles in the entity's functional currency.`);
      return 'failed';
    }
    if (funding.balance + 0.009 < total) { pushNotice(`Payment refused: ${funding.name} holds ${funding.currency} ${funding.balance.toFixed(2)}, which does not cover the ${total.toFixed(2)} being paid.`); return 'failed'; }
    const paymentGl = paymentAccountFor(method ?? 'bank_transfer', funding);
    const entries = buildDebtServicePaymentJournal({ ...spec, treasuryAccountNo: paymentGl.no, treasuryAccountName: paymentGl.name });
    if (aboveMakerLimit(total)) {
      return queuePaymentApproval(entries[0].docNo, `Debt service: ${facility.code} M${row.periodNum} → ${facility.lender}`, total, entries,
        { kind: 'statutory', clientId: currentClient.id, targetId: facility.code, settleAmount: total, cashDelta: -total, bankId: funding.id });
    }
    const result = handleAddJournalLines(entries, currentClient.currency, currentClient.id, () => {
      setBankAccounts((previous) => previous.map((b) => (b.id === funding.id ? { ...b, balance: round2(b.balance + total) } : b)));
    });
    if (!result) return 'failed';
    setBankAccounts((previous) => previous.map((b) => (b.id === funding.id ? { ...b, balance: round2(b.balance - total) } : b)));
    return 'posted';
  };

  const handleDisburseSalaries = (period: string, amount: number, bankId: number, method: PaymentMethod, payee?: PaymentPayee): PaymentResult => {
    const date = postDate();
    const payPeriod = periodFrom(date);
    if (isPeriodClosed) { pushNotice(`Not posted: the current period is closed and frozen for ${currentClient.code}. Reopen it in Month-End Close or post in the next open period.`); return 'failed'; }
    const bank = bankAccounts.find(b => b.id === bankId);
    if (!bank || amount <= 0) { pushNotice(!bank ? 'Payment refused: select the treasury account (bank, cash or mobile money) to pay from.' : 'Payment refused: the amount must be greater than zero.'); return 'failed'; }
    const payable = liabilityBalance(lines, currentClient.id, '205000');
    if (amount > payable + 0.009) { pushNotice(`Salary disbursement refused: ${amount.toFixed(2)} exceeds the Net Salaries Payable balance of ${payable.toFixed(2)} (GL 205000). Post the payroll run first.`); return 'failed'; }
    const funding = fundingAccountFor(method, bank);
    if (funding.balance + 0.009 < amount) { pushNotice(`Payment refused: ${funding.name} holds ${funding.currency} ${funding.balance.toFixed(2)}, which does not cover the ${amount.toFixed(2)} being paid.`); return 'failed'; }
    const paymentGl = paymentAccountFor(method, funding);
    const docNo = uniqueDocNo(`PAY-SAL-${period}`, currentClient.id);
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo, period: payPeriod, date, module: 'HR', docType: 'PAY', accountNo: '205000', accountName: 'Net Salaries Payable', costCenter: 'CC-HR', debit: amount, credit: 0, currency: currentClient.currency, description: `Net salary release for ${period}${payeeSuffix(payee)}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL')}-2`, docNo, period: payPeriod, date, module: 'FI', docType: 'PAY', accountNo: paymentGl.no, accountName: paymentGl.name, costCenter: 'CC-HR', debit: 0, credit: amount, currency: currentClient.currency, description: `Payroll ${method.replace('_', ' ')}${payeeSuffix(payee)}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    if (aboveMakerLimit(amount)) {
      return queuePaymentApproval(docNo, `Net payroll release for ${period}${payeeSuffix(payee)}`, amount, entries,
        { kind: 'salary', clientId: currentClient.id, settleAmount: amount, cashDelta: -amount, bankId: funding.id });
    }
    const result = handleAddJournalLines(entries, currentClient.currency, currentClient.id, () => {
      setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance + amount) } : b));
    });
    if (result) setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance - amount) } : b));
    return result ? 'posted' : 'failed';
  };

  // Expense bills recorded at the Expenses & Statutory desk are paid ONLY here:
  // Dr 202000 Accrued Expenses & Other Payables (reference = bill no) / Cr treasury,
  // with optional income WHT that itself becomes a statutory payable (209000).
  const handleSettleExpenseBill = (input: {
    bill: ExpenseBill; grossAmount: number; whtRate: number; bankId: number; method: PaymentMethod; reference: string;
  } & PaymentExtras): PaymentResult => {
    const { bill, grossAmount, whtRate, bankId, method, reference, payee, whtNote } = input;
    const date = postDate();
    const period = periodFrom(date);
    if (isPeriodClosed) { pushNotice(`Not posted: the current period is closed and frozen for ${currentClient.code}. Reopen it in Month-End Close or post in the next open period.`); return 'failed'; }
    const liveBill = deriveExpenseBills(lines, currentClient.id).find(b => b.billNo === bill.billNo);
    if (!liveBill || grossAmount <= 0 || grossAmount > liveBill.outstanding + 0.009) {
      const reason = !liveBill
        ? `Payment refused: bill ${bill.billNo} is no longer outstanding in this entity's ledger.`
        : grossAmount <= 0
          ? 'Payment refused: the amount must be greater than zero.'
          : `Payment refused: ${grossAmount.toFixed(2)} exceeds the ${liveBill.outstanding.toFixed(2)} outstanding on ${bill.billNo}.`;
      pushNotice(reason);
      return 'failed';
    }
    const bank = bankAccounts.find(b => b.id === bankId);
    if (!bank) { pushNotice('Payment refused: select the treasury account (bank, cash or mobile money) to pay from.'); return 'failed'; }
    const taxBase = liveBill.gross > 0 ? grossAmount * ((liveBill.gross - liveBill.vat) / liveBill.gross) : 0;
    const incomeWht = Math.round(taxBase * whtRate) / 100;
    const cashPaid = round2(grossAmount - incomeWht);
    const funding = fundingAccountFor(method, bank);
    if (cashPaid < 0 || funding.balance + 0.009 < cashPaid) { pushNotice(cashPaid < 0 ? 'Payment refused: the withholding deductions exceed the amount being paid.' : `Payment refused: ${funding.name} holds ${funding.currency} ${funding.balance.toFixed(2)}, which does not cover the ${cashPaid.toFixed(2)} being paid.`); return 'failed'; }
    const paymentGl = paymentAccountFor(method, funding);
    const docNo = uniqueDocNo(reference || `PAY-${liveBill.billNo.replace('EXPB-', '')}`, currentClient.id);
    const base = { docNo, period, date, module: 'FI' as const, docType: 'PAY' as const, costCenter: liveBill.costCenter, currency: currentClient.currency, createdBy: currentUser.username, clientId: currentClient.id, reference: liveBill.billNo };
    const entries: ACDOCALine[] = [
      { ...base, id: `${uniqueId('JL')}-1`, accountNo: EXPENSE_PAYABLE_ACCOUNT, accountName: `Accrued Expenses & Other Payables (${liveBill.payee})`, debit: grossAmount, credit: 0, description: `Payment of expense bill ${liveBill.billNo} to ${liveBill.payee}${payee && payee.name.trim() !== liveBill.payee ? payeeSuffix(payee) : ''}` },
      { ...base, id: `${uniqueId('JL')}-2`, accountNo: paymentGl.no, accountName: paymentGl.name, debit: 0, credit: cashPaid, description: `${method.replace('_', ' ')} payment for ${liveBill.billNo}${payeeSuffix(payee)}${whtSuffix(whtRate > 0, whtRate, whtNote)}` },
    ];
    if (incomeWht > 0) entries.push({ ...base, id: `${uniqueId('JL')}-3`, accountNo: '209000', accountName: 'Income Withholding Tax Payable', debit: 0, credit: incomeWht, description: `Income WHT ${whtRate}% on expense bill ${liveBill.billNo}` });
    if (aboveMakerLimit(grossAmount)) {
      return queuePaymentApproval(docNo, `Expense bill payment: ${liveBill.payee} (${liveBill.billNo})${payee && payee.name.trim() !== liveBill.payee ? payeeSuffix(payee) : ''}`, grossAmount, entries,
        { kind: 'expense', clientId: currentClient.id, targetId: liveBill.billNo, settleAmount: grossAmount, cashDelta: -cashPaid, bankId: funding.id });
    }
    const result = handleAddJournalLines(entries, currentClient.currency, currentClient.id, () => {
      setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance + cashPaid) } : b));
    });
    if (!result) return 'failed';
    setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance - cashPaid) } : b));
    return 'posted';
  };

  // Statutory remittance (PAYE, SSNIT Tier 1 13.5%, Tier 2 5%, WHT, VAT, levies, CIT):
  // Dr the statutory liability registered by payroll/sales/settlements / Cr treasury.
  const handleRemitStatutory = (input: {
    row: StatutoryPayableRow; amount: number; bankId: number; method: PaymentMethod; reference: string;
  } & PaymentExtras): PaymentResult => {
    const { row, amount, bankId, method, reference, payee } = input;
    const date = postDate();
    const period = periodFrom(date);
    if (isPeriodClosed) { pushNotice(`Not posted: the current period is closed and frozen for ${currentClient.code}. Reopen it in Month-End Close or post in the next open period.`); return 'failed'; }
    const balance = liabilityBalance(lines, currentClient.id, row.accountNo);
    if (amount <= 0 || amount > balance + 0.009) { pushNotice(amount <= 0 ? 'Payment refused: the amount must be greater than zero.' : `Payment refused: ${amount.toFixed(2)} exceeds the ${balance.toFixed(2)} outstanding on account ${row.accountNo}.`); return 'failed'; }
    const bank = bankAccounts.find(b => b.id === bankId);
    if (!bank) { pushNotice('Payment refused: select the treasury account (bank, cash or mobile money) to pay from.'); return 'failed'; }
    const funding = fundingAccountFor(method, bank);
    if (funding.balance + 0.009 < amount) { pushNotice(`Payment refused: ${funding.name} holds ${funding.currency} ${funding.balance.toFixed(2)}, which does not cover the ${amount.toFixed(2)} being paid.`); return 'failed'; }
    const paymentGl = paymentAccountFor(method, funding);
    const accountName = visibleAccounts.find(a => a.accountNo === row.accountNo)?.name || row.label;
    const docNo = uniqueDocNo(reference || `STAT-${row.accountNo}-${period}`, currentClient.id);
    const costCenter = row.payroll ? 'CC-HR' : 'CC-ADM';
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: row.accountNo, accountName, costCenter, debit: amount, credit: 0, currency: currentClient.currency, description: `Statutory remittance: ${row.label} to ${payee?.name.trim() || row.authority}${payee ? ` (${payee.kind})` : ''}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL')}-2`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: paymentGl.no, accountName: paymentGl.name, costCenter, debit: 0, credit: amount, currency: currentClient.currency, description: `${method.replace('_', ' ')} remittance ${docNo}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    if (aboveMakerLimit(amount)) {
      return queuePaymentApproval(docNo, `Statutory remittance: ${row.label} → ${payee?.name.trim() || row.authority}`, amount, entries,
        { kind: 'statutory', clientId: currentClient.id, targetId: row.accountNo, settleAmount: amount, cashDelta: -amount, bankId: funding.id });
    }
    const result = handleAddJournalLines(entries, currentClient.currency, currentClient.id, () => {
      setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance + amount) } : b));
    });
    if (!result) return 'failed';
    setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance - amount) } : b));
    return 'posted';
  };

  const handlePostMonthlyPayroll = (period: string, journalLines: ACDOCALine[], records: MonthlyPayrollRecord[]): boolean => {
    if (isPeriodClosed || journalLines.some((l) => l.clientId !== currentClient.id || l.period !== period)) { pushNotice(isPeriodClosed ? `Not posted: the current period is closed and frozen for ${currentClient.code}. Reopen it in Month-End Close or post in the next open period.` : `Payroll ${period} was not posted: the run contains lines for another entity or another period.`); return false; }
    if (lines.some((l) => l.clientId === currentClient.id && l.docNo === `PAYROLL-${period}`)) { pushNotice(`Payroll ${period} was not posted: PAYROLL-${period} is already in this entity's ledger. Reverse it first to re-run the month.`); return false; }
    const result = handleAddJournalLines(journalLines);
    if (result) {
      // Merge: never wipe previously posted payroll periods for this entity.
      const others = persistentStorage.getPayrollRecords().filter((r) => !(r.clientId === currentClient.id && r.period === period));
      persistentStorage.savePayrollRecords([...others, ...records.map((r) => ({ ...r, clientId: currentClient.id }))]);
    }
    return result;
  };

  const handleUpdateNote = (updated: DisclosureNote) => {
    setNotes(notes.map((n) => (n.key === updated.key ? updated : n)));
  };

  // Immutable counter-reversal: posts to the CURRENT period (never the frozen
  // original period), balanced by construction, one reversal per document, and
  // flags the original lines so the books and the audit trail agree.
  const handleReverseDocument = (docNo: string): boolean => {
    const today = new Date().toISOString();
    const period = today.slice(0, 7);
    const check = checkReversal(lines, docNo, currentClient.id, {
      currentPeriod: period,
      closedPeriods: closedPeriodsMap[currentClient.id] || [],
    });
    if (!check.ok) {
      pushNotice(`Reversal refused: ${check.reason}.`);
      return false;
    }
    const original = lines.filter((l) => l.clientId === currentClient.id && l.docNo === docNo);
    const revLines = buildReversalLines(original, { username: currentUser.username, canCheck: currentUser.canCheck, period, date: today.slice(0, 10) });
    // Reversals must post in the ORIGINAL document's currency (a foreign-currency
    // purchase reversed in the entity's functional currency was silently refused).
    const ok = handleAddJournalLines(revLines, original[0].currency, currentClient.id);
    if (!ok) {
      pushNotice(`Reversal of ${docNo} was refused by the posting controls — the ledger is unchanged.`);
    }
    return ok;
  };

  // Year-end close: transfer the fiscal year's P/L to Retained Earnings (310000)
  // with one balanced document dated 31 December of the closed year.
  const handlePostYearEndClose = (year: number): { net: number; accounts: number } | null => {
    const yearLines = lines.filter((l) => l.clientId === currentClient.id && l.period.startsWith(`${year}-`));
    if (lines.some((l) => l.clientId === currentClient.id && l.docNo === `YE-CLOSE-${year}`)) return null;
    const result = buildYearEndCloseEntries(yearLines, visibleAccounts, {
      year,
      period: `${year}-12`,
      date: `${year}-12-31`,
      currency: currentClient.currency,
      username: currentUser.username,
      canCheck: currentUser.canCheck,
      clientId: currentClient.id,
    });
    if (!result) return null;
    const ok = handleAddJournalLines(result.lines, currentClient.currency, currentClient.id);
    return ok ? { net: result.net, accounts: result.accountsClosed.length } : null;
  };

  // Approval loop: approving a request posts its proposed journal lines exactly
  // once, with the approver as the independent checker of record. Payment requests
  // also carry settlement metadata — on approval the treasury balance moves and the
  // supplier/customer document is settled, so the payment is actually effected.
  const handleApprovePost = async (req: { payload?: { lines: ACDOCALine[]; settlement?: PaymentSettlementMeta }; clientId: number }): Promise<boolean> => {
    const proposed = req.payload?.lines || [];
    if (!proposed.length) return false;
    const settlement = req.payload?.settlement;
    if (settlement && settlement.cashDelta < 0) {
      const fundingBank = bankAccounts.find((b) => b.id === settlement.bankId);
      if (!fundingBank || fundingBank.balance + 0.009 < -settlement.cashDelta) {
        pushNotice(`Approved payment ${req.payload?.lines[0]?.docNo || ''} could NOT be effected: insufficient funds in ${fundingBank?.name || 'the funding account'}. Top up treasury and re-submit.`);
        return false;
      }
    }
    const withChecker = proposed.map((l) => ({ ...l, checkedBy: currentUser.username }));
    const { response, sessionLost } = await apiFetchVerified('/api/journal', {
      method: 'POST', body: JSON.stringify({ lines: withChecker }),
    });
    if (sessionLost) { onSessionExpired(); return false; }
    if (!response?.ok) {
      const result = await response?.json().catch(() => null);
      pushNotice(result?.error || 'Approval was not committed. The request remains pending.');
      return false;
    }
    const posted = true;
    setLines((previous) => [...previous, ...withChecker.filter((line) => !previous.some((old) => old.id === line.id))]);
    if (posted && settlement) {
      setBankAccounts((prev) => prev.map((b) => b.id === settlement.bankId ? { ...b, balance: Math.round((b.balance + settlement.cashDelta) * 100) / 100 } : b));
      if (settlement.kind === 'supplier' && settlement.targetId) {
        setPurchaseOrders((prev) => prev.map((p) => {
          if (p.id !== settlement.targetId) return p;
          const paidAmount = Math.min(p.totalAmount, (p.paidAmount || 0) + settlement.settleAmount);
          return { ...p, paidAmount, status: paidAmount + 0.009 >= p.totalAmount ? 'Paid' : 'Invoiced' };
        }));
      }
      if (settlement.kind === 'customer' && settlement.targetId) {
        setSalesInvoices((prev) => prev.map((i) => {
          if (i.id !== settlement.targetId) return i;
          const paidAmount = Math.min(i.totalReceivable, i.paidAmount + settlement.settleAmount);
          return { ...i, paidAmount, status: paidAmount + 0.009 >= i.totalReceivable ? 'Paid' : 'Partial' };
        }));
      }
      // expense / statutory / salary: the payable register is derived from the
      // ledger, so posting the journal already clears the obligation.
    }
    return posted;
  };

  /* ------------------------------------------------------------------ *
   * Control events raised by the workspace are written to the server audit
   * trail (best effort — the action itself never depends on it).
   * ------------------------------------------------------------------ */
  const logControlEvent = (action: string, target: string, details: string, clientId: number) => {
    void apiFetch('/api/audit', { method: 'POST', body: JSON.stringify({ action, target, details, clientId }) }).catch(() => {});
  };

  /* ------------------------------------------------------------------ *
   * General ledger maintenance — edit / delete a posted document.
   * The server is updated FIRST (validated, audited); the local ledger only
   * follows a confirmed success, so the books on screen never diverge from the
   * books on the server.
   * ------------------------------------------------------------------ */
  const handleEditDocument = async (docNo: string, newLines: ACDOCALine[], reason: string): Promise<{ ok: boolean; error?: string }> => {
    if (!newLines.length) return { ok: false, error: 'No lines supplied.' };
    if (newLines.some((l) => l.clientId !== currentClient.id || l.docNo !== docNo)) return { ok: false, error: 'Edited lines must keep the document number and entity.' };
    if (newLines.some((l) => (closedPeriodsMap[l.clientId] || []).includes(l.period))) return { ok: false, error: `Period ${newLines[0].period} is closed for ${currentClient.code}.` };
    const known = new Set(visibleAccounts.map((a) => a.accountNo));
    if (newLines.some((l) => !known.has(l.accountNo))) return { ok: false, error: 'A line references an account that is not in the chart of accounts.' };
    const dr = newLines.reduce((n, l) => n + Math.round(l.debit * 100), 0);
    const cr = newLines.reduce((n, l) => n + Math.round(l.credit * 100), 0);
    if (dr <= 0 || dr !== cr) return { ok: false, error: 'The edited document is not balanced.' };
    const { response, sessionLost } = await apiFetchVerified('/api/journal', {
      method: 'PATCH',
      body: JSON.stringify({ clientId: currentClient.id, docNo, lines: newLines, reason }),
    });
    if (sessionLost) { onSessionExpired(); return { ok: false, error: 'Your session has ended — sign in again.' }; }
    if (!response) return { ok: false, error: 'The server could not be reached. Document edits need a live connection so the audit trail is complete.' };
    if (!response.ok) {
      const b = await response.json().catch(() => null);
      return { ok: false, error: b?.error || `HTTP ${response.status}` };
    }
    setLines((prev) => [...prev.filter((l) => !(l.clientId === currentClient.id && l.docNo === docNo)), ...newLines]);
    return { ok: true };
  };

  const handleDeleteDocument = async (docNo: string, reason: string): Promise<{ ok: boolean; error?: string }> => {
    const { response, sessionLost } = await apiFetchVerified('/api/journal', {
      method: 'DELETE',
      body: JSON.stringify({ clientId: currentClient.id, docNo, reason }),
    });
    if (sessionLost) { onSessionExpired(); return { ok: false, error: 'Your session has ended — sign in again.' }; }
    if (!response) return { ok: false, error: 'The server could not be reached. Deletions need a live connection so the audit trail is complete.' };
    if (!response.ok) {
      const b = await response.json().catch(() => null);
      return { ok: false, error: b?.error || `HTTP ${response.status}` };
    }
    setLines((prev) => prev.filter((l) => !(l.clientId === currentClient.id && l.docNo === docNo)));
    return { ok: true };
  };

  /* ------------------------------------------------------------------ *
   * Chart of accounts — tailoring per entity and firm-master maintenance.
   * ------------------------------------------------------------------ */
  const handleUpdateAccount = (acc: AccountMaster, scope: AccountScope): { ok: boolean; error?: string } => {
    // Renaming a GL account is restricted master data maintenance: Firm Owner,
    // or the entity's own owner/manager. Staff accounts are read-only here.
    if (!mayEditChartOfAccounts(currentUser)) return { ok: false, error: chartEditDenialReason(currentUser) };
    if (scope === 'firm' && !isOwner) return { ok: false, error: 'Only the Firm Owner may change the firm master chart.' };
    const clean: AccountMaster = { accountNo: acc.accountNo, name: acc.name, type: acc.type, category: acc.category, active: acc.active, isCustom: acc.isCustom, clientId: acc.clientId };
    setChartOfAccounts((prev) => {
      if (scope === 'firm' && acc.clientId == null) {
        return prev.map((a) => (a.clientId == null && a.accountNo === acc.accountNo ? { ...a, name: clean.name, type: clean.type, category: clean.category, active: clean.active } : a));
      }
      // Entity scope: update the entity's own row, or create a tailoring row that shadows the master.
      const idx = prev.findIndex((a) => a.clientId === currentClient.id && a.accountNo === acc.accountNo);
      if (idx >= 0) return prev.map((a, i) => (i === idx ? { ...a, name: clean.name, type: clean.type, category: clean.category, active: clean.active } : a));
      return [...prev, { ...clean, clientId: currentClient.id, isCustom: false }];
    });
    logControlEvent('COA_TAILORED', acc.accountNo, `${scope === 'firm' ? 'Firm master' : currentClient.code} · ${acc.name} · ${acc.type} · ${acc.active ? 'active' : 'inactive'}`, currentClient.id);
    return { ok: true };
  };

  const handleDeleteAccount = (accountNo: string): { ok: boolean; error?: string } => {
    if (!mayEditChartOfAccounts(currentUser)) return { ok: false, error: chartEditDenialReason(currentUser) };
    const row = chartOfAccounts.find((a) => a.clientId === currentClient.id && a.accountNo === accountNo);
    if (!row) return { ok: false, error: 'Firm master accounts cannot be deleted — deactivate the account for this entity instead.' };
    const hasMaster = chartOfAccounts.some((a) => a.clientId == null && a.accountNo === accountNo);
    if (!hasMaster && lines.some((l) => l.clientId === currentClient.id && l.accountNo === accountNo)) {
      return { ok: false, error: `Account ${accountNo} has postings and cannot be deleted. Deactivate it instead.` };
    }
    setChartOfAccounts((prev) => prev.filter((a) => !(a.clientId === currentClient.id && a.accountNo === accountNo)));
    logControlEvent('COA_DELETED', accountNo, hasMaster ? `${currentClient.code} tailoring removed — firm master restored` : `${currentClient.code} custom account deleted`, currentClient.id);
    return { ok: true };
  };

  /* ------------------------------------------------------------------ *
   * Reset accounts — clears ONE entity's books so real balances can be
   * entered. Flows through the normal tenant-scoped server sync and is
   * written to the audit trail. Owner and client users may reset their own
   * workspace; other entities are never touched.
   * ------------------------------------------------------------------ */
  const handleResetAccounts = async (opts: ResetAccountsOptions): Promise<{ ok: boolean; error?: string }> => {
    const cid = currentClient.id;
    if (lines.some((line) => line.clientId === cid)) return { ok: false, error: 'Posted records cannot be erased. Use reversal entries or provision a separate, empty workspace.' };
    if (currentUser.status === 'restricted' || currentUser.status === 'suspended') return { ok: false, error: 'Your account is restricted.' };
    if (!isOwner && currentUser.clientId !== cid) return { ok: false, error: 'You can only reset the books of your own entity.' };
    if (!serverStateLoaded) return { ok: false, error: 'The server workspace is not loaded, so a reset cannot be synced safely. Reload the page and try again.' };
    const belongs = (row: { clientId?: number }) => (row.clientId ?? INITIAL_CLIENTS[1].id) === cid;
    const removedLines = lines.filter((l) => l.clientId === cid).length;
    const removedDocs = new Set(lines.filter((l) => l.clientId === cid).map((l) => l.docNo)).size;

    setLines((prev) => prev.filter((l) => l.clientId !== cid));
    setClosedPeriodsMap((prev) => { const next = { ...prev }; delete next[cid]; return next; });
    if (opts.documents) {
      setPurchaseOrders((prev) => prev.filter((p) => !belongs(p)));
      setSalesInvoices((prev) => prev.filter((i) => !belongs(i)));
      persistentStorage.resetEntityRegisters(cid, { documents: true });
      setTaxScheduleEntries((prev) => prev.filter((t) => t.clientId !== cid));
    }
    if (opts.bankBalances) setBankAccounts((prev) => prev.map((b) => (belongs(b) ? { ...b, balance: 0 } : b)));
    if (opts.masters) {
      setEmployees((prev) => prev.filter((e) => !belongs(e)));
      setBusinessPartners((prev) => prev.filter((p) => !belongs(p)));
    }
    if (opts.customAccounts) setChartOfAccounts((prev) => prev.filter((a) => a.clientId !== cid));
    refreshApprovalsCount();
    logControlEvent('RESET_ACCOUNTS', currentClient.code, `${removedLines} journal line(s) / ${removedDocs} document(s) removed · documents ${opts.documents ? 'cleared' : 'kept'} · bank balances ${opts.bankBalances ? 'zeroed' : 'kept'} · masters ${opts.masters ? 'cleared' : 'kept'} · custom accounts ${opts.customAccounts ? 'cleared' : 'kept'}`, cid);
    return { ok: true };
  };

  const resetPreview = {
    lines: lines.filter((l) => l.clientId === currentClient.id).length,
    documents: new Set(lines.filter((l) => l.clientId === currentClient.id).map((l) => l.docNo)).size,
    purchaseOrders: visibleOrders.length,
    salesInvoices: visibleInvoices.length,
    employees: visibleEmployees.length,
    partners: visiblePartners.length,
    bankAccounts: visibleBanks.length,
    customAccounts: chartOfAccounts.filter((a) => a.clientId === currentClient.id).length,
  };

  /* Statutory schedule lines (WHT / VAT) — edits and manual additions. */
  const handleSaveTaxEntry = (entry: TaxScheduleEntry) => {
    if (entry.clientId !== currentClient.id) return;
    setTaxScheduleEntries((prev) => {
      const without = prev.filter((e) => e.id !== entry.id && !(entry.source === 'ledger' && e.source === 'ledger' && e.clientId === entry.clientId && e.sourceKey === entry.sourceKey));
      return [...without, entry];
    });
    logControlEvent('SCHEDULE_EDITED', entry.docNo, `${entry.kind} · ${entry.source} · ${entry.partyName} · tax ${entry.taxAmount.toFixed(2)}`, currentClient.id);
  };
  const handleDeleteTaxEntry = (id: string) => setTaxScheduleEntries((prev) => prev.filter((e) => !(e.id === id && e.clientId === currentClient.id)));

  // Guard against clients viewing private owner administration sections
  const ownerOnlySections = [
    'clients_management',
    'advisory',
    'user_permissions',
    'group_consolidation',
    'enterprise_sso',
    'global_tax',
    'tax_settings',
    'soc_dr',
    'operations',
    'realtime_integrations',
  ];

  const effectiveSection = (!isOwner && ownerOnlySections.includes(activeSection)) || !maySeeSection(currentUser, currentClient, activeSection)
    ? 'dashboard'
    : activeSection;

  // Reports Centre delegates to the selected report; every legacy/report link
  // resolves to a report instead of a dead section.
  const reportTabs: Record<string, string> = {
    reports: 'sales',
    report_sales: 'sales', report_sales_r: 'sales',
    report_purchases: 'purchases', report_purchases_r: 'purchases',
    report_inventory: 'inventory', report_inventory_r: 'inventory',
    report_clients: 'clients', report_clients_r: 'clients', report_clients_crm: 'clients',
    report_store: 'store', report_store_r: 'store',
    report_hr: 'hr', report_hr_r: 'hr',
    report_production_r: 'production',
    report_ageing_r: 'ageing',
    report_financial: 'financial', report_financial_r: 'financial',
  };
  const statementTabs: Record<string, string> = { financial_issue_position: 'position', financial_issue_profit: 'profit', financial_issue_equity: 'equity', financial_issue_cashflow: 'cashflow', financial_issue_notes: 'notes', financial_issue_compliance: 'compliance' };
  const hrTabs: Record<string, string> = {
    hr_desk: 'employees', hr_employees: 'employees', hr_structure: 'structure',
    hr_attendance: 'attendance', hr_requests: 'requests', hr_tasks: 'tasks',
  };

  // Never render persisted browser books until this session has been authenticated
  // AND its entity-scoped snapshot has arrived. The browser may contain data from
  // an earlier login/role; a failed bootstrap must not expose it or permit edits.
  if (!isLocalReview() && !hydrated) return <RestoringSession />;
  if (!isLocalReview() && !serverStateLoaded) {
    return (
      <div className="min-h-screen bg-[#f0f6fc] flex items-center justify-center p-5 text-[#082f4f]">
        <div role="alert" className="max-w-md rounded-xl border border-amber-300 bg-white p-6 shadow-sm">
          <h1 className="text-lg font-black">Server workspace unavailable</h1>
          <p className="my-3 text-xs leading-relaxed text-[#355875]">Your session could not load its authoritative entity data. Cached books are intentionally hidden to protect client confidentiality; no posting or sync has occurred.</p>
          <div className="flex gap-3">
            <button type="button" onClick={() => window.location.reload()} className="rounded bg-[#082f4f] px-3 py-2 text-xs font-bold text-white">Retry load</button>
            <button type="button" onClick={onSignOut} className="rounded border border-sky-300 px-3 py-2 text-xs font-bold">Sign out</button>
          </div>
        </div>
      </div>
    );
  }

  // Entity isolation guard: never render one client's workspace under another
  // client's account (e.g. a stale or orphaned assignment).
  if (workspaceMissing) {
    return (
      <div className="min-h-screen bg-[#f0f6fc] text-[#0a253e] flex items-center justify-center p-6 font-sans">
        <div className="max-w-md rounded-xl border border-rose-300 bg-rose-50 p-6 text-center shadow-xs">
          <p className="text-sm font-black uppercase tracking-wider text-rose-900 mb-2">No workspace assigned</p>
          <p className="text-xs font-semibold text-rose-800 leading-relaxed">
            This account (<span className="font-mono">{currentUser.username}</span>) is not bound to an active client
            entity, so no other client&rsquo;s information can be shown. Contact the firm owner to restore the workspace
            assignment, or sign out.
          </p>
          <button onClick={onSignOut} className="mt-4 rounded-lg bg-[#b42318] px-4 py-2 text-xs font-bold text-white hover:bg-rose-800">
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="app-shell h-dvh overflow-hidden bg-[#f0f6fc] text-[#0a253e] flex flex-col font-sans">
      <a className="skip-link" href="#workspace-content">Skip to workspace</a>
      {/* Top Header */}
      <AccountingHeader
        key={currentClient.id}
        currentClient={currentClient}
        clients={clients}
        onSelectClient={(c) => setCurrentClientId(c.id)}
        currentUser={currentUser}
        onSignOut={onSignOut}
        isBalanced={isBalanced}
        totalLines={clientLines.length}
        totalDocs={uniqueDocs}
        activeSection={effectiveSection}
        pendingApprovalsCount={approvalsCount}
        onOpenApprovals={() => setIsApprovalsModalOpen(true)}
        syncStatus={syncStatus}
      />

      {/* Approvals Drawer / Modal */}
        {isApprovalsModalOpen && <ApprovalsModal
          isOpen={isApprovalsModalOpen}
          onClose={() => {
            setIsApprovalsModalOpen(false);
            refreshApprovalsCount();
          }}
          currentUser={currentUser}
          currentClient={currentClient}
          allowFirmWide={hasFirmWideScope(currentUser)}
          onApprovalResolved={refreshApprovalsCount}
          onApprovePost={handleApprovePost}
        />}

      {/* System notices: every failed server-side operation is surfaced here explicitly. */}
      {systemNotices.length > 0 && (
        <div role="alert" data-print-hide className="shrink-0 max-h-40 overflow-y-auto border-b border-rose-300 bg-rose-50 px-4 py-2.5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <span className="block text-[11px] font-black uppercase tracking-wider text-rose-800">
                System notices — nothing failed silently
              </span>
              <ul className="mt-1 space-y-0.5 text-[11.5px] font-semibold text-rose-900 list-disc pl-4">
                {systemNotices.map((n) => (
                  <li key={n}>{n}</li>
                ))}
              </ul>
            </div>
            <button
              onClick={() => setSystemNotices([])}
              className="shrink-0 rounded border border-rose-300 bg-white px-2.5 py-1 text-[11px] font-bold text-rose-800 hover:bg-rose-100"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Main Shell */}
      {/* Mobile bar: the menu is a drawer on phones/tablets so page content is never pushed below a 30-item list. */}
      <div className="md:hidden shrink-0 flex items-center gap-2 border-b border-sky-200 bg-white px-3 py-2">
        <button
          onClick={() => setMobileNavOpen(true)}
          aria-label="Open navigation menu"
          aria-expanded={mobileNavOpen}
          aria-controls="workspace-navigation"
          className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3 py-1.5 text-xs font-bold text-white"
        >
          <Menu className="h-4 w-4" /> Menu
        </button>
        <span className="truncate text-xs font-black uppercase tracking-wider text-[#082f4f]">{effectiveSection.replace(/_/g, ' ')}</span>
      </div>

      <div className="flex-1 flex min-h-0">
        {/* Sidebar */}
        <AccountingSidebar
          activeSection={effectiveSection}
          onSelectSection={setActiveSection}
          currentClient={currentClient}
          currentUser={currentUser}
          mobileOpen={mobileNavOpen}
          onCloseMobile={() => setMobileNavOpen(false)}
        />

        {/* Center Content Workspace — scrolls independently of the menu */}
        <main id="workspace-content" tabIndex={-1} ref={mainRef} className="flex-1 min-w-0 overflow-y-auto overflow-x-hidden p-3 sm:p-6 lg:p-7">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Sync state is shown in the header; a notice appears here ONLY when server sync is not live. */}
            {(syncStatus.state === 'offline' || syncStatus.state === 'paused' || syncStatus.state === 'rejected') && (
              <div role="status" data-print-hide className={`rounded-lg border px-3 py-2 text-xs font-bold ${syncStatus.state === 'rejected' ? 'border-rose-300 bg-rose-50 text-rose-900' : 'border-amber-400 bg-amber-50 text-amber-950'}`}>
                {syncStatus.state === 'offline' && 'Server sync is offline: your entries are saved in this browser and will sync automatically when the connection returns.'}
                {syncStatus.state === 'paused' && `Server sync is paused: ${syncStatus.detail || 'the server workspace could not be loaded.'}`}
                {syncStatus.state === 'rejected' && `The server did not accept the last sync: ${syncStatus.detail || 'see the system notice above.'}`}
              </div>
            )}
            {/* Every workspace prints as its own working paper, whatever the desk. */}
            <div data-print-hide className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-sky-200 bg-white px-3 py-2">
              <div className="min-w-0">
                <div className="text-[9px] font-bold uppercase tracking-[0.16em] text-[#855b00]">
                  {currentClient.code} · workspace
                </div>
                <div className="truncate text-[12px] font-bold capitalize text-[#082f4f]">
                  {effectiveSection.replace(/_/g, ' ')}{isLocalReview() ? ' · local review' : ''}
                </div>
              </div>
              <ModulePrintButton
                title={`${effectiveSection.replace(/_/g, ' ').replace(/\b\w/g, (m) => m.toUpperCase())} — ${currentClient.name}`}
                subtitle={`${currentClient.code} · working paper printed ${new Date().toISOString().slice(0, 10)}`}
              />
            </div>

            {/* A fault inside one desk must never blank the whole workspace. */}
            <ModuleErrorBoundary
              moduleKey={`${effectiveSection}:${currentClient.id}`}
              label={effectiveSection.replace(/_/g, ' ')}
              onBackToDashboard={() => setActiveSection('dashboard')}
            >
            {effectiveSection === 'dashboard' && (
              <AccountingDashboard
                key={currentClient.id}
                currentClient={currentClient}
                lines={lines}
                onNavigate={setActiveSection}
              />
            )}

            {effectiveSection === 'sector_workflow' && (
              <SectorWorkflowDesk
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                onNavigate={setActiveSection}
                onChangeSector={(sectorName) => {
                  // Re-classify the entity: the workspace re-arms to the new sector profile.
                  setClients((prev) => prev.map((c) => (c.id === currentClient.id ? { ...c, sector: sectorName } : c)));
                  pushNotice(`Workspace switched to sector profile: ${profileForClientSector(sectorName).manualRef}`);
                }}
              />
            )}

            {effectiveSection === 'procurement' && (
              <ProcurementSection
                key={currentClient.id}
                currentClient={currentClient}
                purchaseOrders={visibleOrders}
                partners={visiblePartners}
                accounts={visibleAccounts}
                stockItems={visibleStockItems}
                onAddPO={(po) => setPurchaseOrders(previous => [...previous, { ...po, clientId: currentClient.id }])}
                onPostPOToJournal={handlePostPOToJournal}
                onIssueDebitNote={handleIssueDebitNote}
                currentUser={currentUser}
                onServerMutation={pullServerState}
                onSessionLost={onSessionExpired}
                onNavigate={setActiveSection}
              />
            )}

            {effectiveSection === 'sales' && (
              <SalesSection
                key={currentClient.id}
                currentClient={currentClient}
                salesInvoices={visibleInvoices}
                partners={visiblePartners}
                accounts={visibleAccounts}
                stockItems={visibleStockItems}
                onAddInvoice={(inv) => setSalesInvoices(previous => [...previous, { ...inv, clientId: currentClient.id }])}
                onPostSalesToJournal={handlePostSalesToJournal}
                onIssueCreditNote={handleIssueCreditNote}
                currentUser={currentUser}
                onServerMutation={pullServerState}
                onSessionLost={onSessionExpired}
                onNavigate={setActiveSection}
              />
            )}

            {(effectiveSection === 'business_partners' || effectiveSection === 'business_partners_crm') && (
              <BusinessPartnersSection
                key={currentClient.id}
                currentClient={currentClient}
                partners={visiblePartners}
                salesInvoices={visibleInvoices}
                purchaseOrders={visibleOrders}
                onAddPartner={(newP) => {
                  // Server-authoritative registration: the master file is written
                  // by /api/partners, which validates the record and checks the
                  // entity's write permission, instead of being pushed into
                  // browser state and trusted on the next full-state sync.
                  const payload = { ...newP, clientId: currentClient.id };
                  void (async () => {
                    const { response, sessionLost } = await apiFetchVerified('/api/partners', {
                      method: 'POST',
                      body: JSON.stringify({ clientId: currentClient.id, partner: payload }),
                    });
                    if (sessionLost) { onSessionExpired(); return; }
                    const body = await response?.json().catch(() => null);
                    if (!response || !body?.ok) {
                      pushNotice(`The customer/vendor was not registered: ${body?.error || 'the server could not be reached — nothing was saved.'}`);
                      return;
                    }
                    const saved: BusinessPartner = { ...payload, ...(body.partner as BusinessPartner) };
                    setBusinessPartners((previous) =>
                      previous.some((p) => p.id === saved.id)
                        ? previous.map((p) => (p.id === saved.id ? saved : p))
                        : [...previous, saved]);
                    void pullServerState(currentClient.id);
                  })();
                }}
              />
            )}

            {effectiveSection === 'opening_balance' && (
              <OpeningBalanceSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                accounts={visibleAccounts}
                lines={lines}
                closedPeriods={closedPeriods}
                onAddJournalLines={handleAddJournalLines}
                postingNotice={lastPostingNotice}
                getPostingNotice={getPostingNotice}
              />
            )}

            {effectiveSection === 'payroll' && (
              <PayrollSection
                key={currentClient.id}
                currentClient={currentClient}
                employees={visibleEmployees}
                lines={lines}
                currentUser={currentUser}
                isPeriodClosed={isPeriodClosed}
                onAddEmployee={(emp) => setEmployees(previous => [...previous, { ...emp, clientId: currentClient.id }])}
                onPostMonthlyPayroll={handlePostMonthlyPayroll}
              />
            )}

            {effectiveSection === 'banking' && (
              <BankingSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                bankAccounts={visibleBanks}
                lines={lines}
                accounts={visibleAccounts}
                invoices={visibleInvoices}
                orders={visibleOrders}
                onAddBankAccount={(newAcc) => {
                  const gl = newAcc.glAccount || (newAcc.kind === 'cash' ? '102000' : '100000');
                  const clash = bankAccounts.find((b) => (b.clientId ?? INITIAL_CLIENTS[1].id) === currentClient.id
                    && (b.glAccount || (b.kind === 'cash' ? '102000' : '100000')) === gl && b.currency === newAcc.currency);
                  if (clash) {
                    pushNotice(`${clash.code} (${clash.name}) already owns GL ${gl} in ${newAcc.currency}. Each bank, float or wallet needs its own treasury GL so its balance can be derived from the ledger — add a 10xxxx sub-account in Chart of Accounts first.`);
                    return;
                  }
                  const opening = Math.round((Number(newAcc.balance) || 0) * 100) / 100;
                  if (Math.abs(opening) >= 0.01) {
                    const date = postDate();
                    const docNo = uniqueDocNo(`OB-BANK-${newAcc.code}`, currentClient.id);
                    const openingCurrency = currentClient.currency;
                    const openingRate = newAcc.currency !== openingCurrency ? Number(newAcc.fxRate || 0) : 1;
                    if (newAcc.currency !== openingCurrency && (!Number.isFinite(openingRate) || openingRate <= 0)) {
                      pushNotice(`Choose a valid ${currentClient.currency}-per-1-${newAcc.currency} exchange rate before opening ${newAcc.code}. An untranslated ${newAcc.currency} opening balance would leave the single-currency ledger.`);
                      return;
                    }
                    const base = { docNo, period: periodFrom(date), date, module: 'FI' as const, docType: 'JE' as const, costCenter: 'CC-ADM', currency: newAcc.currency, createdBy: currentUser.username, clientId: currentClient.id };
                    const translatedOpening = translateToFunctional([
                      { ...base, id: `${uniqueId('JL-OB')}-1`, accountNo: gl, accountName: newAcc.name, debit: opening > 0 ? opening : 0, credit: opening < 0 ? -opening : 0, description: `Opening balance — ${newAcc.name} (${newAcc.bankName} ${newAcc.accountNo})` },
                      { ...base, id: `${uniqueId('JL-OB')}-2`, accountNo: '309000', accountName: 'Opening Balance Equity (take-on clearing)', debit: opening < 0 ? -opening : 0, credit: opening > 0 ? opening : 0, description: `Take-on of ${newAcc.code} opening balance` },
                    ], openingCurrency, newAcc.currency, newAcc.currency === openingCurrency ? 1 : openingRate);
                    if (translatedOpening.error) { pushNotice(translatedOpening.error); return; }
                    const ok = handleAddJournalLines(translatedOpening.lines);
                    if (!ok) { pushNotice(`${newAcc.code} was not created: its opening-balance journal was refused (closed period, authority, maker limit or chart).`); return; }
                  }
                  setBankAccounts(previous => [...previous, { ...newAcc, clientId: currentClient.id }]);
                }}
                onAddJournalLines={handleAddJournalLines}
              />
            )}

            {effectiveSection === 'company_profile' && (
              <CompanyProfileSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                isOwner={isOwner}
                clients={clients}
                resetPreview={resetPreview}
                onUpdateClientName={(newName) => {
                  setClients(clients.map((c) => (c.id === currentClient.id ? { ...c, name: newName } : c)));
                }}
                onRefreshAllData={handleRefreshAllData}
                onResetAccounts={handleResetAccounts}
              />
            )}

            {effectiveSection === 'payment_desk' && (
              <PaymentDeskSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                purchaseOrders={visibleOrders}
                salesInvoices={visibleInvoices}
                bankAccounts={visibleBanks}
                partners={visiblePartners}
                employees={visibleEmployees}
                lines={lines}
                isPeriodClosed={isPeriodClosed}
                onSettleSupplierInvoice={handleSettleSupplierInvoice}
                onReceiveCustomerPayment={handleReceiveCustomerPayment}
                onDisburseSalaries={handleDisburseSalaries}
                onSettleExpenseBill={handleSettleExpenseBill}
                onRemitStatutory={handleRemitStatutory}
                onApprovalSubmitted={refreshApprovalsCount}
                onNavigate={setActiveSection}
                onServerMutation={pullServerState}
                onSessionLost={onSessionExpired}
              />
            )}

             {effectiveSection === 'expenses' && (
               <ExpensesSection
                 key={currentClient.id}
                 currentClient={currentClient}
                 currentUser={currentUser}
                 isPeriodClosed={isPeriodClosed}
                 lines={lines}
                 accounts={visibleAccounts}
                 onAddJournalLines={handleAddJournalLines}
                 onNavigate={setActiveSection}
                 onApprovalSubmitted={refreshApprovalsCount}
               />
             )}

             {(effectiveSection === 'inventory' || effectiveSection === 'inventory_ledger') && (
               <InventoryWorkspace
                 key={`${currentClient.id}:${effectiveSection}`}
                 currentClient={currentClient}
                 currentUser={currentUser}
                 isPeriodClosed={isPeriodClosed}
                 lines={lines}
                 items={visibleStockItems}
                 movements={visibleStockMovements}
                 partners={visiblePartners}
                 orders={visibleOrders}
                 invoices={visibleInvoices}
                 onAddJournalLines={handleAddJournalLines}
                 initialTab={effectiveSection === 'inventory_ledger' ? 'ledger' : 'operations'}
                 onAddItem={(item) => setStockItems((prev) => [...prev, { ...item, clientId: currentClient.id }])}
                 onApplyStock={(item, movement) => {
                   setStockItems((prev) => prev.map((i) => (i.id === item.id ? item : i)));
                   setStockMovements((prev) => [...prev, movement]);
                 }}
                 onNavigate={setActiveSection}
               />
             )}

             {effectiveSection === 'boms' && (
               <BomDesk key={currentClient.id} currentClient={currentClient} currentUser={currentUser}
                 stockItems={visibleStockItems} onNavigate={setActiveSection} />
             )}
             {effectiveSection === 'production_desk' && (
               <ProductionDesk key={currentClient.id} currentClient={currentClient} currentUser={currentUser}
                 accounts={visibleAccounts} stockItems={visibleStockItems} onNavigate={setActiveSection}
                 onServerMutation={pullServerState} />
             )}

             {effectiveSection === 'prepayments' && (
               <PrepaymentsSection
                 key={currentClient.id}
                 currentClient={currentClient}
                 currentUser={currentUser}
                 isPeriodClosed={isPeriodClosed}
                 lines={lines}
                 accounts={visibleAccounts}
                 bankAccounts={visibleBanks}
                 partners={visiblePartners}
                 onAddJournalLines={handleAddJournalLines}
                 onBankBalanceChange={(bankId, delta) => setBankAccounts(previous => previous.map(b => b.id === bankId ? { ...b, balance: Math.round((b.balance + delta) * 100) / 100 } : b))}
               />
             )}

             {effectiveSection === 'assets' && (
               <FixedAssetsSection
                 key={currentClient.id}
                 currentClient={currentClient}
                 currentUser={currentUser}
                 isPeriodClosed={isPeriodClosed}
                 lines={lines}
                 assets={visibleAssets}
                 bankAccounts={visibleBanks}
                 onAddJournalLines={handleAddJournalLines}
                 onSaveAssets={(next) => setFixedAssets((prev) => [
                   ...prev.filter((a) => (a.clientId ?? INITIAL_CLIENTS[1].id) !== currentClient.id),
                   ...next.map((a) => ({ ...a, clientId: currentClient.id })),
                 ])}
                 onBankBalanceChange={(bankId, delta) => setBankAccounts(previous => previous.map(b => b.id === bankId ? { ...b, balance: Math.round((b.balance + delta) * 100) / 100 } : b))}
               />
             )}

            {effectiveSection === 'coa_master' && (
              <ChartOfAccountsSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                accounts={visibleAccounts}
                lines={lines}
                profile={currentProfile}
                onAddAccount={(newAcc) => {
                  if (!mayEditChartOfAccounts(currentUser)) return;
                  setChartOfAccounts([...chartOfAccounts, { ...newAcc, clientId: currentClient.id }]);
                  logControlEvent('COA_ADDED', newAcc.accountNo, `${currentClient.code} · ${newAcc.name} · ${newAcc.type}`, currentClient.id);
                }}
                onUpdateAccount={handleUpdateAccount}
                onDeleteAccount={handleDeleteAccount}
              />
            )}

            {effectiveSection === 'general_ledger' && (
              <GeneralLedgerSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                accounts={visibleAccounts}
                closedPeriods={closedPeriods}
                profile={currentProfile}
                onAddJournalLines={handleAddJournalLines}
                onEditDocument={handleEditDocument}
                onDeleteDocument={handleDeleteDocument}
                onReverseDocument={handleReverseDocument}
              />
            )}


            {effectiveSection === 'universal_journal' && (
              <ManualJournalSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                accounts={visibleAccounts}
                onAddJournalLines={handleAddJournalLines}
                onReverseDocument={handleReverseDocument}
                isPeriodClosed={isPeriodClosed}
                onApprovalSubmitted={refreshApprovalsCount}
                postingNotice={lastPostingNotice}
                getPostingNotice={getPostingNotice}
              />
            )}

            {effectiveSection === 'manual_journal' && (
              <ManualJournalSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                accounts={visibleAccounts}
                onAddJournalLines={handleAddJournalLines}
                onReverseDocument={handleReverseDocument}
                isPeriodClosed={isPeriodClosed}
                onApprovalSubmitted={refreshApprovalsCount}
                postingNotice={lastPostingNotice}
                getPostingNotice={getPostingNotice}
              />
            )}

            {(effectiveSection === 'ifrs_desk' || effectiveSection === 'standards_desk' || effectiveSection === 'ifrs_schedules') && (
              <IfrsDesk
                key={`${currentClient.id}:${effectiveSection}`}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                accounts={visibleAccounts}
                assets={visibleAssets}
                stockItems={visibleStockItems}
                stockMovements={visibleStockMovements}
                invoices={visibleInvoices}
                orders={visibleOrders}
                payroll={persistentStorage.getPayrollRecords().filter((r) => (r.clientId ?? INITIAL_CLIENTS[1].id) === currentClient.id)}
                fiscalYearStart={currentProfile?.fiscalYearStart}
                onAddJournalLines={(newLines) => handleAddJournalLines(newLines)}
                onNavigate={setActiveSection}
              />
            )}

            {effectiveSection in hrTabs && (
              <HrManagementDesk
                key={`${currentClient.id}:${effectiveSection}`}
                currentClient={currentClient}
                currentUser={currentUser}
                employees={visibleEmployees}
                initialTab={hrTabs[effectiveSection]}
                onAddEmployee={(emp) => setEmployees((previous) => [...previous, { ...emp, clientId: currentClient.id }])}
                onNavigate={setActiveSection}
              />
            )}

            {effectiveSection === 'crm_desk' && (
              <CrmDesk
                key={`${currentClient.id}:${effectiveSection}`}
                currentClient={currentClient}
                currentUser={currentUser}
                partners={visiblePartners}
                invoices={visibleInvoices}
                orders={visibleOrders}
                accounts={visibleAccounts}
                onNavigate={setActiveSection}
              />
            )}

            {effectiveSection === 'ageing' && (
              <AgeingAnalysisDesk
                key={`${currentClient.id}:ageing`}
                currentClient={currentClient}
                invoices={visibleInvoices}
                orders={visibleOrders}
                lines={lines}
                onNavigate={setActiveSection}
              />
            )}

            {effectiveSection === 'control_accounts' && (
              <ControlAccountsDesk
                key={`${currentClient.id}:cco`}
                currentClient={currentClient}
                lines={lines}
                invoices={visibleInvoices}
                orders={visibleOrders}
                stockItems={visibleStockItems}
                bankAccounts={visibleBanks}
                assets={visibleAssets}
                onNavigate={setActiveSection}
              />
            )}

            {(effectiveSection === 'reports' || effectiveSection in reportTabs) && (
              <ReportsHub
                key={`${currentClient.id}:${effectiveSection}`}
                currentClient={currentClient}
                invoices={visibleInvoices}
                orders={visibleOrders}
                partners={visiblePartners}
                stockItems={visibleStockItems}
                stockMovements={visibleStockMovements}
                employees={visibleEmployees}
                lines={clientLines}
                accounts={visibleAccounts}
                initialTab={reportTabs[effectiveSection] ?? 'sales'}
                onNavigate={setActiveSection}
              />
            )}

            {effectiveSection === 'performance' && (
              <PerformanceManagementDesk
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                accounts={visibleAccounts}
                invoices={visibleInvoices}
                employees={visibleEmployees}
                fiscalYearStart={currentProfile?.fiscalYearStart}
              />
            )}

            {effectiveSection === 'analytics' && (
              <DataAnalyticsDesk
                key={currentClient.id}
                currentClient={currentClient}
                lines={lines}
                accounts={visibleAccounts}
                invoices={visibleInvoices}
                orders={visibleOrders}
              />
            )}

            {effectiveSection === 'my_security' && (
              <MySecurityDesk currentUser={currentUser} />
            )}

            {effectiveSection === 'regulated_industries' && (
              <RegulatedIndustriesDesk
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                stockItems={visibleStockItems}
                isPeriodClosed={isPeriodClosed}
                onAddJournalLines={handleAddJournalLines}
              />
            )}

            {effectiveSection === 'loans_desk' && (
              <LoansAmortisationDesk
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                bankAccounts={visibleBanks}
                accounts={visibleAccounts}
                isPeriodClosed={isPeriodClosed}
                onPostDebtService={handlePostDebtService}
                onPostDrawdown={(facility, bankId) => {
                  const bank = bankAccounts.find((b) => b.id === bankId && (b.clientId ?? INITIAL_CLIENTS[1].id) === currentClient.id);
                  if (!bank || bank.currency !== currentClient.currency) { pushNotice(`Choose a ${currentClient.currency} treasury record to receive the ${facility.code} drawdown.`); return false; }
                  const date = postDate();
                  const gl = paymentAccountFor('bank_transfer', bank);
                  const docNo = uniqueDocNo(`LOAN-DRAW-${facility.code}`, currentClient.id);
                  const base = { docNo, period: periodFrom(date), date, module: 'FI' as const, docType: 'JE' as const, costCenter: 'CC-ADM', currency: currentClient.currency, createdBy: currentUser.username, clientId: currentClient.id, reference: facility.code };
                  return handleAddJournalLines([
                    { ...base, id: `${uniqueId('JL-DRAW')}-1`, accountNo: gl.no, accountName: gl.name, debit: facility.principal, credit: 0, description: `Loan proceeds received — ${facility.facilityName} (${facility.lender})` },
                    { ...base, id: `${uniqueId('JL-DRAW')}-2`, accountNo: '250000', accountName: 'Commercial Borrowings (Ecobank / Stanbic)', debit: 0, credit: facility.principal, description: `Borrowing recognised at drawdown — ${facility.code} ${facility.annualRatePct}% p.a. ${facility.termMonths} months` },
                  ]);
                }}
                onNavigate={setActiveSection}
              />
            )}

            {(effectiveSection === 'financial_reports' || effectiveSection === 'ifrs_statements' || effectiveSection in statementTabs) && (
              <FinancialStatementsSection
                key={`${currentClient.id}:${effectiveSection}`}
                currentClient={currentClient}
                clients={hasFirmWideScope(currentUser) ? clients : clients.filter((c) => c.id === currentClient.id)}
                currentUser={currentUser}
                onSelectClient={(c) => setCurrentClientId(c.id)}
                lines={lines}
                accounts={visibleAccounts}
                onOpenNotesToAccounts={() => setActiveSection('disclosures')}
                onNavigate={setActiveSection}
                defaultView={(effectiveSection === 'ifrs_statements' || effectiveSection in statementTabs) ? 'statutory' : 'working'}
                defaultStatutoryTab={statementTabs[effectiveSection]}
              />
            )}

            {effectiveSection === 'compliance_review' && (
              <ComplianceReviewDesk
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                accounts={visibleAccounts}
                onNavigate={setActiveSection}
              />
            )}

            {(effectiveSection === 'tax_schedule' || effectiveSection === 'tax_schedules') && (
              <TaxDesk
                key={`${currentClient.id}:${effectiveSection}`}
                initialTab={effectiveSection === 'tax_schedules' ? 'schedules' : 'returns'}
                schedules={<TaxSchedulesSection currentClient={currentClient} currentUser={currentUser} lines={lines}
                  salesInvoices={visibleInvoices} purchaseOrders={visibleOrders} partners={visiblePartners}
                  entries={taxScheduleEntries} profile={currentProfile} onSaveEntry={handleSaveTaxEntry} onDeleteEntry={handleDeleteTaxEntry} />}
                returns={(openSchedules) => <TaxFilingScheduleSection currentClient={currentClient} currentUser={currentUser} lines={lines}
                  accounts={visibleAccounts} onAddJournalLines={handleAddJournalLines} isPeriodClosed={isPeriodClosed} onOpenSchedules={openSchedules} />}
              />
            )}

            {effectiveSection === 'disclosures' && (
              <DisclosureNotesDesk
                currentWorkspace={currentClient as any}
                notes={notes as any}
                onUpdateNote={handleUpdateNote as any}
                onNavigate={setActiveSection}
              />
            )}

            {effectiveSection === 'adjustments' && (
              <AdjustmentsDesk
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                accounts={visibleAccounts}
                lines={lines}
                closedPeriods={closedPeriods}
                isPeriodClosed={isPeriodClosed}
                onAddJournalLines={handleAddJournalLines}
                onReverseDocument={handleReverseDocument}
              />
            )}

             {effectiveSection === 'project_costing' && (
               <ProjectCostingDesk
                 key={currentClient.id}
                 currentClient={currentClient}
                 currentUser={currentUser}
                 lines={lines}
                 invoices={visibleInvoices}
                 accounts={visibleAccounts}
                 isPeriodClosed={isPeriodClosed}
                 onAddJournalLines={handleAddJournalLines}
                 onNavigate={setActiveSection}
               />
             )}

             {effectiveSection === 'month_end' && (
               <MonthEndSection
                 key={currentClient.id}
                 currentClient={currentClient}
                 currentUser={currentUser}
                 lines={lines}
                 accounts={visibleAccounts}
                 onPostYearEndClose={handlePostYearEndClose}
                 closedPeriods={closedPeriods}
                 controlExceptions={controlRecoExceptions}
                onTogglePeriodClose={(period) => setClosedPeriodsMap((prev) => {
                   const list = prev[currentClient.id] || [];
                   const next = list.includes(period) ? list.filter((p) => p !== period) : [...list, period];
                   return { ...prev, [currentClient.id]: next };
                 })}
               />
             )}

            {/* Owner/Firm Practice & Enterprise Administration (Strictly Private to Owner) */}
            {isOwner && effectiveSection === 'clients_management' && (
              <ClientsManagementSection
                key={currentClient.id}
                currentClient={currentClient}
                clients={clients}
                onAddClient={(newC) => {
                  // Do not switch entity until the owner closes the one-time
                  // credential receipt. Changing the key here unmounted it.
                  setClients((previous) => [...previous, newC]);
                }}
                onSwitchClient={(c) => setCurrentClientId(c.id)}
              />
            )}

             {isOwner && effectiveSection === 'advisory' && (
               <AdvisorySection currentClient={currentClient} currentUser={currentUser} />
             )}

            {isOwner && effectiveSection === 'user_permissions' && (
              <UserPermissionsDesk onRefreshUsers={handleRefreshAllData} />
            )}

            {isOwner && effectiveSection === 'group_consolidation' && (
              <ConsolidationDesk
                clients={clients}
                lines={lines}
                accounts={visibleAccounts}
              />
            )}

            {isOwner && effectiveSection === 'enterprise_sso' && (
              <SsoDesk />
            )}

            {isOwner && effectiveSection === 'tax_settings' && (
              <TaxSettingsDesk />
            )}

            {isOwner && effectiveSection === 'global_tax' && (
              <GlobalTaxDesk />
            )}

            {isOwner && effectiveSection === 'soc_dr' && (
              <SocBackupDesk />
            )}
            {isOwner && effectiveSection === 'operations' && (
              <OperationsDesk />
            )}

            {isOwner && effectiveSection === 'realtime_integrations' && (
              <IntegrationsDesk />
            )}
            </ModuleErrorBoundary>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;
