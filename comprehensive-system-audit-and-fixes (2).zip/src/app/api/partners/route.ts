import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { auditLog, businessPartners, clients } from "@/db/schema";
import { authJson, getSessionUser } from "@/lib/auth";
import { canAccessFamily } from "@/lib/workspaceScope";
import {
  businessPartnerStorageId,
  prepareBusinessPartnersForStorage,
  type BusinessPartnerStorageRow,
} from "@/lib/businessPartnerSync";
import type { BusinessPartner } from "@/types/accounting";

export const dynamic = "force-dynamic";

/**
 * Server-authoritative customer / vendor master file.
 *
 * The legacy desks register a partner by pushing it into browser state and
 * letting the debounced full-state sync write it back. That works, but it makes
 * the browser the author of a master record: credit limits, credit standing and
 * tax attributes arrive as an untrusted array inside a large payload whose other
 * tables were validated separately.
 *
 * This endpoint is the trade-module pattern applied to the master file instead:
 * one authenticated, permission-checked, validated write that the server
 * performs and then reports back. The desk calls it, the workspace re-pulls, and
 * the sync payload that follows already agrees with what was stored — so this
 * route and the sync can never disagree about a partner.
 *
 * Controls:
 *  • authenticated session required (401, never a silent no-op);
 *  • `businessPartners` write permission for that exact entity (403), auditors
 *    and users scoped to another entity refused;
 *  • the same server-side validation the sync uses (`prepareBusinessPartnersForStorage`),
 *    so credit limits, terms and standing are checked here too — not trusted;
 *  • partner codes are unique per entity (409 on collision);
 *  • the write is recorded in the immutable audit log, field names only.
 */
const MAX_PAYLOAD_BYTES = 64 * 1024;

interface PartnerBody {
  clientId?: unknown;
  partner?: unknown;
}

/** Maps a stored row back to the browser shape (browser id = sourceId). */
function toBrowserPartner(row: BusinessPartnerStorageRow): BusinessPartner {
  const { sourceId, id: _storageId, ...rest } = row;
  return { ...rest, id: sourceId ?? _storageId } as BusinessPartner;
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (error) {
    console.error("partners POST: database unavailable", error);
    return authJson(req, { ok: false, error: "database-unavailable" }, { status: 503 });
  }

  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "A signed-in session is required." }, { status: 401 });

  let body: PartnerBody;
  try {
    const raw = await req.text();
    if (raw.length > MAX_PAYLOAD_BYTES) return authJson(req, { ok: false, error: "The partner record is too large." }, { status: 413 });
    body = JSON.parse(raw) as PartnerBody;
  } catch {
    return authJson(req, { ok: false, error: "Invalid request body." }, { status: 400 });
  }

  const clientId = Number(body.clientId ?? user.clientId ?? 0);
  if (!Number.isSafeInteger(clientId) || clientId <= 0) {
    return authJson(req, { ok: false, error: "An entity must be selected before registering a customer or vendor." }, { status: 400 });
  }
  if (user.clientId != null && user.clientId !== clientId && user.role !== "owner") {
    return authJson(req, { ok: false, error: "You may only register partners in your own entity." }, { status: 403 });
  }

  const entity = (await db.select().from(clients).where(eq(clients.id, clientId)).limit(1))[0];
  if (!entity) return authJson(req, { ok: false, error: "That entity does not exist." }, { status: 404 });

  if (!canAccessFamily(user, entity as never, "businessPartners", "write")) {
    return authJson(req, { ok: false, error: "You do not have permission to register customers or vendors." }, { status: 403 });
  }

  if (!body.partner || typeof body.partner !== "object" || Array.isArray(body.partner)) {
    return authJson(req, { ok: false, error: "A partner object is required." }, { status: 400 });
  }

  // The browser never supplies the tenant: legacy rows that omitted it inherit
  // the authenticated entity, exactly as the sync does.
  const prepared = prepareBusinessPartnersForStorage([body.partner], clientId);
  if (!prepared.ok) {
    return authJson(req, { ok: false, error: prepared.error }, { status: prepared.status });
  }

  const stored = prepared.rows[0];
  const storageId = businessPartnerStorageId(clientId, stored.sourceId);

  try {
    const existing = await db
      .select({ id: businessPartners.id, sourceId: businessPartners.sourceId })
      .from(businessPartners)
      .where(eq(businessPartners.id, storageId))
      .limit(1);
    const isUpdate = existing.length > 0;

    const values = { ...stored, id: storageId };
    if (isUpdate) {
      await db.update(businessPartners).set(values).where(eq(businessPartners.id, storageId));
    } else {
      await db.insert(businessPartners).values(values);
    }

    await db.insert(auditLog).values({
      id: randomUUID(),
      timestamp: new Date().toISOString(),
      userId: user.username,
      username: user.username,
      action: isUpdate ? "PARTNER_UPDATED" : "PARTNER_REGISTERED",
      target: `${stored.type}:${stored.code}`,
      // Field names only: a partner's TIN, address and contact details are
      // business data, not audit-trail material.
      details: `fields: ${Object.keys(stored).sort().join(", ").slice(0, 300)}`,
      clientId,
    });

    const saved = (await db.select().from(businessPartners).where(eq(businessPartners.id, storageId)).limit(1))[0];
    // The row was validated and shaped by prepareBusinessPartnersForStorage on
    // the way in; PostgreSQL returns the columns as plain strings/numbers, so
    // re-attach the literal union types on the way out.
    return authJson(req, { ok: true, updated: isUpdate, partner: toBrowserPartner(saved as unknown as BusinessPartnerStorageRow) });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (/business_partners_.*(scope|code)|duplicate key/i.test(message)) {
      return authJson(req, { ok: false, error: `Partner code ${stored.code} is already used in this entity.` }, { status: 409 });
    }
    console.error("partners POST failed", error);
    return authJson(req, { ok: false, error: "The partner could not be saved." }, { status: 503 });
  }
}
