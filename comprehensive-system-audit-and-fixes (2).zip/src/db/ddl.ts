/**
 * Idempotent DDL generated from `src/db/schema.ts` with `drizzle-kit export`.
 *
 * Regenerate after schema changes:
 *   npx drizzle-kit export --sql > /tmp/ddl.sql   (then convert to IF NOT EXISTS)
 *
 * Applied automatically by `ensureDatabaseReady()` so a fresh database never
 * produces `relation "users" does not exist` (the original "Login failed." bug).
 */
export const SCHEMA_DDL: string[] = [
  "CREATE TABLE IF NOT EXISTS \"approval_requests\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"client_code\" text NOT NULL,\n\t\"client_name\" text NOT NULL,\n\t\"doc_no\" text NOT NULL,\n\t\"doc_type\" text NOT NULL,\n\t\"amount\" double precision NOT NULL,\n\t\"requested_by\" text NOT NULL,\n\t\"requested_at\" text NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"reason_for_approval\" text NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"reviewed_by\" text,\n\t\"reviewed_at\" text,\n\t\"rejection_reason\" text,\n\t\"payload\" jsonb\n)",
  "CREATE TABLE IF NOT EXISTS \"audit_log\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"timestamp\" text NOT NULL,\n\t\"user_id\" text NOT NULL,\n\t\"username\" text NOT NULL,\n\t\"action\" text NOT NULL,\n\t\"target\" text NOT NULL,\n\t\"details\" text NOT NULL,\n\t\"client_id\" integer\n)",
  "CREATE TABLE IF NOT EXISTS \"bank_accounts\" (\n\t\"id\" integer PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"code\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"bank_name\" text NOT NULL,\n\t\"account_no\" text NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"balance\" double precision DEFAULT 0 NOT NULL,\n\t\"kind\" text,\n\t\"gl_account\" text\n)",
  "CREATE TABLE IF NOT EXISTS \"business_partners\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer,\n\t\"code\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"type\" text NOT NULL,\n\t\"tin\" text NOT NULL,\n\t\"email\" text NOT NULL,\n\t\"phone\" text NOT NULL,\n\t\"address\" text NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"is_vat_withholding_agent\" boolean DEFAULT false NOT NULL,\n\t\"vat_withholding_rate\" double precision,\n\t\"is_cst_applicable\" boolean DEFAULT false NOT NULL,\n\t\"is_tourism_levy_applicable\" boolean DEFAULT false NOT NULL,\n\t\"is_vat_registered\" boolean\n)",
  "CREATE TABLE IF NOT EXISTS \"chart_accounts\" (\n\t\"id\" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name \"chart_accounts_id_seq\" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),\n\t\"account_no\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"type\" text NOT NULL,\n\t\"category\" text NOT NULL,\n\t\"active\" boolean DEFAULT true NOT NULL,\n\t\"is_custom\" boolean DEFAULT false NOT NULL,\n\t\"client_id\" integer\n)",
  "CREATE TABLE IF NOT EXISTS \"clients\" (\n\t\"id\" integer PRIMARY KEY NOT NULL,\n\t\"code\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"sector\" text NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"jurisdiction\" text NOT NULL,\n\t\"reg_number\" text NOT NULL,\n\t\"is_parent\" boolean DEFAULT false NOT NULL,\n\t\"assigned_services\" jsonb,\n\t\"admin_username\" text,\n\t\"admin_email\" text,\n\t\"login_url\" text\n)",
  "CREATE TABLE IF NOT EXISTS \"closed_periods\" (\n\t\"id\" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name \"closed_periods_id_seq\" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),\n\t\"client_id\" integer NOT NULL,\n\t\"period\" text NOT NULL,\n\t\"closed_at\" text NOT NULL,\n\t\"closed_by\" text NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"company_profiles\" (\n\t\"client_id\" integer PRIMARY KEY NOT NULL,\n\t\"legal_name\" text NOT NULL,\n\t\"trading_name\" text NOT NULL,\n\t\"tin\" text NOT NULL,\n\t\"vat_reg_no\" text NOT NULL,\n\t\"address\" text NOT NULL,\n\t\"phone\" text NOT NULL,\n\t\"email\" text NOT NULL,\n\t\"website\" text NOT NULL,\n\t\"fiscal_year_start\" text NOT NULL,\n\t\"bank_payment_details\" text NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"disclosure_notes\" (\n\t\"id\" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name \"disclosure_notes_id_seq\" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),\n\t\"key\" text NOT NULL,\n\t\"note_number\" integer NOT NULL,\n\t\"title\" text NOT NULL,\n\t\"standard_ref\" text NOT NULL,\n\t\"applicable\" boolean NOT NULL,\n\t\"not_applicable_reason\" text,\n\t\"body\" text NOT NULL,\n\t\"tables\" jsonb,\n\t\"editable_override\" boolean\n)",
  "CREATE TABLE IF NOT EXISTS \"employees\" (\n\t\"id\" integer PRIMARY KEY NOT NULL,\n\t\"client_id\" integer,\n\t\"bp_no\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"role\" text NOT NULL,\n\t\"department\" text NOT NULL,\n\t\"cost_center\" text,\n\t\"jurisdiction\" text NOT NULL,\n\t\"basic_salary\" double precision NOT NULL,\n\t\"allowances\" double precision DEFAULT 0 NOT NULL,\n\t\"ssnit_number\" text NOT NULL,\n\t\"tin\" text NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"is_resident\" boolean DEFAULT true NOT NULL,\n\t\"exempt_tier1\" boolean DEFAULT false NOT NULL,\n\t\"exempt_tier2\" boolean DEFAULT false NOT NULL,\n\t\"ssnit_exempt\" boolean DEFAULT false NOT NULL,\n\t\"ssnit_exemption_reason\" text,\n\t\"tax_relief\" double precision DEFAULT 0 NOT NULL,\n\t\"relief_type\" text,\n\t\"deductions\" jsonb\n)",
  "CREATE TABLE IF NOT EXISTS \"journal_lines\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"doc_no\" text NOT NULL,\n\t\"period\" text NOT NULL,\n\t\"date\" text NOT NULL,\n\t\"module\" text NOT NULL,\n\t\"doc_type\" text NOT NULL,\n\t\"account_no\" text NOT NULL,\n\t\"account_name\" text NOT NULL,\n\t\"cost_center\" text,\n\t\"debit\" double precision DEFAULT 0 NOT NULL,\n\t\"credit\" double precision DEFAULT 0 NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"created_by\" text NOT NULL,\n\t\"checked_by\" text,\n\t\"is_reversed\" boolean DEFAULT false NOT NULL,\n\t\"reference\" text,\n\t\"client_id\" integer NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"payroll_records\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"record\" jsonb NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"prepayment_records\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"record\" jsonb NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"prepayment_schedules\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"prepayment_id\" text NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"line\" jsonb NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"purchase_orders\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"po_no\" text NOT NULL,\n\t\"vendor_name\" text NOT NULL,\n\t\"item_type\" text NOT NULL,\n\t\"item_description\" text NOT NULL,\n\t\"qty\" double precision NOT NULL,\n\t\"unit_price\" double precision NOT NULL,\n\t\"vat_recoverable\" double precision DEFAULT 0 NOT NULL,\n\t\"total_amount\" double precision NOT NULL,\n\t\"paid_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"date\" text NOT NULL,\n\t\"currency\" text,\n\t\"vat_treatment\" text,\n\t\"net_amount\" double precision,\n\t\"quotation_ref\" text,\n\t\"gl_account\" text NOT NULL,\n\t\"gl_account_name\" text NOT NULL,\n\t\"cost_center\" text NOT NULL,\n\t\"cost_center_name\" text NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"sales_invoices\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"inv_no\" text NOT NULL,\n\t\"customer_name\" text NOT NULL,\n\t\"revenue_stream\" text NOT NULL,\n\t\"net_revenue\" double precision NOT NULL,\n\t\"vat_output\" double precision DEFAULT 0 NOT NULL,\n\t\"cst_amount\" double precision,\n\t\"tourism_levy_amount\" double precision,\n\t\"vat_withheld_by_customer\" double precision,\n\t\"total_receivable\" double precision NOT NULL,\n\t\"paid_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"date\" text NOT NULL\n)",
  // Sessions live in a dedicated table: a `sessions` table left behind by an
  // earlier build (or another app on the same database) has an incompatible
  // shape, and `CREATE TABLE IF NOT EXISTS` would keep it — which broke session
  // lookups and bounced signed-in users back to the login screen.
  "CREATE TABLE IF NOT EXISTS \"bpz_sessions\" (\n\t\"token\" text PRIMARY KEY NOT NULL,\n\t\"user_id\" text NOT NULL,\n\t\"expires_at\" bigint NOT NULL,\n\t\"last_seen_at\" bigint,\n\t\"created_at\" timestamp with time zone DEFAULT now() NOT NULL\n)",
  // Drop then recreate so a database provisioned with the old UNIQUE index is
  // repaired: multi-device sign-in must never fail on a duplicate user_id.
  "DROP INDEX IF EXISTS \"bpz_sessions_user_idx\"",
  "CREATE INDEX IF NOT EXISTS \"bpz_sessions_user_idx\" ON \"bpz_sessions\" USING btree (\"user_id\")",
  "CREATE INDEX IF NOT EXISTS \"bpz_sessions_expiry_idx\" ON \"bpz_sessions\" USING btree (\"expires_at\")",
  "CREATE TABLE IF NOT EXISTS \"users\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"username\" text NOT NULL,\n\t\"email\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"role\" text NOT NULL,\n\t\"maker_limit\" double precision DEFAULT 0 NOT NULL,\n\t\"can_check\" boolean DEFAULT false NOT NULL,\n\t\"client_id\" integer,\n\t\"password_hash\" text,\n\t\"password_salt\" text,\n\t\"status\" text DEFAULT 'active' NOT NULL,\n\t\"restriction_reason\" text,\n\t\"permissions\" jsonb,\n\t\"created_at\" timestamp with time zone DEFAULT now() NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"tax_schedule_entries\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"kind\" text NOT NULL,\n\t\"source\" text NOT NULL,\n\t\"source_key\" text,\n\t\"period\" text NOT NULL,\n\t\"date\" text NOT NULL,\n\t\"doc_no\" text NOT NULL,\n\t\"party_name\" text NOT NULL,\n\t\"party_tin\" text DEFAULT '' NOT NULL,\n\t\"nature\" text DEFAULT '' NOT NULL,\n\t\"gross_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"rate\" double precision DEFAULT 0 NOT NULL,\n\t\"tax_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"levy_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"reference\" text DEFAULT '' NOT NULL,\n\t\"status\" text DEFAULT '' NOT NULL,\n\t\"note\" text,\n\t\"created_by\" text NOT NULL,\n\t\"updated_at\" text NOT NULL\n)",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"chart_accounts_no_idx\" ON \"chart_accounts\" USING btree (\"account_no\")",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"closed_periods_client_period_idx\" ON \"closed_periods\" USING btree (\"client_id\",\"period\")",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"users_username_idx\" ON \"users\" USING btree (\"username\")",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"users_email_idx\" ON \"users\" USING btree (\"email\")",
  // --- Idempotent in-place migrations for databases created by earlier builds ---
  // Employee cost centre (payroll cost allocation by responsibility centre).
  "ALTER TABLE \"employees\" ADD COLUMN IF NOT EXISTS \"cost_center\" text",
  // The chart of accounts is scoped per entity: the same account number may
  // exist as a firm-master account AND as a client's own custom account, so the
  // uniqueness constraint must include the owning entity (0 = firm master).
  "DROP INDEX IF EXISTS \"chart_accounts_no_idx\"",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"chart_accounts_scope_idx\" ON \"chart_accounts\" (\"account_no\", COALESCE(\"client_id\", 0))",
  // Tenant column repairs. Databases created before multi-entity isolation had
  // no `client_id` on the operational tables; a `select` of that column then
  // failed with HTTP 500 on /api/bootstrap and /api/state, which the browser
  // could not distinguish from a broken sign-in. Added as NULLABLE so existing
  // rows are never rejected; new writes always carry the owning entity.
  "ALTER TABLE \"journal_lines\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"bank_accounts\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"purchase_orders\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"employees\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"business_partners\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  // Older builds constrained `type` to lowercase values, while the application uses Vendor/Customer.
  "ALTER TABLE \"business_partners\" DROP CONSTRAINT IF EXISTS \"business_partners_type_check\"",
  // Preserve the original tenant-local id while assigning each tenant a collision-safe storage id.
  "ALTER TABLE \"business_partners\" ADD COLUMN IF NOT EXISTS \"source_id\" text",
  "UPDATE \"business_partners\" SET \"source_id\" = \"id\" WHERE \"source_id\" IS NULL",
  "ALTER TABLE \"business_partners\" ALTER COLUMN \"source_id\" SET NOT NULL",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"business_partners_scope_idx\" ON \"business_partners\" (COALESCE(\"client_id\", 0), \"source_id\")",
  "ALTER TABLE \"approval_requests\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"payroll_records\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"prepayment_records\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"prepayment_schedules\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"closed_periods\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"audit_log\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  // Session/user columns the auth layer depends on. Repaired in place so a
  // partially migrated database can never 401 a freshly issued session.
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"status\" text DEFAULT 'active'",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"restriction_reason\" text",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"permissions\" jsonb",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"password_hash\" text",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"password_salt\" text",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",

  /* --------------------------------------------------------------------- *
   * Trading subsystem: perpetual inventory + tax-aware fixed asset register.
   * --------------------------------------------------------------------- */
  "CREATE TABLE IF NOT EXISTS \"stock_items\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"item_code\" text NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"category\" text NOT NULL,\n\t\"uom\" text NOT NULL,\n\t\"quantity_on_hand\" double precision DEFAULT 0 NOT NULL,\n\t\"unit_cost\" double precision DEFAULT 0 NOT NULL,\n\t\"total_value\" double precision DEFAULT 0 NOT NULL,\n\t\"reorder_level\" double precision,\n\t\"location\" text,\n\t\"gl_account\" text,\n\t\"cost_method\" text,\n\t\"net_realisable_value\" double precision\n)",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"stock_items_scope_idx\" ON \"stock_items\" (\"client_id\",\"item_code\")",
  "CREATE TABLE IF NOT EXISTS \"stock_movements\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"date\" text NOT NULL,\n\t\"item_code\" text NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"type\" text NOT NULL,\n\t\"quantity\" double precision DEFAULT 0 NOT NULL,\n\t\"unit_cost\" double precision DEFAULT 0 NOT NULL,\n\t\"total_value\" double precision DEFAULT 0 NOT NULL,\n\t\"uom\" text NOT NULL,\n\t\"reference\" text,\n\t\"doc_no\" text,\n\t\"note\" text\n)",
  "CREATE INDEX IF NOT EXISTS \"stock_movements_client_idx\" ON \"stock_movements\" (\"client_id\")",
  "CREATE TABLE IF NOT EXISTS \"fixed_assets\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"asset_tag\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"class_code\" text NOT NULL,\n\t\"cost\" double precision DEFAULT 0 NOT NULL,\n\t\"accum_dep\" double precision DEFAULT 0 NOT NULL,\n\t\"useful_life\" text NOT NULL,\n\t\"depreciation_rate\" double precision,\n\t\"depreciation_method\" text,\n\t\"capital_allowance_class\" text,\n\t\"capital_allowance_rate\" double precision,\n\t\"accum_capital_allowance\" double precision DEFAULT 0 NOT NULL,\n\t\"location\" text DEFAULT '' NOT NULL,\n\t\"acquired\" text,\n\t\"disposed_date\" text,\n\t\"disposal_proceeds\" double precision\n)",
  "CREATE INDEX IF NOT EXISTS \"fixed_assets_client_idx\" ON \"fixed_assets\" (\"client_id\")",
  // Sales invoice: exact revenue account + trading-goods cost of sales fields.
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"revenue_account\" text",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"revenue_account_name\" text",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"item_type\" text",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"item_code\" text",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"quantity\" double precision",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"unit_selling_price\" double precision",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"unit_cost\" double precision",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"cogs_amount\" double precision",
  // Purchase order: stock item received and capitalised inward freight.
  "ALTER TABLE \"fixed_assets\" ADD COLUMN IF NOT EXISTS \"capital_allowance_class\" text",
  "ALTER TABLE \"purchase_orders\" ADD COLUMN IF NOT EXISTS \"item_code\" text",
  "ALTER TABLE \"purchase_orders\" ADD COLUMN IF NOT EXISTS \"inward_freight\" double precision",
  "CREATE TABLE IF NOT EXISTS \"journal_headers\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"doc_no\" text NOT NULL,\n\t\"period\" text NOT NULL,\n\t\"date\" text NOT NULL,\n\t\"module\" text NOT NULL,\n\t\"doc_type\" text NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"debit_total\" double precision NOT NULL,\n\t\"credit_total\" double precision NOT NULL,\n\t\"line_count\" integer NOT NULL,\n\t\"created_by\" text NOT NULL,\n\t\"checked_by\" text,\n\t\"reference\" text,\n\t\"content_hash\" text NOT NULL,\n\t\"posted_at\" timestamp with time zone DEFAULT now() NOT NULL\n)",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"journal_headers_client_doc_idx\" ON \"journal_headers\" (\"client_id\", \"doc_no\")",
  "CREATE TABLE IF NOT EXISTS \"posting_events\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"idempotency_key\" text NOT NULL,\n\t\"request_hash\" text NOT NULL,\n\t\"response\" jsonb NOT NULL,\n\t\"actor\" text NOT NULL,\n\t\"created_at\" timestamp with time zone DEFAULT now() NOT NULL\n)",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"posting_events_client_key_idx\" ON \"posting_events\" (\"client_id\", \"idempotency_key\")",
  // Supporting-document evidence, held server-side (never only in a browser cache).
  "CREATE TABLE IF NOT EXISTS \"attachments\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"doc_id\" text NOT NULL,\n\t\"doc_no\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"mime\" text NOT NULL,\n\t\"size\" integer NOT NULL,\n\t\"bytes\" bytea NOT NULL,\n\t\"added_by\" text NOT NULL,\n\t\"added_at\" timestamp with time zone DEFAULT now() NOT NULL\n)",
  "CREATE INDEX IF NOT EXISTS \"attachments_doc_idx\" ON \"attachments\" USING btree (\"client_id\",\"doc_id\")",
  // Cluster-wide login lockout (replaces the per-instance in-memory counter, so
  // several app instances behind a load balancer share one attempt budget).
  "CREATE TABLE IF NOT EXISTS \"bpz_login_attempts\" (\n\t\"identifier\" text PRIMARY KEY NOT NULL,\n\t\"attempts\" integer NOT NULL DEFAULT 0,\n\t\"locked_until\" bigint NOT NULL DEFAULT 0,\n\t\"updated_at\" bigint NOT NULL DEFAULT 0\n)",
  // Multi-factor authentication (RFC 6238 TOTP) — ISO 27001 A.8.5.
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"mfa_secret\" text",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"mfa_enabled\" boolean DEFAULT false NOT NULL",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"mfa_pending_secret\" text",
  // Operational events and cluster-wide rate-limit buckets.
  "CREATE TABLE IF NOT EXISTS \"ops_events\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"at\" timestamp with time zone DEFAULT now() NOT NULL,\n\t\"level\" text NOT NULL,\n\t\"event\" text NOT NULL,\n\t\"detail\" jsonb\n)",
  "CREATE INDEX IF NOT EXISTS \"ops_events_at_idx\" ON \"ops_events\" USING btree (\"at\")",
  "CREATE TABLE IF NOT EXISTS \"bpz_rate_limits\" (\n\t\"key\" text PRIMARY KEY NOT NULL,\n\t\"tokens\" double precision DEFAULT 0 NOT NULL,\n\t\"updated_at\" bigint DEFAULT 0 NOT NULL,\n\t\"locked_until\" bigint DEFAULT 0 NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"bpz_mfa_enrollments\" (\n\t\"token\" text PRIMARY KEY NOT NULL,\n\t\"user_id\" text NOT NULL,\n\t\"secret\" text NOT NULL,\n\t\"expires_at\" bigint NOT NULL,\n\t\"created_at\" timestamp with time zone DEFAULT now() NOT NULL\n)",
  "CREATE INDEX IF NOT EXISTS \"mfa_enrollments_user_idx\" ON \"bpz_mfa_enrollments\" USING btree (\"user_id\")",
  "ALTER TABLE \"bank_accounts\" ADD COLUMN IF NOT EXISTS \"fx_rate\" double precision",
  // Migration ledger. Additive schema changes now live in src/db/migrations.ts as
  // numbered, idempotent, recorded migrations rather than as another hand-written
  // ALTER in this baseline array — see the comment at the top of that file.
  "CREATE TABLE IF NOT EXISTS \"schema_migrations\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"statement_count\" integer NOT NULL,\n\t\"applied_at\" timestamp with time zone DEFAULT now() NOT NULL\n)",
];
