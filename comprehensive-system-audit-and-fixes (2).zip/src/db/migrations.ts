import { sql } from "drizzle-orm";
import type { db as Db } from "@/db";

/**
 * Versioned schema migrations.
 *
 * SCHEMA_DDL in ddl.ts is the idempotent BASELINE: `CREATE TABLE IF NOT EXISTS`
 * for every table, so a brand-new database reaches the current shape without
 * anyone running a tool by hand. That is convenient, but it gives no record of
 * WHAT changed or WHEN — and every additive change has to be remembered as a
 * hand-written `ALTER TABLE ... ADD COLUMN IF NOT EXISTS`, which silently
 * "succeeds" whether or not the developer added it.
 *
 * From here on, additive changes are written as numbered migrations instead:
 *
 *   1. append one entry to MIGRATIONS (never edit a released entry — its id is
 *      the fingerprint that tells other deployments they already have it),
 *   2. every statement must be re-runnable (IF NOT EXISTS / IF EXISTS), because
 *      a migration may be recorded but partially applied after a crash,
 *   3. the runner records the id in `schema_migrations` inside the same
 *      advisory-locked transaction as the DDL, so concurrent cold starts cannot
 *      double-apply or interleave.
 *
 * The credit-control columns on `business_partners` are migration 0001: they
 * were previously a bare ALTER in the baseline, which is exactly the discipline
 * this module replaces.
 */
type Executor = Pick<typeof Db, "execute">;
type Tx = { execute: Executor["execute"] };

export interface Migration {
  /** Stable, ordered, unique. Format: NNNP_snake_case_description. */
  id: string;
  description: string;
  statements: string[];
}

export const MIGRATIONS: Migration[] = [
  {
    id: "0001_business_partner_credit_control",
    description:
      "Credit control on the customer/vendor master file: approved limit, credit period, payment terms, credit standing and opening balance.",
    statements: [
      `ALTER TABLE "business_partners" ADD COLUMN IF NOT EXISTS "credit_limit" double precision`,
      `ALTER TABLE "business_partners" ADD COLUMN IF NOT EXISTS "credit_terms_days" integer`,
      `ALTER TABLE "business_partners" ADD COLUMN IF NOT EXISTS "payment_terms" text`,
      `ALTER TABLE "business_partners" ADD COLUMN IF NOT EXISTS "credit_status" text`,
      `ALTER TABLE "business_partners" ADD COLUMN IF NOT EXISTS "opening_balance" double precision`,
    ],
  },
];

/** Bookkeeping table; created by the baseline DDL so it exists before the runner. */
export const MIGRATION_TABLE_SQL = `create table if not exists "schema_migrations" (
  "id" text primary key not null,
  "description" text not null,
  "statement_count" integer not null,
  "applied_at" timestamp with time zone not null default now()
)`;

/**
 * A migration statement must be safe to re-run: a crash between "apply" and
 * "record" leaves the statement applied but unrecorded, and the next start would
 * replay it. This guard fails loudly rather than letting a non-idempotent
 * statement be shipped.
 */
export function assertIdempotent(migration: Migration): void {
  if (!migration.id || !/^\d{4}_[a-z0-9_]+$/.test(migration.id)) {
    throw new Error(`Migration id "${migration.id}" must look like 0001_snake_case.`);
  }
  if (!migration.statements.length) throw new Error(`Migration ${migration.id} has no statements.`);
  for (const statement of migration.statements) {
    const oneLine = statement.replace(/\s+/g, " ").trim();
    const safe =
      /CREATE TABLE IF NOT EXISTS/i.test(oneLine) ||
      /CREATE INDEX IF NOT EXISTS/i.test(oneLine) ||
      /CREATE UNIQUE INDEX IF NOT EXISTS/i.test(oneLine) ||
      /ADD COLUMN IF NOT EXISTS/i.test(oneLine) ||
      /DROP COLUMN IF EXISTS/i.test(oneLine) ||
      /ALTER COLUMN/i.test(oneLine) || // idempotent by nature (SET TYPE / DROP NOT NULL)
      /DROP TABLE IF EXISTS/i.test(oneLine) ||
      /CREATE OR REPLACE/i.test(oneLine) ||
      /ON CONFLICT DO NOTHING/i.test(oneLine) ||
      /INSERT INTO .* ON CONFLICT/i.test(oneLine);
    if (!safe) throw new Error(`Migration ${migration.id} contains a statement that is not re-runnable:\n  ${oneLine}`);
  }
}

/** Applies every migration that has not been recorded yet. Returns the ids applied. */
export async function applyPendingMigrations(tx: Tx): Promise<string[]> {
  for (const migration of MIGRATIONS) assertIdempotent(migration);
  const seen = new Set<string>();
  for (const migration of MIGRATIONS) {
    if (seen.has(migration.id)) throw new Error(`Duplicate migration id ${migration.id}.`);
    seen.add(migration.id);
  }

  await tx.execute(sql.raw(MIGRATION_TABLE_SQL));
  const applied = await tx.execute<{ id: string }>(sql`select id from "schema_migrations"`);
  const already = new Set(applied.rows.map((row) => row.id));

  const ran: string[] = [];
  for (const migration of MIGRATIONS) {
    if (already.has(migration.id)) continue;
    for (const statement of migration.statements) await tx.execute(sql.raw(statement));
    await tx.execute(
      sql`insert into "schema_migrations" ("id", "description", "statement_count")
          values (${migration.id}, ${migration.description}, ${migration.statements.length})
          on conflict do nothing`,
    );
    ran.push(migration.id);
  }
  return ran;
}

/** Ids of every migration already recorded as applied (for diagnostics/tests). */
export async function appliedMigrationIds(exec: Executor): Promise<string[]> {
  try {
    const res = await exec.execute<{ id: string }>(sql`select id from "schema_migrations" order by id`);
    return res.rows.map((row) => row.id);
  } catch {
    return [];
  }
}
