import type { BusinessPartner } from "@/types/accounting";

export type BusinessPartnerStorageRow = Omit<BusinessPartner, "id" | "clientId"> & {
  /** Database primary key: stable, globally unique, and tenant-scoped. */
  id: string;
  /** Original id used by the browser; it may repeat in another tenant. */
  sourceId: string;
  clientId: number | null;
};

export type BusinessPartnerPreparation =
  | { ok: true; rows: BusinessPartnerStorageRow[] }
  | { ok: false; status: 400 | 409; error: string };

/**
 * Encode a browser-side partner id into a stable database key. The UI can keep
 * short ids such as "1" in every company; the database key includes the tenant.
 */
export function businessPartnerStorageId(clientId: number | null | undefined, sourceId: string): string {
  const scope = clientId == null ? "shared" : `client-${clientId}`;
  return `bpz:${scope}:${encodeURIComponent(sourceId)}`;
}

function clean(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function stableFingerprint(partner: BusinessPartner, clientId: number | null, id: string, code: string, name: string): string {
  return JSON.stringify({
    id,
    clientId,
    code,
    name,
    type: partner.type,
    tin: clean(partner.tin),
    email: clean(partner.email),
    phone: clean(partner.phone),
    address: clean(partner.address),
    currency: clean(partner.currency) || "GHS",
    isVatWithholdingAgent: Boolean(partner.isVatWithholdingAgent),
    vatWithholdingRate: partner.vatWithholdingRate ?? null,
    isCstApplicable: Boolean(partner.isCstApplicable),
    isTourismLevyApplicable: Boolean(partner.isTourismLevyApplicable),
    isVatRegistered: partner.isVatRegistered ?? null,
    creditLimit: partner.creditLimit ?? null,
    creditTermsDays: partner.creditTermsDays ?? null,
    paymentTerms: clean(partner.paymentTerms),
    creditStatus: partner.creditStatus ?? null,
    openingBalance: partner.openingBalance ?? null,
  });
}

/** A credit limit or opening balance must be a finite, non-negative amount. */
function money(value: unknown, label: string, code: string): BusinessPartnerPreparation | number | null {
  if (value == null || value === "") return null;
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) {
    return { ok: false, status: 400, error: `Business partner ${code} has an invalid ${label}.` };
  }
  return Math.round(n * 100) / 100;
}

/**
 * Validate and map untrusted workspace partner rows to database-safe rows.
 * `defaultClientId` is the authenticated user's entity for legacy browser rows
 * that omitted the tenant; firm-wide callers pass null and retain shared rows.
 */
export function prepareBusinessPartnersForStorage(
  input: unknown,
  defaultClientId: number | null,
): BusinessPartnerPreparation {
  if (!Array.isArray(input)) {
    return { ok: false, status: 400, error: "Business partners must be provided as a list." };
  }

  const rows: BusinessPartnerStorageRow[] = [];
  const identities = new Map<string, { fingerprint: string; index: number }>();
  const codes = new Map<string, string>();

  for (let index = 0; index < input.length; index += 1) {
    const raw = input[index];
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return { ok: false, status: 400, error: `Business partner row ${index + 1} is invalid.` };
    }

    const candidate = raw as Partial<BusinessPartner>;
    const sourceId = clean(candidate.id);
    const code = clean(candidate.code).toUpperCase();
    const name = clean(candidate.name);
    if (!sourceId || !code || !name) {
      return { ok: false, status: 400, error: `Business partner row ${index + 1} needs an id, code, and name.` };
    }
    if (candidate.type !== "Vendor" && candidate.type !== "Customer") {
      return { ok: false, status: 400, error: `Business partner ${code} has an unsupported type.` };
    }

    const clientId = candidate.clientId == null ? defaultClientId : candidate.clientId;
    if (clientId !== null && (!Number.isSafeInteger(clientId) || clientId <= 0 || clientId > 2_147_483_647)) {
      return { ok: false, status: 400, error: `Business partner ${code} has an invalid client scope.` };
    }
    const scope = clientId == null ? "shared" : `client-${clientId}`;
    const identity = `${scope}\u0000${sourceId}`;
    const fingerprint = stableFingerprint(candidate as BusinessPartner, clientId, sourceId, code, name);
    const previous = identities.get(identity);
    if (previous) {
      if (previous.fingerprint === fingerprint) continue;
      return {
        ok: false,
        status: 409,
        error: `Conflicting business partner id ${sourceId} appears more than once for ${scope}.`,
      };
    }

    const codeKey = `${scope}\u0000${code}`;
    const previousIdentity = codes.get(codeKey);
    if (previousIdentity && previousIdentity !== identity) {
      return { ok: false, status: 409, error: `Partner code ${code} is already used in ${scope}.` };
    }

    identities.set(identity, { fingerprint, index });
    codes.set(codeKey, identity);

    // Credit control fields are validated here rather than trusted from the
    // browser: an unvalidated credit limit is exactly how a workspace could
    // silently grant itself unlimited credit.
    const limitCheck = money(candidate.creditLimit, "credit limit", code);
    if (limitCheck !== null && typeof limitCheck !== "number") return limitCheck;
    const checkedCreditLimit = limitCheck as number | null;

    const openingCheck = money(candidate.openingBalance, "opening balance", code);
    if (openingCheck !== null && typeof openingCheck !== "number") return openingCheck;
    const checkedOpening = openingCheck as number | null;

    let checkedTerms: number | null = null;
    if (candidate.creditTermsDays != null) {
      const n = Number(candidate.creditTermsDays);
      if (!Number.isInteger(n) || n < 0 || n > 365) {
        return { ok: false, status: 400, error: `Business partner ${code} has credit terms outside 0–365 days.` };
      }
      checkedTerms = n;
    }

    const rawStatus = clean(candidate.creditStatus);
    let checkedStatus: BusinessPartner["creditStatus"] | null = null;
    if (rawStatus) {
      if (rawStatus !== "Active" && rawStatus !== "On Hold" && rawStatus !== "Blocked") {
        return { ok: false, status: 400, error: `Business partner ${code} has an unsupported credit status.` };
      }
      checkedStatus = rawStatus;
    }

    const normalized: BusinessPartner = {
      id: sourceId,
      clientId: clientId ?? undefined,
      code,
      name,
      type: candidate.type,
      tin: clean(candidate.tin),
      email: clean(candidate.email),
      phone: clean(candidate.phone),
      address: clean(candidate.address),
      currency: clean(candidate.currency) || "GHS",
      isVatWithholdingAgent: Boolean(candidate.isVatWithholdingAgent),
      vatWithholdingRate: candidate.vatWithholdingRate,
      isCstApplicable: Boolean(candidate.isCstApplicable),
      isTourismLevyApplicable: Boolean(candidate.isTourismLevyApplicable),
      isVatRegistered: candidate.isVatRegistered,
      creditLimit: checkedCreditLimit ?? undefined,
      creditTermsDays: checkedTerms ?? undefined,
      paymentTerms: clean(candidate.paymentTerms) || undefined,
      creditStatus: checkedStatus ?? undefined,
      openingBalance: checkedOpening ?? undefined,
    };

    rows.push({
      ...normalized,
      id: businessPartnerStorageId(clientId, sourceId),
      sourceId,
      clientId,
    });
  }

  return { ok: true, rows };
}
