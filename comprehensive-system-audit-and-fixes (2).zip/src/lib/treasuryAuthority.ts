import { sql } from "drizzle-orm";
import type { db as Db } from "@/db";
import {
  applyLedgerAuthority,
  deriveTreasuryLedger,
  round2,
  treasuryGlFor,
  type TreasuryRecord,
} from "@/lib/treasuryDerivation";

/**
 * The general ledger is the ONLY authority for treasury balances.
 *
 * A bank / cash / wallet record that owns its treasury GL account (one record
 * per entity · GL · currency) has its balance DERIVED from posted journals on
 * every read (bootstrap) and every write (state sync). A browser therefore can
 * no longer save a bank balance that disagrees with the ledger: a direct edit is
 * simply replaced by the ledger figure. Records that share a GL with another
 * record (legacy set-ups) keep their stored value and are flagged by the
 * Control Accounts desk.
 *
 * The derivation itself lives in `treasuryDerivation.ts` (pure, client-safe) so
 * that the browser and the database compute the figure from the same rules and
 * a workspace sync can never be refused merely because the two sides disagreed
 * about arithmetic.
 */
type Executor = Pick<typeof Db, "execute">;

export type { TreasuryRecord };
export { applyLedgerAuthority, deriveTreasuryLedger, treasuryGlFor, round2 };

/** Ledger balance of every treasury (10xxxx) GL, per entity and currency. */
export async function ledgerTreasuryBalances(exec: Executor, clientIds: number[]): Promise<Map<string, number>> {
  const map = new Map<string, number>();
  if (!clientIds.length) return map;
  const ids = clientIds.filter((n) => Number.isInteger(n)).join(",") || "-1";
  const res = await exec.execute<{ client_id: number; account_no: number | string; currency: string; bal: string | number }>(sql`
    select client_id, account_no, currency, round(sum(debit - credit)::numeric, 2) as bal
      from journal_lines
     where account_no like '10%' and client_id in (${sql.raw(ids)})
     group by client_id, account_no, currency`);
  for (const r of res.rows) map.set(`${Number(r.client_id)}:${r.account_no}:${String(r.currency || "").toUpperCase()}`, round2(Number(r.bal)));
  return map;
}
