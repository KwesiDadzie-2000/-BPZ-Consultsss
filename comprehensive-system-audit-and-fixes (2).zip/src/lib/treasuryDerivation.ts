/**
 * Treasury derivation — PURE, client-safe, no database imports.
 *
 * The general ledger is the ONLY authority for a treasury (cash / bank / wallet)
 * balance. A treasury record's `balance` is therefore a *derived cache*, never an
 * independent fact, and it must be recomputed the same way on the server
 * (`ledgerTreasuryBalances`, SQL over `journal_lines`) and in the browser.
 *
 * Before this module existed the two sides disagreed by construction: the browser
 * hand-maintained `bank.balance` with ad-hoc `balance ± delta` arithmetic in
 * roughly fifteen places, while the server re-derived it from posted journals.
 * Every flow that moved cash through the ledger WITHOUT also nudging the stored
 * record — posting the opening trial balance, an IAS 21 FX revaluation, an asset
 * disposal, a manual journal, a trade posting — pushed the two apart, and the
 * next workspace sync was refused outright with
 * "Treasury record BNK-01 balance 20000.00 does not agree with the ledger
 *  (40000.00). Cash moves only through posted journals."
 *
 * Deriving on BOTH sides makes that disagreement impossible rather than merely
 * detected: the number shown, the number synced and the number stored all come
 * from the same posted journal lines.
 *
 * This module must stay free of `drizzle-orm` / `@/db` so it can be imported by
 * client components without pulling server code into the browser bundle.
 */

export interface TreasuryRecord {
  id?: number;
  clientId?: number | null;
  glAccount?: string | null;
  kind?: string | null;
  currency: string;
  balance: number;
}

/** A posted journal line, structurally typed so it works on client and server. */
export interface TreasuryJournalLine {
  clientId?: number | null;
  accountNo: string;
  currency: string;
  debit: number;
  credit: number;
}

/** Treasury GL of a record: explicit account, else cash-on-hand vs bank default. */
export const treasuryGlFor = (b: Pick<TreasuryRecord, "glAccount" | "kind">): string =>
  b.glAccount || (b.kind === "cash" ? "102000" : "100000");

const key = (clientId: number, gl: string, currency: string) =>
  `${clientId}:${gl}:${String(currency || "").toUpperCase()}`;

/** Round to minor units the same way the server does. */
export const round2 = (n: number): number => Math.round((n + Number.EPSILON) * 100) / 100;

/**
 * Ledger balance of every treasury (10xxxx) GL, per entity and currency —
 * the browser-side mirror of `ledgerTreasuryBalances()` in treasuryAuthority.ts.
 */
export function deriveTreasuryLedger(
  lines: readonly TreasuryJournalLine[],
  clientIds?: readonly number[],
): Map<string, number> {
  const map = new Map<string, number>();
  const allowed = clientIds ? new Set(clientIds) : null;
  for (const l of lines) {
    const cid = l.clientId;
    if (cid == null || !Number.isInteger(cid)) continue;
    if (allowed && !allowed.has(cid)) continue;
    // Must match the SQL predicate `account_no like '10%'`.
    if (!String(l.accountNo || "").startsWith("10")) continue;
    const k = key(cid, String(l.accountNo), String(l.currency || ""));
    map.set(k, round2((map.get(k) ?? 0) + (Number(l.debit) || 0) - (Number(l.credit) || 0)));
  }
  return map;
}

/**
 * Replace each uniquely-mapped treasury record's balance with the ledger balance.
 *
 * A record that shares its (entity · GL · currency) with another record cannot be
 * attributed to one holder, so it keeps its stored value and is flagged by the
 * Control Accounts desk instead.
 */
export function applyLedgerAuthority<T extends TreasuryRecord>(
  records: T[],
  ledger: Map<string, number>,
): T[] {
  const groups = new Map<string, number>();
  for (const b of records) {
    if (b.clientId == null) continue;
    const k = key(b.clientId, treasuryGlFor(b), b.currency);
    groups.set(k, (groups.get(k) ?? 0) + 1);
  }
  return records.map((b) => {
    if (b.clientId == null) return b;
    const k = key(b.clientId, treasuryGlFor(b), b.currency);
    if (groups.get(k) !== 1) return b; // shared GL — cannot attribute, keep stored
    return { ...b, balance: round2(ledger.get(k) ?? 0) };
  });
}
