import assert from 'node:assert/strict';
import { test } from 'node:test';
import {
  parseStatementDate,
  parseStatementAmount,
  parseStatementReport,
  matchStatementLines,
  type StatementLine,
} from '../utils/reports';
import { applyLedgerAuthority, deriveTreasuryLedger } from '../lib/treasuryDerivation';
import { prepareBusinessPartnersForStorage } from '../lib/businessPartnerSync';
import type { ACDOCALine, BusinessPartner } from '../types/accounting';

/* ------------------------------------------------------------------ */
/* Statement import — the real-world formats banks actually export     */
/* ------------------------------------------------------------------ */

test('statement dates: ISO, day-first, month-name and US formats all parse', () => {
  assert.equal(parseStatementDate('2026-03-12'), '2026-03-12');
  assert.equal(parseStatementDate('12/03/2026'), '2026-03-12');
  assert.equal(parseStatementDate('12-03-26'), '2026-03-12');
  assert.equal(parseStatementDate('12 MAR 2026'), '2026-03-12');
  assert.equal(parseStatementDate('March 12, 2026'), '2026-03-12');
  assert.equal(parseStatementDate('03/25/2026'), '2026-03-25'); // US month/day
  assert.equal(parseStatementDate('not a date'), null);
});

test('statement amounts: separators, currencies and bracketed negatives', () => {
  assert.equal(parseStatementAmount('1,234.50'), 1234.5);
  assert.equal(parseStatementAmount('GHS 2,000'), 2000);
  assert.equal(parseStatementAmount('(450.00)'), -450);
  assert.equal(parseStatementAmount('1.234,56'), 1234.56);
  assert.equal(parseStatementAmount(''), 0);
  assert.equal(parseStatementAmount('n/a'), null);
});

test('statement report: header aliases, signed Amount column, totals row skipped', () => {
  const csv = [
    'Value Date;Narrative;Amount;Running Balance',
    '12/03/2026;Transfer to supplier;-1,500.00;18,500.00',
    '13/03/2026;Customer receipt;2,000.00;20,500.00',
    '13/03/2026;Total;;20,500.00',
  ].join('\n');
  const report = parseStatementReport(csv);
  assert.equal(report.delimiter, ';');
  assert.equal(report.headerDetected, true);
  assert.equal(report.lines.length, 2);
  assert.equal(report.lines[0].debit, 1500); // money OUT
  assert.equal(report.lines[0].credit, 0);
  assert.equal(report.lines[1].credit, 2000); // money IN
  assert.equal(report.totals.net, 500);
  assert.equal(report.skippedRows, 1);
});

test('statement report: debit-is-in convention flips the reading', () => {
  const csv = 'Date,Description,Debit,Credit\n2026-03-12,Receipt,500.00,\n';
  const out = parseStatementReport(csv);
  assert.equal(out.lines[0].debit, 500); // default: Debit column = money out
  const flipped = parseStatementReport(csv, { convention: 'debit-is-in' });
  assert.equal(flipped.lines[0].credit, 500);
  assert.equal(flipped.lines[0].debit, 0);
});

test('matching: statement money OUT matches a journal CREDIT on the treasury GL', () => {
  const journal: ACDOCALine[] = [{
    id: 'j1', docNo: 'PAY-001', period: '2026-03', date: '2026-03-12', module: 'FI',
    docType: 'JE', accountNo: '100000', accountName: 'Bank', costCenter: undefined,
    debit: 0, credit: 1500, currency: 'GHS', description: 'Supplier payment',
    createdBy: 'maker', clientId: 2,
  }, {
    id: 'j2', docNo: 'REC-001', period: '2026-03', date: '2026-03-14', module: 'FI',
    docType: 'JE', accountNo: '100000', accountName: 'Bank', costCenter: undefined,
    debit: 2000, credit: 0, currency: 'GHS', description: 'Customer receipt',
    createdBy: 'maker', clientId: 2,
  }];
  const statement: StatementLine[] = [
    { date: '2026-03-12', description: 'Supplier payment', debit: 1500, credit: 0 },
    { date: '2026-03-13', description: 'Customer receipt', debit: 0, credit: 2000 },
    { date: '2026-03-15', description: 'Bank charges', debit: 25, credit: 0 },
  ];
  const results = matchStatementLines(statement, journal, '100000');
  assert.equal(results[0].matched, true);
  assert.equal(results[0].matchedDocNo, 'PAY-001');
  assert.equal(results[1].matched, true);
  assert.equal(results[1].matchedDocNo, 'REC-001');
  assert.equal(results[2].matched, false); // exception queue
});

/* ------------------------------------------------------------------ */
/* Treasury authority — the ledger, not the browser, sets the balance  */
/* ------------------------------------------------------------------ */

const jl = (accountNo: string, debit: number, credit: number, clientId = 2): ACDOCALine => ({
  id: `${accountNo}-${debit}-${credit}`, docNo: 'DOC', period: '2026-03', date: '2026-03-01',
  module: 'FI', docType: 'JE', accountNo, accountName: 'A', costCenter: undefined,
  debit, credit, currency: 'GHS', description: 'x', createdBy: 'maker', clientId,
});

test('treasury derivation: opening journal makes record and ledger agree at 40000', () => {
  // The reported failure: the record said 20000 while the ledger said 40000.
  const lines = [jl('100000', 40000, 0), jl('309000', 0, 40000)];
  const derived = applyLedgerAuthority(
    [{ id: 1, clientId: 2, glAccount: '100000', currency: 'GHS', balance: 20000 }],
    deriveTreasuryLedger(lines),
  );
  assert.equal(derived[0].balance, 40000);
});

test('treasury derivation: a record sharing its GL keeps its stored value', () => {
  const lines = [jl('100000', 1000, 0)];
  const derived = applyLedgerAuthority(
    [
      { id: 1, clientId: 2, glAccount: '100000', currency: 'GHS', balance: 700 },
      { id: 2, clientId: 2, glAccount: '100000', currency: 'GHS', balance: 300 },
    ],
    deriveTreasuryLedger(lines),
  );
  assert.equal(derived[0].balance, 700);
  assert.equal(derived[1].balance, 300);
});

/* ------------------------------------------------------------------ */
/* Customer / vendor credit registration                               */
/* ------------------------------------------------------------------ */

const partner = (over: Partial<BusinessPartner> = {}): BusinessPartner => ({
  id: 'bp-1', code: 'C001', name: 'Accra Retail Ltd', type: 'Customer',
  tin: 'C001', email: '', phone: '', address: '', currency: 'GHS',
  isVatWithholdingAgent: false, isCstApplicable: false, isTourismLevyApplicable: false,
  ...over,
});

test('credit registration: limit, terms and standing survive preparation', () => {
  const result = prepareBusinessPartnersForStorage(
    [partner({ creditLimit: 50000, creditTermsDays: 45, paymentTerms: 'Net 45', creditStatus: 'Active', openingBalance: 1200 })],
    2,
  );
  assert.equal(result.ok, true);
  if (result.ok) {
    assert.equal(result.rows[0].creditLimit, 50000);
    assert.equal(result.rows[0].creditTermsDays, 45);
    assert.equal(result.rows[0].creditStatus, 'Active');
  }
});

test('credit registration: negative limits and bad terms are refused server-side', () => {
  const bad = prepareBusinessPartnersForStorage([partner({ creditLimit: -1 })], 2);
  assert.equal(bad.ok, false);
  const badTerms = prepareBusinessPartnersForStorage([partner({ creditTermsDays: 999 })], 2);
  assert.equal(badTerms.ok, false);
  const badStatus = prepareBusinessPartnersForStorage([partner({ creditStatus: 'Frozen' as never })], 2);
  assert.equal(badStatus.ok, false);
});
