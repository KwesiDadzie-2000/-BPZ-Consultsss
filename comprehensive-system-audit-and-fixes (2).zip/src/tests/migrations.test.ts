import assert from 'node:assert/strict';
import { test } from 'node:test';
import { MIGRATIONS, assertIdempotent, type Migration } from '../db/migrations';

/**
 * Versioned migrations: the guard rails that make an additive schema change
 * safe to ship. A migration that is not re-runnable would replay after a crash
 * between "apply" and "record"; a duplicate id would make two deployments
 * disagree about what is in the database.
 */
test('migration ids are unique, ordered and well formed', () => {
  const ids = MIGRATIONS.map((m) => m.id);
  assert.equal(new Set(ids).size, ids.length, 'duplicate migration id');
  for (const id of ids) assert.match(id, /^\d{4}_[a-z0-9_]+$/);
  const sorted = [...ids].sort();
  assert.deepEqual(ids, sorted, 'migrations must be declared in ascending order');
});

test('every migration carries a description and at least one statement', () => {
  for (const migration of MIGRATIONS) {
    assert.ok(migration.description.trim().length > 10, `${migration.id} needs a description`);
    assert.ok(migration.statements.length > 0, `${migration.id} has no statements`);
  }
});

test('idempotency guard accepts the real migrations and rejects unsafe ones', () => {
  for (const migration of MIGRATIONS) assertIdempotent(migration);

  const unsafe: Migration = {
    id: '0002_unsafe',
    description: 'Drops data without a guard.',
    statements: ['DELETE FROM journal_lines'],
  };
  assert.throws(() => assertIdempotent(unsafe), /not re-runnable/);

  const badId: Migration = {
    id: 'add columns',
    description: 'Malformed id.',
    statements: ['ALTER TABLE t ADD COLUMN IF NOT EXISTS c text'],
  };
  assert.throws(() => assertIdempotent(badId), /must look like/);
});

test('the credit-control change ships as a recorded migration, not a bare ALTER', () => {
  const credit = MIGRATIONS.find((m) => m.id === '0001_business_partner_credit_control');
  assert.ok(credit, 'credit control must be migration 0001');
  const columns = ['credit_limit', 'credit_terms_days', 'payment_terms', 'credit_status', 'opening_balance'];
  for (const column of columns) {
    assert.ok(
      credit.statements.some((s) => s.includes(`"${column}"`) && /ADD COLUMN IF NOT EXISTS/i.test(s)),
      `${column} must be added idempotently`,
    );
  }
});
