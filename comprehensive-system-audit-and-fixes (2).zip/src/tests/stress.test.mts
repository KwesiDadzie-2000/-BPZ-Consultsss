import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import type { ACDOCALine } from '../types/accounting';

/**
 * Stress + integration audit. Destructive: runs ONLY against the disposable
 * local `bpz_review_test` database (same guard as apiRegression).
 */
const url = process.env.BPZ_TEST_DATABASE_URL;
if (!url) throw new Error('Set BPZ_TEST_DATABASE_URL to the disposable local bpz_review_test database.');
const parsed = new URL(url);
if (!['localhost', '127.0.0.1'].includes(parsed.hostname) || parsed.pathname !== '/bpz_review_test') {
  throw new Error('Refusing to run against anything except a local bpz_review_test database.');
}
process.env.DATABASE_URL = url;
process.env.BPZ_SEED_PASSWORD_OWNER = `Stress-${randomUUID()}!`;
process.env.BPZ_SEED_PASSWORD_DEMO = `Stress-${randomUUID()}!`;

const { pool } = await import('../db');
await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
const login = await import('../app/api/auth/login/route');
const journal = await import('../app/api/journal/route');
const state = await import('../app/api/state/route');
const bootstrap = await import('../app/api/bootstrap/route');
const { parseStatementReport, matchStatementLines } = await import('../utils/reports');

type Handler = (request: Request) => Promise<Response>;
const call = (handler: Handler, method: string, body?: unknown, token?: string) => handler(new Request('http://localhost/api/test', {
  method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  ...(body === undefined ? {} : { body: JSON.stringify(body) }),
}));

let passed = 0;
let failed = 0;
async function check(title: string, action: () => Promise<void>) {
  const t0 = Date.now();
  try { await action(); passed++; console.log(`PASS ${title} (${Date.now() - t0} ms)`); }
  catch (error) { failed++; console.error(`FAIL ${title}`, error); }
}

const base: ACDOCALine = {
  id: '', docNo: '', period: '2026-10', date: '2026-10-29', module: 'FI', docType: 'JE',
  accountNo: '100000', accountName: 'Bank', debit: 100, credit: 0, currency: 'GHS',
  description: 'Stress test', createdBy: 'owner', clientId: 2,
};
const pair = (docNo: string, o: Partial<ACDOCALine> = {}): ACDOCALine[] => [
  { ...base, ...o, docNo, id: `${docNo}-a` },
  { ...base, ...o, docNo, id: `${docNo}-b`, accountNo: '400000', debit: 0, credit: o.debit || 100 },
];

const ownerAuth = await call(login.POST, 'POST', { usernameOrEmail: 'owner', password: process.env.BPZ_SEED_PASSWORD_OWNER });
assert.equal(ownerAuth.status, 200);
const { token: owner } = await ownerAuth.json();
const demoAuth = await call(login.POST, 'POST', { usernameOrEmail: 'demo', password: process.env.BPZ_SEED_PASSWORD_DEMO });
assert.equal(demoAuth.status, 200);
const { token: demo } = await demoAuth.json();
const workspace = async (token: string) => {
  const r = await call(bootstrap.GET, 'GET', undefined, token);
  assert.equal(r.status, 200);
  return (await r.json()).state;
};

/* ---------------- Security sweep ---------------- */
await check('every data route refuses unauthenticated access', async () => {
  const routes: [string, Handler, string][] = [];
  for (const name of ['state', 'bootstrap', 'journal', 'attachments', 'audit', 'backups', 'clients', 'desk', 'production', 'trade', 'users', 'workbooks', 'tax-settings', 'mail']) {
    const mod = await import(`../app/api/${name}/route`) as Record<string, Handler>;
    for (const m of ['GET', 'POST', 'PUT', 'DELETE']) if (typeof mod[m] === 'function') routes.push([name, mod[m], m]);
  }
  for (const [name, h, m] of routes) {
    const r = await call(h, m, m === 'GET' || m === 'DELETE' ? undefined : {});
    assert.ok([400, 401, 403, 405].includes(r.status), `${m} /api/${name} returned ${r.status} without a session`);
    assert.notEqual(r.status, 200, `${m} /api/${name} leaked data`);
  }
});

await check('wrong password is refused and does not reveal which field was wrong', async () => {
  const r = await call(login.POST, 'POST', { usernameOrEmail: 'owner', password: 'nope-nope-nope' });
  assert.equal(r.status, 401);
});

await check('demo (client user) cannot post into another client', async () => {
  const r = await call(journal.POST, 'POST', { lines: pair('XTENANT-1', { clientId: 1, createdBy: 'demo' }) }, demo);
  assert.ok([403, 409].includes(r.status), `got ${r.status}`);
});

await check('unbalanced journal is refused', async () => {
  const lines = pair('UNBAL-1');
  lines[1].credit = 99;
  assert.ok([400, 409].includes((await call(journal.POST, 'POST', { lines }, owner)).status));
});

/* ---------------- Concurrency ---------------- */
await check('25 concurrent distinct postings all commit exactly once', async () => {
  const results = await Promise.all(Array.from({ length: 25 }, (_, i) =>
    call(journal.POST, 'POST', { lines: pair(`CONC-${i}`) }, owner)));
  for (const r of results) assert.equal(r.status, 200, JSON.stringify(await r.clone().json()));
  const { rows } = await pool.query("select count(distinct doc_no)::int n from journal_lines where doc_no like 'CONC-%'");
  assert.equal(rows[0].n, 25);
});

await check('10 concurrent replays of ONE document post it once (idempotent)', async () => {
  const lines = pair('RACE-ONE');
  const results = await Promise.all(Array.from({ length: 10 }, () => call(journal.POST, 'POST', { lines }, owner)));
  assert.ok(results.every((r) => r.status === 200 || r.status === 409));
  const { rows } = await pool.query("select count(*)::int n from journal_lines where doc_no = 'RACE-ONE'");
  assert.equal(rows[0].n, 2);
});

/* ---------------- Volume ---------------- */
await check('volume: 400 documents posted sequentially; ledger still balances', async () => {
  for (let i = 0; i < 400; i += 1) {
    const r = await call(journal.POST, 'POST', { lines: pair(`VOL-${i}`, { debit: 10 + (i % 7) }) }, owner);
    assert.equal(r.status, 200);
  }
  const { rows } = await pool.query('select round(sum(debit)::numeric,2) d, round(sum(credit)::numeric,2) c from journal_lines');
  assert.equal(rows[0].d, rows[0].c, 'trial balance does not balance');
});

await check('bootstrap stays responsive with a large ledger (< 5 s)', async () => {
  const t0 = Date.now();
  await workspace(owner);
  assert.ok(Date.now() - t0 < 5000, `bootstrap took ${Date.now() - t0} ms`);
});

/* ---------------- Reported defect: treasury sync ---------------- */
await check('treasury from bootstrap equals ledger (BNK-01 derived, not stored)', async () => {
  const s = await workspace(owner);
  const { rows } = await pool.query("select client_id, account_no, round(sum(debit-credit)::numeric,2) bal from journal_lines where account_no like '10%' group by 1,2");
  for (const b of s.bankAccounts) {
    const gl = b.glAccount || (b.kind === 'cash' ? '102000' : '100000');
    const shared = s.bankAccounts.filter((x: any) => x.clientId === b.clientId && (x.glAccount || (x.kind === 'cash' ? '102000' : '100000')) === gl && x.currency === b.currency).length > 1;
    if (shared) continue;
    const row = rows.find((r: any) => r.client_id === b.clientId && r.account_no === gl);
    assert.equal(Number(b.balance).toFixed(2), Number(row?.bal ?? 0).toFixed(2), `${b.code} disagrees with GL`);
  }
});

await check('non-owner sync with a STALE treasury balance is accepted and corrected (was: whole sync refused)', async () => {
  const s = await workspace(demo);
  if (!s.bankAccounts.length) return; // demo has no treasury in this seed
  const stale = s.bankAccounts.map((b: any) => ({ ...b, balance: b.balance + 20000 }));
  const r = await call(state.PUT, 'PUT', { ...s, journalLines: [], bankAccounts: stale }, demo);
  const body = await r.json();
  assert.equal(r.status, 200, JSON.stringify(body));
  assert.ok(body.warnings.some((w: string) => /corrected to the ledger figure/.test(w)));
  const after = await workspace(demo);
  for (const b of after.bankAccounts) {
    const was = s.bankAccounts.find((x: any) => x.id === b.id);
    assert.equal(b.balance, was.balance, 'stale browser figure was persisted');
  }
});

/* ---------------- Credit registration round-trip ---------------- */
await check('owner registers a customer on credit; fields persist through sync + bootstrap', async () => {
  const s = await workspace(owner);
  const partner = {
    id: 'STRESS-CUST', clientId: 2, code: 'CSTRESS', name: 'Stress Retail Ltd', type: 'Customer',
    tin: 'C0099', email: '', phone: '', address: '', currency: 'GHS',
    isVatWithholdingAgent: false, isCstApplicable: false, isTourismLevyApplicable: false,
    creditLimit: 75000, creditTermsDays: 45, paymentTerms: 'Net 45', creditStatus: 'On Hold', openingBalance: 1200,
  };
  const r = await call(state.PUT, 'PUT', { ...s, journalLines: [], businessPartners: [...s.businessPartners, partner] }, owner);
  assert.equal(r.status, 200, JSON.stringify(await r.clone().json()));
  const after = await workspace(owner);
  const got = after.businessPartners.find((p: any) => p.id === 'STRESS-CUST');
  assert.ok(got, 'partner not persisted');
  assert.equal(got.creditLimit, 75000);
  assert.equal(got.creditTermsDays, 45);
  assert.equal(got.creditStatus, 'On Hold');
  assert.equal(got.openingBalance, 1200);
});

await check('a negative credit limit is rejected by the server', async () => {
  const s = await workspace(owner);
  const bad = s.businessPartners.map((p: any) => (p.id === 'STRESS-CUST' ? { ...p, creditLimit: -5 } : p));
  const r = await call(state.PUT, 'PUT', { ...s, journalLines: [], businessPartners: bad }, owner);
  assert.equal(r.status, 400);
});

/* ---------------- Statement import at scale ---------------- */
await check('statement import: 20,000-row bank file parses and matches quickly', async () => {
  const rows = ['Value Date;Narrative;Withdrawal;Deposit;Balance'];
  const journalLines: ACDOCALine[] = [];
  for (let i = 0; i < 20000; i += 1) {
    const d = `${String((i % 28) + 1).padStart(2, '0')}/03/2026`;
    const amt = (100 + (i % 500)).toFixed(2);
    rows.push(`${d};"Txn ${i}, ref ${i}";${i % 2 ? amt : ''};${i % 2 ? '' : amt};`);
    if (i < 2000) journalLines.push({ ...base, id: `S${i}`, docNo: `S${i}`, date: `2026-03-${String((i % 28) + 1).padStart(2, '0')}`, period: '2026-03',
      debit: i % 2 ? 0 : Number(amt), credit: i % 2 ? Number(amt) : 0 });
  }
  const t0 = Date.now();
  const report = parseStatementReport(rows.join('\n'));
  assert.equal(report.lines.length, 20000);
  assert.equal(report.skippedRows, 0);
  const m = matchStatementLines(report.lines.slice(0, 2000), journalLines, '100000');
  assert.ok(m.filter((x) => x.matched).length >= 1900, 'match rate unexpectedly low');
  assert.ok(Date.now() - t0 < 8000, `took ${Date.now() - t0} ms`);
});

await check('statement import: garbage / binary input never throws', async () => {
  for (const junk of ['', '\u0000\u0001PK\u0003\u0004', '"unterminated,quote\n1,2', 'a\nb\nc', ';;;;\n;;;;']) {
    const r = parseStatementReport(junk);
    assert.ok(Array.isArray(r.lines));
  }
});

console.log(`\n${passed} passed, ${failed} failed`);
await pool.end();
if (failed) process.exit(1);
