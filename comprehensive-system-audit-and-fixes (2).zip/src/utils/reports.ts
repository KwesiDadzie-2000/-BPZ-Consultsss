import type { ACDOCALine, AccountMaster } from '../types/accounting';
import { GHANA_ECONOMY_SECTORS } from '../data/ghanaSectors';
import { docSuffix, uniqueId } from './ids';

/**
 * Shared, ledger-derived reporting engine for the BPZ Consult ERP.
 * Every figure is computed strictly from posted journal lines — no hard-coded amounts.
 */

export const CASH_ACCOUNTS = ['100000', '101000', '102000', '103000', '104000'];

/** Non-cash expenses added back in the IAS 7 indirect operating section. */
const ADD_BACK_EXPENSE = ['600000', '610000', '611000', '612000', '680000', '690000', '698000', '731000'];
/** Non-cash credit movements added back (provision increases). */
const ADD_BACK_CREDIT = ['240000', '270000', '271000'];
/** Gains on disposal removed from operating (presented in investing). */
const REMOVE_GAIN = ['492000'];
/** Working-capital asset groups (debit-normal). */
const RECEIVABLE_ACCOUNTS = ['110000', '111000', '112000', '113000', '114000', '115000', '118000', '141000'];
const INVENTORY_ACCOUNTS = ['120000', '121000', '122000', '123000', '124000'];
const PREPAID_ACCOUNTS = ['116000'];
/** Working-capital liability groups (credit-normal). */
const PAYABLE_ACCOUNTS = ['200000', '201000', '202000', '203000', '205000', '206000', '206100', '207000', '208000', '209000', '212000', '220000', '221000', '223000', '224000'];
/** Investing (debit-normal non-current assets). */
const INVESTING_ACCOUNTS = ['130000', '131000', '132000', '133000', '134000', '135000', '136000', '142000', '143000', '144000', '150000', '152000', '160000', '161000', '162000', '180000'];
/** Financing (credit-normal borrowings, leases, equity, dividends payable). */
const FINANCING_ACCOUNTS = ['210000', '211000', '226000', '230000', '250000', '300000', '301000', '311000', '313000'];

const toMinor = (n: number) => Math.round(n * 100);
const toMajor = (minor: number) => Math.round(minor) / 100;
const inCents = (n: number) => Math.round(n * 100) / 100; // round to 2dp in major units

export const classifyAccount = (accounts: AccountMaster[], code: string): AccountMaster['type'] => {
  const master = accounts.find((a) => a.accountNo === code);
  if (master) return master.type;
  return code.startsWith('1') ? 'Asset'
    : code.startsWith('2') ? 'Liability'
    : code.startsWith('3') ? 'Equity'
    : code.startsWith('4') ? 'Income' : 'Expense';
};

export interface TbRow {
  code: string;
  name: string;
  type: AccountMaster['type'];
  dr: number;
  cr: number;
}

/** Aggregates journal lines into trial-balance rows (amounts in major units). */
export function aggregateTrialBalance(lines: ACDOCALine[], accounts: AccountMaster[]): TbRow[] {
  const map = new Map<string, TbRow>();
  for (const l of lines) {
    const row = map.get(l.accountNo) ?? {
      code: l.accountNo,
      name: accounts.find((a) => a.accountNo === l.accountNo)?.name || l.accountName,
      type: classifyAccount(accounts, l.accountNo),
      dr: 0,
      cr: 0,
    };
    row.dr += toMinor(l.debit);
    row.cr += toMinor(l.credit);
    map.set(l.accountNo, row);
  }
  return [...map.values()].sort((a, b) => a.code.localeCompare(b.code));
}

const netDrCr = (lines: ACDOCALine[], accountNos: string[]): number =>
  toMajor(lines.filter((l) => accountNos.includes(l.accountNo)).reduce((n, l) => n + toMinor(l.debit) - toMinor(l.credit), 0));

const netCrDr = (lines: ACDOCALine[], accountNos: string[]): number =>
  toMajor(lines.filter((l) => accountNos.includes(l.accountNo)).reduce((n, l) => n + toMinor(l.credit) - toMinor(l.debit), 0));

const profitOf = (lines: ACDOCALine[], accounts: AccountMaster[]): number => {
  const rows = aggregateTrialBalance(lines, accounts);
  // Profit = income - expenses = -(sum of P&L debit-minus-credit), rows are in minor units.
  return toMajor(rows
    .filter((r) => r.type === 'Income' || r.type === 'Expense')
    .reduce((n, r) => n - (r.dr - r.cr), 0));
};

export interface CashFlowStatement {
  profitBeforeTax: number;
  addBacks: number;
  removeGains: number;
  deltaReceivables: number;
  deltaInventory: number;
  deltaPrepaids: number;
  deltaPayables: number;
  operating: number;
  investing: number;
  financing: number;
  netChange: number;
  openingCash: number;
  closingCash: number;
  cashMovement: number;
  residual: number;
}

/**
 * IAS 7 indirect-method statement of cash flows derived from the posted journal.
 * `residual` must equal zero — it proves the classification covers every movement.
 */
export function buildCashFlow(lines: ACDOCALine[], accounts: AccountMaster[], from: string, through: string): CashFlowStatement {
  const scoped = lines.filter((l) => l.date <= through);
  const movement = scoped.filter((l) => l.date >= from);
  const prior = scoped.filter((l) => l.date < from);

  const profitBeforeTax = profitOf(movement, accounts);
  const addBacks = netDrCr(movement, ADD_BACK_EXPENSE) + netCrDr(movement, ADD_BACK_CREDIT);
  const removeGains = netCrDr(movement, REMOVE_GAIN);

  // Working-capital movements = closing balance minus opening balance per group.
  const deltaOf = (group: string[], crNormal: boolean) => {
    const closing = crNormal ? netCrDr(scoped, group) : netDrCr(scoped, group);
    const opening = crNormal ? netCrDr(prior, group) : netDrCr(prior, group);
    return inCents(closing - opening);
  };
  const dReceivables = deltaOf(RECEIVABLE_ACCOUNTS, false);
  const dInventory = deltaOf(INVENTORY_ACCOUNTS, false);
  const dPrepaids = deltaOf(PREPAID_ACCOUNTS, false);
  const dPayables = deltaOf(PAYABLE_ACCOUNTS, true);

  const operating = inCents(profitBeforeTax + addBacks - removeGains - dReceivables - dInventory - dPrepaids + dPayables);
  const investing = inCents(-deltaOf(INVESTING_ACCOUNTS, false));
  const financing = inCents(deltaOf(FINANCING_ACCOUNTS, true));
  const netChange = inCents(operating + investing + financing);

  const openingCash = netDrCr(prior, CASH_ACCOUNTS);
  const closingCash = netDrCr(scoped, CASH_ACCOUNTS);
  const cashMovement = inCents(closingCash - openingCash);
  const residual = inCents(cashMovement - netChange);
  return {
    profitBeforeTax, addBacks, removeGains,
    deltaReceivables: dReceivables, deltaInventory: dInventory, deltaPrepaids: dPrepaids, deltaPayables: dPayables,
    operating, investing, financing, netChange,
    openingCash, closingCash, cashMovement, residual,
  };
}

export interface AgingBuckets {
  current: number;
  days31to60: number;
  days61to90: number;
  over90: number;
  total: number;
  overdueCount: number;
}

const dayMs = 86400000;
/** Ages open items into 30-day buckets as at a date (30-day credit terms assumed). */
export function ageIntoBuckets(asOf: string, items: { date: string; amount: number }[]): AgingBuckets {
  const asOfMs = new Date(`${asOf}T00:00:00.000Z`).getTime();
  const buckets = { current: 0, days31to60: 0, days61to90: 0, over90: 0, total: 0, overdueCount: 0 };
  for (const item of items) {
    const age = Math.max(0, Math.floor((asOfMs - new Date(`${item.date}T00:00:00.000Z`).getTime()) / dayMs));
    buckets.total = inCents(buckets.total + item.amount);
    if (age > 90) buckets.over90 = inCents(buckets.over90 + item.amount);
    else if (age > 60) buckets.days61to90 = inCents(buckets.days61to90 + item.amount);
    else if (age > 30) buckets.days31to60 = inCents(buckets.days31to60 + item.amount);
    else buckets.current = inCents(buckets.current + item.amount);
    if (age > 30) buckets.overdueCount += 1;
  }
  return buckets;
}

/** Maps a client sector description to the CIT rate of the matching Ghanaian sector. */
export function sectorCitRate(sector: string): { rate: number; sectorName: string } {
  const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter((w) => w.length > 3 && !['with', 'from', 'other'].includes(w));
  const clientWords = new Set(normalize(sector));
  let best: { rate: number; sectorName: string; score: number } = { rate: 25, sectorName: 'General commerce & services (standard CIT)', score: 0 };
  for (const def of GHANA_ECONOMY_SECTORS) {
    const score = normalize(def.name).filter((w) => clientWords.has(w)).length;
    if (score > best.score) best = { rate: def.citRate, sectorName: def.name, score };
  }
  return { rate: best.rate, sectorName: best.sectorName };
}

/** CIT working paper: gross CIT on taxable profit less WHT credits already withheld. */
export function computeCit(profitBeforeTax: number, citRatePct: number, whtCredits: number) {
  const taxableProfit = Math.max(0, inCents(profitBeforeTax));
  const grossCit = inCents(taxableProfit * citRatePct / 100);
  const netPayable = inCents(Math.max(0, grossCit - Math.max(0, whtCredits)));
  return { taxableProfit, citRatePct, grossCit, whtCredits: Math.max(0, inCents(whtCredits)), netPayable };
}

export interface FxRevaluationRow {
  accountNo: string;
  accountName: string;
  fcyBalance: number;
  bookRate: number;
  closingRate: number;
  revaluedGhs: number;
  gainLoss: number; // positive = gain
}

/**
 * IAS 21 unrealised FX revaluation of foreign-currency monetary items in the journal.
 * gain/loss (GHS) = FCY net balance x (closing rate - book rate).
 */
/**
 * IAS 21.23: only MONETARY items are retranslated at the closing rate. Property,
 * plant and equipment (13xxxx), inventories (12xxxx), right-of-use and intangible
 * assets (15xxxx), equity and the income statement are measured at historical
 * cost or fair value and are never retranslated — an "unrealised FX gain" booked
 * to PPE cost is a misstatement, not a valuation. Unknown accounts are skipped:
 * the engine must never invent a revaluation on an account it cannot classify.
 */
const FX_NON_MONETARY_TYPES = new Set(['Income', 'Expense', 'Equity']);
const FX_NON_MONETARY_PREFIXES = ['12', '13', '15'];
export function isMonetaryForFx(account: AccountMaster | undefined): boolean {
  if (!account) return false;
  if (FX_NON_MONETARY_TYPES.has(account.type)) return false;
  if (FX_NON_MONETARY_PREFIXES.includes(account.accountNo.slice(0, 2))) return false;
  return account.type === 'Asset' || account.type === 'Liability';
}

export function buildFxRevaluation(
  lines: ACDOCALine[],
  accounts: AccountMaster[],
  ccy: string,
  bookRate: number,
  closingRate: number
): FxRevaluationRow[] {
  const fcyLines = lines.filter((l) => l.currency === ccy);
  const byAccount = new Map<string, number>();
  for (const l of fcyLines) {
    if (!isMonetaryForFx(accounts.find((a) => a.accountNo === l.accountNo))) continue;
    byAccount.set(l.accountNo, inCents((byAccount.get(l.accountNo) ?? 0) + l.debit - l.credit));
  }
  const rows: FxRevaluationRow[] = [];
  for (const [accountNo, fcyBalance] of [...byAccount.entries()].sort()) {
    if (Math.abs(fcyBalance) < 0.005) continue;
    const gainLoss = inCents(fcyBalance * (closingRate - bookRate));
    rows.push({
      accountNo,
      accountName: accounts.find((a) => a.accountNo === accountNo)?.name || accountNo,
      fcyBalance,
      bookRate,
      closingRate,
      revaluedGhs: inCents(fcyBalance * closingRate),
      gainLoss,
    });
  }
  return rows;
}

/**
 * A NORMALISED bank statement line.
 *
 * `debit` is always money OUT of the account and `credit` always money IN,
 * regardless of how the source file labelled its columns. That normalisation is
 * what lets the matcher below reason about direction at all: on the treasury GL
 * (an asset) money out is a CREDIT and money in is a DEBIT, so a statement debit
 * must be matched to a journal CREDIT, not a journal debit. Matching
 * "statement debit → journal debit" — which is what this module used to do —
 * paired every withdrawal with a deposit and left genuine items unmatched.
 */
export interface StatementLine {
  date: string;
  description: string;
  /** Money OUT of the account. */
  debit: number;
  /** Money INTO the account. */
  credit: number;
  /** Running balance when the statement carries one. */
  balance?: number;
  /** Document / reference number when the statement carries one. */
  reference?: string;
  /** 1-based source row number, for the exception queue and audit trail. */
  row?: number;
}

export interface StatementMatchResult {
  line: StatementLine;
  matched: boolean;
  matchedDocNo?: string;
  /** Days between the statement value date and the matched posting (0 when unmatched). */
  days?: number;
  /** Net cash effect: positive = money into the account. */
  net: number;
}

/**
 * Which way round the SOURCE file writes its amount columns. The import
 * normalises to `debit` = money out, so this only affects parsing.
 */
export type StatementConvention = 'debit-is-out' | 'debit-is-in';

export interface StatementImportReport {
  lines: StatementLine[];
  /** Data rows seen, matched or not. */
  totalRows: number;
  /** Rows the parser could not use, with a reason. */
  skippedRows: number;
  skippedSamples: string[];
  delimiter: string;
  headerDetected: boolean;
  columns: { date: number; description: number; debit: number; credit: number; amount: number; balance: number; reference: number };
  convention: StatementConvention;
  /** Total money out / money in / net movement across the imported file. */
  totals: { out: number; in: number; net: number };
  warnings: string[];
}

const monthIndex: Record<string, number> = {
  jan: 1, january: 1, feb: 2, february: 2, mar: 3, march: 3, apr: 4, april: 4,
  may: 5, jun: 6, june: 6, jul: 7, july: 7, aug: 8, august: 8, sep: 9, sept: 9,
  september: 9, oct: 10, october: 10, nov: 11, november: 11, dec: 12, december: 12,
};

const pad2 = (n: number) => String(n).padStart(2, '0');

/**
 * Parses the date formats real banks export, and returns `YYYY-MM-DD`.
 *
 * The previous parser accepted `YYYY-MM-DD` and nothing else, so every statement
 * from a Ghanaian bank (`12/03/2026`, `12-03-2026`, `12 MAR 2026`) parsed to zero
 * rows and the import reported "No valid statement lines found".
 */
export function parseStatementDate(raw: string): string | null {
  const v = String(raw || '').trim().replace(/^"|"$/g, '');
  if (!v) return null;
  let m: RegExpMatchArray | null;

  // ISO: 2026-03-12 / 2026/03/12
  if ((m = v.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/))) {
    return iso(+m[1], +m[2], +m[3]);
  }
  // 12 Mar 2026 / 12-Mar-26 / 12 MAR 26
  if ((m = v.match(/^(\d{1,2})[-/.\s]+([A-Za-z]{3,9})[-/.\s]+(\d{2,4})$/))) {
    const mm = monthIndex[m[2].toLowerCase()];
    if (mm) return iso(shortYear(+m[3]), mm, +m[1]);
  }
  // Mar 12, 2026 / March 12 2026
  if ((m = v.match(/^([A-Za-z]{3,9})[-/.\s]+(\d{1,2})(?:st|nd|rd|th)?[-/.\s,]+(\d{2,4})$/))) {
    const mm = monthIndex[m[1].toLowerCase()];
    if (mm) return iso(shortYear(+m[3]), mm, +m[2]);
  }
  // Numeric with separators: 12/03/2026, 12-03-26, 12.03.2026
  if ((m = v.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$/))) {
    const a = +m[1];
    const b = +m[2];
    const y = shortYear(+m[3]);
    // The first component is the day unless it cannot be (e.g. 13/03) or the
    // second one cannot be a month (e.g. 03/25 — US month/day). Ambiguous
    // values such as 03/04/2026 are read day-first, which is the convention in
    // every market this system serves.
    if (a > 12 && b <= 12) return iso(y, b, a);
    if (b > 12 && a <= 12) return iso(y, a, b);
    return iso(y, b, a);
  }
  return null;

  function shortYear(y: number): number {
    return y < 100 ? (y < 70 ? 2000 + y : 1900 + y) : y;
  }
  function iso(y: number, mo: number, d: number): string | null {
    if (!(y >= 1900 && y <= 2999) || !(mo >= 1 && mo <= 12) || !(d >= 1 && d <= 31)) return null;
    return `${y}-${pad2(mo)}-${pad2(d)}`;
  }
}

/**
 * Parses an amount cell: `GHS 1,234.50`, `1.234,56`, `(450.00)`, `450.00-`,
 * `1 234,56`, `₵2,000`, blank. Returns null when the cell is not numeric at all.
 */
export function parseStatementAmount(raw: string): number | null {
  let v = String(raw ?? '').trim();
  if (!v) return 0;
  let negative = false;
  if (/^\(.*\)$/.test(v)) { negative = true; v = v.slice(1, -1); }
  if (/-$/.test(v)) { negative = true; v = v.slice(0, -1); }
  if (/^-/.test(v)) { negative = true; v = v.slice(1); }
  // Strip currency codes/symbols, letters, spaces and NBSP, keeping digits + separators.
  v = v.replace(/(?:GHS|GH₵|GHC|USD|EUR|GBP|NGN|ZAR|KES|NGN|TZS|XOF|XAF|AUD|CAD|JPY|CHF)/gi, '')
       .replace(/[^\d.,-]/g, '')
       .trim();
  if (!v || v === '-' || v === '.') return null;
  const lastDot = v.lastIndexOf('.');
  const lastComma = v.lastIndexOf(',');
  if (lastDot > -1 && lastComma > -1) {
    // Both present: the right-most one is the decimal separator.
    if (lastComma > lastDot) v = v.replace(/\./g, '').replace(',', '.');
    else v = v.replace(/,/g, '');
  } else if (lastComma > -1) {
    // Comma only: decimal separator when it looks like one, thousands otherwise.
    v = /^-?\d{1,3}(,\d{3})+$/.test(v) ? v.replace(/,/g, '') : v.replace(',', '.');
  } else if (lastDot > -1 && /^-?\d{1,3}(\.\d{3})+$/.test(v) && !/^\d+\.\d{2}$/.test(v)) {
    v = v.replace(/\./g, ''); // 1.234.567
  }
  const n = Number(v);
  if (!Number.isFinite(n)) return null;
  return negative ? -n : n;
}

const HEADER_ALIASES: Record<keyof StatementImportReport['columns'], string[]> = {
  date: ['date', 'value date', 'valuedate', 'transaction date', 'txn date', 'posting date', 'posted date', 'booked'],
  description: ['description', 'details', 'detail', 'narrative', 'narration', 'remarks', 'memo', 'transaction', 'particulars', 'info'],
  debit: ['debit', 'withdrawal', 'withdrawals', 'money out', 'paid out', 'out', 'dr', 'debits', 'withdrawal amount'],
  credit: ['credit', 'deposit', 'deposits', 'money in', 'paid in', 'in', 'cr', 'credits', 'deposit amount'],
  amount: ['amount', 'value', 'transaction amount', 'amt', 'sum'],
  balance: ['balance', 'running balance', 'closing balance', 'book balance', 'available balance'],
  reference: ['reference', 'ref', 'cheque', 'check', 'cheque no', 'transaction id', 'txn id', 'voucher', 'doc no'],
};

const TOTALS_ROW = /^\s*(total|totals|subtotal|opening balance|closing balance|brought forward|carried forward|balance b\/f|balance c\/f|b\/f|c\/f|run(?:ning)? balance)\b/i;

/** Splits CSV/TSV text into rows, honouring double-quoted fields and escaped quotes. */
function splitDelimited(text: string, delimiter: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const c = text[i];
    if (quoted) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i += 1; } else quoted = false;
      } else field += c;
      continue;
    }
    if (c === '"') { quoted = true; continue; }
    if (c === delimiter) { row.push(field); field = ''; continue; }
    if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i += 1;
      row.push(field); field = '';
      if (row.some((f) => f.trim() !== '')) rows.push(row);
      row = [];
      continue;
    }
    field += c;
  }
  row.push(field);
  if (row.some((f) => f.trim() !== '')) rows.push(row);
  return rows;
}

/** Picks the delimiter by counting candidates outside quotes on the first line. */
function detectDelimiter(text: string): string {
  const firstLine = text.split(/\r?\n/).find((l) => l.trim()) ?? '';
  const outside = firstLine.replace(/"[^"]*"/g, '');
  const candidates = [',', ';', '\t', '|'];
  let best = ',';
  let bestCount = 0;
  for (const d of candidates) {
    const count = outside.split(d).length - 1;
    if (count > bestCount) { best = d; bestCount = count; }
  }
  return best;
}

function normaliseHeader(value: string): string {
  return String(value || '').replace(/^"|"$/g, '').trim().toLowerCase().replace(/[_-]+/g, ' ').replace(/\s+/g, ' ');
}

/**
 * Parses a bank statement file (CSV / TSV / semicolon- or pipe-delimited text)
 * into normalised statement lines.
 *
 * Handles what real exports actually contain: quoted fields with embedded
 * separators, header rows in several wordings, `DD/MM/YYYY` and `12 MAR 2026`
 * dates, thousands separators, currency symbols, bracketed negatives, a single
 * signed `Amount` column instead of separate Debit/Credit columns, and
 * totals/footer rows that must not be imported as transactions.
 */
export function parseStatementReport(
  text: string,
  options: { convention?: StatementConvention } = {},
): StatementImportReport {
  const convention: StatementConvention = options.convention ?? 'debit-is-out';
  const warnings: string[] = [];
  const delimiter = detectDelimiter(text);
  const rows = splitDelimited(text, delimiter);
  const columns: StatementImportReport['columns'] = {
    date: -1, description: -1, debit: -1, credit: -1, amount: -1, balance: -1, reference: -1,
  };

  // Find the header row and map columns by name.
  let headerIndex = -1;
  for (let r = 0; r < Math.min(rows.length, 15); r += 1) {
    const cells = rows[r].map(normaliseHeader);
    let hits = 0;
    for (const key of Object.keys(HEADER_ALIASES) as (keyof StatementImportReport['columns'])[]) {
      const at = cells.findIndex((c) => c && HEADER_ALIASES[key].includes(c));
      if (at > -1) { columns[key] = at; hits += 1; }
    }
    if (hits >= 2) { headerIndex = r; break; }
    for (const key of Object.keys(columns) as (keyof StatementImportReport['columns'])[]) columns[key] = -1;
  }
  const headerDetected = headerIndex > -1;

  // No usable header: fall back to the documented positional layout
  // Date, Description, Debit, Credit — then Date, Description, Amount.
  if (!headerDetected) {
    columns.date = 0;
    columns.description = 1;
    const width = Math.max(...rows.slice(0, 5).map((r) => r.length), 0);
    if (width >= 4) { columns.debit = 2; columns.credit = 3; }
    else columns.amount = 2;
    warnings.push('No header row was recognised, so columns were read positionally as Date, Description, Debit, Credit. Add a header row to the file to be certain.');
  }
  if (columns.date < 0) {
    return {
      ...emptyReport(), delimiter, headerDetected, columns, convention,
      warnings: [...warnings, 'No date column could be identified. The file needs a "Date" column (also accepted: "Value Date", "Transaction Date").'],
    };
  }
  if (columns.debit < 0 && columns.credit < 0 && columns.amount < 0) {
    return {
      ...emptyReport(), delimiter, headerDetected, columns, convention,
      warnings: [...warnings, 'No amount column could be identified. Add a Debit/Credit pair or a single "Amount" column.'],
    };
  }

  const lines: StatementLine[] = [];
  const skippedSamples: string[] = [];
  let totalRows = 0;
  let skippedRows = 0;

  for (let r = headerIndex + 1; r < rows.length; r += 1) {
    const cells = rows[r];
    const rawRow = cells.join(delimiter).trim();
    if (!rawRow) continue;
    totalRows += 1;

    const description = (cells[columns.description] ?? '').replace(/^"|"$/g, '').trim();
    const reference = columns.reference > -1 ? (cells[columns.reference] ?? '').trim() : '';
    if (TOTALS_ROW.test(description)) { skippedRows += 1; continue; }

    const date = parseStatementDate(cells[columns.date] ?? '');
    if (!date) {
      skippedRows += 1;
      if (skippedSamples.length < 5) skippedSamples.push(`Row ${r + 1}: unreadable date "${(cells[columns.date] ?? '').slice(0, 24)}"`);
      continue;
    }

    let out = 0;
    let inn = 0;
    if (columns.amount > -1) {
      const amount = parseStatementAmount(cells[columns.amount] ?? '');
      if (amount == null) {
        skippedRows += 1;
        if (skippedSamples.length < 5) skippedSamples.push(`Row ${r + 1}: unreadable amount "${(cells[columns.amount] ?? '').slice(0, 24)}"`);
        continue;
      }
      // A signed amount column: money leaving the account is negative.
      if (amount < 0) out = -amount; else inn = amount;
      if (convention === 'debit-is-in') { const t = out; out = inn; inn = t; }
    } else {
      const drRaw = parseStatementAmount(cells[columns.debit] ?? '');
      const crRaw = parseStatementAmount(cells[columns.credit] ?? '');
      if (drRaw == null || crRaw == null) {
        skippedRows += 1;
        if (skippedSamples.length < 5) skippedSamples.push(`Row ${r + 1}: unreadable debit/credit amount`);
        continue;
      }
      // Columns are labelled, so they are authoritative — but a bank that labels
      // its outflow column "Debit" and another that labels the inflow column
      // "Debit" are both common. `convention` decides which reading to trust.
      out = Math.abs(drRaw);
      inn = Math.abs(crRaw);
      if (convention === 'debit-is-in') { const t = out; out = inn; inn = t; }
    }

    if (out === 0 && inn === 0) {
      // A zero-value row is only meaningful if the statement carries balances.
      if (columns.balance < 0) { skippedRows += 1; continue; }
    }

    const balance = columns.balance > -1 ? (parseStatementAmount(cells[columns.balance] ?? '') ?? undefined) : undefined;
    lines.push({ date, description: description || reference || '(no description)', debit: out, credit: inn, balance, reference: reference || undefined, row: r + 1 });
  }

  const totals = lines.reduce(
    (acc, l) => ({ out: acc.out + l.debit, in: acc.in + l.credit, net: acc.net + l.credit - l.debit }),
    { out: 0, in: 0, net: 0 },
  );
  totals.out = Math.round(totals.out * 100) / 100;
  totals.in = Math.round(totals.in * 100) / 100;
  totals.net = Math.round(totals.net * 100) / 100;

  if (!lines.length) warnings.push('No transaction rows could be read from this file. Check that it is a CSV/TSV export and not a scanned PDF or an Excel workbook.');
  if (convention === 'debit-is-in') warnings.push('Reading "Debit" as money IN. Switch the convention back if that is not how this bank labels its columns.');

  return { lines, totalRows, skippedRows, skippedSamples, delimiter, headerDetected, columns, convention, totals, warnings };

  function emptyReport(): Omit<StatementImportReport, 'delimiter' | 'headerDetected' | 'columns' | 'convention' | 'warnings'> {
    return { lines: [], totalRows: 0, skippedRows: 0, skippedSamples: [], totals: { out: 0, in: 0, net: 0 } };
  }
}

/** Convenience wrapper returning only the normalised lines. */
export function parseStatementCsv(text: string, options: { convention?: StatementConvention } = {}): StatementLine[] {
  return parseStatementReport(text, options).lines;
}

/**
 * Matches imported bank statement lines to posted journal cash lines.
 *
 * Direction is derived from the treasury GL, which is an asset: money leaving the
 * bank account CREDITS the GL, money entering it DEBITS the GL. Each statement
 * line is therefore matched to a journal line of the OPPOSITE sign on the same
 * GL account, with the same amount, preferring the closest value date within a
 * 5-day window (banks post a day or two either side of the statement value date).
 */
export function matchStatementLines(
  statement: StatementLine[],
  journalLines: ACDOCALine[],
  glAccount: string,
  windowDays = 5,
): StatementMatchResult[] {
  const pool = journalLines.filter((l) => l.accountNo === glAccount && !l.isReversed
    && ((Number(l.debit) || 0) > 0 || (Number(l.credit) || 0) > 0));
  const used = new Set<string>();
  return statement.map((s) => {
    const moneyOut = (s.debit || 0) > 0 || (s.credit || 0) === 0;
    const stmtAmount = Math.abs(moneyOut ? (s.debit || 0) - (s.credit || 0) : (s.credit || 0) - (s.debit || 0));
    // Money out of the bank credits the treasury GL; money in debits it.
    const journalSide = moneyOut ? 'credit' : 'debit';

    let hit: ACDOCALine | undefined;
    let bestDays = Number.POSITIVE_INFINITY;
    const stmtTime = Date.parse(`${s.date}T00:00:00.000Z`);
    for (const l of pool) {
      if (used.has(l.id)) continue;
      const amount = Number(l[journalSide]) || 0;
      if (Math.abs(Math.abs(amount) - stmtAmount) > 0.009) continue;
      const days = Math.abs(stmtTime - Date.parse(`${l.date}T00:00:00.000Z`)) / dayMs;
      if (days > windowDays) continue;
      if (days < bestDays) { bestDays = days; hit = l; }
    }
    if (hit) used.add(hit.id);
    return {
      line: s,
      matched: !!hit,
      matchedDocNo: hit?.docNo,
      days: hit ? Math.round(bestDays) : undefined,
      net: Math.round(((s.credit || 0) - (s.debit || 0)) * 100) / 100,
    };
  });
}

/** Builds the balanced disposal journal for a fixed asset (IAS 16 derecognition). */
export function buildDisposalEntries(
  asset: { assetTag: string; name: string; cost: number; accumDep: number },
  proceeds: number,
  date: string,
  currency: string,
  clientId: number,
  createdBy: string
): ACDOCALine[] {
  const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
  const period = date.slice(0, 7);
  const docNo = `DISP-${asset.assetTag}-${docSuffix()}`;
  const nbv = round2(asset.cost - asset.accumDep);
  const gain = round2(proceeds - nbv);
  const entries: ACDOCALine[] = [
    { id: `${uniqueId('JL-DISP')}-1`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '100000', accountName: 'Cash at Bank (Operating)', costCenter: 'CC-OPS', debit: round2(proceeds), credit: 0, currency, description: `Disposal proceeds ${asset.assetTag}`, createdBy, clientId },
    { id: `${uniqueId('JL-DISP')}-2`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '130000', accountName: `PPE — ${asset.name}`, costCenter: 'CC-OPS', debit: 0, credit: round2(asset.cost), currency, description: `Cost of disposed asset ${asset.assetTag}`, createdBy, clientId },
  ];
  if (asset.accumDep > 0) entries.push({ id: `${uniqueId('JL-DISP')}-3`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '139000', accountName: 'Accumulated Depreciation — PPE', costCenter: 'CC-OPS', debit: round2(asset.accumDep), credit: 0, currency, description: `Accumulated depreciation reversal ${asset.assetTag}`, createdBy, clientId });
  if (gain > 0) entries.push({ id: `${uniqueId('JL-DISP')}-4`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '492000', accountName: 'Gain on Disposal of PPE', costCenter: 'CC-OPS', debit: 0, credit: gain, currency, description: `Gain on disposal ${asset.assetTag}`, createdBy, clientId });
  if (gain < 0) entries.push({ id: `${uniqueId('JL-DISP')}-4`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '698000', accountName: 'Loss on Disposal of PPE', costCenter: 'CC-OPS', debit: round2(-gain), credit: 0, currency, description: `Loss on disposal ${asset.assetTag}`, createdBy, clientId });
  return entries;
}

/** Builds the balanced debit-note (purchase return) journal reversing a purchase order. */
export function buildDebitNoteEntries(
  po: { poNo: string; vendorName: string; glAccount: string; glAccountName: string; costCenter: string; netAmount?: number; qty: number; unitPrice: number; vatRecoverable: number; totalAmount: number },
  date: string,
  currency: string,
  clientId: number,
  createdBy: string
): ACDOCALine[] {
  const period = date.slice(0, 7);
  const docNo = `DN-${po.poNo.replace('PO-', '')}-${docSuffix()}`;
  const net = po.netAmount ?? Math.round((po.qty * po.unitPrice) * 100) / 100;
  const entries: ACDOCALine[] = [
    { id: `${uniqueId('JL-DN')}-1`, docNo, period, date, module: 'MM', docType: 'REV', accountNo: '200000', accountName: `Trade Payables (${po.vendorName})`, costCenter: po.costCenter, debit: po.totalAmount, credit: 0, currency, description: `Debit note for ${po.poNo} — payable reversal`, createdBy, clientId },
    { id: `${uniqueId('JL-DN')}-2`, docNo, period, date, module: 'MM', docType: 'REV', accountNo: po.glAccount, accountName: po.glAccountName, costCenter: po.costCenter, debit: 0, credit: net, currency, description: `Debit note for ${po.poNo} — ${po.glAccountName} reversal`, createdBy, clientId },
  ];
  if (po.vatRecoverable > 0) entries.push({ id: `${uniqueId('JL-DN')}-3`, docNo, period, date, module: 'MM', docType: 'REV', accountNo: '125000', accountName: 'VAT Input Tax Recoverable', costCenter: po.costCenter, debit: 0, credit: po.vatRecoverable, currency, description: `Input VAT reversal on ${po.poNo}`, createdBy, clientId });
  return entries;
}

export interface CostCentreRow {
  code: string;
  income: number;
  expense: number;
  net: number;
}

export interface CostCentreReport {
  rows: CostCentreRow[];
  totalIncome: number;
  totalExpense: number;
  totalNet: number;
  profit: number;
  residual: number;
}

/** P&L by cost centre for the entity's movement window, derived from posted lines. */
export function buildCostCentreReport(lines: ACDOCALine[], accounts: AccountMaster[], from: string, through: string): CostCentreReport {
  const scoped = lines.filter((l) => l.date >= from && l.date <= through);
  const rows = aggregateTrialBalance(scoped, accounts).filter((r) => r.type === 'Income' || r.type === 'Expense');
  const byCc = new Map<string, CostCentreRow>();
  for (const l of scoped) {
    const type = classifyAccount(accounts, l.accountNo);
    if (type !== 'Income' && type !== 'Expense') continue;
    const code = l.costCenter || 'UNASSIGNED';
    const row = byCc.get(code) ?? { code, income: 0, expense: 0, net: 0 };
    const amount = Math.round((l.credit - l.debit) * 100) / 100;
    if (type === 'Income') row.income = Math.round((row.income + amount) * 100) / 100;
    else row.expense = Math.round((row.expense - amount) * 100) / 100;
    row.net = Math.round((row.income - row.expense) * 100) / 100;
    byCc.set(code, row);
  }
  const sorted = [...byCc.values()].sort((a, b) => a.code.localeCompare(b.code));
  const totalIncome = Math.round(sorted.reduce((n, r) => n + r.income, 0) * 100) / 100;
  const totalExpense = Math.round(sorted.reduce((n, r) => n + r.expense, 0) * 100) / 100;
  const totalNet = Math.round((totalIncome - totalExpense) * 100) / 100;
  const profit = rows.reduce((n, r) => n - (r.dr - r.cr), 0) / 100;
  return { rows: sorted, totalIncome, totalExpense, totalNet, profit, residual: Math.round((totalNet - profit) * 100) / 100 };
}

/** Builds the balanced credit-note (sales return) journal reversing an invoice. */
export function buildCreditNoteEntries(
  inv: { invNo: string; customerName: string; revenueStream: string; netRevenue: number; vatOutput: number; cstAmount?: number; tourismLevyAmount?: number; totalReceivable: number },
  date: string,
  currency: string,
  clientId: number,
  createdBy: string
): ACDOCALine[] {
  const period = date.slice(0, 7);
  const docNo = `CN-${inv.invNo.replace('INV-', '')}-${docSuffix()}`;
  const entries: ACDOCALine[] = [
    { id: `${uniqueId('JL-CN')}-1`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '400000', accountName: 'Revenue from Contracts with Customers', costCenter: 'CC-SLS', debit: inv.netRevenue, credit: 0, currency, description: `Credit note for ${inv.invNo} — revenue reversal`, createdBy, clientId },
    { id: `${uniqueId('JL-CN')}-2`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '110000', accountName: `Trade Receivables (${inv.customerName})`, costCenter: 'CC-SLS', debit: 0, credit: inv.totalReceivable, currency, description: `Credit note for ${inv.invNo} (${inv.revenueStream})`, createdBy, clientId },
  ];
  if (inv.vatOutput > 0) entries.push({ id: `${uniqueId('JL-CN')}-3`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '220000', accountName: 'VAT/NHIL/GETFund Output Liability', costCenter: 'CC-SLS', debit: inv.vatOutput, credit: 0, currency, description: `Output VAT reversal on ${inv.invNo}`, createdBy, clientId });
  if ((inv.cstAmount || 0) > 0) entries.push({ id: `${uniqueId('JL-CN')}-4`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '223000', accountName: 'Communication Service Tax Payable', costCenter: 'CC-SLS', debit: inv.cstAmount || 0, credit: 0, currency, description: `CST reversal on ${inv.invNo}`, createdBy, clientId });
  if ((inv.tourismLevyAmount || 0) > 0) entries.push({ id: `${uniqueId('JL-CN')}-5`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '224000', accountName: 'Tourism Levy Payable', costCenter: 'CC-SLS', debit: inv.tourismLevyAmount || 0, credit: 0, currency, description: `Tourism levy reversal on ${inv.invNo}`, createdBy, clientId });
  return entries;
}

/** Parses a bank statement CSV: Date,Description,Debit,Credit (header optional). */


/**
 * IAS 21 exposure measured from the REGISTERS, not from ledger lines.
 *
 * The ledger is kept in the entity's functional currency (foreign documents are
 * translated at posting), so a revaluation computed from `journal_lines` would
 * always be empty. Monetary exposure lives in the operational registers instead:
 * foreign-currency bank/wallet balances, open customer receivables and open
 * supplier payables. Non-monetary items (inventory, PPE, equity) are excluded —
 * they are measured at historical cost and are never retranslated (IAS 21.23).
 */
export function fxExposureFromRegisters(input: {
  clientId: number;
  currency: string;
  bookRate: number;
  closingRate: number;
  bankAccounts: readonly { clientId?: number | null; currency: string; glAccount?: string | null; kind?: string | null; name: string; balance: number }[];
  invoices: readonly { clientId?: number | null; currency?: string | null; totalReceivable: number; paidAmount?: number; status: string; invNo: string }[];
  purchaseOrders: readonly { clientId?: number | null; currency?: string | null; totalAmount: number; paidAmount?: number; status: string; poNo: string }[];
}): FxRevaluationRow[] {
  const ccy = input.currency.toUpperCase();
  // Rate movement per one unit of foreign currency. (This used to be written
  // `(closingRate - bookRate) / 100 ** 0` — a division by 1 that read as if the
  // difference were being converted to a percentage and hid the arithmetic.)
  const fx = input.closingRate - input.bookRate;
  const rows: FxRevaluationRow[] = [];
  const push = (accountNo: string, accountName: string, fcyBalance: number) => {
    if (Math.abs(fcyBalance) < 0.005) return;
    rows.push({
      accountNo,
      accountName,
      fcyBalance: inCents(fcyBalance),
      bookRate: input.bookRate,
      closingRate: input.closingRate,
      revaluedGhs: inCents(fcyBalance * input.closingRate),
      gainLoss: inCents(fcyBalance * fx),
    });
  };
  for (const bank of input.bankAccounts) {
    if ((bank.clientId ?? input.clientId) !== input.clientId) continue;
    if (String(bank.currency).toUpperCase() !== ccy) continue;
    push(bank.glAccount || (bank.kind === 'cash' ? '102000' : '100000'), `Treasury — ${bank.name}`, bank.balance);
  }
  const openInvoices = input.invoices.filter((i) => (i.clientId ?? input.clientId) === input.clientId
    && String(i.currency ?? '').toUpperCase() === ccy && i.status !== 'Draft' && i.status !== 'Credited');
  push('110000', `Trade receivables (${openInvoices.length} open invoice${openInvoices.length === 1 ? '' : 's'})`,
    openInvoices.reduce((s, i) => s + (i.totalReceivable - (i.paidAmount ?? 0)), 0));
  const openOrders = input.purchaseOrders.filter((o) => (o.clientId ?? input.clientId) === input.clientId
    && String(o.currency ?? '').toUpperCase() === ccy && o.status !== 'Debited');
  push('200000', `Trade payables (${openOrders.length} open bill${openOrders.length === 1 ? '' : 's'})`,
    -openOrders.reduce((s, o) => s + (o.totalAmount - (o.paidAmount ?? 0)), 0));
  return rows;
}
