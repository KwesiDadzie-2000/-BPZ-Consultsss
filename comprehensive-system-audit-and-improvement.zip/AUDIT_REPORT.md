# BPZ Consult ERP — Independent System Audit & Remediation Report

**Scope.** Latest snapshot in `KwesiDadzie-2000/-BPZ-Consultsss` (`new-chat (1).zip`, 29 Oct 2026, 144 files / ~37k LOC).
The original repository and its archives were **not modified**; the snapshot was imported into this workspace, audited, tested and remediated here.

**Frameworks applied.** IFRS (IAS 1, IAS 8, IAS 19, IFRS 15), ISA 315/330 (controls), COSO/ITGC (SoD, access, change),
OWASP ASVS, Ghana statute — VAT Act 2025 (Act 1151), Income Tax Act 2015 (Act 896) as amended by Act 1007 / Act 1094 / Act 1178,
SSNIT Act 766, CST Act 754, Tourism Act 817.

**Method.** Static review (TypeScript, ESLint/React-Compiler), live black-box testing of every API route with crafted
transactions, numerical re-performance of the tax and payroll engines against GRA/SSNIT worked examples, and a
47-case certified sector-transaction suite (`src/tests/sectorTransactions.test.ts`).

---

## 1. Overall critique

| Area | Assessment |
| --- | --- |
| Architecture | Single-page React workspace (`src/App.tsx`, 1.8k lines) with a PostgreSQL ledger. The **browser is authoritative** for most master/operational data via a full-state `POST /api/state` replace — this is the system's chief structural weakness (see §4). The trade (P2P/O2C) engine is correctly **server-authoritative** and is the model the rest should follow. |
| Ledger integrity | Strong fundamentals: minor-unit balancing, idempotent posting events, content hashes, headers, advisory locks, per-entity period freeze, audit log. **But** the posting service trusted client-supplied maker/checker identities — a critical SoD defect (fixed). |
| Tax engine | Already aligned to Act 1151 (VAT/NHIL/GETFund on one base, COVID repealed, CST cascade, Tourism Levy outside base). WHT schedule comprehensive. |
| Payroll | SSNIT model correct (5.5/13, 13.5/5 split, 2026 floor/ceiling). **Defects:** wrong bands for Jan–Aug 2026, non-resident rate 20% (statute 25%), bonus not given 5% final-tax treatment (all fixed). |
| Security | scrypt passwords, HttpOnly cookie sessions, lockout, owner-only admin. Missing baseline HTTP headers (added). Login lockout is per-instance memory (residual). |
| Code quality | tsc clean; 7 ESLint/React-Compiler errors (fixed); several `eslint-disable` dependency suppressions; very large components (`PayrollSection` 1.5k, `ComprehensiveStandardsDesk` 1.2k). |
| Reference data | Sector WHT guidance (`ghanaSectors.ts`) contradicted Act 896 First Schedule in 17 of 25 sectors and still offered the abolished VAT Flat Rate Scheme (fixed). |

---

## 2. Findings and remediation (by severity)

### CRITICAL
| # | Module | Finding | Evidence | Fix |
| --- | --- | --- | --- | --- |
| C1 | `api/journal`, `api/state` | **Maker-limit bypass.** `validateMakerChecker` only applied when `createdBy === session user`; a caller could stamp any other username as maker and post any amount unchecked. | `demo` (limit 25,000) posted a 90,000 document with `createdBy:"owner"` → HTTP 200. | New `validatePostingIdentity`: the signed-in user must be the maker **or** an authorised checker named on the document. Maker-limit now resolved from the **maker's own** record (`src/lib/journalValidation.ts`, `src/lib/postingControls.ts`). Applied to both posting paths. |
| C2 | `api/journal`, `api/state` | **Unvetted checker.** `checkedBy` accepted any string — a non-existent or suspended user satisfied the "independent checker" rule. | 90,000 document with `checkedBy:"ghost"` → HTTP 200. | Checker must exist, be `active`, and have `canCheck` or be owner. |

### HIGH
| # | Module | Finding | Fix |
| --- | --- | --- | --- |
| H1 | Payroll | PAYE for periods **Jan–Aug 2026** fell back to Act 1178 bands (first GHS 588) although Act 1178 only took effect 1 Sep 2026 — every pre-September payslip under-taxed by up to GHS 6/month and mis-stated PAYE remittances. | Act 1094 bands added (`PAYE_BANDS_ACT_1094`), date-aware selection and fallback, settings-store v1→v2 migration preserving user edits. |
| H2 | Payroll | Non-resident employees taxed at **20%**; statute is **25%** (Act 1007). | `NON_RESIDENT_PAYE_RATE = 25`. |
| H3 | Payroll | Bonuses taxed at graduated rates; Act 896 s.6 requires **5% final tax** on bonus ≤ 15% of annual basic, excess to graduated. | `splitQualifyingBonus()`; `bonusFinalTax` / `qualifyingBonus` carried on the record; PAYE remittance includes the final tax. |
| H4 | Posting service | Document-integrity gaps: invalid dates ("garbage", 30-Feb) accepted; mixed currencies / periods / dates in one document accepted; a single line with both Dr and Cr accepted; zero-value lines accepted; one-line documents accepted. | All rejected server-side with specific messages; mirrored client-side. |
| H5 | Posting service | Inactive accounts and other entities' tailored accounts were postable (COA check was existence-only, firm-wide). | `accountPostabilityFor()` — active + entity-scoped. |
| H6 | Client (`App.tsx`) | On HTTP 403 the browser **kept** the rejected document locally ("posted locally but not synced"), desynchronising the local ledger from the ledger of record. | 403 now rolls back local lines and settlement side-effects exactly like 409. |

### MEDIUM
| # | Module | Finding | Fix |
| --- | --- | --- | --- |
| M1 | Sector data | 17 sector WHT notes wrong (e.g. goods 7.5% vs statutory 3%; professional fees 15% vs 7.5%; foreign SaaS 15% vs 20%). Abolished "Flat 3% + 1%" VAT scheme still a type option. | Corrected to Act 896 First Schedule; scheme retired. |
| M2 | HTTP | No security headers; `X-Powered-By` exposed; API cacheability relied on per-route headers. | `next.config.ts`: nosniff, Referrer-Policy, Permissions-Policy, `poweredByHeader:false`, `Cache-Control: no-store` for `/api/*`. |
| M3 | Code | 7 lint errors incl. two "setState in effect" cascades (`tradeClient`, `TradeShared`) and memoisation the React Compiler could not preserve (`TaxSchedulesSection`). | Refactored (render-time key swap; keyed audit cache; compiler memoisation). |

### LOW / OBSERVATIONS
* Login lockout counter is in-process memory — resets on restart and is per instance.
* `handleAddJournalLines` returns `false` without a reason; callers show generic messages.
* Payroll currency switches for GB/US employees, but the Ghana statutory engine still runs — multi-jurisdiction payroll is not truly supported.
* Very large components hamper review and testing.

---

## 3. Module-by-module audit

| Module | Status | Notes |
| --- | --- | --- |
| Authentication / sessions (`lib/auth`, `api/auth/*`) | ✅ Sound | scrypt+salt, legacy rehash, 256-bit tokens, sliding 8h sessions, HttpOnly cookie + Bearer fallback, no-store responses, 5-strike lockout. |
| User administration (`api/users`) | ✅ Sound | Owner-only, password policy enforced server-side, sanitised user objects. |
| Bootstrap / provisioning (`db/bootstrap`) | ✅ Sound | Idempotent DDL + seed under advisory lock. |
| General ledger posting (`api/journal`) | ⚠️→✅ | C1, C2, H4, H5 fixed. Idempotency / replay / conflict controls verified live. |
| Full-state sync (`api/state`) | ⚠️ | Fresh documents now face identical controls. Architectural concern remains (§4). |
| Trade engine P2P/O2C (`lib/tradeService`) | ✅ Sound | Period freeze, balanced functional-currency postings, version-bound approval, maker cannot approve own doc, payment limits, reservation checks. |
| Tax configuration (`utils/taxConfig`, `lib/taxEngine`) | ✅ Sound | Act 1151 regime correct; now versioned with historical PAYE bands. |
| Sales / VAT output (`SalesSection`, `computeOutputLevies`) | ✅ Verified | Mining, telecom (CST cascade), hospitality (tourism outside base) cases pass. |
| Procurement / AP settlement (`transactionMath`) | ✅ Verified | WHT/VAT-WHT proration on part-payments, over-payment refusal. |
| Receivables / customer VAT withholding | ✅ Verified | Full and split receipts capture withheld VAT exactly. |
| Payroll (`utils/payrollCalculator`) | ⚠️→✅ | H1–H3 fixed; re-performed against GRA worked example (GHS 12,000 → PAYE 2,439.50). |
| Fixed assets / prepayments / adjustments / year-end | ✅ Reviewed | Period derived from posting date; reversals and closes generate balanced documents. |
| Reference data (`data/ghanaSectors`) | ⚠️→✅ | M1 fixed. |

---

## 4. Residual architectural risk (recommendation, not remediated here)

`POST /api/state` deletes and re-inserts tenant tables from the browser's copy. Although fresh journal documents are now
validated, a "re-synced document with updated content replaces the one already in the ledger" path exists for documents
the browser believes it already posted. For a ledger of record under ISA 330 / SOX-style ITGC, **posted journals must be
immutable**: migrate the remaining modules to the command-based, server-authoritative pattern already used by the trade
engine, and make `/api/state` a read model only.

---

## 5. Test evidence

* `npx tsx src/tests/sectorTransactions.test.ts` — **47 passed, 0 failed** (mining, agriculture, telecom, hospitality,
  professional services, construction/import, payroll re-performance, posting controls).
* Live API tests (login, session, bootstrap, journal replay/conflict/unbalanced/closed-period/cross-tenant, trade, audit,
  users) — all behave as specified after remediation; C1/C2 reproductions now return 403/409.
* `tsc --noEmit`, `eslint src`, `next build` — clean.
