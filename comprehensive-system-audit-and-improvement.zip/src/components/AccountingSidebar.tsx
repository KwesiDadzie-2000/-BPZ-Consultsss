import React from 'react';
import { ClientEntity, UserAccount } from '../types/accounting';
import { maySeeSection } from '../utils/access';
import {
  LayoutDashboard,
  ShoppingCart,
  Tag,
  Users,
  CreditCard,
  Building,
  ShieldCheck,
  Boxes,
  Truck,
  FileSpreadsheet,
  BookOpen,
  PieChart,
  CalendarCheck,
  Briefcase,
  Layers,
  Globe,
  Radio,
  Server,
  Lock,
  Calculator,
  Settings,
  Scale,
  ShieldAlert,
} from 'lucide-react';

interface AccountingSidebarProps {
  activeSection: string;
  onSelectSection: (section: string) => void;
  currentClient: ClientEntity;
  currentUser: UserAccount;
  /** Phones/tablets: the menu is an off-canvas drawer. */
  mobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const AccountingSidebar: React.FC<AccountingSidebarProps> = ({
  activeSection,
  onSelectSection,
  currentClient,
  currentUser,
  mobileOpen = false,
  onCloseMobile,
}) => {
  const isOwner = currentUser.role === 'owner';

  // Base client accounting groups (shown to ALL clients & staff)
  const clientGroups = [
    {
      name: 'Overview',
      items: [
        { id: 'dashboard', label: 'Command Center', icon: LayoutDashboard, code: 'HQ' },
        { id: 'company_profile', label: 'Company Profile & Backup', icon: Settings, code: 'SET' },
        { id: 'opening_balance', label: 'Opening Balances Setup', icon: Scale, code: 'OPN' },
      ],
    },
    {
      name: 'Operations (Day-to-Day Accounting)',
      items: [
        { id: 'procurement', label: 'Procurement & P2P (MM)', icon: ShoppingCart, code: 'MM' },
        { id: 'sales', label: 'Sales & Invoicing · O2C (SD)', icon: Tag, code: 'SD' },
        { id: 'business_partners', label: 'Suppliers & Customers', icon: Users, code: 'BP' },
        { id: 'payroll', label: 'Payroll Desk (HR)', icon: Users, code: 'HR' },
        { id: 'payment_desk', label: 'Payment Desk', icon: CreditCard, code: 'PMT' },
        { id: 'banking', label: 'Banking & Reconcile', icon: Building, code: 'BANK' },
        { id: 'expenses', label: 'Expenses & Statutory', icon: ShieldCheck, code: 'EXP' },
        { id: 'inventory', label: 'Inventory & Stock', icon: Boxes, code: 'INV' },
        { id: 'assets', label: 'Fixed Assets Register', icon: Truck, code: 'AA' },
        { id: 'prepayments', label: 'Prepayments & Deferrals', icon: CalendarCheck, code: 'PRE' },
      ],
    },
    {
      name: 'IFRS & Accounting Standards',
      items: [
        { id: 'ifrs_statements', label: 'Financial Statements & IFRS', icon: FileSpreadsheet, code: 'IAS1' },
        { id: 'standards_desk', label: 'IFRS / IAS Standards Desk', icon: Layers, code: 'STD' },
        { id: 'loans_desk', label: 'Loan Amortisation Schedules', icon: Calculator, code: 'FIN' },
        { id: 'disclosures', label: 'Notes to Accounts', icon: FileSpreadsheet, code: 'NTS' },
        { id: 'compliance_review', label: 'Compliance Review & Gaps', icon: ShieldAlert, code: 'AUD' },
      ],
    },
    {
      name: 'Finance & Ledger',
      items: [
        { id: 'coa_master', label: 'Chart of Accounts Master', icon: BookOpen, code: 'COA' },
        { id: 'general_ledger', label: 'General Ledger', icon: BookOpen, code: 'GL' },
        { id: 'universal_journal', label: 'Universal Journal', icon: BookOpen, code: 'ACDOCA' },
        { id: 'manual_journal', label: 'Manual Journal Entry', icon: CreditCard, code: 'FI' },
        { id: 'adjustments', label: 'Adjustment of Accounts', icon: Scale, code: 'ADJ' },
        { id: 'tax_schedules', label: 'WHT & VAT Schedules', icon: ShieldCheck, code: 'SCH' },
        { id: 'tax_schedule', label: 'Tax & Statutory Returns', icon: ShieldCheck, code: 'TAX' },
        { id: 'month_end', label: 'Month-End Close', icon: CalendarCheck, code: 'MCC' },
      ],
    },
  ];

  // Owner/Firm Practice & Enterprise Administration groups (strictly PRIVATE to Owner)
  const ownerGroups = [
    {
      name: 'Firm Practice & Clients (Owner Only)',
      items: [
        { id: 'clients_management', label: 'Client Workspaces', icon: Building, code: 'MGT' },
        { id: 'advisory', label: 'Advisory & Timesheets', icon: Briefcase, code: 'AD' },
        { id: 'group_consolidation', label: 'Group Consolidation', icon: Layers, code: 'IFRS10' },
      ],
    },
    {
      name: 'Enterprise Administration (Owner Only)',
      items: [
        { id: 'user_permissions', label: 'User Access & Restrictions', icon: ShieldAlert, code: 'GOV' },
        { id: 'enterprise_sso', label: 'Enterprise SSO (SAML/SCIM)', icon: Lock, code: 'SSO' },
        { id: 'tax_settings', label: 'Tax Rates & Levy Settings', icon: Globe, code: 'TAX' },
        { id: 'global_tax', label: 'Global Tax Reference', icon: Globe, code: 'REF' },
        { id: 'soc_dr', label: 'SOC 2 & Disaster Recovery', icon: Server, code: 'SOC2' },
        { id: 'realtime_integrations', label: 'API & Webhooks Hub', icon: Radio, code: 'ENT' },
      ],
    },
  ];

  const visibleGroups = isOwner ? [...clientGroups, ...ownerGroups] : clientGroups;

  return (
    <>
    {/* Backdrop for the mobile drawer */}
    {mobileOpen && (
      <div
        className="fixed inset-0 z-40 bg-black/50 md:hidden"
        onClick={onCloseMobile}
        aria-hidden="true"
      />
    )}
    <aside
      aria-label="Main navigation"
      className={`fixed inset-y-0 left-0 z-50 w-72 max-w-[85vw] transform transition-transform duration-200 md:static md:z-auto md:w-64 lg:w-72 md:max-w-none md:translate-x-0 shrink-0 border-r border-sky-200 bg-[#eef6fc] p-3.5 flex flex-col justify-between overflow-y-auto overscroll-contain ${mobileOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}`}
    >
      <div className="space-y-4">
      <button
        onClick={onCloseMobile}
        aria-label="Close navigation menu"
        className="md:hidden ml-auto block rounded-lg border border-sky-300 bg-white px-3 py-1 text-xs font-bold text-[#082f4f]"
      >
        Close ✕
      </button>
        {/* Workspace Active Card */}
        <div className="rounded-xl border border-sky-300/80 bg-white p-3 shadow-xs">
          <div className="text-[10px] font-bold uppercase tracking-wider text-[#355875]">
            Active Accounting Workspace
          </div>
          <div className="mt-1 flex items-center justify-between">
            <span className="font-bold text-[#082f4f] text-xs truncate max-w-[170px]">
              {currentClient.name}
            </span>
            <span className="font-mono text-xs font-black text-[#855b00]">
              {currentClient.code}
            </span>
          </div>
          <div className="mt-0.5 text-[11px] text-[#2d4f6d] font-mono">
            {currentClient.sector} · {currentClient.currency}
          </div>
        </div>

        {/* Menu Navigation */}
        <nav className="space-y-3.5">
          {visibleGroups.map((g) => (
            <div key={g.name} className="space-y-1">
              <div className="px-2 text-[10px] font-bold uppercase tracking-wider text-[#355875]">
                {g.name}
              </div>
              <div className="space-y-0.5">
                {g.items.filter(item => maySeeSection(currentUser, currentClient, item.id)).map((item) => {
                  const Icon = item.icon;
                  const isActive = activeSection === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => onSelectSection(item.id)}
                      aria-current={isActive ? 'page' : undefined}
                      className={`w-full flex items-center justify-between rounded-lg px-2.5 py-2 md:py-1.5 text-left text-xs font-semibold transition ${
                        isActive
                          ? 'bg-[#082f4f] text-white shadow-xs font-bold'
                          : 'text-[#163653] hover:bg-sky-200/60'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Icon
                          className={`h-4 w-4 shrink-0 ${
                            isActive ? 'text-[#f5b719]' : 'text-[#355875]'
                          }`}
                        />
                        <span className="truncate">{item.label}</span>
                      </div>
                      {item.code && (
                        <span
                          className={`shrink-0 rounded px-1.5 py-0.2 font-mono text-[9.5px] font-bold ${
                            isActive
                              ? 'bg-white/20 text-white'
                              : 'bg-sky-200/60 text-[#355875]'
                          }`}
                        >
                          {item.code}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
      </div>

      {/* User Session Footer */}
      <div className="mt-6 pt-3 border-t border-sky-200 text-xs">
        <div className="flex items-center justify-between">
          <div className="truncate">
            <div className="font-bold text-[#082f4f] text-xs truncate max-w-[160px]">{currentUser.name}</div>
            <div className="text-[10.5px] font-mono text-[#855b00] uppercase font-bold">{currentUser.role}</div>
          </div>
          <span className="rounded bg-sky-200/70 px-1.5 py-0.5 text-[10px] font-mono font-bold text-[#082f4f]">
            {currentUser.canCheck ? 'Checker Auth' : 'Maker Only'}
          </span>
        </div>
      </div>
    </aside>
    </>
  );
};
