import React, { useState } from 'react';
import { DisclosureNote, Workspace } from '../types';
import {
  FileSpreadsheet,
  Download,
  Printer,
  Search,
  CheckCircle2,
  AlertCircle,
  Edit3,
  RefreshCw,
  Calendar,
} from 'lucide-react';

interface DisclosureNotesDeskProps {
  currentWorkspace: Workspace;
  notes: DisclosureNote[];
  onUpdateNote: (updatedNote: DisclosureNote) => void;
}

export const DisclosureNotesDesk: React.FC<DisclosureNotesDeskProps> = ({
  currentWorkspace,
  notes,
  onUpdateNote,
}) => {
  const [period, setPeriod] = useState('2026-03 (YTD)');
  const [statusFilter, setStatusFilter] = useState<'all' | 'applicable' | 'not_applicable'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingNote, setEditingNote] = useState<DisclosureNote | null>(null);

  const applicableCount = notes.filter((n) => n.applicable).length;
  const naCount = notes.length - applicableCount;

  const filteredNotes = notes.filter((n) => {
    const matchesFilter =
      statusFilter === 'all' ||
      (statusFilter === 'applicable' && n.applicable) ||
      (statusFilter === 'not_applicable' && !n.applicable);
    const matchesSearch =
      n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.standardRef.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.body.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  // Export to Excel / CSV "Notes to Accounts" sheet
  const handleExportCsv = () => {
    let csv = `BPZ CONSULT — NOTES TO THE FINANCIAL STATEMENTS\n`;
    csv += `Client: ${currentWorkspace.name} (${currentWorkspace.code})\n`;
    csv += `Reporting Period: ${period}\n`;
    csv += `Statutory Standard: IAS 1 / IFRS Accounting Standards\n\n`;

    notes.forEach((note) => {
      csv += `NOTE ${note.noteNumber}: ${note.title.toUpperCase()} [${note.standardRef}]\n`;
      if (!note.applicable) {
        csv += `STATUS: NOT APPLICABLE\n`;
        csv += `REASON: ${note.notApplicableReason || 'Criteria not met in current period.'}\n\n`;
      } else {
        csv += `STATUS: APPLICABLE\n`;
        csv += `DISCLOSURE TEXT:\n"${note.body.replace(/"/g, '""')}"\n`;
        if (note.tables && note.tables.length > 0) {
          note.tables.forEach((t) => {
            csv += `\n` + t.headers.join('\t') + `\n`;
            t.rows.forEach((r) => {
              csv += r.join('\t') + `\n`;
            });
          });
        }
        csv += `\n------------------------------------------------------------\n\n`;
      }
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${currentWorkspace.code}_Notes_to_Accounts_${period.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export to Markdown Full Pack
  const handleExportMarkdown = () => {
    let md = `# IAS 1 Notes to the Financial Statements\n\n`;
    md += `**Entity:** ${currentWorkspace.name} (${currentWorkspace.code})  \n`;
    md += `**Period:** ${period}  \n`;
    md += `**Framework:** International Financial Reporting Standards (IFRS)  \n\n`;
    md += `> **Audit Assurance Rule:** Notes that do not apply state so honestly with regulatory justification rather than printing empty tables.\n\n`;

    notes.forEach((n) => {
      md += `## Note ${n.noteNumber}: ${n.title}\n`;
      md += `*Reference: ${n.standardRef}*  \n\n`;
      if (!n.applicable) {
        md += `> **NOT APPLICABLE:** ${n.notApplicableReason}\n\n`;
      } else {
        md += `${n.body}\n\n`;
        if (n.tables) {
          n.tables.forEach((table) => {
            md += `| ` + table.headers.join(' | ') + ` |\n`;
            md += `| ` + table.headers.map(() => '---').join(' | ') + ` |\n`;
            table.rows.forEach((row) => {
              md += `| ` + row.join(' | ') + ` |\n`;
            });
            md += `\n`;
          });
        }
      }
      md += `---\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${currentWorkspace.code}_Notes_Pack.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Notes to the Financial Statements Header */}
      <div className="rounded-xl border border-slate-700 bg-slate-900/90 p-6 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded bg-amber-400/20 px-2 py-0.5 text-xs font-mono font-bold text-amber-300">
                IAS 1 · PRESENTATION OF FINANCIAL STATEMENTS
              </span>
              <span className="text-xs font-semibold text-slate-400">
                Workspace: {currentWorkspace.code}
              </span>
            </div>
            <h2 className="mt-1.5 text-2xl font-black text-white">
              Notes to Accounts
            </h2>
          </div>

          {/* Export Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-500 transition shadow-sm"
              title="Download Notes to Accounts sheet for Excel"
            >
              <FileSpreadsheet className="h-4 w-4" />
              <span>Excel &ldquo;Notes to Accounts&rdquo;</span>
            </button>
            <button
              onClick={handleExportMarkdown}
              className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-bold text-slate-200 hover:bg-slate-700 transition"
              title="Download Markdown pack"
            >
              <Download className="h-4 w-4" />
              <span>Markdown Pack</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-bold text-slate-200 hover:bg-slate-700 transition"
              title="Print pack"
            >
              <Printer className="h-4 w-4" />
              <span>Print Pack</span>
            </button>
          </div>
        </div>

        {/* Counters & Filter Bar */}
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-md border border-slate-700 bg-slate-800 px-2.5 py-1 font-mono font-bold text-slate-200">
              {notes.length} Total Notes
            </span>
            <span className="rounded-md border border-emerald-700 bg-emerald-950/60 px-2.5 py-1 font-mono font-bold text-emerald-300">
              {applicableCount} Applicable
            </span>
            <span className="rounded-md border border-amber-700 bg-amber-950/60 px-2.5 py-1 font-mono font-bold text-amber-300">
              {naCount} Honest N/A (Transparent Exclusions)
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1.5 rounded-md border border-slate-700 bg-slate-800 px-2 py-1">
              <Calendar className="h-3.5 w-3.5 text-slate-400" />
              <select
                value={period}
                onChange={(e) => setPeriod(e.target.value)}
                className="bg-transparent text-slate-200 font-semibold outline-none cursor-pointer"
              >
                <option value="2026-03 (YTD)" className="bg-slate-900">2026-03 (YTD)</option>
                <option value="2025-12 (FY Audited)" className="bg-slate-900">2025-12 (FY Audited)</option>
                <option value="2026-02 (Month Close)" className="bg-slate-900">2026-02 (Month Close)</option>
              </select>
            </div>

            <div className="flex rounded border border-slate-700 bg-slate-800 p-0.5">
              <button
                onClick={() => setStatusFilter('all')}
                className={`rounded px-2.5 py-1 font-semibold ${
                  statusFilter === 'all' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setStatusFilter('applicable')}
                className={`rounded px-2.5 py-1 font-semibold ${
                  statusFilter === 'applicable' ? 'bg-emerald-500 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Applicable
              </button>
              <button
                onClick={() => setStatusFilter('not_applicable')}
                className={`rounded px-2.5 py-1 font-semibold ${
                  statusFilter === 'not_applicable' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Honest N/A
              </button>
            </div>

            <div className="relative">
              <Search className="absolute left-2 top-2 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search disclosure..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-44 rounded border border-slate-700 bg-slate-800 pl-7 pr-2 py-1 text-slate-200 outline-none focus:border-amber-400"
              />
            </div>
          </div>
        </div>
      </div>

      {/* List of Disclosure Notes */}
      <div className="space-y-4">
        {filteredNotes.map((note) => {
          return (
            <div
              key={note.key}
              className={`rounded-xl border p-5 transition-all shadow-md ${
                note.applicable
                  ? 'border-slate-800 bg-[#0d1f33]/90 hover:border-slate-700'
                  : 'border-amber-300 bg-amber-50/95'
              }`}
            >
              {/* Note Header */}
              <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-800/80 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded bg-slate-800 font-mono text-xs font-extrabold text-amber-400">
                      {note.noteNumber}
                    </span>
                    <h3 className="text-base sm:text-lg font-bold text-white">{note.title}</h3>
                  </div>
                  <div className="mt-1 text-xs text-slate-400 font-medium">
                    Standard: <span className="font-mono text-slate-300">{note.standardRef}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Applicability Badge */}
                  {note.applicable ? (
                    <span className="inline-flex items-center gap-1 rounded bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 text-xs font-bold text-emerald-400">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span>Applicable</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 rounded bg-amber-500/10 border border-amber-500/40 px-2.5 py-1 text-xs font-bold text-amber-300">
                      <AlertCircle className="h-3.5 w-3.5" />
                      <span>Honest N/A</span>
                    </span>
                  )}

                  {/* Auditor Override Toggle */}
                  <button
                    onClick={() => {
                      onUpdateNote({
                        ...note,
                        applicable: !note.applicable,
                        notApplicableReason: !note.applicable
                          ? undefined
                          : 'Auditor manual exclusion: deemed immaterial for this period under IAS 1.31.',
                      });
                    }}
                    className="rounded border border-slate-700 bg-slate-800 px-2 py-1 text-[11px] font-semibold text-slate-300 hover:bg-slate-700 transition"
                    title="Toggle applicability"
                  >
                    <RefreshCw className="h-3 w-3 inline mr-1" />
                    Toggle N/A
                  </button>

                  <button
                    onClick={() => setEditingNote(note)}
                    className="rounded border border-slate-700 bg-slate-800 px-2 py-1 text-[11px] font-semibold text-slate-300 hover:bg-slate-700 transition"
                  >
                    <Edit3 className="h-3 w-3 inline mr-1" />
                    Edit Note
                  </button>
                </div>
              </div>

              {/* Note Content */}
              <div className="mt-4 space-y-3">
                {/* Honest N/A Alert Box if not applicable */}
                {!note.applicable && (
                  <div className="rounded-lg border border-amber-600/40 bg-amber-950/20 p-3.5 text-xs text-amber-200 flex items-start gap-2.5">
                    <AlertCircle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="font-bold text-amber-300">Not Applicable:</strong>{' '}
                      {note.notApplicableReason}
                      <p className="mt-1 text-[11px] text-amber-400/80">
                        Per IFRS Practice Statement 2 (Materiality), irrelevant disclosures are omitted rather than populating non-meaningful zero tables.
                      </p>
                    </div>
                  </div>
                )}

                {/* Body Text */}
                <p className="whitespace-pre-line text-xs sm:text-sm text-slate-200 leading-relaxed font-normal">
                  {note.body}
                </p>

                {/* Quantitative Tables if applicable */}
                {note.applicable && note.tables && note.tables.length > 0 && (
                  <div className="mt-4 space-y-3">
                    {note.tables.map((table, tIdx) => (
                      <div key={tIdx} className="overflow-x-auto rounded-lg border border-slate-800 bg-slate-950/80">
                        <table className="min-w-full text-left text-xs">
                          <thead className="border-b border-slate-800 bg-slate-900/80 text-slate-400">
                            <tr>
                              {table.headers.map((h, hIdx) => (
                                <th key={hIdx} className="px-3 py-2 font-semibold tracking-wider">
                                  {h}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-850">
                            {table.rows.map((row, rIdx) => (
                              <tr key={rIdx} className="hover:bg-slate-900/50 transition">
                                {row.map((cell, cIdx) => (
                                  <td
                                    key={cIdx}
                                    className={`px-3 py-2 text-slate-200 font-mono text-[11.5px] ${
                                      cIdx > 1 && !isNaN(Number(String(cell).replace(/,/g, '')))
                                        ? 'text-right'
                                        : ''
                                    }`}
                                  >
                                    {String(cell)}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit Note Modal */}
      {editingNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-2xl rounded-xl border border-slate-700 bg-slate-900 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">
                Edit Note #{editingNote.noteNumber}: {editingNote.title}
              </h3>
              <button
                onClick={() => setEditingNote(null)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Standard Reference</label>
                <input
                  type="text"
                  value={editingNote.standardRef}
                  onChange={(e) => setEditingNote({ ...editingNote, standardRef: e.target.value })}
                  className="w-full rounded border border-slate-700 bg-slate-800 px-3 py-1.5 text-slate-100 outline-none"
                />
              </div>

              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingNote.applicable}
                    onChange={(e) => setEditingNote({ ...editingNote, applicable: e.target.checked })}
                    className="rounded border-slate-700 text-amber-400"
                  />
                  <span className="font-bold text-slate-200">Applicable to this entity</span>
                </label>
              </div>

              {!editingNote.applicable && (
                <div>
                  <label className="block text-amber-300 font-semibold mb-1">Honest N/A Regulatory Reason</label>
                  <textarea
                    rows={2}
                    value={editingNote.notApplicableReason || ''}
                    onChange={(e) => setEditingNote({ ...editingNote, notApplicableReason: e.target.value })}
                    className="w-full rounded border border-slate-700 bg-slate-800 p-2.5 text-slate-100 outline-none"
                  />
                </div>
              )}

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Disclosure Note Body Text</label>
                <textarea
                  rows={6}
                  value={editingNote.body}
                  onChange={(e) => setEditingNote({ ...editingNote, body: e.target.value })}
                  className="w-full rounded border border-slate-700 bg-slate-800 p-2.5 text-slate-100 outline-none font-sans"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setEditingNote(null)}
                className="rounded px-4 py-2 text-xs font-semibold text-slate-400 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onUpdateNote(editingNote);
                  setEditingNote(null);
                }}
                className="rounded bg-amber-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-amber-300"
              >
                Save Disclosure Note
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
