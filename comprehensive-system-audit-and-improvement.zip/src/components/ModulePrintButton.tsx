'use client';

/**
 * Print control shown in every module workspace.
 *
 * Modules that build their own document (payroll, sales, tax schedules,
 * financial reports, the statutory pack) already carry their own print button;
 * this one covers the desks that have no bespoke document — it prints the
 * module the operator is actually looking at, with the controls removed.
 */

import { Printer } from 'lucide-react';
import { printModuleView } from '@/utils/printModuleView';

export function ModulePrintButton({
  title,
  subtitle,
  label = 'Print this module',
  className = '',
  targetId,
}: {
  title: string;
  subtitle?: string;
  label?: string;
  className?: string;
  /** Print only the module with this DOM id (used for the sub-desks). */
  targetId?: string;
}) {
  return (
    <button
      type="button"
      data-print-hide
      onClick={() => printModuleView({ title, subtitle, root: targetId ? document.getElementById(targetId) : undefined })}
      className={`no-print flex items-center gap-1.5 rounded border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] transition hover:bg-sky-50 active:translate-y-px ${className}`}
      title={`Print the ${title} working paper`}
    >
      <Printer className="h-3.5 w-3.5" /> {label}
    </button>
  );
}
