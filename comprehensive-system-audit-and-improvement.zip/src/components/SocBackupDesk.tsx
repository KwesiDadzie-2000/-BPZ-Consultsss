import { useState } from 'react';
import {
  CheckCircle2,
  Play,
  RefreshCw,
  AlertTriangle,
  Server,
  ShieldOff,
} from 'lucide-react';

const DEMO_PITR_STEPS = [
  'Connect to a sandbox VPC in the secondary region (sandbox only — not production).',
  'Fetch the encrypted local JSON backup and verify its SHA-256 hash.',
  'Replay posts to a sandbox Universal Journal and re-validate double entry.',
  'Compare sandbox totals to the official files — log any residual.',
  'Report results. No production data is altered.',
];

export const SocBackupDesk: React.FC = () => {
  const [running, setRunning] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [step, setStep] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleRunDrill = () => {
    setRunning(true);
    setCompleted(false);
    setStep(0);
    setFeedback(null);

    let current = 0;
    const interval = setInterval(() => {
      current++;
      setStep(current);
      if (current >= DEMO_PITR_STEPS.length - 1) {
        clearInterval(interval);
        setRunning(false);
        setCompleted(true);
        setFeedback('Sandbox drill complete. This is a local demo; no real recovery was performed.');
      }
    }, 800);
  };

  return (
    <div className="space-y-6 text-[#0a253e]">
      <div className="rounded-xl border border-amber-400 bg-amber-50 p-4 text-sm text-amber-950 flex items-start gap-2">
        <ShieldOff className="h-5 w-5 mt-0.5 text-amber-700 shrink-0" />
        <div>
          <strong>Infrastructure status.</strong> SOC 2 Type II certification, automated point-in-time recovery and cross-region
          replication are infrastructure obligations. They are tracked here and must be evidenced before live client books
          are kept on the deployment.
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="rounded-xl border border-sky-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-[#355875] text-xs">
            <span className="font-bold uppercase tracking-wider">Storage</span>
            <Server className="h-4 w-4 text-[#006f98]" />
          </div>
          <div className="mt-2 text-base font-black text-[#082f4f]">Browser localStorage</div>
          <div className="text-[11px] text-[#355875] mt-0.5">5 MB nominal limit, no replication</div>
        </div>
        <div className="rounded-xl border border-sky-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-[#355875] text-xs">
            <span className="font-bold uppercase tracking-wider">Backup</span>
            <AlertTriangle className="h-4 w-4 text-amber-700" />
          </div>
          <div className="mt-2 text-base font-black text-amber-800">Manual JSON export only</div>
          <div className="text-[11px] text-[#355875] mt-0.5">Owner must download & store</div>
        </div>
        <div className="rounded-xl border border-sky-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-[#355875] text-xs">
            <span className="font-bold uppercase tracking-wider">Restore validation</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-700" />
          </div>
          <div className="mt-2 text-base font-black text-emerald-800">Dr = Cr + tenant keys</div>
          <div className="text-[11px] text-[#355875] mt-0.5">Browser-side check (not server-side)</div>
        </div>
        <div className="rounded-xl border border-sky-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-[#355875] text-xs">
            <span className="font-bold uppercase tracking-wider">Access control</span>
            <Server className="h-4 w-4 text-rose-700" />
          </div>
          <div className="mt-2 text-base font-black text-rose-800">Client-side only</div>
          <div className="text-[11px] text-[#355875] mt-0.5">No real authentication server</div>
        </div>
      </div>

      <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-sky-200 pb-3">
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f] flex items-center gap-2">
              <Play className="h-4 w-4 text-amber-600" /> Recovery drill (sandbox simulation)
            </h3>
            <p className="mt-1 text-xs text-[#2d4f6d]">
              The drill runs entirely inside the browser. Nothing is restored.
            </p>
          </div>
          <button
            onClick={handleRunDrill}
            disabled={running}
            className="flex items-center gap-2 rounded-lg bg-amber-500 px-4 py-2 text-xs font-bold text-[#082f4f] hover:bg-amber-400 transition shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {running ? (<><RefreshCw className="h-4 w-4 animate-spin" /> Simulating…</>) : (<><Play className="h-4 w-4" /> Run sandbox drill</>)}
          </button>
        </div>

        {(running || completed) && (
          <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-4 space-y-2 font-mono text-xs">
            <div className="flex items-center justify-between text-[#355875] border-b border-sky-200 pb-2">
              <span className="font-bold uppercase tracking-wider">Sandbox log</span>
              <span className="text-amber-700">Step {step + 1} of {DEMO_PITR_STEPS.length}</span>
            </div>
            {DEMO_PITR_STEPS.slice(0, step + 1).map((s, idx) => (
              <div key={idx} className={`flex items-start gap-2 ${idx === DEMO_PITR_STEPS.length - 1 ? 'text-emerald-800 font-bold' : 'text-[#082f4f]'}`}>
                <span className="text-[#355875]">&gt;</span>
                <span>{s}</span>
              </div>
            ))}
          </div>
        )}

        {feedback && (
          <div className="rounded-lg border border-emerald-300 bg-emerald-50 p-3 text-xs font-bold text-emerald-900 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-700" /> {feedback}
          </div>
        )}
      </div>
    </div>
  );
};
