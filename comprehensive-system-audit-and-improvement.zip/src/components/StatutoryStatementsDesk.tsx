'use client';

/**
 * IFRS Statutory Financial Statements.
 *
 * The complete set required by IAS 1.10 — statement of financial position,
 * statement of profit or loss and other comprehensive income, statement of
 * changes in equity, statement of cash flows and the notes — prepared from the
 * posted journal and presented as the document it is: a statutory plate with
 * boxed headings, hairline rules, note references in the margin and comparatives
 * in a second column. Every statement prints on its own; the whole pack prints
 * as one bound document.
 */

import { useMemo, useState } from 'react';
import { Printer, FileText, ShieldCheck, AlertTriangle, Download, BookOpen, X, ArrowRight, CheckCircle2, FileWarning } from 'lucide-react';
import type { AccountMaster, ACDOCALine, ClientEntity, UserAccount } from '@/types/accounting';
import { buildIfrsPack, type IfrsPack, type IfrsRow, type IfrsStatement } from '@/utils/ifrsPack';
import { printIfrsPack } from '@/utils/printIfrs';
import { toPrintEntity } from '@/utils/printEntity';
import { persistentStorage } from '@/utils/persistentStorage';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const fiscalYearStartISO = (clientId: number, year: number): string => {
  const profiles = persistentStorage.getCompanyProfiles();
  const fy = profiles[clientId]?.fiscalYearStart || 'January';
  const idx = Math.max(0, MONTHS.indexOf(fy));
  return `${year}-${String(idx + 1).padStart(2, '0')}-01`;
};

const money = (n: number) =>
  n < 0
    ? `(${Math.abs(n).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})`
    : n.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

type Tab = 'position' | 'profit' | 'equity' | 'cashflow' | 'notes' | 'analysis' | 'compliance';

const TABS: { id: Tab; label: string; standard: string }[] = [
  { id: 'position', label: 'Financial position', standard: 'IAS 1.54' },
  { id: 'profit', label: 'Profit or loss & OCI', standard: 'IAS 1.82A' },
  { id: 'equity', label: 'Changes in equity', standard: 'IAS 1.106' },
  { id: 'cashflow', label: 'Cash flows', standard: 'IAS 7.10' },
  { id: 'notes', label: 'Notes to the statements', standard: 'IAS 1.112' },
  { id: 'analysis', label: 'Ratios & capital', standard: 'IAS 1.134' },
  { id: 'compliance', label: 'IFRS compliance check', standard: 'IAS 1.114' },
];

/** One statutory plate: boxed centred heading, ruled columns, marginal notes. */
function StatementSheet({ statement }: { statement: IfrsStatement }) {
  return (
    <article className="rounded-sm border border-[#bae6fd] bg-[#ffffff] p-6 shadow-[0_1px_0_#eaf3fb,0_18px_38px_-30px_rgba(34,31,26,0.55)] sm:p-9">
      <div className="text-center text-[9px] font-bold uppercase tracking-[0.28em] text-[#855b00]">{statement.standard}</div>
      <h3 className="mx-auto mt-2 max-w-[36rem] border border-[#082f4f] px-4 py-2.5 text-center text-[15px] font-semibold leading-tight text-[#082f4f] sm:text-[17px]">
        {statement.title}
      </h3>
      <p className="mt-2 text-center text-[11.5px] italic text-[#2d4f6d]">{statement.subtitle}</p>

      {statement.matrix && (
        <div className="mt-6 overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-[#0a253e]">
                <th className="py-1.5 pr-4 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Particulars</th>
                {statement.matrix.columns.map((c) => (
                  <th key={c} className="py-1.5 pl-3 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">
                    {c}
                  </th>
                ))}
                <th className="py-1.5 pl-3 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Total</th>
              </tr>
            </thead>
            <tbody>
              {statement.matrix.rows.map((r, i) => (
                <tr
                  key={`${r.label}-${i}`}
                  className={`${r.emphasis === 'total' ? 'border-y-[1.5px] border-double border-[#082f4f] bg-[#eaf3fb] font-semibold text-[#082f4f]' : r.emphasis === 'sub' ? 'border-t border-[#0a253e] bg-[#eff6fd] font-semibold' : 'border-b border-[#bfdbfe]'} transition-colors hover:bg-[#eff6fd]`}
                >
                  <td className="py-[5px] pr-4 text-[11.5px] text-[#0a253e]">{r.label}</td>
                  {r.values.map((v, j) => (
                    <td key={j} className={`py-[5px] pl-3 text-right font-mono text-[11px] tabular-nums ${v < 0 ? 'text-[#855b00]' : 'text-[#0a253e]'}`}>
                      {money(v)}
                    </td>
                  ))}
                  <td className={`py-[5px] pl-3 text-right font-mono text-[11px] font-semibold tabular-nums ${r.total < 0 ? 'text-[#855b00]' : 'text-[#0a253e]'}`}>
                    {money(r.total)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="mt-6 space-y-7">
        {statement.blocks.map((block, bi) => (
          <section key={`${block.title ?? 'block'}-${bi}`}>
            {block.title && (
              <h4 className="mb-1.5 border-b border-[#082f4f] pb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[#082f4f]">
                {block.title}
              </h4>
            )}
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b border-[#0a253e]">
                  <th className="py-1.5 pr-4 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Particulars</th>
                  <th className="w-10 py-1.5 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Note</th>
                  <th className="w-[16%] py-1.5 pl-3 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Amount</th>
                  <th className="w-[16%] py-1.5 pl-3 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Comparative</th>
                </tr>
              </thead>
              <tbody>
                {[...block.rows, ...(block.total ? [block.total] : [])].map((row, i) => (
                  <Row key={`${row.label}-${i}`} row={row} />
                ))}
                {block.rows.length === 0 && !block.total && (
                  <tr>
                    <td colSpan={4} className="py-4 text-center text-[11px] italic text-[#355875]">
                      No amounts recognised in this caption for the period.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </section>
        ))}
      </div>
    </article>
  );
}

function Row({ row }: { row: IfrsRow }) {
  const emphasis =
    row.emphasis === 'grand'
      ? 'border-y-[1.5px] border-double border-[#0a253e] bg-[#eaf3fb] font-semibold'
      : row.emphasis === 'total'
        ? 'border-t-[1.5px] border-b-[3px] border-double border-[#082f4f] bg-[#eaf3fb] font-semibold text-[#082f4f]'
        : row.emphasis === 'sub'
          ? 'border-t border-[#0a253e] bg-[#eff6fd] font-semibold'
          : 'border-b border-[#bfdbfe]';
  return (
    <tr className={`${emphasis} transition-colors hover:bg-[#eff6fd]`}>
      <td className={`py-[5px] pr-4 text-[11.5px] text-[#0a253e] ${row.indent ? 'pl-7 italic text-[#2d4f6d]' : ''}`}>{row.label}</td>
      <td className="py-[5px] text-right text-[9px] font-semibold tracking-[0.12em] text-[#855b00]">{row.note}</td>
      <td className={`py-[5px] pl-3 text-right font-mono text-[11px] tabular-nums ${row.current < 0 ? 'text-[#855b00]' : 'text-[#0a253e]'}`}>
        {money(row.current)}
      </td>
      <td className={`py-[5px] pl-3 text-right font-mono text-[11px] tabular-nums ${row.comparative < 0 ? 'text-[#855b00]' : 'text-[#355875]'}`}>
        {money(row.comparative)}
      </td>
    </tr>
  );
}

/** Where each failed control is actually fixed in the workspace. */
const RESOLUTION: Record<string, { section: string; label: string }> = {
  'Ledger integrity': { section: 'general_ledger', label: 'Open General Ledger' },
  'Journal control': { section: 'universal_journal', label: 'Open Universal Journal' },
  'Master data': { section: 'coa_master', label: 'Open Chart of Accounts' },
  'Financial statements': { section: 'financial_reports', label: 'Open Financial Reports' },
  'Taxation': { section: 'tax_schedule', label: 'Open Tax & Statutory Returns' },
  'Measurement': { section: 'adjustments', label: 'Open Adjustments' },
  'Accounting estimates and errors': { section: 'adjustments', label: 'Open Adjustments' },
  'Non-current assets': { section: 'assets', label: 'Open Fixed Assets Register' },
  'Employee benefits': { section: 'payroll', label: 'Open Payroll Desk' },
  'Expected credit losses': { section: 'financial_reports', label: 'Open Financial Reports' },
  'Inventory counts and costing': { section: 'inventory', label: 'Open Inventory & Stock' },
  'Lease register': { section: 'loans_desk', label: 'Open Finance Schedules' },
  'Cut-off': { section: 'month_end', label: 'Open Month-End Close' },
  'Related parties': { section: 'disclosures', label: 'Open Notes to Accounts' },
  'Segregation of duties': { section: 'user_permissions', label: 'Open User Access' },
  'Statement completeness': { section: 'compliance_review', label: 'Open Compliance Review' },
};

export function StatutoryStatementsDesk({
  currentClient,
  currentUser,
  lines,
  accounts,
  clients,
  onSelectClient,
  onNavigate,
}: {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  clients?: ClientEntity[];
  onSelectClient?: (client: ClientEntity) => void;
  /** Cross-module navigation from a failed control check to the desk that fixes it. */
  onNavigate?: (section: string) => void;
}) {
  const [tab, setTab] = useState<Tab>('position');
  const [controlsOpen, setControlsOpen] = useState(false);
  const [controlFilter, setControlFilter] = useState<'open' | 'all' | 'critical'>('open');
  const [through, setThrough] = useState(() => new Date().toISOString().slice(0, 10));
  const [reportChoice, setReportChoice] = useState<number | null>(null);
  const [fromOverride, setFromOverride] = useState<string | null>(null);

  const reportClientId = reportChoice ?? currentClient.id;
  const reportClient = (clients ?? [currentClient]).find((c) => c.id === reportClientId) || currentClient;
  const from = fromOverride ?? fiscalYearStartISO(reportClientId, Number(through.slice(0, 4)) || new Date().getFullYear());

  const profile = persistentStorage.getCompanyProfiles()[reportClient.id];

  const pack: IfrsPack = useMemo(
    () =>
      buildIfrsPack({
        lines: lines.filter((l) => l.clientId === reportClient.id),
        accounts,
        from,
        through,
        currency: reportClient.currency,
        entityName: reportClient.name,
        entityCode: reportClient.code,
        jurisdiction: reportClient.jurisdiction,
        regNumber: reportClient.regNumber,
        fiscalYearStart: profile?.fiscalYearStart,
        sector: reportClient.sector,
      }),
    [lines, accounts, reportClient, from, through, profile],
  );

  const entity = toPrintEntity(reportClient, profile);
  const preparedBy = `${currentUser.name} (${currentUser.username})`;

  const printPack = (
    include?: { statements?: boolean; notes?: boolean; ratios?: boolean; compliance?: boolean },
    onlyStatement?: 'position' | 'profit' | 'equity' | 'cashflow',
  ) =>
    printIfrsPack(pack, {
      entity: { ...entity, jurisdiction: reportClient.jurisdiction, regNumber: reportClient.regNumber },
      preparedBy,
      include,
      onlyStatement,
      authorisedOn: through,
      status: 'Statutory financial statements — IFRS',
    });

  const printActive = () => {
    if (tab === 'notes') return printPack({ notes: true });
    if (tab === 'analysis') return printPack({ ratios: true });
    if (tab === 'compliance') return printPack({ compliance: true });
    printPack({ statements: true }, tab);
  };

  const exportCsv = () => {
    const cell = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
    const rows: Array<Array<string | number>> = [
      ['Entity', reportClient.name],
      ['Entity code', reportClient.code],
      ['Period', pack.periodLabel],
      ['Comparative', pack.comparativeLabel],
      ['Currency', pack.currency],
      ['Standard', 'IFRS — IAS 1 complete set'],
      [],
      ['Statement', 'Caption', 'Note', 'Current', 'Comparative'],
    ];
    for (const st of pack.statements) {
      for (const block of st.blocks) {
        for (const r of [...block.rows, ...(block.total ? [block.total] : [])]) {
          rows.push([st.title, r.label, r.note ?? '', r.current, r.comparative]);
        }
      }
    }
    for (const n of pack.notes) {
      rows.push([`Note ${n.number}`, n.title, n.standard]);
      for (const p of n.paragraphs) rows.push(['', p]);
    }
    const url = URL.createObjectURL(new Blob([rows.map((r) => r.map(cell).join(',')).join('\r\n')], { type: 'text/csv' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = `${reportClient.code}-IFRS-statements-${through}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const activeStatement = pack.statements.find((s) => s.id === tab);
  const failing = pack.checks.filter((c) => c.severity !== 'pass');
  const critical = pack.checks.filter((c) => c.severity === 'critical');

  return (
    <div className="space-y-5">
      {/* Masthead — the cover of the statutory binder */}
      <div className="overflow-hidden rounded-lg border border-[#bae6fd] bg-[#082f4f]">
        <div className="relative bg-gradient-to-r from-[#082f4f] via-[#0c3f68] to-[#082f4f] px-5 py-6 sm:px-8 sm:py-8">
          <div className="text-[9px] font-bold uppercase tracking-[0.32em] text-[#f5b719]">
            IAS 1 · Complete set of financial statements
          </div>
          <h2 className="mt-2 max-w-[24ch] text-2xl font-semibold leading-tight text-[#ffffff] sm:text-[3xl]">
            Financial statements of {reportClient.name}
          </h2>
          <p className="mt-2 max-w-[62ch] text-[12px] leading-relaxed text-[#e3d9c4]">
            Prepared from the posted general ledger in accordance with International Financial Reporting Standards, with the
            comparative information, accounting policies and notes required by IAS 1. Every figure below is traceable to a journal
            document.
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <button
              onClick={() => printPack()}
              className="flex items-center gap-2 rounded bg-[#f5b719] px-4 py-2 text-xs font-bold text-[#082f4f] transition hover:bg-[#ffd166] active:translate-y-px"
            >
              <Printer className="h-3.5 w-3.5" /> Print full statutory pack
            </button>
            <button
              onClick={printActive}
              className="flex items-center gap-2 rounded border border-[#bae6fd]/60 bg-white/10 px-4 py-2 text-xs font-bold text-[#ffffff] transition hover:bg-white/20 active:translate-y-px"
            >
              <FileText className="h-3.5 w-3.5" /> Print current statement
            </button>
            <button
              onClick={exportCsv}
              className="flex items-center gap-2 rounded border border-[#bae6fd]/60 bg-white/10 px-4 py-2 text-xs font-bold text-[#ffffff] transition hover:bg-white/20 active:translate-y-px"
            >
              <Download className="h-3.5 w-3.5" /> Export CSV
            </button>
          </div>
        </div>
      </div>

      {/* Period control strip */}
      <div className="flex flex-wrap items-end gap-3 rounded-lg border border-sky-200 bg-white p-3">
        <label className="flex flex-col gap-1 text-[10px] font-bold uppercase tracking-wider text-[#2d4f6d]">
          Period from
          <input
            type="date"
            value={from}
            onChange={(e) => setFromOverride(e.target.value)}
            className="rounded border border-sky-300 px-2 py-1.5 text-xs font-semibold text-[#0a253e]"
          />
        </label>
        <label className="flex flex-col gap-1 text-[10px] font-bold uppercase tracking-wider text-[#2d4f6d]">
          Reporting date
          <input
            type="date"
            value={through}
            onChange={(e) => setThrough(e.target.value)}
            className="rounded border border-sky-300 px-2 py-1.5 text-xs font-semibold text-[#0a253e]"
          />
        </label>
        {(clients?.length ?? 0) > 1 && (
          <label className="flex flex-col gap-1 text-[10px] font-bold uppercase tracking-wider text-[#2d4f6d]">
            Reporting entity
            <select
              value={reportClientId}
              onChange={(e) => {
                const id = Number(e.target.value);
                setReportChoice(id);
                onSelectClient?.(clients!.find((c) => c.id === id) ?? currentClient);
              }}
              className="rounded border border-sky-300 px-2 py-1.5 text-xs font-semibold text-[#0a253e]"
            >
              {(clients ?? []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.code} — {c.name}
                </option>
              ))}
            </select>
          </label>
        )}
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => { setControlFilter(pack.totals.balanced ? 'all' : 'critical'); setControlsOpen(true); }}
            className={`rounded px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider transition hover:brightness-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#082f4f] ${pack.totals.balanced ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}
            title="View the balance control checks"
          >
            {pack.totals.balanced ? 'Statement balances' : 'Out of balance — view'}
          </button>
          <button
            type="button"
            onClick={() => { setControlFilter('all'); setControlsOpen(true); }}
            className="rounded bg-sky-100 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[#163653] transition hover:bg-sky-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#082f4f]"
            title="Open the control register"
          >
            {pack.checks.filter((c) => c.severity === 'pass').length}/{pack.checks.length} controls clear
          </button>
          <button
            type="button"
            onClick={() => { setControlFilter('open'); setControlsOpen(true); }}
            className={`rounded px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#082f4f] ${failing.length === 0 ? 'bg-emerald-100 text-emerald-800 hover:brightness-95' : 'bg-amber-100 text-[#8a5d00] hover:bg-amber-200'}`}
            title={failing.length === 0 ? 'Every control check is clear' : 'View each item that needs attention'}
          >
            {failing.length === 0 ? 'All controls clear' : `${failing.length} item${failing.length === 1 ? '' : 's'} for attention`}
          </button>
        </div>
      </div>

      {failing.length > 0 && (
        <div role="alert" className="flex flex-wrap items-center justify-between gap-3 rounded border border-rose-300 bg-rose-50 p-3 text-xs font-semibold text-rose-900">
          <div className="min-w-0">
            <span className="font-black uppercase tracking-wider">{critical.length > 0 ? 'Do not issue — ' : 'Review before issue — '}</span>
            {critical.length > 0 ? critical.map((c) => c.title).join('; ') : `${failing.length} control item(s) still need management confirmation`}.
            {' '}Resolve these before the statements are signed.
          </div>
          <button
            type="button"
            onClick={() => { setControlFilter('open'); setControlsOpen(true); }}
            className="flex shrink-0 items-center gap-1.5 rounded bg-rose-800 px-3 py-1.5 text-[11px] font-bold text-white transition hover:bg-rose-900"
          >
            <FileWarning className="h-3.5 w-3.5" /> View the {failing.length} issue{failing.length === 1 ? '' : 's'} <ArrowRight className="h-3 w-3" />
          </button>
        </div>
      )}

      {/* Statement tabs */}
      <div className="flex flex-wrap gap-1.5">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`rounded px-3 py-1.5 text-[11px] font-bold transition ${
              tab === t.id ? 'bg-[#082f4f] text-[#ffffff] shadow' : 'border border-sky-200 bg-white text-[#163653] hover:bg-sky-50'
            }`}
          >
            {t.label}
            <span className={`ml-2 font-mono text-[9px] ${tab === t.id ? 'text-[#f5b719]' : 'text-[#855b00]'}`}>{t.standard}</span>
          </button>
        ))}
      </div>

      {/* Document + compliance rail */}
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_260px]">
        <div>
          {activeStatement && <StatementSheet statement={activeStatement} />}

          {tab === 'notes' && (
            <div className="space-y-4">
              {pack.notes.map((n) => (
                <article key={n.number} className="rounded-sm border border-[#bae6fd] bg-[#ffffff] p-6">
                  <h4 className="text-[13px] font-semibold text-[#082f4f]">
                    {n.number}. {n.title}
                    <span className="ml-3 text-[9px] font-bold uppercase tracking-[0.18em] text-[#855b00]">{n.standard}</span>
                  </h4>
                  {n.paragraphs.map((p, i) => (
                    <p key={i} className="mt-2 max-w-[80ch] text-[11.5px] leading-relaxed text-[#0a253e]">
                      {p}
                    </p>
                  ))}
                  {n.table && (
                    <table className="mt-3 w-full border-collapse">
                      <thead>
                        <tr className="border-b border-[#0a253e]">
                          {n.table.columns.map((c, i) => (
                            <th key={c} className={`py-1.5 text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875] ${i > 0 ? 'text-right' : 'text-left'}`}>
                              {c}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {n.table.rows.map((r, i) => (
                          <tr key={i} className="border-b border-[#bfdbfe]">
                            {r.map((v, j) => (
                              <td key={j} className={`py-[5px] text-[11px] ${j > 0 ? `text-right font-mono tabular-nums ${typeof v === 'number' && v < 0 ? 'text-[#855b00]' : ''}` : ''}`}>
                                {typeof v === 'number' ? money(v) : v}
                              </td>
                            ))}
                          </tr>
                        ))}
                        {n.table.totals && (
                          <tr className="border-y-[1.5px] border-double border-[#082f4f] bg-[#eaf3fb] font-semibold">
                            {n.table.totals.map((v, j) => (
                              <td key={j} className={`py-[6px] text-[11px] text-[#082f4f] ${j > 0 ? 'text-right font-mono tabular-nums' : ''}`}>
                                {typeof v === 'number' ? money(v) : v}
                              </td>
                            ))}
                          </tr>
                        )}
                      </tbody>
                    </table>
                  )}
                </article>
              ))}
            </div>
          )}

          {tab === 'analysis' && (
            <div className="space-y-4">
              <div className="rounded-sm border border-[#bae6fd] bg-[#ffffff] p-6">
                <h4 className="border-b border-[#082f4f] pb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[#082f4f]">
                  Capital, liquidity and performance analysis
                </h4>
                <table className="mt-3 w-full border-collapse">
                  <thead>
                    <tr className="border-b border-[#0a253e]">
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Measure</th>
                      <th className="py-1.5 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Current</th>
                      <th className="py-1.5 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Comparative</th>
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Basis</th>
                      <th className="py-1.5 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Ref</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pack.ratios.map((r) => (
                      <tr key={r.label} className="border-b border-[#bfdbfe]">
                        <td className="py-[6px] pr-3 text-[11.5px] text-[#0a253e]">{r.label}</td>
                        <td className="py-[6px] text-right font-mono text-[11px] tabular-nums text-[#0a253e]">{r.current}</td>
                        <td className="py-[6px] text-right font-mono text-[11px] tabular-nums text-[#355875]">{r.comparative}</td>
                        <td className="py-[6px] pl-3 text-[10.5px] italic text-[#2d4f6d]">{r.basis}</td>
                        <td className="py-[6px] text-right text-[9px] font-semibold tracking-[0.12em] text-[#855b00]">{r.ref}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="rounded-sm border border-[#bae6fd] bg-[#ffffff] p-6">
                <h4 className="border-b border-[#082f4f] pb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[#082f4f]">
                  Significant accounting policies — note 3
                </h4>
                <table className="mt-3 w-full border-collapse">
                  <tbody>
                    {pack.notes
                      .find((n) => n.number === 3)
                      ?.table?.rows.map((r, i) => (
                        <tr key={i} className="border-b border-[#bfdbfe]">
                          <td className="py-[6px] pr-3 text-[11.5px] text-[#0a253e]">{r[0]}</td>
                          <td className="py-[6px] text-right text-[9px] font-bold uppercase tracking-[0.12em] text-[#855b00]">{r[1]}</td>
                          <td className="py-[6px] pl-3 text-[10.5px] italic text-[#2d4f6d]">{r[2]}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab === 'compliance' && (
            <div className="space-y-4">
              <div className="rounded-sm border border-[#bae6fd] bg-[#ffffff] p-6">
                <h4 className="border-b border-[#082f4f] pb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[#082f4f]">
                  IAS 1.10 completeness checklist
                </h4>
                <table className="mt-3 w-full border-collapse">
                  <thead>
                    <tr className="border-b border-[#0a253e]">
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Requirement</th>
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Standard</th>
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Status</th>
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#355875]">Basis</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pack.checklist.map((c) => (
                      <tr key={c.requirement} className="border-b border-[#bfdbfe]">
                        <td className="py-[6px] pr-3 text-[11.5px] text-[#0a253e]">{c.requirement}</td>
                        <td className="py-[6px] pr-3 font-mono text-[10px] text-[#2d4f6d]">{c.standard}</td>
                        <td className="py-[6px] pr-3">
                          <span
                            className={`rounded px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.12em] ${
                              c.status === 'Satisfied'
                                ? 'bg-emerald-100 text-emerald-800'
                                : c.status === 'Partial'
                                  ? 'bg-amber-100 text-[#7a4c00]'
                                  : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {c.status}
                          </span>
                        </td>
                        <td className="py-[6px] text-[10.5px] italic text-[#2d4f6d]">{c.detail}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="rounded-sm border border-[#bae6fd] bg-[#ffffff] p-6">
                <h4 className="flex items-center gap-2 border-b border-[#082f4f] pb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[#082f4f]">
                  <ShieldCheck className="h-3.5 w-3.5" /> Control checks run against the ledger
                </h4>
                <div className="mt-3 space-y-2">
                  {pack.checks.map((c) => (
                    <div key={c.id} className="flex items-start gap-3 border-b border-[#bfdbfe] pb-2">
                      <span
                        className={`mt-0.5 rounded px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.12em] ${
                          c.severity === 'pass'
                            ? 'bg-emerald-100 text-emerald-800'
                            : c.severity === 'critical'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-[#7a4c00]'
                        }`}
                      >
                        {c.severity === 'pass' ? 'Clear' : c.severity === 'critical' ? 'Critical' : 'Review'}
                      </span>
                      <div>
                        <div className="text-[11.5px] font-semibold text-[#0a253e]">
                          {c.title} <span className="ml-2 text-[9px] font-bold uppercase tracking-[0.12em] text-[#855b00]">{c.standard}</span>
                        </div>
                        <div className="text-[10.5px] text-[#2d4f6d]">{c.detail}</div>
                        <div className="text-[10.5px] italic text-[#355875]">{c.action}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Compliance rail — the authority standing beside each figure */}
        <aside className="h-max rounded-lg border border-sky-200 bg-white p-4 lg:sticky lg:top-4">
          <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#855b00]">Authority</div>
          <h4 className="mt-1 text-sm font-bold text-[#082f4f]">{TABS.find((t) => t.id === tab)?.standard}</h4>
          <p className="mt-1 text-[11px] leading-relaxed text-[#2d4f6d]">
            {tab === 'position' && 'IAS 1.54 requires a classified statement of financial position, with current and non-current items presented separately and comparatives for the preceding period (IAS 1.38).'}
            {tab === 'profit' && 'IAS 1.82A permits a single statement of profit or loss and other comprehensive income; profit or loss items are presented before OCI items, and total comprehensive income is shown.'}
            {tab === 'equity' && 'IAS 1.106 requires a statement of changes in equity showing each component of equity, the effects of changes in accounting policies and corrections of errors, and transactions with owners in their capacity as owners.'}
            {tab === 'cashflow' && 'IAS 7.10 requires cash flows classified into operating, investing and financing activities. IAS 7.44 additionally requires a reconciliation of net debt where cash flows are classified by activity.'}
            {tab === 'notes' && 'IAS 1.112 requires the notes to present information about the basis of preparation, specific accounting policies, and disclosures that are not presented elsewhere — in a systematic order.'}
            {tab === 'analysis' && 'IAS 1.60 requires disclosure of the entity’s liquidity and capital management, including maturity analysis and the entity’s objectives, policies and processes for managing capital.'}
            {tab === 'compliance' && 'IAS 1.114 requires an explicit statement of compliance with IFRS. The completeness checklist verifies the complete set required by IAS 1.10.'}
          </p>

          <div className="mt-4 border-t border-sky-100 pt-3">
            <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#855b00]">Key figures</div>
            <dl className="mt-2 space-y-2">
              {[
                ['Revenue', pack.totals.revenue],
                ['Profit for the period', pack.totals.profitForPeriod],
                ['Total comprehensive income', pack.totals.totalComprehensiveIncome],
                ['Total assets', pack.totals.totalAssets],
                ['Total equity', pack.totals.totalEquity],
                ['Net debt', pack.totals.netDebt],
              ].map(([label, value]) => (
                <div key={String(label)} className="flex items-baseline justify-between gap-2">
                  <dt className="text-[10.5px] text-[#2d4f6d]">{label}</dt>
                  <dd className={`font-mono text-[11px] font-semibold tabular-nums ${Number(value) < 0 ? 'text-[#855b00]' : 'text-[#0a253e]'}`}>
                    {money(Number(value))}
                  </dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="mt-4 border-t border-sky-100 pt-3">
            <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.16em] text-[#855b00]">
              <BookOpen className="h-3 w-3" /> Note references
            </div>
            <div className="mt-2 flex flex-wrap gap-1">
              {pack.notes.map((n) => (
                <span key={n.number} title={`${n.title} — ${n.standard}`} className="rounded border border-sky-200 bg-sky-50 px-1.5 py-0.5 font-mono text-[9px] font-bold text-[#163653]">
                  {n.number}
                </span>
              ))}
            </div>
          </div>

          {failing.length > 0 && (
            <div className="mt-4 flex items-start gap-2 rounded border border-amber-300 bg-amber-50 p-2.5">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#8a5d00]" />
              <p className="text-[10.5px] leading-relaxed text-[#7a4c00]">
                {failing.length} control check{failing.length === 1 ? '' : 's'} still require attention. Open the IFRS Compliance
                Review for the full gap register and remediation plan.
              </p>
            </div>
          )}
        </aside>
      </div>

      {/* Control register — every figure behind the status pills, with where to fix it */}
      {controlsOpen && (
        <div className="fixed inset-0 z-[80] flex justify-end bg-slate-950/45 p-0 sm:p-4" role="dialog" aria-modal="true" aria-label="IFRS control checks">
          <div className="flex h-full w-full max-w-2xl flex-col overflow-hidden rounded-none border border-sky-200 bg-white shadow-2xl sm:rounded-xl">
            <header className="flex items-start justify-between gap-3 border-b border-sky-200 bg-[#082f4f] px-4 py-3 text-white">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#f5b719]">IAS 1 · Internal control</div>
                <h3 className="text-base font-bold">Control checks — {reportClient.name}</h3>
                <p className="text-[11px] text-sky-100">
                  {pack.checks.filter((c) => c.severity === 'pass').length} of {pack.checks.length} clear · {critical.length} critical · {failing.length - critical.length} for review
                </p>
              </div>
              <button type="button" onClick={() => setControlsOpen(false)} aria-label="Close control checks" className="rounded border border-white/40 p-1 hover:bg-white/10">
                <X className="h-4 w-4" />
              </button>
            </header>
            <div className="flex flex-wrap gap-1.5 border-b border-sky-100 bg-sky-50/70 px-4 py-2">
              {([['open', `Open items (${failing.length})`], ['critical', `Critical (${critical.length})`], ['all', `All checks (${pack.checks.length})`]] as const).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setControlFilter(id)}
                  className={`rounded px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-wider ${controlFilter === id ? 'bg-[#082f4f] text-white' : 'border border-sky-200 bg-white text-[#163653] hover:bg-sky-100'}`}
                >{label}</button>
              ))}
            </div>
            <div className="min-h-0 flex-1 space-y-2.5 overflow-y-auto p-4">
              {(controlFilter === 'open' ? [...critical, ...failing.filter((c) => c.severity === 'warning')]
                : controlFilter === 'critical' ? critical
                  : pack.checks)
                .map((c) => {
                  const target = RESOLUTION[c.area] ?? { section: 'compliance_review', label: 'Open Compliance Review' };
                  return (
                    <article key={c.id} className={`rounded-lg border p-3 ${c.severity === 'critical' ? 'border-rose-300 bg-rose-50/70' : c.severity === 'warning' ? 'border-amber-300 bg-amber-50/70' : 'border-sky-200 bg-white'}`}>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`rounded px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.12em] ${c.severity === 'pass' ? 'bg-emerald-100 text-emerald-800' : c.severity === 'critical' ? 'bg-rose-200 text-rose-900' : 'bg-amber-200 text-[#7a4c00]'}`}>
                          {c.severity === 'pass' ? 'Clear' : c.severity === 'critical' ? 'Critical' : 'Review'}
                        </span>
                        <span className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#855b00]">{c.standard}</span>
                        <span className="ml-auto text-[9.5px] font-bold uppercase tracking-wider text-[#355875]">{c.area}</span>
                      </div>
                      <div className="mt-1.5 flex items-start gap-1.5 text-[12px] font-bold text-[#0a253e]">
                        {c.severity === 'pass' ? <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-700" /> : <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-700" />}
                        {c.title}
                      </div>
                      <p className="mt-1 text-[11px] leading-relaxed text-[#2d4f6d]">{c.detail}</p>
                      <p className="mt-1 rounded border border-sky-100 bg-white/80 px-2 py-1 text-[10.5px] italic text-[#355875]">
                        <span className="font-bold not-italic text-[#082f4f]">How to resolve: </span>{c.action}
                      </p>
                      {c.severity !== 'pass' && (
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          <button
                            type="button"
                            onClick={() => { setControlsOpen(false); onNavigate?.(target.section); }}
                            className="flex items-center gap-1 rounded bg-[#082f4f] px-2.5 py-1 text-[10.5px] font-bold text-white hover:bg-[#0c3f68]"
                          >
                            {target.label} <ArrowRight className="h-3 w-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => { setTab('compliance'); setControlsOpen(false); }}
                            className="rounded border border-sky-300 bg-white px-2.5 py-1 text-[10.5px] font-bold text-[#082f4f] hover:bg-sky-50"
                          >
                            Open the compliance tab
                          </button>
                        </div>
                      )}
                    </article>
                  );
                })}
              {(controlFilter === 'open' && failing.length === 0) && (
                <p className="rounded border border-emerald-300 bg-emerald-50 p-4 text-center text-xs font-bold text-emerald-900">
                  Every control check is clear for this period. The statements may be issued.
                </p>
              )}
            </div>
            <footer className="flex items-center justify-between gap-2 border-t border-sky-200 bg-sky-50 px-4 py-2 text-[10.5px] text-[#355875]">
              <span>Checks run against {lines.filter((l) => l.clientId === reportClient.id).length} posted journal lines.</span>
              <button type="button" onClick={() => { setControlsOpen(false); onNavigate?.('compliance_review'); }} className="font-bold text-[#082f4f] underline">
                Full compliance review
              </button>
            </footer>
          </div>
        </div>
      )}
    </div>
  );
}
