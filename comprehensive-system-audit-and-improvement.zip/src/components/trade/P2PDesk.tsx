import { useState } from 'react';
import { Plus, RefreshCw } from 'lucide-react';
import type { AccountMaster, BusinessPartner, ClientEntity, StockItem, UserAccount } from '../../types/accounting';
import { Card } from '../ui';
import { useTradeDesk, fmtMoney, type TradeDocument, type TradePayment } from '../../lib/tradeClient';
import { DeskNotice, DocumentDrawer, DocumentsTable, ModulePrintFooter, PaymentDeskRedirect, PaymentsTable, Pipeline, btnPrimary, btnSecondary, btnGreen, type LifecycleHandlers } from './TradeShared';
import { PeriodReportButton } from './PeriodActivityReport';
import { AllocateForm, FulfilmentForm, NoteForm, OrderForm, SupplierInvoiceForm } from './TradeForms';

type ModalState =
  | { kind: 'order'; docType: 'purchase_requisition' | 'purchase_order'; from?: TradeDocument }
  | { kind: 'grn'; order: TradeDocument }
  | { kind: 'sin'; source?: TradeDocument }
  | { kind: 'note'; invoice: TradeDocument }
  | { kind: 'pay'; invoice?: TradeDocument }
  | { kind: 'allocate'; payment?: TradePayment; doc?: TradeDocument }
  | null;

export interface P2PDeskProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  partners: BusinessPartner[];
  accounts: AccountMaster[];
  stockItems: StockItem[];
  defaultTaxRate: number;
  onServerMutation: () => Promise<void>;
  onSessionLost: () => void;
  /** Cash never leaves this desk — settlements are handed to the Payment Desk. */
  onNavigate?: (section: string) => void;
}

export function P2PDesk({ currentClient, currentUser, partners, accounts, stockItems, defaultTaxRate, onServerMutation, onSessionLost, onNavigate }: P2PDeskProps) {
  // Scoped load: only the purchasing lifecycle family is transferred and parsed.
  const desk = useTradeDesk({ clientId: currentClient.id, scope: 'p2p', onServerMutation, onSessionLost });
  const [modal, setModal] = useState<ModalState>(null);
  const [openDoc, setOpenDoc] = useState<TradeDocument | null>(null);
  const [view, setView] = useState<'orders' | 'receipts' | 'invoices' | 'payments'>('orders');
  const documents = desk.state?.documents || [];
  const payments = desk.state?.payments || [];
  const live = openDoc ? documents.find((d) => d.id === openDoc.id) || null : null;

  const requisitions = documents.filter((d) => d.docType === 'purchase_requisition');
  const orders = documents.filter((d) => d.docType === 'purchase_order');
  const receipts = documents.filter((d) => d.docType === 'goods_receipt');
  const invoices = documents.filter((d) => d.docType === 'supplier_invoice');
  const notes = documents.filter((d) => d.docType === 'supplier_credit_note' || d.docType === 'supplier_debit_note');
  const openPayable = invoices.filter((d) => ['Open', 'PartiallySettled'].includes(d.status)).reduce((s, d) => s + (d.openBalance || 0) * d.exchangeRate, 0);
  const grni = receipts.filter((d) => d.postedAt).reduce((s, d) => s + d.totalAmount * d.exchangeRate, 0) - invoices.filter((d) => d.postedAt).reduce((s, d) => s + d.netAmount * d.exchangeRate, 0);

  const handlers: LifecycleHandlers = {
    onConvert: (doc) => setModal({ kind: 'order', docType: 'purchase_order', from: doc }),
    onFulfil: (doc) => setModal({ kind: 'grn', order: doc }),
    onInvoice: (doc) => setModal({ kind: 'sin', source: doc }),
    onPay: (doc) => setModal({ kind: 'pay', invoice: doc }),
    onNote: (doc) => setModal({ kind: 'note', invoice: doc }),
    onAllocate: (doc) => setModal({ kind: 'allocate', doc }),
  };
  const openDocument = (doc: TradeDocument) => setOpenDoc(doc);

  if (desk.loading && !desk.state) {
    return <Card title="Procure-to-pay lifecycle" sub="Loading the server-held purchasing workspace…"><p className="text-xs text-[#355875]">Connecting to the firm&rsquo;s server…</p></Card>;
  }
  if (desk.loadError && !desk.state) {
    return (
      <Card title="Procure-to-pay lifecycle" sub="Server connection required">
        <p role="alert" className="text-xs font-bold text-rose-900">{desk.loadError}</p>
        <button onClick={() => void desk.refresh()} className={btnSecondary + ' mt-3'}>Retry</button>
      </Card>
    );
  }

  return (
    <div className="space-y-5">
      <DeskNotice notice={desk.notice} onDismiss={() => desk.setNotice(null)} />
      <Card title="Procure-to-pay pipeline" sub="Requisition → purchase order → goods receipt → supplier invoice (three-way match) → payment. Every posting is committed by the server in one transaction with stock, ledger and audit trail." action={
        <div className="flex flex-wrap gap-1.5">
          <button onClick={() => void desk.refresh()} disabled={desk.busy} className={btnSecondary} title="Reload from server"><RefreshCw className="inline h-3.5 w-3.5" /></button>
          <button onClick={() => setModal({ kind: 'order', docType: 'purchase_requisition' })} disabled={desk.busy} className={btnSecondary}><Plus className="inline h-3.5 w-3.5" /> Requisition</button>
          <button onClick={() => setModal({ kind: 'order', docType: 'purchase_order' })} disabled={desk.busy} className={btnPrimary}><Plus className="inline h-3.5 w-3.5" /> Purchase order</button>
          <button onClick={() => setModal({ kind: 'sin' })} disabled={desk.busy} className={btnSecondary}>Record supplier invoice</button>
          <button onClick={() => setModal({ kind: 'pay' })} disabled={desk.busy} className={btnGreen} title="Supplier payments are raised at the Payment Desk">Pay supplier</button>
        </div>
      }>
        <Pipeline steps={[
          { label: 'Requisitions', count: requisitions.filter((d) => !['Converted'].includes(d.status)).length, hint: `${requisitions.filter((d) => d.status === 'Submitted').length} awaiting approval` },
          { label: 'Purchase orders', count: orders.length, hint: `${orders.filter((d) => ['Approved', 'PartiallyReceived'].includes(d.status)).length} open for receipt` },
          { label: 'Goods receipts', count: receipts.length, hint: `${receipts.filter((d) => !d.postedAt).length} unposted` },
          { label: 'Supplier invoices', count: invoices.length, hint: `${invoices.filter((d) => ['Open', 'PartiallySettled'].includes(d.status)).length} open · ${currentClient.currency} ${fmtMoney(openPayable)}` },
          { label: 'Payments', count: payments.filter((p) => p.paymentType === 'supplier_payment').length, hint: `GRNI ${currentClient.currency} ${fmtMoney(Math.max(0, grni))}` },
        ]} />
        <div className="mt-4 flex flex-wrap gap-1 border-t border-sky-100 pt-3">
          {([['orders', `Requisitions & orders (${requisitions.length + orders.length})`], ['receipts', `Goods receipts (${receipts.length})`], ['invoices', `Supplier invoices & notes (${invoices.length + notes.length})`], ['payments', `Payments (${payments.filter((p) => p.paymentType === 'supplier_payment' || p.paymentType === 'reversal').length})`]] as const).map(([k, label]) => (
            <button key={k} onClick={() => setView(k)} className={`rounded px-3 py-1.5 text-[11px] font-bold ${view === k ? 'bg-[#082f4f] text-white' : 'bg-sky-50 text-[#082f4f] hover:bg-sky-100'}`}>{label}</button>
          ))}
        </div>
      </Card>

      {view === 'orders' && (
        <>
      <div id="p2p-orders" className="space-y-2">
          <DocumentsTable title="Purchase orders" sub="Approved orders authorise receipt; nothing posts to the ledger until goods or services are received." docs={orders} documents={documents} desk={desk} currentUser={currentUser} handlers={handlers} onOpen={openDocument} emptyText="No purchase orders yet — raise one above or convert an approved requisition." childType="goods_receipt" />
        <ModulePrintFooter targetId="p2p-orders" title={`Purchase order register — ${currentClient.name}`} subtitle={`${currentClient.code} · printed ${new Date().toISOString().slice(0, 10)}`} />
      </div>
      <div id="p2p-requisitions" className="space-y-2">
          <DocumentsTable title="Purchase requisitions" sub="Internal demand. Once approved, a requisition is converted into a purchase order (lines are carried across)." docs={requisitions} documents={documents} desk={desk} currentUser={currentUser} handlers={handlers} onOpen={openDocument} emptyText="No requisitions." />
        <ModulePrintFooter targetId="p2p-requisitions" title={`Purchase requisitions — ${currentClient.name}`} subtitle={`${currentClient.code} · printed ${new Date().toISOString().slice(0, 10)}`} />
      </div>
        </>
      )}
      {view === 'receipts' && (
      <div id="p2p-receipts" className="space-y-2">
        <DocumentsTable title="Goods receipts (GRN)" sub="Posting a receipt debits inventory / expense and credits 204000 GRNI; stock quantity, lots and carrying cost are updated in the same transaction." docs={receipts} documents={documents} desk={desk} currentUser={currentUser} handlers={handlers} onOpen={openDocument} emptyText="No goods receipts — open an approved purchase order and choose Receive goods." />
        <ModulePrintFooter targetId="p2p-receipts" title={`Goods received notes — ${currentClient.name}`} subtitle={`${currentClient.code} · printed ${new Date().toISOString().slice(0, 10)}`} />
      </div>
      )}
      {view === 'invoices' && (
        <>
      <div id="p2p-invoices" className="space-y-2">
          <DocumentsTable title="Supplier invoices" sub="Matched to receipts (price tolerance enforced, GRNI cleared, approved variances to 520000). Open balances are settled from Pay supplier." docs={invoices} documents={documents} desk={desk} currentUser={currentUser} handlers={handlers} onOpen={openDocument} emptyText="No supplier invoices recorded." actions={<PeriodReportButton side="procurement" client={currentClient} documents={documents} payments={payments} />} />
        <ModulePrintFooter targetId="p2p-invoices" title={`Supplier invoice register — ${currentClient.name}`} subtitle={`${currentClient.code} · printed ${new Date().toISOString().slice(0, 10)}`} />
      </div>
      <div id="p2p-notes" className="space-y-2">
          <DocumentsTable title="Supplier debit / credit notes" sub="Purchase returns and price reductions, linked to the original invoice and auto-applied to its open balance." docs={notes} documents={documents} desk={desk} currentUser={currentUser} handlers={handlers} onOpen={openDocument} emptyText="No supplier notes." />
        <ModulePrintFooter targetId="p2p-notes" title={`Supplier debit and credit notes — ${currentClient.name}`} subtitle={`${currentClient.code} · printed ${new Date().toISOString().slice(0, 10)}`} />
      </div>
        </>
      )}
      {view === 'payments' && (
      <div id="p2p-payments" className="space-y-2">
        <PaymentsTable title="Supplier payments" sub="Cash movements are posted against the chosen treasury account; unapplied amounts are supplier advances (116000) until applied." payments={payments} documents={documents} desk={desk} currentUser={currentUser} onAllocate={(p) => setModal({ kind: 'allocate', payment: p })} types={['supplier_payment']} />
        <ModulePrintFooter targetId="p2p-payments" title={`Supplier payment register — ${currentClient.name}`} subtitle={`${currentClient.code} · printed ${new Date().toISOString().slice(0, 10)}`} />
      </div>
      )}

      {live && <DocumentDrawer doc={live} documents={documents} desk={desk} currentUser={currentUser} handlers={{ ...handlers, onConvert: (d) => { setOpenDoc(null); handlers.onConvert?.(d); }, onFulfil: (d) => { setOpenDoc(null); handlers.onFulfil?.(d); }, onInvoice: (d) => { setOpenDoc(null); handlers.onInvoice?.(d); }, onPay: (d) => { setOpenDoc(null); handlers.onPay?.(d); }, onNote: (d) => { setOpenDoc(null); handlers.onNote?.(d); }, onAllocate: (d) => { setOpenDoc(null); handlers.onAllocate?.(d); } }} onClose={() => setOpenDoc(null)} />}
      {modal?.kind === 'order' && <OrderForm docType={modal.docType} fromDocument={modal.from} desk={desk} currentClient={currentClient} partners={partners} accounts={accounts} stockItems={stockItems} defaultTaxRate={defaultTaxRate} onClose={() => setModal(null)} />}
      {modal?.kind === 'grn' && <FulfilmentForm kind="goods_receipt" order={modal.order} desk={desk} documents={documents} onClose={() => setModal(null)} />}
      {modal?.kind === 'sin' && <SupplierInvoiceForm desk={desk} documents={documents} source={modal.source} currentClient={currentClient} defaultTaxRate={defaultTaxRate} onClose={() => setModal(null)} />}
      {modal?.kind === 'note' && <NoteForm kind="supplier_debit_note" invoice={modal.invoice} desk={desk} documents={documents} accounts={accounts} stockItems={stockItems} defaultTaxRate={defaultTaxRate} onClose={() => setModal(null)} />}
      {modal?.kind === 'pay' && (
        <PaymentDeskRedirect
          side="supplier"
          docNo={modal.invoice?.docNo}
          partyName={modal.invoice?.partyName}
          amount={modal.invoice?.openBalance ?? null}
          currency={modal.invoice?.currency || currentClient.currency}
          onClose={() => setModal(null)}
          onGo={() => { setModal(null); onNavigate?.('payment_desk'); }}
        />
      )}
      {modal?.kind === 'allocate' && (modal.payment || modal.doc) && <AllocateForm source={modal.payment ? { kind: 'payment', payment: modal.payment } : { kind: 'credit', doc: modal.doc! }} desk={desk} documents={documents} onClose={() => setModal(null)} />}
    </div>
  );
}
