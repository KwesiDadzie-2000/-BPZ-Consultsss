/**
 * BPZ Consult ERP — certified sector transaction suite.
 *
 * Runs professionally-standard transactions for each Ghanaian sector through the
 * SAME engines the application uses (tax, payroll, settlement, journal controls)
 * and asserts the statutory outcome. Every expectation is traceable to:
 *   • VAT Act 2025 (Act 1151) — VAT 15%, NHIL 2.5%, GETFund 2.5% on one base (20%);
 *     COVID-19 levy repealed; CST 5% cascades into the VAT base (s.15.3);
 *     Tourism Development Levy 1% outside the VAT base.
 *   • Income Tax Act 2015 (Act 896) First Schedule — resident WHT goods 3% / works 5% /
 *     services 7.5%; VAT withholding 7% by appointed agents; bonus 5% final tax ≤ 15%
 *     of annual basic; non-resident employment income 25% (Act 1007).
 *   • Act 1094 PAYE bands (Jan 2024 – Aug 2026) and Act 1178 bands (from 1 Sep 2026).
 *   • SSNIT Act 766 — 5.5% employee / 13% employer on insurable basic (2026 floor
 *     GHS 587.80, ceiling GHS 69,000); 13.5% Tier 1 + 5% Tier 2 remittance split.
 *   • IAS 1 / IAS 8 / ISA 330 — double entry, period integrity, segregation of duties.
 *
 * Run:  npx tsx src/tests/sectorTransactions.test.ts
 */
import { computeOutputLevies } from "../utils/taxConfig";
import { calculateSupplierSettlement, computeCustomerVatWithholding, computeExpenseVatSplit, computePoVat, isBalancedDocument } from "../utils/transactionMath";
import { calculateProgressivePaye, computeEmployeeMonthlyPayroll, currentPayeBands, splitQualifyingBonus } from "../utils/payrollCalculator";
import { validateJournalLines, validateMakerChecker, validatePostingIdentity, type PostingUserRecord } from "../lib/journalValidation";
import type { ACDOCALine, EmployeeProfile } from "../types/accounting";

let passed = 0;
let failed = 0;
const failures: string[] = [];

function check(name: string, actual: unknown, expected: unknown) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) passed += 1;
  else {
    failed += 1;
    failures.push(`${name}\n      expected ${JSON.stringify(expected)}\n      actual   ${JSON.stringify(actual)}`);
  }
  console.log(`${ok ? "  ✔" : "  ✘"} ${name}`);
}
const near = (n: number) => Math.round(n * 100) / 100;
const section = (title: string) => console.log(`\n${title}`);

/* ------------------------------------------------------------------ */
section("1. Mining & extractives (standard-rated supplies, services WHT, appointed VAT agent)");
{
  const sale = computeOutputLevies(1_000_000, {}, "2026-09-15");
  check("Gold sale GHS 1,000,000 → VAT 150,000 / NHIL 25,000 / GETFund 25,000 / COVID 0 / total 200,000", [sale.vat, sale.nhil, sale.getfund, sale.total], [150000, 25000, 25000, 200000]);
  const settlement = calculateSupplierSettlement({ invoiceGross: 120_000, invoiceTaxableValue: 100_000, alreadyPaid: 0, paymentGross: 120_000, incomeWhtRate: 7.5, vatWithholdingRate: 7 });
  check("Mine-site services bill 100,000 + 20% — settle in full: WHT 7,500, VAT WHT 7,000, cash 105,500", [settlement.incomeWht, settlement.vatWithheld, settlement.cash], [7500, 7000, 105500]);
  const partial = calculateSupplierSettlement({ invoiceGross: 120_000, invoiceTaxableValue: 100_000, alreadyPaid: 0, paymentGross: 60_000, incomeWhtRate: 7.5, vatWithholdingRate: 7 });
  check("50% part-payment prorates withholding: WHT 3,750, VAT WHT 3,500, cash 52,750, outstanding 60,000", [partial.incomeWht, partial.vatWithheld, partial.cash, partial.resultingOutstanding], [3750, 3500, 52750, 60000]);
  const goods = calculateSupplierSettlement({ invoiceGross: 240_000, invoiceTaxableValue: 200_000, alreadyPaid: 0, paymentGross: 240_000, incomeWhtRate: 3, vatWithholdingRate: 0 });
  check("Explosives (goods) 200,000 + VAT — resident goods WHT 3% = 6,000", goods.incomeWht, 6000);
  let threw = false;
  try { calculateSupplierSettlement({ invoiceGross: 120_000, invoiceTaxableValue: 100_000, alreadyPaid: 100_000, paymentGross: 30_000, incomeWhtRate: 7.5, vatWithholdingRate: 7 }); } catch { threw = true; }
  check("Over-payment of a supplier balance is refused", threw, true);
}

/* ------------------------------------------------------------------ */
section("2. Commercial agriculture (exempt produce, minimum-wage farm hand, inclusive-priced inputs)");
{
  const produce = computePoVat(500, 40, "none", 20);
  check("Raw cocoa purchase 500 × 40 — exempt: net 20,000, VAT 0, gross 20,000", [produce.net, produce.vat, produce.gross], [20000, 0, 20000]);
  const inputs = computePoVat(10, 1_200, "inclusive", 20);
  check("Fertiliser quoted VAT-inclusive 12,000 → net 10,000, VAT 2,000", [inputs.net, inputs.vat], [10000, 2000]);
  const farmHand: EmployeeProfile = { id: "E-AG1", bpNo: "BP-AG1", name: "Farm hand", department: "Field", role: "Labourer", basicSalary: 587.8, allowances: 0, isResident: true, jurisdiction: "GH", deductions: [] } as unknown as EmployeeProfile;
  const sep = computeEmployeeMonthlyPayroll({ employee: farmHand, period: "2026-09" });
  check("Minimum-wage earner Sep-2026: SSNIT 32.33, PAYE 0 (tax-free band 588)", [sep.ssnitTier1Employee, sep.payeTax], [32.33, 0]);
  const mar = computeEmployeeMonthlyPayroll({ employee: farmHand, period: "2026-03" });
  check("Same earner Mar-2026 (Act 1094, tax-free 490): PAYE 3.27", mar.payeTax, 3.27);
}

/* ------------------------------------------------------------------ */
section("3. Telecommunications (CST cascades into the VAT base — Act 1151 s.15.3)");
{
  const airtime = computeOutputLevies(1_000, { cst: true }, "2026-09-15");
  check("Airtime 1,000 → CST 50; VAT 157.50 / NHIL 26.25 / GETFund 26.25 on 1,050; total 260", [airtime.cst, airtime.vat, airtime.nhil, airtime.getfund, airtime.total], [50, 157.5, 26.25, 26.25, 260]);
}

/* ------------------------------------------------------------------ */
section("4. Hospitality & tourism (Tourism Development Levy 1% outside the VAT base)");
{
  const room = computeOutputLevies(1_000, { tourism: true }, "2026-09-15");
  check("Room night 1,000 → Tourism 10; VAT 150 / NHIL 25 / GETFund 25 on 1,000; total 210", [room.tourism, room.vat, room.nhil, room.getfund, room.total], [10, 150, 25, 25, 210]);
}

/* ------------------------------------------------------------------ */
section("5. Professional services (BPZ) — customer is an appointed VAT-withholding agent");
{
  const invoiceGross = 120_000; // 100,000 fee + 20%
  const invoiceWht = 7_000;     // 7% of taxable value withheld by the agent
  check("Full receipt of 113,000 captures the whole 7,000 VAT withheld", computeCustomerVatWithholding(invoiceWht, invoiceGross, invoiceGross, 113_000), 7000);
  const first = computeCustomerVatWithholding(invoiceWht, invoiceGross, invoiceGross, 56_500);
  check("Half receipt 56,500 → 3,500 withheld", first, 3500);
  const second = computeCustomerVatWithholding(invoiceWht, invoiceGross, invoiceGross - 56_500 - first, 56_500);
  check("Final receipt captures the remaining 3,500 exactly", second, 3500);
  const expense = computeExpenseVatSplit(2_400, true, 20);
  check("Office expense 2,400 VAT-inclusive → net 2,000, input VAT 400", [expense.net, expense.vat], [2000, 400]);
}

/* ------------------------------------------------------------------ */
section("6. Construction (works WHT 5%) and import trade (goods WHT 3%)");
{
  const works = calculateSupplierSettlement({ invoiceGross: 600_000, invoiceTaxableValue: 500_000, alreadyPaid: 0, paymentGross: 600_000, incomeWhtRate: 5, vatWithholdingRate: 0 });
  check("Sub-contractor works 500,000 + VAT → WHT 25,000, cash 575,000", [works.incomeWht, works.cash], [25000, 575000]);
  const goods = computePoVat(100, 850, "standard", 20);
  check("Imported machinery parts 100 × 850 standard-rated → VAT 17,000, gross 102,000", [goods.vat, goods.gross], [17000, 102000]);
}

/* ------------------------------------------------------------------ */
section("7. Payroll engine — statutory re-performance");
{
  const staff: EmployeeProfile = { id: "E1", bpNo: "BP1", name: "Accountant", department: "Finance", role: "Senior", basicSalary: 12_000, allowances: 0, isResident: true, jurisdiction: "GH", deductions: [] } as unknown as EmployeeProfile;
  const sep = computeEmployeeMonthlyPayroll({ employee: staff, period: "2026-09" });
  check("GHS 12,000 Sep-2026: SSNIT 660, chargeable 11,340, PAYE 2,439.50 (GRA worked example)", [sep.ssnitTier1Employee, sep.taxableIncome, sep.payeTax], [660, 11340, 2439.5]);
  const mar = computeEmployeeMonthlyPayroll({ employee: staff, period: "2026-03" });
  check("GHS 12,000 Mar-2026 on Act 1094 bands: PAYE 2,433.50", mar.payeTax, 2433.5);
  check("Band selection: Aug-2026 → Act 1094 (first 490); Sep-2026 → Act 1178 (first 588)", [currentPayeBands("2026-08-31")[1].lower, currentPayeBands("2026-09-30")[1].lower], [490, 588]);
  check("Top of the 17.5% band Sep-2026 (3,668) → 521.50", calculateProgressivePaye(3668, currentPayeBands("2026-09-30")), 521.5);
  check("Employer SSNIT 13% of 12,000 = 1,560; Tier 1 1,620 / Tier 2 600 / NHIA 300", [sep.ssnitEmployerCost, sep.ssnitTier1Allocation, sep.ssnitTier2Allocation, sep.nhiaRemittance], [1560, 1620, 600, 300]);
  const high = computeEmployeeMonthlyPayroll({ employee: { ...staff, basicSalary: 80_000 }, period: "2026-09" });
  check("Basic 80,000 capped at 69,000 insurable: employee 3,795, employer 8,970", [high.ssnitTier1Employee, high.ssnitEmployerCost], [3795, 8970]);
  const bonus = splitQualifyingBonus(12_000, 30_000);
  check("Bonus 30,000 vs cap 21,600: qualifying 21,600 @5% = 1,080; excess 8,400 to graduated", [bonus.qualifying, bonus.finalTax, bonus.excess], [21600, 1080, 8400]);
  const withBonus = computeEmployeeMonthlyPayroll({ employee: staff, period: "2026-09", bonusAdditions: 30_000 });
  check("Payslip with 30,000 bonus: chargeable 19,740, PAYE 5,623.10 (incl. 1,080 final tax)", [withBonus.taxableIncome, withBonus.payeTax, withBonus.bonusFinalTax], [19740, 5623.1, 1080]);
  const nonRes = computeEmployeeMonthlyPayroll({ employee: { ...staff, isResident: false }, period: "2026-09" });
  check("Non-resident GHS 12,000 → flat 25% = 3,000, no reliefs", nonRes.payeTax, 3000);
  check("Net pay chain reconciles: gross − deductions = net", near(sep.grossPay - sep.totalEmployeeDeductions), sep.netSalary);
}

/* ------------------------------------------------------------------ */
section("8. Posting controls — double entry, period integrity, segregation of duties");
{
  const base = (over: Partial<ACDOCALine>): ACDOCALine => ({
    id: "L", docNo: "JE-1", period: "2026-09", date: "2026-09-15", module: "FI", docType: "JE", accountNo: "100000", accountName: "Cash",
    debit: 0, credit: 0, currency: "GHS", description: "test", createdBy: "demo", clientId: 2, ...over,
  } as ACDOCALine);
  const ctx = { allowedClientIds: [2], closedPeriodKeys: new Set(["2:2026-01"]), coaAccountNos: new Set(["100000", "400000", "999000"]), isAccountPostable: (no: string) => no !== "999000" };
  const ok = [base({ id: "a", debit: 100 }), base({ id: "b", accountNo: "400000", credit: 100 })];
  check("Balanced two-line document passes", validateJournalLines(ok, ctx), null);
  check("Unbalanced document rejected", validateJournalLines([base({ id: "a", debit: 100 }), base({ id: "b", accountNo: "400000", credit: 90 })], ctx) !== null, true);
  check("Single line carrying both Dr and Cr rejected", validateJournalLines([base({ id: "a", debit: 100, credit: 100 })], ctx) !== null, true);
  check("Mixed currencies within a document rejected", validateJournalLines([ok[0], { ...ok[1], currency: "USD" }], ctx) !== null, true);
  check("Mixed periods within a document rejected", validateJournalLines([ok[0], { ...ok[1], period: "2026-08" }], ctx) !== null, true);
  check("Invalid calendar date rejected", validateJournalLines(ok.map((l) => ({ ...l, date: "2026-02-30" })), ctx) !== null, true);
  check("Closed period rejected", validateJournalLines(ok.map((l) => ({ ...l, period: "2026-01" })), ctx) !== null, true);
  check("Inactive account rejected", validateJournalLines([ok[0], { ...ok[1], accountNo: "999000" }], ctx) !== null, true);
  check("Cross-tenant line rejected", validateJournalLines(ok.map((l) => ({ ...l, clientId: 1 })), ctx) !== null, true);

  const users = new Map<string, PostingUserRecord>([
    ["demo", { username: "demo", role: "accountant", makerLimit: 25_000, canCheck: false, status: "active" }],
    ["checker_kofi", { username: "checker_kofi", role: "manager", makerLimit: 150_000, canCheck: true, status: "active" }],
    ["owner", { username: "owner", role: "owner", makerLimit: 1_000_000, canCheck: true, status: "active" }],
    ["suspended_sam", { username: "suspended_sam", role: "manager", makerLimit: 0, canCheck: true, status: "suspended" }],
  ]);
  const demo = users.get("demo")!;
  const kofi = users.get("checker_kofi")!;
  const big = [base({ id: "a", debit: 90_000 }), base({ id: "b", accountNo: "400000", credit: 90_000 })];
  check("Maker posts own document under limit", validatePostingIdentity(ok, { session: demo, users }), null);
  check("Spoofed createdBy (another user) is refused for the session", validatePostingIdentity(ok.map((l) => ({ ...l, createdBy: "owner" })), { session: demo, users }) !== null, true);
  check("Unknown maker refused", validatePostingIdentity(ok.map((l) => ({ ...l, createdBy: "ghost" })), { session: demo, users }) !== null, true);
  check("Checker named on the document may post it on the maker's behalf", validatePostingIdentity(big.map((l) => ({ ...l, checkedBy: "checker_kofi" })), { session: kofi, users }), null);
  check("Ghost checker refused", validatePostingIdentity(big.map((l) => ({ ...l, checkedBy: "ghost" })), { session: demo, users }) !== null, true);
  check("Suspended checker refused", validatePostingIdentity(big.map((l) => ({ ...l, checkedBy: "suspended_sam" })), { session: demo, users }) !== null, true);
  check("Over maker limit without checker refused", validateMakerChecker(big, { username: "demo", makerLimit: 25_000, users }) !== null, true);
  check("Over maker limit, self-checked refused", validateMakerChecker(big.map((l) => ({ ...l, checkedBy: "demo" })), { username: "demo", makerLimit: 25_000, users }) !== null, true);
  check("Over maker limit with independent authorised checker passes", validateMakerChecker(big.map((l) => ({ ...l, checkedBy: "checker_kofi" })), { username: "demo", makerLimit: 25_000, users }), null);
  check("Maker's OWN limit governs even when a higher-limit user submits", validateMakerChecker(big, { username: "owner", makerLimit: 1_000_000, users }) !== null, true);
  check("isBalancedDocument helper agrees", isBalancedDocument(ok), true);
}

/* ------------------------------------------------------------------ */
console.log(`\n${passed} passed, ${failed} failed`);
if (failed) {
  console.log("\nFailures:");
  for (const f of failures) console.log(`  - ${f}`);
  process.exit(1);
}
