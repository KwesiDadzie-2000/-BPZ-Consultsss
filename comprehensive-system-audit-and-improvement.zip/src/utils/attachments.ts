/**
 * Supporting-document attachments.
 *
 * Attachments are evidence, not accounting data: they are kept out of the
 * ledger and out of Postgres (base64 blobs in an accounting table break at
 * enterprise scale and make every state sync expensive). Each file is stored in
 * the browser's IndexedDB against the document it supports, with strict type
 * and size limits so a failed upload always returns a readable reason instead
 * of silently doing nothing.
 */

export interface AttachmentMeta {
  id: string;
  clientId: number;
  /** Ledger / trade document this evidence belongs to (invoice, GRN, journal…). */
  docId: string;
  docNo: string;
  name: string;
  mime: string;
  size: number;
  addedAt: string;
  addedBy: string;
}

interface StoredAttachment extends AttachmentMeta {
  blob: Blob;
}

export const ATTACHMENT_LIMITS = {
  maxFileBytes: 4 * 1024 * 1024,
  maxFilesPerDocument: 8,
  acceptedExtensions: ['pdf', 'png', 'jpg', 'jpeg', 'webp', 'csv', 'xlsx', 'docx', 'txt'],
} as const;

const DB_NAME = 'bpz-attachments';
const STORE = 'documents';
const DB_VERSION = 1;

export class AttachmentError extends Error {}

const openDb = (): Promise<IDBDatabase> =>
  new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new AttachmentError('This browser cannot store attachments locally. Use a current browser or attach the evidence in the document management system.'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, { keyPath: 'id' });
        store.createIndex('docId', 'docId', { unique: false });
        store.createIndex('clientId', 'clientId', { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new AttachmentError('The local attachment store could not be opened.'));
    request.onblocked = () => reject(new AttachmentError('The attachment store is locked by another tab. Close other tabs and try again.'));
  });

const txDone = (tx: IDBTransaction): Promise<void> =>
  new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(new AttachmentError(tx.error?.message || 'The attachment could not be saved.'));
    tx.onabort = () => reject(new AttachmentError(tx.error?.message || 'The attachment save was aborted.'));
  });

const readAll = <T,>(request: IDBRequest<T[]>): Promise<T[]> =>
  new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result ?? []);
    request.onerror = () => reject(new AttachmentError('The stored attachments could not be read.'));
  });

const stripBlob = ({ blob: _blob, ...meta }: StoredAttachment): AttachmentMeta => meta;

export function validateAttachment(file: File, existingCount: number): string | null {
  if (!file || file.size === 0) return 'The selected file is empty. Choose the actual supporting document.';
  if (file.size > ATTACHMENT_LIMITS.maxFileBytes) {
    return `${file.name} is ${(file.size / (1024 * 1024)).toFixed(1)} MB. The limit per supporting document is ${ATTACHMENT_LIMITS.maxFileBytes / (1024 * 1024)} MB — compress the file or attach the signed page only.`;
  }
  const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
  if (!(ATTACHMENT_LIMITS.acceptedExtensions as readonly string[]).includes(ext)) {
    return `${file.name} is not an accepted evidence file. Allowed: ${ATTACHMENT_LIMITS.acceptedExtensions.join(', ')}.`;
  }
  if (existingCount >= ATTACHMENT_LIMITS.maxFilesPerDocument) {
    return `This document already holds ${ATTACHMENT_LIMITS.maxFilesPerDocument} attachments. Remove a superseded file before adding another.`;
  }
  return null;
}

const newId = () =>
  `att_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;

export async function addAttachment(input: {
  file: File;
  clientId: number;
  docId: string;
  docNo: string;
  addedBy: string;
}): Promise<AttachmentMeta> {
  const db = await openDb();
  try {
    const existing = await listAttachments(input.clientId, input.docId);
    const invalid = validateAttachment(input.file, existing.length);
    if (invalid) throw new AttachmentError(invalid);

    const duplicate = existing.find((a) => a.name === input.file.name && a.size === input.file.size);
    if (duplicate) {
      throw new AttachmentError(`${input.file.name} is already attached to ${input.docNo}. Remove the old copy first if you are replacing it.`);
    }

    const record: StoredAttachment = {
      id: newId(),
      clientId: input.clientId,
      docId: input.docId,
      docNo: input.docNo,
      name: input.file.name,
      mime: input.file.type || 'application/octet-stream',
      size: input.file.size,
      addedAt: new Date().toISOString(),
      addedBy: input.addedBy,
      blob: input.file,
    };
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(record);
    await txDone(tx);
    return stripBlob(record);
  } catch (error) {
    if (error instanceof AttachmentError) throw error;
    const quota = error instanceof DOMException && (error.name === 'QuotaExceededError' || error.name === 'NS_ERROR_DOM_QUOTA_REACHED');
    throw new AttachmentError(quota
      ? 'The browser has no storage space left for attachments. Remove superseded files, then try again.'
      : 'The attachment could not be saved. Try again, or attach a smaller file.');
  } finally {
    db.close();
  }
}

export async function listAttachments(clientId: number, docId?: string): Promise<AttachmentMeta[]> {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE, 'readonly');
    const store = tx.objectStore(STORE);
    const rows = await readAll<StoredAttachment>(docId ? store.index('docId').getAll(docId) : store.index('clientId').getAll(clientId));
    return rows
      .filter((r) => r.clientId === clientId && (!docId || r.docId === docId))
      .map(stripBlob)
      .sort((a, b) => b.addedAt.localeCompare(a.addedAt));
  } finally {
    db.close();
  }
}

export async function deleteAttachment(id: string): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    await txDone(tx);
  } finally {
    db.close();
  }
}

/** Opens the evidence in a new tab (PDFs/images render inline) or downloads it. */
export async function openAttachment(id: string): Promise<void> {
  const db = await openDb();
  try {
    const record = await new Promise<StoredAttachment | undefined>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const request = tx.objectStore(STORE).get(id);
      request.onsuccess = () => resolve(request.result as StoredAttachment | undefined);
      request.onerror = () => reject(new AttachmentError('The attachment could not be read.'));
    });
    if (!record) throw new AttachmentError('This attachment is no longer stored on this device.');
    const url = URL.createObjectURL(record.blob);
    const win = window.open(url, '_blank', 'noopener,noreferrer');
    if (!win) {
      const link = document.createElement('a');
      link.href = url;
      link.download = record.name;
      link.click();
    }
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
  } finally {
    db.close();
  }
}

export const formatBytes = (bytes: number): string => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};
