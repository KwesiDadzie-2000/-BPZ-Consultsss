import { EmployeeProfile, MonthlyPayrollRecord, PayrollDeductionConfig } from '../types/accounting';
import { PAYE_BANDS_ACT_1094, taxConfigStore } from './taxConfig';

export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export interface PayeBandMonthly {
  lower: number;
  upper: number | null;
  rate: number; // percentage e.g. 5 for 5%
}

/**
 * Ghana GRA Statutory Monthly PAYE Progressive Bands (Income Tax (Amendment) Act, 2026 — Act 1178,
 * effective 1 September 2026, per the official GRA schedule):
 * - FIRST 588.00: 0.00%
 * - NEXT 80.00: 5.00% (Cumulative 588 - 668)
 * - NEXT 100.00: 10.00% (Cumulative 668 - 768)
 * - NEXT 2,900.00: 17.50% (Cumulative 768 - 3,668)
 * - NEXT 16,000.00: 25.00% (Cumulative 3,668 - 19,668)
 * - NEXT 30,332.00: 30.00% (Cumulative 19,668 - 50,000)
 * - EXCEEDING 50,000.00: 35.00%
 */
export const GHANA_PAYE_BANDS_MONTHLY: PayeBandMonthly[] = [
  { lower: 0, upper: 588, rate: 0.0 },
  { lower: 588, upper: 668, rate: 5.0 },
  { lower: 668, upper: 768, rate: 10.0 },
  { lower: 768, upper: 3668, rate: 17.5 },
  { lower: 3668, upper: 19668, rate: 25.0 },
  { lower: 19668, upper: 50000, rate: 30.0 },
  { lower: 50000, upper: null, rate: 35.0 },
];

export const GHANA_PAYE_TABLE_DISPLAY = [
  { bracket: 'FIRST', amount: 588, cumulative: 588, rate: '0.00%', maxTax: 0.0 },
  { bracket: 'NEXT', amount: 80, cumulative: 668, rate: '5.00%', maxTax: 4.0 },
  { bracket: 'NEXT', amount: 100, cumulative: 768, rate: '10.00%', maxTax: 10.0 },
  { bracket: 'NEXT', amount: 2900, cumulative: 3668, rate: '17.50%', maxTax: 507.5 },
  { bracket: 'NEXT', amount: 16000, cumulative: 19668, rate: '25.00%', maxTax: 4000.0 },
  { bracket: 'NEXT', amount: 30332, cumulative: 50000, rate: '30.00%', maxTax: 9099.6 },
  { bracket: 'EXCEEDING', amount: 50000, cumulative: null, rate: '35.00%', maxTax: null },
];

/* ============================================================================
 * SSNIT statutory framework (SSNIT Act 766 as amended by Acts 789/883;
 * official SSNIT contribution rates, 2026 insurable-earnings band):
 *
 *  - Combined mandatory contribution: 18.5% of BASIC SALARY only
 *      · Employee share: 5.5% of basic  (deducted from the worker's salary)
 *      · Employer share: 13.0% of basic (employer cost, on top of wages)
 *  - Remittance split of the combined 18.5%:
 *      · 13.5% → SSNIT (mandatory Tier 1 Basic National Social Security
 *        Scheme), remitted within 14 days after month end; of this 13.5%,
 *        2.5% is forwarded by SSNIT to NHIA (National Health Insurance
 *        Authority) for the member's health cover.
 *      · 5.0% → the worker's mandatory Tier 2 privately-managed occupational
 *        pension scheme (licensed trustee). The Tier 2 5% is a mandatory
 *        component of the 18.5% — it is funded from the combined
 *        contribution, not deducted additionally from the worker's pay.
 *  - 2026 insurable-earnings band (effective 1 Jan 2026):
 *      minimum GHS 587.80 / maximum GHS 69,000 per month.
 * ========================================================================== */
export const SSNIT_MIN_INSURABLE_EARNINGS = 587.8;
export const SSNIT_MAX_INSURABLE_EARNINGS = 69000;
export const SSNIT_EMPLOYEE_RATE = 5.5;   // % of insurable basic salary
export const SSNIT_EMPLOYER_RATE = 13.0;  // % of insurable basic salary
export const SSNIT_TIER1_ALLOCATION_RATE = 13.5; // % of insurable basic → SSNIT
export const SSNIT_TIER2_ALLOCATION_RATE = 5.0;  // % of insurable basic → Tier 2 trustee (mandatory)
export const NHIA_FORWARD_RATE = 2.5;    // % of insurable basic → NHIA (routed via the 13.5%)

/** 2026 SSNIT insurable base: clamped to the statutory minimum/maximum. */
export const ssnitInsurableBaseFor = (basicSalary: number): number =>
  round2(Math.min(Math.max(basicSalary, SSNIT_MIN_INSURABLE_EARNINGS), SSNIT_MAX_INSURABLE_EARNINGS));

/** Act 1094 monthly bands (1 Jan 2024 – 31 Aug 2026) — statutory fallback for periods before Act 1178. */
export const GHANA_PAYE_BANDS_MONTHLY_ACT_1094: PayeBandMonthly[] = PAYE_BANDS_ACT_1094.map((b) => ({ lower: b.from, upper: b.to, rate: b.rate }));

/** Act 1178 took effect on 1 September 2026 (GRA notice); earlier periods use Act 1094. */
export const ACT_1178_EFFECTIVE_FROM = '2026-09-01';

/** Flat PAYE rate on the employment income of a non-resident individual (Act 896 First Schedule para 2, as amended by Act 1007). */
export const NON_RESIDENT_PAYE_RATE = 25;

/**
 * Bonus taxation (Act 896 s.6 / Income Tax Regulations 2016 (L.I. 2244) reg. 6):
 * a bonus of up to 15% of the employee's ANNUAL basic salary is taxed at a 5% final
 * rate and excluded from chargeable income; any excess is added to employment income
 * and taxed at the graduated rates.
 */
export const QUALIFYING_BONUS_CAP_PCT_OF_ANNUAL_BASIC = 15;
export const QUALIFYING_BONUS_FINAL_TAX_RATE = 5;

export function currentPayeBands(onDate = new Date().toISOString().slice(0, 10)): PayeBandMonthly[] {
  const eligible = taxConfigStore.get().payeBands.filter((b) => b.isActive && b.effectiveFrom <= onDate);
  if (!eligible.length) return onDate < ACT_1178_EFFECTIVE_FROM ? GHANA_PAYE_BANDS_MONTHLY_ACT_1094 : GHANA_PAYE_BANDS_MONTHLY;
  const latestEffectiveFrom = eligible.map((b) => b.effectiveFrom).sort().at(-1)!;
  return eligible
    .filter((b) => b.effectiveFrom === latestEffectiveFrom)
    .sort((a, b) => a.from - b.from)
    .map((b) => ({ lower: b.from, upper: b.to, rate: b.rate }));
}

const periodEndDate = (period: string): string => {
  const [year, month] = period.split('-').map(Number);
  return new Date(Date.UTC(year, month, 0)).toISOString().slice(0, 10);
};

export function calculateProgressivePaye(taxableIncome: number, bands: PayeBandMonthly[] = currentPayeBands()): number {
  if (taxableIncome <= 0) return 0;
  let tax = 0;
  for (const b of bands) {
    if (taxableIncome <= b.lower) break;
    const bracketCap = b.upper === null ? taxableIncome : Math.min(taxableIncome, b.upper);
    const taxableInBracket = bracketCap - b.lower;
    tax += (taxableInBracket * b.rate) / 100;
  }
  return round2(tax);
}

/** Splits a bonus into the 5%-final-tax qualifying portion and the excess that joins chargeable income. */
export function splitQualifyingBonus(basicMonthly: number, bonus: number, priorBonusThisYear = 0) {
  const b = Math.max(0, round2(bonus));
  if (b <= 0) return { qualifying: 0, excess: 0, finalTax: 0 };
  const annualCap = round2((Math.max(0, basicMonthly) * 12 * QUALIFYING_BONUS_CAP_PCT_OF_ANNUAL_BASIC) / 100);
  const remainingCap = Math.max(0, round2(annualCap - Math.max(0, priorBonusThisYear)));
  const qualifying = round2(Math.min(b, remainingCap));
  const excess = round2(b - qualifying);
  return { qualifying, excess, finalTax: round2((qualifying * QUALIFYING_BONUS_FINAL_TAX_RATE) / 100) };
}

/**
 * Computes a comprehensive payroll record for an employee for a specific period.
 *
 * Ghana 2026 statutory model:
 *  - SSNIT 18.5% of basic (insurable band): 5.5% employee deduction + 13% employer cost.
 *    Remittance: 13.5% to SSNIT Tier 1 (incl. 2.5% forwarded to NHIA) + mandatory 5%
 *    to the Tier 2 occupational trustee. The Tier 2 5% is part of the 18.5%, so it is
 *    never a separate deduction from the worker's salary.
 *  - PAYE on chargeable income (gross − 5.5% SSNIT − allowable reliefs) using the
 *    GRA graduated bands in force for the period (Act 1094 to Aug 2026, Act 1178 from
 *    1 Sep 2026); non-resident individuals are taxed 25% flat on gross (Act 1007).
 */
export function computeEmployeeMonthlyPayroll(params: {
  employee: EmployeeProfile;
  period: string;
  basicSalary?: number;
  allowances?: number;
  bonusAdditions?: number;
  /** Bonus already paid to this employee earlier in the same calendar year (for the 15% annual cap). */
  priorBonusThisYear?: number;
  taxRelief?: number;
  reliefType?: string;
  isResident?: boolean;
  exemptTier1?: boolean;
  exemptTier2?: boolean;
  ssnitExempt?: boolean;
  ssnitExemptionReason?: string;
  deductions?: PayrollDeductionConfig[];
}): MonthlyPayrollRecord {
  const { employee, period } = params;

  const basic = round2(params.basicSalary ?? employee.basicSalary ?? 0);
  const allowances = round2(params.allowances ?? employee.allowances ?? 0);
  const bonuses = round2(params.bonusAdditions ?? 0);
  const grossPay = round2(basic + allowances + bonuses);

  const isResident = params.isResident ?? employee.isResident ?? true;
  const ssnitExempt = params.ssnitExempt ?? employee.ssnitExempt ?? false;
  const exemptT1 = ssnitExempt || (params.exemptTier1 ?? employee.exemptTier1 ?? false);
  const exemptT2 = ssnitExempt || (params.exemptTier2 ?? employee.exemptTier2 ?? false);

  // 1. Statutory SSNIT contributions — on BASIC salary within the 2026 insurable band.
  const insurableBase = ssnitExempt ? 0 : ssnitInsurableBaseFor(basic);
  // Employee's mandatory deduction: 5.5% of the insurable basic salary.
  const ssnitT1 = exemptT1 ? 0 : round2((insurableBase * SSNIT_EMPLOYEE_RATE) / 100);
  // Employer's mandatory cost: 13% of the insurable basic salary.
  const ssnitEmployer = exemptT1 ? 0 : round2((insurableBase * SSNIT_EMPLOYER_RATE) / 100);
  // Remittance allocation of the combined 18.5%:
  // 13.5% → SSNIT Tier 1 (of which 2.5% is forwarded by SSNIT to NHIA);
  // 5%    → mandatory Tier 2 occupational trustee.
  const ssnitTier1Allocation = exemptT1 ? 0 : round2((insurableBase * SSNIT_TIER1_ALLOCATION_RATE) / 100);
  const nhiaRemittance = exemptT1 ? 0 : round2((insurableBase * NHIA_FORWARD_RATE) / 100);
  const ssnitTier2Allocation = exemptT2 ? 0 : round2((insurableBase * SSNIT_TIER2_ALLOCATION_RATE) / 100);
  // Kept for backwards compatibility with stored payslips: the worker no longer bears a
  // separate Tier 2 deduction — the 5% is funded inside the combined 18.5% remittance.
  const ssnitT2 = 0;

  // 2. Personal & Statutory Reliefs (Marriage, Child education, Old age, Disability)
  const allowableRelief = isResident ? Math.max(0, params.taxRelief ?? employee.taxRelief ?? 0) : 0;

  // 3. Taxable Income & PAYE Calculation
  let taxableIncome = 0;
  let payeTax = 0;

  // Qualifying bonus (Act 896 s.6): up to 15% of annual basic, net of any bonus already
  // paid this year, is taxed at the 5% final rate; the excess joins chargeable income.
  const bonusSplit = splitQualifyingBonus(basic, bonuses, params.priorBonusThisYear ?? 0);
  const bonusFinalTax = isResident ? bonusSplit.finalTax : 0;
  const bonusInChargeable = isResident ? bonusSplit.excess : bonuses;

  if (isResident) {
    // Under Act 896, the employee's SSNIT pension contribution (5.5%) and personal
    // reliefs are deductible from chargeable income.
    taxableIncome = Math.max(0, round2(basic + allowances + bonusInChargeable - ssnitT1 - allowableRelief));
    payeTax = round2(calculateProgressivePaye(taxableIncome, currentPayeBands(periodEndDate(period))) + bonusFinalTax);
  } else {
    // Non-resident individual: employment income taxed at a flat 25% (Act 896 First
    // Schedule para 2 as amended by Act 1007) on gross, with no reliefs.
    taxableIncome = grossPay;
    payeTax = round2((grossPay * NON_RESIDENT_PAYE_RATE) / 100);
  }

  // 4. Custom Deductions evaluated on Gross, Basic, or Net
  const activeDeductions = params.deductions ?? employee.deductions ?? [];
  const computedCustomDeductions: {
    id: string;
    name: string;
    base: 'gross' | 'basic' | 'net';
    amount: number;
  }[] = [];

  let totalCustomDeductions = 0;

  activeDeductions.forEach((d) => {
    let amt = 0;
    if (d.base === 'gross') {
      const pctPart = d.ratePct ? (grossPay * d.ratePct) / 100 : 0;
      amt = round2(pctPart + (d.fixedAmount || 0));
    } else if (d.base === 'basic') {
      const pctPart = d.ratePct ? (basic * d.ratePct) / 100 : 0;
      amt = round2(pctPart + (d.fixedAmount || 0));
    } else {
      // Net base: fixed amount or percentage of post-tax net
      const provisionalNet = Math.max(0, grossPay - ssnitT1 - ssnitT2 - payeTax);
      const pctPart = d.ratePct ? (provisionalNet * d.ratePct) / 100 : 0;
      amt = round2(pctPart + (d.fixedAmount || 0));
    }
    amt = Math.max(0, amt);
    computedCustomDeductions.push({
      id: d.id,
      name: d.name,
      base: d.base,
      amount: amt,
    });
    totalCustomDeductions += amt;
  });

  totalCustomDeductions = round2(totalCustomDeductions);

  // 5. Total Employee Deductions & Net Salary
  const totalEmployeeDeductions = round2(ssnitT1 + ssnitT2 + payeTax + totalCustomDeductions);
  const netSalary = round2(grossPay - totalEmployeeDeductions);
  const employerTotalCost = round2(grossPay + ssnitEmployer);

  return {
    id: `PAY-${period}-${employee.bpNo}`,
    employeeId: employee.id,
    bpNo: employee.bpNo,
    name: employee.name,
    department: employee.department,
    role: employee.role,
    period,
    currency: employee.jurisdiction === 'GB' ? 'GBP' : employee.jurisdiction === 'US' ? 'USD' : 'GHS',
    isResident,
    exemptTier1: exemptT1,
    exemptTier2: exemptT2,
    ssnitExempt,
    ssnitExemptionReason: params.ssnitExemptionReason ?? employee.ssnitExemptionReason,
    basicSalary: basic,
    allowances,
    bonusAdditions: bonuses,
    grossPay,
    taxRelief: allowableRelief,
    reliefType: params.reliefType ?? employee.reliefType ?? 'Personal Relief',
    ssnitInsurableBase: insurableBase,
    ssnitTier1Employee: ssnitT1,
    ssnitTier2Employee: ssnitT2,
    ssnitEmployerCost: ssnitEmployer,
    ssnitTier1Allocation,
    ssnitTier2Allocation,
    nhiaRemittance,
    taxableIncome,
    payeTax,
    bonusFinalTax,
    qualifyingBonus: isResident ? bonusSplit.qualifying : 0,
    customDeductions: computedCustomDeductions,
    totalCustomDeductions,
    totalEmployeeDeductions,
    netSalary,
    employerTotalCost,
    status: 'Draft',
  };
}

/**
 * One-time migration for payroll records saved under the pre-2026 model (SSNIT on
 * gross pay, an extra 5% "Tier 2 employee" deduction and the mislabelled 13%
 * employer line). Recomputes the statutory SSNIT fields, the PAYE taxable base and
 * the net-pay chain from the stored inputs so old payslips reconcile to the
 * statutory model. Records that already carry the 2026 fields pass through unchanged.
 */
export function normalizePayrollRecord(r: MonthlyPayrollRecord): MonthlyPayrollRecord {
  const hasNewFields =
    typeof r.ssnitInsurableBase === 'number' &&
    typeof r.ssnitTier1Allocation === 'number' &&
    typeof r.ssnitTier2Allocation === 'number' &&
    typeof r.nhiaRemittance === 'number';
  if (hasNewFields) return r;

  const exemptT1 = !!r.ssnitExempt || !!r.exemptTier1;
  const exemptT2 = !!r.ssnitExempt || !!r.exemptTier2;
  const base = r.ssnitExempt ? 0 : ssnitInsurableBaseFor(r.basicSalary || 0);
  const t1 = exemptT1 ? 0 : round2((base * SSNIT_EMPLOYEE_RATE) / 100);
  const employer = exemptT1 ? 0 : round2((base * SSNIT_EMPLOYER_RATE) / 100);
  const t1Alloc = exemptT1 ? 0 : round2((base * SSNIT_TIER1_ALLOCATION_RATE) / 100);
  const t2Alloc = exemptT2 ? 0 : round2((base * SSNIT_TIER2_ALLOCATION_RATE) / 100);
  const nhia = exemptT1 ? 0 : round2((base * NHIA_FORWARD_RATE) / 100);

  // PAYE on the statutory base: gross − 5.5% SSNIT − allowable reliefs (residents).
  let payeTax: number;
  if (r.isResident) {
    const taxable = Math.max(0, round2(r.grossPay - t1 - (r.taxRelief || 0)));
    payeTax = calculateProgressivePaye(taxable, currentPayeBands(periodEndDate(r.period)));
  } else {
    payeTax = round2((r.grossPay * NON_RESIDENT_PAYE_RATE) / 100);
  }

  const totalDeductions = round2(t1 + payeTax + (r.totalCustomDeductions || 0));
  return {
    ...r,
    ssnitInsurableBase: base,
    ssnitTier1Employee: t1,
    ssnitTier2Employee: 0,
    ssnitEmployerCost: employer,
    ssnitTier1Allocation: t1Alloc,
    ssnitTier2Allocation: t2Alloc,
    nhiaRemittance: nhia,
    payeTax,
    totalEmployeeDeductions: totalDeductions,
    netSalary: round2(r.grossPay - totalDeductions),
    employerTotalCost: round2(r.grossPay + employer),
  };
}
