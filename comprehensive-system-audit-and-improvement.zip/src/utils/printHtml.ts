/**
 * Stand-alone HTML printing.
 *
 * `printReport()` prints tabular working papers in the suite's blue house
 * style. The statutory IFRS pack is a different artefact: a bound set of
 * financial statements that must look like a document prepared for filing,
 * so it carries its own typesetting (serif headings, hairline rules, boxed
 * statutory captions, tabular figures). This helper only does the mechanical
 * part — put that HTML on paper without printing the application shell.
 */

let openDocuments = 0;

/**
 * Renders `html` into a hidden, self-contained iframe and prints it.
 * Falls back to a pop-up window when the browser refuses iframes (some
 * hardened enterprise browsers do) and, as a last resort, to `window.print()`
 * of a thrown-together document so the operator is never left with nothing.
 */
export function printHtmlDocument(html: string, title = 'Report'): void {
  const frame = document.createElement('iframe');
  frame.setAttribute('aria-hidden', 'true');
  frame.style.position = 'fixed';
  frame.style.right = '0';
  frame.style.bottom = '0';
  frame.style.width = '0';
  frame.style.height = '0';
  frame.style.border = '0';
  frame.style.opacity = '0';
  const token = ++openDocuments;

  const cleanup = () => {
    try {
      frame.contentWindow?.close();
    } catch {
      /* ignore */
    }
    frame.remove();
    openDocuments = Math.max(0, openDocuments - 1);
    void token;
  };

  frame.onload = () => {
    const doc = frame.contentDocument;
    if (!doc) {
      cleanup();
      printViaWindow(html, title);
      return;
    }
    doc.open();
    doc.write(html);
    doc.close();
    const win = frame.contentWindow;
    if (!win) {
      cleanup();
      printViaWindow(html, title);
      return;
    }
    // Give web fonts and layout a beat before the print dialog opens.
    const fire = () => {
      try {
        win.focus();
        win.print();
      } catch {
        printViaWindow(html, title);
      }
      // Keep the frame alive briefly: Chrome cancels printing if the frame is
      // torn down while the dialog is still being prepared.
      setTimeout(cleanup, 1500);
    };
    if (doc.readyState === 'complete') setTimeout(fire, 250);
    else win.addEventListener('load', () => setTimeout(fire, 250), { once: true });
  };

  document.body.appendChild(frame);
  // Safari sometimes withholds the load event for about:blank frames.
  setTimeout(() => {
    if (!frame.contentDocument?.body?.childElementCount && frame.isConnected) {
      cleanup();
      printViaWindow(html, title);
    }
  }, 3000);
}

function printViaWindow(html: string, title: string): void {
  try {
    const win = window.open('', '_blank', 'width=900,height=700');
    if (!win) return;
    win.document.open();
    win.document.write(html);
    win.document.close();
    win.document.title = title;
    win.focus();
    setTimeout(() => win.print(), 350);
  } catch {
    // Nothing else can be done without a printer target; the operator still
    // has the on-screen document.
  }
}
