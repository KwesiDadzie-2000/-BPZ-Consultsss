/**
 * Statutory IFRS statements — printed document.
 *
 * The pack is typeset as the document it is: a set of financial statements
 * prepared for filing. Centred boxed statutory headings (IAS 1 convention),
 * hairline rules between captions, figures in tabular columns with negatives in
 * brackets, note references in the right margin, running page headers and a
 * signature block. Nothing of the application shell is printed.
 */

import type { IfrsNote, IfrsPack, IfrsRow, IfrsStatement } from '@/utils/ifrsPack';
import { printHtmlDocument } from '@/utils/printHtml';

const esc = (v: unknown): string =>
  String(v ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

const num = (n: number): string =>
  n < 0
    ? `(${Math.abs(n).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})`
    : n.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export interface IfrsPrintOptions {
  entity: { name: string; code: string; currency: string; legalName?: string; tin?: string; regNumber?: string; address?: string; jurisdiction?: string };
  preparedBy: string;
  /** Sections to include — defaults to everything. */
  include?: { statements?: boolean; notes?: boolean; ratios?: boolean; compliance?: boolean };
  /** Print one primary statement on its own (e.g. just the cash flows). */
  onlyStatement?: 'position' | 'profit' | 'equity' | 'cashflow';
  /** Signed-off status stamp printed in the header. */
  status?: string;
  /** ISO date of authorisation for issue. */
  authorisedOn?: string;
}

const STYLE = `
  @page { size: A4 portrait; margin: 16mm 15mm 18mm 15mm; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; background: #ffffff; }
  body {
    font-family: "Source Serif 4", "Iowan Old Style", Georgia, "Times New Roman", serif;
    color: #0a253e; font-size: 10pt; line-height: 1.45;
    font-variant-numeric: tabular-nums;
  }
  .sheet { background: #ffffff; }
  .runhead {
    display: flex; justify-content: space-between; align-items: baseline;
    border-bottom: 1px solid #bae6fd; padding-bottom: 4px; margin-bottom: 14px;
    font-family: "IBM Plex Sans", "Segoe UI", Arial, sans-serif;
    font-size: 7pt; letter-spacing: .16em; text-transform: uppercase; color: #355875;
  }
  .cover { padding: 22mm 0 10mm; text-align: center; page-break-after: always; }
  .cover .rule { width: 68mm; height: 2px; background: #082f4f; margin: 10mm auto; }
  .cover .kicker { font-family: "IBM Plex Sans", Arial, sans-serif; font-size: 8pt; letter-spacing: .34em; text-transform: uppercase; color: #082f4f; }
  .cover h1 { font-size: 27pt; line-height: 1.12; margin: 6mm 0 3mm; font-weight: 600; letter-spacing: -0.01em; }
  .cover h2 { font-size: 13pt; font-weight: 400; font-style: italic; margin: 0 0 2mm; color: #2d4f6d; }
  .cover .meta { font-family: "IBM Plex Sans", Arial, sans-serif; font-size: 8.5pt; letter-spacing: .12em; text-transform: uppercase; color: #355875; }
  h2.statement-title {
    text-align: center; font-size: 12pt; font-weight: 600; margin: 0 0 1mm;
    border: 1px solid #082f4f; padding: 3.2mm 0; letter-spacing: .02em;
  }
  .statement-sub { text-align: center; font-style: italic; color: #2d4f6d; margin: 0 0 4mm; font-size: 9pt; }
  .standard { text-align: center; font-family: "IBM Plex Sans", Arial, sans-serif; font-size: 7pt; letter-spacing: .22em; text-transform: uppercase; color: #855b00; margin: 0 0 4mm; }
  section { page-break-inside: auto; margin-bottom: 7mm; }
  .page-break { page-break-before: always; }
  h3.block-title {
    font-family: "IBM Plex Sans", Arial, sans-serif; font-size: 7.6pt; font-weight: 700;
    letter-spacing: .18em; text-transform: uppercase; color: #082f4f;
    border-bottom: 1px solid #082f4f; padding-bottom: 1.4mm; margin: 5mm 0 1.5mm;
  }
  table { width: 100%; border-collapse: collapse; }
  th {
    font-family: "IBM Plex Sans", Arial, sans-serif; font-size: 7pt; font-weight: 700;
    letter-spacing: .12em; text-transform: uppercase; color: #355875;
    border-bottom: 1px solid #0a253e; padding: 1.6mm 1mm; text-align: right;
  }
  th:first-child { text-align: left; }
  td { padding: 1.35mm 1mm; border-bottom: 1px solid #ddd4c2; vertical-align: top; }
  td.label { padding-right: 6mm; }
  td.indent { padding-left: 7mm; font-style: italic; color: #2d4f6d; }
  td.num, th.num { text-align: right; font-family: "IBM Plex Mono", "SFMono-Regular", Consolas, monospace; font-variant-numeric: tabular-nums; font-size: 9pt; white-space: nowrap; }
  td.note { text-align: right; width: 9mm; font-family: "IBM Plex Sans", Arial, sans-serif; font-size: 8pt; color: #355875; }
  td.neg { color: #855b00; }
  tr.sub td { border-top: 1px solid #0a253e; font-weight: 600; background: #eaf3fb; }
  tr.total td { border-top: 1.5px solid #082f4f; border-bottom: 3px double #082f4f; font-weight: 700; background: #eaf3fb; }
  tr.grand td { border-top: 2px solid #0a253e; border-bottom: 3px double #0a253e; font-weight: 700; font-size: 10.5pt; }
  h4.note-title { font-size: 10.5pt; margin: 5mm 0 1.2mm; font-weight: 600; }
  h4.note-title span.std {
    font-family: "IBM Plex Sans", Arial, sans-serif; font-size: 7pt; letter-spacing: .18em;
    text-transform: uppercase; color: #855b00; margin-left: 3mm;
  }
  p { margin: 0 0 2mm; text-align: justify; max-width: 152mm; }
  p.lead { font-style: italic; color: #2d4f6d; }
  .cols { column-count: 2; column-gap: 9mm; }
  .sign { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10mm; margin-top: 16mm; page-break-inside: avoid; }
  .sign div { border-top: 1px solid #0a253e; padding-top: 1.6mm; font-family: "IBM Plex Sans", Arial, sans-serif; font-size: 7.5pt; letter-spacing: .12em; text-transform: uppercase; color: #2d4f6d; }
  .foot { margin-top: 10mm; border-top: 1px solid #bae6fd; padding-top: 2mm; font-family: "IBM Plex Sans", Arial, sans-serif; font-size: 7pt; letter-spacing: .1em; text-transform: uppercase; color: #355875; display: flex; justify-content: space-between; }
  .badge { font-family: "IBM Plex Sans", Arial, sans-serif; font-size: 7pt; letter-spacing: .12em; text-transform: uppercase; padding: 0.6mm 2mm; border-radius: 2px; }
  .badge.pass { background: #d1fae5; color: #082f4f; }
  .badge.warn { background: #fef3c7; color: #7a4c00; }
  .badge.fail { background: #ffe4e6; color: #855b00; }
  .checklist td { font-size: 9pt; }
`;

function rowHtml(row: IfrsRow, currency: string): string {
  const cls = row.emphasis === 'grand' ? ' class="grand"' : row.emphasis === 'total' ? ' class="total"' : row.emphasis === 'sub' ? ' class="sub"' : '';
  const labelCls = row.indent ? 'label indent' : 'label';
  const neg = (n: number) => (n < 0 ? ' neg' : '');
  return `<tr${cls}>
    <td class="${labelCls}">${esc(row.label)}</td>
    <td class="note">${row.note ? esc(row.note) : ''}</td>
    <td class="num${neg(row.current)}">${num(row.current)}</td>
    <td class="num${neg(row.comparative)}">${num(row.comparative)}</td>
  </tr>`;
}

function statementHtml(st: IfrsStatement, currency: string, breakBefore: boolean): string {
  // IAS 1.106 is a matrix — one column per component of equity — so it is
  // typeset as a grid rather than as a two-column statement.
  if (st.matrix) {
    const m = st.matrix;
    return `<section class="${breakBefore ? 'page-break' : ''}">
      <div class="standard">${esc(st.standard)}</div>
      <h2 class="statement-title">${esc(st.title)}</h2>
      <p class="statement-sub">${esc(st.subtitle)}</p>
      <table>
        <thead><tr>
          <th>Particulars</th>
          ${m.columns.map((c) => `<th class="num">${esc(c)}</th>`).join('')}
          <th class="num">Total</th>
        </tr></thead>
        <tbody>
          ${m.rows
            .map((row) => {
              const cls =
                row.emphasis === 'total' ? ' class="total"' : row.emphasis === 'sub' ? ' class="sub"' : '';
              return `<tr${cls}>
                <td class="label">${esc(row.label)}</td>
                ${row.values.map((v) => `<td class="num${v < 0 ? ' neg' : ''}">${num(v)}</td>`).join('')}
                <td class="num${row.total < 0 ? ' neg' : ''}"><b>${num(row.total)}</b></td>
              </tr>`;
            })
            .join('')}
        </tbody>
      </table>
    </section>`;
  }
  const blocks = st.blocks
    .map((block) => {
      const rows = block.rows.map((r) => rowHtml(r, currency)).join('');
      const total = block.total ? rowHtml(block.total, currency) : '';
      return `${block.title ? `<h3 class="block-title">${esc(block.title)}</h3>` : ''}
        <table>
          <thead><tr><th>Particulars</th><th class="num">Note</th><th class="num">${esc(currency)}</th><th class="num">Comparative</th></tr></thead>
          <tbody>${rows}${total}</tbody>
        </table>`;
    })
    .join('');

  return `<section class="${breakBefore ? 'page-break' : ''}">
    <div class="standard">${esc(st.standard)}</div>
    <h2 class="statement-title">${esc(st.title)}</h2>
    <p class="statement-sub">${esc(st.subtitle)}</p>
    ${blocks}
  </section>`;
}

function noteHtml(note: IfrsNote): string {
  const table = note.table
    ? `<table>
        <thead><tr>${note.table.columns.map((c, i) => `<th class="${i > 0 ? 'num' : ''}">${esc(c)}</th>`).join('')}</tr></thead>
        <tbody>
          ${note.table.rows
            .map(
              (row) =>
                `<tr>${row
                  .map(
                    (v, i) =>
                      `<td class="${i > 0 ? `num${typeof v === 'number' && v < 0 ? ' neg' : ''}` : 'label'}">${
                        typeof v === 'number' ? num(v) : esc(v)
                      }</td>`,
                  )
                  .join('')}</tr>`,
            )
            .join('')}
          ${
            note.table.totals
              ? `<tr class="sub">${note.table.totals
                  .map(
                    (v, i) =>
                      `<td class="${i > 0 ? `num${typeof v === 'number' && v < 0 ? ' neg' : ''}` : 'label'}">${
                        typeof v === 'number' ? num(v) : esc(v)
                      }</td>`,
                  )
                  .join('')}</tr>`
              : ''
          }
        </tbody>
      </table>`
    : '';

  return `<section>
    <h4 class="note-title">${note.number}. ${esc(note.title)}<span class="std">${esc(note.standard)}</span></h4>
    ${note.paragraphs.map((p) => `<p>${esc(p)}</p>`).join('')}
    ${table}
  </section>`;
}

export function buildIfrsHtml(pack: IfrsPack, options: IfrsPrintOptions): string {
  const include = options.include ?? { statements: true, notes: true, ratios: true, compliance: true };
  const e = options.entity;
  const printedAt = new Date().toLocaleString('en-GB', { dateStyle: 'long', timeStyle: 'short' });
  const ccy = pack.currency;

  const cover = `<div class="cover">
      <div class="kicker">${esc(options.status ?? 'Statutory financial statements')}</div>
      <h1>${esc(e.legalName || e.name)}</h1>
      <h2>Financial statements for the period ${esc(pack.periodLabel)}</h2>
      <div class="rule"></div>
      <div class="meta">
        Prepared in accordance with International Financial Reporting Standards (IFRS)<br/>
        Entity code ${esc(e.code)} · ${esc(e.jurisdiction ?? pack.jurisdiction)}${e.regNumber ? ` · Registration ${esc(e.regNumber)}` : ''}<br/>
        Presentation currency ${esc(ccy)}${e.tin ? ` · TIN ${esc(e.tin)}` : ''}<br/>
        ${e.address ? `${esc(e.address)}<br/>` : ''}
      </div>
    </div>`;

  const statementSet = options.onlyStatement
    ? pack.statements.filter((s) => s.id === options.onlyStatement)
    : pack.statements;
  const statements = include.statements
    ? statementSet.map((st, i) => statementHtml(st, ccy, i > 0)).join('')
    : '';

  const notes = include.notes
    ? `<section class="page-break">
        <div class="standard">IAS 1.112</div>
        <h2 class="statement-title">Notes to the financial statements</h2>
        <p class="statement-sub">Forming an integral part of these financial statements, for the period ${esc(pack.periodLabel)}</p>
       </section>
       ${pack.notes.map((n) => noteHtml(n)).join('')}`
    : '';

  const ratios = include.ratios
    ? `<section class="page-break">
        <div class="standard">IAS 1.134 · IAS 1.60</div>
        <h2 class="statement-title">Capital, liquidity and performance analysis</h2>
        <p class="statement-sub">Ratios derived from the statement of financial position and the statement of profit or loss</p>
        <table>
          <thead><tr><th>Measure</th><th class="num">Current</th><th class="num">Comparative</th><th>Basis of calculation</th><th class="num">Reference</th></tr></thead>
          <tbody>
            ${pack.ratios
              .map(
                (r) => `<tr>
                  <td class="label">${esc(r.label)}</td>
                  <td class="num">${esc(r.current)}</td>
                  <td class="num">${esc(r.comparative)}</td>
                  <td class="label" style="font-size:8.5pt;color:#2d4f6d">${esc(r.basis)}</td>
                  <td class="note">${esc(r.ref)}</td>
                </tr>`,
              )
              .join('')}
          </tbody>
        </table>
      </section>`
    : '';

  const compliance = include.compliance
    ? `<section class="page-break">
        <div class="standard">IAS 1.114</div>
        <h2 class="statement-title">Statement of compliance and completeness checklist</h2>
        <p class="statement-sub">Verification that the complete set of financial statements required by IAS 1.10 has been presented</p>
        <table class="checklist">
          <thead><tr><th>Requirement</th><th>Standard</th><th>Status</th><th>Basis</th></tr></thead>
          <tbody>
            ${pack.checklist
              .map(
                (c) => `<tr>
                  <td class="label">${esc(c.requirement)}</td>
                  <td class="label" style="font-size:8pt">${esc(c.standard)}</td>
                  <td class="label"><span class="badge ${c.status === 'Satisfied' ? 'pass' : c.status === 'Partial' ? 'warn' : 'fail'}">${esc(c.status)}</span></td>
                  <td class="label" style="font-size:8.5pt;color:#2d4f6d">${esc(c.detail)}</td>
                </tr>`,
              )
              .join('')}
          </tbody>
        </table>
      </section>`
    : '';

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${esc(e.name)} — Financial statements ${esc(pack.periodLabel)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:ital,wght@0,400;0,600;0,700;1,400;1,600&family=IBM+Plex+Sans:wght@400;600;700&family=IBM+Plex+Mono:wght@400;600&display=swap" rel="stylesheet" />
<style>${STYLE}</style>
</head>
<body class="sheet">
  <div class="runhead">
    <span>${esc(e.legalName || e.name)} · Financial statements ${esc(pack.periodLabel)}</span>
    <span>Entity ${esc(e.code)} · ${esc(ccy)}</span>
  </div>
  ${cover}
  ${statements}
  ${notes}
  ${ratios}
  ${compliance}
  <div class="sign">
    <div>Approved for issue by — Director</div>
    <div>Reviewed by — Reporting accountant</div>
    <div>Authorised for issue — Date ${esc(options.authorisedOn ?? '')}</div>
  </div>
  <div class="foot">
    <span>Prepared by ${esc(options.preparedBy)} · printed ${esc(printedAt)}</span>
    <span>Generated from the posted general ledger · retain with the signed minutes</span>
  </div>
</body>
</html>`;
}

/** Prints the complete statutory pack (or a selection of it) on A4. */
export function printIfrsPack(pack: IfrsPack, options: IfrsPrintOptions): void {
  printHtmlDocument(buildIfrsHtml(pack, options), `${options.entity.name} — Financial statements`);
}
