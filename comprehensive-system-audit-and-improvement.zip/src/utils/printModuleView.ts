/**
 * Module view printing.
 *
 * Thirteen modules already print a purpose-built document. Everything else —
 * registers, desks and setups — still had no way to get onto paper, so the
 * operator printed the browser page and got the whole workspace with it.
 *
 * `printModuleView()` prints the working desk the operator is looking at: the
 * letterhead, the module title and the module's own content, with the controls,
 * buttons and navigation stripped out and the page split sensibly. It reuses
 * the stylesheets already loaded by the application so the printed page matches
 * the screen exactly.
 */

const esc = (v: unknown): string =>
  String(v ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

export interface ModulePrintOptions {
  title: string;
  subtitle?: string;
  /** Root element to print. Defaults to the active workspace. */
  root?: HTMLElement | null;
  orientation?: 'portrait' | 'landscape';
}

/** Collects the stylesheets the page is already using so the printout matches. */
function styleMarkup(): string {
  const nodes = Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'));
  return nodes
    .map((n) => {
      if (n.tagName === 'STYLE') return `<style>${n.textContent ?? ''}</style>`;
      return n.outerHTML;
    })
    .join('\n');
}

function cleanClone(root: HTMLElement): HTMLElement {
  const clone = root.cloneNode(true) as HTMLElement;
  clone.querySelectorAll('button, input, select, textarea, nav, [data-print-hide], .no-print').forEach((n) => n.remove());
  // Blank form scaffolding left behind by removed controls.
  clone.querySelectorAll('form').forEach((f) => {
    if (!f.textContent?.trim() && !f.querySelector('table')) f.remove();
  });
  clone.style.maxWidth = 'none';
  clone.style.overflow = 'visible';
  return clone;
}

export function buildModuleHtml(options: ModulePrintOptions): string {
  const root = options.root ?? document.querySelector('main');
  const body = root ? cleanClone(root).innerHTML : '<p>No printable content.</p>';
  const printedAt = new Date().toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' });
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${esc(options.title)}</title>
${styleMarkup()}
<style>
  @page { size: A4 ${options.orientation === 'landscape' ? 'landscape' : 'portrait'}; margin: 14mm 12mm 16mm 12mm; }
  html, body { background: #fff; }
  body { padding: 0; max-width: none; margin: 0; }
  .print-letterhead { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #082f4f; padding-bottom: 8px; margin-bottom: 4px; }
  .print-letterhead .mark { width: 38px; height: 38px; border-radius: 8px; background: #f5b719; color: #082f4f; font-weight: 900; display: flex; align-items: center; justify-content: center; font-size: 12pt; font-family: Arial, sans-serif; }
  .print-letterhead .firm { font-family: Arial, sans-serif; font-weight: 800; letter-spacing: .04em; font-size: 10pt; color: #082f4f; }
  .print-letterhead .firm small { display: block; font-weight: 600; color: #855b00; letter-spacing: .08em; text-transform: uppercase; font-size: 7.5pt; }
  .print-letterhead .meta { text-align: right; font-family: Arial, sans-serif; font-size: 8.5pt; color: #2d4f6d; }
  .print-letterhead .meta b { display: block; font-size: 11pt; color: #082f4f; }
  .print-title { font-family: Arial, sans-serif; margin: 10px 0 2px; font-size: 15pt; color: #082f4f; }
  .print-subtitle { font-family: Arial, sans-serif; margin: 0 0 10px; font-size: 9pt; color: #2d4f6d; }
  .print-foot { margin-top: 16px; border-top: 1px solid #cfe0f1; padding-top: 6px; font-family: Arial, sans-serif; font-size: 7.5pt; color: #355875; display: flex; justify-content: space-between; }
  table { page-break-inside: auto; }
  tr { page-break-inside: avoid; }
  thead { display: table-header-group; }
  .shadow-sm, .shadow, .shadow-xs { box-shadow: none !important; }
</style>
</head>
<body>
  <header class="print-letterhead">
    <div style="display:flex;gap:10px;align-items:center">
      <div class="mark">BPZ</div>
      <div class="firm">BPZ CONSULT<small>Accounting · Tax · Payroll · IFRS</small></div>
    </div>
    <div class="meta"><b>${esc(options.title)}</b>${options.subtitle ? `<span>${esc(options.subtitle)}</span><br/>` : ''}<span>Printed ${esc(printedAt)}</span></div>
  </header>
  <h1 class="print-title">${esc(options.title)}</h1>
  ${options.subtitle ? `<p class="print-subtitle">${esc(options.subtitle)}</p>` : ''}
  <main>${body}</main>
  <div class="print-foot"><span>Generated from the BPZ Consult workspace · working paper</span><span>${esc(printedAt)}</span></div>
</body>
</html>`;
}

export function printModuleView(options: ModulePrintOptions): void {
  const html = buildModuleHtml(options);
  const frame = document.createElement('iframe');
  frame.setAttribute('aria-hidden', 'true');
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0';
  frame.onload = () => {
    const doc = frame.contentDocument;
    const win = frame.contentWindow;
    if (!doc || !win) return frame.remove();
    doc.open();
    doc.write(html);
    doc.close();
    setTimeout(() => {
      win.focus();
      win.print();
      setTimeout(() => frame.remove(), 1500);
    }, 250);
  };
  document.body.appendChild(frame);
}
