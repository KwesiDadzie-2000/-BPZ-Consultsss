import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { authJson, createSession, pruneExpiredSessions, sanitizeUser, SESSION_TTL_MS } from "@/lib/auth";
import { hashPassword, needsRehash, newSalt, verifyPassword } from "@/lib/password";

export const dynamic = "force-dynamic";

// Server-side failed-attempt tracking (per server instance).
const failures = new Map<string, { count: number; until: number }>();
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MS = 5 * 60 * 1000;

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    console.error("database provisioning failed", e);
    return authJson(req, { ok: false, error: "The workspace database is unavailable. Please try again in a moment." }, { status: 503 });
  }
  try {
    let body: { usernameOrEmail?: unknown; password?: unknown } | null = null;
    try {
      body = await req.json();
    } catch {
      return authJson(req, { ok: false, error: "Invalid request body." }, { status: 400 });
    }
    const identifier = String(body?.usernameOrEmail || "").trim().toLowerCase();
    const password = String(body?.password || "");
    if (!identifier || !password) {
      return authJson(req, { ok: false, error: "Username and password are required." }, { status: 400 });
    }

    let lock = failures.get(identifier);
    // An expired lockout starts a fresh window — previously the count stayed at
    // 5, so a single typo after the lock expired re-locked the account at once.
    if (lock && lock.until !== 0 && lock.until <= Date.now()) {
      failures.delete(identifier);
      lock = undefined;
    }
    if (lock && lock.until > Date.now()) {
      return authJson(
        req,
        { ok: false, error: "Too many failed attempts. Wait 5 minutes before trying again.", retryAfterSeconds: Math.ceil((lock.until - Date.now()) / 1000) },
        { status: 429 }
      );
    }

    const found = await db
      .select()
      .from(users)
      .where(or(eq(users.username, identifier), eq(users.email, identifier)))
      .limit(1);
    const user = found[0];

    if (!user || !user.passwordHash || !user.passwordSalt || !(await verifyPassword(password, user.passwordSalt, user.passwordHash))) {
      const next = (lock?.count ?? 0) + 1;
      failures.set(identifier, { count: next, until: next >= MAX_FAILED_ATTEMPTS ? Date.now() + LOCKOUT_MS : 0 });
      return authJson(req, { ok: false, error: "Invalid username, email, or password." }, { status: 401 });
    }

    if (user.status === "restricted" || user.status === "suspended") {
      return authJson(
        req,
        { ok: false, error: `Account restricted by administrator.${user.restrictionReason ? ` Reason: "${user.restrictionReason}"` : ""}` },
        { status: 403 }
      );
    }

    failures.delete(identifier);

    // Transparent credential upgrade: any account still carrying a legacy
    // SHA-256 hash is re-hashed with scrypt on this successful login, so the
    // estate migrates to the strong KDF without locking anyone out.
    if (needsRehash(user.passwordHash)) {
      const salt = newSalt();
      await db
        .update(users)
        .set({ passwordSalt: salt, passwordHash: await hashPassword(password, salt) })
        .where(eq(users.id, user.id));
    }

    const token = await createSession(user.id);
    // Housekeeping — never allowed to fail the sign-in itself.
    void pruneExpiredSessions();

    /**
     * The token travels BOTH as an HttpOnly cookie (survives reloads, new tabs,
     * proxy header stripping and blocked JavaScript storage) and in the body
     * (so the browser client can also send it as a Bearer token). Returning it
     * twice is what makes the session impossible to lose right after sign-in.
     */
    return authJson(
      req,
      { ok: true, user: sanitizeUser(user), token, expiresInSeconds: SESSION_TTL_MS / 1000 },
      { token }
    );
  } catch (e) {
    console.error("login error", e);
    return authJson(req, { ok: false, error: "Login failed." }, { status: 500 });
  }
}
