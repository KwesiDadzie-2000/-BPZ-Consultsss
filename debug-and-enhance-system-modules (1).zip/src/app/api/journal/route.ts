import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import { auditLog, chartAccounts, closedPeriods, clients, journalHeaders, journalLines, postingEvents } from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope } from "@/lib/auth";
import { sameJournalLines, validateJournalLines, validateMakerChecker } from "@/lib/journalValidation";
import { buildJournalHeader, buildPostingEvent, journalContentHash, journalHeaderId, postingIdempotencyKey } from "@/lib/journalPosting";
import { eq, inArray, sql } from "drizzle-orm";
import type { ACDOCALine } from "@/types/accounting";

export const dynamic = "force-dynamic";

/**
 * Server-side posting service: validates the document (tenant ownership, open
 * period, chart-of-accounts existence, double entry in minor units, idempotent
 * document number) and inserts it with an audit-trail entry in one transaction.
 */
export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch {
    return Response.json({ ok: false, error: "The accounting database is temporarily unavailable." }, { status: 503 });
  }
  try {
    return await handleJournalPost(req);
  } catch (error) {
    const reference = crypto.randomUUID();
    const cause = error instanceof Error ? error.cause : undefined;
    const codeValue = error && typeof error === "object" && "code" in error
      ? (error as { code?: unknown }).code
      : cause && typeof cause === "object" && "code" in cause
        ? (cause as { code?: unknown }).code
        : undefined;
    const code = typeof codeValue === "string" ? codeValue : undefined;
    console.error(`[journal-post:${reference}] ${error instanceof Error ? error.name : "UnknownError"}${code ? ` code=${code}` : ""}`);
    return Response.json({ ok: false, error: `The journal was not posted. Retry; if it continues, share reference ${reference}.`, reference }, { status: 500 });
  }
}

interface JournalPostGroup {
  clientId: number;
  docNo: string;
  lines: ACDOCALine[];
}

async function handleJournalPost(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });

  let lines: ACDOCALine[];
  let requestIdempotencyKey: string | undefined;
  try {
    const body = await req.json();
    lines = body?.lines;
    requestIdempotencyKey = typeof body?.idempotencyKey === "string" ? body.idempotencyKey.trim() : undefined;
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  if (!Array.isArray(lines) || !lines.length) return Response.json({ ok: false, error: "No journal lines provided." }, { status: 400 });
  if (lines.some((line) => !line || typeof line.id !== "string" || !line.id.trim() || typeof line.docNo !== "string" || !line.docNo.trim())) {
    return Response.json({ ok: false, error: "Every journal line needs a unique id and document number." }, { status: 400 });
  }
  if (new Set(lines.map((line) => line.id)).size !== lines.length) {
    return Response.json({ ok: false, error: "Duplicate journal line ids in the posting request." }, { status: 400 });
  }

  const myClientId = user.clientId ?? null;
  const allClients = await db.select().from(clients);
  const allowedClientIds = hasFirmWideScope(user) ? allClients.map((client) => client.id) : myClientId === null ? [] : [myClientId];
  if (lines.some((line) => !allowedClientIds.includes(line.clientId))) {
    return authJson(req, { ok: false, error: "Transaction belongs to a different client." }, { status: 403 });
  }

  const groupsByKey = new Map<string, JournalPostGroup>();
  for (const line of lines) {
    const key = `${line.clientId}\u0000${line.docNo}`;
    const group = groupsByKey.get(key) ?? { clientId: line.clientId, docNo: line.docNo, lines: [] };
    group.lines.push(line);
    groupsByKey.set(key, group);
  }
  const groups = [...groupsByKey.values()];
  const documentNumbers = [...new Set(groups.map((group) => group.docNo))];
  const idempotencyKeys = groups.map((group) => postingIdempotencyKey(group.clientId, group.docNo, requestIdempotencyKey));
  const [previouslyStored, previousHeaders, previousEvents] = await Promise.all([
    db.select().from(journalLines).where(inArray(journalLines.docNo, documentNumbers)),
    db.select().from(journalHeaders).where(inArray(journalHeaders.docNo, documentNumbers)),
    db.select().from(postingEvents).where(inArray(postingEvents.idempotencyKey, idempotencyKeys)),
  ]);
  const newGroups: JournalPostGroup[] = [];
  for (const group of groups) {
    const requestHash = journalContentHash(group.lines);
    const eventKey = postingIdempotencyKey(group.clientId, group.docNo, requestIdempotencyKey);
    const event = previousEvents.find((row) => row.clientId === group.clientId && row.idempotencyKey === eventKey);
    if (event) {
      if (event.requestHash !== requestHash) {
        return Response.json({ ok: false, error: `Idempotency key for ${group.docNo} was already used with different content.` }, { status: 409 });
      }
      continue;
    }
    const header = previousHeaders.find((row) => row.clientId === group.clientId && row.docNo === group.docNo);
    if (header && header.contentHash !== requestHash) {
      return Response.json({ ok: false, error: `Document ${group.docNo} already exists with different content.` }, { status: 409 });
    }
    const existing = previouslyStored.filter((row) => row.clientId === group.clientId && row.docNo === group.docNo);
    if (existing.length && !sameJournalLines(existing, group.lines)) {
      return Response.json({ ok: false, error: `Document ${group.docNo} already exists with different content.` }, { status: 409 });
    }
    if (!existing.length && !header) newGroups.push(group);
  }
  if (!newGroups.length) return Response.json({ ok: true, idempotent: true, lines });

  const [coa, closed] = await Promise.all([db.select().from(chartAccounts), db.select().from(closedPeriods)]);
  const closedKeys = new Set(closed.filter((period) => allowedClientIds.includes(period.clientId)).map((period) => `${period.clientId}:${period.period}`));
  const coaNos = new Set(coa.filter((account) => account.clientId === null || allowedClientIds.includes(account.clientId)).map((account) => account.accountNo));
  const freshLines = newGroups.flatMap((group) => group.lines);
  const validationError = validateJournalLines(freshLines, { allowedClientIds, closedPeriodKeys: closedKeys, coaAccountNos: coaNos });
  if (validationError) return Response.json({ ok: false, error: validationError }, { status: 409 });
  const makerCheckerError = validateMakerChecker(freshLines, { username: user.username, makerLimit: user.makerLimit });
  if (makerCheckerError) return Response.json({ ok: false, error: makerCheckerError }, { status: 409 });

  let transactionError: string | null = null;
  let savedLines: ACDOCALine[] = [];
  let idempotent = false;
  await db.transaction(async (tx) => {
    // The same lock is used by full-state sync; re-read after acquiring it so
    // concurrent retries cannot double-insert a document.
    await tx.execute(sql`select pg_advisory_xact_lock(4027332)`);
    const [latest, latestHeaders, latestEvents] = await Promise.all([
      tx.select().from(journalLines).where(inArray(journalLines.docNo, documentNumbers)),
      tx.select().from(journalHeaders).where(inArray(journalHeaders.docNo, documentNumbers)),
      tx.select().from(postingEvents).where(inArray(postingEvents.idempotencyKey, idempotencyKeys)),
    ]);
    const pending: JournalPostGroup[] = [];
    for (const group of groups) {
      const requestHash = journalContentHash(group.lines);
      const eventKey = postingIdempotencyKey(group.clientId, group.docNo, requestIdempotencyKey);
      const event = latestEvents.find((row) => row.clientId === group.clientId && row.idempotencyKey === eventKey);
      if (event) {
        if (event.requestHash !== requestHash) transactionError = `Idempotency key for ${group.docNo} was already used with different content.`;
        if (transactionError) return;
        continue;
      }
      const header = latestHeaders.find((row) => row.clientId === group.clientId && row.docNo === group.docNo);
      if (header) {
        if (header.contentHash !== requestHash) transactionError = `Document ${group.docNo} already exists with different content.`;
        if (transactionError) return;
        continue;
      }
      const existing = latest.filter((row) => row.clientId === group.clientId && row.docNo === group.docNo);
      if (!existing.length) {
        pending.push(group);
      } else if (!sameJournalLines(existing, group.lines)) {
        transactionError = `Document ${group.docNo} already exists with different content.`;
        return;
      }
    }
    if (!pending.length) {
      idempotent = true;
      savedLines = lines;
      return;
    }

    const pendingLines = pending.flatMap((group) => group.lines);
    const [latestCoa, latestClosed] = await Promise.all([tx.select().from(chartAccounts), tx.select().from(closedPeriods)]);
    const latestClosedKeys = new Set(latestClosed.filter((period) => allowedClientIds.includes(period.clientId)).map((period) => `${period.clientId}:${period.period}`));
    const latestCoaNos = new Set(latestCoa.filter((account) => account.clientId === null || allowedClientIds.includes(account.clientId)).map((account) => account.accountNo));
    transactionError = validateJournalLines(pendingLines, { allowedClientIds, closedPeriodKeys: latestClosedKeys, coaAccountNos: latestCoaNos });
    if (transactionError) return;
    transactionError = validateMakerChecker(pendingLines, { username: user.username, makerLimit: user.makerLimit });
    if (transactionError) return;

    const existingIds = await tx.select({ id: journalLines.id }).from(journalLines).where(inArray(journalLines.id, pendingLines.map((line) => line.id)));
    if (existingIds.length) {
      transactionError = `Journal line id ${existingIds[0].id} has already been used.`;
      return;
    }
    await tx.insert(journalLines).values(pendingLines.map((line) => ({
      id: line.id, docNo: line.docNo, period: line.period, date: line.date, module: line.module, docType: line.docType,
      accountNo: line.accountNo, accountName: line.accountName, costCenter: line.costCenter ?? null,
      debit: line.debit, credit: line.credit, currency: line.currency, description: line.description,
      createdBy: line.createdBy, checkedBy: line.checkedBy ?? null, isReversed: line.isReversed ?? false,
      reference: line.reference ?? null, clientId: line.clientId,
    })));
    await tx.insert(journalHeaders).values(pending.map((group) => buildJournalHeader(group.lines))).onConflictDoNothing();
    await tx.insert(postingEvents).values(pending.map((group) => buildPostingEvent(group.lines, user.username, requestIdempotencyKey))).onConflictDoNothing();
    await tx.insert(auditLog).values(pending.map((group) => {
      const debits = group.lines.reduce((total, line) => total + Math.round(line.debit * 100), 0) / 100;
      return {
        id: crypto.randomUUID(), timestamp: new Date().toISOString(), userId: user.username, username: user.username,
        action: "POST_JOURNAL", target: group.docNo, details: `${group.lines.length} line(s), debits ${debits.toFixed(2)}`,
        clientId: group.clientId,
      };
    }));
    savedLines = lines;
  });

  if (transactionError) return Response.json({ ok: false, error: transactionError }, { status: 409 });
  return Response.json({ ok: true, idempotent, lines: savedLines });
}

/* ------------------------------------------------------------------------- *
 * Document maintenance (General Ledger desk)
 * ------------------------------------------------------------------------- */

interface DocumentScope {
  user: NonNullable<Awaited<ReturnType<typeof getSessionUser>>>;
  clientId: number;
  docNo: string;
  existing: (typeof journalLines.$inferSelect)[];
}

/**
 * Loads a document and applies the shared maintenance rules:
 *  - tenant ownership, open period, not reversed / not a reversal;
 *  - restricted or suspended users may not maintain documents;
 *  - a maker may only maintain their own documents within their maker limit;
 *    checkers (and the owner) may maintain any document of their entities.
 */
async function loadDocumentScope(req: Request, body: { clientId?: number; docNo?: string }): Promise<DocumentScope | Response> {
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
  if (user.status === "restricted" || user.status === "suspended") {
    return Response.json({ ok: false, error: "Your posting authority is restricted — document maintenance is not permitted." }, { status: 403 });
  }
  const clientId = Number(body?.clientId);
  const docNo = String(body?.docNo || "").trim();
  if (!Number.isFinite(clientId) || !docNo) return Response.json({ ok: false, error: "clientId and docNo are required." }, { status: 400 });

  const allClients = await db.select().from(clients);
  const allowedClientIds = hasFirmWideScope(user) ? allClients.map((c) => c.id) : user.clientId == null ? [] : [user.clientId];
  if (!allowedClientIds.includes(clientId)) return Response.json({ ok: false, error: "Document belongs to a different client." }, { status: 403 });

  const existing = (await db.select().from(journalLines).where(eq(journalLines.docNo, docNo))).filter((l) => l.clientId === clientId);
  if (!existing.length) return Response.json({ ok: false, error: `Document ${docNo} was not found on the server.` }, { status: 404 });
  if (existing.some((l) => l.isReversed)) return Response.json({ ok: false, error: `Document ${docNo} has been reversed and is frozen.` }, { status: 409 });
  if (existing.some((l) => l.docType === "REV")) return Response.json({ ok: false, error: `Reversal documents are immutable.` }, { status: 409 });

  const closed = await db.select().from(closedPeriods);
  const frozen = new Set(closed.map((c) => `${c.clientId}:${c.period}`));
  if (existing.some((l) => frozen.has(`${l.clientId}:${l.period}`))) {
    return Response.json({ ok: false, error: `Period ${existing[0].period} is closed and frozen for this entity.` }, { status: 409 });
  }

  const total = existing.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
  const privileged = user.role === "owner" || user.canCheck;
  if (!privileged) {
    if (existing.some((l) => l.createdBy !== user.username)) {
      return Response.json({ ok: false, error: "Only the maker of a document (or a checker) may maintain it." }, { status: 403 });
    }
    if (user.makerLimit > 0 && total > user.makerLimit) {
      return Response.json({ ok: false, error: "This document exceeds your maker limit — ask a checker to maintain it." }, { status: 403 });
    }
  }
  return { user, clientId, docNo, existing };
}

const audit = (tx: Parameters<Parameters<typeof db.transaction>[0]>[0], user: { username: string }, action: string, target: string, details: string, clientId: number) =>
  tx.insert(auditLog).values({
    id: crypto.randomUUID(), timestamp: new Date().toISOString(), userId: user.username, username: user.username,
    action, target, details, clientId,
  });

/**
 * Replaces the lines of ONE posted document (General Ledger "edit document").
 * The document number is kept; new lines must balance, reference existing
 * accounts, stay in the same entity and in an open period.
 */
export async function PATCH(req: Request) {
  await ensureDatabaseReady();
  let body: { clientId?: number; docNo?: string; lines?: ACDOCALine[]; reason?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  const scope = await loadDocumentScope(req, body);
  if (scope instanceof Response) return scope;
  const { user, clientId, docNo, existing } = scope;
  const lines = Array.isArray(body.lines) ? body.lines : [];
  if (!lines.length) return Response.json({ ok: false, error: "No journal lines provided." }, { status: 400 });
  if (lines.some((l) => l.docNo !== docNo || l.clientId !== clientId)) {
    return Response.json({ ok: false, error: "Edited lines must keep the document number and entity." }, { status: 400 });
  }

  const allClients = await db.select().from(clients);
  const allowedClientIds = hasFirmWideScope(user) ? allClients.map((c) => c.id) : user.clientId == null ? [] : [user.clientId];
  const [coa, closed] = await Promise.all([db.select().from(chartAccounts), db.select().from(closedPeriods)]);
  const closedKeys = new Set(closed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`));
  const coaNos = new Set(coa.filter((a) => a.clientId === null || allowedClientIds.includes(a.clientId)).map((a) => a.accountNo));
  const error = validateJournalLines(lines, { allowedClientIds, closedPeriodKeys: closedKeys, coaAccountNos: coaNos });
  if (error) return Response.json({ ok: false, error }, { status: 409 });
  // Above the maker limit the edited document still needs an independent checker.
  const privileged = user.role === "owner" || user.canCheck;
  const total = lines.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
  if (!privileged && user.makerLimit > 0 && total > user.makerLimit) {
    return Response.json({ ok: false, error: "The edited document exceeds your maker limit — submit it for approval instead." }, { status: 403 });
  }
  // Line ids must stay unique across the ledger.
  const incomingIds = new Set(lines.map((l) => l.id));
  if (incomingIds.size !== lines.length) return Response.json({ ok: false, error: "Duplicate line ids in the edited document." }, { status: 400 });

  await db.transaction(async (tx) => {
    await tx.delete(journalLines).where(inArray(journalLines.id, existing.map((l) => l.id)));
    await tx.insert(journalLines).values(
      lines.map((l) => ({
        id: l.id, docNo: l.docNo, period: l.period, date: l.date, module: l.module, docType: l.docType,
        accountNo: l.accountNo, accountName: l.accountName, costCenter: l.costCenter ?? null, debit: l.debit,
        credit: l.credit, currency: l.currency, description: l.description, createdBy: l.createdBy,
        checkedBy: l.checkedBy ?? null, isReversed: false, reference: l.reference ?? null, clientId: l.clientId,
      }))
    );
    const nextHeader = buildJournalHeader(lines);
    await tx.insert(journalHeaders).values(nextHeader).onConflictDoUpdate({
      target: journalHeaders.id,
      set: {
        clientId: nextHeader.clientId, docNo: nextHeader.docNo, period: nextHeader.period, date: nextHeader.date,
        module: nextHeader.module, docType: nextHeader.docType, currency: nextHeader.currency,
        description: nextHeader.description, debitTotal: nextHeader.debitTotal, creditTotal: nextHeader.creditTotal,
        lineCount: nextHeader.lineCount, createdBy: nextHeader.createdBy, checkedBy: nextHeader.checkedBy,
        reference: nextHeader.reference, contentHash: nextHeader.contentHash,
      },
    });
    const before = existing.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
    await audit(tx, user, "EDIT_JOURNAL", docNo, `${existing.length} → ${lines.length} line(s), debits ${before.toFixed(2)} → ${total.toFixed(2)}${body.reason ? ` · ${body.reason}` : ""}`, clientId);
  });
  return Response.json({ ok: true, lines });
}

/** Deletes ONE posted document (owner or checker only; open periods only). */
export async function DELETE(req: Request) {
  await ensureDatabaseReady();
  let body: { clientId?: number; docNo?: string; reason?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  const scope = await loadDocumentScope(req, body);
  if (scope instanceof Response) return scope;
  const { user, clientId, docNo, existing } = scope;
  if (!(user.role === "owner" || user.canCheck)) {
    return Response.json({ ok: false, error: "Only the firm owner or a checker may delete a posted document. Makers should reverse it instead." }, { status: 403 });
  }
  await db.transaction(async (tx) => {
    await tx.delete(journalLines).where(inArray(journalLines.id, existing.map((l) => l.id)));
    await tx.delete(journalHeaders).where(eq(journalHeaders.id, journalHeaderId(clientId, docNo)));
    const total = existing.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
    await audit(tx, user, "DELETE_JOURNAL", docNo, `${existing.length} line(s) removed, debits ${total.toFixed(2)}${body.reason ? ` · ${body.reason}` : ""}`, clientId);
  });
  return Response.json({ ok: true });
}
