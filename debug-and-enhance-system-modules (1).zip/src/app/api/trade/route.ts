import { ensureDatabaseReady } from "@/db/bootstrap";
import { authJson, getSessionUser } from "@/lib/auth";
import {
  executeTradeCommand,
  getTradeOutbox,
  getRecordAudit,
  getTradeWorkspace,
  markOutboxAttempt,
  TradeServiceError,
} from "@/lib/tradeService";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function statusFor(error: unknown) {
  if (error instanceof TradeServiceError) return error.status;
  const code = error && typeof error === "object" && "code" in error ? String((error as { code?: unknown }).code) : "";
  if (code === "23505" || code === "40001" || code === "40P01") return 409;
  return 500;
}

function messageFor(error: unknown, reference: string) {
  if (error instanceof TradeServiceError) return error.message;
  const code = error && typeof error === "object" && "code" in error ? String((error as { code?: unknown }).code) : "";
  if (code === "23505") return "A duplicate document, external reference or allocation already exists. Refresh the workspace and review the current status.";
  if (code === "40001" || code === "40P01") return "The transaction encountered a concurrent update. Retry the same request with the same idempotency key.";
  // The message and stack are logged server-side (never returned to the browser)
  // so an operator can diagnose a failure from the reference alone. Previously
  // only the error *name* was logged, which made faults effectively untraceable.
  console.error(
    `[trade-api:${reference}]`,
    error instanceof Error ? `${error.name}: ${error.message}` : "UnknownError",
    code ? `pg=${code}` : "",
    error instanceof Error && error.stack ? `\n${error.stack}` : "",
  );
  return `The trade operation was not committed. Retry safely; if the problem continues, share reference ${reference}.`;
}

export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
    const url = new URL(req.url);
    const clientId = Number(url.searchParams.get("clientId"));
    if (!Number.isInteger(clientId) || clientId <= 0) return authJson(req, { ok: false, error: "A valid clientId is required." }, { status: 400 });
    if (url.searchParams.get("view") === "audit") {
      const events = await getRecordAudit(clientId, url.searchParams.get("recordId") || "", user);
      return authJson(req, { ok: true, events });
    }
    if (url.searchParams.get("view") === "outbox") {
      const events = await getTradeOutbox(clientId, user);
      return authJson(req, { ok: true, events });
    }
    // Desk-scoped loading: `?scope=p2p|o2c` returns only the lifecycle family the
    // caller renders. `?full=1` restores the complete payload for banking /
    // integration desks. Both keep the payment desk (`scope=all`) unchanged.
    const scopeParam = url.searchParams.get("scope");
    const scope = scopeParam === "p2p" || scopeParam === "o2c" ? scopeParam : "all";
    const full = url.searchParams.get("full") === "1";
    const auditLimitParam = Number(url.searchParams.get("auditLimit"));
    const state = await getTradeWorkspace(clientId, user, {
      scope,
      full,
      auditLimit: Number.isFinite(auditLimitParam) && auditLimitParam > 0 ? auditLimitParam : undefined,
    });
    return authJson(req, state);
  } catch (error) {
    const reference = crypto.randomUUID();
    return authJson(req, { ok: false, error: messageFor(error, reference), reference }, { status: statusFor(error) });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return authJson(req, { ok: false, error: "Invalid JSON payload." }, { status: 400 });
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) return authJson(req, { ok: false, error: "A JSON object payload is required." }, { status: 400 });
    const result = await executeTradeCommand(body as Record<string, unknown>, user);
    return authJson(req, { ok: true, ...result });
  } catch (error) {
    const reference = crypto.randomUUID();
    return authJson(req, { ok: false, error: messageFor(error, reference), reference }, { status: statusFor(error) });
  }
}

export async function PATCH(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
    const body = await req.json().catch(() => null) as Record<string, unknown> | null;
    if (!body) return authJson(req, { ok: false, error: "Invalid JSON payload." }, { status: 400 });
    const clientId = Number(body.clientId);
    const result = await markOutboxAttempt(clientId, String(body.id || ""), user, typeof body.error === "string" ? body.error : undefined);
    return authJson(req, { ok: true, ...result });
  } catch (error) {
    const reference = crypto.randomUUID();
    return authJson(req, { ok: false, error: messageFor(error, reference), reference }, { status: statusFor(error) });
  }
}
