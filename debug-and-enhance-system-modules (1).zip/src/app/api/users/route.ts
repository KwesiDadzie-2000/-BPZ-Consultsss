import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import { users } from "@/db/schema";
import { authJson, requireOwner, sanitizeUser } from "@/lib/auth";
import { hashPassword, newSalt, passwordPolicyError } from "@/lib/password";
import { eq } from "drizzle-orm";
import type { UserAccount } from "@/types/accounting";

export const dynamic = "force-dynamic";

/** Owner-only: list all user accounts (sanitized — never any password material). */
export async function GET(req: Request) {
  await ensureDatabaseReady();
  const user = await requireOwner(req);
  if (!user) return authJson(req, { ok: false, error: "Forbidden" }, { status: 403 });
  const rows = await db.select().from(users);
  return Response.json({ ok: true, users: rows.map(sanitizeUser) });
}

/** Owner-only: create or update a user account. Plaintext passwords are hashed server-side. */
export async function PUT(req: Request) {
  await ensureDatabaseReady();
  const user = await requireOwner(req);
  if (!user) return authJson(req, { ok: false, error: "Forbidden" }, { status: 403 });

  let body: { user?: UserAccount & { password?: string } };
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  const u = body?.user;
  if (!u || !u.username) return Response.json({ ok: false, error: "User is required." }, { status: 400 });

  // Password policy is enforced server-side so a weak credential can never be
  // written, regardless of what the client form allows.
  if (u.password) {
    const policyError = passwordPolicyError(u.password);
    if (policyError) return Response.json({ ok: false, error: policyError }, { status: 400 });
  }
  // A brand-new account must be given a credential — never create a loginable
  // user with a null hash.
  const existingForCheck = await db.select().from(users).where(eq(users.username, u.username)).limit(1);
  if (!existingForCheck[0] && !u.password) {
    return Response.json({ ok: false, error: "A password is required when creating a new user." }, { status: 400 });
  }

  const salt = newSalt();
  const passwordHash = u.password ? await hashPassword(u.password, salt) : null;

  const existing = await db.select().from(users).where(eq(users.username, u.username)).limit(1);
  if (existing[0]) {
    await db
      .update(users)
      .set({
        name: u.name,
        email: u.email,
        role: u.role,
        makerLimit: u.makerLimit,
        canCheck: u.canCheck,
        clientId: u.clientId ?? null,
        status: u.status ?? "active",
        restrictionReason: u.restrictionReason ?? null,
        permissions: u.permissions ?? null,
        ...(passwordHash ? { passwordHash, passwordSalt: salt } : {}),
      })
      .where(eq(users.username, u.username));
  } else {
    await db.insert(users).values({
      id: u.username,
      username: u.username,
      email: u.email,
      name: u.name,
      role: u.role,
      makerLimit: u.makerLimit,
      canCheck: u.canCheck,
      clientId: u.clientId ?? null,
      passwordHash,
      passwordSalt: passwordHash ? salt : null,
      status: u.status ?? "active",
      restrictionReason: u.restrictionReason ?? null,
      permissions: u.permissions ?? null,
    });
  }

  const rows = await db.select().from(users).where(eq(users.username, u.username)).limit(1);
  return Response.json({ ok: true, user: rows[0] ? sanitizeUser(rows[0]) : null });
}
