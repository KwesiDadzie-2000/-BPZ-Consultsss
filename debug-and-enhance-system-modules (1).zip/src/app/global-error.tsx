"use client";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'system-ui, sans-serif', background: '#f0f6fc', color: '#0a253e', margin: 0 }}>
        <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
          <div style={{ maxWidth: 560, background: '#fff', border: '1px solid #fda29b', borderRadius: 16, padding: 24 }}>
            <h1 style={{ fontSize: 15, textTransform: 'uppercase', letterSpacing: 1, color: '#912018', margin: 0 }}>
              BPZ Consult — the application could not start
            </h1>
            <p style={{ fontSize: 13, lineHeight: 1.6, color: '#2d4f6d' }}>
              Workspace data held in this browser is untouched. Reload to try again.
            </p>
            <pre style={{ fontSize: 11, background: '#f0f6fc', padding: 12, borderRadius: 8, overflow: 'auto' }}>
              {error.message}
              {error.digest ? `\n\nReference: ${error.digest}` : ''}
            </pre>
            <button
              onClick={reset}
              style={{ background: '#082f4f', color: '#fff', border: 0, borderRadius: 8, padding: '10px 16px', fontWeight: 700, fontSize: 12, cursor: 'pointer' }}
            >
              Reload workspace
            </button>
          </div>
        </div>
      </body>
    </html>
  );
}
