import React, { useMemo, useState } from 'react';
import { ACDOCALine, AccountMaster, ClientEntity, UserAccount } from '../types/accounting';
import { Card, PageHeader, thCls, rowCls, numCls, formatGHS, Badge } from './ui';
import { COST_CENTRES } from '../data/costCentres';
import { uniqueId } from '../utils/ids';
import { AlertTriangle, CheckCircle, Plus, RotateCcw, Scale, Trash2 } from 'lucide-react';

/**
 * Adjustment of Accounts desk.
 *
 * A dedicated, entity-scoped module for period-end and corrective adjustments:
 * accruals, prepayment releases, depreciation top-ups, provisions, impairments,
 * reclassifications, error corrections, FX revaluation and write-offs/backs.
 *
 * Every adjustment posts a balanced ADJ document into THIS entity's ledger,
 * carries a mandatory reason (audit evidence), a cost centre, and may be flagged
 * as auto-reversing so the counter entry lands in the following period.
 */

export interface AdjustmentTemplate {
  id: string;
  label: string;
  standard: string;
  hint: string;
  /** Suggested debit / credit account numbers (may be absent in the chart). */
  debit?: string;
  credit?: string;
  autoReverse?: boolean;
}

export const ADJUSTMENT_TEMPLATES: AdjustmentTemplate[] = [
  { id: 'accrual', label: 'Accrued expense (expense not yet billed)', standard: 'IAS 1 / IAS 37', hint: 'Dr expense, Cr accruals. Normally reverses in the next period when the invoice arrives.', debit: '640000', credit: '202000', autoReverse: true },
  { id: 'accrued_income', label: 'Accrued income (revenue earned, not invoiced)', standard: 'IFRS 15', hint: 'Dr accrued income receivable, Cr revenue.', debit: '112000', credit: '400000', autoReverse: true },
  { id: 'prepaid_release', label: 'Prepayment amortisation / release to P&L', standard: 'IAS 1', hint: 'Dr expense, Cr prepayments.', debit: '640000', credit: '124000' },
  { id: 'depreciation', label: 'Depreciation / amortisation top-up', standard: 'IAS 16 / IAS 38', hint: 'Dr depreciation expense, Cr accumulated depreciation.', debit: '680000', credit: '131000' },
  { id: 'provision', label: 'Provision or accrual for liabilities', standard: 'IAS 37', hint: 'Dr expense, Cr provision liability.', debit: '640000', credit: '203000' },
  { id: 'impairment', label: 'Impairment / expected credit loss', standard: 'IFRS 9 / IAS 36', hint: 'Dr impairment expense, Cr allowance account.', debit: '690000', credit: '119000' },
  { id: 'reclass', label: 'Reclassification between accounts', standard: 'IAS 1', hint: 'Move a balance between two ledger accounts without touching profit.' },
  { id: 'error', label: 'Correction of error / misposting', standard: 'IAS 8', hint: 'Correct a previously posted amount; state the original document in the reference.' },
  { id: 'fx', label: 'Foreign exchange revaluation', standard: 'IAS 21', hint: 'Dr/Cr monetary item, opposite entry to FX gain/loss.', debit: '700000', credit: '410000' },
  { id: 'writeoff', label: 'Write-off / write-back', standard: 'IFRS 9 / IAS 2', hint: 'Remove an irrecoverable balance or reinstate a recovered one.' },
  { id: 'stock', label: 'Stock / inventory count adjustment', standard: 'IAS 2', hint: 'Dr or Cr inventory against cost of sales for count differences.', debit: '500000', credit: '120000' },
  { id: 'custom', label: 'Other adjustment (free form)', standard: '—', hint: 'Build the adjustment line by line.' },
];

interface DraftLine {
  key: string;
  accountNo: string;
  debit: number;
  credit: number;
  costCenter: string;
  narrative: string;
}

interface AdjustmentsDeskProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  accounts: AccountMaster[];
  lines: ACDOCALine[];
  closedPeriods?: string[];
  isPeriodClosed?: boolean;
  onAddJournalLines: (newLines: ACDOCALine[]) => boolean;
  /** Reverses a posted adjustment (returns false when blocked). */
  onReverseDocument?: (docNo: string) => boolean;
}

const blankLine = (costCenter = 'CC-ADM'): DraftLine => ({
  key: uniqueId('ADJ-L'),
  accountNo: '',
  debit: 0,
  credit: 0,
  costCenter,
  narrative: '',
});

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const nextPeriod = (period: string) => {
  const [y, m] = period.split('-').map(Number);
  return m >= 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`;
};

export const AdjustmentsDesk: React.FC<AdjustmentsDeskProps> = ({
  currentClient,
  currentUser,
  accounts,
  lines,
  closedPeriods = [],
  onAddJournalLines,
  onReverseDocument,
}) => {
  const today = new Date().toISOString().slice(0, 10);
  const [templateId, setTemplateId] = useState<string>('accrual');
  const [adjDate, setAdjDate] = useState(today);
  const [reference, setReference] = useState('');
  const [reason, setReason] = useState('');
  const [autoReverse, setAutoReverse] = useState(false);
  const [draft, setDraft] = useState<DraftLine[]>([blankLine(), blankLine()]);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const template = ADJUSTMENT_TEMPLATES.find((t) => t.id === templateId) || ADJUSTMENT_TEMPLATES[0];

  // Entity-scoped data only — this desk never shows another entity's figures.
  const clientLines = useMemo(() => lines.filter((l) => l.clientId === currentClient.id), [lines, currentClient.id]);

  const balances = useMemo(() => {
    const map = new Map<string, number>();
    for (const l of clientLines) map.set(l.accountNo, (map.get(l.accountNo) ?? 0) + l.debit - l.credit);
    return map;
  }, [clientLines]);

  const postedAdjustments = useMemo(() => {
    const docs = new Map<string, { docNo: string; date: string; period: string; amount: number; description: string; reversed: boolean; createdBy: string; reference?: string }>();
    for (const l of clientLines) {
      if (!l.docNo.startsWith('ADJ-')) continue;
      const current = docs.get(l.docNo) || { docNo: l.docNo, date: l.date, period: l.period, amount: 0, description: l.description, reversed: false, createdBy: l.createdBy, reference: l.reference };
      current.amount += l.debit;
      current.reversed = current.reversed || !!l.isReversed;
      docs.set(l.docNo, current);
    }
    const reversedDocs = new Set(
      clientLines.filter((l) => l.docType === 'REV').map((l) => l.reference || l.docNo.replace(/^REV-/, ''))
    );
    return [...docs.values()]
      .map((d) => ({ ...d, reversed: d.reversed || reversedDocs.has(d.docNo) }))
      .sort((a, b) => (a.date < b.date ? 1 : -1));
  }, [clientLines]);

  const period = adjDate.slice(0, 7);
  const periodFrozen = closedPeriods.includes(period);
  const totalDr = round2(draft.reduce((s, l) => s + (Number(l.debit) || 0), 0));
  const totalCr = round2(draft.reduce((s, l) => s + (Number(l.credit) || 0), 0));
  const balanced = Math.abs(totalDr - totalCr) < 0.005 && totalDr > 0;
  const mayPost = currentUser.permissions?.canPostJournals !== false && currentUser.status !== 'restricted' && currentUser.status !== 'suspended';

  const applyTemplate = (id: string) => {
    setTemplateId(id);
    const t = ADJUSTMENT_TEMPLATES.find((x) => x.id === id);
    setAutoReverse(!!t?.autoReverse);
    const known = (no?: string) => (no && accounts.some((a) => a.accountNo === no) ? no : '');
    setDraft([
      { ...blankLine(), accountNo: known(t?.debit) },
      { ...blankLine(), accountNo: known(t?.credit) },
    ]);
  };

  const updateLine = (key: string, patch: Partial<DraftLine>) => {
    setDraft((prev) => prev.map((l) => (l.key === key ? { ...l, ...patch } : l)));
  };

  const buildLines = (docNo: string, postPeriod: string, postDate: string, mirror: boolean): ACDOCALine[] =>
    draft
      .filter((l) => l.accountNo && (Number(l.debit) > 0 || Number(l.credit) > 0))
      .map((l, idx) => {
        const meta = accounts.find((a) => a.accountNo === l.accountNo);
        const dr = round2(Number(l.debit) || 0);
        const cr = round2(Number(l.credit) || 0);
        return {
          id: `${uniqueId('JL-ADJ')}-${idx}`,
          docNo,
          period: postPeriod,
          date: postDate,
          module: 'FI' as const,
          docType: 'JE' as const,
          accountNo: l.accountNo,
          accountName: meta?.name || 'Nominal ledger account',
          costCenter: l.costCenter,
          debit: mirror ? cr : dr,
          credit: mirror ? dr : cr,
          currency: currentClient.currency,
          description: `${mirror ? 'Auto-reversal of ' : ''}${template.label}${l.narrative ? ` — ${l.narrative}` : ''}`,
          createdBy: currentUser.username,
          checkedBy: currentUser.canCheck ? currentUser.username : undefined,
          clientId: currentClient.id,
          reference: reference || undefined,
        };
      });

  const handlePost = () => {
    setError(null);
    setSuccess(null);
    if (!mayPost) {
      setError('Your account is not permitted to post journals. Ask the firm owner to grant posting rights.');
      return;
    }
    if (!reason.trim() || reason.trim().length < 8) {
      setError('An adjustment requires a written reason (audit evidence) of at least 8 characters.');
      return;
    }
    if (!balanced) {
      setError(`The adjustment does not balance: debits ₵${formatGHS(totalDr)} vs credits ₵${formatGHS(totalCr)}. Dr must equal Cr and be greater than zero.`);
      return;
    }
    if (draft.some((l) => (Number(l.debit) > 0 && Number(l.credit) > 0))) {
      setError('A single line may carry either a debit or a credit, never both. Split it into two lines.');
      return;
    }
    if (periodFrozen) {
      setError(`Period ${period} is closed for ${currentClient.code}. Reopen it in Month-End Close or date the adjustment in an open period.`);
      return;
    }
    const docNo = `ADJ-${currentClient.code}-${adjDate.replace(/-/g, '')}-${uniqueId('').slice(-4).toUpperCase()}`;
    const entries = buildLines(docNo, period, adjDate, false);
    if (entries.length < 2) {
      setError('An adjustment needs at least two posting lines with an account and an amount.');
      return;
    }
    entries[0] = { ...entries[0], description: `${entries[0].description} | Reason: ${reason.trim()}` };
    if (!onAddJournalLines(entries)) {
      setError(`The adjustment ${docNo} was NOT posted. Check that the period is open, every account exists in the chart of accounts and Dr = Cr.`);
      return;
    }
    let message = `Adjustment ${docNo} posted to ${currentClient.code}: ₵${formatGHS(totalDr)}.`;
    if (autoReverse) {
      const revPeriod = nextPeriod(period);
      if (closedPeriods.includes(revPeriod)) {
        message += ` The auto-reversal was NOT posted: period ${revPeriod} is already closed — post it manually when the period is reopened.`;
      } else {
        const revDate = `${revPeriod}-01`;
        const revEntries = buildLines(`${docNo}-AR`, revPeriod, revDate, true);
        message += onAddJournalLines(revEntries)
          ? ` Auto-reversal ${docNo}-AR posted in ${revPeriod}.`
          : ` The auto-reversal in ${revPeriod} was REJECTED — post it manually.`;
      }
    }
    setSuccess(message);
    setDraft([blankLine(), blankLine()]);
    setReason('');
    setReference('');
    setTimeout(() => setSuccess(null), 9000);
  };

  const handleReverse = (docNo: string) => {
    if (!onReverseDocument) return;
    const ok = onReverseDocument(docNo);
    if (ok) {
      setSuccess(`Reversal posted for ${docNo} in the current period.`);
      setTimeout(() => setSuccess(null), 6000);
    } else {
      setError(`Reversal blocked for ${docNo}: it may already be reversed, or the current period is frozen for ${currentClient.code}.`);
      setTimeout(() => setError(null), 8000);
    }
  };

  const sortedAccounts = [...accounts].sort((a, b) => a.accountNo.localeCompare(b.accountNo));

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`FI · ADJUSTMENT OF ACCOUNTS · ${currentClient.code}`}
        title="Adjustments Desk"
        desc={`Period-end and corrective adjustments for ${currentClient.name} only. Accruals, prepayment releases, depreciation, provisions, impairments, reclassifications, error corrections, FX revaluation and write-offs — each posted as a balanced, reasoned ADJ document in this entity's ledger.`}
      />

      {success && (
        <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-xs font-bold text-emerald-900 flex items-start gap-2 shadow-xs">
          <CheckCircle className="h-4 w-4 shrink-0 mt-0.5 text-emerald-700" />
          <span>{success}</span>
        </div>
      )}
      {error && (
        <div role="alert" className="rounded-xl border border-rose-300 bg-rose-50 p-4 text-xs font-bold text-rose-900 flex items-start gap-2 shadow-xs">
          <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-rose-700" />
          <span>{error}</span>
        </div>
      )}

      <Card title="Build an adjustment" sub={`${template.standard} · ${template.hint}`}>
        <div className="p-4 space-y-4 text-xs">
          <div className="grid gap-3 md:grid-cols-4">
            <div className="md:col-span-2">
              <label className="block font-bold text-[#0a253e] mb-1">Adjustment type</label>
              <select
                value={templateId}
                onChange={(e) => applyTemplate(e.target.value)}
                className="w-full rounded border border-sky-300 px-2 py-1.5 font-semibold text-[#082f4f] outline-none"
              >
                {ADJUSTMENT_TEMPLATES.map((t) => (
                  <option key={t.id} value={t.id}>{t.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-bold text-[#0a253e] mb-1">Adjustment date</label>
              <input
                type="date"
                value={adjDate}
                onChange={(e) => setAdjDate(e.target.value)}
                className="w-full rounded border border-sky-300 px-2 py-1.5 font-mono font-bold text-[#082f4f] outline-none"
              />
              {periodFrozen && (
                <span className="mt-1 block text-[10.5px] font-bold text-rose-700">Period {period} is closed for this entity.</span>
              )}
            </div>
            <div>
              <label className="block font-bold text-[#0a253e] mb-1">Reference / source document</label>
              <input
                type="text"
                value={reference}
                placeholder="e.g. INV-2026-014 or audit memo 3"
                onChange={(e) => setReference(e.target.value)}
                className="w-full rounded border border-sky-300 px-2 py-1.5 font-semibold text-[#082f4f] outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-[#0a253e] mb-1">Reason for the adjustment (mandatory audit evidence)</label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={2}
              placeholder="Explain why the books are being adjusted, who approved it and what evidence supports it."
              className="w-full rounded border border-sky-300 px-2 py-1.5 font-semibold text-[#082f4f] outline-none"
            />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-xs">
              <thead>
                <tr className="border-b border-sky-200 bg-sky-50/70">
                  <th className={thCls}>Account</th>
                  <th className={thCls}>Cost centre</th>
                  <th className={thCls}>Line narrative</th>
                  <th className={thCls + ' text-right'}>Debit</th>
                  <th className={thCls + ' text-right'}>Credit</th>
                  <th className={thCls + ' text-right'}>Current balance</th>
                  <th className={thCls}></th>
                </tr>
              </thead>
              <tbody>
                {draft.map((l) => (
                  <tr key={l.key} className={rowCls}>
                    <td className="px-3 py-1.5">
                      <select
                        value={l.accountNo}
                        onChange={(e) => updateLine(l.key, { accountNo: e.target.value })}
                        className="w-full min-w-[220px] rounded border border-sky-200 px-2 py-1 font-semibold text-[#082f4f] outline-none"
                      >
                        <option value="">— select account —</option>
                        {sortedAccounts.map((a) => (
                          <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>
                        ))}
                      </select>
                    </td>
                    <td className="px-3 py-1.5">
                      <select
                        value={l.costCenter}
                        onChange={(e) => updateLine(l.key, { costCenter: e.target.value })}
                        className="rounded border border-sky-200 px-2 py-1 font-mono font-bold text-[#082f4f] outline-none"
                      >
                        {COST_CENTRES.map((c) => (
                          <option key={c.code} value={c.code}>{c.code} · {c.name}</option>
                        ))}
                      </select>
                    </td>
                    <td className="px-3 py-1.5">
                      <input
                        type="text"
                        value={l.narrative}
                        onChange={(e) => updateLine(l.key, { narrative: e.target.value })}
                        className="w-full min-w-[160px] rounded border border-sky-200 px-2 py-1 text-[#082f4f] outline-none"
                      />
                    </td>
                    <td className="px-3 py-1.5 text-right">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={l.debit || ''}
                        onChange={(e) => updateLine(l.key, { debit: Number(e.target.value), credit: 0 })}
                        className="w-28 rounded border border-sky-200 px-2 py-1 text-right font-mono font-bold text-[#082f4f] outline-none"
                      />
                    </td>
                    <td className="px-3 py-1.5 text-right">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={l.credit || ''}
                        onChange={(e) => updateLine(l.key, { credit: Number(e.target.value), debit: 0 })}
                        className="w-28 rounded border border-sky-200 px-2 py-1 text-right font-mono font-bold text-[#082f4f] outline-none"
                      />
                    </td>
                    <td className={numCls}>
                      {l.accountNo ? formatGHS(balances.get(l.accountNo) ?? 0) : '—'}
                    </td>
                    <td className="px-3 py-1.5 text-center">
                      <button
                        onClick={() => setDraft((prev) => (prev.length > 2 ? prev.filter((x) => x.key !== l.key) : prev))}
                        disabled={draft.length <= 2}
                        className="rounded border border-rose-200 bg-rose-50 p-1 text-rose-700 hover:bg-rose-100 disabled:opacity-30"
                        title="Remove line"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <button
              onClick={() => setDraft((prev) => [...prev, blankLine()])}
              className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-1.5 text-xs font-bold text-[#082f4f] hover:bg-sky-50"
            >
              <Plus className="h-3.5 w-3.5" /> Add line
            </button>

            <label className="flex items-center gap-2 text-[11.5px] font-bold text-[#163653]">
              <input type="checkbox" checked={autoReverse} onChange={(e) => setAutoReverse(e.target.checked)} />
              Auto-reverse in {nextPeriod(period)} (accruals &amp; deferrals)
            </label>

            <div className="flex items-center gap-5 font-mono text-xs">
              <span>Dr <strong className="text-[#8a5d00]">₵{formatGHS(totalDr)}</strong></span>
              <span>Cr <strong className="text-[#087a55]">₵{formatGHS(totalCr)}</strong></span>
              <Badge tone={balanced ? 'green' : 'red'}>
                <Scale className="h-3 w-3" /> {balanced ? 'Balanced' : `Out by ₵${formatGHS(Math.abs(totalDr - totalCr))}`}
              </Badge>
              <button
                onClick={handlePost}
                disabled={!balanced || periodFrozen || !mayPost}
                className="rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] disabled:bg-slate-300 disabled:text-slate-500"
              >
                Post adjustment
              </button>
            </div>
          </div>
        </div>
      </Card>

      <Card title="Adjustments register" sub={`Adjusting documents posted to ${currentClient.code} — other entities are never listed here`}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Document</th>
                <th className={thCls}>Date</th>
                <th className={thCls}>Period</th>
                <th className={thCls}>Narrative</th>
                <th className={thCls}>Posted by</th>
                <th className={thCls + ' text-right'}>Value</th>
                <th className={thCls + ' text-center'}>Action</th>
              </tr>
            </thead>
            <tbody>
              {postedAdjustments.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-3 py-6 text-center text-[#355875]">
                    No adjustments posted for this entity yet.
                  </td>
                </tr>
              )}
              {postedAdjustments.map((d) => (
                <tr key={d.docNo} className={`${rowCls} ${d.reversed ? 'opacity-60' : ''}`}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">
                    {d.docNo}
                    {d.reversed && (
                      <span className="ml-1.5 rounded border border-rose-300 bg-rose-100 px-1 text-[9px] font-bold text-rose-800">REVERSED</span>
                    )}
                  </td>
                  <td className="px-3 py-2 font-mono text-[#2d4f6d]">{d.date}</td>
                  <td className="px-3 py-2 font-mono text-[#2d4f6d]">{d.period}</td>
                  <td className="px-3 py-2 max-w-[320px] truncate text-[#0a253e]" title={d.description}>{d.description}</td>
                  <td className="px-3 py-2 font-mono text-[#355875]">{d.createdBy}</td>
                  <td className={numCls + ' font-bold'}>₵{formatGHS(d.amount)}</td>
                  <td className="px-3 py-2 text-center">
                    <button
                      onClick={() => handleReverse(d.docNo)}
                      disabled={d.reversed || !onReverseDocument}
                      className="rounded border border-rose-300 bg-rose-50 px-2 py-0.5 text-[10.5px] font-bold text-rose-800 hover:bg-rose-100 disabled:opacity-40"
                    >
                      <RotateCcw className="mr-1 inline h-3 w-3" />Reverse
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default AdjustmentsDesk;
