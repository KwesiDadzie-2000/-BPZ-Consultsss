import { useMemo, useState } from 'react';
import type { AccountMaster, ACDOCALine, ClientEntity, UserAccount } from '../types/accounting';
import { Card, PageHeader, StatusBadge, formatGHS, thCls, numCls, rowCls } from './ui';
import { FilePlus2, ArrowRight, ReceiptText, ShieldCheck } from 'lucide-react';
import { taxConfigStore } from '../utils/taxConfig';
import { computeExpenseVatSplit } from '../utils/transactionMath';
import { persistentStorage } from '../utils/persistentStorage';
import { EXPENSE_BILL_PREFIX, EXPENSE_PAYABLE_ACCOUNT, deriveExpenseBills } from '../utils/payables';
import { StatutoryPayablesCard } from './StatutoryPayables';
import { docSuffix } from '../utils/ids';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  isPeriodClosed: boolean;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  onAddJournalLines: (lines: ACDOCALine[]) => boolean;
  onNavigate?: (section: string) => void;
  onApprovalSubmitted?: () => void;
}

/**
 * Expenses & Statutory desk — RECORDS obligations, never moves money.
 * Every expense bill posts Dr expense (+ recoverable input VAT) / Cr 202000
 * Accrued Expenses & Other Payables. Payment is effected exclusively at the
 * Payment Desk, which clears the payable against bank/cash. Statutory payables
 * (PAYE, SSNIT Tier 1 13.5%, Tier 2 5%, WHT, VAT…) are visible here the moment
 * their source document (payroll, settlement, invoice) is posted.
 */
export const ExpensesSection = ({ currentClient, currentUser, isPeriodClosed, lines, accounts, onAddJournalLines, onNavigate, onApprovalSubmitted }: Props) => {
  const [period, setPeriod] = useState(() => new Date().toISOString().slice(0, 7));
  const [payee, setPayee] = useState('');
  const eligible = useMemo(() => accounts.filter(a => a.active && a.type === 'Expense'), [accounts]);
  const [accountNo, setAccountNo] = useState(eligible.find(a => a.accountNo === '620000')?.accountNo || eligible[0]?.accountNo || '620000');
  const [costCenter, setCostCenter] = useState('CC-ADM');
  const [amount, setAmount] = useState(0);
  const [narration, setNarration] = useState('');
  const [vatInclusive, setVatInclusive] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const selectedAccount = eligible.find(a => a.accountNo === accountNo);
  const clientLines = useMemo(() => lines.filter(l => l.clientId === currentClient.id), [lines, currentClient.id]);
  const bills = useMemo(() => deriveExpenseBills(lines, currentClient.id), [lines, currentClient.id]);
  const openBills = bills.filter(b => b.status === 'Awaiting payment' || b.status === 'Partially paid');
  const settledBills = bills.filter(b => b.status === 'Paid' || b.status === 'Reversed');
  const totalAwaiting = openBills.reduce((s, b) => s + b.outstanding, 0);

  // Period activity across expense and payable accounts — debits AND credits, so
  // accruals and Payment-Desk settlements both show correctly.
  const periodAccounts = accounts.filter(a => a.type === 'Expense' || a.accountNo === EXPENSE_PAYABLE_ACCOUNT);
  const periodLines = clientLines.filter(l => l.period === period);
  const summary = periodAccounts.map(a => {
    const rows = periodLines.filter(l => l.accountNo === a.accountNo);
    return {
      account: a,
      debit: rows.reduce((n, l) => n + l.debit, 0),
      credit: rows.reduce((n, l) => n + l.credit, 0),
    };
  }).filter(x => x.debit !== 0 || x.credit !== 0);

  const restricted = currentUser.status === 'restricted' || currentUser.status === 'suspended' || currentUser.permissions?.canPostJournals === false;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isPeriodClosed) return setFeedback('Recording blocked: the accounting period is closed.');
    if (restricted) return setFeedback('Recording blocked: this user is restricted from creating journals.');
    if (!payee.trim() || !selectedAccount || amount <= 0 || !Number.isFinite(amount)) return setFeedback('Payee, expense account and a positive amount are required.');
    if (period > new Date().toISOString().slice(0, 7)) return setFeedback('Recording blocked: the expense period cannot be in the future.');
    if ((persistentStorage.getClosedPeriods()[currentClient.id] || []).includes(period)) return setFeedback(`Recording blocked: period ${period} is closed for this entity.`);

    const date = new Date().toISOString().slice(0, 10);
    const billNo = `${EXPENSE_BILL_PREFIX}${period}-${docSuffix()}`;
    const vatRate = taxConfigStore.rate('VAT') + taxConfigStore.rate('NHIL') + taxConfigStore.rate('GETFUND');
    const split = computeExpenseVatSplit(amount, vatInclusive, vatRate);
    const desc = narration.trim() || `${selectedAccount.category} — ${payee.trim()}`;
    const base = { docNo: billNo, period, date, module: 'FI' as const, docType: 'STAT' as const, costCenter, currency: currentClient.currency, createdBy: currentUser.username, clientId: currentClient.id, reference: billNo };
    const entries: ACDOCALine[] = [
      { ...base, id: `JL-${billNo}-1`, accountNo: selectedAccount.accountNo, accountName: selectedAccount.name, debit: split.net, credit: 0, description: `${payee.trim()} — ${desc}` },
      { ...base, id: `JL-${billNo}-2`, accountNo: EXPENSE_PAYABLE_ACCOUNT, accountName: `Accrued Expenses & Other Payables (${payee.trim()})`, debit: 0, credit: split.gross, description: `Expense bill ${billNo} payable to ${payee.trim()} — settle at the Payment Desk` },
    ];
    if (split.vat > 0) entries.splice(1, 0, { ...base, id: `JL-${billNo}-1b`, accountNo: '125000', accountName: 'VAT Input Tax Recoverable', debit: split.vat, credit: 0, description: `Input VAT on ${payee.trim()} bill ${billNo}` });

    // Maker-checker: above the maker limit the bill goes to the approval queue and
    // is posted exactly once when an independent checker signs off.
    if (currentUser.makerLimit > 0 && split.gross > currentUser.makerLimit) {
      persistentStorage.addApprovalRequest({
        id: `APP-${billNo}`, clientId: currentClient.id, clientCode: currentClient.code, clientName: currentClient.name,
        docNo: billNo, docType: 'JE', amount: split.gross,
        requestedBy: `${currentUser.name} (${currentUser.username})`, requestedAt: new Date().toISOString(),
        description: `Expense bill: ${payee.trim()} — ${desc}`,
        reasonForApproval: `Bill ${formatGHS(split.gross)} exceeds maker limit ${formatGHS(currentUser.makerLimit)}. On approval the payable is recorded; payment still passes the Payment Desk.`,
        status: 'pending', payload: { lines: entries },
      });
      if (onApprovalSubmitted) onApprovalSubmitted();
      setFeedback(`${billNo} submitted to the approval queue (exceeds your maker limit of ${formatGHS(currentUser.makerLimit)}). Once approved it becomes payable at the Payment Desk.`);
      setPayee(''); setAmount(0); setNarration('');
      return;
    }

    const ok = onAddJournalLines(entries);
    if (!ok) return setFeedback('Recording rejected. Confirm the period is open and the ledger accepts the document.');
    setFeedback(`${billNo} recorded: ${payee.trim()} payable ${formatGHS(split.gross)} (GL ${EXPENSE_PAYABLE_ACCOUNT}). It is now awaiting payment at the Payment Desk — no money has left the bank.`);
    setPayee(''); setAmount(0); setNarration('');
  };

  const errorTone = feedback && (feedback.includes('blocked') || feedback.includes('required') || feedback.includes('rejected'));

  return <div className="space-y-6">
    <PageHeader kicker={`EXP · Obligation Recording & Statutory Register · ${currentClient.code}`} title="Expenses & Statutory Desk" desc="Record expense bills as payables and monitor statutory obligations. Every payment — expense or statutory — is effected only at the Payment Desk." />

    {/* Workflow strip: record here → pay at the Payment Desk */}
    <div className="grid gap-3 sm:grid-cols-3">
      {[
        { icon: FilePlus2, title: '1 · Record the bill', text: 'Dr expense (+ input VAT) · Cr 202000 payable. No cash moves at this desk.' },
        { icon: ShieldCheck, title: '2 · Maker-checker control', text: 'Bills above your maker limit queue for independent approval before posting.' },
        { icon: ReceiptText, title: '3 · Pay at the Payment Desk', text: 'Treasury clears the payable: Dr 202000 / statutory GL · Cr bank or cash.' },
      ].map(s => (
        <div key={s.title} className="rounded-xl border border-sky-200 bg-white p-4 shadow-xs transition hover:shadow-md hover:border-sky-300">
          <s.icon className="h-5 w-5 text-[#006f98]" />
          <div className="mt-2 text-xs font-black text-[#082f4f]">{s.title}</div>
          <div className="mt-1 text-[11px] leading-relaxed text-[#355875]">{s.text}</div>
        </div>
      ))}
    </div>

    {feedback && <div className={`rounded-lg border p-3 text-xs font-bold ${errorTone ? 'border-rose-300 bg-rose-50 text-rose-900' : 'border-emerald-300 bg-emerald-50 text-emerald-900'}`}>{feedback}</div>}

    <Card
      title="Record an expense bill (payable)"
      sub="Debit expense GL (+ recoverable input VAT) · credit 202000 Accrued Expenses & Other Payables. Payment is effected at the Payment Desk."
    >
      <form onSubmit={submit} className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
        <label className="font-bold text-[#355875] sm:col-span-2">Payee / vendor<input value={payee} onChange={e => setPayee(e.target.value)} placeholder="e.g. ECG, landlord, consultant, supplier" className="mt-1 w-full rounded border border-sky-300 p-2" required /></label>
        <label className="font-bold text-[#355875]">Expense period<input type="month" value={period} max={new Date().toISOString().slice(0, 7)} onChange={e => setPeriod(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2" required /></label>
        <label className="font-bold text-[#355875] sm:col-span-2">Expense GL account<select value={accountNo} onChange={e => setAccountNo(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2 font-semibold text-[#082f4f]">{eligible.map(a => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>)}</select></label>
        <label className="font-bold text-[#355875]">Cost centre<input value={costCenter} onChange={e => setCostCenter(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" required /></label>
        <label className="font-bold text-[#355875]">Bill amount (gross)<input type="number" min="0" step="0.01" value={amount || ''} onChange={e => setAmount(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" required /></label>
        <label className="font-bold text-[#355875]">Bill VAT treatment<select value={vatInclusive ? 'inclusive' : 'none'} onChange={e => setVatInclusive(e.target.value === 'inclusive')} className="mt-1 w-full rounded border border-sky-300 p-2 font-semibold text-[#082f4f]"><option value="none">No VAT — bill not VAT-inclusive</option><option value="inclusive">VAT-inclusive — split recoverable input VAT</option></select></label>
        <label className="font-bold text-[#355875]">Narration<input value={narration} onChange={e => setNarration(e.target.value)} placeholder="What is this cost for?" className="mt-1 w-full rounded border border-sky-300 p-2" /></label>
        <button type="submit" disabled={isPeriodClosed || restricted} className="sm:col-span-3 rounded bg-[#082f4f] text-white font-bold py-2.5 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 transition hover:bg-[#0c3f68]"><FilePlus2 className="h-3.5 w-3.5" /> Record bill as payable — send to Payment Desk</button>
      </form>
    </Card>

    <Card
      title="Expense bills awaiting payment"
      sub={`${openBills.length} open bill(s) · ${currentClient.currency} ${formatGHS(totalAwaiting)} outstanding at the Payment Desk`}
      action={onNavigate && openBills.length > 0 ? (
        <button onClick={() => onNavigate('payment_desk')} className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-2 text-xs font-bold text-white transition hover:bg-emerald-800 shadow-xs">
          Open Payment Desk <ArrowRight className="h-3.5 w-3.5" />
        </button>
      ) : undefined}
    >
      <div className="overflow-x-auto"><table className="w-full min-w-[820px] text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Bill</th><th className={thCls}>Payee</th><th className={thCls}>Expense GL</th><th className={thCls}>Period</th><th className={thCls + ' text-right'}>Gross</th><th className={thCls + ' text-right'}>Paid</th><th className={thCls + ' text-right'}>Outstanding</th><th className={thCls}>Status</th></tr></thead><tbody>
        {openBills.length ? openBills.map(b => (
          <tr key={b.billNo} className={rowCls}>
            <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{b.billNo}</td>
            <td className="px-3 py-2 font-bold text-[#082f4f]">{b.payee}<span className="block text-[10px] font-normal text-[#355875]">{b.description}</span></td>
            <td className="px-3 py-2 font-mono">{b.expenseAccountNo}</td>
            <td className="px-3 py-2 font-mono">{b.period}</td>
            <td className={numCls}>{formatGHS(b.gross)}</td>
            <td className={numCls}>{formatGHS(b.paid)}</td>
            <td className={numCls + ' font-bold text-rose-700'}>{formatGHS(b.outstanding)}</td>
            <td className="px-3 py-2"><StatusBadge status={b.status} /></td>
          </tr>
        )) : <tr><td colSpan={8} className="p-6 text-center text-[#355875]">No expense bills awaiting payment. Recorded bills appear here instantly and at the Payment Desk.</td></tr>}
      </tbody></table></div>
      {settledBills.length > 0 && <details className="mt-3 text-xs"><summary className="cursor-pointer font-bold text-[#355875] hover:text-[#082f4f]">Settled / reversed bills ({settledBills.length})</summary>
        <div className="mt-2 overflow-x-auto"><table className="w-full text-xs"><thead><tr className="border-b border-sky-200"><th className={thCls}>Bill</th><th className={thCls}>Payee</th><th className={thCls + ' text-right'}>Gross</th><th className={thCls}>Status</th></tr></thead><tbody>
          {settledBills.map(b => <tr key={b.billNo} className={rowCls}><td className="px-3 py-2 font-mono">{b.billNo}</td><td className="px-3 py-2">{b.payee}</td><td className={numCls}>{formatGHS(b.gross)}</td><td className="px-3 py-2"><StatusBadge status={b.status} /></td></tr>)}
        </tbody></table></div>
      </details>}
    </Card>

    <StatutoryPayablesCard
      lines={lines}
      clientId={currentClient.id}
      currency={currentClient.currency}
      onAction={onNavigate ? () => onNavigate('payment_desk') : undefined}
      actionLabel="Remit at Payment Desk"
    />

    <Card title={`Period activity — ${period}`} sub="Debits and credits on expense and payable accounts, derived from posted journal lines.">
      <div className="flex gap-3 pb-3"><label className="text-xs font-bold text-[#355875]">Reporting month<input type="month" value={period} onChange={e => setPeriod(e.target.value)} className="block mt-1 p-2 border border-sky-300 rounded" /></label></div>
      <div className="overflow-x-auto"><table className="w-full min-w-[700px] text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>GL</th><th className={thCls}>Account</th><th className={thCls + ' text-right'}>Debits (incurred / settled)</th><th className={thCls + ' text-right'}>Credits (accrued / reversed)</th><th className={thCls + ' text-right'}>Net movement</th></tr></thead><tbody>
        {summary.length ? summary.map(x => (
          <tr key={x.account.accountNo} className={rowCls}>
            <td className="p-2 font-mono font-bold text-[#855b00]">{x.account.accountNo}</td>
            <td className="p-2 font-bold text-[#082f4f]">{x.account.name}</td>
            <td className={numCls}>{formatGHS(x.debit)}</td>
            <td className={numCls}>{formatGHS(x.credit)}</td>
            <td className={numCls + ' font-bold'}>{formatGHS(x.debit - x.credit)}</td>
          </tr>
        )) : <tr><td colSpan={5} className="p-6 text-center text-[#355875]">No expense or payable activity posted in this period.</td></tr>}
      </tbody></table></div>
    </Card>
  </div>;
};
