'use client';

/**
 * Complete IAS 1 / IAS 18 financial statements.
 *
 * The presentation deliberately follows the printed statutory format rather
 * than a dashboard: a dense two-column accounting statement (particulars |
 * amount) with sub-total rules, negative amounts in parentheses, a comparative
 * column for every figure as IAS 1.38 requires, and the notes that IAS 1.112
 * calls for. It is the one screen in the suite designed to be printed and
 * handed to an auditor.
 */

import { useMemo } from 'react';
import { Printer } from 'lucide-react';
import type { AccountMaster, ACDOCALine, UserAccount } from '@/types/accounting';
import type { ClientEntity } from '@/types/accounting';
import { buildIasStatements, type StatementSection } from '@/utils/statements';
import { printReport, type PrintReportSpec, type PrintSection } from '@/utils/printReport';
import { toPrintEntity } from '@/utils/printEntity';

const fmt = (n: number) => (n < 0 ? `(${Math.abs(n).toLocaleString('en-GH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})` : n.toLocaleString('en-GH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));

const ruleFor = (kind?: 'sub' | 'total') =>
  kind === 'total' ? 'border-t-2 border-b-4 border-double border-[#082f4f] bg-sky-50/70 font-black text-[#082f4f]'
    : kind === 'sub' ? 'border-t border-[#082f4f] font-bold text-[#082f4f]'
      : '';

function StatementBlock({ section, currency, comparativeLabel }: { section: StatementSection; currency: string; comparativeLabel: string }) {
  return (
    <section className="mb-5 break-inside-avoid">
      <h3 className="mb-1 text-[11px] font-black uppercase tracking-[0.14em] text-[#082f4f]">{section.title}</h3>
      <table className="w-full border-collapse text-[11px]">
        <thead>
          <tr className="border-y border-sky-300 bg-sky-50/80">
            <th className="px-2 py-1.5 text-left text-[9.5px] font-bold uppercase tracking-[0.1em] text-[#355875]">Particulars</th>
            <th className="px-2 py-1.5 text-right text-[9.5px] font-bold uppercase tracking-[0.1em] text-[#355875]">{currency}</th>
            <th className="px-2 py-1.5 text-right text-[9.5px] font-bold uppercase tracking-[0.1em] text-[#355875]">{comparativeLabel}</th>
          </tr>
        </thead>
        <tbody className="font-mono tabular-nums">
          {section.rows.map((row, i) => (
            <tr key={`${row.label}-${i}`} className={`border-b border-sky-100 ${ruleFor(row.emphasis)}`}>
              <td className={`px-2 py-1 font-sans text-[#0a253e] ${row.indent ? 'pl-6' : ''}`}>
                {row.label}
                {row.ref && <span className="ml-2 text-[8.5px] font-bold uppercase tracking-wider text-[#855b00]">{row.ref}</span>}
              </td>
              <td className="px-2 py-1 text-right">{fmt(row.current)}</td>
              <td className="px-2 py-1 text-right text-[#355875]">{fmt(row.comparative)}</td>
            </tr>
          ))}
          <tr className={`border-y-2 border-[#082f4f] bg-sky-100/80 font-black text-[#082f4f] ${ruleFor('total')}`}>
            <td className="px-2 py-1.5 font-sans">{section.totalLabel}</td>
            <td className="px-2 py-1.5 text-right">{fmt(section.totalCurrent)}</td>
            <td className="px-2 py-1.5 text-right">{fmt(section.totalComparative)}</td>
          </tr>
        </tbody>
      </table>
    </section>
  );
}

function toPrintSections(sections: StatementSection[], comparativeLabel: string): PrintSection[] {
  return sections.map((s) => ({
    title: s.title,
    columns: [
      { key: 'label', label: 'Particulars', width: '52%' },
      { key: 'current', label: 'Amount', numeric: true, width: '24%' },
      { key: 'comparative', label: comparativeLabel, numeric: true, width: '24%' },
    ],
    rows: s.rows.map((r) => ({ label: r.label, current: r.current, comparative: r.comparative })),
    totals: { label: s.totalLabel, current: s.totalCurrent, comparative: s.totalComparative },
  }));
}

export function FinancialStatementsCard({ currentClient, lines, accounts, from, through, currentUser }: {
  currentClient: ClientEntity;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  from: string;
  through: string;
  currentUser: UserAccount;
}) {
  const statements = useMemo(
    () => buildIasStatements(
      lines.filter((l) => l.clientId === currentClient.id),
      accounts,
      from,
      through,
      currentClient.currency,
      currentClient.name,
    ),
    [lines, accounts, currentClient, from, through],
  );

  const print = () => {
    const entity = toPrintEntity(currentClient, null);
    const noteSections: PrintSection[] = statements.notes.map((n) => ({
      title: `Note ${n.number} — ${n.title}`,
      columns: n.table
        ? n.table.columns.map((c, i) => ({ key: `c${i}`, label: c, numeric: i > 0 }))
        : [{ key: 'text', label: 'Disclosure' }],
      rows: n.table
        ? n.table.rows.map((row) => Object.fromEntries(row.map((v, i) => [`c${i}`, v])))
        : n.paragraphs.map((p) => ({ text: p })),
      totals: n.table?.totals ? Object.fromEntries(n.table.totals.map((v, i) => [`c${i}`, v])) : undefined,
    }));
    const spec: PrintReportSpec = {
      title: `Financial Statements of ${currentClient.name}`,
      kicker: 'IAS 1 Presentation of Financial Statements · IAS 18 Revenue',
      subtitle: `For the period ${statements.periodLabel} · presented in ${currentClient.currency}`,
      entity,
      periodLabel: statements.periodLabel,
      preparedBy: currentUser.name,
      stats: [
        { label: 'Revenue', value: statements.totals.revenue },
        { label: 'Profit for the period', value: statements.totals.profitForPeriod },
        { label: 'Total assets', value: statements.totals.totalAssets },
        { label: 'Total equity', value: statements.totals.totalEquityAndLiabilities - (statements.financialPosition[3].totalCurrent + statements.financialPosition[4].totalCurrent) },
      ],
      sections: [
        ...toPrintSections(statements.financialPosition, statements.comparativeLabel),
        ...toPrintSections(statements.profitOrLoss, statements.comparativeLabel),
        ...toPrintSections(statements.otherComprehensiveIncome, statements.comparativeLabel),
        ...toPrintSections(statements.changesInEquity, statements.comparativeLabel),
        ...toPrintSections(statements.cashFlows, statements.comparativeLabel),
        ...noteSections,
      ],
      paragraphs: [
        `These financial statements have been prepared in accordance with International Financial Reporting Standards. The comparative column for the statement of financial position is the position at the beginning of the reporting period; the comparative column for the performance statements is the equivalent prior-year period (${statements.comparativeLabel}).`,
        statements.totals.balanced
          ? 'The statement of financial position balances: total assets equal total equity and liabilities.'
          : 'WARNING — the statement of financial position does not balance. Review the chart of accounts classification before issuing these statements.',
      ],
      footerNote: 'Approved by the Board of Directors and authorised for issue on behalf of the entity. Retain with the signed minutes.',
    };
    printReport(spec);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3 rounded-lg border border-sky-200 bg-white p-4">
        <div>
          <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#855b00]">IAS 1 · IAS 18</div>
          <h2 className="text-xl font-black tracking-tight text-[#082f4f]">Financial statements of {currentClient.name}</h2>
          <p className="mt-1 text-[11px] text-[#355875]">
            For the period <strong>{statements.periodLabel}</strong> · comparative <strong>{statements.comparativeLabel}</strong> · presented in {currentClient.currency}
          </p>
        </div>
        <button onClick={print} className="flex items-center gap-1.5 rounded bg-[#082f4f] px-4 py-2 text-xs font-bold text-white transition hover:bg-[#0c3f68]">
          <Printer className="h-3.5 w-3.5" /> Print full statements
        </button>
      </div>

      {!statements.totals.balanced && (
        <div role="alert" className="rounded border border-rose-300 bg-rose-50 p-3 text-xs font-bold text-rose-900">
          The statement of financial position does not balance (total assets {fmt(statements.totals.totalAssets)} against equity and liabilities {fmt(statements.totals.totalEquityAndLiabilities)}).
          Review the account classification in the chart of accounts before issuing these statements.
        </div>
      )}

      <div className="rounded-lg border border-sky-200 bg-white p-5">
        <div className="mb-4 border-b-2 border-[#082f4f] pb-2">
          <div className="text-[9.5px] font-bold uppercase tracking-[0.18em] text-[#855b00]">Statement of financial position</div>
          <div className="text-sm font-black text-[#082f4f]">As at {through}</div>
        </div>
        {statements.financialPosition.map((s) => <StatementBlock key={s.title} section={s} currency={currentClient.currency} comparativeLabel={statements.comparativeLabel} />)}
      </div>

      <div className="rounded-lg border border-sky-200 bg-white p-5">
        <div className="mb-4 border-b-2 border-[#082f4f] pb-2">
          <div className="text-[9.5px] font-bold uppercase tracking-[0.18em] text-[#855b00]">Statement of profit or loss and other comprehensive income</div>
          <div className="text-sm font-black text-[#082f4f]">For the period {statements.periodLabel}</div>
        </div>
        {statements.profitOrLoss.map((s) => <StatementBlock key={s.title} section={s} currency={currentClient.currency} comparativeLabel={statements.comparativeLabel} />)}
        {statements.otherComprehensiveIncome.map((s) => <StatementBlock key={`oci-${s.title}`} section={s} currency={currentClient.currency} comparativeLabel={statements.comparativeLabel} />)}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="rounded-lg border border-sky-200 bg-white p-5">
          <div className="mb-4 border-b-2 border-[#082f4f] pb-2">
            <div className="text-[9.5px] font-bold uppercase tracking-[0.18em] text-[#855b00]">Statement of changes in equity</div>
            <div className="text-sm font-black text-[#082f4f]">{statements.periodLabel}</div>
          </div>
          {statements.changesInEquity.map((s) => <StatementBlock key={`sce-${s.title}`} section={s} currency={currentClient.currency} comparativeLabel={statements.comparativeLabel} />)}
        </div>
        <div className="rounded-lg border border-sky-200 bg-white p-5">
          <div className="mb-4 border-b-2 border-[#082f4f] pb-2">
            <div className="text-[9.5px] font-bold uppercase tracking-[0.18em] text-[#855b00]">Statement of cash flows (IAS 7)</div>
            <div className="text-sm font-black text-[#082f4f]">{statements.periodLabel}</div>
          </div>
          {statements.cashFlows.map((s) => <StatementBlock key={`cf-${s.title}`} section={s} currency={currentClient.currency} comparativeLabel={statements.comparativeLabel} />)}
        </div>
      </div>

      <div className="rounded-lg border border-sky-200 bg-white p-5">
        <div className="mb-4 border-b-2 border-[#082f4f] pb-2">
          <div className="text-[9.5px] font-bold uppercase tracking-[0.18em] text-[#855b00]">Notes to the financial statements</div>
          <div className="text-sm font-black text-[#082f4f]">Forming an integral part of these statements</div>
        </div>
        <div className="space-y-5">
          {statements.notes.map((n) => (
            <article key={n.number} className="break-inside-avoid">
              <h4 className="text-[11px] font-black uppercase tracking-[0.12em] text-[#082f4f]">Note {n.number} — {n.title}</h4>
              {n.paragraphs.map((p, i) => (
                <p key={i} className="mt-1.5 max-w-[78ch] text-[11px] leading-relaxed text-[#2d4f6d]">{p}</p>
              ))}
              {n.table && (
                <table className="mt-2.5 w-full border-collapse text-[11px]">
                  <thead>
                    <tr className="border-y border-sky-300 bg-sky-50/80">
                      {n.table.columns.map((c, i) => (
                        <th key={c} className={`px-2 py-1.5 text-[9.5px] font-bold uppercase tracking-[0.1em] text-[#355875] ${i > 0 ? 'text-right' : 'text-left'}`}>{c}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="font-mono tabular-nums">
                    {n.table.rows.map((row, i) => (
                      <tr key={i} className="border-b border-sky-100">
                        {row.map((v, j) => (
                          <td key={j} className={`px-2 py-1 ${j > 0 ? 'text-right' : 'font-sans text-[#0a253e]'}`}>{typeof v === 'number' ? fmt(v) : v}</td>
                        ))}
                      </tr>
                    ))}
                    {n.table.totals && (
                      <tr className="border-y-2 border-[#082f4f] bg-sky-100/80 font-black text-[#082f4f]">
                        {n.table.totals.map((v, j) => (
                          <td key={j} className={`px-2 py-1.5 ${j > 0 ? 'text-right' : 'font-sans'}`}>{typeof v === 'number' ? fmt(v) : v}</td>
                        ))}
                      </tr>
                    )}
                  </tbody>
                </table>
              )}
            </article>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-5 pt-6 text-[10.5px] text-[#355875] sm:grid-cols-3">
        <div className="border-t border-slate-400 pt-1">Approved for issue by</div>
        <div className="border-t border-slate-400 pt-1">Director</div>
        <div className="border-t border-slate-400 pt-1">Date</div>
      </div>
    </div>
  );
}
