import { useMemo, useState } from 'react';
import type { ACDOCALine, BankAccount, ClientEntity, FixedAsset, UserAccount } from '../types/accounting';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { Save } from 'lucide-react';
import { buildDisposalEntries } from '../utils/reports';
import { docSuffix, uniqueId } from '../utils/ids';
import {
  CAPITAL_ALLOWANCE_CLASSES,
  annualCapitalAllowance,
  buildDeferredTaxEntries,
  capitalAllowanceSchedule,
  classFor,
  computeDeferredTax,
  effectiveDepRate,
  ledgerDeferredTaxBalance,
  monthlyDepreciation,
  netBookValue,
  taxWrittenDownValue,
  type DepreciationMethod,
} from '../utils/assetTax';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  isPeriodClosed: boolean;
  lines: ACDOCALine[];
  assets: FixedAsset[];
  bankAccounts?: BankAccount[];
  onAddJournalLines: (lines: ACDOCALine[]) => boolean;
  onSaveAssets: (assets: FixedAsset[]) => void;
  onBankBalanceChange?: (bankId: number, delta: number) => void;
}

const round2 = (n: number) => Math.round(n * 100) / 100;

export const FixedAssetsSection = ({
  currentClient, currentUser, isPeriodClosed, lines, assets, bankAccounts = [], onAddJournalLines, onSaveAssets, onBankBalanceChange,
}: Props) => {
  const [assetTag, setAssetTag] = useState('AST-001');
  const [name, setName] = useState('');
  const [classCode, setClassCode] = useState('Vehicles');
  const [cost, setCost] = useState(0);
  const [usefulLife, setUsefulLife] = useState('5 Years');
  const [depRate, setDepRate] = useState(20);
  const [depMethod, setDepMethod] = useState<DepreciationMethod>('straight_line');
  const [caClass, setCaClass] = useState('CLASS_2');
  const [caRate, setCaRate] = useState(30);
  const [location, setLocation] = useState('Head office');
  const [acquired, setAcquired] = useState(() => new Date().toISOString().slice(0, 10));
  const [feedback, setFeedback] = useState<string | null>(null);
  const [depPeriod, setDepPeriod] = useState(() => new Date().toISOString().slice(0, 7));
  const [disposeTarget, setDisposeTarget] = useState<FixedAsset | null>(null);
  const [disposeDate, setDisposeDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [proceeds, setProceeds] = useState(0);
  const [taxRate, setTaxRate] = useState(25);
  const [taxYear, setTaxYear] = useState(() => String(new Date().getFullYear()));
  const [editing, setEditing] = useState<FixedAsset | null>(null);

  const isRestricted = currentUser.status === 'restricted' || currentUser.status === 'suspended';
  const ok = (text: string) => setFeedback(`OK · ${text}`);
  const err = (text: string) => setFeedback(`BLOCKED · ${text}`);

  const ledgerCost = lines.filter((l) => l.clientId === currentClient.id && l.accountNo === '130000').reduce((n, l) => n + Math.round((l.debit - l.credit) * 100), 0) / 100;
  const ledgerDep = lines.filter((l) => l.clientId === currentClient.id && l.accountNo === '139000').reduce((n, l) => n + Math.round((l.credit - l.debit) * 100), 0) / 100;

  const registerCost = round2(assets.filter((a) => !a.disposedDate).reduce((n, a) => n + a.cost, 0));
  const registerDep = round2(assets.filter((a) => !a.disposedDate).reduce((n, a) => n + a.accumDep, 0));

  const caSchedule = useMemo(() => capitalAllowanceSchedule(assets), [assets]);
  const recognisedDt = useMemo(() => ledgerDeferredTaxBalance(lines, currentClient.id), [lines, currentClient.id]);
  const deferredTax = useMemo(() => computeDeferredTax(assets, taxRate, recognisedDt), [assets, taxRate, recognisedDt]);

  const saveAsset = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (isPeriodClosed) return err('Posting blocked. The accounting period is closed.');
    if (isRestricted) return err('Action blocked. Your account has been restricted.');
    if (!assetTag.trim() || !name.trim() || cost <= 0) return err('Asset tag, name and a positive cost are required.');
    if (assets.some((a) => a.assetTag.toLowerCase() === assetTag.trim().toLowerCase())) return err(`Asset tag ${assetTag} already exists in this register.`);
    if (depRate <= 0 || depRate > 100) return err('Depreciation rate must be between 0 and 100 percent per annum.');
    if (currentUser.makerLimit > 0 && cost > currentUser.makerLimit) return err(`Cost exceeds your maker limit ${formatGHS(currentUser.makerLimit)} — request approval first.`);

    const period = acquired.slice(0, 7);
    const docNo = `AST-${period}-${docSuffix()}`;
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL-FA')}-1`, docNo, period, date: acquired, module: 'FI-AA', docType: 'STAT', accountNo: '130000', accountName: `PPE - ${name}`, costCenter: 'CC-OPS', debit: cost, credit: 0, currency: currentClient.currency, description: `Acquisition of ${assetTag}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL-FA')}-2`, docNo, period, date: acquired, module: 'FI-AA', docType: 'STAT', accountNo: '100000', accountName: 'Cash at Bank (Operating)', costCenter: 'CC-OPS', debit: 0, credit: cost, currency: currentClient.currency, description: `Cash payment for ${assetTag}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    if (!onAddJournalLines(entries)) return err('Asset not registered — check the period, the chart of accounts and duplicate documents.');

    const funding = bankAccounts.find((b) => b.glAccount === '100000') || bankAccounts.find((b) => b.kind !== 'cash');
    if (funding && onBankBalanceChange) onBankBalanceChange(funding.id, -round2(cost));

    const asset: FixedAsset = {
      id: uniqueId('FA'), clientId: currentClient.id, assetTag: assetTag.trim(), name: name.trim(), classCode,
      cost: round2(cost), accumDep: 0, nbv: round2(cost), usefulLife,
      depreciationRate: depRate, depreciationMethod: depMethod,
      capitalAllowanceClass: caClass, capitalAllowanceRate: caRate, accumCapitalAllowance: 0,
      taxBase: round2(cost), location, acquired,
    };
    onSaveAssets([...assets, asset]);
    ok(`Asset ${asset.assetTag} registered at ${formatGHS(asset.cost)} — ${depMethod === 'reducing_balance' ? 'reducing balance' : 'straight line'} ${depRate}% p.a., capital allowance pool ${classFor(caClass).label}.`);
  };

  const applyEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing) return;
    if (isRestricted) return err('Action blocked. Your account has been restricted.');
    if ((editing.depreciationRate ?? 0) <= 0 || (editing.depreciationRate ?? 0) > 100) return err('Depreciation rate must be between 0 and 100 percent.');
    onSaveAssets(assets.map((a) => (a.id === editing.id ? { ...editing, nbv: netBookValue(editing), taxBase: taxWrittenDownValue(editing) } : a)));
    setEditing(null);
    ok(`Depreciation and capital allowance settings updated for ${editing.assetTag}. Future charges use the new rate and method.`);
  };

  const runDepreciation = () => {
    setFeedback(null);
    if (isPeriodClosed) return err('Posting blocked. The accounting period is closed.');
    if (isRestricted) return err('Action blocked. Your account has been restricted.');
    const active = assets.filter((a) => !a.disposedDate);
    if (!active.length) return err('No active assets to depreciate.');
    let posted = 0; let skipped = 0; let total = 0;
    const updated = assets.map((a) => {
      if (a.disposedDate) return a;
      const monthly = monthlyDepreciation(a);
      if (monthly <= 0) { skipped += 1; return a; }
      const docNo = `DEP-${a.assetTag}-${depPeriod}`;
      if (lines.some((l) => l.clientId === currentClient.id && l.docNo === docNo)) { skipped += 1; return a; }
      const success = onAddJournalLines([
        { id: `${uniqueId('JL-DEP')}-1`, docNo, period: depPeriod, date: `${depPeriod}-28`, module: 'FI-AA', docType: 'DEP', accountNo: '600000', accountName: `Depreciation — ${a.name}`, costCenter: 'CC-OPS', debit: monthly, credit: 0, currency: currentClient.currency, description: `${a.depreciationMethod === 'reducing_balance' ? 'Reducing-balance' : 'Straight-line'} depreciation ${a.assetTag} at ${effectiveDepRate(a)}% p.a. (${depPeriod})`, createdBy: currentUser.username, clientId: currentClient.id },
        { id: `${uniqueId('JL-DEP')}-2`, docNo, period: depPeriod, date: `${depPeriod}-28`, module: 'FI-AA', docType: 'DEP', accountNo: '139000', accountName: 'Accumulated Depreciation — PPE', costCenter: 'CC-OPS', debit: 0, credit: monthly, currency: currentClient.currency, description: `Accumulated depreciation ${a.assetTag} (${depPeriod})`, createdBy: currentUser.username, clientId: currentClient.id },
      ]);
      if (!success) { skipped += 1; return a; }
      posted += 1; total += monthly;
      const next = { ...a, accumDep: round2(a.accumDep + monthly) };
      return { ...next, nbv: netBookValue(next) };
    });
    onSaveAssets(updated);
    setFeedback(posted > 0
      ? `OK · Depreciation ${depPeriod}: ${posted} asset(s) posted, ${formatGHS(total)} charged to 600000.${skipped ? ` ${skipped} skipped (fully depreciated or already posted).` : ''}`
      : 'BLOCKED · No depreciation posted — assets may be fully depreciated or already posted for this period.');
  };

  /** Capital allowances are a TAX computation: they change the tax base only, never the ledger. */
  const claimCapitalAllowances = () => {
    setFeedback(null);
    if (isRestricted) return err('Action blocked. Your account has been restricted.');
    const active = assets.filter((a) => !a.disposedDate);
    if (!active.length) return err('No active assets in the register.');
    let claimed = 0; let count = 0;
    const updated = assets.map((a) => {
      if (a.disposedDate) return a;
      const allowance = annualCapitalAllowance(a);
      if (allowance <= 0) return a;
      claimed += allowance; count += 1;
      const next = { ...a, accumCapitalAllowance: round2((a.accumCapitalAllowance || 0) + allowance) };
      return { ...next, taxBase: taxWrittenDownValue(next) };
    });
    if (!count) return err('No capital allowance available — every asset is already written down for tax.');
    onSaveAssets(updated);
    ok(`Capital allowances claimed for ${taxYear}: ${formatGHS(claimed)} across ${count} asset(s). Tax written-down values updated — recompute deferred tax to post the IAS 12 effect.`);
  };

  const postDeferredTax = () => {
    setFeedback(null);
    if (isPeriodClosed) return err('Posting blocked. The accounting period is closed.');
    if (isRestricted) return err('Action blocked. Your account has been restricted.');
    if (Math.abs(deferredTax.movement) < 0.005) return err('Deferred tax is already at the required balance — no movement to post.');
    const date = `${depPeriod}-28`;
    const docNo = `DTX-${depPeriod}-${docSuffix()}`;
    const entries = buildDeferredTaxEntries(
      { docNo, date, currency: currentClient.currency, clientId: currentClient.id, createdBy: currentUser.username, costCenter: 'CC-ADM' },
      deferredTax,
    );
    if (!entries.length) return err('Nothing to post.');
    if (!onAddJournalLines(entries)) return err('Deferred tax journal rejected — check the period and the chart of accounts.');
    ok(`IAS 12 deferred tax posted: movement ${formatGHS(deferredTax.movement)} at ${taxRate}% on a temporary difference of ${formatGHS(deferredTax.temporaryDifference)}.`);
  };

  const dispose = (e: React.FormEvent) => {
    e.preventDefault();
    if (!disposeTarget) return;
    if (isPeriodClosed) return err('Posting blocked. The accounting period is closed.');
    if (isRestricted) return err('Action blocked. Your account has been restricted.');
    const nbv = netBookValue(disposeTarget);
    const gain = round2(proceeds - nbv);
    const entries = buildDisposalEntries(disposeTarget, proceeds, disposeDate, currentClient.currency, currentClient.id, currentUser.username);
    if (!onAddJournalLines(entries)) return err('Disposal rejected — check the period, balance and duplicate document number.');
    const funding = bankAccounts.find((b) => b.glAccount === '100000') || bankAccounts.find((b) => b.kind !== 'cash');
    if (funding && onBankBalanceChange && proceeds > 0) onBankBalanceChange(funding.id, proceeds);
    onSaveAssets(assets.map((a) => (a.id === disposeTarget.id ? { ...a, disposedDate: disposeDate, disposalProceeds: proceeds } : a)));
    setDisposeTarget(null);
    ok(`Asset ${disposeTarget.assetTag} disposed. ${gain >= 0 ? `Gain ${formatGHS(gain)}` : `Loss ${formatGHS(Math.abs(gain))}`} posted. Balancing allowance/charge must be assessed in the tax computation.`);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`AA · Fixed assets, capital allowances & deferred tax · ${currentClient.code}`}
        title="Fixed Assets (IAS 16) · Capital Allowances · Deferred Tax (IAS 12)"
        desc="Register assets with their own depreciation rate and method, claim capital allowances against the tax base, and post the resulting deferred tax movement."
      />
      {feedback && (
        <div className={`text-xs rounded-lg p-3 border ${feedback.startsWith('OK') ? 'bg-emerald-50 text-emerald-900 border-emerald-300' : 'bg-rose-50 text-rose-900 border-rose-300'}`}>{feedback.replace(/^(OK|BLOCKED) · /, '')}</div>
      )}

      <div className="grid gap-4 md:grid-cols-3">
        <Card title="Register vs ledger" sub="Cost and accumulated depreciation">
          <div className="space-y-1 font-mono text-xs">
            <div>Register cost: {formatGHS(registerCost)} · GL 130000: {formatGHS(ledgerCost)}</div>
            <div>Register depreciation: {formatGHS(registerDep)} · GL 139000: {formatGHS(ledgerDep)}</div>
            <div className="border-t pt-1 font-bold">Carrying amount: {formatGHS(round2(registerCost - registerDep))}</div>
          </div>
        </Card>
        <Card title="Tax base (TWDV)" sub="After capital allowances claimed">
          <div className="text-2xl font-black text-[#082f4f]">{formatGHS(deferredTax.taxBase)}</div>
          <div className="mt-1 text-[11px] text-[#355875]">Temporary difference: {formatGHS(deferredTax.temporaryDifference)}</div>
        </Card>
        <Card title="Deferred tax (IAS 12)" sub={`At ${taxRate}% corporate tax rate`}>
          <div className="space-y-1 font-mono text-xs">
            <div>Required balance: {formatGHS(deferredTax.requiredBalance)} {deferredTax.requiredBalance >= 0 ? '(liability)' : '(asset)'}</div>
            <div>Recognised in ledger: {formatGHS(deferredTax.recognisedBalance)}</div>
            <div className="border-t pt-1 font-bold">Movement to post: {formatGHS(deferredTax.movement)}</div>
          </div>
        </Card>
      </div>

      <Card title="Register an asset" sub="The acquisition posts Dr PPE / Cr Bank and stores the depreciation and tax settings used by every later run.">
        <form onSubmit={saveAsset} className="grid gap-3 md:grid-cols-3 text-xs">
          <label className="block font-bold text-[#355875]">Asset tag<input value={assetTag} onChange={(e) => setAssetTag(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" /></label>
          <label className="block font-bold text-[#355875] md:col-span-2">Description<input value={name} onChange={(e) => setName(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" /></label>
          <label className="block font-bold text-[#355875]">Asset class<input value={classCode} onChange={(e) => setClassCode(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" /></label>
          <label className="block font-bold text-[#355875]">Cost ({currentClient.currency})<input type="number" min="0" step="0.01" value={cost || ''} onChange={(e) => setCost(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" /></label>
          <label className="block font-bold text-[#355875]">Acquisition date<input type="date" value={acquired} onChange={(e) => setAcquired(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" /></label>
          <label className="block font-bold text-[#355875]">Useful life<input value={usefulLife} onChange={(e) => setUsefulLife(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" /></label>
          <label className="block font-bold text-[#355875]">Depreciation rate (% p.a.)<input type="number" min="0" max="100" step="0.01" value={depRate || ''} onChange={(e) => setDepRate(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" /></label>
          <label className="block font-bold text-[#355875]">Depreciation method
            <select value={depMethod} onChange={(e) => setDepMethod(e.target.value as DepreciationMethod)} className="mt-1 block w-full rounded border border-sky-300 p-2">
              <option value="straight_line">Straight line (on cost)</option>
              <option value="reducing_balance">Reducing balance (on carrying amount)</option>
            </select>
          </label>
          <label className="block font-bold text-[#355875] md:col-span-2">Capital allowance pool (Act 896, Third Schedule)
            <select value={caClass} onChange={(e) => { setCaClass(e.target.value); setCaRate(classFor(e.target.value).rate); }} className="mt-1 block w-full rounded border border-sky-300 p-2">
              {CAPITAL_ALLOWANCE_CLASSES.map((c) => <option key={c.code} value={c.code}>{c.label} — {c.examples}</option>)}
            </select>
          </label>
          <label className="block font-bold text-[#355875]">Capital allowance rate (%)<input type="number" min="0" max="100" step="0.01" value={caRate} onChange={(e) => setCaRate(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" /></label>
          <label className="block font-bold text-[#355875] md:col-span-2">Location<input value={location} onChange={(e) => setLocation(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" /></label>
          <div className="md:col-span-3 flex justify-end">
            <button type="submit" className="flex items-center gap-1.5 rounded bg-[#082f4f] px-4 py-2 font-bold text-white"><Save className="h-4 w-4" /> Register asset</button>
          </div>
        </form>
      </Card>

      <Card title="Asset register" sub="Carrying amount (IAS 16) alongside the tax written-down value used for capital allowances.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1040px] text-xs">
            <thead><tr className="border-b border-sky-200 bg-sky-50/70">
              <th className={thCls}>Tag</th><th className={thCls}>Asset</th><th className={thCls}>Method</th>
              <th className={thCls + ' text-right'}>Rate</th><th className={thCls + ' text-right'}>Cost</th>
              <th className={thCls + ' text-right'}>Acc. dep.</th><th className={thCls + ' text-right'}>Carrying</th>
              <th className={thCls + ' text-right'}>CA claimed</th><th className={thCls + ' text-right'}>Tax base</th>
              <th className={thCls + ' text-right'}>Temp. diff.</th><th className={thCls + ' text-center'}>Action</th>
            </tr></thead>
            <tbody>
              {assets.map((a) => {
                const carrying = netBookValue(a);
                const base = taxWrittenDownValue(a);
                return (
                  <tr key={a.id} className={rowCls}>
                    <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{a.assetTag}</td>
                    <td className="px-3 py-2">{a.name}{a.disposedDate && <span className="ml-2 rounded bg-slate-100 px-1.5 py-0.5 text-[10px]">disposed {a.disposedDate}</span>}</td>
                    <td className="px-3 py-2">{a.depreciationMethod === 'reducing_balance' ? 'Reducing balance' : 'Straight line'}</td>
                    <td className={numCls}>{effectiveDepRate(a)}%</td>
                    <td className={numCls}>{formatGHS(a.cost)}</td>
                    <td className={numCls}>{formatGHS(a.accumDep)}</td>
                    <td className={numCls + ' font-bold'}>{formatGHS(carrying)}</td>
                    <td className={numCls}>{formatGHS(a.accumCapitalAllowance || 0)}</td>
                    <td className={numCls}>{formatGHS(base)}</td>
                    <td className={numCls}>{formatGHS(round2(carrying - base))}</td>
                    <td className="px-3 py-2 text-center">
                      <div className="flex justify-center gap-1">
                        <button onClick={() => setEditing(a)} className="rounded border border-sky-300 bg-sky-50 px-2 py-1 text-[11px] font-bold text-[#082f4f]">Rates</button>
                        {!a.disposedDate && <button onClick={() => { setDisposeTarget(a); setProceeds(0); }} className="rounded border border-amber-400 bg-amber-50 px-2 py-1 text-[11px] font-bold text-[#855b00]">Dispose</button>}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {!assets.length && <tr><td colSpan={11} className="px-3 py-6 text-center text-[#355875]">No assets registered for this entity yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Monthly depreciation run" sub="Dr 600000 Depreciation · Cr 139000 Accumulated depreciation. Each asset posts once per period.">
          <div className="flex flex-wrap items-end gap-3 text-xs">
            <label className="block font-bold text-[#355875]">Period<input type="month" value={depPeriod} onChange={(e) => setDepPeriod(e.target.value)} className="mt-1 block rounded border border-sky-300 p-2 font-mono" /></label>
            <button onClick={runDepreciation} className="rounded bg-[#082f4f] px-4 py-2 font-bold text-white">Run depreciation</button>
          </div>
          <p className="mt-3 text-[11px] text-[#355875]">Straight line charges cost × rate ÷ 12; reducing balance charges the carrying amount × rate ÷ 12. The charge is capped so the carrying amount never goes below zero.</p>
        </Card>

        <Card title="Capital allowances & IAS 12" sub="Capital allowances change the tax base only; the deferred tax movement is the journal entry.">
          <div className="flex flex-wrap items-end gap-3 text-xs">
            <label className="block font-bold text-[#355875]">Year of assessment<input value={taxYear} onChange={(e) => setTaxYear(e.target.value)} className="mt-1 block w-28 rounded border border-sky-300 p-2 font-mono" /></label>
            <label className="block font-bold text-[#355875]">Corporate tax rate (%)<input type="number" min="0" max="100" step="0.01" value={taxRate} onChange={(e) => setTaxRate(Number(e.target.value))} className="mt-1 block w-28 rounded border border-sky-300 p-2 font-mono" /></label>
            <button onClick={claimCapitalAllowances} className="rounded border border-[#082f4f] px-4 py-2 font-bold text-[#082f4f]">Compute &amp; claim capital allowances</button>
            <button onClick={postDeferredTax} className="rounded bg-[#082f4f] px-4 py-2 font-bold text-white">Post deferred tax movement</button>
          </div>
          <p className="mt-3 text-[11px] text-[#355875]">
            Deferred tax = (carrying amount − tax base) × tax rate. A taxable difference is credited to 222000 (liability) against 731000; a deductible difference is debited to 117000 (asset) and recognised only when recovery is probable.
          </p>
        </Card>
      </div>

      <Card title="Capital allowance schedule" sub="Pool, rate, opening tax written-down value, allowance for the year and closing TWDV.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[880px] text-xs">
            <thead><tr className="border-b border-sky-200 bg-sky-50/70">
              <th className={thCls}>Tag</th><th className={thCls}>Asset</th><th className={thCls}>Pool</th>
              <th className={thCls + ' text-right'}>Rate</th><th className={thCls + ' text-right'}>Cost</th>
              <th className={thCls + ' text-right'}>Opening TWDV</th><th className={thCls + ' text-right'}>Allowance</th><th className={thCls + ' text-right'}>Closing TWDV</th>
            </tr></thead>
            <tbody>
              {caSchedule.map((r) => (
                <tr key={r.assetTag} className={rowCls}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{r.assetTag}</td>
                  <td className="px-3 py-2">{r.name}</td>
                  <td className="px-3 py-2">{r.className}</td>
                  <td className={numCls}>{r.rate}%</td>
                  <td className={numCls}>{formatGHS(r.cost)}</td>
                  <td className={numCls}>{formatGHS(r.openingTwdv)}</td>
                  <td className={numCls + ' font-bold'}>{formatGHS(r.allowance)}</td>
                  <td className={numCls}>{formatGHS(r.closingTwdv)}</td>
                </tr>
              ))}
              {!caSchedule.length && <tr><td colSpan={8} className="px-3 py-6 text-center text-[#355875]">No qualifying assets in the register.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>

      <Card title="Deferred tax computation (IAS 12)" sub="Asset-by-asset temporary differences between the carrying amount and the tax base.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-xs">
            <thead><tr className="border-b border-sky-200 bg-sky-50/70">
              <th className={thCls}>Tag</th><th className={thCls}>Asset</th>
              <th className={thCls + ' text-right'}>Carrying amount</th><th className={thCls + ' text-right'}>Tax base</th>
              <th className={thCls + ' text-right'}>Temporary difference</th><th className={thCls + ' text-right'}>Deferred tax @ {taxRate}%</th>
            </tr></thead>
            <tbody>
              {deferredTax.rows.map((r) => (
                <tr key={r.assetTag} className={rowCls}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{r.assetTag}</td>
                  <td className="px-3 py-2">{r.name}</td>
                  <td className={numCls}>{formatGHS(r.carryingAmount)}</td>
                  <td className={numCls}>{formatGHS(r.taxBase)}</td>
                  <td className={numCls}>{formatGHS(r.temporaryDifference)}</td>
                  <td className={numCls + ' font-bold'}>{formatGHS(r.deferredTax)}</td>
                </tr>
              ))}
              {!deferredTax.rows.length && <tr><td colSpan={6} className="px-3 py-6 text-center text-[#355875]">No active assets to measure.</td></tr>}
            </tbody>
            {deferredTax.rows.length > 0 && (
              <tfoot><tr className="border-t border-sky-200 bg-sky-50/70 font-bold">
                <td className="px-3 py-2" colSpan={2}>Total</td>
                <td className={numCls}>{formatGHS(deferredTax.carryingAmount)}</td>
                <td className={numCls}>{formatGHS(deferredTax.taxBase)}</td>
                <td className={numCls}>{formatGHS(deferredTax.temporaryDifference)}</td>
                <td className={numCls}>{formatGHS(deferredTax.requiredBalance)}</td>
              </tr></tfoot>
            )}
          </table>
        </div>
      </Card>

      {editing && (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/50 p-4">
          <form onSubmit={applyEdit} className="my-8 w-full max-w-lg space-y-3 rounded-xl bg-white p-6 text-xs shadow-xl">
            <h3 className="border-b border-sky-100 pb-2 text-base font-bold text-[#082f4f]">Depreciation &amp; capital allowance — {editing.assetTag}</h3>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block font-bold text-[#355875]">Depreciation rate (% p.a.)
                <input type="number" min="0" max="100" step="0.01" value={editing.depreciationRate ?? effectiveDepRate(editing)} onChange={(e) => setEditing({ ...editing, depreciationRate: Number(e.target.value) })} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
              </label>
              <label className="block font-bold text-[#355875]">Method
                <select value={editing.depreciationMethod || 'straight_line'} onChange={(e) => setEditing({ ...editing, depreciationMethod: e.target.value as DepreciationMethod })} className="mt-1 block w-full rounded border border-sky-300 p-2">
                  <option value="straight_line">Straight line</option>
                  <option value="reducing_balance">Reducing balance</option>
                </select>
              </label>
              <label className="block font-bold text-[#355875] sm:col-span-2">Capital allowance pool
                <select value={editing.capitalAllowanceClass || 'CLASS_2'} onChange={(e) => setEditing({ ...editing, capitalAllowanceClass: e.target.value, capitalAllowanceRate: classFor(e.target.value).rate })} className="mt-1 block w-full rounded border border-sky-300 p-2">
                  {CAPITAL_ALLOWANCE_CLASSES.map((c) => <option key={c.code} value={c.code}>{c.label}</option>)}
                </select>
              </label>
              <label className="block font-bold text-[#355875]">Capital allowance rate (%)
                <input type="number" min="0" max="100" step="0.01" value={editing.capitalAllowanceRate ?? classFor(editing.capitalAllowanceClass).rate} onChange={(e) => setEditing({ ...editing, capitalAllowanceRate: Number(e.target.value) })} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
              </label>
              <label className="block font-bold text-[#355875]">Useful life
                <input value={editing.usefulLife} onChange={(e) => setEditing({ ...editing, usefulLife: e.target.value })} className="mt-1 block w-full rounded border border-sky-300 p-2" />
              </label>
            </div>
            <p className="rounded bg-sky-50 border border-sky-200 p-2 text-[10.5px] text-[#2d4f6d]">Rate and method changes apply prospectively (IAS 8 change in estimate) — posted depreciation is never rewritten.</p>
            <div className="flex justify-end gap-2 border-t border-sky-100 pt-3">
              <button type="button" onClick={() => setEditing(null)} className="px-3 py-2">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-2 font-bold text-white">Save settings</button>
            </div>
          </form>
        </div>
      )}

      {disposeTarget && (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/50 p-4">
          <form onSubmit={dispose} className="my-8 w-full max-w-md space-y-3 rounded-xl bg-white p-6 text-xs shadow-xl">
            <h3 className="border-b border-sky-100 pb-2 text-base font-bold text-[#082f4f]">Dispose {disposeTarget.assetTag}</h3>
            <div className="font-mono text-[11px] text-[#355875]">
              Carrying amount: {formatGHS(netBookValue(disposeTarget))} · Tax base: {formatGHS(taxWrittenDownValue(disposeTarget))}
            </div>
            <label className="block font-bold text-[#355875]">Disposal date<input type="date" value={disposeDate} onChange={(e) => setDisposeDate(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" /></label>
            <label className="block font-bold text-[#355875]">Proceeds ({currentClient.currency})<input type="number" min="0" step="0.01" value={proceeds || ''} onChange={(e) => setProceeds(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" /></label>
            <div className="flex justify-end gap-2 border-t border-sky-100 pt-3">
              <button type="button" onClick={() => setDisposeTarget(null)} className="px-3 py-2">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-2 font-bold text-white">Post disposal</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
