import React, { useMemo, useState } from 'react';
import type { ACDOCALine, AccountMaster, ClientEntity, UserAccount } from '../types/accounting';
import type { CompanyProfile } from '../utils/persistentStorage';
import { Card, PageHeader, Stat, StatusBadge, formatGHS, thCls, numCls, rowCls } from './ui';
import { BookOpen, Plus, Printer, FileSpreadsheet, Pencil, Trash2, RotateCcw, X, Check, AlertCircle } from 'lucide-react';
import { buildGeneralLedger, balanceLabel, validateDocumentLines, r2, type AccountLedger } from '../utils/ledger';
import { printReport, downloadCsv, type PrintSection } from '../utils/printReport';
import { toPrintEntity } from '../utils/printEntity';
import { uniqueId, nextDocNo } from '../utils/ids';
import { COST_CENTRES } from '../data/costCentres';

interface DraftLine {
  id: string;
  accountNo: string;
  description: string;
  costCenter: string;
  debit: string;
  credit: string;
}

interface GeneralLedgerSectionProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  closedPeriods: string[];
  profile?: CompanyProfile;
  onAddJournalLines: (lines: ACDOCALine[]) => boolean;
  onEditDocument: (docNo: string, lines: ACDOCALine[], reason: string) => Promise<{ ok: boolean; error?: string }>;
  onDeleteDocument: (docNo: string, reason: string) => Promise<{ ok: boolean; error?: string }>;
  onReverseDocument: (docNo: string) => boolean;
}

const today = () => new Date().toISOString().slice(0, 10);
const num = (s: string) => { const n = Number(String(s).replace(/,/g, '')); return Number.isFinite(n) ? n : NaN; };

export const GeneralLedgerSection: React.FC<GeneralLedgerSectionProps> = ({
  currentClient, currentUser, lines, accounts, closedPeriods, profile,
  onAddJournalLines, onEditDocument, onDeleteDocument, onReverseDocument,
}) => {
  const year = new Date().getFullYear();
  const [from, setFrom] = useState(`${year}-01-01`);
  const [through, setThrough] = useState(today());
  const [accountFilter, setAccountFilter] = useState<string>('ALL');
  const [search, setSearch] = useState('');
  const [includeEmpty, setIncludeEmpty] = useState(false);
  const [toast, setToast] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);
  const flash = (tone: 'ok' | 'err', text: string) => { setToast({ tone, text }); setTimeout(() => setToast(null), 7000); };

  // Editor state (shared by "Add GL entry" and "Edit document").
  const [editor, setEditor] = useState<null | { mode: 'add' | 'edit'; docNo: string; docType: ACDOCALine['docType']; date: string; reference: string; narrative: string; reason: string; draft: DraftLine[]; original?: ACDOCALine[] }>(null);
  const [editorError, setEditorError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [deleting, setDeleting] = useState<null | { docNo: string; reason: string }>(null);

  const isRestricted = currentUser.status === 'restricted' || currentUser.status === 'suspended' || currentUser.permissions?.canPostJournals === false;
  const canDelete = currentUser.role === 'owner' || currentUser.canCheck;
  const activeAccounts = useMemo(() => accounts.filter((a) => a.active).sort((a, b) => a.accountNo.localeCompare(b.accountNo)), [accounts]);
  const knownAccounts = useMemo(() => new Set(accounts.map((a) => a.accountNo)), [accounts]);
  const clientLines = useMemo(() => lines.filter((l) => l.clientId === currentClient.id), [lines, currentClient.id]);

  const ledgers: AccountLedger[] = useMemo(
    () => buildGeneralLedger(lines, accounts, currentClient.id, from, through, { accountNo: accountFilter === 'ALL' ? undefined : accountFilter, includeEmpty, search: search.trim() || undefined }),
    [lines, accounts, currentClient.id, from, through, accountFilter, includeEmpty, search]
  );
  const totalDr = r2(ledgers.reduce((n, l) => n + l.totalDebit, 0));
  const totalCr = r2(ledgers.reduce((n, l) => n + l.totalCredit, 0));
  const docCount = new Set(ledgers.flatMap((l) => l.entries.map((e) => e.line.docNo))).size;
  const periodLabel = `${from} to ${through}`;

  /* ----------------------------------------------------------------- print & export */
  const printLedger = () => {
    const sections: PrintSection[] = ledgers.map((l) => ({
      title: `${l.accountNo} · ${l.name}`,
      subtitle: `${l.type} · ${l.category || 'General ledger'} · Opening balance ${balanceLabel(l.opening, l.type, formatGHS)}`,
      columns: [
        { key: 'date', label: 'Date', width: '11%' }, { key: 'docNo', label: 'Document', width: '15%' }, { key: 'type', label: 'Type', width: '6%' },
        { key: 'description', label: 'Narrative' }, { key: 'cc', label: 'Cost centre', width: '9%' },
        { key: 'debit', label: 'Debit', numeric: true, width: '11%' }, { key: 'credit', label: 'Credit', numeric: true, width: '11%' }, { key: 'balance', label: 'Balance', width: '13%', align: 'right' },
      ],
      rows: [
        { date: from, docNo: '', type: '', description: 'Opening balance brought forward', cc: '', debit: '', credit: '', balance: balanceLabel(l.opening, l.type, formatGHS) },
        ...l.entries.map((e) => ({ date: e.line.date, docNo: e.line.docNo, type: e.line.docType, description: e.line.description, cc: e.line.costCenter || '', debit: e.line.debit || '', credit: e.line.credit || '', balance: balanceLabel(e.balance, l.type, formatGHS) })),
      ],
      totals: { date: '', docNo: '', type: '', description: 'Period movement & closing balance', cc: '', debit: l.totalDebit, credit: l.totalCredit, balance: balanceLabel(l.closing, l.type, formatGHS) },
    }));
    printReport({
      kicker: 'General ledger',
      title: accountFilter === 'ALL' ? 'General Ledger — all accounts' : `General Ledger — ${accountFilter}`,
      subtitle: `${ledgers.length} account(s) · ${docCount} document(s) · ${currentClient.currency}`,
      entity: toPrintEntity(currentClient, profile),
      periodLabel,
      preparedBy: `${currentUser.name} (${currentUser.username})`,
      orientation: 'landscape',
      stats: [{ label: 'Accounts', value: String(ledgers.length) }, { label: 'Documents', value: String(docCount) }, { label: 'Total debits', value: totalDr }, { label: 'Total credits', value: totalCr }],
      sections,
    });
  };

  const exportCsv = () => {
    const rows: (string | number)[][] = [['Entity', currentClient.code, currentClient.name], ['From', from, 'Through', through], [],
      ['Account', 'Account name', 'Type', 'Date', 'Document', 'Doc type', 'Narrative', 'Cost centre', 'Debit', 'Credit', 'Balance']];
    for (const l of ledgers) {
      rows.push([l.accountNo, l.name, l.type, from, 'OPENING', '', 'Opening balance', '', '', '', l.opening]);
      for (const e of l.entries) rows.push([l.accountNo, l.name, l.type, e.line.date, e.line.docNo, e.line.docType, e.line.description, e.line.costCenter || '', e.line.debit, e.line.credit, e.balance]);
      rows.push([l.accountNo, l.name, l.type, through, 'CLOSING', '', 'Closing balance', '', l.totalDebit, l.totalCredit, l.closing]);
    }
    downloadCsv(`${currentClient.code}-general-ledger-${from}-${through}.csv`, rows);
  };

  /* ----------------------------------------------------------------- editor helpers */
  const blankLine = (): DraftLine => ({ id: uniqueId('JL'), accountNo: activeAccounts[0]?.accountNo || '', description: '', costCenter: COST_CENTRES[0]?.code || 'CC-ADM', debit: '', credit: '' });

  const openAdd = () => {
    if (isRestricted) { flash('err', 'Your posting authority is restricted by the Firm Owner.'); return; }
    const docNo = nextDocNo(`GL-${new Date().toISOString().slice(0, 7)}`, clientLines.map((l) => l.docNo));
    setEditorError(null);
    setEditor({ mode: 'add', docNo, docType: 'JE', date: today(), reference: '', narrative: '', reason: '', draft: [blankLine(), blankLine()] });
  };

  const openEdit = (docNo: string) => {
    if (isRestricted) { flash('err', 'Your posting authority is restricted by the Firm Owner.'); return; }
    const original = clientLines.filter((l) => l.docNo === docNo).slice().sort((a, b) => a.id.localeCompare(b.id));
    if (!original.length) return;
    if (original.some((l) => l.isReversed)) { flash('err', `${docNo} has been reversed and is frozen.`); return; }
    if (original.some((l) => l.docType === 'REV')) { flash('err', 'Reversal documents are immutable — reverse the original instead.'); return; }
    if (closedPeriods.includes(original[0].period)) { flash('err', `Period ${original[0].period} is closed — reopen it at Month-End Close before editing.`); return; }
    setEditorError(null);
    setEditor({
      mode: 'edit', docNo, docType: original[0].docType, date: original[0].date, reference: original[0].reference || '', narrative: '', reason: '',
      original,
      draft: original.map((l) => ({ id: l.id, accountNo: l.accountNo, description: l.description, costCenter: l.costCenter || 'CC-ADM', debit: l.debit ? String(l.debit) : '', credit: l.credit ? String(l.credit) : '' })),
    });
  };

  const draftTotals = (draft: DraftLine[]) => ({
    dr: r2(draft.reduce((n, d) => n + (num(d.debit) || 0), 0)),
    cr: r2(draft.reduce((n, d) => n + (num(d.credit) || 0), 0)),
  });

  const submitEditor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editor) return;
    const period = editor.date.slice(0, 7);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(editor.date)) { setEditorError('Enter a valid posting date.'); return; }
    if (closedPeriods.includes(period)) { setEditorError(`Period ${period} is closed and frozen for ${currentClient.code}.`); return; }
    const parsed = editor.draft.map((d) => ({ accountNo: d.accountNo, debit: d.debit.trim() === '' ? 0 : num(d.debit), credit: d.credit.trim() === '' ? 0 : num(d.credit) }));
    const err = validateDocumentLines(parsed, knownAccounts);
    if (err) { setEditorError(err); return; }
    const total = parsed.reduce((n, d) => n + d.debit, 0);
    if (currentUser.makerLimit > 0 && total > currentUser.makerLimit && !currentUser.canCheck) {
      setEditorError(`Document total ₵${formatGHS(total)} exceeds your maker limit of ₵${formatGHS(currentUser.makerLimit)}. Use the Manual Journal desk to submit it for checker approval.`);
      return;
    }
    const built: ACDOCALine[] = editor.draft.map((d, i) => {
      const prior = editor.original?.find((l) => l.id === d.id);
      return {
        id: d.id, docNo: editor.docNo, period, date: editor.date, module: prior?.module ?? 'FI', docType: editor.docType,
        accountNo: d.accountNo, accountName: accounts.find((a) => a.accountNo === d.accountNo)?.name || prior?.accountName || d.accountNo,
        costCenter: d.costCenter || undefined, debit: r2(parsed[i].debit), credit: r2(parsed[i].credit), currency: prior?.currency ?? currentClient.currency,
        description: d.description.trim() || editor.narrative.trim() || `${editor.mode === 'add' ? 'General ledger entry' : 'Edited entry'} ${editor.docNo}`,
        createdBy: prior?.createdBy ?? currentUser.username,
        checkedBy: prior?.checkedBy ?? (currentUser.canCheck ? currentUser.username : undefined),
        clientId: currentClient.id, reference: editor.reference.trim() || prior?.reference || undefined,
      };
    });
    if (editor.mode === 'add') {
      const ok = onAddJournalLines(built);
      if (!ok) { setEditorError(`Posting refused — the period may be closed or document ${editor.docNo} already exists.`); return; }
      flash('ok', `Document ${editor.docNo} posted: ${built.length} lines, ₵${formatGHS(total)}.`);
      setEditor(null);
      return;
    }
    if (!editor.reason.trim()) { setEditorError('State the reason for the edit — it is written to the audit trail.'); return; }
    setBusy(true);
    const res = await onEditDocument(editor.docNo, built, editor.reason.trim());
    setBusy(false);
    if (!res.ok) { setEditorError(res.error || 'The server refused the edit.'); return; }
    flash('ok', `Document ${editor.docNo} updated on the server and in the ledger.`);
    setEditor(null);
  };

  const confirmDelete = async () => {
    if (!deleting) return;
    if (!deleting.reason.trim()) { flash('err', 'State the reason for deleting the document.'); return; }
    setBusy(true);
    const res = await onDeleteDocument(deleting.docNo, deleting.reason.trim());
    setBusy(false);
    if (!res.ok) { flash('err', res.error || 'The server refused the deletion.'); return; }
    flash('ok', `Document ${deleting.docNo} deleted and recorded in the audit trail.`);
    setDeleting(null);
  };

  const reverse = (docNo: string) => {
    const ok = onReverseDocument(docNo);
    flash(ok ? 'ok' : 'err', ok ? `Reversal of ${docNo} posted into the current period.` : `Reversal of ${docNo} was refused — see the system notice for the reason.`);
  };

  const editorTotals = editor ? draftTotals(editor.draft) : { dr: 0, cr: 0 };
  const editorBalanced = Math.abs(editorTotals.dr - editorTotals.cr) < 0.005 && editorTotals.dr > 0;

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`GL · General Ledger · ${currentClient.code}`}
        title="General Ledger"
        desc="Account-by-account ledger of the active entity with opening balances, running balances and closing balances, built from posted journal entries. Add entries directly, edit or delete a posted document (audited), or reverse it."
      >
        <div className="flex flex-wrap gap-2">
          <button onClick={exportCsv} className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"><FileSpreadsheet className="h-4 w-4 text-emerald-700" /><span>Export CSV</span></button>
          <button onClick={printLedger} className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"><Printer className="h-4 w-4" /><span>Print ledger</span></button>
          <button onClick={openAdd} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"><Plus className="h-4 w-4" /><span>Add GL entry</span></button>
        </div>
      </PageHeader>

      {toast && (
        <div role="status" className={`rounded-lg border p-3 text-xs font-bold flex items-center gap-2 ${toast.tone === 'ok' ? 'border-emerald-300 bg-emerald-50 text-emerald-900' : 'border-rose-300 bg-rose-50 text-rose-900'}`}>
          {toast.tone === 'ok' ? <Check className="h-4 w-4 shrink-0" /> : <AlertCircle className="h-4 w-4 shrink-0" />}<span>{toast.text}</span>
        </div>
      )}

      <div className="flex flex-wrap items-end gap-3 rounded-xl bg-white p-4 border border-sky-200 text-xs">
        <label className="font-bold text-[#355875]">Account
          <select value={accountFilter} onChange={(e) => setAccountFilter(e.target.value)} className="block mt-1 min-w-[260px] max-w-[360px] rounded border border-sky-300 p-2 font-bold text-[#082f4f]">
            <option value="ALL">All accounts with activity</option>
            {accounts.slice().sort((a, b) => a.accountNo.localeCompare(b.accountNo)).map((a) => <option key={`${a.accountNo}-${a.clientId ?? 'm'}`} value={a.accountNo}>{a.accountNo} · {a.name}{a.active ? '' : ' (inactive)'}</option>)}
          </select>
        </label>
        <label className="font-bold text-[#355875]">From<input type="date" value={from} max={through} onChange={(e) => setFrom(e.target.value)} className="block mt-1 rounded border border-sky-300 p-2" /></label>
        <label className="font-bold text-[#355875]">Through<input type="date" value={through} min={from} onChange={(e) => setThrough(e.target.value)} className="block mt-1 rounded border border-sky-300 p-2" /></label>
        <label className="font-bold text-[#355875]">Search<input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="account no or name" className="block mt-1 rounded border border-sky-300 p-2 w-48" /></label>
        <label className="flex items-center gap-2 font-semibold text-[#355875] pb-2"><input type="checkbox" checked={includeEmpty} onChange={(e) => setIncludeEmpty(e.target.checked)} /> Include accounts without movement</label>
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Accounts shown" value={ledgers.length} sub={`${accounts.length} in the chart`} />
        <Stat label="Documents in range" value={docCount} sub={periodLabel} />
        <Stat label="Total debits" value={formatGHS(totalDr)} sub={currentClient.currency} />
        <Stat label="Total credits" value={formatGHS(totalCr)} sub={Math.abs(totalDr - totalCr) < 0.005 || accountFilter !== 'ALL' || search ? 'Movement in range' : 'Out of balance — investigate'} tone={Math.abs(totalDr - totalCr) < 0.005 || accountFilter !== 'ALL' || search ? undefined : 'text-rose-700'} />
      </div>

      {ledgers.length === 0 && (
        <Card title="No ledger activity" sub="Nothing posted for the selected account and date range">
          <p className="text-xs text-[#2d4f6d]">Widen the date range, choose another account, or add a GL entry.</p>
        </Card>
      )}

      {ledgers.map((l) => (
        <Card
          key={l.accountNo}
          title={<span className="flex items-center gap-2"><BookOpen className="h-4 w-4 text-[#855b00]" /><span className="font-mono text-[#855b00]">{l.accountNo}</span><span>{l.name}</span>{!l.active && <span className="rounded bg-slate-200 px-1.5 py-0.5 text-[10px] font-bold text-slate-600">Inactive</span>}</span>}
          sub={`${l.type} · ${l.category || 'General ledger'} · Opening ${balanceLabel(l.opening, l.type, formatGHS)} · Closing ${balanceLabel(l.closing, l.type, formatGHS)}`}
          pad={false}
        >
          <div className="overflow-x-auto">
            <table className="w-full min-w-[920px] text-xs">
              <thead><tr className="border-b border-sky-200">
                <th className={thCls}>Date</th><th className={thCls}>Document</th><th className={thCls}>Type</th><th className={thCls}>Narrative</th><th className={thCls}>Cost centre</th><th className={thCls + ' text-right'}>Debit</th><th className={thCls + ' text-right'}>Credit</th><th className={thCls + ' text-right'}>Balance</th><th className={thCls + ' text-center'}>Actions</th>
              </tr></thead>
              <tbody>
                <tr className="bg-sky-50/50">
                  <td className="px-3 py-2 font-mono">{from}</td><td className="px-3 py-2" colSpan={6}><span className="font-bold text-[#355875]">Opening balance brought forward</span></td>
                  <td className={numCls + ' font-bold'}>{balanceLabel(l.opening, l.type, formatGHS)}</td><td />
                </tr>
                {l.entries.map((e) => {
                  const ln = e.line;
                  const frozen = closedPeriods.includes(ln.period) || ln.isReversed || ln.docType === 'REV';
                  return (
                    <tr key={ln.id} className={rowCls + (ln.isReversed ? ' opacity-60' : '')}>
                      <td className="px-3 py-2 font-mono whitespace-nowrap">{ln.date}</td>
                      <td className="px-3 py-2 font-mono font-bold text-[#082f4f] whitespace-nowrap">{ln.docNo}{ln.isReversed && <span className="ml-1 rounded bg-amber-100 px-1 text-[9px] text-[#855b00]">REVERSED</span>}</td>
                      <td className="px-3 py-2"><StatusBadge status={ln.docType} /></td>
                      <td className="px-3 py-2 text-[#163653] max-w-[360px]"><span className="line-clamp-2">{ln.description}</span>{ln.reference && <span className="block text-[10px] text-[#355875]">Ref {ln.reference}</span>}</td>
                      <td className="px-3 py-2 font-mono text-[#355875]">{ln.costCenter || '—'}</td>
                      <td className={numCls}>{ln.debit ? formatGHS(ln.debit) : ''}</td>
                      <td className={numCls}>{ln.credit ? formatGHS(ln.credit) : ''}</td>
                      <td className={numCls + ' font-bold'}>{balanceLabel(e.balance, l.type, formatGHS)}</td>
                      <td className="px-2 py-1.5">
                        <div className="flex items-center justify-center gap-1">
                          <button title={frozen ? 'Frozen (closed period or reversed)' : 'Edit document'} disabled={frozen || isRestricted} onClick={() => openEdit(ln.docNo)} className="rounded border border-sky-300 bg-white p-1 text-[#082f4f] hover:bg-sky-50 disabled:opacity-30"><Pencil className="h-3.5 w-3.5" /></button>
                          <button title="Reverse document into the current period" disabled={ln.isReversed || ln.docType === 'REV' || isRestricted} onClick={() => reverse(ln.docNo)} className="rounded border border-amber-300 bg-white p-1 text-[#855b00] hover:bg-amber-50 disabled:opacity-30"><RotateCcw className="h-3.5 w-3.5" /></button>
                          {canDelete && <button title="Delete document (owner / checker)" disabled={frozen} onClick={() => setDeleting({ docNo: ln.docNo, reason: '' })} className="rounded border border-rose-300 bg-white p-1 text-rose-700 hover:bg-rose-50 disabled:opacity-30"><Trash2 className="h-3.5 w-3.5" /></button>}
                        </div>
                      </td>
                    </tr>
                  );
                })}
                <tr className="bg-sky-100 font-bold">
                  <td className="px-3 py-2 font-mono">{through}</td><td className="px-3 py-2" colSpan={4}>Period movement &amp; closing balance</td>
                  <td className={numCls}>{formatGHS(l.totalDebit)}</td><td className={numCls}>{formatGHS(l.totalCredit)}</td><td className={numCls}>{balanceLabel(l.closing, l.type, formatGHS)}</td><td />
                </tr>
              </tbody>
            </table>
          </div>
        </Card>
      ))}

      {/* Document editor: add a new GL entry or edit a posted document */}
      {editor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={submitEditor} className="w-full max-w-4xl rounded-xl border border-sky-300 bg-white p-5 shadow-xl space-y-4 text-xs">
            <div className="flex items-start justify-between gap-3 border-b border-sky-100 pb-2">
              <div>
                <h3 className="text-base font-bold text-[#082f4f]">{editor.mode === 'add' ? 'Add general ledger entry' : `Edit document ${editor.docNo}`}</h3>
                <p className="text-[11px] text-[#2d4f6d]">{editor.mode === 'add' ? 'Multi-line double entry — debits must equal credits. Posted through the server posting controls.' : 'Changes replace the posted lines on the server and are written to the audit trail with your reason.'}</p>
              </div>
              <button type="button" onClick={() => setEditor(null)} className="rounded border border-sky-200 p-1 text-[#355875] hover:bg-sky-50"><X className="h-4 w-4" /></button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <label className="font-bold text-[#355875]">Document no.<input value={editor.docNo} readOnly className="mt-1 w-full rounded border border-sky-200 bg-sky-50 p-2 font-mono font-bold text-[#082f4f]" /></label>
              <label className="font-bold text-[#355875]">Posting date<input type="date" value={editor.date} onChange={(e) => setEditor({ ...editor, date: e.target.value })} className="mt-1 w-full rounded border border-sky-300 p-2" required /></label>
              <label className="font-bold text-[#355875]">Document type
                <select value={editor.docType} onChange={(e) => setEditor({ ...editor, docType: e.target.value as ACDOCALine['docType'] })} className="mt-1 w-full rounded border border-sky-300 p-2 font-bold text-[#082f4f]">
                  {(['JE', 'STAT', 'DEP', 'INV', 'PO', 'PAY'] as const).map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </label>
              <label className="font-bold text-[#355875]">Reference<input value={editor.reference} onChange={(e) => setEditor({ ...editor, reference: e.target.value })} placeholder="invoice / receipt / contract" className="mt-1 w-full rounded border border-sky-300 p-2" /></label>
            </div>
            {editor.mode === 'add' && <label className="block font-bold text-[#355875]">Narrative (used for lines without their own)<input value={editor.narrative} onChange={(e) => setEditor({ ...editor, narrative: e.target.value })} className="mt-1 w-full rounded border border-sky-300 p-2" /></label>}
            <div className="overflow-x-auto rounded-lg border border-sky-200">
              <table className="w-full min-w-[760px] text-xs">
                <thead><tr><th className={thCls}>Account</th><th className={thCls}>Line narrative</th><th className={thCls}>Cost centre</th><th className={thCls + ' text-right'}>Debit</th><th className={thCls + ' text-right'}>Credit</th><th className={thCls} /></tr></thead>
                <tbody>
                  {editor.draft.map((d, i) => (
                    <tr key={d.id} className="border-b border-sky-100">
                      <td className="p-1.5">
                        <select value={d.accountNo} onChange={(e) => setEditor({ ...editor, draft: editor.draft.map((x, j) => j === i ? { ...x, accountNo: e.target.value } : x) })} className="w-full min-w-[220px] rounded border border-sky-300 p-1.5 font-mono text-[#082f4f]">
                          {!activeAccounts.some((a) => a.accountNo === d.accountNo) && d.accountNo && <option value={d.accountNo}>{d.accountNo} · {accounts.find((a) => a.accountNo === d.accountNo)?.name || 'inactive account'}</option>}
                          {activeAccounts.map((a) => <option key={`${a.accountNo}-${a.clientId ?? 'm'}`} value={a.accountNo}>{a.accountNo} · {a.name}</option>)}
                        </select>
                      </td>
                      <td className="p-1.5"><input value={d.description} onChange={(e) => setEditor({ ...editor, draft: editor.draft.map((x, j) => j === i ? { ...x, description: e.target.value } : x) })} className="w-full rounded border border-sky-300 p-1.5" placeholder="narrative" /></td>
                      <td className="p-1.5">
                        <select value={d.costCenter} onChange={(e) => setEditor({ ...editor, draft: editor.draft.map((x, j) => j === i ? { ...x, costCenter: e.target.value } : x) })} className="rounded border border-sky-300 p-1.5 font-mono">
                          {!COST_CENTRES.some((c) => c.code === d.costCenter) && d.costCenter && <option value={d.costCenter}>{d.costCenter}</option>}
                          {COST_CENTRES.map((c) => <option key={c.code} value={c.code}>{c.code}</option>)}
                        </select>
                      </td>
                      <td className="p-1.5"><input inputMode="decimal" value={d.debit} onChange={(e) => setEditor({ ...editor, draft: editor.draft.map((x, j) => j === i ? { ...x, debit: e.target.value, credit: e.target.value ? '' : x.credit } : x) })} className="w-28 rounded border border-sky-300 p-1.5 text-right font-mono" placeholder="0.00" /></td>
                      <td className="p-1.5"><input inputMode="decimal" value={d.credit} onChange={(e) => setEditor({ ...editor, draft: editor.draft.map((x, j) => j === i ? { ...x, credit: e.target.value, debit: e.target.value ? '' : x.debit } : x) })} className="w-28 rounded border border-sky-300 p-1.5 text-right font-mono" placeholder="0.00" /></td>
                      <td className="p-1.5 text-center"><button type="button" disabled={editor.draft.length <= 2} onClick={() => setEditor({ ...editor, draft: editor.draft.filter((_, j) => j !== i) })} className="rounded border border-rose-200 p-1 text-rose-700 hover:bg-rose-50 disabled:opacity-30" title="Remove line"><Trash2 className="h-3.5 w-3.5" /></button></td>
                    </tr>
                  ))}
                  <tr className="bg-sky-50 font-bold">
                    <td className="p-2" colSpan={3}>
                      <button type="button" onClick={() => setEditor({ ...editor, draft: [...editor.draft, blankLine()] })} className="flex items-center gap-1 rounded border border-sky-300 bg-white px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50"><Plus className="h-3 w-3" /> Add line</button>
                    </td>
                    <td className={numCls}>{formatGHS(editorTotals.dr)}</td><td className={numCls}>{formatGHS(editorTotals.cr)}</td>
                    <td className="p-2 text-center"><span className={`rounded px-2 py-0.5 text-[10px] ${editorBalanced ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>{editorBalanced ? 'Balanced' : `Δ ${formatGHS(Math.abs(editorTotals.dr - editorTotals.cr))}`}</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
            {editor.mode === 'edit' && <label className="block font-bold text-[#355875]">Reason for edit (audit trail)<input value={editor.reason} onChange={(e) => setEditor({ ...editor, reason: e.target.value })} className="mt-1 w-full rounded border border-sky-300 p-2" placeholder="e.g. wrong expense account selected on original posting" required /></label>}
            {editorError && <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 p-2.5 font-bold text-rose-900 flex items-center gap-2"><AlertCircle className="h-4 w-4 shrink-0" />{editorError}</div>}
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setEditor(null)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" disabled={busy} className="rounded bg-[#082f4f] px-4 py-1.5 font-bold text-white disabled:opacity-50">{busy ? 'Saving…' : editor.mode === 'add' ? 'Post entry' : 'Save changes'}</button>
            </div>
          </form>
        </div>
      )}

      {deleting && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-xl border border-rose-300 bg-white p-5 shadow-xl space-y-3 text-xs">
            <h3 className="text-base font-bold text-rose-800">Delete document {deleting.docNo}?</h3>
            <p className="text-[#2d4f6d]">All lines of this document are removed from the ledger of {currentClient.code} on the server. Prefer a reversal when the original must remain visible in the books. The deletion is written to the audit trail with your reason.</p>
            <label className="block font-bold text-[#355875]">Reason<input value={deleting.reason} onChange={(e) => setDeleting({ ...deleting, reason: e.target.value })} className="mt-1 w-full rounded border border-sky-300 p-2" placeholder="e.g. duplicate posting of supplier invoice" /></label>
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button onClick={() => setDeleting(null)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button onClick={confirmDelete} disabled={busy} className="rounded bg-[#b42318] px-4 py-1.5 font-bold text-white hover:bg-rose-800 disabled:opacity-50">{busy ? 'Deleting…' : 'Delete document'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
