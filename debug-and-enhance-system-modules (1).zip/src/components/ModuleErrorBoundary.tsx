import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface Props {
  /** Module identifier — changing it resets the boundary. */
  moduleKey: string;
  label?: string;
  children: React.ReactNode;
  onBackToDashboard?: () => void;
}

interface State {
  error: Error | null;
}

/**
 * Nothing fails silently — and nothing takes the whole workspace down.
 *
 * A render-time fault in one desk used to bubble to the root and show the
 * browser's blank "This page couldn't load" screen. The boundary now contains
 * the fault inside the module, keeps the header, sidebar and the rest of the
 * books usable, and prints the diagnostic so it can be reported.
 */
export class ModuleErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidUpdate(prev: Props) {
    if (prev.moduleKey !== this.props.moduleKey && this.state.error) {
      this.setState({ error: null });
    }
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error(`[BPZ] module "${this.props.moduleKey}" failed to render`, error, info.componentStack);
  }

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    return (
      <div role="alert" className="rounded-xl border border-rose-300 bg-rose-50 p-6 shadow-xs">
        <div className="flex items-start gap-3">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-rose-700" />
          <div className="space-y-2">
            <h2 className="text-sm font-black uppercase tracking-wider text-rose-900">
              The {this.props.label || this.props.moduleKey} module could not be displayed
            </h2>
            <p className="text-xs font-semibold leading-relaxed text-rose-900">
              Your books are safe — nothing was posted or lost. The rest of the workspace is still usable; the fault
              below has been written to the browser console for the support desk.
            </p>
            <pre className="max-h-40 overflow-auto rounded border border-rose-200 bg-white p-3 font-mono text-[11px] text-rose-800">
              {error.message}
            </pre>
            <div className="flex gap-2 pt-1">
              <button
                onClick={() => this.setState({ error: null })}
                className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3 py-1.5 text-xs font-bold text-white hover:bg-[#0c3f68]"
              >
                <RotateCcw className="h-3.5 w-3.5" /> Try this module again
              </button>
              {this.props.onBackToDashboard && (
                <button
                  onClick={this.props.onBackToDashboard}
                  className="rounded-lg border border-rose-300 bg-white px-3 py-1.5 text-xs font-bold text-rose-800 hover:bg-rose-100"
                >
                  Back to Command Center
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ModuleErrorBoundary;
