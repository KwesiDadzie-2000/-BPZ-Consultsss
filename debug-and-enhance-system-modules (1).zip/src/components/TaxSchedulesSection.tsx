import React, { useMemo, useState } from 'react';
import type { ACDOCALine, BusinessPartner, ClientEntity, PurchaseOrder, SalesInvoice, TaxScheduleEntry, TaxScheduleKind, UserAccount } from '../types/accounting';
import type { CompanyProfile } from '../utils/persistentStorage';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import { Printer, FileSpreadsheet, Plus, Pencil, Trash2, Undo2, X, Check, AlertCircle, ShieldCheck } from 'lucide-react';
import {
  deriveWhtDeductions, deriveWhtCredits, deriveVatOutput, deriveVatInput, mergeScheduleRows, scheduleTotals,
  periodRemitted, liabilityBalanceThrough, TAX_ACCOUNTS, r2, type ScheduleRow, type VatRates,
} from '../utils/ledger';
import { taxConfigStore } from '../utils/taxConfig';
import { printReport, downloadCsv, type PrintColumn } from '../utils/printReport';
import { toPrintEntity } from '../utils/printEntity';
import { uniqueId } from '../utils/ids';

type Tab = 'wht' | 'wht_credit' | 'vat_output' | 'vat_input' | 'vat_return' | 'rates';

const TABS: { id: Tab; label: string }[] = [
  { id: 'wht', label: 'WHT deducted (payable)' },
  { id: 'wht_credit', label: 'WHT suffered (credits)' },
  { id: 'vat_output', label: 'VAT output (sales)' },
  { id: 'vat_input', label: 'VAT input (purchases)' },
  { id: 'vat_return', label: 'VAT return summary' },
  { id: 'rates', label: 'WHT rate reference' },
];

const WHT_NATURES = ['Goods', 'Services', 'Works', 'Professional / technical fees', 'Rent — residential', 'Rent — commercial', 'Royalties', 'Interest', 'Dividends', 'Directors fees', 'Commission', 'Non-resident supply', 'Management / technical fee (non-resident)', 'Other'];
const VAT_NATURES = ['Standard-rated supply', 'Standard-rated purchase — goods', 'Standard-rated purchase — services', 'Zero-rated', 'Exempt', 'Relief supply', 'Import', 'Reverse charge (imported services)', 'Credit note (standard-rated)', 'Debit note (standard-rated)', 'Flat rate scheme (3%)', 'Other'];
const WHT_STATUSES = ['Deducted', 'Remitted', 'Certificate issued', 'Exempt (certificate held)', 'Pending'];
const VAT_STATUSES = ['Posted', 'Filed', 'Pending', 'Disputed'];

interface TaxSchedulesSectionProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  salesInvoices: SalesInvoice[];
  purchaseOrders: PurchaseOrder[];
  partners: BusinessPartner[];
  entries: TaxScheduleEntry[];
  profile?: CompanyProfile;
  onSaveEntry: (entry: TaxScheduleEntry) => void;
  onDeleteEntry: (id: string) => void;
}

interface EditorState {
  mode: 'add' | 'edit';
  kind: TaxScheduleKind;
  row: ScheduleRow;
}

const kindLabel = (k: TaxScheduleKind) => k === 'wht' ? 'Withholding tax deducted' : k === 'wht_credit' ? 'Withholding tax suffered' : k === 'vat_output' ? 'Output VAT' : 'Input VAT';
const isWht = (k: TaxScheduleKind) => k === 'wht' || k === 'wht_credit';

export const TaxSchedulesSection: React.FC<TaxSchedulesSectionProps> = ({ currentClient, currentUser, lines, salesInvoices, purchaseOrders, partners, entries, profile, onSaveEntry, onDeleteEntry }) => {
  const [tab, setTab] = useState<Tab>('wht');
  const [month, setMonth] = useState(() => new Date().toISOString().slice(0, 7));
  const [scope, setScope] = useState<'month' | 'year'>('month');
  const [editor, setEditor] = useState<EditorState | null>(null);
  const [editorError, setEditorError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const flash = (t: string) => { setToast(t); setTimeout(() => setToast(null), 6000); };

  const rates: VatRates = useMemo(() => ({
    vat: taxConfigStore.rate('VAT'), nhil: taxConfigStore.rate('NHIL'), getfund: taxConfigStore.rate('GETFUND'), covid: taxConfigStore.rate('COVID'),
  }), []);
  const whtComponents = useMemo(() => taxConfigStore.get().components.filter((c) => c.type === 'withholding_tax'), []);
  const periodLabel = scope === 'month' ? month : `Year ${month.slice(0, 4)}`;
  const inScope = (p: string) => scope === 'month' ? p === month : p.startsWith(month.slice(0, 4));

  const rowsFor = (kind: TaxScheduleKind): ScheduleRow[] => {
    const derived = kind === 'wht' ? deriveWhtDeductions(lines, currentClient.id, null, partners)
      : kind === 'wht_credit' ? deriveWhtCredits(lines, currentClient.id, null, partners)
      : kind === 'vat_output' ? deriveVatOutput(lines, currentClient.id, null, salesInvoices, partners, rates)
      : deriveVatInput(lines, currentClient.id, null, purchaseOrders, partners, rates);
    return mergeScheduleRows(derived, entries, kind, currentClient.id, null).filter((r) => inScope(r.period));
  };
  const whtRows = useMemo(rowsFor.bind(null, 'wht'), [lines, entries, partners, currentClient.id, scope, month]); // eslint-disable-line react-hooks/exhaustive-deps
  const creditRows = useMemo(rowsFor.bind(null, 'wht_credit'), [lines, entries, partners, currentClient.id, scope, month]); // eslint-disable-line react-hooks/exhaustive-deps
  const outRows = useMemo(rowsFor.bind(null, 'vat_output'), [lines, entries, partners, salesInvoices, currentClient.id, scope, month, rates]); // eslint-disable-line react-hooks/exhaustive-deps
  const inRows = useMemo(rowsFor.bind(null, 'vat_input'), [lines, entries, partners, purchaseOrders, currentClient.id, scope, month, rates]); // eslint-disable-line react-hooks/exhaustive-deps

  const whtT = scheduleTotals(whtRows);
  const creditT = scheduleTotals(creditRows);
  const outT = scheduleTotals(outRows);
  const inT = scheduleTotals(inRows);
  const periods = scope === 'month' ? [month] : Array.from({ length: 12 }, (_, i) => `${month.slice(0, 4)}-${String(i + 1).padStart(2, '0')}`);
  const whtRemitted = r2(periods.reduce((s, p) => s + periodRemitted(lines, currentClient.id, p, TAX_ACCOUNTS.WHT_PAYABLE), 0));
  const vatWhtRemitted = r2(periods.reduce((s, p) => s + periodRemitted(lines, currentClient.id, p, TAX_ACCOUNTS.VAT_WHT_PAYABLE), 0));
  const vatRemitted = r2(periods.reduce((s, p) => s + periodRemitted(lines, currentClient.id, p, TAX_ACCOUNTS.OUTPUT_VAT), 0));
  const lastPeriod = scope === 'month' ? month : `${month.slice(0, 4)}-12`;
  const whtBalance = liabilityBalanceThrough(lines, currentClient.id, lastPeriod, TAX_ACCOUNTS.WHT_PAYABLE);
  const vatBalance = liabilityBalanceThrough(lines, currentClient.id, lastPeriod, TAX_ACCOUNTS.OUTPUT_VAT);
  const inputBalance = -liabilityBalanceThrough(lines, currentClient.id, lastPeriod, TAX_ACCOUNTS.INPUT_VAT);
  const netVat = r2(outT.tax - inT.tax);
  const totalDue = r2(netVat + outT.levy);

  const activeKind: TaxScheduleKind | null = tab === 'wht' || tab === 'wht_credit' || tab === 'vat_output' || tab === 'vat_input' ? tab : null;
  const activeRows = tab === 'wht' ? whtRows : tab === 'wht_credit' ? creditRows : tab === 'vat_output' ? outRows : tab === 'vat_input' ? inRows : [];
  const activeTotals = scheduleTotals(activeRows);

  /* --------------------------------------------------------------- editing */
  const blankRow = (kind: TaxScheduleKind): ScheduleRow => ({
    key: '', kind, source: 'manual', edited: false, period: scope === 'month' ? month : `${month.slice(0, 4)}-01`, date: scope === 'month' ? `${month}-01` : `${month.slice(0, 4)}-01-01`, docNo: '',
    partyName: '', partyTin: '', nature: isWht(kind) ? 'Services' : kind === 'vat_output' ? 'Standard-rated supply' : 'Standard-rated purchase — services',
    grossAmount: 0, rate: isWht(kind) ? 7.5 : rates.vat, taxAmount: 0, levyAmount: 0, reference: '', status: isWht(kind) ? 'Deducted' : 'Posted',
  });
  const openAdd = () => { if (!activeKind) return; setEditorError(null); setEditor({ mode: 'add', kind: activeKind, row: blankRow(activeKind) }); };
  const openEdit = (row: ScheduleRow) => { setEditorError(null); setEditor({ mode: 'edit', kind: row.kind, row: { ...row } }); };
  const recompute = (row: ScheduleRow, field: 'grossAmount' | 'rate' | 'taxAmount' | 'levyAmount', value: number): ScheduleRow => {
    const next = { ...row, [field]: value };
    if (field === 'grossAmount' || field === 'rate') {
      next.taxAmount = r2(next.grossAmount * next.rate / 100);
      if (!isWht(row.kind)) next.levyAmount = r2(next.grossAmount * (rates.nhil + rates.getfund + rates.covid) / 100);
    }
    return next;
  };
  const saveEditor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editor) return;
    const row = editor.row;
    if (!row.partyName.trim()) { setEditorError('Enter the name of the supplier, customer or payee.'); return; }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(row.date)) { setEditorError('Enter a valid date.'); return; }
    if (![row.grossAmount, row.rate, row.taxAmount, row.levyAmount].every(Number.isFinite)) { setEditorError('Amounts must be numbers.'); return; }
    if (editor.mode === 'add' && !row.docNo.trim()) { setEditorError('Enter the document / invoice number.'); return; }
    const entry: TaxScheduleEntry = {
      id: row.entryId || uniqueId('TSE'), clientId: currentClient.id, kind: editor.kind,
      source: row.source === 'ledger' ? 'ledger' : 'manual', sourceKey: row.source === 'ledger' ? row.key : undefined,
      period: row.date.slice(0, 7), date: row.date, docNo: row.docNo.trim(), partyName: row.partyName.trim(), partyTin: row.partyTin.trim(),
      nature: row.nature, grossAmount: r2(row.grossAmount), rate: row.rate, taxAmount: r2(row.taxAmount), levyAmount: r2(row.levyAmount),
      reference: row.reference.trim(), status: row.status, note: row.note?.trim() || undefined,
      createdBy: currentUser.username, updatedAt: new Date().toISOString(),
    };
    onSaveEntry(entry);
    flash(editor.mode === 'add' ? `Schedule line ${entry.docNo} added to ${kindLabel(editor.kind)}.` : `Schedule line ${entry.docNo} updated.`);
    setEditor(null);
  };
  const revert = (row: ScheduleRow) => { if (row.entryId) { onDeleteEntry(row.entryId); flash(`${row.docNo} reverted to the ledger-derived values.`); } };
  const remove = (row: ScheduleRow) => { if (row.entryId && confirm(`Remove manual schedule line ${row.docNo}?`)) { onDeleteEntry(row.entryId); flash(`${row.docNo} removed.`); } };

  /* --------------------------------------------------------------- print / export */
  const columnsFor = (kind: TaxScheduleKind): PrintColumn[] => isWht(kind)
    ? [{ key: 'date', label: 'Date' }, { key: 'docNo', label: 'Document' }, { key: 'partyName', label: kind === 'wht' ? 'Payee' : 'Withholding agent (customer)' }, { key: 'partyTin', label: 'TIN' }, { key: 'nature', label: 'Nature of payment' }, { key: 'grossAmount', label: 'Gross amount', numeric: true }, { key: 'rate', label: 'Rate %', align: 'right' }, { key: 'taxAmount', label: kind === 'wht' ? 'WHT deducted' : 'Tax withheld', numeric: true }, { key: 'levyAmount', label: 'VAT withheld', numeric: true }, { key: 'status', label: 'Status' }]
    : [{ key: 'date', label: 'Date' }, { key: 'docNo', label: kind === 'vat_output' ? 'Invoice' : 'Supplier invoice / PO' }, { key: 'partyName', label: kind === 'vat_output' ? 'Customer' : 'Supplier' }, { key: 'partyTin', label: 'TIN' }, { key: 'nature', label: 'Classification' }, { key: 'grossAmount', label: 'Taxable value', numeric: true }, { key: 'taxAmount', label: `VAT ${rates.vat}%`, numeric: true }, { key: 'levyAmount', label: `NHIL+GETFund ${r2(rates.nhil + rates.getfund + rates.covid)}%`, numeric: true }, { key: 'total', label: 'Total tax', numeric: true }, { key: 'status', label: 'Status' }];
  const toPrintRows = (rows: ScheduleRow[]): Record<string, string | number | undefined>[] => rows.map((r) => ({
    date: r.date, docNo: r.docNo, partyName: r.partyName, partyTin: r.partyTin, nature: r.nature, grossAmount: r.grossAmount,
    rate: r.rate ? `${r.rate}` : '', taxAmount: r.taxAmount, levyAmount: r.levyAmount, total: r2(r.taxAmount + r.levyAmount),
    reference: r.reference, status: r.status,
  }));
  const totalsFor = (rows: ScheduleRow[]) => { const t = scheduleTotals(rows); return { date: 'TOTAL', docNo: `${t.count} line(s)`, grossAmount: t.gross, taxAmount: t.tax, levyAmount: t.levy, total: r2(t.tax + t.levy) }; };

  const printActive = () => {
    const entity = toPrintEntity(currentClient, profile);
    const preparedBy = `${currentUser.name} (${currentUser.username})`;
    if (tab === 'vat_return') {
      printReport({
        kicker: 'Statutory schedule', title: 'VAT return summary', subtitle: `VAT ${rates.vat}% · NHIL ${rates.nhil}% · GETFund ${rates.getfund}% · ${currentClient.currency}`, entity, periodLabel, preparedBy,
        stats: [{ label: 'Output VAT', value: outT.tax }, { label: 'Deductible input VAT', value: inT.tax }, { label: 'Net VAT payable', value: netVat }, { label: 'Total due incl. levies', value: totalDue }],
        sections: [
          { title: 'Return computation', columns: [{ key: 'line', label: 'Line' }, { key: 'desc', label: 'Description' }, { key: 'amount', label: currentClient.currency, numeric: true }], rows: vatReturnLines.map((l) => ({ line: l.no, desc: l.label, amount: l.amount })), emphasise: (i) => !!vatReturnLines[i].bold },
          { title: 'Output VAT schedule', columns: columnsFor('vat_output'), rows: toPrintRows(outRows), totals: totalsFor(outRows) },
          { title: 'Input VAT schedule', columns: columnsFor('vat_input'), rows: toPrintRows(inRows), totals: totalsFor(inRows) },
        ],
        orientation: 'landscape',
      });
      return;
    }
    if (tab === 'rates') {
      printReport({
        kicker: 'Reference', title: 'Withholding tax rate reference (Income Tax Act 896, First Schedule)', entity, periodLabel: taxConfigStore.get().effectiveFrom, preparedBy,
        sections: [{ columns: [{ key: 'code', label: 'Code' }, { key: 'name', label: 'Payment type' }, { key: 'rate', label: 'Rate %', align: 'right' }, { key: 'effectiveFrom', label: 'Effective from' }, { key: 'active', label: 'Active' }], rows: whtComponents.map((c) => ({ code: c.code, name: c.name, rate: String(c.rate), effectiveFrom: c.effectiveFrom, active: c.isActive ? 'Yes' : 'No' })) }],
      });
      return;
    }
    if (!activeKind) return;
    const stats = isWht(activeKind)
      ? [{ label: 'Gross payments', value: activeTotals.gross }, { label: activeKind === 'wht' ? 'WHT deducted' : 'Tax withheld', value: activeTotals.tax }, { label: 'VAT withheld', value: activeTotals.levy }, { label: activeKind === 'wht' ? 'Remitted to GRA' : 'Lines', value: activeKind === 'wht' ? whtRemitted : String(activeTotals.count) }]
      : [{ label: 'Taxable value', value: activeTotals.gross }, { label: `VAT ${rates.vat}%`, value: activeTotals.tax }, { label: 'Levies', value: activeTotals.levy }, { label: 'Lines', value: String(activeTotals.count) }];
    printReport({ kicker: 'Statutory schedule', title: `${kindLabel(activeKind)} schedule`, subtitle: `${currentClient.currency} · derived from posted journal entries${activeRows.some((r) => r.edited || r.source === 'manual') ? ' with schedule edits/additions' : ''}`, entity, periodLabel, preparedBy, stats, orientation: 'landscape',
      sections: [{ columns: columnsFor(activeKind), rows: toPrintRows(activeRows), totals: totalsFor(activeRows) }] });
  };

  const exportActive = () => {
    if (!activeKind) return;
    const cols = columnsFor(activeKind);
    downloadCsv(`${currentClient.code}-${activeKind}-schedule-${periodLabel.replace(/\s+/g, '-')}.csv`, [
      ['Entity', currentClient.code, currentClient.name], ['Schedule', kindLabel(activeKind)], ['Period', periodLabel], [],
      cols.map((c) => c.label),
      ...toPrintRows(activeRows).map((r) => cols.map((c) => r[c.key] ?? '')),
      cols.map((c) => (totalsFor(activeRows) as Record<string, string | number | undefined>)[c.key] ?? ''),
    ]);
  };

  const vatReturnLines: { no: string; label: string; amount: number; bold?: boolean }[] = [
    { no: '1', label: `Standard-rated supplies — taxable value`, amount: outT.gross },
    { no: '2', label: `Output VAT at ${rates.vat}%`, amount: outT.tax },
    { no: '3', label: `NHIL + GETFund levies on supplies (${r2(rates.nhil + rates.getfund)}%, not deductible)`, amount: outT.levy },
    { no: '4', label: `Standard-rated purchases — taxable value`, amount: inT.gross },
    { no: '5', label: `Deductible input VAT at ${rates.vat}%`, amount: inT.tax },
    { no: '6', label: `Levies suffered on purchases (expensed, not deductible)`, amount: inT.levy },
    { no: '7', label: 'Net VAT payable / (refundable) = line 2 − line 5', amount: netVat, bold: true },
    { no: '8', label: 'Levies payable (line 3)', amount: outT.levy },
    { no: '9', label: 'Total VAT & levies due to GRA (line 7 + line 8)', amount: totalDue, bold: true },
    { no: '10', label: 'VAT remitted in the period (STAT payments on 220000)', amount: vatRemitted },
    { no: '11', label: 'VAT withholding remitted by the entity as an agent (221000)', amount: vatWhtRemitted },
    { no: '12', label: `Ledger balance 220000 (output VAT & levies payable) through ${lastPeriod}`, amount: vatBalance },
    { no: '13', label: `Ledger balance 125000 (input VAT recoverable) through ${lastPeriod}`, amount: inputBalance },
  ];

  return (
    <div className="space-y-5">
      <PageHeader kicker={`TAX · Statutory schedules · ${currentClient.code}`} title="Withholding tax & VAT schedules" desc="GRA-style monthly schedules derived from posted journal entries, the sales register and the purchase register. Edit any line (TIN, nature of payment, references) or add lines for deductions and supplies that did not pass through the desks.">
        <div className="flex flex-wrap gap-2">
          {activeKind && <button onClick={exportActive} className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"><FileSpreadsheet className="h-4 w-4 text-emerald-700" /><span>Export CSV</span></button>}
          <button onClick={printActive} className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"><Printer className="h-4 w-4" /><span>Print schedule</span></button>
          {activeKind && <button onClick={openAdd} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"><Plus className="h-4 w-4" /><span>Add schedule line</span></button>}
        </div>
      </PageHeader>

      {toast && <div role="status" className="rounded-lg border border-emerald-300 bg-emerald-50 p-3 text-xs font-bold text-emerald-900 flex items-center gap-2"><Check className="h-4 w-4 shrink-0" />{toast}</div>}

      <div className="flex flex-wrap items-end gap-3 rounded-xl bg-white p-4 border border-sky-200 text-xs">
        <label className="font-bold text-[#355875]">Reporting month<input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="block mt-1 rounded border border-sky-300 p-2" /></label>
        <div className="flex rounded-lg border border-sky-300 overflow-hidden">
          <button onClick={() => setScope('month')} className={`px-3 py-2 font-bold ${scope === 'month' ? 'bg-[#082f4f] text-white' : 'bg-white text-[#355875]'}`}>Month</button>
          <button onClick={() => setScope('year')} className={`px-3 py-2 font-bold ${scope === 'year' ? 'bg-[#082f4f] text-white' : 'bg-white text-[#355875]'}`}>Whole year</button>
        </div>
        <span className="pb-2 text-[#2d4f6d]">Rates in force: VAT {rates.vat}% · NHIL {rates.nhil}% · GETFund {rates.getfund}%{rates.covid ? ` · COVID ${rates.covid}%` : ''} · VAT WHT {taxConfigStore.rate('VAT_WHT')}%</span>
      </div>

      <div className="flex flex-wrap gap-2">{TABS.map((t) => <button key={t.id} onClick={() => setTab(t.id)} className={`px-3 py-2 text-xs font-bold rounded ${tab === t.id ? 'bg-[#082f4f] text-white' : 'bg-white border border-sky-200 text-[#163653]'}`}>{t.label}</button>)}</div>

      {tab === 'wht' && (
        <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
          <Stat label="Gross payments subject to WHT" value={formatGHS(whtT.gross)} sub={`${whtT.count} payment(s) · ${periodLabel}`} />
          <Stat label="WHT deducted" value={formatGHS(whtT.tax)} sub="Credits to 209000" tone="text-[#082f4f]" />
          <Stat label="Remitted to GRA" value={formatGHS(whtRemitted)} sub={`Statutory payments in ${periodLabel}`} tone="text-emerald-700" />
          <Stat label="WHT payable balance" value={formatGHS(whtBalance)} sub={`Ledger 209000 through ${lastPeriod}`} tone={whtBalance > 0.005 ? 'text-amber-700' : undefined} />
        </div>
      )}
      {tab === 'wht_credit' && (
        <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
          <Stat label="Receipts withheld upon" value={formatGHS(creditT.gross)} sub={`${creditT.count} receipt(s)`} />
          <Stat label="Tax withheld by customers" value={formatGHS(creditT.tax)} sub="Debits to 115000 — claim against CIT" tone="text-[#082f4f]" />
          <Stat label="Credit notes outstanding" value={creditRows.filter((r) => !/issued|received/i.test(r.status)).length} sub="Chase GRA withholding certificates" />
          <Stat label="Ledger 115000 balance" value={formatGHS(-liabilityBalanceThrough(lines, currentClient.id, lastPeriod, TAX_ACCOUNTS.WHT_RECEIVABLE))} sub={`Through ${lastPeriod}`} />
        </div>
      )}
      {(tab === 'vat_output' || tab === 'vat_input') && (
        <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
          <Stat label="Taxable value" value={formatGHS(activeTotals.gross)} sub={`${activeTotals.count} document(s) · ${periodLabel}`} />
          <Stat label={`VAT ${rates.vat}%`} value={formatGHS(activeTotals.tax)} sub={tab === 'vat_output' ? 'Output VAT charged' : 'Deductible input VAT'} tone="text-[#082f4f]" />
          <Stat label="NHIL + GETFund" value={formatGHS(activeTotals.levy)} sub={tab === 'vat_output' ? 'Levies charged (payable)' : 'Levies suffered (cost)'} />
          <Stat label="Total tax stack" value={formatGHS(r2(activeTotals.tax + activeTotals.levy))} sub={tab === 'vat_output' ? 'Credits to 220000' : 'Debits to 125000'} tone="text-emerald-700" />
        </div>
      )}

      {activeKind && (
        <Card title={`${kindLabel(activeKind)} schedule — ${periodLabel}`} sub={`${activeRows.length} line(s) · ledger-derived rows marked ◦, edited rows marked ✎, manual rows marked +`} pad={false}>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1080px] text-xs">
              <thead><tr className="border-b border-sky-200">
                <th className={thCls}>Src</th><th className={thCls}>Date</th><th className={thCls}>Document</th><th className={thCls}>{isWht(activeKind) ? (activeKind === 'wht' ? 'Payee' : 'Withholding agent') : activeKind === 'vat_output' ? 'Customer' : 'Supplier'}</th><th className={thCls}>TIN</th><th className={thCls}>{isWht(activeKind) ? 'Nature of payment' : 'Classification'}</th>
                <th className={thCls + ' text-right'}>{isWht(activeKind) ? 'Gross' : 'Taxable value'}</th><th className={thCls + ' text-right'}>Rate %</th><th className={thCls + ' text-right'}>{isWht(activeKind) ? (activeKind === 'wht' ? 'WHT deducted' : 'Tax withheld') : `VAT ${rates.vat}%`}</th><th className={thCls + ' text-right'}>{isWht(activeKind) ? 'VAT withheld' : 'Levies'}</th><th className={thCls}>Reference</th><th className={thCls}>Status</th><th className={thCls + ' text-center'}>Actions</th>
              </tr></thead>
              <tbody>
                {activeRows.length === 0 && <tr><td colSpan={13} className="p-6 text-center text-[#355875] italic">No {kindLabel(activeKind).toLowerCase()} lines for {periodLabel}. Add a schedule line or post the underlying transactions.</td></tr>}
                {activeRows.map((r) => (
                  <tr key={r.key} className={rowCls}>
                    <td className="px-2 py-2 text-center font-mono" title={r.source === 'manual' ? 'Manual addition' : r.edited ? 'Ledger row with edits' : 'Derived from the ledger'}>{r.source === 'manual' ? '+' : r.edited ? '✎' : '◦'}</td>
                    <td className="px-3 py-2 font-mono whitespace-nowrap">{r.date}</td>
                    <td className="px-3 py-2 font-mono font-bold text-[#082f4f] whitespace-nowrap">{r.docNo}</td>
                    <td className="px-3 py-2 font-bold text-[#163653]">{r.partyName || <span className="text-rose-700">— add payee</span>}</td>
                    <td className="px-3 py-2 font-mono">{r.partyTin || <span className="text-amber-700">missing</span>}</td>
                    <td className="px-3 py-2 text-[#355875]">{r.nature}</td>
                    <td className={numCls}>{formatGHS(r.grossAmount)}</td>
                    <td className={numCls}>{r.rate ? r.rate : '—'}</td>
                    <td className={numCls + ' font-bold'}>{formatGHS(r.taxAmount)}</td>
                    <td className={numCls}>{formatGHS(r.levyAmount)}</td>
                    <td className="px-3 py-2 text-[#355875] max-w-[180px] truncate" title={r.reference}>{r.reference || '—'}</td>
                    <td className="px-3 py-2"><span className="rounded bg-sky-100 px-2 py-0.5 text-[10.5px] font-bold text-[#163653]">{r.status}</span></td>
                    <td className="px-2 py-1.5">
                      <div className="flex items-center justify-center gap-1">
                        <button title="Edit schedule line" onClick={() => openEdit(r)} className="rounded border border-sky-300 bg-white p-1 text-[#082f4f] hover:bg-sky-50"><Pencil className="h-3.5 w-3.5" /></button>
                        {r.source === 'ledger' && r.edited && <button title="Revert to ledger values" onClick={() => revert(r)} className="rounded border border-amber-300 bg-white p-1 text-[#855b00] hover:bg-amber-50"><Undo2 className="h-3.5 w-3.5" /></button>}
                        {r.source === 'manual' && <button title="Remove manual line" onClick={() => remove(r)} className="rounded border border-rose-300 bg-white p-1 text-rose-700 hover:bg-rose-50"><Trash2 className="h-3.5 w-3.5" /></button>}
                      </div>
                    </td>
                  </tr>
                ))}
                <tr className="bg-sky-100 font-bold">
                  <td className="px-3 py-2" colSpan={6}>Totals — {activeTotals.count} line(s)</td>
                  <td className={numCls}>{formatGHS(activeTotals.gross)}</td><td />
                  <td className={numCls}>{formatGHS(activeTotals.tax)}</td><td className={numCls}>{formatGHS(activeTotals.levy)}</td><td colSpan={3} />
                </tr>
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {tab === 'vat_return' && (
        <>
          <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
            <Stat label="Output VAT" value={formatGHS(outT.tax)} sub={`${outRows.length} sales document(s)`} />
            <Stat label="Deductible input VAT" value={formatGHS(inT.tax)} sub={`${inRows.length} purchase document(s)`} />
            <Stat label={netVat >= 0 ? 'Net VAT payable' : 'Net VAT refundable'} value={formatGHS(Math.abs(netVat))} sub="Output VAT − input VAT" tone={netVat >= 0 ? 'text-amber-700' : 'text-emerald-700'} />
            <Stat label="Total due incl. levies" value={formatGHS(totalDue)} sub="Net VAT + NHIL/GETFund on supplies" tone="text-[#082f4f]" />
          </div>
          <Card title={`VAT return computation — ${periodLabel}`} sub="Lines follow the GRA VAT return layout; NHIL and GETFund are straight levies and are not deductible as input tax">
            <table className="w-full text-xs"><thead><tr><th className={thCls + ' w-12'}>Line</th><th className={thCls}>Description</th><th className={thCls + ' text-right'}>{currentClient.currency}</th></tr></thead><tbody>
              {vatReturnLines.map((l) => <tr key={l.no} className={rowCls + (l.bold ? ' bg-sky-50/60 font-bold' : '')}><td className="px-3 py-2 font-mono">{l.no}</td><td className="px-3 py-2">{l.label}</td><td className={numCls + (l.bold ? ' font-bold' : '')}>{formatGHS(l.amount)}</td></tr>)}
            </tbody></table>
            <p className="mt-3 text-[11px] text-[#2d4f6d] flex items-start gap-2"><ShieldCheck className="h-4 w-4 shrink-0 text-[#855b00]" />Verify the schedules against source invoices and GRA e-VAT records before filing. Remittances are made at the Payment Desk (statutory remittance) and reduce the ledger balances shown on lines 12 and 13.</p>
          </Card>
        </>
      )}

      {tab === 'rates' && (
        <Card title="Withholding tax rate reference" sub={`Income Tax Act 2015 (Act 896) First Schedule, as configured at Tax Rates & Levy Settings · effective ${taxConfigStore.get().effectiveFrom}`} pad={false}>
          <div className="overflow-x-auto"><table className="w-full min-w-[640px] text-xs"><thead><tr><th className={thCls}>Code</th><th className={thCls}>Payment type</th><th className={thCls + ' text-right'}>Rate %</th><th className={thCls}>Effective from</th><th className={thCls}>Status</th></tr></thead><tbody>
            {whtComponents.map((c) => <tr key={c.id} className={rowCls}><td className="px-3 py-2 font-mono text-[#855b00]">{c.code}</td><td className="px-3 py-2">{c.name}</td><td className={numCls + ' font-bold'}>{c.rate}</td><td className="px-3 py-2 font-mono">{c.effectiveFrom}</td><td className="px-3 py-2"><span className={`rounded px-2 py-0.5 text-[10.5px] font-bold ${c.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'}`}>{c.isActive ? 'Active' : 'Inactive'}</span></td></tr>)}
          </tbody></table></div>
        </Card>
      )}

      {editor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={saveEditor} className="w-full max-w-2xl rounded-xl border border-sky-300 bg-white p-5 shadow-xl space-y-4 text-xs">
            <div className="flex items-start justify-between gap-3 border-b border-sky-100 pb-2">
              <div>
                <h3 className="text-base font-bold text-[#082f4f]">{editor.mode === 'add' ? `Add ${kindLabel(editor.kind).toLowerCase()} line` : `Edit ${editor.row.docNo}`}</h3>
                <p className="text-[11px] text-[#2d4f6d]">{editor.row.source === 'ledger' ? 'This line is derived from the ledger. Your edits are stored as schedule overrides and can be reverted; the journal itself is unchanged.' : 'Manual schedule line — does not post to the ledger. Use it for items recorded outside the Payment Desk, imports, reverse charges or certificate corrections.'}</p>
              </div>
              <button type="button" onClick={() => setEditor(null)} className="rounded border border-sky-200 p-1 text-[#355875] hover:bg-sky-50"><X className="h-4 w-4" /></button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <label className="font-bold text-[#355875]">Date<input type="date" value={editor.row.date} onChange={(e) => setEditor({ ...editor, row: { ...editor.row, date: e.target.value } })} className="mt-1 w-full rounded border border-sky-300 p-2" required /></label>
              <label className="font-bold text-[#355875]">Document / invoice no.<input value={editor.row.docNo} readOnly={editor.row.source === 'ledger'} onChange={(e) => setEditor({ ...editor, row: { ...editor.row, docNo: e.target.value } })} className={`mt-1 w-full rounded border border-sky-300 p-2 font-mono ${editor.row.source === 'ledger' ? 'bg-sky-50' : ''}`} /></label>
              <label className="font-bold text-[#355875]">Status
                <select value={editor.row.status} onChange={(e) => setEditor({ ...editor, row: { ...editor.row, status: e.target.value } })} className="mt-1 w-full rounded border border-sky-300 p-2">
                  {(isWht(editor.kind) ? WHT_STATUSES : VAT_STATUSES).map((s) => <option key={s} value={s}>{s}</option>)}
                  {!(isWht(editor.kind) ? WHT_STATUSES : VAT_STATUSES).includes(editor.row.status) && <option value={editor.row.status}>{editor.row.status}</option>}
                </select>
              </label>
              <label className="font-bold text-[#355875] col-span-2">{isWht(editor.kind) ? (editor.kind === 'wht' ? 'Payee (supplier / individual)' : 'Withholding agent (customer)') : editor.kind === 'vat_output' ? 'Customer' : 'Supplier'}
                <input list="bpz-partners" value={editor.row.partyName} onChange={(e) => { const name = e.target.value; const hit = partners.find((p) => p.name.toLowerCase() === name.toLowerCase()); setEditor({ ...editor, row: { ...editor.row, partyName: name, partyTin: hit?.tin || editor.row.partyTin } }); }} className="mt-1 w-full rounded border border-sky-300 p-2 font-bold text-[#082f4f]" required />
                <datalist id="bpz-partners">{partners.map((p) => <option key={p.id} value={p.name} />)}</datalist>
              </label>
              <label className="font-bold text-[#355875]">TIN<input value={editor.row.partyTin} onChange={(e) => setEditor({ ...editor, row: { ...editor.row, partyTin: e.target.value } })} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" placeholder="e.g. C0001234567" /></label>
              <label className="font-bold text-[#355875] col-span-2 md:col-span-3">{isWht(editor.kind) ? 'Nature of payment' : 'Supply classification'}
                <select value={editor.row.nature} onChange={(e) => setEditor({ ...editor, row: { ...editor.row, nature: e.target.value } })} className="mt-1 w-full rounded border border-sky-300 p-2">
                  {(isWht(editor.kind) ? WHT_NATURES : VAT_NATURES).map((n) => <option key={n} value={n}>{n}</option>)}
                  {!(isWht(editor.kind) ? WHT_NATURES : VAT_NATURES).includes(editor.row.nature) && editor.row.nature && <option value={editor.row.nature}>{editor.row.nature}</option>}
                </select>
              </label>
              <label className="font-bold text-[#355875]">{isWht(editor.kind) ? 'Gross amount' : 'Taxable value'}<input type="number" step="0.01" value={editor.row.grossAmount} onChange={(e) => setEditor({ ...editor, row: recompute(editor.row, 'grossAmount', Number(e.target.value)) })} className="mt-1 w-full rounded border border-sky-300 p-2 text-right font-mono" /></label>
              <label className="font-bold text-[#355875]">Rate %
                {isWht(editor.kind) ? (
                  <select value={editor.row.rate} onChange={(e) => setEditor({ ...editor, row: recompute(editor.row, 'rate', Number(e.target.value)) })} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono">
                    {[...new Set([editor.row.rate, ...whtComponents.map((c) => c.rate)])].sort((a, b) => a - b).map((r) => <option key={r} value={r}>{r}%</option>)}
                  </select>
                ) : <input type="number" step="0.01" value={editor.row.rate} onChange={(e) => setEditor({ ...editor, row: recompute(editor.row, 'rate', Number(e.target.value)) })} className="mt-1 w-full rounded border border-sky-300 p-2 text-right font-mono" />}
              </label>
              <label className="font-bold text-[#355875]">{isWht(editor.kind) ? 'Tax withheld' : `VAT ${rates.vat}%`}<input type="number" step="0.01" value={editor.row.taxAmount} onChange={(e) => setEditor({ ...editor, row: recompute(editor.row, 'taxAmount', Number(e.target.value)) })} className="mt-1 w-full rounded border border-sky-300 p-2 text-right font-mono font-bold" /></label>
              <label className="font-bold text-[#355875]">{isWht(editor.kind) ? 'VAT withheld (agents)' : 'NHIL + GETFund levies'}<input type="number" step="0.01" value={editor.row.levyAmount} onChange={(e) => setEditor({ ...editor, row: recompute(editor.row, 'levyAmount', Number(e.target.value)) })} className="mt-1 w-full rounded border border-sky-300 p-2 text-right font-mono" /></label>
              <label className="font-bold text-[#355875] col-span-2">Reference (certificate / receipt / e-VAT no.)<input value={editor.row.reference} onChange={(e) => setEditor({ ...editor, row: { ...editor.row, reference: e.target.value } })} className="mt-1 w-full rounded border border-sky-300 p-2" /></label>
              <label className="font-bold text-[#355875] col-span-2 md:col-span-3">Note<input value={editor.row.note || ''} onChange={(e) => setEditor({ ...editor, row: { ...editor.row, note: e.target.value } })} className="mt-1 w-full rounded border border-sky-300 p-2" placeholder="optional" /></label>
            </div>
            {editorError && <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 p-2.5 font-bold text-rose-900 flex items-center gap-2"><AlertCircle className="h-4 w-4 shrink-0" />{editorError}</div>}
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setEditor(null)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 font-bold text-white">{editor.mode === 'add' ? 'Add line' : 'Save line'}</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
