import { useMemo, useState } from 'react';
import { RefreshCw, Wallet } from 'lucide-react';
import type { BusinessPartner, ClientEntity, UserAccount } from '../types/accounting';
import { Card, StatusBadge, numCls, rowCls, thCls } from './ui';
import { useTradeDesk, fmtMoney, type TradeDocument, type TradePayment } from '../lib/tradeClient';
import { DeskNotice, btnGreen, btnPrimary, btnSecondary } from './trade/TradeShared';
import { AllocateForm, PaymentForm } from './trade/TradeForms';

/**
 * Lifecycle open items, settled from the Payment Desk.
 *
 * ROOT CAUSE of the fragmented treasury: supplier payments were raised inside
 * the P2P desk and customer receipts inside the O2C desk, while the Payment
 * Desk only saw the legacy (browser-held) purchase orders and sales invoices.
 * Three screens could move money and only one of them produced a voucher.
 *
 * This card brings the server-authoritative open items onto the Payment Desk so
 * EVERY payment — legacy or lifecycle — is raised here. The lifecycle desks now
 * link across instead of holding their own payment forms.
 */
type ModalState =
  | { kind: 'pay'; invoice?: TradeDocument }
  | { kind: 'receive'; invoice?: TradeDocument; advance?: boolean }
  | { kind: 'allocate'; payment: TradePayment }
  | null;

export interface TradeSettlementsCardProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  partners: BusinessPartner[];
  disabled?: boolean;
  disabledReason?: string;
  onServerMutation: () => Promise<void>;
  onSessionLost: () => void;
}

const OPEN_STATUSES = ['Open', 'PartiallySettled'];

export function TradeSettlementsCard({
  currentClient, currentUser, partners, disabled = false, disabledReason, onServerMutation, onSessionLost,
}: TradeSettlementsCardProps) {
  // 'all' scope: the Payment Desk is the one place that must see both sides.
  const desk = useTradeDesk({ clientId: currentClient.id, scope: 'all', onServerMutation, onSessionLost });
  const [modal, setModal] = useState<ModalState>(null);
  const [side, setSide] = useState<'payable' | 'receivable'>('payable');

  const documents = useMemo(() => desk.state?.documents || [], [desk.state]);
  const payments = useMemo(() => desk.state?.payments || [], [desk.state]);

  const openPayables = useMemo(
    () => documents.filter((d) => d.docType === 'supplier_invoice' && OPEN_STATUSES.includes(d.status) && (d.openBalance || 0) > 0.009)
      .sort((a, b) => (a.dueDate || a.date).localeCompare(b.dueDate || b.date)),
    [documents],
  );
  const openReceivables = useMemo(
    () => documents.filter((d) => d.docType === 'sales_invoice' && OPEN_STATUSES.includes(d.status) && (d.openBalance || 0) > 0.009)
      .sort((a, b) => (a.dueDate || a.date).localeCompare(b.dueDate || b.date)),
    [documents],
  );
  const unappliedCash = useMemo(
    () => payments.filter((p) => p.status === 'posted' && p.unallocated > 0.009),
    [payments],
  );

  const payableTotal = openPayables.reduce((s, d) => s + (d.openBalance || 0) * d.exchangeRate, 0);
  const receivableTotal = openReceivables.reduce((s, d) => s + (d.openBalance || 0) * d.exchangeRate, 0);

  const rows = side === 'payable' ? openPayables : openReceivables;
  const blocked = disabled || desk.busy;

  if (desk.loading && !desk.state) {
    return (
      <Card title="Lifecycle open items" sub="Loading the server-held settlement workspace…">
        <p className="text-xs text-[#355875]">Connecting to the firm&rsquo;s server…</p>
      </Card>
    );
  }
  if (desk.loadError && !desk.state) {
    return (
      <Card title="Lifecycle open items" sub="Server connection required">
        <p role="alert" className="text-xs font-bold text-rose-900">{desk.loadError}</p>
        <button onClick={() => void desk.refresh()} className={btnSecondary + ' mt-3'}>Retry</button>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      <DeskNotice notice={desk.notice} onDismiss={() => desk.setNotice(null)} />
      <Card
        title="Lifecycle open items — settled here"
        sub="Supplier invoices matched through Procure-to-pay and customer invoices issued through Order-to-cash are paid and received at this desk. The server posts the cash movement, the open-item allocation, the withholding and the journal in one transaction."
        action={
          <div className="flex flex-wrap gap-1.5">
            <button onClick={() => void desk.refresh()} disabled={desk.busy} className={btnSecondary} title="Reload from server">
              <RefreshCw className="inline h-3.5 w-3.5" />
            </button>
            <button onClick={() => setModal({ kind: 'pay' })} disabled={blocked} className={btnPrimary}>
              <Wallet className="inline h-3.5 w-3.5" /> Pay supplier
            </button>
            <button onClick={() => setModal({ kind: 'receive' })} disabled={blocked} className={btnGreen}>Record receipt</button>
            <button onClick={() => setModal({ kind: 'receive', advance: true })} disabled={blocked} className={btnSecondary}>Customer advance</button>
          </div>
        }
      >
        {disabled && disabledReason && (
          <p role="alert" className="mb-3 rounded border border-rose-300 bg-rose-50 px-3 py-2 text-[11px] font-bold text-rose-900">{disabledReason}</p>
        )}

        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          <button
            type="button"
            onClick={() => setSide('payable')}
            className={`rounded-lg border p-3 text-left ${side === 'payable' ? 'border-[#082f4f] bg-[#eaf3fb]' : 'border-sky-200 bg-white hover:bg-sky-50'}`}
          >
            <span className="block text-[10px] font-black uppercase tracking-wider text-[#355875]">Open payables (P2P)</span>
            <span className="block font-mono text-sm font-black text-[#082f4f]">{currentClient.currency} {fmtMoney(payableTotal)}</span>
            <span className="block text-[10px] font-semibold text-[#355875]">{openPayables.length} supplier invoice(s)</span>
          </button>
          <button
            type="button"
            onClick={() => setSide('receivable')}
            className={`rounded-lg border p-3 text-left ${side === 'receivable' ? 'border-[#082f4f] bg-[#eaf3fb]' : 'border-sky-200 bg-white hover:bg-sky-50'}`}
          >
            <span className="block text-[10px] font-black uppercase tracking-wider text-[#355875]">Open receivables (O2C)</span>
            <span className="block font-mono text-sm font-black text-emerald-800">{currentClient.currency} {fmtMoney(receivableTotal)}</span>
            <span className="block text-[10px] font-semibold text-[#355875]">{openReceivables.length} customer invoice(s)</span>
          </button>
          <div className="rounded-lg border border-amber-300 bg-amber-50 p-3">
            <span className="block text-[10px] font-black uppercase tracking-wider text-[#855b00]">Unapplied cash</span>
            <span className="block font-mono text-sm font-black text-[#855b00]">
              {currentClient.currency} {fmtMoney(unappliedCash.reduce((s, p) => s + p.unallocated * p.exchangeRate, 0))}
            </span>
            <span className="block text-[10px] font-semibold text-[#855b00]">{unappliedCash.length} payment(s) to apply</span>
          </div>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[720px] text-xs">
            <thead>
              <tr>
                <th className={thCls}>Document</th>
                <th className={thCls}>{side === 'payable' ? 'Supplier' : 'Customer'}</th>
                <th className={thCls}>Date</th>
                <th className={thCls}>Due</th>
                <th className={thCls + ' text-right'}>Invoice total</th>
                <th className={thCls + ' text-right'}>Open balance</th>
                <th className={thCls}>Status</th>
                <th className={thCls + ' text-right'}>Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && (
                <tr><td colSpan={8} className="px-2 py-6 text-center text-[11px] font-semibold text-[#355875]">
                  No open {side === 'payable' ? 'supplier' : 'customer'} invoices from the lifecycle desks.
                </td></tr>
              )}
              {rows.map((doc) => (
                <tr key={doc.id} className={rowCls}>
                  <td className="px-2 py-1.5 font-mono font-bold text-[#082f4f]">{doc.docNo}</td>
                  <td className="px-2 py-1.5 font-semibold">{doc.partyName}</td>
                  <td className="px-2 py-1.5 font-mono">{doc.date}</td>
                  <td className="px-2 py-1.5 font-mono">{doc.dueDate || '—'}</td>
                  <td className={numCls}>{doc.currency} {fmtMoney(doc.totalAmount)}</td>
                  <td className={numCls + ' font-bold'}>{doc.currency} {fmtMoney(doc.openBalance || 0)}</td>
                  <td className="px-2 py-1.5"><StatusBadge status={doc.status} /></td>
                  <td className="px-2 py-1.5 text-right">
                    <button
                      onClick={() => setModal(side === 'payable' ? { kind: 'pay', invoice: doc } : { kind: 'receive', invoice: doc })}
                      disabled={blocked}
                      className={side === 'payable' ? btnPrimary : btnGreen}
                    >
                      {side === 'payable' ? 'Pay' : 'Receive'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {unappliedCash.length > 0 && (
          <div className="mt-4 rounded-lg border border-amber-300 bg-amber-50/60 p-3">
            <p className="text-[10px] font-black uppercase tracking-wider text-[#855b00]">Cash held unapplied — apply to an open item</p>
            <ul className="mt-2 space-y-1">
              {unappliedCash.map((p) => (
                <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-semibold text-[#5c4300]">
                  <span className="font-mono">{p.paymentNo} · {p.partyName} · {p.currency} {fmtMoney(p.unallocated)} unapplied</span>
                  <button onClick={() => setModal({ kind: 'allocate', payment: p })} disabled={blocked} className={btnSecondary}>Apply</button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </Card>

      {modal?.kind === 'pay' && (
        <PaymentForm kind="supplier_payment" desk={desk} documents={documents} partners={partners}
          currentClient={currentClient} currentUser={currentUser} invoice={modal.invoice} onClose={() => setModal(null)} />
      )}
      {modal?.kind === 'receive' && (
        <PaymentForm kind={modal.advance ? 'customer_advance' : 'customer_receipt'} desk={desk} documents={documents} partners={partners}
          currentClient={currentClient} currentUser={currentUser} invoice={modal.invoice} onClose={() => setModal(null)} />
      )}
      {modal?.kind === 'allocate' && (
        <AllocateForm source={{ kind: 'payment', payment: modal.payment }} desk={desk} documents={documents} onClose={() => setModal(null)} />
      )}
    </div>
  );
}
