import { useState } from 'react';
import { Plus, RefreshCw } from 'lucide-react';
import type { AccountMaster, BusinessPartner, ClientEntity, StockItem, UserAccount } from '../../types/accounting';
import { Card } from '../ui';
import { useTradeDesk, fmtMoney, type TradeDocument, type TradePayment } from '../../lib/tradeClient';
import { DeskNotice, DocumentDrawer, DocumentsTable, PaymentDeskRedirect, PaymentsTable, Pipeline, btnPrimary, btnSecondary, btnGreen, type LifecycleHandlers } from './TradeShared';
import { PeriodReportButton } from './PeriodActivityReport';
import { AllocateForm, FulfilmentForm, NoteForm, OrderForm, SalesInvoiceForm } from './TradeForms';

type ModalState =
  | { kind: 'order' }
  | { kind: 'delivery'; order: TradeDocument }
  | { kind: 'invoice'; source?: TradeDocument }
  | { kind: 'note'; invoice: TradeDocument }
  | { kind: 'receipt'; invoice?: TradeDocument; advance?: boolean }
  | { kind: 'allocate'; payment?: TradePayment; doc?: TradeDocument }
  | null;

export interface O2CDeskProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  partners: BusinessPartner[];
  accounts: AccountMaster[];
  stockItems: StockItem[];
  defaultTaxRate: number;
  onServerMutation: () => Promise<void>;
  onSessionLost: () => void;
  /** Cash never lands on this desk — receipts are raised at the Payment Desk. */
  onNavigate?: (section: string) => void;
}

export function O2CDesk({ currentClient, currentUser, partners, accounts, stockItems, defaultTaxRate, onServerMutation, onSessionLost, onNavigate }: O2CDeskProps) {
  // Scoped load: only the sales lifecycle family is transferred and parsed.
  const desk = useTradeDesk({ clientId: currentClient.id, scope: 'o2c', onServerMutation, onSessionLost });
  const [modal, setModal] = useState<ModalState>(null);
  const [openDoc, setOpenDoc] = useState<TradeDocument | null>(null);
  const [view, setView] = useState<'orders' | 'deliveries' | 'invoices' | 'receipts'>('orders');
  const documents = desk.state?.documents || [];
  const payments = desk.state?.payments || [];
  const live = openDoc ? documents.find((d) => d.id === openDoc.id) || null : null;

  const orders = documents.filter((d) => d.docType === 'sales_order');
  const deliveries = documents.filter((d) => d.docType === 'sales_delivery');
  const invoices = documents.filter((d) => d.docType === 'sales_invoice');
  const notes = documents.filter((d) => d.docType === 'customer_credit_note' || d.docType === 'customer_debit_note');
  const openReceivable = invoices.filter((d) => ['Open', 'PartiallySettled'].includes(d.status)).reduce((s, d) => s + (d.openBalance || 0) * d.exchangeRate, 0);
  const unbilled = deliveries.filter((d) => d.postedAt).reduce((s, d) => s + d.netAmount * d.exchangeRate, 0) - invoices.filter((d) => d.postedAt).reduce((s, d) => s + d.lines.filter((l) => l.sourceLineId).reduce((a, l) => a + l.netAmount, 0) * d.exchangeRate, 0);
  const advances = payments.filter((p) => p.status === 'posted' && (p.paymentType === 'customer_advance' || p.paymentType === 'customer_receipt')).reduce((s, p) => s + p.unallocated * p.exchangeRate, 0);

  const handlers: LifecycleHandlers = {
    onFulfil: (doc) => setModal({ kind: 'delivery', order: doc }),
    onInvoice: (doc) => setModal({ kind: 'invoice', source: doc }),
    onPay: (doc) => setModal({ kind: 'receipt', invoice: doc }),
    onNote: (doc) => setModal({ kind: 'note', invoice: doc }),
    onAllocate: (doc) => setModal({ kind: 'allocate', doc }),
  };
  const openDocument = (doc: TradeDocument) => setOpenDoc(doc);

  if (desk.loading && !desk.state) {
    return <Card title="Order-to-cash lifecycle" sub="Loading the server-held sales workspace…"><p className="text-xs text-[#355875]">Connecting to the firm&rsquo;s server…</p></Card>;
  }
  if (desk.loadError && !desk.state) {
    return (
      <Card title="Order-to-cash lifecycle" sub="Server connection required">
        <p role="alert" className="text-xs font-bold text-rose-900">{desk.loadError}</p>
        <button onClick={() => void desk.refresh()} className={btnSecondary + ' mt-3'}>Retry</button>
      </Card>
    );
  }

  return (
    <div className="space-y-5">
      <DeskNotice notice={desk.notice} onDismiss={() => desk.setNotice(null)} />
      <Card title="Order-to-cash pipeline" sub="Sales order (stock reserved on approval) → delivery (revenue on transfer of control, cost of sales at carrying value) → invoice (receivable + output tax) → receipt. Committed by the server in one transaction." action={
        <div className="flex flex-wrap gap-1.5">
          <button onClick={() => void desk.refresh()} disabled={desk.busy} className={btnSecondary} title="Reload from server"><RefreshCw className="inline h-3.5 w-3.5" /></button>
          <button onClick={() => setModal({ kind: 'order' })} disabled={desk.busy} className={btnPrimary}><Plus className="inline h-3.5 w-3.5" /> Sales order</button>
          <button onClick={() => setModal({ kind: 'invoice' })} disabled={desk.busy} className={btnSecondary}>Issue invoice</button>
          <button onClick={() => setModal({ kind: 'receipt' })} disabled={desk.busy} className={btnGreen}>Record receipt</button>
          <button onClick={() => setModal({ kind: 'receipt', advance: true })} disabled={desk.busy} className={btnSecondary}>Customer advance</button>
        </div>
      }>
        <Pipeline steps={[
          { label: 'Sales orders', count: orders.length, hint: `${orders.filter((d) => ['Approved', 'PartiallyDelivered'].includes(d.status)).length} open for delivery` },
          { label: 'Deliveries', count: deliveries.length, hint: `${deliveries.filter((d) => !d.postedAt).length} unposted` },
          { label: 'Invoices', count: invoices.length, hint: `unbilled ${currentClient.currency} ${fmtMoney(Math.max(0, unbilled))}` },
          { label: 'Receivables', count: invoices.filter((d) => ['Open', 'PartiallySettled'].includes(d.status)).length, hint: `${currentClient.currency} ${fmtMoney(openReceivable)} open` },
          { label: 'Receipts', count: payments.filter((p) => p.paymentType === 'customer_receipt' || p.paymentType === 'customer_advance').length, hint: `unapplied ${currentClient.currency} ${fmtMoney(advances)}` },
        ]} />
        <div className="mt-4 flex flex-wrap gap-1 border-t border-sky-100 pt-3">
          {([['orders', `Sales orders (${orders.length})`], ['deliveries', `Deliveries (${deliveries.length})`], ['invoices', `Invoices & credit notes (${invoices.length + notes.length})`], ['receipts', `Receipts (${payments.filter((p) => p.paymentType !== 'supplier_payment').length})`]] as const).map(([k, label]) => (
            <button key={k} onClick={() => setView(k)} className={`rounded px-3 py-1.5 text-[11px] font-bold ${view === k ? 'bg-[#082f4f] text-white' : 'bg-sky-50 text-[#082f4f] hover:bg-sky-100'}`}>{label}</button>
          ))}
        </div>
      </Card>

      {view === 'orders' && (
        <DocumentsTable title="Sales orders" sub="Approval reserves stock for the customer; nothing posts until goods are delivered or services are invoiced with evidence." docs={orders} documents={documents} desk={desk} currentUser={currentUser} handlers={handlers} onOpen={openDocument} emptyText="No sales orders yet." childType="sales_delivery" />
      )}
      {view === 'deliveries' && (
        <DocumentsTable title="Delivery notes" sub="Posting a delivery issues stock at carrying value (Dr 504000 / Cr inventory) and recognises revenue (Dr 118100 unbilled / Cr revenue) once acceptance evidence is recorded." docs={deliveries} documents={documents} desk={desk} currentUser={currentUser} handlers={handlers} onOpen={openDocument} emptyText="No deliveries — open an approved sales order and choose Deliver." />
      )}
      {view === 'invoices' && (
        <>
          <DocumentsTable title="Sales invoices" sub="Dr 110000 receivable / Cr 118100 unbilled revenue (deliveries) or Cr revenue (evidenced services) / Cr 220000 output tax. Settle from Record receipt." docs={invoices} documents={documents} desk={desk} currentUser={currentUser} handlers={handlers} onOpen={openDocument} emptyText="No sales invoices issued." actions={<PeriodReportButton side="sales" client={currentClient} documents={documents} payments={payments} />} />
          <DocumentsTable title="Customer credit / debit notes" sub="Returns, price credits and additional charges linked to the original invoice; saleable returns are restored to stock at original carrying cost." docs={notes} documents={documents} desk={desk} currentUser={currentUser} handlers={handlers} onOpen={openDocument} emptyText="No customer notes." />
        </>
      )}
      {view === 'receipts' && (
        <PaymentsTable title="Customer receipts & advances" sub="Receipts are applied to open invoices; unapplied cash is a contract liability (225000) until applied to a recognised sale." payments={payments} documents={documents} desk={desk} currentUser={currentUser} onAllocate={(p) => setModal({ kind: 'allocate', payment: p })} types={['customer_receipt', 'customer_advance']} />
      )}

      {live && <DocumentDrawer doc={live} documents={documents} desk={desk} currentUser={currentUser} handlers={{ onFulfil: (d) => { setOpenDoc(null); handlers.onFulfil?.(d); }, onInvoice: (d) => { setOpenDoc(null); handlers.onInvoice?.(d); }, onPay: (d) => { setOpenDoc(null); handlers.onPay?.(d); }, onNote: (d) => { setOpenDoc(null); handlers.onNote?.(d); }, onAllocate: (d) => { setOpenDoc(null); handlers.onAllocate?.(d); } }} onClose={() => setOpenDoc(null)} />}
      {modal?.kind === 'order' && <OrderForm docType="sales_order" desk={desk} currentClient={currentClient} partners={partners} accounts={accounts} stockItems={stockItems} defaultTaxRate={defaultTaxRate} onClose={() => setModal(null)} />}
      {modal?.kind === 'delivery' && <FulfilmentForm kind="sales_delivery" order={modal.order} desk={desk} documents={documents} onClose={() => setModal(null)} />}
      {modal?.kind === 'invoice' && <SalesInvoiceForm desk={desk} documents={documents} source={modal.source} currentClient={currentClient} partners={partners} accounts={accounts} stockItems={stockItems} defaultTaxRate={defaultTaxRate} onClose={() => setModal(null)} />}
      {modal?.kind === 'note' && <NoteForm kind="customer_credit_note" invoice={modal.invoice} desk={desk} documents={documents} accounts={accounts} stockItems={stockItems} defaultTaxRate={defaultTaxRate} onClose={() => setModal(null)} />}
      {modal?.kind === 'receipt' && (
        <PaymentDeskRedirect
          side="customer"
          docNo={modal.invoice?.docNo}
          partyName={modal.invoice?.partyName}
          amount={modal.invoice?.openBalance ?? null}
          currency={modal.invoice?.currency || currentClient.currency}
          onClose={() => setModal(null)}
          onGo={() => { setModal(null); onNavigate?.('payment_desk'); }}
        />
      )}
      {modal?.kind === 'allocate' && (modal.payment || modal.doc) && <AllocateForm source={modal.payment ? { kind: 'payment', payment: modal.payment } : { kind: 'credit', doc: modal.doc! }} desk={desk} documents={documents} onClose={() => setModal(null)} />}
    </div>
  );
}
