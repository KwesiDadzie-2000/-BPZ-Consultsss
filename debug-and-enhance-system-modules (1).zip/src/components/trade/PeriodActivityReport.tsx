'use client';

/**
 * End-of-period activity report for the Sales (O2C) and Procurement (P2P)
 * desks. Closes the loop the desks were missing: after a period of trading the
 * user can produce, on demand, exactly what happened — document counts and
 * values by type, tax collected or suffered by GRA component, the top parties
 * by value, and the open position at the period end — and print it as a
 * working paper.
 */

import { useMemo, useState } from 'react';
import { Printer, X } from 'lucide-react';
import type { ClientEntity } from '@/types/accounting';
import type { TradeDocument, TradePayment } from '@/lib/tradeClient';
import { printReport, type PrintReportSpec, type PrintSection } from '@/utils/printReport';
import { toPrintEntity } from '@/utils/printEntity';
import { computeTaxBreakdown, normaliseTaxRegime, type TaxComponent } from '@/lib/taxEngine';
import { isSalesDoc, regimeForDocument } from '@/utils/documentPrint';
import { btnPrimary, btnSecondary, inputCls, labelCls, symbolFor } from './TradeShared';

const fmt = (n: number) => n.toLocaleString('en-GH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const DOC_LABELS: Record<string, string> = {
  purchase_requisition: 'Purchase requisitions',
  purchase_order: 'Purchase orders',
  goods_receipt: 'Goods received notes',
  supplier_invoice: 'Supplier invoices',
  supplier_credit_note: 'Supplier credit notes',
  supplier_debit_note: 'Supplier debit notes',
  sales_order: 'Sales orders',
  sales_delivery: 'Delivery notes',
  sales_invoice: 'Sales invoices',
  customer_credit_note: 'Customer credit notes',
  customer_debit_note: 'Customer debit notes',
};

interface Row {
  docType: string;
  count: number;
  net: number;
  tax: number;
  total: number;
  open: number;
}

export function PeriodReportButton({ side, client, documents, payments }: {
  side: 'sales' | 'procurement';
  client: ClientEntity;
  documents: TradeDocument[];
  payments: TradePayment[];
}) {
  const [open, setOpen] = useState(false);
  const today = new Date().toISOString().slice(0, 10);
  const [from, setFrom] = useState(`${today.slice(0, 4)}-${today.slice(5, 7)}-01`);
  const [through, setThrough] = useState(today);
  const sym = symbolFor(client.currency);

  const inRange = (date: string) => date >= from && date <= through;

  const model = useMemo(() => {
    const docs = documents.filter((d) => inRange(d.date) && (side === 'sales' ? isSalesDoc(d.docType) : !isSalesDoc(d.docType)));
    const pays = payments.filter((p) => inRange(p.date) && (side === 'sales' ? p.paymentType.startsWith('customer') : p.paymentType === 'supplier_payment'));

    const byType = new Map<string, Row>();
    const byParty = new Map<string, { count: number; total: number }>();
    const byTax = new Map<string, TaxComponent>();
    let net = 0; let tax = 0; let total = 0; let open = 0;

    for (const d of docs) {
      const row = byType.get(d.docType) || { docType: d.docType, count: 0, net: 0, tax: 0, total: 0, open: 0 };
      row.count += 1;
      row.net += d.netAmount;
      row.tax += d.taxAmount;
      row.total += d.totalAmount;
      row.open += d.openBalance ?? 0;
      byType.set(d.docType, row);
      net += d.netAmount; tax += d.taxAmount; total += d.totalAmount; open += d.openBalance ?? 0;

      const party = byParty.get(d.partyName) || { count: 0, total: 0 };
      party.count += 1; party.total += d.totalAmount;
      byParty.set(d.partyName, party);

      const breakdown = computeTaxBreakdown(d.netAmount, regimeForDocument(d, isSalesDoc(d.docType) ? 'sales' : 'purchase'), isSalesDoc(d.docType) ? 'sales' : 'purchase');
      for (const c of breakdown.components) {
        const agg = byTax.get(c.code) || { ...c, amount: 0 };
        agg.amount += c.amount;
        byTax.set(c.code, agg);
      }
    }

    const cash = pays.reduce((s, p) => s + p.cashAmount, 0);
    const withheld = pays.reduce((s, p) => s + p.withheldAmount, 0);
    const unapplied = pays.reduce((s, p) => s + (p.unallocated || 0), 0);

    return {
      types: [...byType.values()].sort((a, b) => b.total - a.total),
      parties: [...byParty.entries()].map(([name, v]) => ({ name, ...v })).sort((a, b) => b.total - a.total).slice(0, 10),
      taxes: [...byTax.values()].sort((a, b) => b.amount - a.amount),
      counts: { documents: docs.length, payments: pays.length },
      net, tax, total, open, cash, withheld, unapplied,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [documents, payments, from, through, side]);

  const title = side === 'sales' ? 'Sales desk — period activity report' : 'Procurement desk — period activity report';

  const print = () => {
    const sections: PrintSection[] = [
      {
        title: 'Activity by document type',
        subtitle: `All ${side === 'sales' ? 'sales and customer' : 'procurement and supplier'} documents dated within the period.`,
        columns: [
          { key: 'docType', label: 'Document type', width: '28%' },
          { key: 'count', label: 'Count', numeric: true, width: '10%' },
          { key: 'net', label: 'Net', numeric: true, width: '16%' },
          { key: 'tax', label: 'Tax', numeric: true, width: '16%' },
          { key: 'total', label: 'Total', numeric: true, width: '16%' },
          { key: 'open', label: 'Open balance', numeric: true, width: '14%' },
        ],
        rows: model.types.map((r) => ({ docType: DOC_LABELS[r.docType] || r.docType, count: r.count, net: r.net, tax: r.tax, total: r.total, open: r.open })),
        totals: { docType: 'Total', count: model.counts.documents, net: model.net, tax: model.tax, total: model.total, open: model.open },
      },
      {
        title: side === 'sales' ? 'Output tax charged (GRA)' : 'Input tax suffered (GRA)',
        columns: [
          { key: 'component', label: 'Component', width: '46%' },
          { key: 'rate', label: 'Rate', numeric: true, width: '16%' },
          { key: 'amount', label: `${client.currency}`, numeric: true, width: '22%' },
          { key: 'gl', label: 'GL', width: '16%' },
        ],
        rows: model.taxes.map((t) => ({ component: t.label, rate: `${t.rate}%`, amount: t.amount, gl: t.accountNo })),
        note: 'Computed under the Value Added Tax Act, 2025 (Act 1151): VAT 15% with NHIL 2.5% and GETFund 2.5% on the taxable value; CST, where charged, forms part of that value (s.15.3); the Tourism Development Levy is charged separately (Tourism Act 817).',
      },
      {
        title: side === 'sales' ? 'Top customers by value' : 'Top suppliers by value',
        columns: [
          { key: 'name', label: 'Party', width: '58%' },
          { key: 'count', label: 'Documents', numeric: true, width: '16%' },
          { key: 'total', label: `${client.currency}`, numeric: true, width: '26%' },
        ],
        rows: model.parties.map((p) => ({ name: p.name, count: p.count, total: p.total })),
        totals: { name: `Top ${model.parties.length} of the period`, count: model.parties.reduce((s, p) => s + p.count, 0), total: model.parties.reduce((s, p) => s + p.total, 0) },
      },
      {
        title: 'Cash settlement',
        columns: [
          { key: 'label', label: 'Movement', width: '70%' },
          { key: 'value', label: `${client.currency}`, numeric: true, width: '30%' },
        ],
        rows: [
          { label: side === 'sales' ? 'Customer receipts and advances received' : 'Supplier payments made', value: model.cash },
          { label: 'Tax withheld at source (payable to GRA)', value: model.withheld },
          { label: 'Unapplied — held as a contract liability / supplier advance', value: model.unapplied },
        ],
        totals: { label: 'Net cash effect for the period', value: model.cash },
      },
    ];

    const spec: PrintReportSpec = {
      title,
      kicker: side === 'sales' ? 'Order to cash' : 'Procure to pay',
      subtitle: `${client.name} (${client.code}) · ${from} to ${through}`,
      entity: toPrintEntity(client, null),
      periodLabel: `${from} to ${through}`,
      preparedBy: 'BPZ Consult',
      stats: [
        { label: 'Documents', value: String(model.counts.documents) },
        { label: 'Payments', value: String(model.counts.payments) },
        { label: 'Net value', value: model.net },
        { label: 'Tax', value: model.tax },
      ],
      sections,
      paragraphs: [
        `Gross value processed in the period: ${client.currency} ${fmt(model.total)}. Open balance carried forward at ${through}: ${client.currency} ${fmt(model.open)}.`,
        'This report is derived from documents posted to the general ledger and reconciles to the trial balance for the same period.',
      ],
      footerNote: 'Prepared for management review. Retain with the period-end working papers.',
    };
    printReport(spec);
  };

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className={btnSecondary}>
        <Printer className="h-3 w-3 inline" /> Period report
      </button>
      {open && (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/50 p-4">
          <div className="mt-8 w-full max-w-3xl rounded-xl bg-white p-6 shadow-xl text-[#082f4f]">
            <div className="flex items-start justify-between gap-3 border-b border-sky-200 pb-3">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#855b00]">End of period</div>
                <h2 className="text-lg font-black">{title}</h2>
                <div className="text-xs text-[#355875]">{client.name} ({client.code}) · {client.currency}</div>
              </div>
              <button onClick={() => setOpen(false)} className="rounded p-1 text-[#355875] hover:bg-sky-50" aria-label="Close"><X className="h-4 w-4" /></button>
            </div>

            <div className="grid grid-cols-2 gap-3 py-4">
              <div><label className={labelCls}>Period from</label><input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className={inputCls} /></div>
              <div><label className={labelCls}>Period through</label><input type="date" value={through} onChange={(e) => setThrough(e.target.value)} className={inputCls} /></div>
            </div>

            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {[
                { label: 'Documents', value: String(model.counts.documents) },
                { label: 'Gross value', value: `${sym}${fmt(model.total)}` },
                { label: 'Tax', value: `${sym}${fmt(model.tax)}` },
                { label: 'Open balance', value: `${sym}${fmt(model.open)}` },
              ].map((s) => (
                <div key={s.label} className="rounded border border-sky-200 bg-sky-50/60 p-2.5">
                  <div className="text-[9px] font-bold uppercase tracking-wider text-[#355875]">{s.label}</div>
                  <div className="font-mono text-sm font-black">{s.value}</div>
                </div>
              ))}
            </div>

            <h3 className="mt-4 text-[11px] font-black uppercase tracking-[0.12em] text-[#082f4f]">Activity by document type</h3>
            <div className="mt-1 overflow-x-auto rounded border border-sky-200">
              <table className="w-full min-w-[520px] text-[11px]">
                <thead><tr className="bg-sky-50/80">
                  <th className="px-2 py-1.5 text-left text-[9.5px] font-bold uppercase tracking-wider text-[#355875]">Document type</th>
                  <th className="px-2 py-1.5 text-right text-[9.5px] font-bold uppercase tracking-wider text-[#355875]">Count</th>
                  <th className="px-2 py-1.5 text-right text-[9.5px] font-bold uppercase tracking-wider text-[#355875]">Net</th>
                  <th className="px-2 py-1.5 text-right text-[9.5px] font-bold uppercase tracking-wider text-[#355875]">Tax</th>
                  <th className="px-2 py-1.5 text-right text-[9.5px] font-bold uppercase tracking-wider text-[#355875]">Total</th>
                </tr></thead>
                <tbody className="font-mono tabular-nums">
                  {model.types.length === 0 && <tr><td colSpan={5} className="px-3 py-6 text-center font-sans text-[#355875]">No documents in this period.</td></tr>}
                  {model.types.map((r) => (
                    <tr key={r.docType} className="border-b border-sky-100">
                      <td className="px-2 py-1 font-sans">{DOC_LABELS[r.docType] || r.docType}</td>
                      <td className="px-2 py-1 text-right">{r.count}</td>
                      <td className="px-2 py-1 text-right">{fmt(r.net)}</td>
                      <td className="px-2 py-1 text-right">{fmt(r.tax)}</td>
                      <td className="px-2 py-1 text-right font-bold">{fmt(r.total)}</td>
                    </tr>
                  ))}
                  {model.types.length > 0 && (
                    <tr className="border-y-2 border-[#082f4f] bg-sky-100/80 font-black">
                      <td className="px-2 py-1.5 font-sans">Total</td>
                      <td className="px-2 py-1.5 text-right">{model.counts.documents}</td>
                      <td className="px-2 py-1.5 text-right">{fmt(model.net)}</td>
                      <td className="px-2 py-1.5 text-right">{fmt(model.tax)}</td>
                      <td className="px-2 py-1.5 text-right">{fmt(model.total)}</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {model.taxes.length > 0 && (
              <>
                <h3 className="mt-4 text-[11px] font-black uppercase tracking-[0.12em] text-[#082f4f]">{side === 'sales' ? 'Tax charged' : 'Input tax suffered'}</h3>
                <div className="mt-1 flex flex-wrap gap-1.5">
                  {model.taxes.map((t) => (
                    <span key={t.code} className="rounded border border-sky-200 bg-sky-50 px-2 py-1 text-[10.5px] font-bold text-[#082f4f]">
                      {t.label} {t.rate}% · {sym}{fmt(t.amount)}
                    </span>
                  ))}
                </div>
              </>
            )}

            <h3 className="mt-4 text-[11px] font-black uppercase tracking-[0.12em] text-[#082f4f]">{side === 'sales' ? 'Top customers' : 'Top suppliers'}</h3>
            <div className="mt-1 overflow-x-auto rounded border border-sky-200">
              <table className="w-full min-w-[420px] text-[11px]">
                <thead><tr className="bg-sky-50/80">
                  <th className="px-2 py-1.5 text-left text-[9.5px] font-bold uppercase tracking-wider text-[#355875]">Party</th>
                  <th className="px-2 py-1.5 text-right text-[9.5px] font-bold uppercase tracking-wider text-[#355875]">Documents</th>
                  <th className="px-2 py-1.5 text-right text-[9.5px] font-bold uppercase tracking-wider text-[#355875]">Value</th>
                </tr></thead>
                <tbody className="font-mono tabular-nums">
                  {model.parties.length === 0 && <tr><td colSpan={3} className="px-3 py-6 text-center font-sans text-[#355875]">No activity in this period.</td></tr>}
                  {model.parties.map((p) => (
                    <tr key={p.name} className="border-b border-sky-100">
                      <td className="px-2 py-1 font-sans">{p.name}</td>
                      <td className="px-2 py-1 text-right">{p.count}</td>
                      <td className="px-2 py-1 text-right font-bold">{fmt(p.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-5 flex justify-end gap-2 border-t border-sky-100 pt-3">
              <button onClick={() => setOpen(false)} className={btnSecondary}>Close</button>
              <button onClick={print} className={btnPrimary}><Printer className="h-3 w-3 inline" /> Print period report</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/** Reads the regime a stored document was raised under (re-exported for the desks). */
export const documentRegime = regimeForDocument;
export const legacyRegime = normaliseTaxRegime;
