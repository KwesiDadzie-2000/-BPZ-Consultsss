'use client';

/**
 * Ghana tax treatment panel — the control the sales and procurement desks were
 * missing. Every document raised under Sales or Procurement carries its own tax
 * regime, so the rates the user enters here drive the document totals, the
 * journal the engine posts and the tax reports that follow.
 *
 * Statutory defaults come from the GRA regime verified in `@/lib/taxEngine`:
 * VAT 15% + NHIL 2.5% + GETFund 2.5% on the taxable value, Communication
 * Service Tax (5%) cascading into that value where the entity charges it, the
 * Tourism Development Levy (1%) charged separately, and the withholding rates
 * that apply at source.
 */

import { useMemo } from 'react';
import { computeTaxBreakdown, DEFAULT_TAX_REGIME, normaliseTaxRegime, type TaxBreakdown, type TaxRegime, type TaxSide } from '@/lib/taxEngine';
import { inputCls, labelCls, symbolFor } from './TradeShared';

export interface TaxRegimePanelProps {
  side: TaxSide;
  currency: string;
  regime: TaxRegime;
  onChange: (regime: TaxRegime) => void;
  /** Tax-exclusive value the preview is computed on. */
  netAmount: number;
  disabled?: boolean;
}

const fmt = (n: number) => n.toLocaleString('en-GH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const WITHHOLDING_RATES = [0, 3, 5, 7.5, 8, 10, 15, 20];

export function TaxRegimePanel({ side, currency, regime, onChange, netAmount, disabled }: TaxRegimePanelProps) {
  const breakdown = useMemo<TaxBreakdown>(
    () => computeTaxBreakdown(netAmount, regime, side),
    [netAmount, regime, side],
  );
  const sym = symbolFor(currency);
  const set = (patch: Partial<TaxRegime>) => onChange({ ...regime, ...patch });

  const standardStack = () => set({ vatRate: 15, nhilRate: 2.5, getfundRate: 2.5, covidRate: 0 });
  const zeroRated = () => set({ vatRate: 0, nhilRate: 0, getfundRate: 0, covidRate: 0, cstRate: 0, tourismRate: 0 });

  const chip = (on: boolean) =>
    `rounded border px-2 py-1 text-[10.5px] font-bold transition ${on ? 'border-[#082f4f] bg-[#082f4f] text-white' : 'border-sky-300 bg-white text-[#082f4f] hover:bg-sky-50'} disabled:opacity-50`;

  return (
    <div className="rounded-lg border border-sky-200 bg-sky-50/50 p-3">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="text-[10.5px] font-bold uppercase tracking-wider text-[#355875]">Ghana tax treatment</div>
          <div className="text-[10px] text-[#355875]">Value Added Tax Act, 2025 (Act 1151) · Tourism Act 817 · CST Act 754 as amended by Act 1025</div>
        </div>
        <div className="flex gap-1.5">
          <button type="button" onClick={standardStack} disabled={disabled} className="rounded border border-sky-300 bg-white px-2 py-1 text-[10.5px] font-bold text-[#082f4f] hover:bg-sky-50 disabled:opacity-50">Standard 20% stack</button>
          <button type="button" onClick={zeroRated} disabled={disabled} className="rounded border border-sky-300 bg-white px-2 py-1 text-[10.5px] font-bold text-[#082f4f] hover:bg-sky-50 disabled:opacity-50">Zero / exempt</button>
          <button type="button" onClick={() => onChange({ ...DEFAULT_TAX_REGIME })} disabled={disabled} className="rounded border border-sky-300 bg-white px-2 py-1 text-[10.5px] font-bold text-[#082f4f] hover:bg-sky-50 disabled:opacity-50">Reset</button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-6">
        <div>
          <label className={labelCls}>VAT rate %</label>
          <input type="number" min="0" max="100" step="0.5" value={regime.vatRate} disabled={disabled}
            onChange={(e) => set({ vatRate: Number(e.target.value) })} className={inputCls + ' font-mono'} />
        </div>
        <div>
          <label className={labelCls}>NHIL %</label>
          <input type="number" min="0" max="100" step="0.25" value={regime.nhilRate} disabled={disabled}
            onChange={(e) => set({ nhilRate: Number(e.target.value) })} className={inputCls + ' font-mono'} />
        </div>
        <div>
          <label className={labelCls}>GETFund %</label>
          <input type="number" min="0" max="100" step="0.25" value={regime.getfundRate} disabled={disabled}
            onChange={(e) => set({ getfundRate: Number(e.target.value) })} className={inputCls + ' font-mono'} />
        </div>
        <div>
          <label className={labelCls}>COVID levy %</label>
          <input type="number" min="0" max="100" step="0.25" value={regime.covidRate} disabled={disabled}
            onChange={(e) => set({ covidRate: Number(e.target.value) })} className={inputCls + ' font-mono'} />
          <div className="mt-0.5 text-[9px] text-[#855b00]">Repealed 1 Jan 2026</div>
        </div>
        <div>
          <label className={labelCls}>CST % (cascade)</label>
          <input type="number" min="0" max="100" step="0.5" value={regime.cstRate} disabled={disabled}
            onChange={(e) => set({ cstRate: Number(e.target.value) })} className={inputCls + ' font-mono'} />
          <div className="mt-0.5 text-[9px] text-[#355875]">Enters the VAT base</div>
        </div>
        <div>
          <label className={labelCls}>Tourism levy %</label>
          <input type="number" min="0" max="100" step="0.5" value={regime.tourismRate} disabled={disabled}
            onChange={(e) => set({ tourismRate: Number(e.target.value) })} className={inputCls + ' font-mono'} />
          <div className="mt-0.5 text-[9px] text-[#355875]">Outside the VAT base</div>
        </div>
      </div>

      <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
        <span className="text-[10px] font-bold uppercase tracking-wider text-[#355875]">Apply:</span>
        <button type="button" disabled={disabled} onClick={() => set({ cstRate: regime.cstRate > 0 ? 0 : 5 })} className={chip(regime.cstRate > 0)}>
          Communication Service Tax {regime.cstRate > 0 ? `${regime.cstRate}%` : 'off'}
        </button>
        <button type="button" disabled={disabled} onClick={() => set({ tourismRate: regime.tourismRate > 0 ? 0 : 1 })} className={chip(regime.tourismRate > 0)}>
          Tourism Development Levy {regime.tourismRate > 0 ? `${regime.tourismRate}%` : 'off'}
        </button>
        {side === 'sales' && (
          <button type="button" disabled={disabled} onClick={() => set({ vatWithholdingRate: regime.vatWithholdingRate > 0 ? 0 : 7 })} className={chip(regime.vatWithholdingRate > 0)}>
            Customer VAT withholding {regime.vatWithholdingRate > 0 ? `${regime.vatWithholdingRate}%` : 'off'}
          </button>
        )}
        {side === 'purchase' && (
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#355875]">Income WHT</span>
            <select value={regime.incomeWhtRate} disabled={disabled} onChange={(e) => set({ incomeWhtRate: Number(e.target.value) })}
              className={inputCls + ' w-24 font-mono'}>
              {WITHHOLDING_RATES.map((r) => <option key={r} value={r}>{r}%</option>)}
            </select>
          </div>
        )}
      </div>

      <div className="mt-3 overflow-hidden rounded border border-sky-200 bg-white">
        <table className="w-full text-[11px]">
          <tbody>
            {breakdown.components.map((c) => (
              <tr key={c.code} className="border-b border-sky-100">
                <td className="px-2 py-1">{c.label} <span className="font-mono text-[10px] text-[#355875]">{c.rate}%</span></td>
                <td className="px-2 py-1 text-right font-mono">{sym}{fmt(c.amount)}</td>
              </tr>
            ))}
            <tr className="border-b border-sky-100">
              <td className="px-2 py-1 font-bold">Total tax charged</td>
              <td className="px-2 py-1 text-right font-mono font-bold">{sym}{fmt(breakdown.totalTax)}</td>
            </tr>
            <tr className="bg-sky-50">
              <td className="px-2 py-1.5 font-black text-[#082f4f]">Document total (effective rate {breakdown.effectiveRate}%)</td>
              <td className="px-2 py-1.5 text-right font-mono font-black text-[#082f4f]">{sym}{fmt(breakdown.gross)}</td>
            </tr>
            {breakdown.vatWithheld > 0 && (
              <tr>
                <td className="px-2 py-1 text-[#855b00]">Less VAT withheld at source — receivable from GRA</td>
                <td className="px-2 py-1 text-right font-mono text-[#855b00]">({sym}{fmt(breakdown.vatWithheld)})</td>
              </tr>
            )}
            {breakdown.incomeWhTax > 0 && (
              <tr>
                <td className="px-2 py-1 text-[#855b00]">Income withholding tax deducted from the payment</td>
                <td className="px-2 py-1 text-right font-mono text-[#855b00]">({sym}{fmt(breakdown.incomeWhTax)})</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="mt-1.5 text-[9.5px] leading-relaxed text-[#355875]">
        VAT is charged at 15% with NHIL and the GETFund Levy at 2.5% each on the same taxable value. Where Communication Service Tax is charged it is
        added to the cost first and forms part of the taxable value before VAT (Act 1151 s.15.3). The Tourism Development Levy is charged separately and
        is excluded from the VAT taxable value (Tourism Act 817).
      </p>
    </div>
  );
}

/** Reads the regime a stored document was raised under, defaulting to the current statutory stack. */
export function readRegime(data: Record<string, unknown> | undefined, side: TaxSide): TaxRegime {
  return normaliseTaxRegime(data?.tax, side);
}
