import { useMemo, useState, type FormEvent } from 'react';
import type { AccountMaster, BusinessPartner, ClientEntity, StockItem, UserAccount } from '../../types/accounting';
import { thCls, numCls } from '../ui';
import {
  Field, Modal, LineEditor, newDraftLine, toApiLines, validateDraftLines, draftTotals,
  inputCls, labelCls, btnPrimary, btnSecondary, symbolFor, type DraftLine,
} from './TradeShared';
import {
  DOC_TYPE_LABEL, fmtMoney, fmtQty, money, fulfilledQuantity, pendingQuantity,
  type TradeDesk, type TradeDocument, type TradeItemType, type TradePayment,
} from '../../lib/tradeClient';
import { TaxRegimePanel } from './TaxRegimePanel';
import { DEFAULT_TAX_REGIME, type TaxRegime } from '../../lib/taxEngine';

const today = () => new Date().toISOString().slice(0, 10);
const ErrorLine = ({ text }: { text: string | null }) => (text ? <div role="alert" className="rounded border border-rose-300 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-900">{text}</div> : null);

function FormFooter({ onClose, busy, label }: { onClose: () => void; busy: boolean; label: string }) {
  return (
    <div className="flex justify-end gap-2 border-t border-sky-100 pt-3">
      <button type="button" onClick={onClose} className={btnSecondary}>Cancel</button>
      <button type="submit" disabled={busy} className={btnPrimary}>{busy ? 'Committing…' : label}</button>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Requisition / purchase order / sales order
 * ------------------------------------------------------------------ */
export function OrderForm({ docType, desk, currentClient, partners, accounts, stockItems, fromDocument, defaultTaxRate, onClose }: {
  docType: 'purchase_requisition' | 'purchase_order' | 'sales_order'; desk: TradeDesk; currentClient: ClientEntity; partners: BusinessPartner[];
  accounts: AccountMaster[]; stockItems: StockItem[]; fromDocument?: TradeDocument; defaultTaxRate: number; onClose: () => void;
}) {
  const mode: 'purchase' | 'sales' = docType === 'sales_order' ? 'sales' : 'purchase';
  const partyOptions = partners.filter((p) => p.type === (mode === 'sales' ? 'Customer' : 'Vendor'));
  const defaultRevenue = accounts.find((a) => a.type === 'Income' && a.active && a.accountNo === '400000')?.accountNo || accounts.find((a) => a.type === 'Income' && a.active)?.accountNo || '';
  const [partyName, setPartyName] = useState(fromDocument?.partyName || '');
  const [date, setDate] = useState(today());
  const [dueDate, setDueDate] = useState('');
  const [currency, setCurrency] = useState(fromDocument?.currency || currentClient.currency);
  const [exchangeRate, setExchangeRate] = useState(fromDocument?.exchangeRate || 1);
  const [externalRef, setExternalRef] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('30 days');
  const [priceTol, setPriceTol] = useState(5);
  const [qtyTol, setQtyTol] = useState(0);
  const [tax, setTax] = useState<TaxRegime>({ ...DEFAULT_TAX_REGIME });
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [lines, setLines] = useState<DraftLine[]>(() => fromDocument
    ? fromDocument.lines.map((l) => newDraftLine({ itemType: l.itemType as TradeItemType, itemCode: l.itemCode || '', description: l.description, uom: l.uom, quantity: l.quantity, unitPrice: l.unitPrice, discountAmount: l.discountAmount, taxRate: l.taxRate, accountNo: l.accountNo || '', revenueAccount: l.revenueAccount || defaultRevenue, costCenter: l.costCenter || 'CC-OPS' }))
    : [newDraftLine({ itemType: stockItems.length ? 'stock' : 'service', taxRate: defaultTaxRate, revenueAccount: defaultRevenue, costCenter: mode === 'sales' ? 'CC-SLS' : 'CC-OPS' })]);
  const functional = currency === currentClient.currency;
  const totals = draftTotals(lines);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const v = validateDraftLines(lines, mode, stockItems);
    if (v) return setError(v);
    if (docType !== 'purchase_requisition' && !partyName.trim()) return setError(mode === 'sales' ? 'Select the customer.' : 'Select the supplier.');
    if (!functional && !(exchangeRate > 0)) return setError(`Enter the ${currency} → ${currentClient.currency} exchange rate.`);
    setError(null);
    const party = partyOptions.find((p) => p.name === partyName);
    const r = await desk.run({
      action: 'create_document', docType, date, dueDate: dueDate || undefined, currency, exchangeRate: functional ? 1 : exchangeRate,
      partyName: partyName.trim(), partyId: party ? String(party.id) : undefined, externalRef: externalRef.trim() || undefined,
      sourceDocumentId: fromDocument?.id,
      tax,
      data: { notes, paymentTerms, priceTolerancePct: priceTol, quantityTolerancePct: qtyTol, requisitionId: fromDocument?.id || '' },
      lines: toApiLines(lines, mode, stockItems),
    }, (res) => `${DOC_TYPE_LABEL[docType]} ${String(res.docNo)} saved as a draft (no journal yet). Submit it for authorisation.`);
    if (r.ok) onClose();
  };

  return (
    <Modal title={fromDocument ? `Raise purchase order from ${fromDocument.docNo}` : `New ${DOC_TYPE_LABEL[docType].toLowerCase()}`} sub="Authorisation document — nothing posts to the ledger until goods are received, delivered or invoiced." onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Field label={mode === 'sales' ? 'Customer' : docType === 'purchase_requisition' ? 'Preferred supplier (optional)' : 'Supplier'} className="col-span-2">
            <input list={`parties-${docType}`} value={partyName} onChange={(e) => setPartyName(e.target.value)} className={inputCls} placeholder={partyOptions.length ? 'Choose or type a name' : 'Type the name'} />
            <datalist id={`parties-${docType}`}>{partyOptions.map((p) => <option key={p.id} value={p.name}>{p.code}</option>)}</datalist>
          </Field>
          <Field label="Document date"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} required /></Field>
          <Field label={mode === 'sales' ? 'Requested delivery' : 'Required by'}><input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className={inputCls} /></Field>
          <Field label="Currency">
            <select value={currency} onChange={(e) => setCurrency(e.target.value)} className={inputCls}>
              {[currentClient.currency, 'GHS', 'USD', 'GBP', 'EUR'].filter((c, i, arr) => arr.indexOf(c) === i).map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label={`Rate → ${currentClient.currency}`}><input type="number" min="0" step="0.0001" value={functional ? 1 : exchangeRate} disabled={functional} onChange={(e) => setExchangeRate(Number(e.target.value))} className={inputCls + ' font-mono'} /></Field>
          <Field label={mode === 'sales' ? 'Customer PO / quote ref' : 'Quotation / tender ref'}><input value={externalRef} onChange={(e) => setExternalRef(e.target.value)} className={inputCls + ' font-mono'} /></Field>
          <Field label="Payment terms"><input value={paymentTerms} onChange={(e) => setPaymentTerms(e.target.value)} className={inputCls} /></Field>
          {docType === 'purchase_order' && (
            <>
              <Field label="Price tolerance %" hint="Invoice price variance above this is rejected at matching."><input type="number" min="0" max="100" step="0.5" value={priceTol} onChange={(e) => setPriceTol(Number(e.target.value))} className={inputCls + ' font-mono'} /></Field>
              <Field label="Over-receipt tolerance %" hint="Receipts above ordered quantity + tolerance are blocked."><input type="number" min="0" max="100" step="0.5" value={qtyTol} onChange={(e) => setQtyTol(Number(e.target.value))} className={inputCls + ' font-mono'} /></Field>
            </>
          )}
          <Field label="Notes" className="col-span-2 md:col-span-4"><input value={notes} onChange={(e) => setNotes(e.target.value)} className={inputCls} /></Field>
        </div>
        <TaxRegimePanel side={mode === 'sales' ? 'sales' : 'purchase'} currency={currency} regime={tax} onChange={setTax} netAmount={totals.net} disabled={desk.busy} />
        <LineEditor lines={lines} onChange={setLines} mode={mode} stockItems={stockItems} accounts={accounts} currency={currency} defaultTaxRate={defaultTaxRate} />
        {!functional && <p className="text-[10.5px] text-[#355875]">Functional-currency value at the entered rate: {currentClient.currency} {fmtMoney(totals.total * exchangeRate)}.</p>}
        <ErrorLine text={error} />
        <FormFooter onClose={onClose} busy={desk.busy} label={`Save ${DOC_TYPE_LABEL[docType].toLowerCase()} draft`} />
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ *
 * Goods receipt (from PO) / delivery note (from SO)
 * ------------------------------------------------------------------ */
export function FulfilmentForm({ order, kind, desk, documents, onClose }: { order: TradeDocument; kind: 'goods_receipt' | 'sales_delivery'; desk: TradeDesk; documents: TradeDocument[]; onClose: () => void }) {
  const tolerance = kind === 'goods_receipt' ? Number((order.data as Record<string, unknown>).quantityTolerancePct || 0) : 0;
  const rows = order.lines.map((line) => {
    const done = fulfilledQuantity(documents, line.id, kind);
    const pending = pendingQuantity(documents, line.id, kind);
    const cap = Math.max(0, money(line.quantity * (1 + tolerance / 100)) - done - pending);
    return { line, done, pending, remaining: Math.max(0, line.quantity - done - pending), cap };
  });
  const [qty, setQty] = useState<Record<string, number>>(() => Object.fromEntries(rows.map((r) => [r.line.id, r.remaining])));
  const [date, setDate] = useState(today());
  const [landedCost, setLandedCost] = useState(0);
  const [landedMethod, setLandedMethod] = useState<'value' | 'quantity'>('value');
  const [warehouse, setWarehouse] = useState('Main store');
  const [evidenceRef, setEvidenceRef] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const hasStock = order.lines.some((l) => l.itemType === 'stock');
  const sym = symbolFor(order.currency);
  const stock = desk.state?.stockItems || [];

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const lines = rows.filter((r) => (qty[r.line.id] || 0) > 0).map((r) => ({ sourceLineId: r.line.id, quantity: qty[r.line.id] }));
    if (!lines.length) return setError('Enter a quantity on at least one line.');
    for (const r of rows) {
      const q = qty[r.line.id] || 0;
      if (q < 0) return setError(`${r.line.description}: quantity cannot be negative.`);
      if (q > r.cap + 0.0005) return setError(`${r.line.description}: ${fmtQty(q)} exceeds the open quantity of ${fmtQty(r.cap)}${tolerance ? ` (incl. ${tolerance}% tolerance)` : ''}.`);
      if (kind === 'sales_delivery' && r.line.itemType === 'stock' && r.line.itemCode) {
        const item = stock.find((s) => s.itemCode === r.line.itemCode);
        if (item && q > item.quantityOnHand + 0.0005) return setError(`${r.line.itemCode}: only ${fmtQty(item.quantityOnHand)} ${item.uom} on hand — negative stock is blocked.`);
      }
    }
    if (kind === 'sales_delivery' && !evidenceRef.trim()) return setError('Record the delivery note / proof-of-delivery / customer acceptance reference — revenue is recognised on transfer of control.');
    if (landedCost > 0 && !hasStock) return setError('Landed cost can only be capitalised on stocked goods.');
    setError(null);
    const r = await desk.run({
      action: 'create_document', docType: kind, date, currency: order.currency, exchangeRate: order.exchangeRate,
      partyName: order.partyName, partyId: order.partyId || undefined, sourceDocumentId: order.id,
      data: { landedCost: kind === 'goods_receipt' ? landedCost : 0, landedCostMethod: landedMethod, warehouse, evidenceRef, notes }, lines,
    }, (res) => `${DOC_TYPE_LABEL[kind]} ${String(res.docNo)} drafted against ${order.docNo}. Submit & post it to update stock and the ledger.`);
    if (r.ok) onClose();
  };

  return (
    <Modal title={`${kind === 'goods_receipt' ? 'Receive goods against' : 'Deliver against'} ${order.docNo}`} sub={`${order.partyName} · ${order.currency} · ${kind === 'goods_receipt' ? 'Posting: Dr inventory / expense, Cr 204000 GRNI (nothing is payable until the supplier invoice is matched).' : 'Posting: Dr 504000 cost of sales / Cr inventory at carrying value, Dr 118100 unbilled revenue / Cr revenue (IFRS 15 control transfer).'}`} onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Field label={kind === 'goods_receipt' ? 'Receipt date' : 'Dispatch date'}><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} required /></Field>
          <Field label="Warehouse / location"><input value={warehouse} onChange={(e) => setWarehouse(e.target.value)} className={inputCls} /></Field>
          {kind === 'goods_receipt' ? (
            <>
              <Field label={`Inward freight / landed cost (${sym})`} hint="Capitalised into stock cost (IAS 2.11)."><input type="number" min="0" step="0.01" value={landedCost} disabled={!hasStock} onChange={(e) => setLandedCost(Number(e.target.value))} className={inputCls + ' font-mono'} /></Field>
              <Field label="Allocate landed cost by"><select value={landedMethod} onChange={(e) => setLandedMethod(e.target.value as 'value' | 'quantity')} className={inputCls}><option value="value">Line value</option><option value="quantity">Quantity</option></select></Field>
            </>
          ) : (
            <Field label="Delivery / acceptance evidence" className="col-span-2" hint="Waybill, signed delivery note or customer acceptance reference."><input value={evidenceRef} onChange={(e) => setEvidenceRef(e.target.value)} className={inputCls + ' font-mono'} required /></Field>
          )}
          <Field label="Notes" className="col-span-2 md:col-span-4"><input value={notes} onChange={(e) => setNotes(e.target.value)} className={inputCls} /></Field>
        </div>
        <div className="overflow-x-auto rounded border border-sky-200">
          <table className="w-full min-w-[760px] text-[11px]">
            <thead><tr className="bg-sky-50/70"><th className={thCls}>Line</th><th className={thCls}>Type</th><th className={thCls + ' text-right'}>Ordered</th><th className={thCls + ' text-right'}>Done</th><th className={thCls + ' text-right'}>In drafts</th><th className={thCls + ' text-right'}>Open</th><th className={thCls + ' text-right'}>{kind === 'goods_receipt' ? 'Receive now' : 'Deliver now'}</th><th className={thCls + ' text-right'}>Unit price</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.line.id} className="border-t border-sky-100">
                  <td className="px-2 py-1.5">{r.line.itemCode && <span className="font-mono font-bold text-[#855b00]">{r.line.itemCode} · </span>}{r.line.description}</td>
                  <td className="px-2 py-1.5">{r.line.itemType}</td>
                  <td className={numCls}>{fmtQty(r.line.quantity)} {r.line.uom}</td>
                  <td className={numCls}>{fmtQty(r.done)}</td>
                  <td className={numCls}>{fmtQty(r.pending)}</td>
                  <td className={numCls + ' font-bold'}>{fmtQty(r.remaining)}</td>
                  <td className="px-2 py-1.5 text-right"><input type="number" min="0" step="0.001" value={qty[r.line.id] ?? 0} onChange={(e) => setQty({ ...qty, [r.line.id]: Number(e.target.value) })} className={inputCls + ' w-24 text-right font-mono'} /></td>
                  <td className={numCls}>{sym}{fmtMoney(r.line.unitPrice)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <ErrorLine text={error} />
        <FormFooter onClose={onClose} busy={desk.busy} label={kind === 'goods_receipt' ? 'Create goods receipt' : 'Create delivery note'} />
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ *
 * Supplier invoice — three-way match (PO ↔ GRN ↔ invoice)
 * ------------------------------------------------------------------ */
interface MatchCandidate { key: string; sourceLineId: string; sourceDocNo: string; sourceDocId: string; description: string; itemCode: string | null; uom: string; open: number; unitPrice: number; taxRate: number; currency: string; exchangeRate: number; partyName: string; partyId: string | null; kind: 'receipt' | 'service order'; tolerance: number }

export function SupplierInvoiceForm({ desk, documents, source, currentClient, defaultTaxRate, onClose }: { desk: TradeDesk; documents: TradeDocument[]; source?: TradeDocument; currentClient: ClientEntity; defaultTaxRate: number; onClose: () => void }) {
  const candidates = useMemo<MatchCandidate[]>(() => {
    const byId = new Map(documents.map((d) => [d.id, d]));
    const lineById = new Map(documents.flatMap((d) => d.lines.map((l) => [l.id, { line: l, doc: d }] as const)));
    const out: MatchCandidate[] = [];
    for (const d of documents) {
      if (d.docType === 'goods_receipt' && d.postedAt) {
        for (const l of d.lines) {
          const open = money(l.quantity - fulfilledQuantity(documents, l.id, 'supplier_invoice') - pendingQuantity(documents, l.id, 'supplier_invoice'));
          if (open <= 0.0005) continue;
          const po = l.sourceLineId ? lineById.get(l.sourceLineId) : undefined;
          out.push({ key: l.id, sourceLineId: l.id, sourceDocNo: d.docNo, sourceDocId: d.id, description: l.description, itemCode: l.itemCode, uom: l.uom, open, unitPrice: l.quantity > 0 ? money(l.netAmount / l.quantity) : l.unitPrice, taxRate: po?.line.taxRate ?? defaultTaxRate, currency: d.currency, exchangeRate: d.exchangeRate, partyName: d.partyName, partyId: d.partyId, kind: 'receipt', tolerance: Number((po?.doc.data as Record<string, unknown> | undefined)?.priceTolerancePct ?? 5) });
        }
      }
      if (d.docType === 'purchase_order' && ['Approved', 'PartiallyReceived', 'Received'].includes(d.status)) {
        for (const l of d.lines) {
          if (l.itemType !== 'service') continue;
          const open = money(l.quantity - fulfilledQuantity(documents, l.id, 'goods_receipt') - pendingQuantity(documents, l.id, 'goods_receipt') - fulfilledQuantity(documents, l.id, 'supplier_invoice') - pendingQuantity(documents, l.id, 'supplier_invoice'));
          if (open <= 0.0005) continue;
          out.push({ key: l.id, sourceLineId: l.id, sourceDocNo: d.docNo, sourceDocId: d.id, description: l.description, itemCode: null, uom: l.uom, open, unitPrice: l.unitPrice, taxRate: l.taxRate, currency: d.currency, exchangeRate: d.exchangeRate, partyName: d.partyName, partyId: d.partyId, kind: 'service order', tolerance: Number((d.data as Record<string, unknown>).priceTolerancePct ?? 5) });
        }
      }
    }
    void byId;
    return out;
  }, [documents, defaultTaxRate]);
  const suppliers = [...new Set(candidates.map((c) => c.partyName))];
  const [supplier, setSupplier] = useState(source?.partyName || suppliers[0] || '');
  const mine = candidates.filter((c) => c.partyName === supplier);
  const [picked, setPicked] = useState<Record<string, { on: boolean; qty: number; price: number; tax: number }>>({});
  const [taxRegime, setTaxRegime] = useState<TaxRegime>({ ...DEFAULT_TAX_REGIME });
  const row = (c: MatchCandidate) => picked[c.key] || { on: !!source && c.sourceDocId === source.id, qty: c.open, price: c.unitPrice, tax: c.taxRate };
  const [externalRef, setExternalRef] = useState('');
  const [date, setDate] = useState(today());
  const [dueDate, setDueDate] = useState('');
  const [rateOverride, setRateOverride] = useState<number | null>(null);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const selected = mine.filter((c) => row(c).on);
  const currency = selected[0]?.currency || mine[0]?.currency || currentClient.currency;
  const functional = currency === currentClient.currency;
  const exchangeRate = functional ? 1 : (rateOverride ?? selected[0]?.exchangeRate ?? 1);
  const sym = symbolFor(currency);
  const net = money(selected.reduce((s, c) => s + row(c).qty * row(c).price, 0));
  const tax = money(selected.reduce((s, c) => s + money(row(c).qty * row(c).price) * row(c).tax / 100, 0));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!supplier) return setError('Select the supplier.');
    if (!externalRef.trim()) return setError("Enter the supplier's own invoice number — it is used for duplicate-invoice detection.");
    if (!selected.length) return setError('Tick at least one received or ordered service line to match.');
    if (selected.some((c) => c.currency !== currency)) return setError('All matched lines must share one currency — raise one invoice per currency.');
    for (const c of selected) {
      const r = row(c);
      if (!(r.qty > 0) || r.qty > c.open + 0.0005) return setError(`${c.description}: quantity must be between 0 and the unbilled ${fmtQty(c.open)}.`);
      if (r.price < 0) return setError(`${c.description}: price cannot be negative.`);
      const variance = c.unitPrice > 0 ? Math.abs(r.price - c.unitPrice) / c.unitPrice * 100 : 0;
      if (variance > c.tolerance + 0.009) return setError(`${c.description}: price variance ${variance.toFixed(2)}% exceeds the ${c.tolerance}% tolerance approved on the order. Agree a credit with the supplier or raise an authorised PO amendment.`);
    }
    setError(null);
    const r = await desk.run({
      action: 'create_document', docType: 'supplier_invoice', date, dueDate: dueDate || undefined, currency, exchangeRate,
      partyName: supplier, partyId: selected[0]?.partyId || undefined, externalRef: externalRef.trim(),
      tax: taxRegime,
      data: { notes, paymentTerms: '' },
      lines: selected.map((c) => ({ sourceLineId: c.sourceLineId, quantity: row(c).qty, unitPrice: row(c).price, taxRate: row(c).tax, taxCode: row(c).tax > 0 ? 'VAT' : 'none' })),
    }, (res) => `Supplier invoice ${String(res.docNo)} drafted and matched. Submit & post to recognise the payable.`);
    if (r.ok) onClose();
  };

  return (
    <Modal title="Record supplier invoice (three-way match)" sub="Every line must match a posted goods receipt or an approved service order; GRNI is cleared and any approved price variance is posted to 520000." onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Field label="Supplier" className="col-span-2">
            <select value={supplier} onChange={(e) => { setSupplier(e.target.value); setPicked({}); }} className={inputCls}>
              <option value="">Select supplier with unbilled receipts</option>
              {suppliers.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Supplier invoice no." hint="Duplicate numbers for the same supplier are rejected."><input value={externalRef} onChange={(e) => setExternalRef(e.target.value)} className={inputCls + ' font-mono'} required /></Field>
          <Field label="Invoice date"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} required /></Field>
          <Field label="Due date"><input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className={inputCls} /></Field>
          <Field label={`Currency / rate → ${currentClient.currency}`}><div className="flex gap-1"><input value={currency} disabled className={inputCls + ' w-16 font-mono'} /><input type="number" min="0" step="0.0001" value={exchangeRate} disabled={functional} onChange={(e) => setRateOverride(Number(e.target.value))} className={inputCls + ' font-mono'} /></div></Field>
          <Field label="Notes" className="col-span-2"><input value={notes} onChange={(e) => setNotes(e.target.value)} className={inputCls} /></Field>
        </div>
        <div className="overflow-x-auto rounded border border-sky-200">
          <table className="w-full min-w-[860px] text-[11px]">
            <thead><tr className="bg-sky-50/70"><th className={thCls}></th><th className={thCls}>Source</th><th className={thCls}>Line</th><th className={thCls + ' text-right'}>Unbilled</th><th className={thCls + ' text-right'}>Invoice qty</th><th className={thCls + ' text-right'}>Receipt price</th><th className={thCls + ' text-right'}>Invoice price</th><th className={thCls + ' text-right'}>Tax %</th><th className={thCls + ' text-right'}>Line total</th></tr></thead>
            <tbody>
              {mine.length === 0 && <tr><td colSpan={9} className="px-3 py-4 text-center text-[#355875]">No unbilled receipts or approved service orders for this supplier. Post a goods receipt first.</td></tr>}
              {mine.map((c) => { const r = row(c); const set = (patch: Partial<typeof r>) => setPicked({ ...picked, [c.key]: { ...r, ...patch } }); return (
                <tr key={c.key} className={`border-t border-sky-100 ${r.on ? 'bg-emerald-50/40' : ''}`}>
                  <td className="px-2 py-1.5"><input type="checkbox" checked={r.on} onChange={(e) => set({ on: e.target.checked })} /></td>
                  <td className="px-2 py-1.5 font-mono"><div className="font-bold text-[#855b00]">{c.sourceDocNo}</div><div className="text-[10px] text-[#355875]">{c.kind}</div></td>
                  <td className="px-2 py-1.5">{c.itemCode && <span className="font-mono font-bold">{c.itemCode} · </span>}{c.description}</td>
                  <td className={numCls}>{fmtQty(c.open)} {c.uom}</td>
                  <td className="px-2 py-1.5 text-right"><input type="number" min="0" step="0.001" value={r.qty} onChange={(e) => set({ qty: Number(e.target.value) })} className={inputCls + ' w-24 text-right font-mono'} /></td>
                  <td className={numCls}>{sym}{fmtMoney(c.unitPrice)}</td>
                  <td className="px-2 py-1.5 text-right"><input type="number" min="0" step="0.01" value={r.price} onChange={(e) => set({ price: Number(e.target.value) })} className={inputCls + ' w-28 text-right font-mono'} /></td>
                  <td className="px-2 py-1.5 text-right"><input type="number" min="0" max="100" step="0.5" value={r.tax} onChange={(e) => set({ tax: Number(e.target.value) })} className={inputCls + ' w-16 text-right font-mono'} /></td>
                  <td className={numCls + ' font-bold'}>{sym}{fmtMoney(money(r.qty * r.price) * (1 + r.tax / 100))}</td>
                </tr>
              ); })}
            </tbody>
          </table>
        </div>
        <TaxRegimePanel side="purchase" currency={currency} regime={taxRegime} onChange={setTaxRegime} netAmount={net} disabled={desk.busy} />
        <div className="flex justify-end gap-4 font-mono text-[11px]"><span>Net <strong>{sym}{fmtMoney(net)}</strong></span><span>Input tax <strong>{sym}{fmtMoney(tax)}</strong></span><span className="text-[#082f4f]">Payable <strong>{sym}{fmtMoney(net + tax)}</strong></span></div>
        <ErrorLine text={error} />
        <FormFooter onClose={onClose} busy={desk.busy} label="Save matched invoice draft" />
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ *
 * Sales invoice — from posted deliveries and/or evidenced services
 * ------------------------------------------------------------------ */
export function SalesInvoiceForm({ desk, documents, source, currentClient, partners, accounts, stockItems, defaultTaxRate, onClose }: {
  desk: TradeDesk; documents: TradeDocument[]; source?: TradeDocument; currentClient: ClientEntity; partners: BusinessPartner[]; accounts: AccountMaster[]; stockItems: StockItem[]; defaultTaxRate: number; onClose: () => void;
}) {
  const deliveries = useMemo(() => documents.filter((d) => d.docType === 'sales_delivery' && d.postedAt).flatMap((d) => d.lines.map((l) => ({ doc: d, line: l, open: money(l.quantity - fulfilledQuantity(documents, l.id, 'sales_invoice') - pendingQuantity(documents, l.id, 'sales_invoice')) })).filter((x) => x.open > 0.0005)), [documents]);
  const customers = [...new Set([...deliveries.map((x) => x.doc.partyName), ...partners.filter((p) => p.type === 'Customer').map((p) => p.name)])];
  const [customer, setCustomer] = useState(source?.partyName || customers[0] || '');
  const mine = deliveries.filter((x) => x.doc.partyName === customer);
  const [picked, setPicked] = useState<Record<string, { on: boolean; qty: number }>>({});
  const row = (x: typeof mine[number]) => picked[x.line.id] || { on: !!source && x.doc.id === source.id, qty: x.open };
  const [direct, setDirect] = useState<DraftLine[]>([]);
  const [salesTax, setSalesTax] = useState<TaxRegime>({ ...DEFAULT_TAX_REGIME });
  const [serviceEvidence, setServiceEvidence] = useState('');
  const [date, setDate] = useState(today());
  const [dueDate, setDueDate] = useState('');
  const [rateOverride, setRateOverride] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const selected = mine.filter((x) => row(x).on);
  const currency = selected[0]?.doc.currency || currentClient.currency;
  const functional = currency === currentClient.currency;
  const exchangeRate = functional ? 1 : (rateOverride ?? selected[0]?.doc.exchangeRate ?? 1);
  const sym = symbolFor(currency);
  const deliveredNet = money(selected.reduce((s, x) => s + (x.line.quantity > 0 ? x.line.netAmount / x.line.quantity : 0) * row(x).qty, 0));
  const deliveredTax = money(selected.reduce((s, x) => s + (x.line.quantity > 0 ? x.line.netAmount / x.line.quantity : 0) * row(x).qty * x.line.taxRate / 100, 0));
  const directTotals = draftTotals(direct);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!customer.trim()) return setError('Select the customer.');
    if (!selected.length && !direct.length) return setError('Tick a delivered line or add an evidenced service line.');
    if (selected.some((x) => x.doc.currency !== currency)) return setError('All invoiced deliveries must share one currency.');
    for (const x of selected) { const q = row(x).qty; if (!(q > 0) || q > x.open + 0.0005) return setError(`${x.line.description}: quantity must be between 0 and the unbilled ${fmtQty(x.open)}.`); }
    if (direct.length) {
      const v = validateDraftLines(direct, 'sales', stockItems);
      if (v) return setError(v);
      if (!serviceEvidence.trim()) return setError('Direct service lines need completion evidence (timesheet, sign-off, milestone certificate) before revenue is recognised.');
    }
    setError(null);
    const party = partners.find((p) => p.name === customer && p.type === 'Customer');
    const r = await desk.run({
      action: 'create_document', docType: 'sales_invoice', date, dueDate: dueDate || undefined, currency, exchangeRate,
      partyName: customer.trim(), partyId: selected[0]?.doc.partyId || (party ? String(party.id) : undefined),
      tax: salesTax,
      data: { serviceEvidence: serviceEvidence.trim(), paymentTerms: '' },
      lines: [
        ...selected.map((x) => ({ sourceLineId: x.line.id, quantity: row(x).qty })),
        ...toApiLines(direct, 'sales', stockItems).map((l) => ({ ...l, itemType: 'service', data: { serviceEvidence: serviceEvidence.trim() } })),
      ],
    }, (res) => `Sales invoice ${String(res.docNo)} drafted. Submit & post to raise the receivable and output tax.`);
    if (r.ok) onClose();
  };

  return (
    <Modal title="Issue sales invoice" sub="Goods are invoiced from posted deliveries (revenue was recognised on delivery; the invoice clears 118100 unbilled revenue). Services may be invoiced directly with completion evidence." onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Field label="Customer" className="col-span-2">
            <input list="o2c-customers" value={customer} onChange={(e) => { setCustomer(e.target.value); setPicked({}); }} className={inputCls} />
            <datalist id="o2c-customers">{customers.map((c) => <option key={c} value={c} />)}</datalist>
          </Field>
          <Field label="Invoice date"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} required /></Field>
          <Field label="Due date"><input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className={inputCls} /></Field>
          <Field label={`Currency / rate → ${currentClient.currency}`}><div className="flex gap-1"><input value={currency} disabled className={inputCls + ' w-16 font-mono'} /><input type="number" min="0" step="0.0001" value={exchangeRate} disabled={functional} onChange={(e) => setRateOverride(Number(e.target.value))} className={inputCls + ' font-mono'} /></div></Field>
        </div>
        <div>
          <div className={labelCls}>Delivered, not yet invoiced</div>
          <div className="overflow-x-auto rounded border border-sky-200">
            <table className="w-full min-w-[760px] text-[11px]">
              <thead><tr className="bg-sky-50/70"><th className={thCls}></th><th className={thCls}>Delivery</th><th className={thCls}>Line</th><th className={thCls + ' text-right'}>Unbilled</th><th className={thCls + ' text-right'}>Invoice qty</th><th className={thCls + ' text-right'}>Unit price</th><th className={thCls + ' text-right'}>Tax %</th></tr></thead>
              <tbody>
                {mine.length === 0 && <tr><td colSpan={7} className="px-3 py-3 text-center text-[#355875]">No unbilled deliveries for this customer.</td></tr>}
                {mine.map((x) => { const r = row(x); return (
                  <tr key={x.line.id} className={`border-t border-sky-100 ${r.on ? 'bg-emerald-50/40' : ''}`}>
                    <td className="px-2 py-1.5"><input type="checkbox" checked={r.on} onChange={(e) => setPicked({ ...picked, [x.line.id]: { ...r, on: e.target.checked } })} /></td>
                    <td className="px-2 py-1.5 font-mono font-bold text-[#855b00]">{x.doc.docNo}<div className="text-[10px] font-normal text-[#355875]">{x.doc.date}</div></td>
                    <td className="px-2 py-1.5">{x.line.itemCode && <span className="font-mono font-bold">{x.line.itemCode} · </span>}{x.line.description}</td>
                    <td className={numCls}>{fmtQty(x.open)} {x.line.uom}</td>
                    <td className="px-2 py-1.5 text-right"><input type="number" min="0" step="0.001" value={r.qty} onChange={(e) => setPicked({ ...picked, [x.line.id]: { ...r, qty: Number(e.target.value) } })} className={inputCls + ' w-24 text-right font-mono'} /></td>
                    <td className={numCls}>{sym}{fmtMoney(x.line.unitPrice)}</td>
                    <td className={numCls}>{x.line.taxRate}%</td>
                  </tr>
                ); })}
              </tbody>
            </table>
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between"><div className={labelCls}>Direct service lines (optional)</div>{direct.length === 0 && <button type="button" onClick={() => setDirect([newDraftLine({ itemType: 'service', taxRate: defaultTaxRate, costCenter: 'CC-SLS', revenueAccount: accounts.find((a) => a.type === 'Income' && a.active && a.accountNo === '400000')?.accountNo || '' })])} className={btnSecondary}>+ Add service line</button>}</div>
          {direct.length > 0 && (
            <>
              <LineEditor lines={direct} onChange={setDirect} mode="sales" stockItems={stockItems} accounts={accounts} currency={currency} allowedTypes={['service']} defaultTaxRate={defaultTaxRate} />
              <Field label="Service completion evidence" hint="Required: signed timesheet, acceptance certificate, milestone sign-off…"><input value={serviceEvidence} onChange={(e) => setServiceEvidence(e.target.value)} className={inputCls + ' font-mono'} /></Field>
            </>
          )}
        </div>
        <TaxRegimePanel side="sales" currency={currency} regime={salesTax} onChange={setSalesTax} netAmount={money(deliveredNet + directTotals.net)} disabled={desk.busy} />
        <div className="flex justify-end gap-4 font-mono text-[11px]"><span>Net <strong>{sym}{fmtMoney(deliveredNet + directTotals.net)}</strong></span><span>Output tax <strong>{sym}{fmtMoney(deliveredTax + directTotals.tax)}</strong></span><span className="text-[#082f4f]">Receivable <strong>{sym}{fmtMoney(deliveredNet + deliveredTax + directTotals.total)}</strong></span></div>
        <ErrorLine text={error} />
        <FormFooter onClose={onClose} busy={desk.busy} label="Save invoice draft" />
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ *
 * Credit / debit notes against a posted invoice
 * ------------------------------------------------------------------ */
export function NoteForm({ kind, invoice, desk, documents, accounts, stockItems, defaultTaxRate, onClose }: {
  kind: 'customer_credit_note' | 'customer_debit_note' | 'supplier_credit_note' | 'supplier_debit_note'; invoice: TradeDocument; desk: TradeDesk; documents: TradeDocument[];
  accounts: AccountMaster[]; stockItems: StockItem[]; defaultTaxRate: number; onClose: () => void;
}) {
  const [noteKind, setNoteKind] = useState(kind);
  const isCustomer = noteKind.startsWith('customer');
  const freeForm = noteKind === 'customer_debit_note';
  const priorNotes = documents.filter((d) => d.docType === noteKind && d.postedAt);
  const priorCredit = (lineId: string) => priorNotes.reduce((s, d) => s + d.lines.filter((l) => l.sourceLineId === lineId).reduce((a, l) => a + l.totalAmount, 0), 0);
  const priorQty = (lineId: string) => priorNotes.reduce((s, d) => s + d.lines.filter((l) => l.sourceLineId === lineId && l.data?.priceOnly !== true).reduce((a, l) => a + l.quantity, 0), 0);
  const [rows, setRows] = useState<Record<string, { on: boolean; mode: 'return' | 'price'; qty: number; amount: number; restock: boolean; condition: 'saleable' | 'damaged' }>>({});
  const row = (lineId: string, maxQty: number) => rows[lineId] || { on: false, mode: 'return' as const, qty: maxQty, amount: 0, restock: true, condition: 'saleable' as const };
  const [direct, setDirect] = useState<DraftLine[]>(() => [newDraftLine({ itemType: 'service', taxRate: defaultTaxRate, costCenter: 'CC-SLS', revenueAccount: accounts.find((a) => a.type === 'Income' && a.active && a.accountNo === '400000')?.accountNo || '' })]);
  const [date, setDate] = useState(today());
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const sym = symbolFor(invoice.currency);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return setError('A reason is required — it is written to the audit trail with the note.');
    let lines: Record<string, unknown>[] = [];
    if (freeForm) {
      const v = validateDraftLines(direct, 'sales', stockItems);
      if (v) return setError(v);
      lines = toApiLines(direct, 'sales', stockItems);
    } else {
      for (const l of invoice.lines) {
        const maxQty = money(l.quantity - priorQty(l.id));
        const r = row(l.id, maxQty);
        if (!r.on) continue;
        if (r.mode === 'return') {
          if (!(r.qty > 0) || r.qty > maxQty + 0.0005) return setError(`${l.description}: return quantity must be between 0 and ${fmtQty(maxQty)}.`);
          lines.push({ sourceLineId: l.id, quantity: r.qty, data: { priceOnly: false, restock: isCustomer && l.itemType === 'stock' ? r.restock : false, returnCondition: r.condition } });
        } else {
          const headroom = money(l.totalAmount - priorCredit(l.id));
          if (!(r.amount > 0) || money(r.amount * (1 + l.taxRate / 100)) > headroom + 0.009) return setError(`${l.description}: price credit (plus tax) must be between 0 and ${fmtMoney(headroom)}.`);
          lines.push({ sourceLineId: l.id, quantity: 0, creditAmount: r.amount, data: { priceOnly: true } });
        }
      }
      if (!lines.length) return setError('Tick at least one invoice line.');
    }
    setError(null);
    const r = await desk.run({
      action: 'create_document', docType: noteKind, date, currency: invoice.currency, exchangeRate: invoice.exchangeRate,
      partyName: invoice.partyName, partyId: invoice.partyId || undefined, sourceRef: invoice.docNo, sourceDocumentId: invoice.id, reason: reason.trim(),
      data: { notes: reason.trim() }, lines,
    }, (res) => `${DOC_TYPE_LABEL[noteKind]} ${String(res.docNo)} drafted against ${invoice.docNo}. Submit & post to apply it.`);
    if (r.ok) onClose();
  };

  return (
    <Modal title={`${DOC_TYPE_LABEL[noteKind]} against ${invoice.docNo}`} sub={`${invoice.partyName} · ${invoice.currency} · original total ${fmtMoney(invoice.totalAmount)} · the original invoice is never edited; the note is linked and auto-applied to its open balance.`} onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Field label="Note type" className="col-span-2">
            <select value={noteKind} onChange={(e) => setNoteKind(e.target.value as typeof kind)} className={inputCls}>
              {isCustomer ? (<><option value="customer_credit_note">Credit note — return / price reduction (reduces receivable)</option><option value="customer_debit_note">Debit note — additional charge (increases receivable)</option></>)
                : (<><option value="supplier_debit_note">Debit note to supplier — purchase return / price reduction (reduces payable)</option><option value="supplier_credit_note">Supplier credit note received (reduces payable)</option></>)}
            </select>
          </Field>
          <Field label="Date"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} required /></Field>
          <Field label="Reason (audit trail)"><input value={reason} onChange={(e) => setReason(e.target.value)} className={inputCls} required /></Field>
        </div>
        {freeForm ? (
          <LineEditor lines={direct} onChange={setDirect} mode="sales" stockItems={stockItems} accounts={accounts} currency={invoice.currency} allowedTypes={['service', 'office']} defaultTaxRate={defaultTaxRate} />
        ) : (
          <div className="overflow-x-auto rounded border border-sky-200">
            <table className="w-full min-w-[860px] text-[11px]">
              <thead><tr className="bg-sky-50/70"><th className={thCls}></th><th className={thCls}>Invoice line</th><th className={thCls + ' text-right'}>Invoiced</th><th className={thCls + ' text-right'}>Already credited</th><th className={thCls}>Basis</th><th className={thCls + ' text-right'}>Return qty / net credit</th><th className={thCls}>Stock</th></tr></thead>
              <tbody>
                {invoice.lines.map((l) => { const maxQty = money(l.quantity - priorQty(l.id)); const r = row(l.id, maxQty); const set = (patch: Partial<typeof r>) => setRows({ ...rows, [l.id]: { ...r, ...patch } }); return (
                  <tr key={l.id} className={`border-t border-sky-100 ${r.on ? 'bg-amber-50/40' : ''}`}>
                    <td className="px-2 py-1.5"><input type="checkbox" checked={r.on} onChange={(e) => set({ on: e.target.checked })} /></td>
                    <td className="px-2 py-1.5">{l.itemCode && <span className="font-mono font-bold">{l.itemCode} · </span>}{l.description}<div className="text-[10px] text-[#355875]">{sym}{fmtMoney(l.unitPrice)} × {fmtQty(l.quantity)} · tax {l.taxRate}%</div></td>
                    <td className={numCls}>{fmtMoney(l.totalAmount)}</td>
                    <td className={numCls}>{fmtMoney(priorCredit(l.id))}</td>
                    <td className="px-2 py-1.5"><select value={r.mode} onChange={(e) => set({ mode: e.target.value as 'return' | 'price' })} className={inputCls}><option value="return">Quantity returned</option><option value="price">Price-only credit</option></select></td>
                    <td className="px-2 py-1.5 text-right">{r.mode === 'return' ? <input type="number" min="0" max={maxQty} step="0.001" value={r.qty} onChange={(e) => set({ qty: Number(e.target.value) })} className={inputCls + ' w-24 text-right font-mono'} /> : <input type="number" min="0" step="0.01" value={r.amount} onChange={(e) => set({ amount: Number(e.target.value) })} className={inputCls + ' w-28 text-right font-mono'} />}</td>
                    <td className="px-2 py-1.5">{l.itemType === 'stock' && r.mode === 'return' ? (isCustomer ? <div className="space-y-1"><label className="flex items-center gap-1"><input type="checkbox" checked={r.restock} onChange={(e) => set({ restock: e.target.checked })} /> restock</label><select value={r.condition} onChange={(e) => set({ condition: e.target.value as 'saleable' | 'damaged' })} className={inputCls}><option value="saleable">saleable</option><option value="damaged">damaged / scrap</option></select></div> : <span className="text-[10px] text-[#355875]">Stock issued back to supplier at carrying value</span>) : <span className="text-[10px] text-[#355875]">—</span>}</td>
                  </tr>
                ); })}
              </tbody>
            </table>
          </div>
        )}
        <ErrorLine text={error} />
        <FormFooter onClose={onClose} busy={desk.busy} label="Save note draft" />
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ *
 * Payments: supplier payment / customer receipt / customer advance
 * ------------------------------------------------------------------ */
export function PaymentForm({ kind, desk, documents, partners, currentClient, currentUser, invoice, onClose }: {
  kind: 'supplier_payment' | 'customer_receipt' | 'customer_advance'; desk: TradeDesk; documents: TradeDocument[]; partners: BusinessPartner[];
  currentClient: ClientEntity; currentUser: UserAccount; invoice?: TradeDocument; onClose: () => void;
}) {
  const supplierSide = kind === 'supplier_payment';
  const targetType = supplierSide ? 'supplier_invoice' : 'sales_invoice';
  const banks = desk.state?.bankAccounts || [];
  const openAll = documents.filter((d) => d.docType === targetType && ['Open', 'PartiallySettled'].includes(d.status));
  const parties = [...new Set([...openAll.map((d) => d.partyName), ...partners.filter((p) => p.type === (supplierSide ? 'Vendor' : 'Customer')).map((p) => p.name)])];
  const [party, setParty] = useState(invoice?.partyName || parties[0] || '');
  const preferredCcy = invoice?.currency || currentClient.currency;
  const [bankId, setBankId] = useState<number>(() => (banks.find((b) => b.currency === preferredCcy) || banks[0])?.id || 0);
  const bank = banks.find((b) => b.id === bankId);
  const currency = bank?.currency || currentClient.currency;
  const functional = currency === currentClient.currency;
  const open = openAll.filter((d) => d.partyName === party && d.currency === currency).sort((a, b) => a.date.localeCompare(b.date));
  const [alloc, setAlloc] = useState<Record<string, number>>(() => (invoice && invoice.openBalance ? { [invoice.id]: invoice.openBalance } : {}));
  const allocated = money(Object.values(alloc).reduce((s, n) => s + (n || 0), 0));
  const [amount, setAmount] = useState<number>(() => (invoice?.openBalance ?? 0));
  const [withheld, setWithheld] = useState(0);
  const [method, setMethod] = useState('bank_transfer');
  const [reference, setReference] = useState('');
  const [date, setDate] = useState(today());
  const [exchangeRate, setExchangeRate] = useState(1);
  const [error, setError] = useState<string | null>(null);
  const sym = symbolFor(currency);
  const cash = money(amount - withheld);
  const functionalAmount = money(amount * (functional ? 1 : exchangeRate));
  const aboveLimit = currentUser.role !== 'owner' && (currentUser.makerLimit <= 0 || functionalAmount > currentUser.makerLimit + 0.009);

  const autoApply = () => {
    let left = amount;
    const next: Record<string, number> = {};
    for (const d of open) { const take = money(Math.min(left, d.openBalance || 0)); if (take > 0) { next[d.id] = take; left = money(left - take); } }
    setAlloc(next);
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!party.trim()) return setError(supplierSide ? 'Select the supplier.' : 'Select the customer.');
    if (!bank) return setError('Choose the bank / cash account.');
    if (!(amount > 0)) return setError('Enter a positive gross amount.');
    if (withheld < 0 || withheld > amount) return setError('Withholding cannot exceed the gross amount.');
    if (!functional && !(exchangeRate > 0)) return setError(`Enter the ${currency} → ${currentClient.currency} rate.`);
    for (const d of open) { const a = alloc[d.id] || 0; if (a < 0 || a > (d.openBalance || 0) + 0.009) return setError(`Allocation to ${d.docNo} exceeds its open balance of ${fmtMoney(d.openBalance || 0)}.`); }
    if (allocated > amount + 0.009) return setError(`Allocations (${fmtMoney(allocated)}) exceed the payment amount.`);
    if (kind === 'customer_advance' && allocated > 0) return setError('A customer advance is held as a contract liability — do not allocate it here; apply it later from the payments list.');
    if (!supplierSide && withheld > 0 && allocated + 0.009 < amount) return setError('Customer withholding tax must be recorded against identified invoices — allocate the full receipt.');
    if (supplierSide && bank.balance + 0.009 < cash) return setError(`Insufficient funds: ${bank.name} holds ${sym}${fmtMoney(bank.balance)} but ${sym}${fmtMoney(cash)} is needed.`);
    if (aboveLimit) return setError(`This payment (${currentClient.currency} ${fmtMoney(functionalAmount)}) exceeds your maker limit of ${fmtMoney(currentUser.makerLimit)}. The server will refuse it — ask a user with checker authority and a sufficient limit to post it.`);
    setError(null);
    const partner = partners.find((p) => p.name === party);
    const r = await desk.run({
      action: 'create_payment', paymentType: kind, partyName: party.trim(), partyId: partner ? String(partner.id) : undefined,
      amount, withheldAmount: withheld, date, currency, exchangeRate: functional ? 1 : exchangeRate, bankAccountId: bank.id, method, reference: reference.trim() || undefined,
      allocations: Object.entries(alloc).filter(([, a]) => a > 0).map(([documentId, a]) => ({ documentId, amount: a })),
    }, (res) => `${supplierSide ? 'Payment' : 'Receipt'} ${String(res.paymentNo)} posted (journal ${String(res.journalNo)}) · applied ${fmtMoney(Number(res.allocated))}${Number(res.unallocated) > 0 ? ` · unapplied ${fmtMoney(Number(res.unallocated))}` : ''}.`);
    if (r.ok) onClose();
  };

  return (
    <Modal title={supplierSide ? 'Pay supplier (open-item settlement)' : kind === 'customer_advance' ? 'Record customer advance' : 'Record customer receipt'} sub={supplierSide ? 'Dr 200000 trade payables (per invoice) / Cr bank; income WHT withheld is credited to 209000. Unapplied amounts become a supplier advance (116000).' : 'Dr bank / Cr 110000 receivables (per invoice); customer VAT/income withholding is debited to 115000. Unapplied cash is a contract liability (225000).'} onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Field label={supplierSide ? 'Supplier' : 'Customer'} className="col-span-2">
            <input list="pay-parties" value={party} onChange={(e) => { setParty(e.target.value); setAlloc({}); }} className={inputCls} />
            <datalist id="pay-parties">{parties.map((p) => <option key={p} value={p} />)}</datalist>
          </Field>
          <Field label="Bank / cash account">
            <select value={bankId} onChange={(e) => { setBankId(Number(e.target.value)); setAlloc({}); }} className={inputCls}>
              {banks.length === 0 && <option value={0}>No treasury account — add one in Banking</option>}
              {banks.map((b) => <option key={b.id} value={b.id}>{b.name} · {b.currency} {fmtMoney(b.balance)}</option>)}
            </select>
          </Field>
          <Field label="Date"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} required /></Field>
          <Field label={`Gross amount (${currency})`}><input type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(Number(e.target.value))} className={inputCls + ' font-mono font-bold'} required /></Field>
          <Field label={supplierSide ? 'Income WHT withheld' : 'Withheld by customer'} hint={supplierSide ? 'Credited to 209000 WHT payable' : 'Debited to 115000 WHT receivable'}><input type="number" min="0" step="0.01" value={withheld} onChange={(e) => setWithheld(Number(e.target.value))} className={inputCls + ' font-mono'} /></Field>
          <Field label="Method"><select value={method} onChange={(e) => setMethod(e.target.value)} className={inputCls}><option value="bank_transfer">Bank transfer</option><option value="cheque">Cheque</option><option value="cash">Cash</option><option value="mobile_money">Mobile money</option></select></Field>
          <Field label="Reference"><input value={reference} onChange={(e) => setReference(e.target.value)} className={inputCls + ' font-mono'} /></Field>
          {!functional && <Field label={`Rate → ${currentClient.currency}`}><input type="number" min="0" step="0.0001" value={exchangeRate} onChange={(e) => setExchangeRate(Number(e.target.value))} className={inputCls + ' font-mono'} /></Field>}
        </div>
        <div className="rounded border border-sky-200 bg-sky-50/50 px-3 py-2 text-[11px] font-mono flex flex-wrap gap-4">
          <span>Cash movement <strong>{sym}{fmtMoney(cash)}</strong></span>
          <span>Applied <strong>{sym}{fmtMoney(allocated)}</strong></span>
          <span className={amount - allocated > 0.009 ? 'text-amber-800' : ''}>Unapplied <strong>{sym}{fmtMoney(Math.max(0, amount - allocated))}</strong></span>
          {bank && <span>Account balance after <strong>{sym}{fmtMoney(supplierSide ? bank.balance - cash : bank.balance + cash)}</strong></span>}
          {aboveLimit && <span className="text-rose-800 font-bold">Above your maker limit</span>}
        </div>
        {kind !== 'customer_advance' && (
          <div>
            <div className="flex items-center justify-between"><div className={labelCls}>Open {supplierSide ? 'supplier invoices' : 'customer invoices'} in {currency}</div><button type="button" onClick={autoApply} className={btnSecondary}>Auto-apply oldest first</button></div>
            <div className="overflow-x-auto rounded border border-sky-200">
              <table className="w-full min-w-[640px] text-[11px]">
                <thead><tr className="bg-sky-50/70"><th className={thCls}>Invoice</th><th className={thCls}>Date / due</th><th className={thCls}>Ref</th><th className={thCls + ' text-right'}>Total</th><th className={thCls + ' text-right'}>Open</th><th className={thCls + ' text-right'}>Apply</th></tr></thead>
                <tbody>
                  {open.length === 0 && <tr><td colSpan={6} className="px-3 py-3 text-center text-[#355875]">No open items for this party in {currency}. The full amount will be held as {supplierSide ? 'a supplier advance' : 'an unapplied customer advance'}.</td></tr>}
                  {open.map((d) => (
                    <tr key={d.id} className="border-t border-sky-100">
                      <td className="px-2 py-1.5 font-mono font-bold text-[#855b00]">{d.docNo}</td>
                      <td className="px-2 py-1.5 font-mono">{d.date}{d.dueDate ? ` / ${d.dueDate}` : ''}</td>
                      <td className="px-2 py-1.5 font-mono">{d.externalRef || '—'}</td>
                      <td className={numCls}>{fmtMoney(d.totalAmount)}</td>
                      <td className={numCls + ' font-bold'}>{fmtMoney(d.openBalance || 0)}</td>
                      <td className="px-2 py-1.5 text-right"><input type="number" min="0" step="0.01" value={alloc[d.id] ?? 0} onChange={(e) => setAlloc({ ...alloc, [d.id]: Number(e.target.value) })} className={inputCls + ' w-28 text-right font-mono'} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        <ErrorLine text={error} />
        <FormFooter onClose={onClose} busy={desk.busy} label={supplierSide ? 'Post payment' : 'Post receipt'} />
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ *
 * Apply an unallocated payment or an open credit note to open invoices
 * ------------------------------------------------------------------ */
export function AllocateForm({ source, desk, documents, onClose }: { source: { kind: 'payment'; payment: TradePayment } | { kind: 'credit'; doc: TradeDocument }; desk: TradeDesk; documents: TradeDocument[]; onClose: () => void }) {
  const party = source.kind === 'payment' ? source.payment.partyName : source.doc.partyName;
  const currency = source.kind === 'payment' ? source.payment.currency : source.doc.currency;
  const supplierSide = source.kind === 'payment' ? source.payment.paymentType === 'supplier_payment' : source.doc.docType.startsWith('supplier');
  const available = source.kind === 'payment' ? source.payment.unallocated : (source.doc.openBalance || 0);
  const label = source.kind === 'payment' ? source.payment.paymentNo : source.doc.docNo;
  const open = documents.filter((d) => d.docType === (supplierSide ? 'supplier_invoice' : 'sales_invoice') && ['Open', 'PartiallySettled'].includes(d.status) && d.partyName === party && d.currency === currency).sort((a, b) => a.date.localeCompare(b.date));
  const [alloc, setAlloc] = useState<Record<string, number>>({});
  const [date, setDate] = useState(today());
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const total = money(Object.values(alloc).reduce((s, n) => s + (n || 0), 0));
  const autoApply = () => { let left = available; const next: Record<string, number> = {}; for (const d of open) { const take = money(Math.min(left, d.openBalance || 0)); if (take > 0) { next[d.id] = take; left = money(left - take); } } setAlloc(next); };
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (total <= 0) return setError('Enter at least one allocation.');
    if (total > available + 0.009) return setError(`Allocations (${fmtMoney(total)}) exceed the available ${fmtMoney(available)}.`);
    for (const d of open) if ((alloc[d.id] || 0) > (d.openBalance || 0) + 0.009) return setError(`Allocation to ${d.docNo} exceeds its open balance.`);
    setError(null);
    const r = await desk.run({
      action: 'allocate_source', sourceType: source.kind === 'payment' ? 'payment' : supplierSide ? 'supplier_credit_note' : 'customer_credit_note',
      sourceId: source.kind === 'payment' ? source.payment.id : source.doc.id, date, reason: reason.trim() || 'Open-item allocation.',
      allocations: Object.entries(alloc).filter(([, a]) => a > 0).map(([documentId, a]) => ({ documentId, amount: a })),
    }, (res) => `${label}: ${fmtMoney(Number(res.allocated))} applied · ${fmtMoney(Number(res.availableAfter))} still unapplied.`);
    if (r.ok) onClose();
  };
  return (
    <Modal title={`Apply ${label} to open invoices`} sub={`${party} · ${currency} ${fmtMoney(available)} available${source.kind === 'payment' ? ' · releasing an advance posts the matching ledger transfer' : ''}.`} onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <div className="grid grid-cols-2 gap-3"><Field label="Allocation date"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} /></Field><Field label="Reason"><input value={reason} onChange={(e) => setReason(e.target.value)} className={inputCls} /></Field></div>
        <div className="flex items-center justify-between"><div className={labelCls}>Open items</div><button type="button" onClick={autoApply} className={btnSecondary}>Auto-apply oldest first</button></div>
        <div className="overflow-x-auto rounded border border-sky-200">
          <table className="w-full text-[11px]">
            <thead><tr className="bg-sky-50/70"><th className={thCls}>Invoice</th><th className={thCls}>Date</th><th className={thCls + ' text-right'}>Open</th><th className={thCls + ' text-right'}>Apply</th></tr></thead>
            <tbody>
              {open.length === 0 && <tr><td colSpan={4} className="px-3 py-3 text-center text-[#355875]">No open invoices for {party} in {currency}.</td></tr>}
              {open.map((d) => <tr key={d.id} className="border-t border-sky-100"><td className="px-2 py-1.5 font-mono font-bold text-[#855b00]">{d.docNo}</td><td className="px-2 py-1.5 font-mono">{d.date}</td><td className={numCls}>{fmtMoney(d.openBalance || 0)}</td><td className="px-2 py-1.5 text-right"><input type="number" min="0" step="0.01" value={alloc[d.id] ?? 0} onChange={(e) => setAlloc({ ...alloc, [d.id]: Number(e.target.value) })} className={inputCls + ' w-28 text-right font-mono'} /></td></tr>)}
            </tbody>
          </table>
        </div>
        <div className="text-right font-mono text-[11px]">Applying <strong>{fmtMoney(total)}</strong> of {fmtMoney(available)}</div>
        <ErrorLine text={error} />
        <FormFooter onClose={onClose} busy={desk.busy} label="Apply allocation" />
      </form>
    </Modal>
  );
}
