/**
 * Firm-wide cost centre registry.
 *
 * Every posting (payroll, procurement, adjustments, expenses) carries a cost
 * centre so management accounts can be analysed by responsibility centre.
 */
export interface CostCentre {
  code: string;
  name: string;
  /** Default natural owner — used to pre-select a sensible centre on forms. */
  group: 'Operations' | 'Support' | 'Commercial' | 'Executive';
}

export const COST_CENTRES: CostCentre[] = [
  { code: 'CC-ADM', name: 'Administration & Head Office', group: 'Support' },
  { code: 'CC-FIN', name: 'Finance & Accounts', group: 'Support' },
  { code: 'CC-HR', name: 'Human Resources & Payroll', group: 'Support' },
  { code: 'CC-IT', name: 'Information Technology', group: 'Support' },
  { code: 'CC-OPS', name: 'Operations / Production', group: 'Operations' },
  { code: 'CC-ENG', name: 'Plant, Engineering & Maintenance', group: 'Operations' },
  { code: 'CC-LOG', name: 'Logistics, Transport & Fleet', group: 'Operations' },
  { code: 'CC-PRJ', name: 'Projects & Contracts', group: 'Operations' },
  { code: 'CC-SLS', name: 'Sales & Marketing', group: 'Commercial' },
  { code: 'CC-PRC', name: 'Procurement & Stores', group: 'Commercial' },
  { code: 'CC-EXE', name: 'Executive / Board', group: 'Executive' },
];

export const COST_CENTRE_CODES = COST_CENTRES.map((c) => c.code);

export function costCentreName(code?: string): string {
  if (!code) return 'Unassigned';
  return COST_CENTRES.find((c) => c.code === code)?.name || code;
}

/** Maps a payroll department to its default cost centre (used as a form default). */
export const DEPARTMENT_DEFAULT_COST_CENTRE: Record<string, string> = {
  Operations: 'CC-OPS',
  Finance: 'CC-FIN',
  Logistics: 'CC-LOG',
  Engineering: 'CC-ENG',
  Executive: 'CC-EXE',
  Sales: 'CC-SLS',
  Procurement: 'CC-PRC',
  IT: 'CC-IT',
  HR: 'CC-HR',
};

export function defaultCostCentreForDepartment(department: string): string {
  return DEPARTMENT_DEFAULT_COST_CENTRE[department] || 'CC-ADM';
}
