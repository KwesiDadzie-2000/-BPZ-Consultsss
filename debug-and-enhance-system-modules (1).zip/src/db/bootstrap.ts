import { sql } from "drizzle-orm";
import { db } from "@/db";
import { SCHEMA_DDL } from "@/db/ddl";
import { TRADE_SCHEMA_DDL } from "@/db/tradeDdl";
import { TRADE_PERF_DDL } from "@/db/tradePerfDdl";
import { seedInto } from "@/db/seedData";

/**
 * Database self-provisioning.
 *
 * ROOT CAUSE of the original "Login failed." screen: the app only worked after a
 * human ran `drizzle-kit push` AND `tsx src/db/seed.ts`. On a fresh database the
 * login route threw `relation "users" does not exist` (HTTP 500 → "Login
 * failed."), and with an empty `users` table every credential was rejected.
 *
 * `ensureDatabaseReady()` now runs before any auth/state route touches the
 * database:
 *   1. creates any missing tables/indexes (idempotent DDL from the schema),
 *   2. seeds the demonstration workspace once, only if no user exists yet.
 * Both steps run under a transaction-scoped advisory lock so concurrent cold
 * requests (or several server instances) cannot double-seed.
 */
const LOCK_KEY = 4_027_331;

/** Creates any missing tables/indexes. Safe to run any number of times. */
export async function ensureSchema(): Promise<void> {
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(${LOCK_KEY})`);
    for (const statement of [...SCHEMA_DDL, ...TRADE_SCHEMA_DDL, ...TRADE_PERF_DDL]) await tx.execute(sql.raw(statement));
  });
}

/**
 * Lock → DDL → "any users?" → seed, all inside ONE transaction. The advisory
 * lock is held until commit, so a second instance waits and then sees the seeded
 * users; a failure rolls everything back and the next request retries.
 */
async function provision(): Promise<void> {
  const seeded = await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(${LOCK_KEY})`);
    for (const statement of [...SCHEMA_DDL, ...TRADE_SCHEMA_DDL, ...TRADE_PERF_DDL]) await tx.execute(sql.raw(statement));
    const result = await tx.execute<{ n: number }>(sql`select count(*)::int as n from users`);
    if (Number(result.rows[0]?.n ?? 0) > 0) return false;
    await seedInto(tx);
    return true;
  });
  if (seeded) console.log("[bpz] Fresh database provisioned with the demonstration workspace.");
}

const globalForBootstrap = globalThis as typeof globalThis & { __bpzReady?: Promise<void> };

export function ensureDatabaseReady(): Promise<void> {
  if (!globalForBootstrap.__bpzReady) {
    globalForBootstrap.__bpzReady = provision().catch((error) => {
      // Do not cache failures — the next request retries (e.g. DB was briefly down).
      globalForBootstrap.__bpzReady = undefined;
      throw error;
    });
  }
  return globalForBootstrap.__bpzReady;
}
