import "dotenv/config";
import { ensureSchema } from "@/db/bootstrap";
import { seedDemoData } from "@/db/seedData";

/**
 * CLI: `npx tsx src/db/seed.ts` — creates any missing tables, then wipes and
 * reloads the demonstration dataset. The running app performs the same
 * provisioning automatically on first use (see src/db/bootstrap.ts).
 */
async function main() {
  await ensureSchema();
  await seedDemoData();
  console.log("BPZ Consult demo data loaded.");
}

main().then(() => process.exit(0)).catch((e) => {
  console.error(e);
  process.exit(1);
});
