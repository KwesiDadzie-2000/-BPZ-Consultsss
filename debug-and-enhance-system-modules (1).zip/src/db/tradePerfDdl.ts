/**
 * Query (non-unique) indexes for the trading subledger.
 *
 * ROOT CAUSE of the slow procure-to-pay / order-to-cash desks: the generated DDL
 * in `tradeDdl.ts` only carried the UNIQUE constraints. Every workspace read
 * (`GET /api/trade`) therefore fell back to a sequential scan of
 * `trade_documents`, `trade_document_lines`, `trade_document_links`,
 * `trade_allocations`, `trade_cash_movements` and `trade_audit_events` — once
 * per desk open, and again after every posting.
 *
 * These statements are additive and idempotent: they create only indexes, never
 * alter a table, so the original schema is untouched.
 */
export const TRADE_PERF_DDL: string[] = [
  // Desk-scoped document lists: client + family (+ newest first).
  `CREATE INDEX IF NOT EXISTS "trade_documents_client_type_date_idx" ON "trade_documents" USING btree ("client_id","doc_type","date" DESC)`,
  `CREATE INDEX IF NOT EXISTS "trade_documents_client_status_idx" ON "trade_documents" USING btree ("client_id","status")`,
  // Line / link fan-out for the loaded documents.
  `CREATE INDEX IF NOT EXISTS "trade_document_lines_doc_idx" ON "trade_document_lines" USING btree ("client_id","document_id")`,
  `CREATE INDEX IF NOT EXISTS "trade_document_lines_source_idx" ON "trade_document_lines" USING btree ("client_id","source_line_id")`,
  `CREATE INDEX IF NOT EXISTS "trade_document_links_from_idx" ON "trade_document_links" USING btree ("client_id","from_document_id")`,
  `CREATE INDEX IF NOT EXISTS "trade_document_links_to_idx" ON "trade_document_links" USING btree ("client_id","to_document_id")`,
  // Open-item settlement maths (open balance per invoice, unapplied per payment).
  `CREATE INDEX IF NOT EXISTS "trade_allocations_target_idx" ON "trade_allocations" USING btree ("client_id","target_document_id")`,
  `CREATE INDEX IF NOT EXISTS "trade_allocations_source_idx" ON "trade_allocations" USING btree ("client_id","source_id")`,
  `CREATE INDEX IF NOT EXISTS "trade_allocations_open_idx" ON "trade_allocations" USING btree ("client_id") WHERE "reversed_at" IS NULL`,
  // Payment desk: payments by family and by party.
  `CREATE INDEX IF NOT EXISTS "trade_payments_client_type_idx" ON "trade_payments" USING btree ("client_id","payment_type","date" DESC)`,
  `CREATE INDEX IF NOT EXISTS "trade_payments_client_party_idx" ON "trade_payments" USING btree ("client_id","party_name")`,
  // Cashbook aggregation.
  `CREATE INDEX IF NOT EXISTS "trade_cash_movements_bank_idx" ON "trade_cash_movements" USING btree ("client_id","bank_account_id")`,
  // Newest-first audit tail (the workspace now reads a capped window).
  `CREATE INDEX IF NOT EXISTS "trade_audit_events_client_time_idx" ON "trade_audit_events" USING btree ("client_id","occurred_at" DESC)`,
  `CREATE INDEX IF NOT EXISTS "trade_audit_events_record_idx" ON "trade_audit_events" USING btree ("client_id","record_type","record_id")`,
  // Inventory lots (FIFO release) and reservations (sales-order commitment).
  `CREATE INDEX IF NOT EXISTS "trade_inventory_lots_item_idx" ON "trade_inventory_lots" USING btree ("client_id","item_code","receipt_date")`,
  `CREATE INDEX IF NOT EXISTS "trade_inventory_reservations_doc_idx" ON "trade_inventory_reservations" USING btree ("client_id","document_id")`,
  `CREATE INDEX IF NOT EXISTS "trade_inventory_reservations_item_idx" ON "trade_inventory_reservations" USING btree ("client_id","item_code") WHERE "status" = 'active'`,
  // Integration desks.
  `CREATE INDEX IF NOT EXISTS "trade_outbox_pending_idx" ON "trade_outbox" USING btree ("client_id","status","next_attempt_at")`,
  `CREATE INDEX IF NOT EXISTS "trade_bank_statements_account_idx" ON "trade_bank_statements" USING btree ("client_id","bank_account_id","statement_date")`,
  // Core ledger reads used by every desk that renders a trial balance.
  `CREATE INDEX IF NOT EXISTS "journal_lines_client_account_idx" ON "journal_lines" USING btree ("client_id","account_no")`,
  `CREATE INDEX IF NOT EXISTS "journal_lines_client_doc_idx" ON "journal_lines" USING btree ("client_id","doc_no")`,
];
