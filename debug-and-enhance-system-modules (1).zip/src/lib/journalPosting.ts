import { createHash } from "node:crypto";
import type { ACDOCALine } from "@/types/accounting";
import { journalLinesFingerprint } from "@/lib/journalValidation";

export function journalContentHash(lines: readonly ACDOCALine[]): string {
  return createHash("sha256").update(journalLinesFingerprint(lines)).digest("hex");
}

export function journalHeaderId(clientId: number, docNo: string): string {
  return `JH:${clientId}:${encodeURIComponent(docNo)}`;
}

export function buildJournalHeader(lines: readonly ACDOCALine[], postedAt = new Date()) {
  if (!lines.length) throw new Error("A journal header requires at least one line.");
  const first = lines[0];
  const debitCents = lines.reduce((total, line) => total + Math.round(line.debit * 100), 0);
  const creditCents = lines.reduce((total, line) => total + Math.round(line.credit * 100), 0);
  return {
    id: journalHeaderId(first.clientId, first.docNo),
    clientId: first.clientId,
    docNo: first.docNo,
    period: first.period,
    date: first.date,
    module: first.module,
    docType: first.docType,
    currency: first.currency,
    description: first.description,
    debitTotal: debitCents / 100,
    creditTotal: creditCents / 100,
    lineCount: lines.length,
    createdBy: first.createdBy,
    checkedBy: first.checkedBy ?? null,
    reference: first.reference ?? null,
    contentHash: journalContentHash(lines),
    postedAt,
  };
}

export function postingIdempotencyKey(clientId: number, docNo: string, suppliedIdempotencyKey?: string): string {
  const requestedKey = suppliedIdempotencyKey?.trim();
  return requestedKey ? `${requestedKey}:${clientId}:${encodeURIComponent(docNo)}` : docNo;
}

export function buildPostingEvent(
  lines: readonly ACDOCALine[],
  actor: string,
  suppliedIdempotencyKey?: string,
) {
  if (!lines.length) throw new Error("A posting event requires at least one journal line.");
  const first = lines[0];
  const requestedKey = suppliedIdempotencyKey?.trim();
  const idempotencyKey = requestedKey
    ? `${requestedKey}:${first.clientId}:${encodeURIComponent(first.docNo)}`
    : first.docNo;
  return {
    id: crypto.randomUUID(),
    clientId: first.clientId,
    idempotencyKey,
    requestHash: journalContentHash(lines),
    response: { ok: true, clientId: first.clientId, docNo: first.docNo, lines },
    actor,
    createdAt: new Date(),
  };
}
