/**
 * Ghana indirect-tax engine (GRA), shared by the browser and the trade service.
 *
 * Legal basis — verified against gra.gov.gh and the GRA Administrative
 * Guidelines to the Value Added Tax Act, 2025 (Act 1151):
 *
 *  · VAT                     15%   (Act 1151 s.5) on the taxable value.
 *  · NHIL                    2.5%  (Act 1151 s.6) on the SAME taxable value as VAT.
 *  · GETFund Levy            2.5%  (Act 1151 s.6) on the SAME taxable value as VAT.
 *  · COVID-19 Health Recovery Levy  — REPEALED with effect from 1 January 2026
 *                                     (COVID-19 Health Recovery Levy Repeal Act, 2025).
 *                                     Kept as a zero-rated, switchable component so
 *                                     prior-period documents still reconcile.
 *  · Communication Service Tax 5%  (Act 754, as amended by Act 864 and Act 1025,
 *                                     which reduced 9% → 5% with effect from 15 Sept 2020).
 *                                     Charged only by Class 1 electronic communications
 *                                     service providers notified by the Commissioner-General.
 *                                     Per Act 1151 s.15.3 CST is ADDED TO THE COST to form the
 *                                     taxable value before VAT and the levies are computed.
 *  · Tourism Development Levy 1%   (Tourism Act 817) on hospitality accommodation.
 *                                     Charged separately and does NOT form part of the
 *                                     VAT taxable value.
 *  · VAT Withholding         7%    of the taxable value, deducted at source by appointed
 *                                     withholding agents; it is a receivable from GRA, not a
 *                                     discount — the supplier still books the full receivable.
 *
 * Everything a user can override is a rate, so a future GRA change is a settings
 * edit rather than a code change.
 */

export type TaxSide = "sales" | "purchase";

export interface TaxRegime {
  /** Standard-rated VAT, % of taxable value. */
  vatRate: number;
  /** National Health Insurance Levy, % of taxable value. */
  nhilRate: number;
  /** GETFund Levy, % of taxable value. */
  getfundRate: number;
  /** COVID-19 Health Recovery Levy — repealed 2026-01-01, normally 0. */
  covidRate: number;
  /** Communication Service Tax, % of the charge (cascades into the VAT base). */
  cstRate: number;
  /** Tourism Development Levy, % of the charge (kept out of the VAT base). */
  tourismRate: number;
  /** VAT withheld at source by an appointed agent, % of taxable value (sales only). */
  vatWithholdingRate: number;
  /** Income withholding tax on the payment, % of the tax-exclusive value (purchase only). */
  incomeWhtRate: number;
}

export const DEFAULT_TAX_REGIME: TaxRegime = {
  vatRate: 15,
  nhilRate: 2.5,
  getfundRate: 2.5,
  covidRate: 0,
  cstRate: 0,
  tourismRate: 0,
  vatWithholdingRate: 0,
  incomeWhtRate: 0,
};

export interface TaxComponent {
  code: string;
  label: string;
  rate: number;
  amount: number;
  /** Treasury account the component is posted to. */
  accountNo: string;
  /** `cascade` = added to the cost before VAT is computed (Act 1151 s.15.3). */
  base: "charge" | "charge_plus_cst";
}

export interface TaxBreakdown {
  /** Tax-exclusive value of the supply. */
  net: number;
  /** net + CST — the value VAT and the levies are computed on. */
  taxableValue: number;
  components: TaxComponent[];
  /** Everything charged to the customer / payable to GRA on top of `net`. */
  totalTax: number;
  /** Amount withheld at source by an appointed VAT agent (sales). */
  vatWithheld: number;
  /** Income withholding tax deducted from the payment (purchase). */
  incomeWhTax: number;
  /** net + totalTax — what the document is worth before any withholding. */
  gross: number;
  /** Effective headline rate, % of `net` (0 when `net` is 0). */
  effectiveRate: number;
}

/**
 * Treasury accounts. `220000` is the universal VAT output liability and is the
 * fallback for every levy account, so a chart of accounts that has not yet been
 * extended still posts correctly (the levy is simply reported inside VAT output).
 */
export const TAX_ACCOUNTS = {
  vatOutput: "220000",
  vatInput: "125000",
  vatWithholdingPayable: "221000",
  vatWithholdingReceivable: "115000",
  /** 220000 is captioned "VAT / NHIL / GETFund Output Liability" in the chart. */
  nhilGetfundPayable: "220000",
  cstPayable: "223000",
  tourismPayable: "224000",
  incomeWhtPayable: "209000",
  incomeWhtReceivable: "115000",
} as const;

const FALLBACK: Record<string, string> = {
  [TAX_ACCOUNTS.cstPayable]: TAX_ACCOUNTS.vatOutput,
  [TAX_ACCOUNTS.tourismPayable]: TAX_ACCOUNTS.vatOutput,
};

/** Prefer the dedicated levy account, fall back to VAT output when the chart has not been extended. */
export function resolveTaxAccount(accountNo: string, activeAccounts: ReadonlySet<string>): string {
  if (activeAccounts.has(accountNo)) return accountNo;
  const fallback = FALLBACK[accountNo];
  return fallback && activeAccounts.has(fallback) ? fallback : accountNo;
}

const round2 = (n: number) => Math.round((Number.isFinite(n) ? n : 0) * 100) / 100;
const clampRate = (n: number, fallback = 0) => {
  const value = typeof n === "number" ? n : Number(n);
  return Number.isFinite(value) && value >= 0 && value <= 100 ? value : fallback;
};

export function normaliseTaxRegime(input: unknown, side: TaxSide = "sales"): TaxRegime {
  const raw = (input && typeof input === "object" ? input : {}) as Record<string, unknown>;
  return {
    vatRate: clampRate(raw.vatRate as number, DEFAULT_TAX_REGIME.vatRate),
    nhilRate: clampRate(raw.nhilRate as number, DEFAULT_TAX_REGIME.nhilRate),
    getfundRate: clampRate(raw.getfundRate as number, DEFAULT_TAX_REGIME.getfundRate),
    covidRate: clampRate(raw.covidRate as number, 0),
    cstRate: clampRate(raw.cstRate as number, 0),
    tourismRate: clampRate(raw.tourismRate as number, 0),
    vatWithholdingRate: side === "sales" ? clampRate(raw.vatWithholdingRate as number, 0) : 0,
    incomeWhtRate: side === "purchase" ? clampRate(raw.incomeWhtRate as number, 0) : 0,
  };
}

/**
 * The whole GRA stack for one tax-exclusive value.
 *
 * Ordering matters and follows the Act: CST is added to the charge first
 * (s.15.3), VAT/NHIL/GETFund are then computed on that augmented value, and the
 * Tourism Levy sits outside the VAT base entirely.
 */
export function computeTaxBreakdown(net: number, regime: TaxRegime, side: TaxSide = "sales"): TaxBreakdown {
  const base = round2(Math.max(0, net));
  const cst = round2(base * regime.cstRate / 100);
  const taxableValue = round2(base + cst);
  const components: TaxComponent[] = [];

  if (regime.cstRate > 0) {
    components.push({ code: "CST", label: "Communication Service Tax", rate: regime.cstRate, amount: cst, accountNo: TAX_ACCOUNTS.cstPayable, base: "charge" });
  }
  // On purchases every recoverable component is input tax (Act 1151 s.6 makes
  // NHIL and GETFund claimable alongside VAT); on sales each levy is a separate
  // liability to GRA.
  const recoverable = side === "purchase";
  const vat = round2(taxableValue * regime.vatRate / 100);
  if (regime.vatRate > 0) {
    components.push({ code: "VAT", label: "Value Added Tax", rate: regime.vatRate, amount: vat, accountNo: recoverable ? TAX_ACCOUNTS.vatInput : TAX_ACCOUNTS.vatOutput, base: "charge_plus_cst" });
  }
  const nhil = round2(taxableValue * regime.nhilRate / 100);
  if (regime.nhilRate > 0) {
    components.push({ code: "NHIL", label: "National Health Insurance Levy", rate: regime.nhilRate, amount: nhil, accountNo: recoverable ? TAX_ACCOUNTS.vatInput : TAX_ACCOUNTS.nhilGetfundPayable, base: "charge_plus_cst" });
  }
  const getfund = round2(taxableValue * regime.getfundRate / 100);
  if (regime.getfundRate > 0) {
    components.push({ code: "GETFUND", label: "GETFund Levy", rate: regime.getfundRate, amount: getfund, accountNo: recoverable ? TAX_ACCOUNTS.vatInput : TAX_ACCOUNTS.nhilGetfundPayable, base: "charge_plus_cst" });
  }
  const covid = round2(taxableValue * regime.covidRate / 100);
  if (regime.covidRate > 0) {
    components.push({ code: "COVID", label: "COVID-19 Health Recovery Levy", rate: regime.covidRate, amount: covid, accountNo: recoverable ? TAX_ACCOUNTS.vatInput : TAX_ACCOUNTS.vatOutput, base: "charge_plus_cst" });
  }
  // Tourism Development Levy: charged on the value of the accommodation supply,
  // kept OUT of the VAT taxable value (Tourism Act 817).
  const tourism = round2(base * regime.tourismRate / 100);
  if (regime.tourismRate > 0) {
    components.push({ code: "TOURISM", label: "Tourism Development Levy", rate: regime.tourismRate, amount: tourism, accountNo: TAX_ACCOUNTS.tourismPayable, base: "charge" });
  }

  const totalTax = round2(components.reduce((sum, c) => sum + c.amount, 0));
  const vatWithheld = side === "sales" ? round2(taxableValue * regime.vatWithholdingRate / 100) : 0;
  const incomeWhTax = side === "purchase" ? round2(base * regime.incomeWhtRate / 100) : 0;
  const gross = round2(base + totalTax);

  return {
    net: base,
    taxableValue,
    components,
    totalTax,
    vatWithheld,
    incomeWhTax,
    gross,
    effectiveRate: base > 0 ? round2(totalTax / base * 100) : 0,
  };
}

/**
 * Single headline rate that reproduces `totalTax` on `net`. Used for the
 * `trade_document_lines.tax_rate` column, which stays a plain number so every
 * existing tolerance / matching query keeps working.
 */
export function effectiveTaxRate(net: number, breakdown: TaxBreakdown): number {
  return net > 0 ? Math.round((breakdown.totalTax / net) * 10000) / 100 : 0;
}

/** Sum a set of net values through the regime in one call (document level). */
export function computeDocumentTax(nets: readonly number[], regime: TaxRegime, side: TaxSide = "sales"): TaxBreakdown {
  return computeTaxBreakdown(nets.reduce((sum, n) => sum + Math.max(0, n), 0), regime, side);
}

/** Human-readable caption used on printed documents and reports. */
export function taxComponentCaption(breakdown: TaxBreakdown): string {
  return breakdown.components.map((c) => `${c.label} ${c.rate}%`).join(" · ");
}
