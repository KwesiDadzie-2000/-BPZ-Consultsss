/**
 * Fixed asset accounting, tax depreciation and deferred tax engine.
 * -----------------------------------------------------------------------------
 *  IAS 16  — book depreciation: straight-line or reducing balance on a user
 *            supplied rate (or the rate implied by the useful life).
 *  Ghana Income Tax Act 2015 (Act 896) Third Schedule — capital allowances by
 *            asset pool/class (reducing balance for classes 1–3, straight line
 *            for classes 4–6). Rates remain editable per asset.
 *  IAS 12  — deferred tax on the temporary difference between the carrying
 *            amount (NBV) and the tax base (tax written-down value).
 *
 *  Deferred tax entry (liability increase):
 *      Dr Income tax expense — deferred (731000)
 *      Cr Deferred tax liability (222000)
 *  A net deductible difference produces a deferred tax asset (117000) instead,
 *  recognised only to the extent recovery is probable.
 */
import type { ACDOCALine, FixedAsset } from '../types/accounting';
import { uniqueId } from './ids';

export const DEFERRED_TAX_LIABILITY = '222000';
export const DEFERRED_TAX_LIABILITY_NAME = 'Deferred Tax Liability (IAS 12)';
export const DEFERRED_TAX_ASSET = '117000';
export const DEFERRED_TAX_ASSET_NAME = 'Deferred Tax Asset (IAS 12)';
export const DEFERRED_TAX_EXPENSE = '731000';
export const DEFERRED_TAX_EXPENSE_NAME = 'Income Tax Expense — Deferred Tax (IAS 12)';
export const DEPRECIATION_EXPENSE = '600000';
export const ACCUM_DEPRECIATION = '139000';
export const PPE_COST = '130000';

export type DepreciationMethod = 'straight_line' | 'reducing_balance';

export const money = (value: number): number => Math.round((Number.isFinite(value) ? value : 0) * 100) / 100;

/** Ghana Act 896 Third Schedule pools. `straightLine` pools are written off evenly. */
export interface CapitalAllowanceClass {
  code: string;
  label: string;
  rate: number;
  straightLine: boolean;
  examples: string;
}

export const CAPITAL_ALLOWANCE_CLASSES: CapitalAllowanceClass[] = [
  { code: 'CLASS_1', label: 'Class 1 — 40% reducing balance', rate: 40, straightLine: false, examples: 'Computers, data handling equipment' },
  { code: 'CLASS_2', label: 'Class 2 — 30% reducing balance', rate: 30, straightLine: false, examples: 'Plant & machinery, motor vehicles, construction equipment' },
  { code: 'CLASS_3', label: 'Class 3 — 20% reducing balance', rate: 20, straightLine: false, examples: 'Railroad cars, aircraft, specialised public utility plant' },
  { code: 'CLASS_4', label: 'Class 4 — 20% straight line', rate: 20, straightLine: true, examples: 'Buildings and structures in a business' },
  { code: 'CLASS_5', label: 'Class 5 — 10% straight line', rate: 10, straightLine: true, examples: 'Mineral & petroleum exploration and production rights' },
  { code: 'CLASS_6', label: 'Class 6 — 10% straight line', rate: 10, straightLine: true, examples: 'Intangibles other than Class 5 (over useful life)' },
  { code: 'NONE', label: 'No capital allowance (non-qualifying)', rate: 0, straightLine: true, examples: 'Land, assets held for sale, non-qualifying expenditure' },
];

export const classFor = (code?: string): CapitalAllowanceClass =>
  CAPITAL_ALLOWANCE_CLASSES.find((c) => c.code === code) || CAPITAL_ALLOWANCE_CLASSES[1];

export const yearsOfLife = (life: string): number => {
  const m = String(life || '').match(/(\d+(?:\.\d+)?)/);
  return m ? Number(m[1]) : 0;
};

/** Book depreciation rate: explicit rate wins, otherwise derived from useful life. */
export const effectiveDepRate = (asset: Pick<FixedAsset, 'depreciationRate' | 'usefulLife'>): number => {
  if (asset.depreciationRate && asset.depreciationRate > 0) return asset.depreciationRate;
  const years = yearsOfLife(asset.usefulLife);
  return years > 0 ? Math.round((100 / years) * 100) / 100 : 0;
};

export const netBookValue = (asset: Pick<FixedAsset, 'cost' | 'accumDep'>): number => money(asset.cost - asset.accumDep);

export const taxWrittenDownValue = (asset: Pick<FixedAsset, 'cost' | 'accumCapitalAllowance'>): number =>
  money(asset.cost - (asset.accumCapitalAllowance || 0));

/**
 * Monthly book depreciation charge. Reducing balance applies the annual rate to
 * the opening net book value; the charge is capped so NBV never goes negative.
 */
export const monthlyDepreciation = (asset: FixedAsset): number => {
  const rate = effectiveDepRate(asset);
  if (rate <= 0 || asset.cost <= 0) return 0;
  const nbv = netBookValue(asset);
  if (nbv <= 0) return 0;
  const method: DepreciationMethod = asset.depreciationMethod || 'straight_line';
  const annual = method === 'reducing_balance' ? (nbv * rate) / 100 : (asset.cost * rate) / 100;
  return money(Math.min(annual / 12, nbv));
};

/** Annual capital allowance for the asset's pool, capped at the remaining tax base. */
export const annualCapitalAllowance = (asset: FixedAsset): number => {
  const cls = classFor(asset.capitalAllowanceClass);
  const rate = asset.capitalAllowanceRate ?? cls.rate;
  if (rate <= 0 || asset.cost <= 0) return 0;
  const twdv = taxWrittenDownValue(asset);
  if (twdv <= 0) return 0;
  const base = cls.straightLine ? asset.cost : twdv;
  return money(Math.min((base * rate) / 100, twdv));
};

export interface DeferredTaxRow {
  assetTag: string;
  name: string;
  carryingAmount: number;
  taxBase: number;
  temporaryDifference: number;
  deferredTax: number;
}

export interface DeferredTaxComputation {
  taxRatePct: number;
  rows: DeferredTaxRow[];
  carryingAmount: number;
  taxBase: number;
  temporaryDifference: number;
  /** Positive = deferred tax liability; negative = deferred tax asset. */
  requiredBalance: number;
  recognisedBalance: number;
  movement: number;
}

/**
 * IAS 12 computation across the register. A carrying amount above the tax base
 * is a taxable temporary difference (liability); below it is deductible (asset).
 */
export const computeDeferredTax = (
  assets: FixedAsset[],
  taxRatePct: number,
  recognisedBalance = 0,
): DeferredTaxComputation => {
  const live = assets.filter((a) => !a.disposedDate);
  const rows: DeferredTaxRow[] = live.map((a) => {
    const carrying = netBookValue(a);
    const base = taxWrittenDownValue(a);
    const diff = money(carrying - base);
    return {
      assetTag: a.assetTag,
      name: a.name,
      carryingAmount: carrying,
      taxBase: base,
      temporaryDifference: diff,
      deferredTax: money((diff * taxRatePct) / 100),
    };
  });
  const carryingAmount = money(rows.reduce((n, r) => n + r.carryingAmount, 0));
  const taxBase = money(rows.reduce((n, r) => n + r.taxBase, 0));
  const temporaryDifference = money(carryingAmount - taxBase);
  const requiredBalance = money((temporaryDifference * taxRatePct) / 100);
  return {
    taxRatePct,
    rows,
    carryingAmount,
    taxBase,
    temporaryDifference,
    requiredBalance,
    recognisedBalance: money(recognisedBalance),
    movement: money(requiredBalance - recognisedBalance),
  };
};

interface Ctx {
  docNo: string;
  date: string;
  currency: string;
  clientId: number;
  createdBy: string;
  costCenter?: string;
}

const mk = (
  ctx: Ctx,
  accountNo: string,
  accountName: string,
  debit: number,
  credit: number,
  description: string,
): ACDOCALine => ({
  id: uniqueId('JL-TAX'),
  docNo: ctx.docNo,
  period: ctx.date.slice(0, 7),
  date: ctx.date,
  module: 'FI-AA',
  docType: 'STAT',
  accountNo,
  accountName,
  costCenter: ctx.costCenter || 'CC-ADM',
  debit: money(debit),
  credit: money(credit),
  currency: ctx.currency,
  description,
  createdBy: ctx.createdBy,
  clientId: ctx.clientId,
});

/**
 * Deferred tax movement journal. `requiredBalance`/`recognisedBalance` are the
 * closing and opening deferred tax positions (positive = liability).
 */
export const buildDeferredTaxEntries = (ctx: Ctx, computation: DeferredTaxComputation): ACDOCALine[] => {
  const movement = money(computation.movement);
  if (Math.abs(movement) < 0.005) return [];
  const asLiability = computation.requiredBalance >= 0;
  const account = asLiability ? DEFERRED_TAX_LIABILITY : DEFERRED_TAX_ASSET;
  const accountName = asLiability ? DEFERRED_TAX_LIABILITY_NAME : DEFERRED_TAX_ASSET_NAME;
  const amount = Math.abs(movement);
  const narrative = `IAS 12 deferred tax movement at ${computation.taxRatePct}% on temporary difference ${computation.temporaryDifference.toFixed(2)}`;
  // Increase in a liability position (or decrease in an asset) charges expense.
  const chargeExpense = movement > 0;
  return chargeExpense
    ? [
        mk(ctx, DEFERRED_TAX_EXPENSE, DEFERRED_TAX_EXPENSE_NAME, amount, 0, narrative),
        mk(ctx, account, accountName, 0, amount, narrative),
      ]
    : [
        mk(ctx, account, accountName, amount, 0, narrative),
        mk(ctx, DEFERRED_TAX_EXPENSE, DEFERRED_TAX_EXPENSE_NAME, 0, amount, narrative),
      ];
};

/** Current deferred tax position already posted to the ledger (liability positive). */
export const ledgerDeferredTaxBalance = (lines: ACDOCALine[], clientId: number): number => {
  const liability =
    lines
      .filter((l) => l.clientId === clientId && l.accountNo === DEFERRED_TAX_LIABILITY)
      .reduce((n, l) => n + Math.round(l.credit * 100) - Math.round(l.debit * 100), 0) / 100;
  const asset =
    lines
      .filter((l) => l.clientId === clientId && l.accountNo === DEFERRED_TAX_ASSET)
      .reduce((n, l) => n + Math.round(l.debit * 100) - Math.round(l.credit * 100), 0) / 100;
  return money(liability - asset);
};

export interface CapitalAllowanceRow {
  assetTag: string;
  name: string;
  className: string;
  rate: number;
  cost: number;
  openingTwdv: number;
  allowance: number;
  closingTwdv: number;
}

export const capitalAllowanceSchedule = (assets: FixedAsset[]): CapitalAllowanceRow[] =>
  assets
    .filter((a) => !a.disposedDate)
    .map((a) => {
      const cls = classFor(a.capitalAllowanceClass);
      const opening = taxWrittenDownValue(a);
      const allowance = annualCapitalAllowance(a);
      return {
        assetTag: a.assetTag,
        name: a.name,
        className: cls.label,
        rate: a.capitalAllowanceRate ?? cls.rate,
        cost: money(a.cost),
        openingTwdv: opening,
        allowance,
        closingTwdv: money(opening - allowance),
      };
    });
