import type {
  ACDOCALine,
  AccountMaster,
  BusinessPartner,
  PurchaseOrder,
  SalesInvoice,
  TaxScheduleEntry,
  TaxScheduleKind,
} from '../types/accounting';
import { classifyAccount } from './reports';

/**
 * General ledger and statutory schedule engine.
 * Every figure is derived from posted journal lines — nothing is hard-coded.
 */

export const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const toMinor = (n: number) => Math.round(n * 100);

/** Statutory accounts used by the schedules (firm master chart numbers). */
export const TAX_ACCOUNTS = {
  INPUT_VAT: '125000',
  WHT_RECEIVABLE: '115000',
  WHT_PAYABLE: '209000',
  OUTPUT_VAT: '220000',
  VAT_WHT_PAYABLE: '221000',
  TRADE_PAYABLES: '200000',
  ACCRUED_PAYABLES: '202000',
  TRADE_RECEIVABLES: '110000',
} as const;

/* ============================================================================
 * GENERAL LEDGER
 * ========================================================================== */

export interface LedgerEntry {
  line: ACDOCALine;
  /** Running balance after this entry, signed in the account's NORMAL direction (positive = normal balance). */
  balance: number;
}

export interface AccountLedger {
  accountNo: string;
  name: string;
  type: AccountMaster['type'];
  category: string;
  /** Opening balance at `from`, signed in the account's normal direction. */
  opening: number;
  entries: LedgerEntry[];
  totalDebit: number;
  totalCredit: number;
  closing: number;
  active: boolean;
}

export const isDebitNormal = (type: AccountMaster['type']) => type === 'Asset' || type === 'Expense';

/** Human label for a signed normal-direction balance, e.g. "12,000.00 Dr". */
export function balanceLabel(balance: number, type: AccountMaster['type'], fmt: (n: number) => string): string {
  if (Math.abs(balance) < 0.005) return `${fmt(0)}`;
  const debitNormal = isDebitNormal(type);
  const isDr = debitNormal ? balance > 0 : balance < 0;
  return `${fmt(Math.abs(balance))} ${isDr ? 'Dr' : 'Cr'}`;
}

const sortLines = (a: ACDOCALine, b: ACDOCALine) =>
  a.date.localeCompare(b.date) || a.docNo.localeCompare(b.docNo) || a.id.localeCompare(b.id);

/**
 * Builds the general ledger of one entity for a date window. Accounts with no
 * movement and a zero opening balance are omitted unless `includeEmpty` is set.
 */
export function buildGeneralLedger(
  lines: ACDOCALine[],
  accounts: AccountMaster[],
  clientId: number,
  from: string,
  through: string,
  opts: { accountNo?: string; includeEmpty?: boolean; search?: string } = {}
): AccountLedger[] {
  const scoped = lines.filter((l) => l.clientId === clientId && l.date <= through && (!opts.accountNo || l.accountNo === opts.accountNo));
  const byAccount = new Map<string, ACDOCALine[]>();
  for (const l of scoped) {
    const list = byAccount.get(l.accountNo) ?? [];
    list.push(l);
    byAccount.set(l.accountNo, list);
  }
  const accountNos = new Set<string>([...byAccount.keys()]);
  if (opts.includeEmpty) for (const a of accounts) if (!opts.accountNo || a.accountNo === opts.accountNo) accountNos.add(a.accountNo);

  const ledgers: AccountLedger[] = [];
  for (const accountNo of [...accountNos].sort((a, b) => a.localeCompare(b))) {
    const master = accounts.find((a) => a.accountNo === accountNo);
    const type = master?.type ?? classifyAccount(accounts, accountNo);
    const sign = isDebitNormal(type) ? 1 : -1;
    const all = (byAccount.get(accountNo) ?? []).slice().sort(sortLines);
    const openingMinor = all.filter((l) => l.date < from).reduce((n, l) => n + sign * (toMinor(l.debit) - toMinor(l.credit)), 0);
    let running = openingMinor;
    const entries: LedgerEntry[] = [];
    let dr = 0;
    let cr = 0;
    for (const l of all.filter((l) => l.date >= from)) {
      running += sign * (toMinor(l.debit) - toMinor(l.credit));
      dr += toMinor(l.debit);
      cr += toMinor(l.credit);
      entries.push({ line: l, balance: running / 100 });
    }
    const name = master?.name || all[0]?.accountName || accountNo;
    if (opts.search) {
      const q = opts.search.toLowerCase();
      if (!accountNo.includes(q) && !name.toLowerCase().includes(q)) continue;
    }
    if (!opts.includeEmpty && !entries.length && openingMinor === 0) continue;
    ledgers.push({
      accountNo,
      name,
      type,
      category: master?.category || '',
      opening: openingMinor / 100,
      entries,
      totalDebit: dr / 100,
      totalCredit: cr / 100,
      closing: running / 100,
      active: master?.active ?? true,
    });
  }
  return ledgers;
}

/** Document-level validation shared by the GL editor and the add-entry form. */
export function validateDocumentLines(
  draft: { accountNo: string; debit: number; credit: number }[],
  knownAccounts: Set<string>
): string | null {
  if (!draft.length) return 'A document needs at least two lines.';
  if (draft.length < 2) return 'A document needs at least two lines (one debit and one credit).';
  for (const d of draft) {
    if (!d.accountNo || !knownAccounts.has(d.accountNo)) return `Account ${d.accountNo || '(blank)'} does not exist in the chart of accounts.`;
    if (!Number.isFinite(d.debit) || !Number.isFinite(d.credit) || d.debit < 0 || d.credit < 0) return 'Amounts must be zero or positive numbers.';
    if (d.debit > 0 && d.credit > 0) return 'A line may carry a debit OR a credit, not both.';
    if (d.debit === 0 && d.credit === 0) return 'Every line needs an amount.';
  }
  const dr = draft.reduce((n, d) => n + toMinor(d.debit), 0);
  const cr = draft.reduce((n, d) => n + toMinor(d.credit), 0);
  if (dr <= 0) return 'The document total must be greater than zero.';
  if (dr !== cr) return `Document is not balanced: debits ${(dr / 100).toFixed(2)} ≠ credits ${(cr / 100).toFixed(2)}.`;
  return null;
}

/* ============================================================================
 * STATUTORY SCHEDULES — WITHHOLDING TAX & VAT
 * ========================================================================== */

export interface ScheduleRow {
  key: string;
  kind: TaxScheduleKind;
  source: 'ledger' | 'manual';
  /** Set when a stored entry (manual or override) backs this row. */
  entryId?: string;
  edited: boolean;
  period: string;
  date: string;
  docNo: string;
  partyName: string;
  partyTin: string;
  nature: string;
  grossAmount: number;
  rate: number;
  taxAmount: number;
  levyAmount: number;
  reference: string;
  status: string;
  note?: string;
}

export interface VatRates {
  vat: number;
  nhil: number;
  getfund: number;
  covid: number;
}

const partyFromAccountName = (accountName: string): string | null => {
  const m = accountName.match(/\(([^)]+)\)\s*$/);
  return m ? m[1] : null;
};

const partyFromDescription = (description: string): string | null => {
  const payee = description.match(/payee:\s*([^—(·]+?)(?:\s*\(|\s*—|\s*·|$)/i);
  if (payee) return payee[1].trim();
  const to = description.match(/\bto\s+([^—(·]+?)(?:\s*\(|\s*—|\s*·|$)/i);
  if (to) return to[1].trim();
  const by = description.match(/\bby\s+([^—(·]+?)\s+on\b/i);
  if (by) return by[1].trim();
  return null;
};

const rateFromDescription = (description: string): number | null => {
  const m = description.match(/(\d+(?:\.\d+)?)\s*%/);
  return m ? Number(m[1]) : null;
};

const tinFor = (partners: BusinessPartner[], name: string): string => {
  const n = name.trim().toLowerCase();
  if (!n) return '';
  const hit = partners.find((p) => p.name.trim().toLowerCase() === n);
  return hit?.tin || '';
};

const groupByDoc = (lines: ACDOCALine[]): Map<string, ACDOCALine[]> => {
  const map = new Map<string, ACDOCALine[]>();
  for (const l of lines) {
    const list = map.get(l.docNo) ?? [];
    list.push(l);
    map.set(l.docNo, list);
  }
  return map;
};

/**
 * Withholding tax DEDUCTED by the entity from payments to suppliers (credits to
 * 209000) — the monthly WHT return schedule. One row per document.
 */
export function deriveWhtDeductions(lines: ACDOCALine[], clientId: number, period: string | null, partners: BusinessPartner[]): ScheduleRow[] {
  const scoped = lines.filter((l) => l.clientId === clientId && (!period || l.period === period));
  const docs = groupByDoc(scoped);
  const rows: ScheduleRow[] = [];
  for (const [docNo, docLines] of docs) {
    const whtLines = docLines.filter((l) => l.accountNo === TAX_ACCOUNTS.WHT_PAYABLE && l.credit > 0);
    if (!whtLines.length) continue;
    if (docLines.every((l) => l.isReversed)) continue;
    const tax = r2(whtLines.reduce((s, l) => s + l.credit, 0));
    const vatWithheld = r2(docLines.filter((l) => l.accountNo === TAX_ACCOUNTS.VAT_WHT_PAYABLE).reduce((s, l) => s + l.credit - l.debit, 0));
    const payableLine = docLines.find((l) => (l.accountNo === TAX_ACCOUNTS.TRADE_PAYABLES || l.accountNo === TAX_ACCOUNTS.ACCRUED_PAYABLES) && l.debit > 0);
    const party = (payableLine && partyFromAccountName(payableLine.accountName)) || partyFromDescription(docLines.map((l) => l.description).join(' · ')) || '';
    const rate = rateFromDescription(whtLines.map((l) => l.description).join(' ')) ?? 0;
    const gross = rate > 0 ? r2(tax * 100 / rate) : r2(payableLine?.debit ?? 0);
    const descr = whtLines[0].description.toLowerCase();
    const nature = docNo.startsWith('OPEN') || descr.includes('opening') ? 'Opening balance'
      : descr.includes('rent') ? 'Rent'
      : descr.includes('service') || docNo.includes('EXPB') ? 'Services'
      : descr.includes('works') ? 'Works'
      : descr.includes('goods') || docLines.some((l) => l.accountNo.startsWith('12')) ? 'Goods'
      : 'Services';
    rows.push({
      key: `wht:${docNo}`, kind: 'wht', source: 'ledger', edited: false,
      period: whtLines[0].period, date: whtLines[0].date, docNo,
      partyName: party, partyTin: tinFor(partners, party), nature,
      grossAmount: gross, rate, taxAmount: tax, levyAmount: vatWithheld,
      reference: whtLines[0].reference || '', status: 'Deducted',
    });
  }
  return rows.sort((a, b) => a.date.localeCompare(b.date) || a.docNo.localeCompare(b.docNo));
}

/**
 * Withholding tax SUFFERED by the entity (customers withheld at source — debits
 * to 115000). These are the GRA credit notes claimable against CIT.
 */
export function deriveWhtCredits(lines: ACDOCALine[], clientId: number, period: string | null, partners: BusinessPartner[]): ScheduleRow[] {
  const scoped = lines.filter((l) => l.clientId === clientId && (!period || l.period === period));
  const docs = groupByDoc(scoped);
  const rows: ScheduleRow[] = [];
  for (const [docNo, docLines] of docs) {
    const credits = docLines.filter((l) => l.accountNo === TAX_ACCOUNTS.WHT_RECEIVABLE && l.debit > 0);
    if (!credits.length || docLines.every((l) => l.isReversed)) continue;
    const tax = r2(credits.reduce((s, l) => s + l.debit, 0));
    const recLine = docLines.find((l) => l.accountNo === TAX_ACCOUNTS.TRADE_RECEIVABLES && l.credit > 0);
    const party = (recLine && partyFromAccountName(recLine.accountName)) || partyFromDescription(credits[0].description) || '';
    const rate = rateFromDescription(credits[0].description) ?? 0;
    const gross = rate > 0 ? r2(tax * 100 / rate) : r2(recLine?.credit ?? 0);
    rows.push({
      key: `wht_credit:${docNo}`, kind: 'wht_credit', source: 'ledger', edited: false,
      period: credits[0].period, date: credits[0].date, docNo,
      partyName: party, partyTin: tinFor(partners, party),
      nature: credits[0].description.toLowerCase().includes('vat') ? 'VAT withheld by agent' : 'Income tax withheld',
      grossAmount: gross, rate, taxAmount: tax, levyAmount: 0,
      reference: credits[0].reference || '', status: 'Credit note pending',
    });
  }
  return rows.sort((a, b) => a.date.localeCompare(b.date) || a.docNo.localeCompare(b.docNo));
}

/** Splits a combined VAT stack (VAT + levies) using the configured rates. */
export function splitVatStack(total: number, base: number, rates: VatRates): { vat: number; levies: number } {
  const levyRate = rates.nhil + rates.getfund + rates.covid;
  const stackRate = rates.vat + levyRate;
  if (stackRate <= 0) return { vat: r2(total), levies: 0 };
  // Prefer the taxable base when known; otherwise derive it from the stack total.
  const effBase = base > 0 ? base : total * 100 / stackRate;
  const levies = r2(Math.min(total, effBase * levyRate / 100));
  return { vat: r2(total - levies), levies };
}

/** Output VAT schedule: one row per sales document crediting 220000 (credit notes appear as negatives). */
export function deriveVatOutput(
  lines: ACDOCALine[],
  clientId: number,
  period: string | null,
  invoices: SalesInvoice[],
  partners: BusinessPartner[],
  rates: VatRates
): ScheduleRow[] {
  const scoped = lines.filter((l) => l.clientId === clientId && (!period || l.period === period));
  const docs = groupByDoc(scoped);
  const rows: ScheduleRow[] = [];
  for (const [docNo, docLines] of docs) {
    const vatLines = docLines.filter((l) => l.accountNo === TAX_ACCOUNTS.OUTPUT_VAT);
    if (!vatLines.length || docLines.every((l) => l.isReversed)) continue;
    if (docNo.startsWith('STAT-')) continue; // remittances are payments, not supplies
    const total = r2(vatLines.reduce((s, l) => s + l.credit - l.debit, 0));
    if (Math.abs(total) < 0.005) continue;
    const invoice = invoices.find((i) => i.clientId === clientId && (i.invNo === docNo || docNo.includes(i.invNo.replace('INV-', ''))));
    const incomeBase = r2(docLines.filter((l) => l.accountNo.startsWith('4')).reduce((s, l) => s + l.credit - l.debit, 0));
    const taxable = invoice && docNo === invoice.invNo ? invoice.netRevenue : incomeBase !== 0 ? incomeBase : 0;
    const recLine = docLines.find((l) => l.accountNo === TAX_ACCOUNTS.TRADE_RECEIVABLES);
    const party = invoice?.customerName || (recLine && partyFromAccountName(recLine.accountName)) || '';
    const base = Math.abs(taxable) + (invoice?.cstAmount || 0);
    const { vat, levies } = splitVatStack(Math.abs(total), base, rates);
    const sign = total < 0 ? -1 : 1;
    rows.push({
      key: `vat_output:${docNo}`, kind: 'vat_output', source: 'ledger', edited: false,
      period: vatLines[0].period, date: vatLines[0].date, docNo,
      partyName: party, partyTin: tinFor(partners, party),
      nature: sign < 0 ? 'Credit note (standard-rated)' : 'Standard-rated supply',
      grossAmount: sign * r2(taxable ? Math.abs(taxable) : 0), rate: rates.vat,
      taxAmount: sign * vat, levyAmount: sign * levies,
      reference: invoice?.revenueStream || vatLines[0].reference || '', status: invoice?.status || 'Posted',
    });
  }
  return rows.sort((a, b) => a.date.localeCompare(b.date) || a.docNo.localeCompare(b.docNo));
}

/** Input VAT schedule: one row per purchase document debiting 125000 (debit notes appear as negatives). */
export function deriveVatInput(
  lines: ACDOCALine[],
  clientId: number,
  period: string | null,
  orders: PurchaseOrder[],
  partners: BusinessPartner[],
  rates: VatRates
): ScheduleRow[] {
  const scoped = lines.filter((l) => l.clientId === clientId && (!period || l.period === period));
  const docs = groupByDoc(scoped);
  const rows: ScheduleRow[] = [];
  for (const [docNo, docLines] of docs) {
    const vatLines = docLines.filter((l) => l.accountNo === TAX_ACCOUNTS.INPUT_VAT);
    if (!vatLines.length || docLines.every((l) => l.isReversed)) continue;
    const total = r2(vatLines.reduce((s, l) => s + l.debit - l.credit, 0));
    if (Math.abs(total) < 0.005) continue;
    const po = orders.find((p) => p.clientId === clientId && p.poNo === docNo);
    const payableLine = docLines.find((l) => l.accountNo === TAX_ACCOUNTS.TRADE_PAYABLES || l.accountNo === TAX_ACCOUNTS.ACCRUED_PAYABLES);
    const party = po?.vendorName || (payableLine && partyFromAccountName(payableLine.accountName)) || partyFromDescription(docLines.map((l) => l.description).join(' · ')) || '';
    const costBase = r2(docLines.filter((l) => l.accountNo !== TAX_ACCOUNTS.INPUT_VAT && l.accountNo !== TAX_ACCOUNTS.TRADE_PAYABLES && l.accountNo !== TAX_ACCOUNTS.ACCRUED_PAYABLES && (l.accountNo.startsWith('1') || l.accountNo.startsWith('5') || l.accountNo.startsWith('6') || l.accountNo.startsWith('7'))).reduce((s, l) => s + l.debit - l.credit, 0));
    const taxable = po ? (po.netAmount ?? r2(po.qty * po.unitPrice)) : Math.abs(costBase);
    const { vat, levies } = splitVatStack(Math.abs(total), taxable, rates);
    const sign = total < 0 ? -1 : 1;
    rows.push({
      key: `vat_input:${docNo}`, kind: 'vat_input', source: 'ledger', edited: false,
      period: vatLines[0].period, date: vatLines[0].date, docNo,
      partyName: party, partyTin: tinFor(partners, party),
      nature: sign < 0 ? 'Debit note (standard-rated)' : po?.itemType === 'material' ? 'Standard-rated purchase — goods' : 'Standard-rated purchase — services',
      grossAmount: sign * r2(taxable), rate: rates.vat,
      taxAmount: sign * vat, levyAmount: sign * levies,
      reference: po?.quotationRef || vatLines[0].reference || '', status: po?.status || 'Posted',
    });
  }
  return rows.sort((a, b) => a.date.localeCompare(b.date) || a.docNo.localeCompare(b.docNo));
}

/**
 * Merges journal-derived rows with stored entries: overrides replace the derived
 * values of their source row; manual rows are appended. Orphaned overrides
 * (whose journal document no longer exists) are dropped.
 */
export function mergeScheduleRows(derived: ScheduleRow[], entries: TaxScheduleEntry[], kind: TaxScheduleKind, clientId: number, period: string | null): ScheduleRow[] {
  const mine = entries.filter((e) => e.clientId === clientId && e.kind === kind && (!period || e.period === period));
  const overrides = new Map(mine.filter((e) => e.source === 'ledger' && e.sourceKey).map((e) => [e.sourceKey!, e]));
  const merged: ScheduleRow[] = derived.map((row) => {
    const o = overrides.get(row.key);
    if (!o) return row;
    return {
      ...row,
      entryId: o.id, edited: true,
      partyName: o.partyName || row.partyName, partyTin: o.partyTin, nature: o.nature || row.nature,
      grossAmount: o.grossAmount, rate: o.rate, taxAmount: o.taxAmount, levyAmount: o.levyAmount,
      reference: o.reference, status: o.status || row.status, note: o.note,
      date: o.date || row.date, period: o.period || row.period,
    };
  });
  for (const e of mine.filter((e) => e.source === 'manual')) {
    merged.push({
      key: `manual:${e.id}`, kind, source: 'manual', entryId: e.id, edited: false,
      period: e.period, date: e.date, docNo: e.docNo, partyName: e.partyName, partyTin: e.partyTin, nature: e.nature,
      grossAmount: e.grossAmount, rate: e.rate, taxAmount: e.taxAmount, levyAmount: e.levyAmount,
      reference: e.reference, status: e.status, note: e.note,
    });
  }
  return merged.sort((a, b) => a.date.localeCompare(b.date) || a.docNo.localeCompare(b.docNo));
}

export interface ScheduleTotals {
  gross: number;
  tax: number;
  levy: number;
  count: number;
}

export function scheduleTotals(rows: ScheduleRow[]): ScheduleTotals {
  return {
    gross: r2(rows.reduce((s, r) => s + r.grossAmount, 0)),
    tax: r2(rows.reduce((s, r) => s + r.taxAmount, 0)),
    levy: r2(rows.reduce((s, r) => s + r.levyAmount, 0)),
    count: rows.length,
  };
}

/** Net movement on a liability account within a period: credits − debits (remittances are debits). */
export function periodRemitted(lines: ACDOCALine[], clientId: number, period: string, accountNo: string): number {
  return r2(lines.filter((l) => l.clientId === clientId && l.period === period && l.accountNo === accountNo && l.docNo.startsWith('STAT-')).reduce((s, l) => s + l.debit - l.credit, 0));
}

/** Cumulative balance of a liability account through the end of a period (credit-normal, positive = payable). */
export function liabilityBalanceThrough(lines: ACDOCALine[], clientId: number, period: string, accountNo: string): number {
  return r2(lines.filter((l) => l.clientId === clientId && l.period <= period && l.accountNo === accountNo).reduce((s, l) => s + l.credit - l.debit, 0));
}
