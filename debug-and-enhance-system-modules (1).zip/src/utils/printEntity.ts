import type { PrintEntity } from './printReport';

/**
 * Letterhead details for a printed report: the entity's registered legal
 * profile (TIN, VAT number, address) when one has been saved, otherwise the
 * workspace master record. Structural types keep this free of UI imports.
 */
export function toPrintEntity(
  client: { name: string; code: string; currency: string },
  profile?: { legalName?: string; tin?: string; vatRegNo?: string; address?: string; phone?: string; email?: string } | null
): PrintEntity {
  return {
    name: client.name,
    code: client.code,
    currency: client.currency,
    legalName: profile?.legalName || undefined,
    tin: profile?.tin || undefined,
    vatRegNo: profile?.vatRegNo || undefined,
    address: profile?.address || undefined,
    phone: profile?.phone || undefined,
    email: profile?.email || undefined,
  };
}
