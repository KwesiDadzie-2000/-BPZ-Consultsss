/**
 * Report printing — prints ONE report, not the workspace.
 *
 * The previous print path relied on `window.print()` plus a global print
 * stylesheet, so the browser printed whatever was on screen: the active page,
 * every card on it, banners and all. Owners and clients need a clean statutory
 * working paper for exactly the report they are looking at.
 *
 * `printReport()` renders the report into an isolated, self-contained HTML
 * document (entity letterhead, title, period, tables, totals, signature block)
 * inside a hidden iframe and prints THAT document only. Nothing from the
 * application shell is included. A pop-up window is used only as a fallback
 * when iframes are unavailable.
 */

export interface PrintColumn {
  key: string;
  label: string;
  align?: 'left' | 'right' | 'center';
  width?: string;
  /** Format numbers with thousands separators and two decimals. */
  numeric?: boolean;
}

export interface PrintSection {
  title?: string;
  subtitle?: string;
  columns: PrintColumn[];
  rows: Record<string, string | number | null | undefined>[];
  /** Optional totals row rendered in bold under the table. */
  totals?: Record<string, string | number | null | undefined>;
  /** Optional highlighted rows by index (e.g. subtotals). */
  emphasise?: (rowIndex: number) => boolean;
  note?: string;
}

export interface PrintEntity {
  name: string;
  code: string;
  currency: string;
  legalName?: string;
  tin?: string;
  vatRegNo?: string;
  address?: string;
  phone?: string;
  email?: string;
}

export interface PrintStat {
  label: string;
  value: string | number;
}

export interface PrintReportSpec {
  title: string;
  subtitle?: string;
  kicker?: string;
  entity: PrintEntity;
  periodLabel: string;
  preparedBy: string;
  sections: PrintSection[];
  stats?: PrintStat[];
  footerNote?: string;
  orientation?: 'portrait' | 'landscape';
  /** Optional free-form HTML-escaped paragraphs printed before the tables. */
  paragraphs?: string[];
}

const esc = (v: unknown): string =>
  String(v ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

const money = (n: number): string =>
  n.toLocaleString('en-GH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const cellText = (value: string | number | null | undefined, numeric?: boolean): string => {
  if (value === null || value === undefined || value === '') return numeric ? '' : '';
  if (typeof value === 'number') return numeric || Number.isFinite(value) ? money(value) : String(value);
  return String(value);
};

function sectionHtml(section: PrintSection): string {
  const head = section.columns
    .map((c) => `<th style="text-align:${c.align ?? (c.numeric ? 'right' : 'left')};${c.width ? `width:${c.width};` : ''}">${esc(c.label)}</th>`)
    .join('');
  const body = section.rows.length
    ? section.rows
        .map((row, i) => {
          const strong = section.emphasise?.(i) ? ' class="em"' : '';
          const tds = section.columns
            .map((c) => `<td style="text-align:${c.align ?? (c.numeric ? 'right' : 'left')}"${c.numeric ? ' class="num"' : ''}>${esc(cellText(row[c.key], c.numeric))}</td>`)
            .join('');
          return `<tr${strong}>${tds}</tr>`;
        })
        .join('')
    : `<tr><td colspan="${section.columns.length}" class="empty">No entries for the selected criteria.</td></tr>`;
  const totals = section.totals
    ? `<tr class="totals">${section.columns
        .map((c) => `<td style="text-align:${c.align ?? (c.numeric ? 'right' : 'left')}"${c.numeric ? ' class="num"' : ''}>${esc(cellText(section.totals![c.key], c.numeric))}</td>`)
        .join('')}</tr>`
    : '';
  return `
    <section class="block">
      ${section.title ? `<h2>${esc(section.title)}</h2>` : ''}
      ${section.subtitle ? `<p class="sub">${esc(section.subtitle)}</p>` : ''}
      <table>
        <thead><tr>${head}</tr></thead>
        <tbody>${body}${totals}</tbody>
      </table>
      ${section.note ? `<p class="note">${esc(section.note)}</p>` : ''}
    </section>`;
}

/** Builds the stand-alone HTML document for a report. Exported for tests. */
export function buildReportHtml(spec: PrintReportSpec): string {
  const e = spec.entity;
  const printedAt = new Date().toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' });
  const stats = spec.stats?.length
    ? `<div class="stats">${spec.stats
        .map((s) => `<div class="stat"><div class="label">${esc(s.label)}</div><div class="value">${esc(typeof s.value === 'number' ? money(s.value) : s.value)}</div></div>`)
        .join('')}</div>`
    : '';
  const paragraphs = spec.paragraphs?.length ? spec.paragraphs.map((p) => `<p class="para">${esc(p)}</p>`).join('') : '';
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${esc(spec.title)} — ${esc(e.code)}</title>
<style>
  @page { size: A4 ${spec.orientation === 'landscape' ? 'landscape' : 'portrait'}; margin: 14mm 12mm 16mm 12mm; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; background: #fff; }
  body { font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; color: #0a253e; font-size: 10.5pt; line-height: 1.35; }
  .letterhead { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; border-bottom: 2px solid #082f4f; padding-bottom: 8px; margin-bottom: 10px; }
  .brand { display: flex; gap: 10px; align-items: center; }
  .mark { width: 38px; height: 38px; border-radius: 8px; background: #f5b719; color: #082f4f; font-weight: 900; display: flex; align-items: center; justify-content: center; font-size: 12pt; }
  .firm { font-weight: 800; letter-spacing: .04em; font-size: 10pt; color: #082f4f; }
  .firm small { display: block; font-weight: 600; color: #855b00; letter-spacing: .08em; text-transform: uppercase; font-size: 7.5pt; }
  .entity { text-align: right; font-size: 9pt; color: #2d4f6d; }
  .entity b { display: block; font-size: 11pt; color: #082f4f; }
  .kicker { font-size: 8pt; font-weight: 800; letter-spacing: .12em; text-transform: uppercase; color: #855b00; }
  h1 { font-size: 16pt; margin: 2px 0 2px; color: #082f4f; }
  .subtitle { margin: 0 0 6px; color: #2d4f6d; font-size: 9.5pt; }
  .meta { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px 14px; font-size: 8.5pt; color: #2d4f6d; border: 1px solid #cfe0f1; border-radius: 6px; padding: 6px 10px; margin-bottom: 10px; background: #f7fbff; }
  .meta b { color: #0a253e; }
  .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin: 8px 0 12px; }
  .stat { border: 1px solid #cfe0f1; border-radius: 6px; padding: 6px 8px; }
  .stat .label { font-size: 7.5pt; text-transform: uppercase; letter-spacing: .06em; color: #2d4f6d; font-weight: 700; }
  .stat .value { font-family: "JetBrains Mono", Consolas, monospace; font-weight: 800; font-size: 11pt; margin-top: 2px; }
  .block { margin: 10px 0 14px; page-break-inside: auto; }
  h2 { font-size: 11pt; margin: 0 0 2px; color: #082f4f; }
  .sub { margin: 0 0 6px; font-size: 8.5pt; color: #2d4f6d; }
  table { width: 100%; border-collapse: collapse; font-size: 8.8pt; }
  thead { display: table-header-group; }
  th { background: #e9f2fb; color: #163653; text-transform: uppercase; letter-spacing: .05em; font-size: 7.6pt; padding: 5px 6px; border-bottom: 1px solid #b5d1ec; }
  td { padding: 4px 6px; border-bottom: 1px solid #e3eef9; vertical-align: top; }
  td.num { font-family: "JetBrains Mono", Consolas, monospace; font-variant-numeric: tabular-nums; white-space: nowrap; }
  tr { page-break-inside: avoid; }
  tr.em td { font-weight: 700; background: #f3f9ff; }
  tr.totals td { font-weight: 800; border-top: 2px solid #082f4f; border-bottom: 2px double #082f4f; background: #eef6fc; }
  td.empty { text-align: center; color: #355875; font-style: italic; padding: 14px; }
  .note, .para { font-size: 8.5pt; color: #2d4f6d; margin: 6px 0 0; }
  .para { margin-bottom: 6px; }
  .sign { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-top: 26px; page-break-inside: avoid; }
  .sign div { border-top: 1px solid #355875; padding-top: 4px; font-size: 8pt; color: #2d4f6d; }
  .foot { margin-top: 14px; font-size: 7.8pt; color: #355875; border-top: 1px solid #cfe0f1; padding-top: 6px; display: flex; justify-content: space-between; gap: 12px; }
  @media screen { body { padding: 20px; max-width: 1100px; margin: 0 auto; } }
</style>
</head>
<body>
  <header class="letterhead">
    <div class="brand">
      <div class="mark">BPZ</div>
      <div class="firm">BPZ CONSULT<small>Accounting · Tax · Payroll · IFRS</small></div>
    </div>
    <div class="entity">
      <b>${esc(e.legalName || e.name)}</b>
      ${e.legalName && e.legalName !== e.name ? `<span>${esc(e.name)} · </span>` : ''}<span>Entity ${esc(e.code)} · Reporting currency ${esc(e.currency)}</span>
      ${e.tin ? `<br/>TIN ${esc(e.tin)}` : ''}${e.vatRegNo ? ` · VAT ${esc(e.vatRegNo)}` : ''}
      ${e.address ? `<br/>${esc(e.address)}` : ''}
      ${e.phone || e.email ? `<br/>${esc([e.phone, e.email].filter(Boolean).join(' · '))}` : ''}
    </div>
  </header>
  ${spec.kicker ? `<div class="kicker">${esc(spec.kicker)}</div>` : ''}
  <h1>${esc(spec.title)}</h1>
  ${spec.subtitle ? `<p class="subtitle">${esc(spec.subtitle)}</p>` : ''}
  <div class="meta">
    <div>Period: <b>${esc(spec.periodLabel)}</b></div>
    <div>Prepared by: <b>${esc(spec.preparedBy)}</b></div>
    <div>Printed: <b>${esc(printedAt)}</b></div>
  </div>
  ${stats}
  ${paragraphs}
  ${spec.sections.map(sectionHtml).join('')}
  <div class="sign">
    <div>Prepared by</div>
    <div>Reviewed by</div>
    <div>Approved by (date &amp; signature)</div>
  </div>
  <footer class="foot">
    <span>${esc(spec.footerNote || 'Generated from posted journal entries held on the BPZ Consult server. Figures are management working papers until reviewed and signed.')}</span>
    <span>${esc(e.code)} · ${esc(spec.title)}</span>
  </footer>
</body>
</html>`;
}

/**
 * Prints the given report in an isolated document. Returns false when the
 * environment has no document (e.g. tests) so callers can fall back gracefully.
 */
export function printReport(spec: PrintReportSpec): boolean {
  if (typeof document === 'undefined' || typeof window === 'undefined') return false;
  const html = buildReportHtml(spec);
  try {
    const frame = document.createElement('iframe');
    frame.setAttribute('aria-hidden', 'true');
    frame.title = `Print — ${spec.title}`;
    frame.style.position = 'fixed';
    frame.style.right = '0';
    frame.style.bottom = '0';
    frame.style.width = '0';
    frame.style.height = '0';
    frame.style.border = '0';
    frame.style.opacity = '0';
    document.body.appendChild(frame);
    const cleanup = () => { setTimeout(() => { try { frame.remove(); } catch { /* ignore */ } }, 1500); };
    const doPrint = () => {
      const w = frame.contentWindow;
      if (!w) { cleanup(); return; }
      try {
        w.addEventListener('afterprint', cleanup, { once: true });
        w.focus();
        w.print();
      } catch {
        cleanup();
      }
      // Browsers that never fire afterprint (or where print is cancelled) still get cleaned up.
      setTimeout(cleanup, 60_000);
    };
    frame.onload = doPrint;
    const doc = frame.contentDocument || frame.contentWindow?.document;
    if (!doc) throw new Error('no-frame-document');
    doc.open();
    doc.write(html);
    doc.close();
    return true;
  } catch {
    // Fallback: a pop-up with the same stand-alone document.
    const w = window.open('', '_blank', 'noopener,noreferrer,width=1024,height=768');
    if (!w) return false;
    w.document.open();
    w.document.write(html);
    w.document.close();
    w.focus();
    setTimeout(() => { try { w.print(); } catch { /* ignore */ } }, 250);
    return true;
  }
}

/** Downloads an array of rows as CSV (shared by report desks). */
export function downloadCsv(fileName: string, rows: (string | number | null | undefined)[][]): void {
  if (typeof document === 'undefined') return;
  const cell = (s: string | number | null | undefined) => `"${String(s ?? '').replace(/"/g, '""')}"`;
  const csv = rows.map((r) => r.map(cell).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
