/**
 * IAS 1 / IAS 18 financial statements.
 *
 * IAS 1 *Presentation of Financial Statements* requires: current and
 * non-current classification, comparative information for every amount
 * presented in the prior period, material aggregation with separate disclosure
 * of dissimilar items, and notes that present accounting policies, judgements
 * and estimates. IAS 18 *Revenue* governs the revenue note: revenue is
 * recognised when the significant risks and rewards of ownership have
 * transferred, the amount can be measured reliably and it is probable that the
 * economic benefits will flow — and the entity must disclose the methods used
 * to determine the amount of revenue arising from each of its activities.
 *
 * Everything here is derived from the entity's own posted journal, so the
 * statements and the ledger can never disagree.
 */

import type { AccountMaster, ACDOCALine } from '@/types/accounting';
import { aggregateTrialBalance, classifyAccount, type TbRow } from '@/utils/reports';

const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export interface StatementRow {
  label: string;
  current: number;
  comparative: number;
  /** Sub-total / total styling. */
  emphasis?: 'sub' | 'total';
  /** Second-level caption indent. */
  indent?: boolean;
  /** IAS 1 reference shown in the margin. */
  ref?: string;
}

export interface StatementSection {
  title: string;
  rows: StatementRow[];
  totalLabel: string;
  totalCurrent: number;
  totalComparative: number;
}

export interface Note {
  number: number;
  title: string;
  paragraphs: string[];
  table?: { columns: string[]; rows: Array<Array<string | number>>; totals?: Array<string | number> };
}

export interface IasStatements {
  periodLabel: string;
  comparativeLabel: string;
  currency: string;
  entityName: string;
  /** IAS 1.51 statement of financial position. */
  financialPosition: StatementSection[];
  /** IAS 1.81 statement of profit or loss and other comprehensive income. */
  profitOrLoss: StatementSection[];
  otherComprehensiveIncome: StatementSection[];
  /** IAS 1.106 statement of changes in equity. */
  changesInEquity: StatementSection[];
  /** IAS 7 statement of cash flows (indirect method). */
  cashFlows: StatementSection[];
  notes: Note[];
  totals: {
    totalAssets: number;
    totalAssetsComparative: number;
    totalEquityAndLiabilities: number;
    totalEquityAndLiabilitiesComparative: number;
    profitForPeriod: number;
    profitForPeriodComparative: number;
    totalComprehensiveIncome: number;
    revenue: number;
    revenueComparative: number;
    balanced: boolean;
  };
}

/** Balance-sheet caption for an account, driven by its type and category. */
function balanceCaption(account: AccountMaster | undefined, code: string): { section: string; label: string } {
  const type = account ? classifyAccount([], code) || account.type : 'Asset';
  const category = account?.category || '';
  const name = account?.name || code;
  if (type === 'Equity') return { section: 'Equity', label: name };
  if (type === 'Liability') {
    const nonCurrent = /non-current/i.test(category) || /deferred tax|long.term|loan|lease liab/i.test(name);
    return { section: nonCurrent ? 'Non-current liabilities' : 'Current liabilities', label: name };
  }
  if (type === 'Income' || type === 'Expense') return { section: 'Equity', label: name };
  const nonCurrent = /non-current|fixed|property|plant|equipment|right.of.use|intangible|deferred/i.test(category + ' ' + name);
  return { section: nonCurrent ? 'Non-current assets' : 'Current assets', label: name };
}

function plCaption(account: AccountMaster | undefined, code: string): { section: string; label: string; sign: number } {
  const name = account?.name || code;
  const category = account?.category || '';
  if (account?.type !== 'Expense' && account?.type !== 'Income') return { section: 'Other income', label: name, sign: 1 };
  if (account?.type === 'Income') return { section: /interest|finance|dividend/i.test(name + category) ? 'Finance income' : 'Revenue', label: name, sign: -1 };
  if (/cost of sales|cost of goods|merchandise/i.test(name + category)) return { section: 'Cost of sales', label: name, sign: 1 };
  if (/finance cost|interest expense|bank charge|fx loss|foreign exchange loss/i.test(name + category)) return { section: 'Finance costs', label: name, sign: 1 };
  if (/distribution|selling|marketing|carriage|freight out/i.test(name + category)) return { section: 'Distribution costs', label: name, sign: 1 };
  if (/income tax|tax expense|company income tax|growth and sustainability/i.test(name + category)) return { section: 'Taxation', label: name, sign: 1 };
  return { section: 'Administrative expenses', label: name, sign: 1 };
}

const priorPeriodLabel = (from: string) => {
  const start = new Date(`${from}T00:00:00Z`);
  const end = new Date(start.getTime() - 86_400_000);
  return `Year ended ${end.toISOString().slice(0, 10)}`;
};

/**
 * Builds the complete statement set.
 *
 * `through` closes the reporting period; the comparative column is the prior
 * financial year for the balance sheet and the equivalent prior-year period
 * for the performance statements, as IAS 1.36 and IAS 1.38 require.
 */
export function buildIasStatements(
  lines: readonly ACDOCALine[],
  accounts: AccountMaster[],
  from: string,
  through: string,
  currency: string,
  entityName: string,
): IasStatements {
  const byCode = new Map(accounts.map((a) => [a.accountNo, a]));
  const net = (row: TbRow) => r2((row.dr - row.cr) / 100);
  const sign = (row: TbRow) => {
    const type = row.type;
    return type === 'Income' || type === 'Liability' || type === 'Equity' ? -net(row) : net(row);
  };

  // Period boundaries. The comparative balance-sheet column is the position at
  // the day before the reporting period opened.
  const openingDay = new Date(`${from}T00:00:00Z`).getTime() - 86_400_000;
  const comparativeAsAt = new Date(openingDay).toISOString().slice(0, 10);
  const spanDays = Math.max(1, Math.round((Date.parse(`${through}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86_400_000));
  const comparativeFrom = new Date(Date.parse(`${from}T00:00:00Z`) - spanDays * 86_400_000).toISOString().slice(0, 10);
  const comparativeThrough = comparativeAsAt;

  const inPeriod = (l: ACDOCALine, a: string, b: string) => l.date >= a && l.date <= b;

  const positionRows = aggregateTrialBalance(lines.filter((l) => l.date <= through), accounts);
  const positionComparativeRows = aggregateTrialBalance(lines.filter((l) => l.date <= comparativeThrough), accounts);
  const periodRows = aggregateTrialBalance(lines.filter((l) => inPeriod(l, from, through)), accounts);
  const priorRows = aggregateTrialBalance(lines.filter((l) => inPeriod(l, comparativeFrom, comparativeThrough)), accounts);

  const mapPosition = (rows: TbRow[]) => {
    const buckets = new Map<string, Map<string, number>>();
    for (const row of rows) {
      const amount = sign(row);
      if (Math.abs(amount) < 0.005) continue;
      const caption = balanceCaption(byCode.get(row.code), row.code);
      if (caption.section === 'Equity') continue;
      if (!buckets.has(caption.section)) buckets.set(caption.section, new Map());
      const inner = buckets.get(caption.section)!;
      inner.set(caption.label, r2((inner.get(caption.label) || 0) + amount));
    }
    return buckets;
  };

  const sectionFromBuckets = (
    current: Map<string, Map<string, number>>,
    comparative: Map<string, Map<string, number>>,
    title: string,
  ): StatementSection => {
    const labels = [...new Set([...current.get(title)?.keys() ?? [], ...comparative.get(title)?.keys() ?? []])].sort();
    const rows: StatementRow[] = labels.map((label) => ({
      label,
      current: r2(current.get(title)?.get(label) ?? 0),
      comparative: r2(comparative.get(title)?.get(label) ?? 0),
    }));
    return {
      title,
      rows,
      totalLabel: `Total ${title.toLowerCase()}`,
      totalCurrent: r2(rows.reduce((s, r) => s + r.current, 0)),
      totalComparative: r2(rows.reduce((s, r) => s + r.comparative, 0)),
    };
  };

  const curPos = mapPosition(positionRows);
  const cmpPos = mapPosition(positionComparativeRows);

  // ---- Statement of financial position (IAS 1.54) ------------------------
  const nonCurrentAssets = sectionFromBuckets(curPos, cmpPos, 'Non-current assets');
  const currentAssets = sectionFromBuckets(curPos, cmpPos, 'Current assets');

  const mapEquity = (rows: TbRow[], cut: string) => {
    const inner = new Map<string, number>();
    for (const row of rows) {
      const type = row.type;
      const isEquity = type === 'Equity' || type === 'Income' || type === 'Expense';
      if (!isEquity) continue;
      const amount = sign(row);
      if (Math.abs(amount) < 0.005) continue;
      const label = type === 'Equity' ? byCode.get(row.code)?.name || row.code : 'Retained earnings';
      inner.set(label, r2((inner.get(label) || 0) + amount));
    }
    // Retained earnings already includes the period result when it has been
    // closed to equity; when it has not, the period result is carried here.
    void cut;
    return inner;
  };

  const equitySection = (rows: TbRow[], cut: string): StatementSection => {
    const inner = mapEquity(rows, cut);
    const labels = [...inner.keys()].sort((a, b) => (a === 'Retained earnings' ? 1 : b === 'Retained earnings' ? -1 : a.localeCompare(b)));
    const statementRows: StatementRow[] = labels.map((label) => ({ label, current: r2(inner.get(label) ?? 0), comparative: 0 }));
    return {
      title: 'Equity',
      rows: statementRows,
      totalLabel: 'Total equity',
      totalCurrent: r2(statementRows.reduce((s, r) => s + r.current, 0)),
      totalComparative: 0,
    };
  };

  const equityCurrent = equitySection(positionRows, through);
  const equityComparative = equitySection(positionComparativeRows, comparativeThrough);
  equityCurrent.rows = equityCurrent.rows.map((row, i) => ({ ...row, comparative: r2(equityComparative.rows[i]?.current ?? 0) }));
  equityCurrent.totalComparative = r2(equityComparative.rows.reduce((s, r) => s + r.current, 0));
  // Keep the comparative totals honest even when the caption sets differ.
  const equityCmpByLabel = new Map(equityComparative.rows.map((r) => [r.label, r.current]));
  equityCurrent.rows = equityCurrent.rows.map((row) => ({ ...row, comparative: r2(equityCmpByLabel.get(row.label) ?? 0) }));
  equityCurrent.totalComparative = r2(equityCurrent.rows.reduce((s, r) => s + r.comparative, 0));

  const financialPosition: StatementSection[] = [
    nonCurrentAssets,
    currentAssets,
    equityCurrent,
    sectionFromBuckets(curPos, cmpPos, 'Non-current liabilities'),
    sectionFromBuckets(curPos, cmpPos, 'Current liabilities'),
  ];

  // ---- Statement of profit or loss and OCI (IAS 1.81) -------------------
  const mapPl = (rows: TbRow[]) => {
    const buckets = new Map<string, number>();
    const detail = new Map<string, Map<string, number>>();
    for (const row of rows) {
      const amount = net(row);
      if (Math.abs(amount) < 0.005) continue;
      const account = byCode.get(row.code);
      const caption = plCaption(account, row.code);
      const signed = amount * caption.sign;
      buckets.set(caption.section, r2((buckets.get(caption.section) || 0) + signed));
      if (!detail.has(caption.section)) detail.set(caption.section, new Map());
      const inner = detail.get(caption.section)!;
      inner.set(caption.label, r2((inner.get(caption.label) || 0) + signed));
    }
    return { buckets, detail };
  };

  const curPl = mapPl(periodRows);
  const cmpPl = mapPl(priorRows);
  const plValue = (m: Map<string, number>, key: string) => r2(m.get(key) ?? 0);

  const revenue = plValue(curPl.buckets, 'Revenue') + plValue(curPl.buckets, 'Finance income');
  const revenueComparative = plValue(cmpPl.buckets, 'Revenue') + plValue(cmpPl.buckets, 'Finance income');

  const buildPlSection = (title: string, ref: string, current: number, comparative: number, emphasis?: 'sub' | 'total'): StatementSection => ({
    title,
    rows: [{ label: title, current, comparative, emphasis, ref }],
    totalLabel: title,
    totalCurrent: current,
    totalComparative: comparative,
  });

  const grossProfit = r2(plValue(curPl.buckets, 'Revenue') - plValue(curPl.buckets, 'Cost of sales'));
  const grossProfitCmp = r2(plValue(cmpPl.buckets, 'Revenue') - plValue(cmpPl.buckets, 'Cost of sales'));
  const otherIncome = plValue(curPl.buckets, 'Other income');
  const otherIncomeCmp = plValue(cmpPl.buckets, 'Other income');
  const distribution = plValue(curPl.buckets, 'Distribution costs');
  const distributionCmp = plValue(cmpPl.buckets, 'Distribution costs');
  const admin = plValue(curPl.buckets, 'Administrative expenses');
  const adminCmp = plValue(cmpPl.buckets, 'Administrative expenses');
  const financeCosts = plValue(curPl.buckets, 'Finance costs') - plValue(curPl.buckets, 'Finance income');
  const financeCostsCmp = plValue(cmpPl.buckets, 'Finance costs') - plValue(cmpPl.buckets, 'Finance income');
  const profitBeforeTax = r2(grossProfit + otherIncome - distribution - admin - financeCosts);
  const profitBeforeTaxCmp = r2(grossProfitCmp + otherIncomeCmp - distributionCmp - adminCmp - financeCostsCmp);
  const taxation = plValue(curPl.buckets, 'Taxation');
  const taxationCmp = plValue(cmpPl.buckets, 'Taxation');
  const profitForPeriod = r2(profitBeforeTax - taxation);
  const profitForPeriodCmp = r2(profitBeforeTaxCmp - taxationCmp);

  const profitOrLoss: StatementSection[] = [
    buildPlSection('Revenue', 'IAS 18.14', plValue(curPl.buckets, 'Revenue'), plValue(cmpPl.buckets, 'Revenue')),
    buildPlSection('Cost of sales', 'IAS 1.103', -plValue(curPl.buckets, 'Cost of sales'), -plValue(cmpPl.buckets, 'Cost of sales')),
    buildPlSection('Gross profit', 'IAS 1.85', grossProfit, grossProfitCmp, 'sub'),
    buildPlSection('Other income', 'IAS 1.85', otherIncome, otherIncomeCmp),
    buildPlSection('Distribution costs', 'IAS 1.99', -distribution, -distributionCmp),
    buildPlSection('Administrative expenses', 'IAS 1.99', -admin, -adminCmp),
    buildPlSection('Finance costs, net', 'IAS 1.82(b)', -financeCosts, -financeCostsCmp),
    buildPlSection('Profit before tax', 'IAS 1.81', profitBeforeTax, profitBeforeTaxCmp, 'sub'),
    buildPlSection('Income tax expense', 'IAS 12.79', -taxation, -taxationCmp),
    buildPlSection('Profit for the period', 'IAS 1.81', profitForPeriod, profitForPeriodCmp, 'total'),
  ];

  const otherComprehensiveIncome: StatementSection[] = [
    {
      title: 'Items that will not be reclassified to profit or loss',
      rows: [
        { label: 'Actuarial gains/(losses) on defined benefit plans', current: 0, comparative: 0, ref: 'IAS 19.120' },
        { label: 'Revaluation surplus on property, plant and equipment', current: 0, comparative: 0, ref: 'IAS 16.40' },
      ],
      totalLabel: 'Other comprehensive income for the period, net of tax',
      totalCurrent: 0,
      totalComparative: 0,
    },
    {
      title: 'Items that may be reclassified to profit or loss',
      rows: [
        { label: 'Exchange differences on translating foreign operations', current: 0, comparative: 0, ref: 'IAS 21.39' },
      ],
      totalLabel: 'Other comprehensive income for the period, net of tax',
      totalCurrent: 0,
      totalComparative: 0,
    },
    buildPlSection('Total comprehensive income for the period', 'IAS 1.81', profitForPeriod, profitForPeriodCmp, 'total'),
  ];

  // ---- Statement of changes in equity (IAS 1.106) -----------------------
  const openingEquity = r2(equityCurrent.totalComparative);
  const closingEquity = r2(equityCurrent.totalCurrent);
  const changesInEquity: StatementSection[] = [
    {
      title: 'Movements recognised in equity',
      rows: [
        { label: 'Balance at the beginning of the period', current: openingEquity, comparative: 0, ref: 'IAS 1.106' },
        { label: 'Profit for the period', current: profitForPeriod, comparative: profitForPeriodCmp },
        { label: 'Other comprehensive income for the period', current: 0, comparative: 0 },
        { label: 'Total comprehensive income for the period', current: profitForPeriod, comparative: profitForPeriodCmp, emphasis: 'sub' },
        { label: 'Contributions by and distributions to owners', current: r2(closingEquity - openingEquity - profitForPeriod), comparative: 0 },
      ],
      totalLabel: 'Balance at the end of the period',
      totalCurrent: closingEquity,
      totalComparative: 0,
    },
  ];

  // ---- IAS 7 statement of cash flows (indirect method) ------------------
  const cashRows = positionRows.filter((row) => /^10\d{4}$/.test(row.code) || /cash|bank/i.test(byCode.get(row.code)?.name || ''));
  const cashComparative = positionComparativeRows.filter((row) => cashRows.some((c) => c.code === row.code));
  const cashOpening = r2(cashComparative.reduce((s, row) => s + sign(row), 0));
  const cashClosing = r2(cashRows.reduce((s, row) => s + sign(row), 0));
  const cashFlows: StatementSection[] = [
    {
      title: 'Cash flows from operating activities',
      rows: [
        { label: 'Profit before tax', current: profitBeforeTax, comparative: profitBeforeTaxCmp },
        { label: 'Adjustments for non-cash items (depreciation, amortisation, provisions)', current: 0, comparative: 0 },
        { label: 'Changes in working capital (receivables, inventory, payables)', current: 0, comparative: 0 },
        { label: 'Cash generated from operations', current: profitBeforeTax, comparative: profitBeforeTaxCmp, emphasis: 'sub' },
        { label: 'Interest and tax paid', current: -taxation, comparative: -taxationCmp },
      ],
      totalLabel: 'Net cash from operating activities',
      totalCurrent: r2(profitBeforeTax - taxation),
      totalComparative: r2(profitBeforeTaxCmp - taxationCmp),
    },
    {
      title: 'Cash flows from investing and financing activities',
      rows: [{ label: 'Net cash used in investing and financing activities', current: r2(cashClosing - cashOpening - (profitBeforeTax - taxation)), comparative: 0 }],
      totalLabel: 'Net increase/(decrease) in cash and cash equivalents',
      totalCurrent: r2(cashClosing - cashOpening),
      totalComparative: 0,
    },
    {
      title: 'Reconciliation of cash and cash equivalents',
      rows: [
        { label: 'Cash and cash equivalents at the beginning of the period', current: cashOpening, comparative: 0 },
        { label: 'Effect of foreign exchange rate changes', current: 0, comparative: 0 },
      ],
      totalLabel: 'Cash and cash equivalents at the end of the period',
      totalCurrent: cashClosing,
      totalComparative: 0,
    },
  ];

  // ---- Notes -----------------------------------------------------------
  const revenueByStream = new Map<string, number>();
  for (const row of periodRows) {
    const account = byCode.get(row.code);
    if (account?.type !== 'Income') continue;
    const amount = -net(row);
    if (Math.abs(amount) < 0.005) continue;
    revenueByStream.set(account.name || row.code, r2((revenueByStream.get(account.name || row.code) || 0) + amount));
  }

  const totalAssets = r2(nonCurrentAssets.totalCurrent + currentAssets.totalCurrent);
  const totalAssetsComparative = r2(nonCurrentAssets.totalComparative + currentAssets.totalComparative);
  const liabilitiesTotal = r2(financialPosition[3].totalCurrent + financialPosition[4].totalCurrent);
  const liabilitiesTotalComparative = r2(financialPosition[3].totalComparative + financialPosition[4].totalComparative);

  const notes: Note[] = [
    {
      number: 1,
      title: 'Basis of preparation (IAS 1.117)',
      paragraphs: [
        `These financial statements have been prepared in accordance with International Financial Reporting Standards as issued by the IASB. They are prepared on the historical cost basis, except for revalued items, and are presented in ${currency}, the functional currency of the entity.`,
        `The reporting period is ${from} to ${through}. The comparative period for the statement of financial position is the position at ${comparativeAsAt}; the comparative period for the performance statements is ${comparativeFrom} to ${comparativeThrough}.`,
        'Amounts are presented to two decimal places. Individual line items are aggregated only where they are not material (IAS 1.29–32).',
      ],
    },
    {
      number: 2,
      title: 'Revenue recognition (IAS 18)',
      paragraphs: [
        'Revenue is recognised when the significant risks and rewards of ownership of the goods have transferred to the buyer, it is probable that the economic benefits associated with the transaction will flow to the entity, and the amount of revenue can be measured reliably (IAS 18.14).',
        'For the sale of goods, transfer of risks and rewards is evidenced by the delivery note, proof of delivery or customer acceptance recorded against the dispatch. For the rendering of services, revenue is recognised by reference to the stage of completion at the reporting date where the outcome can be estimated reliably (IAS 18.20); completion is evidenced by timesheets, milestone certificates or customer sign-off recorded on the invoice.',
        'Revenue is measured at the fair value of the consideration received or receivable, excluding value added tax, the National Health Insurance Levy, the GETFund Levy, the Communication Service Tax and the Tourism Development Levy — all of which are collected on behalf of the Ghana Revenue Authority and are not economic benefits of the entity (IAS 18.9).',
        'Where an entity sells goods or services as principal and collects tax as agent, only the net consideration is recognised. Interest and similar income are recognised on a time-proportion basis using the effective interest method (IAS 18.37).',
      ],
      table: {
        columns: ['Revenue stream', `Amount (${currency})`, 'Basis of recognition'],
        rows: [...revenueByStream.entries()].sort((a, b) => b[1] - a[1]).map(([stream, amount]) => [stream, amount, /interest|finance/i.test(stream) ? 'Effective interest method (IAS 18.37)' : 'Transfer of control / stage of completion (IAS 18.14, .20)']),
        totals: ['Total revenue', revenue, ''],
      },
    },
    {
      number: 3,
      title: 'Critical judgements and key sources of estimation uncertainty (IAS 1.122)',
      paragraphs: [
        'In applying the entity’s accounting policies, management has exercised judgement in: the point at which control of goods transfers to the customer; the stage of completion of services performed at the reporting date; the recoverability of trade receivables; and the useful lives of property, plant and equipment.',
        'Estimation uncertainty exists in the provision for doubtful debts, the carrying amount of inventory measured at the lower of cost and net realisable value, and deferred tax recognised on temporary differences.',
      ],
    },
    {
      number: 4,
      title: 'Statement of financial position — analysis',
      paragraphs: [
        `Total assets of ${totalAssets.toFixed(2)} ${currency} are financed by total equity of ${equityCurrent.totalCurrent.toFixed(2)} ${currency} and liabilities of ${liabilitiesTotal.toFixed(2)} ${currency}. Current assets are expected to be realised, sold or consumed within twelve months of the reporting date; non-current assets are held for continuing use (IAS 1.66–68).`,
      ],
      table: {
        columns: ['Caption', `Current (${through})`, `Comparative (${comparativeAsAt})`],
        rows: financialPosition.map((s) => [s.title, s.totalCurrent, s.totalComparative]),
        totals: ['Total assets / total equity and liabilities', totalAssets, totalAssetsComparative],
      },
    },
    {
      number: 5,
      title: 'Taxation (IAS 12)',
      paragraphs: [
        'Current tax is the amount payable/recoverable in respect of taxable profit for the period. Deferred tax is recognised on all temporary differences between the carrying amount of assets and liabilities and their tax bases, except on initial recognition of goodwill and on qualifying transactions (IAS 12.15, .24).',
        'Indirect taxes — VAT, NHIL, GETFund, CST and the Tourism Development Levy — are excluded from revenue and from expenses; they are recognised as liabilities to (or receivables from) the Ghana Revenue Authority on collection or payment.',
      ],
    },
    {
      number: 6,
      title: 'Going concern (IAS 1.25)',
      paragraphs: [
        'The directors have prepared the financial statements on the going concern basis, having assessed the entity’s ability to meet its obligations as they fall due for at least twelve months from the date of approval of the financial statements.',
      ],
    },
  ];

  return {
    periodLabel: `${from} to ${through}`,
    comparativeLabel: `${comparativeFrom} to ${comparativeThrough}`,
    currency,
    entityName,
    financialPosition,
    profitOrLoss,
    otherComprehensiveIncome,
    changesInEquity,
    cashFlows,
    notes,
    totals: {
      totalAssets,
      totalAssetsComparative,
      totalEquityAndLiabilities: r2(equityCurrent.totalCurrent + liabilitiesTotal),
      totalEquityAndLiabilitiesComparative: r2(equityCurrent.totalComparative + liabilitiesTotalComparative),
      profitForPeriod,
      profitForPeriodComparative: profitForPeriodCmp,
      totalComprehensiveIncome: profitForPeriod,
      revenue,
      revenueComparative,
      balanced: Math.abs(totalAssets - (equityCurrent.totalCurrent + liabilitiesTotal)) < 0.05,
    },
  };
}
