import type { PayeBand, TaxComponent } from '../types/accounting';

export interface TaxSettings {
  version: number;
  jurisdiction: string;
  effectiveFrom: string;
  updatedAt: string;
  payeBands: PayeBand[];
  components: TaxComponent[];
}

const KEY = 'bpz_tax_settings_gh_v1';

// Source: Ghana Revenue Authority pages, checked 2026-10-15:
// PAYE: 2026 bands effective 1 September 2026.
// VAT: Act 1151 effective 1 January 2026, VAT 15% + NHIL 2.5% + GETFund 2.5%.
// CST: 5% (Act 754, amended by Acts 998 & 1025), only Class 1 electronic communications
//      service providers notified by GRA; CST cascades into the VAT base (Act 1151 s.15.3).
// Tourism Levy: 1% (Tourism Act 817) on hospitality accommodation; no VAT-base cascade.
// Income WHT: full Act 896 First Schedule captured - resident goods 3%, works 5%,
//      services 7.5%, royalties/natural resources 15%, dividends 8%, interest 8%,
//      residential rent 8%, commercial rent 15%, director fees 20%, agent commissions 10%,
//      examiner/teacher/endorsement fees 10%, petroleum subcontractors 7.5%,
//      unprocessed precious minerals 3%, realisation of assets/liabilities 3%;
//      non-resident goods/works/services 20%, management/technical fees 20%,
//      royalties/rents 15%, telecom & transport 15%, petroleum subcontractors 15%,
//      insurance premiums 5%, branch repatriation 8%, interest 8%, dividends 8%,
//      realisation 10%.
// VAT WHT: appointed agents withhold 7% of the standard-rated taxable value at payment.
export const DEFAULT_GH_TAX_SETTINGS: TaxSettings = {
  version: 1,
  jurisdiction: 'GH',
  effectiveFrom: '2026-09-01',
  updatedAt: '2026-10-15T00:00:00.000Z',
  payeBands: [
    { id: 'paye-2026-1', name: 'First GH¢588', from: 0, to: 588, rate: 0, effectiveFrom: '2026-09-01', isActive: true },
    { id: 'paye-2026-2', name: 'Next GH¢80', from: 588, to: 668, rate: 5, effectiveFrom: '2026-09-01', isActive: true },
    { id: 'paye-2026-3', name: 'Next GH¢100', from: 668, to: 768, rate: 10, effectiveFrom: '2026-09-01', isActive: true },
    { id: 'paye-2026-4', name: 'Next GH¢2,900', from: 768, to: 3668, rate: 17.5, effectiveFrom: '2026-09-01', isActive: true },
    { id: 'paye-2026-5', name: 'Next GH¢16,000', from: 3668, to: 19668, rate: 25, effectiveFrom: '2026-09-01', isActive: true },
    { id: 'paye-2026-6', name: 'Next GH¢30,332', from: 19668, to: 50000, rate: 30, effectiveFrom: '2026-09-01', isActive: true },
    { id: 'paye-2026-7', name: 'Exceeding GH¢50,000', from: 50000, to: null, rate: 35, effectiveFrom: '2026-09-01', isActive: true },
  ],
  components: [
    { id: 'vat-2026', code: 'VAT', name: 'Value Added Tax', rate: 15, type: 'sales_tax', appliesTo: 'both', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'nhil-2026', code: 'NHIL', name: 'National Health Insurance Levy', rate: 2.5, type: 'sales_tax', appliesTo: 'both', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'getfund-2026', code: 'GETFUND', name: 'GETFund Levy', rate: 2.5, type: 'sales_tax', appliesTo: 'both', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'covid-2026', code: 'COVID', name: 'COVID-19 Health Recovery Levy', rate: 0, type: 'special_levy', appliesTo: 'both', isActive: false, effectiveFrom: '2026-01-01' },
    { id: 'wht-goods-2026', code: 'WHT_GOODS', name: 'Income WHT - resident supply of goods', rate: 3, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-services-2026', code: 'WHT_SERVICES', name: 'Income WHT - resident supply of services', rate: 7.5, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-works-2026', code: 'WHT_WORKS', name: 'Income WHT - resident supply of works', rate: 5, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-prof-2026', code: 'WHT_PROFESSIONAL', name: 'Income WHT - resident professional/technical fee (services)', rate: 7.5, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-nonres-2026', code: 'WHT_NON_RESIDENT', name: 'Income WHT - non-resident goods, works or services', rate: 20, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-interest-2026', code: 'WHT_INTEREST', name: 'Income WHT - interest (excl. individuals & resident financial institutions)', rate: 8, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-dividend-2026', code: 'WHT_DIVIDEND', name: 'Income WHT - dividends (final tax)', rate: 8, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-rent-res-2026', code: 'WHT_RENT_RESIDENTIAL', name: 'Income WHT - rent on residential property (final tax)', rate: 8, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-rent-com-2026', code: 'WHT_RENT_COMMERCIAL', name: 'Income WHT - rent on non-residential property (final tax)', rate: 15, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-royalty-2026', code: 'WHT_ROYALTY', name: 'Income WHT - royalties & natural resource payments', rate: 15, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-director-2026', code: 'WHT_DIRECTOR_FEES', name: 'Income WHT - directors/managers/board members fees (resident individuals)', rate: 20, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-agent-2026', code: 'WHT_AGENT_COMMISSION', name: 'Income WHT - insurance/sales/canvassing/lotto agent commissions (individuals)', rate: 10, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-examiner-2026', code: 'WHT_EXAMINER_TEACHER', name: 'Income WHT - examiners/part-time teachers/lecturers & endorsement fees (final tax)', rate: 10, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-petroleum-sub-2026', code: 'WHT_PETROLEUM_SUB', name: 'Income WHT - payments to petroleum subcontractors (resident)', rate: 7.5, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-precious-2026', code: 'WHT_PRECIOUS_MINERALS', name: 'Income WHT - payments for unprocessed precious minerals', rate: 3, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-realisation-2026', code: 'WHT_REALISATION', name: 'Income WHT - consideration for realisation of assets & liabilities (resident)', rate: 3, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-nonres-royalty-2026', code: 'WHT_NONRES_ROYALTY_RENT', name: 'Income WHT - non-resident royalties, natural resource payments & rents (final tax)', rate: 15, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-nonres-mgmt-2026', code: 'WHT_NONRES_MGMT_TECH', name: 'Income WHT - non-resident management, consulting & technical fees (final tax)', rate: 20, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-nonres-telecom-2026', code: 'WHT_NONRES_TELECOM_TRANSPORT', name: 'Income WHT - non-resident telecom/shipping/air transport income (final tax)', rate: 15, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-nonres-petroleum-2026', code: 'WHT_NONRES_PETROLEUM_SUB', name: 'Income WHT - payments to non-resident petroleum subcontractors (final tax)', rate: 15, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-nonres-insurance-2026', code: 'WHT_NONRES_INSURANCE', name: 'Income WHT - non-resident general insurance premiums (final tax)', rate: 5, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-nonres-branch-2026', code: 'WHT_NONRES_BRANCH', name: 'Income WHT - repatriated branch after-tax profits (final tax)', rate: 8, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-nonres-interest-2026', code: 'WHT_NONRES_INTEREST', name: 'Income WHT - non-resident interest income (final tax)', rate: 8, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-nonres-dividend-2026', code: 'WHT_NONRES_DIVIDEND', name: 'Income WHT - non-resident dividends (final tax)', rate: 8, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'wht-nonres-realisation-2026', code: 'WHT_NONRES_REALISATION', name: 'Income WHT - non-resident realisation of assets & liabilities (final tax)', rate: 10, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'vat-wht-2026', code: 'VAT_WHT', name: 'VAT withholding - 7% of taxable value (appointed agents only)', rate: 7, type: 'withholding_tax', appliesTo: 'purchase', isActive: true, effectiveFrom: '2026-01-01' },
    { id: 'cst-2026', code: 'CST', name: 'Communication Service Tax (Act 754; Class 1 ECS providers notified by GRA)', rate: 5, type: 'special_levy', appliesTo: 'sales', isActive: true, effectiveFrom: '2020-09-15' },
    { id: 'tourism-2026', code: 'TOURISM_LEVY', name: 'Tourism Development Levy (Tourism Act 817; hospitality accommodation)', rate: 1, type: 'special_levy', appliesTo: 'sales', isActive: true, effectiveFrom: '2026-01-01' },
  ],
};

const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v)) as T;

export const taxConfigStore = {
  get(): TaxSettings {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as TaxSettings;
        if (parsed.version === 1 && Array.isArray(parsed.payeBands) && Array.isArray(parsed.components)) return parsed;
      }
    } catch { /* ignore corrupt local settings */ }
    return clone(DEFAULT_GH_TAX_SETTINGS);
  },
  save(settings: TaxSettings) {
    localStorage.setItem(KEY, JSON.stringify({ ...settings, updatedAt: new Date().toISOString() }));
  },
  reset() { localStorage.removeItem(KEY); },
  rate(code: string, onDate = new Date().toISOString().slice(0, 10)) {
    const active = this.get().components.filter(c => c.code === code && c.isActive && c.effectiveFrom <= onDate).sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom))[0];
    return active?.rate ?? 0;
  },
};

export const computeOutputLevies = (taxableValue: number, opts: { cst?: boolean; tourism?: boolean }, onDate?: string) => {
  const rate = (code: string) => taxConfigStore.rate(code, onDate);
  const round = (n: number) => Math.round(n * 100) / 100;
  // CST (Act 754 as amended by Act 998/1025): 5% on the electronic communications service
  // charge, computed on the value excluding VAT, NHIL and GETFund.
  const cst = opts.cst ? taxableValue * rate('CST') / 100 : 0;
  // VAT Act 2025 (Act 1151) s.15.3 / GRA administrative guidelines: where CST applies
  // (electronic communications services), the CST is added to the cost to arrive at the
  // taxable value BEFORE VAT, NHIL and GETFund are charged (CST cascades into the VAT base).
  const vatBase = taxableValue + cst;
  const vat = vatBase * rate('VAT') / 100;
  const nhil = vatBase * rate('NHIL') / 100;
  const getfund = vatBase * rate('GETFUND') / 100;
  // Tourism Development Levy (Tourism Act 817): 1% on hospitality accommodation charges;
  // levy cascading was abolished for qualifying domestic supplies from 1 January 2026,
  // so it is charged on the VAT-exclusive value and does not inflate the VAT base.
  const tourism = opts.tourism ? taxableValue * rate('TOURISM_LEVY') / 100 : 0;
  // Total is the sum of the rounded components so the invoice always adds up to the kobo.
  return {
    vat: round(vat),
    nhil: round(nhil),
    getfund: round(getfund),
    cst: round(cst),
    tourism: round(tourism),
    total: round(round(vat) + round(nhil) + round(getfund) + round(cst) + round(tourism)),
  };
};
