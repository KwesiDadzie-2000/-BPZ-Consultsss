/**
 * Perpetual inventory & trading engine (IAS 2).
 * -----------------------------------------------------------------------------
 * One costing engine shared by purchasing, inventory and sales so quantity and
 * value always move together and the valuation report reconciles to the
 * inventory control account.
 *
 *  Purchase (credit)      Dr Inventory              Cr Trade payables
 *  Inward freight         Dr Inventory              Cr Bank
 *  Sale (credit)          Dr Trade receivables      Cr Revenue (+ tax liabilities)
 *  Related stock issue    Dr Cost of sales          Cr Inventory      (carrying cost)
 *  Write-down to NRV      Dr Write-down expense     Cr Inventory
 *  Customer return        Dr Inventory              Cr Cost of sales  (recoverable cost)
 *
 * A purchase order alone creates no entry; inventory is recognised when control
 * of the goods passes. Money arithmetic is done in minor units (pesewas/cents)
 * so posted amounts are exact.
 */
import type { ACDOCALine, StockItem, StockMovement } from '../types/accounting';
import { uniqueId } from './ids';

export const INVENTORY_ACCOUNT = '120000';
export const INVENTORY_ACCOUNT_NAME = 'Inventories — Raw Materials & Spares';
export const COGS_ACCOUNT = '504000';
export const COGS_ACCOUNT_NAME = 'Cost of Goods Sold — Merchandise';
export const WRITE_DOWN_ACCOUNT = '690000';
export const WRITE_DOWN_ACCOUNT_NAME = 'Impairment Loss on Non-Financial Assets';

export type CostMethod = 'weighted_average' | 'fifo' | 'specific';

/** Exact 2dp rounding through integer minor units — never bare float arithmetic. */
export const money = (value: number): number => Math.round((Number.isFinite(value) ? value : 0) * 100) / 100;
/** Quantities carry 3 decimals (units of measure such as kg / litres). */
export const qty3 = (value: number): number => Math.round((Number.isFinite(value) ? value : 0) * 1000) / 1000;

export interface CostResult {
  /** Carrying cost released from inventory for the issued quantity. */
  cost: number;
  /** Unit cost applied (weighted average, or the FIFO blended rate for the issue). */
  unitCost: number;
  /** Updated item after the movement. */
  item: StockItem;
  error?: string;
}

const valued = (item: StockItem, quantity: number, totalValue: number): StockItem => {
  const q = qty3(quantity);
  const v = money(totalValue);
  return {
    ...item,
    quantityOnHand: q,
    totalValue: v,
    unitCost: q > 0 ? money(v / q) : item.unitCost,
  };
};

/** Goods received: quantity and cost are added; the weighted-average rate re-bases. */
export const applyReceipt = (item: StockItem, quantity: number, unitCost: number): CostResult => {
  if (quantity <= 0) return { cost: 0, unitCost: item.unitCost, item, error: 'Receipt quantity must be positive.' };
  if (unitCost < 0) return { cost: 0, unitCost: item.unitCost, item, error: 'Unit cost cannot be negative.' };
  const addedValue = money(quantity * unitCost);
  const next = valued(item, item.quantityOnHand + quantity, item.totalValue + addedValue);
  return { cost: addedValue, unitCost: next.unitCost, item: next };
};

/**
 * Inward freight and other directly attributable acquisition costs are
 * capitalised into inventory and spread over the quantity on hand (IAS 2.11).
 */
export const applyLandedCost = (item: StockItem, amount: number): CostResult => {
  if (amount <= 0) return { cost: 0, unitCost: item.unitCost, item, error: 'Landed cost must be positive.' };
  if (item.quantityOnHand <= 0) {
    return { cost: 0, unitCost: item.unitCost, item, error: 'Landed cost cannot be capitalised when no stock is on hand — expense it instead.' };
  }
  const next = valued(item, item.quantityOnHand, item.totalValue + amount);
  return { cost: money(amount), unitCost: next.unitCost, item: next };
};

/**
 * FIFO cost of an issue, rebuilt from the item's receipt/return-in movements
 * less quantities already issued. Falls back to the weighted average when the
 * movement history is incomplete (e.g. opening balances loaded as a value).
 */
export const fifoIssueCost = (item: StockItem, movements: StockMovement[], quantity: number): number => {
  const history = movements
    .filter((m) => m.itemCode === item.itemCode && m.clientId === item.clientId)
    .slice()
    .sort((a, b) => (a.date === b.date ? a.id.localeCompare(b.id) : a.date.localeCompare(b.date)));
  const layers: { qty: number; unitCost: number }[] = [];
  const consume = (amount: number): number => {
    let remaining = amount;
    let cost = 0;
    while (remaining > 0.0000001 && layers.length) {
      const layer = layers[0];
      const take = Math.min(layer.qty, remaining);
      cost += take * layer.unitCost;
      layer.qty = qty3(layer.qty - take);
      remaining = qty3(remaining - take);
      if (layer.qty <= 0) layers.shift();
    }
    return cost;
  };
  for (const m of history) {
    if (m.type === 'Receipt' || m.type === 'ReturnIn' || (m.type === 'Adjustment' && m.quantity > 0)) {
      layers.push({ qty: qty3(m.quantity), unitCost: m.unitCost });
    } else if (m.type === 'Freight') {
      const totalQty = layers.reduce((n, l) => n + l.qty, 0);
      if (totalQty > 0) {
        const uplift = m.totalValue / totalQty;
        for (const l of layers) l.unitCost = l.unitCost + uplift;
      }
    } else if (m.type === 'Issue' || m.type === 'ReturnOut' || (m.type === 'Adjustment' && m.quantity < 0)) {
      consume(Math.abs(m.quantity));
    }
  }
  const available = layers.reduce((n, l) => n + l.qty, 0);
  if (available + 0.0001 < quantity) return money(quantity * item.unitCost);
  return money(consume(quantity));
};

/**
 * Stock issue. Negative stock is blocked by default: an unauthorised negative
 * balance makes cost of sales unreliable.
 */
export const applyIssue = (
  item: StockItem,
  quantity: number,
  movements: StockMovement[] = [],
  method: CostMethod = 'weighted_average',
): CostResult => {
  if (quantity <= 0) return { cost: 0, unitCost: item.unitCost, item, error: 'Issue quantity must be positive.' };
  if (quantity > item.quantityOnHand + 0.0001) {
    return {
      cost: 0,
      unitCost: item.unitCost,
      item,
      error: `Only ${item.quantityOnHand} ${item.uom} of ${item.itemCode} on hand — negative stock is blocked.`,
    };
  }
  const cost = method === 'fifo' ? fifoIssueCost(item, movements, quantity) : money(quantity * item.unitCost);
  const cappedCost = Math.min(cost, money(item.totalValue));
  const next = valued(item, item.quantityOnHand - quantity, item.totalValue - cappedCost);
  return { cost: cappedCost, unitCost: quantity > 0 ? money(cappedCost / quantity) : item.unitCost, item: next };
};

/** Lower of cost and net realisable value (IAS 2.9). Returns the write-down required. */
export const nrvWriteDown = (item: StockItem, netRealisableValuePerUnit: number): number => {
  if (item.quantityOnHand <= 0 || netRealisableValuePerUnit < 0) return 0;
  const nrvTotal = money(item.quantityOnHand * netRealisableValuePerUnit);
  const diff = money(item.totalValue - nrvTotal);
  return diff > 0 ? diff : 0;
};

export const applyWriteDown = (item: StockItem, amount: number): CostResult => {
  const capped = Math.min(money(amount), money(item.totalValue));
  if (capped <= 0) return { cost: 0, unitCost: item.unitCost, item, error: 'Write-down must be positive and cannot exceed carrying value.' };
  const next = valued(item, item.quantityOnHand, item.totalValue - capped);
  return { cost: capped, unitCost: next.unitCost, item: next };
};

export interface MovementInput {
  clientId: number;
  date: string;
  item: StockItem;
  type: StockMovement['type'];
  quantity: number;
  unitCost: number;
  totalValue: number;
  docNo?: string;
  reference?: string;
  note?: string;
}

export const buildMovement = (input: MovementInput): StockMovement => ({
  id: uniqueId('SM'),
  clientId: input.clientId,
  date: input.date,
  itemCode: input.item.itemCode,
  description: input.item.description,
  type: input.type,
  quantity: qty3(input.quantity),
  unitCost: money(input.unitCost),
  totalValue: money(input.totalValue),
  uom: input.item.uom,
  docNo: input.docNo,
  reference: input.reference,
  note: input.note,
});

interface EntryContext {
  docNo: string;
  date: string;
  currency: string;
  clientId: number;
  createdBy: string;
  costCenter?: string;
}

const line = (
  ctx: EntryContext,
  accountNo: string,
  accountName: string,
  debit: number,
  credit: number,
  description: string,
  module: ACDOCALine['module'] = 'INV',
  docType: ACDOCALine['docType'] = 'JE',
): ACDOCALine => ({
  id: uniqueId('JL-INV'),
  docNo: ctx.docNo,
  period: ctx.date.slice(0, 7),
  date: ctx.date,
  module,
  docType,
  accountNo,
  accountName,
  costCenter: ctx.costCenter || 'CC-OPS',
  debit: money(debit),
  credit: money(credit),
  currency: ctx.currency,
  description,
  createdBy: ctx.createdBy,
  clientId: ctx.clientId,
});

/** Dr Cost of sales / Cr Inventory — at carrying cost, never at selling price. */
export const buildCogsEntries = (
  ctx: EntryContext,
  cost: number,
  itemCode: string,
  inventoryAccount = INVENTORY_ACCOUNT,
  cogsAccount = COGS_ACCOUNT,
  cogsAccountName = COGS_ACCOUNT_NAME,
): ACDOCALine[] => {
  const amount = money(cost);
  if (amount <= 0) return [];
  return [
    line(ctx, cogsAccount, cogsAccountName, amount, 0, `Cost of sales — ${itemCode} (${ctx.docNo})`, 'INV', 'INV'),
    line(ctx, inventoryAccount, INVENTORY_ACCOUNT_NAME, 0, amount, `Stock issued on ${ctx.docNo} — ${itemCode}`, 'INV', 'INV'),
  ];
};

/** Dr Inventory / Cr Cost of sales — accepted customer return of saleable goods. */
export const buildReturnInEntries = (ctx: EntryContext, cost: number, itemCode: string): ACDOCALine[] => {
  const amount = money(cost);
  if (amount <= 0) return [];
  return [
    line(ctx, INVENTORY_ACCOUNT, INVENTORY_ACCOUNT_NAME, amount, 0, `Goods returned to stock — ${itemCode}`, 'INV', 'INV'),
    line(ctx, COGS_ACCOUNT, COGS_ACCOUNT_NAME, 0, amount, `Reversal of cost of sales — ${itemCode}`, 'INV', 'INV'),
  ];
};

/** Dr Write-down expense / Cr Inventory — measurement to NRV or an approved loss. */
export const buildWriteDownEntries = (ctx: EntryContext, amount: number, itemCode: string, reason: string): ACDOCALine[] => {
  const value = money(amount);
  if (value <= 0) return [];
  return [
    line(ctx, WRITE_DOWN_ACCOUNT, WRITE_DOWN_ACCOUNT_NAME, value, 0, `Inventory write-down ${itemCode} — ${reason}`),
    line(ctx, INVENTORY_ACCOUNT, INVENTORY_ACCOUNT_NAME, 0, value, `Inventory write-down ${itemCode} — ${reason}`),
  ];
};

/** Dr Inventory / Cr Bank — inward freight capitalised into the goods' cost. */
export const buildFreightEntries = (ctx: EntryContext, amount: number, itemCode: string, bankAccount = '100000'): ACDOCALine[] => {
  const value = money(amount);
  if (value <= 0) return [];
  return [
    line(ctx, INVENTORY_ACCOUNT, INVENTORY_ACCOUNT_NAME, value, 0, `Inward freight capitalised — ${itemCode}`, 'MM', 'PO'),
    line(ctx, bankAccount, 'Cash at Bank (Operating)', 0, value, `Inward freight paid — ${itemCode}`, 'MM', 'PO'),
  ];
};

/** Count / shrinkage adjustment. Positive = surplus found, negative = loss. */
export const buildAdjustmentEntries = (ctx: EntryContext, value: number, itemCode: string, reason: string): ACDOCALine[] => {
  const amount = money(Math.abs(value));
  if (amount <= 0) return [];
  return value > 0
    ? [
        line(ctx, INVENTORY_ACCOUNT, INVENTORY_ACCOUNT_NAME, amount, 0, `Stock count surplus ${itemCode} — ${reason}`),
        line(ctx, COGS_ACCOUNT, COGS_ACCOUNT_NAME, 0, amount, `Stock count surplus ${itemCode} — ${reason}`),
      ]
    : [
        line(ctx, WRITE_DOWN_ACCOUNT, WRITE_DOWN_ACCOUNT_NAME, amount, 0, `Stock loss ${itemCode} — ${reason}`),
        line(ctx, INVENTORY_ACCOUNT, INVENTORY_ACCOUNT_NAME, 0, amount, `Stock loss ${itemCode} — ${reason}`),
      ];
};

export interface InventoryReconciliation {
  valuation: number;
  ledger: number;
  difference: number;
  reconciled: boolean;
}

/** Inventory valuation report = inventory control account (120000). */
export const reconcileInventory = (items: StockItem[], lines: ACDOCALine[], clientId: number): InventoryReconciliation => {
  const valuation = money(items.filter((i) => i.clientId === clientId).reduce((n, i) => n + i.totalValue, 0));
  const ledger =
    lines
      .filter((l) => l.clientId === clientId && l.accountNo === INVENTORY_ACCOUNT)
      .reduce((n, l) => n + Math.round(l.debit * 100) - Math.round(l.credit * 100), 0) / 100;
  const difference = money(valuation - ledger);
  return { valuation, ledger, difference, reconciled: Math.abs(difference) < 0.005 };
};

export interface TradingResult {
  revenue: number;
  costOfSales: number;
  grossProfit: number;
  grossMarginPct: number;
  markupOnCostPct: number;
}

/** Gross profit analytics used by the inventory desk and the trading report. */
export const tradingResult = (revenue: number, costOfSales: number): TradingResult => {
  const gp = money(revenue - costOfSales);
  return {
    revenue: money(revenue),
    costOfSales: money(costOfSales),
    grossProfit: gp,
    grossMarginPct: revenue > 0 ? Math.round((gp / revenue) * 10000) / 100 : 0,
    markupOnCostPct: costOfSales > 0 ? Math.round((gp / costOfSales) * 10000) / 100 : 0,
  };
};
