export const r2 = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;

/** Calculates a partial supplier settlement without over-paying the AP liability. */
export function calculateSupplierSettlement(input: {
  invoiceGross: number;
  invoiceTaxableValue: number;
  alreadyPaid: number;
  paymentGross: number;
  incomeWhtRate: number;
  vatWithholdingRate: number;
}) {
  const outstanding = r2(input.invoiceGross - input.alreadyPaid);
  if (!Number.isFinite(input.paymentGross) || input.paymentGross <= 0 || input.paymentGross > outstanding + 0.009) {
    throw new Error('Payment must be positive and cannot exceed the outstanding invoice balance.');
  }
  const proportion = input.invoiceGross === 0 ? 0 : input.paymentGross / input.invoiceGross;
  const taxablePaymentBase = r2(input.invoiceTaxableValue * proportion);
  const incomeWht = r2(taxablePaymentBase * input.incomeWhtRate / 100);
  const vatWithheld = r2(taxablePaymentBase * input.vatWithholdingRate / 100);
  const cash = r2(input.paymentGross - incomeWht - vatWithheld);
  if (cash < 0) throw new Error('Withholding deductions cannot exceed the gross payment.');
  return { outstanding, taxablePaymentBase, incomeWht, vatWithheld, cash, resultingPaid: r2(input.alreadyPaid + input.paymentGross), resultingOutstanding: r2(outstanding - input.paymentGross) };
}

/** Validates a complete double-entry document in minor currency units. */
export function isBalancedDocument(lines: { debit: number; credit: number }[]) {
  const debit = lines.reduce((n, l) => n + Math.round(l.debit * 100), 0);
  const credit = lines.reduce((n, l) => n + Math.round(l.credit * 100), 0);
  return debit > 0 && debit === credit;
}

export type VatTreatment = 'standard' | 'inclusive' | 'none' | 'zero_rated';

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

/**
 * Computes net / input VAT / gross for a purchase order line from the quoted
 * quantity and unit price, honouring the vendor's VAT treatment:
 * - standard:   quotation exclusive of VAT; VAT added on top
 * - inclusive:  quoted price includes VAT; VAT split out of the gross
 * - none / zero_rated: no input VAT (non-VAT vendor, exempt or zero-rated bill)
 */
export function computePoVat(qty: number, unitPrice: number, treatment: VatTreatment, vatRatePct: number) {
  const quoted = round2(qty * unitPrice);
  if (treatment === 'inclusive') {
    const gross = quoted;
    const net = round2(gross / (1 + vatRatePct / 100));
    return { net, vat: round2(gross - net), gross };
  }
  const net = quoted;
  const vat = treatment === 'standard' ? round2((net * vatRatePct) / 100) : 0;
  return { net, vat, gross: round2(net + vat) };
}

/**
 * Splits a paid expense amount into expense (net) and recoverable input VAT.
 * When the bill is not VAT-inclusive (non-VAT vendor), the full amount is the expense.
 */
export function computeExpenseVatSplit(amount: number, vatInclusive: boolean, vatRatePct: number) {
  const gross = round2(amount);
  if (!vatInclusive) return { net: gross, vat: 0, gross };
  const net = round2(gross / (1 + vatRatePct / 100));
  return { net, vat: round2(gross - net), gross };
}

/**
 * Computes the VAT withheld at source by an appointed-agent customer on a cash receipt.
 * The customer pays (invoice gross − total withholding); the withheld amount settles the
 * receivable via the WHT receivable account. Partial receipts prorate the withholding;
 * the final receipt always captures the remaining withheld amount exactly.
 */
export function computeCustomerVatWithholding(invoiceWht: number, invoiceGross: number, outstanding: number, cashAmount: number) {
  if (!Number.isFinite(cashAmount) || cashAmount <= 0 || invoiceWht <= 0 || invoiceGross <= invoiceWht || outstanding <= 0) return 0;
  const remainingWht = (invoiceWht * outstanding) / invoiceGross;
  const proportional = (cashAmount * invoiceWht) / (invoiceGross - invoiceWht);
  return Math.round(Math.min(remainingWht, proportional) * 100) / 100;
}
