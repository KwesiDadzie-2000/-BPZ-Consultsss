'use client';

/**
 * IFRS Statutory Financial Statements.
 *
 * The complete set required by IAS 1.10 — statement of financial position,
 * statement of profit or loss and other comprehensive income, statement of
 * changes in equity, statement of cash flows and the notes — prepared from the
 * posted journal and presented as the document it is: a statutory plate with
 * boxed headings, hairline rules, note references in the margin and comparatives
 * in a second column. Every statement prints on its own; the whole pack prints
 * as one bound document.
 */

import { useMemo, useState } from 'react';
import { Printer, FileText, ShieldCheck, AlertTriangle, Download, BookOpen } from 'lucide-react';
import type { AccountMaster, ACDOCALine, ClientEntity, UserAccount } from '@/types/accounting';
import { buildIfrsPack, type IfrsPack, type IfrsRow, type IfrsStatement } from '@/utils/ifrsPack';
import { printIfrsPack } from '@/utils/printIfrs';
import { toPrintEntity } from '@/utils/printEntity';
import { persistentStorage } from '@/utils/persistentStorage';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const fiscalYearStartISO = (clientId: number, year: number): string => {
  const profiles = persistentStorage.getCompanyProfiles();
  const fy = profiles[clientId]?.fiscalYearStart || 'January';
  const idx = Math.max(0, MONTHS.indexOf(fy));
  return `${year}-${String(idx + 1).padStart(2, '0')}-01`;
};

const money = (n: number) =>
  n < 0
    ? `(${Math.abs(n).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})`
    : n.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

type Tab = 'position' | 'profit' | 'equity' | 'cashflow' | 'notes' | 'analysis' | 'compliance';

const TABS: { id: Tab; label: string; standard: string }[] = [
  { id: 'position', label: 'Financial position', standard: 'IAS 1.54' },
  { id: 'profit', label: 'Profit or loss & OCI', standard: 'IAS 1.82A' },
  { id: 'equity', label: 'Changes in equity', standard: 'IAS 1.106' },
  { id: 'cashflow', label: 'Cash flows', standard: 'IAS 7.10' },
  { id: 'notes', label: 'Notes to the statements', standard: 'IAS 1.112' },
  { id: 'analysis', label: 'Ratios & capital', standard: 'IAS 1.134' },
  { id: 'compliance', label: 'IFRS compliance check', standard: 'IAS 1.114' },
];

/** One statutory plate: boxed centred heading, ruled columns, marginal notes. */
function StatementSheet({ statement }: { statement: IfrsStatement }) {
  return (
    <article className="rounded-sm border border-[#c9bfac] bg-[#fbf9f4] p-6 shadow-[0_1px_0_#e7ddca,0_18px_38px_-30px_rgba(34,31,26,0.55)] sm:p-9">
      <div className="text-center text-[9px] font-bold uppercase tracking-[0.28em] text-[#a8341f]">{statement.standard}</div>
      <h3 className="mx-auto mt-2 max-w-[36rem] border border-[#0e3b2e] px-4 py-2.5 text-center text-[15px] font-semibold leading-tight text-[#0e3b2e] sm:text-[17px]">
        {statement.title}
      </h3>
      <p className="mt-2 text-center text-[11.5px] italic text-[#4b4638]">{statement.subtitle}</p>

      {statement.matrix && (
        <div className="mt-6 overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-[#221f1a]">
                <th className="py-1.5 pr-4 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Particulars</th>
                {statement.matrix.columns.map((c) => (
                  <th key={c} className="py-1.5 pl-3 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">
                    {c}
                  </th>
                ))}
                <th className="py-1.5 pl-3 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Total</th>
              </tr>
            </thead>
            <tbody>
              {statement.matrix.rows.map((r, i) => (
                <tr
                  key={`${r.label}-${i}`}
                  className={`${r.emphasis === 'total' ? 'border-y-[1.5px] border-double border-[#0e3b2e] bg-[#e7ddca] font-semibold text-[#0e3b2e]' : r.emphasis === 'sub' ? 'border-t border-[#221f1a] bg-[#f2ecdf] font-semibold' : 'border-b border-[#e4dbcb]'} transition-colors hover:bg-[#f2ecdf]`}
                >
                  <td className="py-[5px] pr-4 text-[11.5px] text-[#221f1a]">{r.label}</td>
                  {r.values.map((v, j) => (
                    <td key={j} className={`py-[5px] pl-3 text-right font-mono text-[11px] tabular-nums ${v < 0 ? 'text-[#a8341f]' : 'text-[#221f1a]'}`}>
                      {money(v)}
                    </td>
                  ))}
                  <td className={`py-[5px] pl-3 text-right font-mono text-[11px] font-semibold tabular-nums ${r.total < 0 ? 'text-[#a8341f]' : 'text-[#221f1a]'}`}>
                    {money(r.total)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="mt-6 space-y-7">
        {statement.blocks.map((block, bi) => (
          <section key={`${block.title ?? 'block'}-${bi}`}>
            {block.title && (
              <h4 className="mb-1.5 border-b border-[#0e3b2e] pb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[#0e3b2e]">
                {block.title}
              </h4>
            )}
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b border-[#221f1a]">
                  <th className="py-1.5 pr-4 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Particulars</th>
                  <th className="w-10 py-1.5 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Note</th>
                  <th className="w-[16%] py-1.5 pl-3 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Amount</th>
                  <th className="w-[16%] py-1.5 pl-3 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Comparative</th>
                </tr>
              </thead>
              <tbody>
                {[...block.rows, ...(block.total ? [block.total] : [])].map((row, i) => (
                  <Row key={`${row.label}-${i}`} row={row} />
                ))}
                {block.rows.length === 0 && !block.total && (
                  <tr>
                    <td colSpan={4} className="py-4 text-center text-[11px] italic text-[#6b6152]">
                      No amounts recognised in this caption for the period.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </section>
        ))}
      </div>
    </article>
  );
}

function Row({ row }: { row: IfrsRow }) {
  const emphasis =
    row.emphasis === 'grand'
      ? 'border-y-[1.5px] border-double border-[#221f1a] bg-[#efe8da] font-semibold'
      : row.emphasis === 'total'
        ? 'border-t-[1.5px] border-b-[3px] border-double border-[#0e3b2e] bg-[#e7ddca] font-semibold text-[#0e3b2e]'
        : row.emphasis === 'sub'
          ? 'border-t border-[#221f1a] bg-[#f2ecdf] font-semibold'
          : 'border-b border-[#e4dbcb]';
  return (
    <tr className={`${emphasis} transition-colors hover:bg-[#f2ecdf]`}>
      <td className={`py-[5px] pr-4 text-[11.5px] text-[#221f1a] ${row.indent ? 'pl-7 italic text-[#4b4638]' : ''}`}>{row.label}</td>
      <td className="py-[5px] text-right text-[9px] font-semibold tracking-[0.12em] text-[#a8341f]">{row.note}</td>
      <td className={`py-[5px] pl-3 text-right font-mono text-[11px] tabular-nums ${row.current < 0 ? 'text-[#a8341f]' : 'text-[#221f1a]'}`}>
        {money(row.current)}
      </td>
      <td className={`py-[5px] pl-3 text-right font-mono text-[11px] tabular-nums ${row.comparative < 0 ? 'text-[#a8341f]' : 'text-[#6b6152]'}`}>
        {money(row.comparative)}
      </td>
    </tr>
  );
}

export function StatutoryStatementsDesk({
  currentClient,
  currentUser,
  lines,
  accounts,
  clients,
  onSelectClient,
}: {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  clients?: ClientEntity[];
  onSelectClient?: (client: ClientEntity) => void;
}) {
  const [tab, setTab] = useState<Tab>('position');
  const [through, setThrough] = useState(() => new Date().toISOString().slice(0, 10));
  const [reportChoice, setReportChoice] = useState<number | null>(null);
  const [fromOverride, setFromOverride] = useState<string | null>(null);

  const reportClientId = reportChoice ?? currentClient.id;
  const reportClient = (clients ?? [currentClient]).find((c) => c.id === reportClientId) || currentClient;
  const from = fromOverride ?? fiscalYearStartISO(reportClientId, Number(through.slice(0, 4)) || new Date().getFullYear());

  const profile = persistentStorage.getCompanyProfiles()[reportClient.id];

  const pack: IfrsPack = useMemo(
    () =>
      buildIfrsPack({
        lines: lines.filter((l) => l.clientId === reportClient.id),
        accounts,
        from,
        through,
        currency: reportClient.currency,
        entityName: reportClient.name,
        entityCode: reportClient.code,
        jurisdiction: reportClient.jurisdiction,
        regNumber: reportClient.regNumber,
        fiscalYearStart: profile?.fiscalYearStart,
        sector: reportClient.sector,
      }),
    [lines, accounts, reportClient, from, through, profile],
  );

  const entity = toPrintEntity(reportClient, profile);
  const preparedBy = `${currentUser.name} (${currentUser.username})`;

  const printPack = (
    include?: { statements?: boolean; notes?: boolean; ratios?: boolean; compliance?: boolean },
    onlyStatement?: 'position' | 'profit' | 'equity' | 'cashflow',
  ) =>
    printIfrsPack(pack, {
      entity: { ...entity, jurisdiction: reportClient.jurisdiction, regNumber: reportClient.regNumber },
      preparedBy,
      include,
      onlyStatement,
      authorisedOn: through,
      status: 'Statutory financial statements — IFRS',
    });

  const printActive = () => {
    if (tab === 'notes') return printPack({ notes: true });
    if (tab === 'analysis') return printPack({ ratios: true });
    if (tab === 'compliance') return printPack({ compliance: true });
    printPack({ statements: true }, tab);
  };

  const exportCsv = () => {
    const cell = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
    const rows: Array<Array<string | number>> = [
      ['Entity', reportClient.name],
      ['Entity code', reportClient.code],
      ['Period', pack.periodLabel],
      ['Comparative', pack.comparativeLabel],
      ['Currency', pack.currency],
      ['Standard', 'IFRS — IAS 1 complete set'],
      [],
      ['Statement', 'Caption', 'Note', 'Current', 'Comparative'],
    ];
    for (const st of pack.statements) {
      for (const block of st.blocks) {
        for (const r of [...block.rows, ...(block.total ? [block.total] : [])]) {
          rows.push([st.title, r.label, r.note ?? '', r.current, r.comparative]);
        }
      }
    }
    for (const n of pack.notes) {
      rows.push([`Note ${n.number}`, n.title, n.standard]);
      for (const p of n.paragraphs) rows.push(['', p]);
    }
    const url = URL.createObjectURL(new Blob([rows.map((r) => r.map(cell).join(',')).join('\r\n')], { type: 'text/csv' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = `${reportClient.code}-IFRS-statements-${through}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const activeStatement = pack.statements.find((s) => s.id === tab);
  const failing = pack.checks.filter((c) => c.severity !== 'pass');
  const critical = pack.checks.filter((c) => c.severity === 'critical');

  return (
    <div className="space-y-5">
      {/* Masthead — the cover of the statutory binder */}
      <div className="overflow-hidden rounded-lg border border-[#c9bfac] bg-[#0e3b2e]">
        <div
          className="relative bg-[#0e3b2e] bg-cover bg-center px-5 py-6 sm:px-8 sm:py-8"
          style={{
            backgroundImage:
              "linear-gradient(105deg, rgba(14,59,46,0.97) 0%, rgba(14,59,46,0.88) 42%, rgba(14,59,46,0.55) 100%), url('images/statutory-paper.jpg')",
          }}
        >
          <div className="text-[9px] font-bold uppercase tracking-[0.32em] text-[#d8c79b]">
            IAS 1 · Complete set of financial statements
          </div>
          <h2 className="mt-2 max-w-[24ch] text-2xl font-semibold leading-tight text-[#f6f2ea] sm:text-[3xl]">
            Financial statements of {reportClient.name}
          </h2>
          <p className="mt-2 max-w-[62ch] text-[12px] leading-relaxed text-[#e3d9c4]">
            Prepared from the posted general ledger in accordance with International Financial Reporting Standards, with the
            comparative information, accounting policies and notes required by IAS 1. Every figure below is traceable to a journal
            document.
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <button
              onClick={() => printPack()}
              className="flex items-center gap-2 rounded bg-[#f5b719] px-4 py-2 text-xs font-bold text-[#0e3b2e] transition hover:bg-[#ffd166] active:translate-y-px"
            >
              <Printer className="h-3.5 w-3.5" /> Print full statutory pack
            </button>
            <button
              onClick={printActive}
              className="flex items-center gap-2 rounded border border-[#c9bfac]/60 bg-white/10 px-4 py-2 text-xs font-bold text-[#f6f2ea] transition hover:bg-white/20 active:translate-y-px"
            >
              <FileText className="h-3.5 w-3.5" /> Print current statement
            </button>
            <button
              onClick={exportCsv}
              className="flex items-center gap-2 rounded border border-[#c9bfac]/60 bg-white/10 px-4 py-2 text-xs font-bold text-[#f6f2ea] transition hover:bg-white/20 active:translate-y-px"
            >
              <Download className="h-3.5 w-3.5" /> Export CSV
            </button>
          </div>
        </div>
      </div>

      {/* Period control strip */}
      <div className="flex flex-wrap items-end gap-3 rounded-lg border border-sky-200 bg-white p-3">
        <label className="flex flex-col gap-1 text-[10px] font-bold uppercase tracking-wider text-[#2d4f6d]">
          Period from
          <input
            type="date"
            value={from}
            onChange={(e) => setFromOverride(e.target.value)}
            className="rounded border border-sky-300 px-2 py-1.5 text-xs font-semibold text-[#0a253e]"
          />
        </label>
        <label className="flex flex-col gap-1 text-[10px] font-bold uppercase tracking-wider text-[#2d4f6d]">
          Reporting date
          <input
            type="date"
            value={through}
            onChange={(e) => setThrough(e.target.value)}
            className="rounded border border-sky-300 px-2 py-1.5 text-xs font-semibold text-[#0a253e]"
          />
        </label>
        {(clients?.length ?? 0) > 1 && (
          <label className="flex flex-col gap-1 text-[10px] font-bold uppercase tracking-wider text-[#2d4f6d]">
            Reporting entity
            <select
              value={reportClientId}
              onChange={(e) => {
                const id = Number(e.target.value);
                setReportChoice(id);
                onSelectClient?.(clients!.find((c) => c.id === id) ?? currentClient);
              }}
              className="rounded border border-sky-300 px-2 py-1.5 text-xs font-semibold text-[#0a253e]"
            >
              {(clients ?? []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.code} — {c.name}
                </option>
              ))}
            </select>
          </label>
        )}
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <span className={`rounded px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${pack.totals.balanced ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
            {pack.totals.balanced ? 'Statement balances' : 'Out of balance'}
          </span>
          <span className="rounded bg-sky-100 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[#163653]">
            {pack.checks.filter((c) => c.severity === 'pass').length}/{pack.checks.length} controls clear
          </span>
          <span className="rounded bg-amber-100 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[#8a5d00]">
            {failing.length} item{failing.length === 1 ? '' : 's'} for attention
          </span>
        </div>
      </div>

      {critical.length > 0 && (
        <div role="alert" className="rounded border border-rose-300 bg-rose-50 p-3 text-xs font-semibold text-rose-900">
          <span className="font-black uppercase tracking-wider">Do not issue — </span>
          {critical.map((c) => c.title).join('; ')}. Resolve these before the statements are signed.
        </div>
      )}

      {/* Statement tabs */}
      <div className="flex flex-wrap gap-1.5">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`rounded px-3 py-1.5 text-[11px] font-bold transition ${
              tab === t.id ? 'bg-[#0e3b2e] text-[#f6f2ea] shadow' : 'border border-sky-200 bg-white text-[#163653] hover:bg-sky-50'
            }`}
          >
            {t.label}
            <span className={`ml-2 font-mono text-[9px] ${tab === t.id ? 'text-[#d8c79b]' : 'text-[#855b00]'}`}>{t.standard}</span>
          </button>
        ))}
      </div>

      {/* Document + compliance rail */}
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_260px]">
        <div>
          {activeStatement && <StatementSheet statement={activeStatement} />}

          {tab === 'notes' && (
            <div className="space-y-4">
              {pack.notes.map((n) => (
                <article key={n.number} className="rounded-sm border border-[#c9bfac] bg-[#fbf9f4] p-6">
                  <h4 className="text-[13px] font-semibold text-[#0e3b2e]">
                    {n.number}. {n.title}
                    <span className="ml-3 text-[9px] font-bold uppercase tracking-[0.18em] text-[#a8341f]">{n.standard}</span>
                  </h4>
                  {n.paragraphs.map((p, i) => (
                    <p key={i} className="mt-2 max-w-[80ch] text-[11.5px] leading-relaxed text-[#221f1a]">
                      {p}
                    </p>
                  ))}
                  {n.table && (
                    <table className="mt-3 w-full border-collapse">
                      <thead>
                        <tr className="border-b border-[#221f1a]">
                          {n.table.columns.map((c, i) => (
                            <th key={c} className={`py-1.5 text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152] ${i > 0 ? 'text-right' : 'text-left'}`}>
                              {c}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {n.table.rows.map((r, i) => (
                          <tr key={i} className="border-b border-[#e4dbcb]">
                            {r.map((v, j) => (
                              <td key={j} className={`py-[5px] text-[11px] ${j > 0 ? `text-right font-mono tabular-nums ${typeof v === 'number' && v < 0 ? 'text-[#a8341f]' : ''}` : ''}`}>
                                {typeof v === 'number' ? money(v) : v}
                              </td>
                            ))}
                          </tr>
                        ))}
                        {n.table.totals && (
                          <tr className="border-y-[1.5px] border-double border-[#0e3b2e] bg-[#e7ddca] font-semibold">
                            {n.table.totals.map((v, j) => (
                              <td key={j} className={`py-[6px] text-[11px] text-[#0e3b2e] ${j > 0 ? 'text-right font-mono tabular-nums' : ''}`}>
                                {typeof v === 'number' ? money(v) : v}
                              </td>
                            ))}
                          </tr>
                        )}
                      </tbody>
                    </table>
                  )}
                </article>
              ))}
            </div>
          )}

          {tab === 'analysis' && (
            <div className="space-y-4">
              <div className="rounded-sm border border-[#c9bfac] bg-[#fbf9f4] p-6">
                <h4 className="border-b border-[#0e3b2e] pb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[#0e3b2e]">
                  Capital, liquidity and performance analysis
                </h4>
                <table className="mt-3 w-full border-collapse">
                  <thead>
                    <tr className="border-b border-[#221f1a]">
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Measure</th>
                      <th className="py-1.5 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Current</th>
                      <th className="py-1.5 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Comparative</th>
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Basis</th>
                      <th className="py-1.5 text-right text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Ref</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pack.ratios.map((r) => (
                      <tr key={r.label} className="border-b border-[#e4dbcb]">
                        <td className="py-[6px] pr-3 text-[11.5px] text-[#221f1a]">{r.label}</td>
                        <td className="py-[6px] text-right font-mono text-[11px] tabular-nums text-[#221f1a]">{r.current}</td>
                        <td className="py-[6px] text-right font-mono text-[11px] tabular-nums text-[#6b6152]">{r.comparative}</td>
                        <td className="py-[6px] pl-3 text-[10.5px] italic text-[#4b4638]">{r.basis}</td>
                        <td className="py-[6px] text-right text-[9px] font-semibold tracking-[0.12em] text-[#a8341f]">{r.ref}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="rounded-sm border border-[#c9bfac] bg-[#fbf9f4] p-6">
                <h4 className="border-b border-[#0e3b2e] pb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[#0e3b2e]">
                  Significant accounting policies — note 3
                </h4>
                <table className="mt-3 w-full border-collapse">
                  <tbody>
                    {pack.notes
                      .find((n) => n.number === 3)
                      ?.table?.rows.map((r, i) => (
                        <tr key={i} className="border-b border-[#e4dbcb]">
                          <td className="py-[6px] pr-3 text-[11.5px] text-[#221f1a]">{r[0]}</td>
                          <td className="py-[6px] text-right text-[9px] font-bold uppercase tracking-[0.12em] text-[#a8341f]">{r[1]}</td>
                          <td className="py-[6px] pl-3 text-[10.5px] italic text-[#4b4638]">{r[2]}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab === 'compliance' && (
            <div className="space-y-4">
              <div className="rounded-sm border border-[#c9bfac] bg-[#fbf9f4] p-6">
                <h4 className="border-b border-[#0e3b2e] pb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[#0e3b2e]">
                  IAS 1.10 completeness checklist
                </h4>
                <table className="mt-3 w-full border-collapse">
                  <thead>
                    <tr className="border-b border-[#221f1a]">
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Requirement</th>
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Standard</th>
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Status</th>
                      <th className="py-1.5 text-left text-[9px] font-bold uppercase tracking-[0.14em] text-[#6b6152]">Basis</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pack.checklist.map((c) => (
                      <tr key={c.requirement} className="border-b border-[#e4dbcb]">
                        <td className="py-[6px] pr-3 text-[11.5px] text-[#221f1a]">{c.requirement}</td>
                        <td className="py-[6px] pr-3 font-mono text-[10px] text-[#4b4638]">{c.standard}</td>
                        <td className="py-[6px] pr-3">
                          <span
                            className={`rounded px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.12em] ${
                              c.status === 'Satisfied'
                                ? 'bg-[#dfe9df] text-[#0e3b2e]'
                                : c.status === 'Partial'
                                  ? 'bg-[#f2e2c4] text-[#7a4c00]'
                                  : 'bg-[#f2d6cf] text-[#a8341f]'
                            }`}
                          >
                            {c.status}
                          </span>
                        </td>
                        <td className="py-[6px] text-[10.5px] italic text-[#4b4638]">{c.detail}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="rounded-sm border border-[#c9bfac] bg-[#fbf9f4] p-6">
                <h4 className="flex items-center gap-2 border-b border-[#0e3b2e] pb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[#0e3b2e]">
                  <ShieldCheck className="h-3.5 w-3.5" /> Control checks run against the ledger
                </h4>
                <div className="mt-3 space-y-2">
                  {pack.checks.map((c) => (
                    <div key={c.id} className="flex items-start gap-3 border-b border-[#e4dbcb] pb-2">
                      <span
                        className={`mt-0.5 rounded px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.12em] ${
                          c.severity === 'pass'
                            ? 'bg-[#dfe9df] text-[#0e3b2e]'
                            : c.severity === 'critical'
                              ? 'bg-[#f2d6cf] text-[#a8341f]'
                              : 'bg-[#f2e2c4] text-[#7a4c00]'
                        }`}
                      >
                        {c.severity === 'pass' ? 'Clear' : c.severity === 'critical' ? 'Critical' : 'Review'}
                      </span>
                      <div>
                        <div className="text-[11.5px] font-semibold text-[#221f1a]">
                          {c.title} <span className="ml-2 text-[9px] font-bold uppercase tracking-[0.12em] text-[#a8341f]">{c.standard}</span>
                        </div>
                        <div className="text-[10.5px] text-[#4b4638]">{c.detail}</div>
                        <div className="text-[10.5px] italic text-[#6b6152]">{c.action}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Compliance rail — the authority standing beside each figure */}
        <aside className="h-max rounded-lg border border-sky-200 bg-white p-4 lg:sticky lg:top-4">
          <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#855b00]">Authority</div>
          <h4 className="mt-1 text-sm font-bold text-[#082f4f]">{TABS.find((t) => t.id === tab)?.standard}</h4>
          <p className="mt-1 text-[11px] leading-relaxed text-[#2d4f6d]">
            {tab === 'position' && 'IAS 1.54 requires a classified statement of financial position, with current and non-current items presented separately and comparatives for the preceding period (IAS 1.38).'}
            {tab === 'profit' && 'IAS 1.82A permits a single statement of profit or loss and other comprehensive income; profit or loss items are presented before OCI items, and total comprehensive income is shown.'}
            {tab === 'equity' && 'IAS 1.106 requires a statement of changes in equity showing each component of equity, the effects of changes in accounting policies and corrections of errors, and transactions with owners in their capacity as owners.'}
            {tab === 'cashflow' && 'IAS 7.10 requires cash flows classified into operating, investing and financing activities. IAS 7.44 additionally requires a reconciliation of net debt where cash flows are classified by activity.'}
            {tab === 'notes' && 'IAS 1.112 requires the notes to present information about the basis of preparation, specific accounting policies, and disclosures that are not presented elsewhere — in a systematic order.'}
            {tab === 'analysis' && 'IAS 1.60 requires disclosure of the entity’s liquidity and capital management, including maturity analysis and the entity’s objectives, policies and processes for managing capital.'}
            {tab === 'compliance' && 'IAS 1.114 requires an explicit statement of compliance with IFRS. The completeness checklist verifies the complete set required by IAS 1.10.'}
          </p>

          <div className="mt-4 border-t border-sky-100 pt-3">
            <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#855b00]">Key figures</div>
            <dl className="mt-2 space-y-2">
              {[
                ['Revenue', pack.totals.revenue],
                ['Profit for the period', pack.totals.profitForPeriod],
                ['Total comprehensive income', pack.totals.totalComprehensiveIncome],
                ['Total assets', pack.totals.totalAssets],
                ['Total equity', pack.totals.totalEquity],
                ['Net debt', pack.totals.netDebt],
              ].map(([label, value]) => (
                <div key={String(label)} className="flex items-baseline justify-between gap-2">
                  <dt className="text-[10.5px] text-[#2d4f6d]">{label}</dt>
                  <dd className={`font-mono text-[11px] font-semibold tabular-nums ${Number(value) < 0 ? 'text-[#a8341f]' : 'text-[#0a253e]'}`}>
                    {money(Number(value))}
                  </dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="mt-4 border-t border-sky-100 pt-3">
            <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.16em] text-[#855b00]">
              <BookOpen className="h-3 w-3" /> Note references
            </div>
            <div className="mt-2 flex flex-wrap gap-1">
              {pack.notes.map((n) => (
                <span key={n.number} title={`${n.title} — ${n.standard}`} className="rounded border border-sky-200 bg-sky-50 px-1.5 py-0.5 font-mono text-[9px] font-bold text-[#163653]">
                  {n.number}
                </span>
              ))}
            </div>
          </div>

          {failing.length > 0 && (
            <div className="mt-4 flex items-start gap-2 rounded border border-amber-300 bg-amber-50 p-2.5">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#8a5d00]" />
              <p className="text-[10.5px] leading-relaxed text-[#7a4c00]">
                {failing.length} control check{failing.length === 1 ? '' : 's'} still require attention. Open the IFRS Compliance
                Review for the full gap register and remediation plan.
              </p>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
