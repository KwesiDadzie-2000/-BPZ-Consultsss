# Audit response: client sign-in and module access

This note records the defects found when the client sign-in path was tested end to
end, what was changed, and what remains open. The original assessments
(`SYSTEM_AUDIT_2026.md`, `SYSTEM_REVIEW.md`) are left unaltered on purpose.

## 1. Defects reproduced and fixed

| # | Symptom reported | Root cause found | Fix |
|---|------------------|------------------|-----|
| 1 | Client's password "becomes incorrect" | Three compounding causes. (a) The sign-in form had no protection against browser autofill, so a password the owner had saved on the same machine was filled into the client's form. (b) Failed-attempt lockout was kept in browser storage shared by every account on that machine, so one mistyped password locked out all accounts, including correct ones. (c) The client link opened the owner's still-live session, so the client never saw a credential prompt for their own account. The server-side password verification was tested and is correct. | Sign-in form clears the password field on mount and before submit, uses `autocomplete="new-password"`, and no longer keeps a browser-wide lockout counter. The server enforces a lockout per account. |
| 2 | Clicking the client's login link opens the owner's whole workspace | The owner's session token is mirrored in browser storage and an HttpOnly cookie, and the app restored it before showing the form. The sign-in link (`/?workspace=CODE`) was never read. | A workspace link always starts at the sign-in form and ends any existing session first. The sign-in request carries the workspace code. The server refuses an account from another workspace (403) and an unknown code (404). The owner may use a client link and is taken to that client's entity. The link is removed from the address bar after use. |
| 3 | Cached data from the owner visible to a client on the same browser | The browser cache holds every entity's journals, clients and users. | The cache is bound to the signed-in username. A change of user purges it before the workspace renders. Non-owners receive only their own entity from the entity list, and `/api/bootstrap` already scopes data server-side. |
| 4 | Clients see modules that were not ticked for them | Access was decided only by the contracted services and three permission flags. There was no per-user module selection. | `permissions.allowedModules` is a per-user list of module ids. The owner ticks it in *User Access & Restrictions*. The access rule (`maySeeSection`) enforces it for every sidebar item and content view. Owner-only administration is excluded for every non-owner. |
| 5 | Module ticks could be forged or bloated | No validation on the stored permission block. | The server keeps only catalogue ids, removes owner-only ids, de-duplicates, and caps the list at 200 entries. |

## 2. Where the rules live

- `src/utils/moduleCatalog.ts`: the single list of module ids, owner-only modules, and
  the client-grantable catalogue. The sidebar, access rule, permission editor and
  server sanitiser all read it.
- `src/utils/access.ts`: `maySeeSection` (owner-only, contracted services, status,
  per-user ticks, and the existing payroll / period-close / chart-of-accounts flags).
- `src/app/api/auth/login/route.ts`: password check, then workspace binding.
- `src/app/api/users/route.ts`: owner-only write, with permission sanitisation.
- `src/app/api/state/route.ts`: period closing requires `canClosePeriod` (already
  enforced server-side and re-verified in this audit).

## 3. Tests run for this change

Against a live server with a fresh database:

- owner activation, owner login, client creation (201), client login (200);
- client login through the client's own link (200, workspace returned);
- client login through another client's link (403);
- unknown workspace code (404);
- owner login through a client link (200, workspace returned);
- owner stores module ticks; unknown and owner-only ids are dropped; the client
  session reflects the ticks;
- client calls to owner APIs (`/api/clients`, `/api/users`) are refused (403);
- client `/api/bootstrap` returns only the client's own entity.

## 4. Open items (not closed in this pass)

These are real gaps that need more work before live use:

1. **Server-side module enforcement is partial.** Module ticks are enforced in the
   interface and in the sanitised data, but the state-sync endpoint still accepts
   writes to any collection within the client's own entity. A client who calls the
   API directly could write outside their ticked modules. Enforcing that needs a
   collection-to-module map on the server.
2. **Login lockout is per server instance.** The attempt counter is in memory, so
   several instances would each allow their own attempts. It should move to the
   database.
3. **Working balances are still browser-edited** (bank balances, invoice and purchase
   order status, stock). The server checks who may save them, not that they agree
   with the ledger. A reconciliation report comparing them to posted journals is the
   next step, and server-side settlement rules should follow.
4. **Consolidation loads every entity's journal** when it is opened.
5. **Demonstration single-sign-on switch** was removed from the workspace, so no
   local "log in as" bypass remains.
6. **Tax rates, IFRS 17 / IFRS 9 measurement and royalty / fuel-levy calculations**
   are outside the scope of this access fix. Rates must be confirmed by a Ghana-qualified
   accountant against current GRA, Minerals Commission and NPA instruments before use.
