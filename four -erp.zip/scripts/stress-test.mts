/**
 * Load, concurrency and integrity stress test (destructive; disposable DB only).
 *
 *   BPZ_STRESS_DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/bpz_stress_test \
 *     STRESS_CLIENTS=20 STRESS_DOCS=2500 npx tsx scripts/stress-test.mts
 *
 * Seeds a realistic multi-tenant ledger volume, then measures the latency of the
 * hottest server paths and races concurrent writers against the posting,
 * idempotency, stock and lockout controls. Every race ends with an integrity
 * assertion (balanced books, no duplicates, no negative stock, GL = stock).
 */
import { randomUUID } from 'node:crypto';
import { performance } from 'node:perf_hooks';

const url = process.env.BPZ_STRESS_DATABASE_URL;
if (!url) throw new Error('Set BPZ_STRESS_DATABASE_URL to a disposable local bpz_stress_test database.');
const parsed = new URL(url);
if (!['localhost', '127.0.0.1'].includes(parsed.hostname) || parsed.pathname !== '/bpz_stress_test') {
  throw new Error('Refusing to run anywhere except a local bpz_stress_test database.');
}
process.env.DATABASE_URL = url;
process.env.BPZ_BOOTSTRAP_MODE = 'production';
process.env.BPZ_OWNER_EMAIL = 'owner@example.invalid';
process.env.BPZ_SETUP_TOKEN = randomUUID() + randomUUID();

const CLIENTS = Number(process.env.STRESS_CLIENTS ?? 20);
const DOCS = Number(process.env.STRESS_DOCS ?? 2500);
const DATE = '2026-11-05';

const { pool } = await import('@/db');
await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
const setup = await import('@/app/api/auth/setup/route');
const loginRoute = await import('@/app/api/auth/login/route');
const clientsRoute = await import('@/app/api/clients/route');
const journalRoute = await import('@/app/api/journal/route');
const bootstrapRoute = await import('@/app/api/bootstrap/route');
const stateRoute = await import('@/app/api/state/route');
const productionRoute = await import('@/app/api/production/route');
const healthRoute = await import('@/app/api/health/route');

type Handler = (req: Request) => Promise<Response>;
async function call(handler: Handler, method: string, path: string, body?: unknown, token?: string, raw?: string) {
  const res = await handler(new Request(`http://localhost${path}`, {
    method, headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    ...(raw !== undefined ? { body: raw } : body === undefined ? {} : { body: JSON.stringify(body) }),
  }));
  const text = await res.text();
  let json: any = null; try { json = JSON.parse(text); } catch { /* not json */ }
  return { status: res.status, body: json, bytes: text.length };
}
const results: string[] = []; const failures: string[] = []; let passed = 0;
function check(title: string, ok: boolean, detail = '') { if (ok) passed++; else failures.push(`${title}${detail ? ` — ${detail}` : ''}`); }
async function timed<T>(fn: () => Promise<T>): Promise<[T, number]> { const t = performance.now(); const v = await fn(); return [v, performance.now() - t]; }
const pct = (xs: number[], p: number) => { const s = [...xs].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };
async function pooled<T>(n: number, concurrency: number, task: (i: number) => Promise<T>): Promise<T[]> {
  const out: T[] = new Array(n); let next = 0;
  await Promise.all(Array.from({ length: concurrency }, async () => { while (next < n) { const i = next++; out[i] = await task(i); } }));
  return out;
}

// ---- setup -----------------------------------------------------------------------------------
const ownerPw = `Owner-${randomUUID().slice(0, 8)}-Aa1!`;
const act = await call(setup.POST, 'POST', '/api/auth/setup', { password: ownerPw, confirm: ownerPw, setupToken: process.env.BPZ_SETUP_TOKEN });
const owner = act.body?.token as string;
check('owner activation', !!owner);
const clientIds: number[] = []; const admins: { clientId: number; token: string; username: string }[] = [];
for (let i = 1; i <= CLIENTS; i++) {
  const code = `ST-${String(i).padStart(3, '0')}`; const username = `admin_st${i}`; const pw = `Client-${randomUUID().slice(0, 8)}-Aa1!`;
  const c = await call(clientsRoute.POST, 'POST', '/api/clients', {
    client: { code, name: `Stress Client ${i} Ltd`, sector: 'Manufacturing & Consumer Goods', currency: 'GHS', jurisdiction: 'GH', regNumber: `R-${code}`,
      assignedServices: ['bookkeeping', 'payroll', 'tax_compliance', 'management_accounts', 'ifrs_reporting'] },
    admin: { username, name: 'Finance Manager', email: `${username}@example.invalid`, password: pw, role: 'manager', makerLimit: 1_000_000 },
  }, owner);
  if (c.status !== 201) { check(`client ${code} created`, false, JSON.stringify(c.body)); continue; }
  clientIds.push(c.body.client.id);
  const l = await call(loginRoute.POST, 'POST', '/api/auth/login', { usernameOrEmail: username, password: pw });
  admins.push({ clientId: c.body.client.id, token: l.body.token, username });
}
check(`${CLIENTS} clients onboarded`, clientIds.length === CLIENTS, String(clientIds.length));

// ---- bulk volume seed (SQL) ------------------------------------------------------------------
const [, seedMs] = await timed(async () => {
  await pool.query(`
    insert into journal_lines (id, doc_no, period, date, module, doc_type, account_no, account_name, debit, credit, currency, description, created_by, client_id)
    select gen_random_uuid()::text, 'BULK-' || c || '-' || d, '2026-10', '2026-10-15', 'FI', 'JE',
           case when s = 1 then '100000' else '400000' end, case when s = 1 then 'Cash at Bank' else 'Revenue' end,
           case when s = 1 then 100 + (d % 900) else 0 end, case when s = 2 then 100 + (d % 900) else 0 end,
           'GHS', 'Bulk seeded sale', 'owner', c
    from unnest($1::int[]) c, generate_series(1, $2::int) d, generate_series(1, 2) s`, [clientIds, DOCS]);
  await pool.query(`
    insert into journal_headers (id, client_id, doc_no, period, date, module, doc_type, currency, description, debit_total, credit_total, line_count, created_by, content_hash)
    select 'JH:' || c || ':' || 'BULK-' || c || '-' || d, c, 'BULK-' || c || '-' || d, '2026-10', '2026-10-15', 'FI', 'JE', 'GHS', 'Bulk', 100 + (d % 900), 100 + (d % 900), 2, 'owner', md5(c || '-' || d)
    from unnest($1::int[]) c, generate_series(1, $2::int) d`, [clientIds, DOCS]);
  await pool.query('analyze');
});
const totalLines = Number((await pool.query('select count(*) n from journal_lines')).rows[0].n);
results.push(`Seeded ${totalLines.toLocaleString()} journal lines across ${CLIENTS} entities in ${(seedMs / 1000).toFixed(1)} s`);

const accountName = (no: string) => (no === '100000' ? 'Cash at Bank' : no === '300000' ? 'Stated Share Capital' : 'Revenue');
function doc(clientId: number, docNo: string, amount: number, maker: string) {
  return [
    { id: randomUUID(), docNo, period: DATE.slice(0, 7), date: DATE, module: 'FI', docType: 'JE', accountNo: '100000', accountName: accountName('100000'), debit: amount, credit: 0, currency: 'GHS', description: 'Stress post', createdBy: maker, clientId },
    { id: randomUUID(), docNo, period: DATE.slice(0, 7), date: DATE, module: 'FI', docType: 'JE', accountNo: '300000', accountName: accountName('300000'), debit: 0, credit: amount, currency: 'GHS', description: 'Stress post', createdBy: maker, clientId },
  ];
}

// ---- 1. single-post latency at volume --------------------------------------------------------
const singles: number[] = [];
for (let i = 0; i < 40; i++) {
  const a = admins[i % admins.length];
  const [r, ms] = await timed(() => call(journalRoute.POST, 'POST', '/api/journal', { lines: doc(a.clientId, `SEQ-${i}`, 250, a.username) }, a.token));
  singles.push(ms); if (r.status !== 200) check(`sequential post ${i}`, false, `${r.status} ${JSON.stringify(r.body)}`);
}
results.push(`Journal POST (sequential, ${totalLines.toLocaleString()} lines in DB): p50 ${pct(singles, 0.5).toFixed(0)} ms · p95 ${pct(singles, 0.95).toFixed(0)} ms`);

// ---- 2. concurrent posting across tenants ----------------------------------------------------
const N = 400;
const [conc, concMs] = await timed(() => pooled(N, 40, async (i) => {
  const a = admins[i % admins.length];
  const [r, ms] = await timed(() => call(journalRoute.POST, 'POST', '/api/journal', { lines: doc(a.clientId, `CONC-${i}`, 100 + i, a.username) }, a.token));
  return { status: r.status, ms };
}));
const concOk = conc.filter((r) => r.status === 200).length;
results.push(`Journal POST ×${N} at concurrency 40: ${concOk}/${N} ok · ${(N / (concMs / 1000)).toFixed(0)} docs/s · p95 ${pct(conc.map((c) => c.ms), 0.95).toFixed(0)} ms`);
check('all concurrent posts accepted', concOk === N, `${concOk}/${N}; statuses ${[...new Set(conc.map((c) => c.status))]}`);
const concDocs = Number((await pool.query("select count(distinct (client_id, doc_no)) n from journal_lines where doc_no like 'CONC-%'")).rows[0].n);
check('every concurrent document stored exactly once', concDocs === N, String(concDocs));

// ---- 3. duplicate-submission race (double click / retry storm) ------------------------------
const dupe = admins[0]; const dupeLines = doc(dupe.clientId, 'DUP-RACE-1', 777, dupe.username);
const dupRes = await Promise.all(Array.from({ length: 25 }, () => call(journalRoute.POST, 'POST', '/api/journal', { lines: dupeLines }, dupe.token)));
const dupLineCount = Number((await pool.query("select count(*) n from journal_lines where doc_no='DUP-RACE-1'")).rows[0].n);
check('25 identical concurrent submissions → one document, all answered OK/idempotent', dupLineCount === 2 && dupRes.every((r) => r.status === 200), `${dupLineCount} lines; ${dupRes.map((r) => r.status)}`);
const conflict = await Promise.all(Array.from({ length: 10 }, (_, i) => call(journalRoute.POST, 'POST', '/api/journal', { lines: doc(dupe.clientId, 'DUP-CONFLICT', 1000 + i, dupe.username) }, dupe.token)));
check('conflicting concurrent versions of one doc → exactly one wins', conflict.filter((r) => r.status === 200).length === 1, conflict.map((r) => r.status).join(','));

// ---- 4. bootstrap and state-sync latency at volume -------------------------------------------
const [ownerBoot, ownerBootMs] = await timed(() => call(bootstrapRoute.GET, 'GET', '/api/bootstrap', undefined, owner));
results.push(`Bootstrap (owner, entity=all — Group Consolidation only): ${ownerBootMs.toFixed(0)} ms · ${(ownerBoot.bytes / 1e6).toFixed(1)} MB`);
const [ownerScoped, ownerScopedMs] = await timed(() => call(bootstrapRoute.GET, 'GET', `/api/bootstrap?entity=${clientIds[0]}`, undefined, owner));
results.push(`Bootstrap (owner sign-in, active entity only): ${ownerScopedMs.toFixed(0)} ms · ${(ownerScoped.bytes / 1e6).toFixed(2)} MB`);
check('owner scoped bootstrap returns one entity journal but every client', ownerScoped.body?.state?.journalScope === clientIds[0]
  && ownerScoped.body.state.journalLines.every((l: any) => l.clientId === clientIds[0]) && ownerScoped.body.state.clients.length === CLIENTS + 1);
const forged = await call(bootstrapRoute.GET, 'GET', `/api/bootstrap?entity=${clientIds[1]}`, undefined, admins[0].token);
check('client user cannot widen bootstrap to another entity', forged.body?.state?.journalLines?.every((l: any) => l.clientId === admins[0].clientId));
const a0 = admins[0];
const [clientBoot, clientBootMs] = await timed(() => call(bootstrapRoute.GET, 'GET', '/api/bootstrap', undefined, a0.token));
results.push(`Bootstrap (one client): ${clientBootMs.toFixed(0)} ms · ${(clientBoot.bytes / 1e6).toFixed(2)} MB`);
check('client bootstrap returns only its own journal', clientBoot.body?.state?.journalLines?.every((l: any) => l.clientId === a0.clientId));
const s = clientBoot.body.state;
let currentRevision = s.stateRevision;
const statePayload = (journalLines: unknown[]) => ({
  stateRevision: currentRevision,
  clients: s.clients, journalLines, bankAccounts: s.bankAccounts, purchaseOrders: s.purchaseOrders, salesInvoices: s.salesInvoices,
  employees: s.employees, businessPartners: s.businessPartners, payrollRecords: s.payrollRecords, prepaymentRecords: s.prepaymentRecords,
  prepaymentSchedules: s.prepaymentSchedules, approvalRequests: s.approvalRequests, companyProfiles: s.companyProfiles,
  chartOfAccounts: s.chartOfAccounts, disclosureNotes: s.disclosureNotes, closedPeriods: s.closedPeriods, taxScheduleEntries: s.taxScheduleEntries,
  stockItems: s.stockItems, stockMovements: s.stockMovements, fixedAssets: s.fixedAssets,
});
const syncTimes: number[] = [];
for (let i = 0; i < 8; i++) {
  const [r, ms] = await timed(() => call(stateRoute.PUT, 'PUT', '/api/state', statePayload(s.journalLines), a0.token));
  syncTimes.push(ms); if (r.status !== 200) check(`client state sync ${i}`, false, `${r.status} ${JSON.stringify(r.body)}`);
  else currentRevision = r.body.stateRevision;
}
results.push(`State sync (client, full journal payload ${s.journalLines.length.toLocaleString()} lines): p50 ${pct(syncTimes, 0.5).toFixed(0)} ms`);
const deltaTimes: number[] = [];
for (let i = 0; i < 8; i++) {
  const [r, ms] = await timed(() => call(stateRoute.PUT, 'PUT', '/api/state', statePayload(doc(a0.clientId, `SYNC-DELTA-${i}`, 50, a0.username)), a0.token));
  deltaTimes.push(ms); if (r.status !== 200) check(`client delta sync ${i}`, false, `${r.status} ${JSON.stringify(r.body)}`);
  else currentRevision = r.body.stateRevision;
}
results.push(`State sync (client, only new documents): p50 ${pct(deltaTimes, 0.5).toFixed(0)} ms`);
check('delta sync posted its new documents', Number((await pool.query("select count(*) n from journal_lines where doc_no like 'SYNC-DELTA-%'")).rows[0].n) === 16);
check('delta sync did not delete omitted history', Number((await pool.query('select count(*) n from journal_lines where client_id=$1', [a0.clientId])).rows[0].n) >= DOCS * 2);

// ---- 5. sync and posting racing each other ---------------------------------------------------
const race = await Promise.all([
  ...Array.from({ length: 20 }, (_, i) => call(journalRoute.POST, 'POST', '/api/journal', { lines: doc(a0.clientId, `RACE-J-${i}`, 10, a0.username) }, a0.token)),
  ...Array.from({ length: 4 }, () => call(stateRoute.PUT, 'PUT', '/api/state', statePayload([]), a0.token)),
]);
check('concurrent posts succeed; stale syncs return 409 without overwriting',
  race.slice(0, 20).every((r) => r.status === 200) && race.slice(20).filter((r) => r.status === 200).length === 1
    && race.slice(20).filter((r) => r.status === 409).length === 3, race.map((r) => r.status).join(','));
check('no posted document lost to a stale sync', Number((await pool.query("select count(distinct doc_no) n from journal_lines where doc_no like 'RACE-J-%'")).rows[0].n) === 20);

// ---- 6. production stock race (no negative stock, GL = stock) ---------------------------------
const pc = admins[1];
await pool.query("insert into stock_items (id, client_id, item_code, description, category, uom, quantity_on_hand, unit_cost, total_value, gl_account, cost_method) values ($1,$2,'RM-RACE','Race material','Raw Materials','kg',100,10,1000,'120000','weighted_average'), ($3,$2,'FG-RACE','Race output','Finished Goods','unit',0,0,0,'121000','weighted_average')",
  [randomUUID(), pc.clientId, randomUUID()]);
await call(journalRoute.POST, 'POST', '/api/journal', { lines: [
  { id: randomUUID(), docNo: 'OPEN-RM', period: DATE.slice(0, 7), date: DATE, module: 'FI', docType: 'JE', accountNo: '120000', accountName: 'Inventories', debit: 1000, credit: 0, currency: 'GHS', description: 'Opening stock', createdBy: 'owner', clientId: pc.clientId },
  { id: randomUUID(), docNo: 'OPEN-RM', period: DATE.slice(0, 7), date: DATE, module: 'FI', docType: 'JE', accountNo: '300000', accountName: 'Capital', debit: 0, credit: 1000, currency: 'GHS', description: 'Opening stock', createdBy: 'owner', clientId: pc.clientId },
] }, owner);
const prod = (action: string, payload: Record<string, unknown>, key?: string) => call(productionRoute.POST, 'POST', '/api/production', { clientId: pc.clientId, action, payload, requestKey: key }, owner);
await prod('save_bom', { parentItemCode: 'FG-RACE', componentItemCode: 'RM-RACE', qtyPerUnit: 1, wastePct: 0 });
const ord = await prod('create_order', { itemCode: 'FG-RACE', qty: 1000, startDate: DATE, costCenter: 'CC-PROD' }, randomUUID());
await prod('release_order', { orderId: ord.body?.order?.id });
const issueRace = await Promise.all(Array.from({ length: 30 }, () => prod('issue_material', { orderId: ord.body?.order?.id, itemCode: 'RM-RACE', qty: 5, date: DATE }, randomUUID())));
const okIssues = issueRace.filter((r) => r.status === 200).length;
const rm = (await pool.query("select quantity_on_hand q, total_value v from stock_items where client_id=$1 and item_code='RM-RACE'", [pc.clientId])).rows[0];
check('30 racing issues of 5 kg against 100 kg → exactly 20 succeed, 10 refused', okIssues === 20, `${okIssues} ok`);
check('raw material never negative', Number(rm.q) === 0 && Number(rm.v) === 0, JSON.stringify(rm));
const glRm = Number((await pool.query("select coalesce(sum(debit-credit),0) b from journal_lines where client_id=$1 and account_no='120000'", [pc.clientId])).rows[0].b);
const glWip = Number((await pool.query("select coalesce(sum(debit-credit),0) b from journal_lines where client_id=$1 and account_no='122000'", [pc.clientId])).rows[0].b);
check('stock GL 120000 equals stock value after race (0)', glRm === 0, String(glRm));
check('WIP 122000 equals 20 × 5 kg × 10 = 1,000', glWip === 1000, String(glWip));
const keyRace = randomUUID();
const keyRes = await Promise.all(Array.from({ length: 10 }, () => prod('receive_output', { orderId: ord.body?.order?.id, qty: 50, date: DATE }, keyRace)));
const receipts = Number((await pool.query('select count(*) n from production_receipts where id=$1', [keyRace])).rows[0].n);
check('10 concurrent retries of one output request key → one receipt', receipts === 1 && keyRes.every((r) => r.status === 200), `${receipts}; ${keyRes.map((r) => r.status)}`);

// ---- 7. abuse and resilience -----------------------------------------------------------------
const brute = await Promise.all(Array.from({ length: 12 }, () => call(loginRoute.POST, 'POST', '/api/auth/login', { usernameOrEmail: admins[2].username, password: 'Wrong-Password-1!' })));
check('credential stuffing locks the account (429 after 5 failures)', brute.some((r) => r.status === 429), brute.map((r) => r.status).join(','));
const flood = await pooled(3000, 50, (i) => call(loginRoute.POST, 'POST', '/api/auth/login', { usernameOrEmail: `nobody-${i}@x.invalid`, password: 'x' }));
check('3,000 random-identity login attempts answered without crash', flood.every((r) => r.status === 401 || r.status === 400 || r.status === 429));
const big = '{"lines":[' + Array.from({ length: 200_000 }, () => '{"id":"x"}').join(',') + ']}';
const [bigRes, bigMs] = await timed(() => call(journalRoute.POST, 'POST', '/api/journal', undefined, admins[0].token, big));
check('oversized journal payload rejected with 413', bigRes.status === 413, `${bigRes.status} after ${bigMs.toFixed(0)} ms`);
const junk = await call(journalRoute.POST, 'POST', '/api/journal', undefined, admins[0].token, '{not json');
check('malformed JSON → controlled 400', junk.status === 400, String(junk.status));
const health = await Promise.all(Array.from({ length: 100 }, () => call(healthRoute.GET as Handler, 'GET', '/api/health')));
check('health endpoint stable under 100 parallel probes', health.every((r) => r.status === 200));

// ---- final integrity -------------------------------------------------------------------------
const unbalanced = Number((await pool.query('select count(*) n from (select client_id, doc_no from journal_lines group by 1,2 having round(sum(debit)::numeric,2) <> round(sum(credit)::numeric,2)) x')).rows[0].n);
check('every document in the database balances', unbalanced === 0, `${unbalanced} unbalanced`);
const orphans = Number((await pool.query("select count(*) n from (select distinct client_id, doc_no from journal_lines where doc_no not like 'BULK-%') l left join journal_headers h using (client_id, doc_no) where h.id is null")).rows[0].n);
check('every posted document has a control header', orphans === 0, `${orphans} without header`);
const mem = process.memoryUsage();
results.push(`Process memory after run: RSS ${(mem.rss / 1e6).toFixed(0)} MB, heap ${(mem.heapUsed / 1e6).toFixed(0)} MB`);

console.log('\n' + results.map((r) => `• ${r}`).join('\n'));
console.log(`\nStress test: ${passed} passed, ${failures.length} failed.`);
for (const f of failures) console.log(`FAIL ${f}`);
await pool.end();
process.exit(failures.length ? 1 : 0);
