import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import { clients, users } from "@/db/schema";
import { eq, or, sql } from "drizzle-orm";
import { authJson, createSession, pruneExpiredSessions, sanitizeUser, SESSION_TTL_MS } from "@/lib/auth";
import { hashPassword, needsRehash, newSalt, verifyPassword } from "@/lib/password";
import { BODY_LIMITS, RequestBodyError, readJsonBody } from "@/lib/http";
import { verifyTotp } from "@/lib/totp";

export const dynamic = "force-dynamic";

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MS = 5 * 60 * 1000;

/**
 * Cluster-wide failed-attempt tracking in PostgreSQL. The increment is a single
 * atomic upsert, so parallel guesses — on one instance or many behind a load
 * balancer — can never all observe the same counter.
 */
async function registerAttempt(identifier: string): Promise<{ attempts: number; lockedUntil: number }> {
  const now = Date.now();
  const res = await db.execute<{ attempts: number; locked_until: string | number }>(sql`
    insert into bpz_login_attempts (identifier, attempts, locked_until, updated_at)
    values (${identifier}, 1, 0, ${now})
    on conflict (identifier) do update set
      attempts = case when bpz_login_attempts.locked_until > 0 and bpz_login_attempts.locked_until <= ${now}
                      then 1 else bpz_login_attempts.attempts + 1 end,
      locked_until = case when bpz_login_attempts.locked_until > 0 and bpz_login_attempts.locked_until <= ${now}
                          then 0 else bpz_login_attempts.locked_until end,
      updated_at = ${now}
    returning attempts, locked_until`);
  const row = res.rows[0];
  let attempts = Number(row?.attempts ?? 1);
  let lockedUntil = Number(row?.locked_until ?? 0);
  if (attempts >= MAX_FAILED_ATTEMPTS && lockedUntil <= now) {
    lockedUntil = now + LOCKOUT_MS;
    await db.execute(sql`update bpz_login_attempts set locked_until = ${lockedUntil} where identifier = ${identifier}`);
  }
  attempts = Math.max(attempts, 1);
  return { attempts, lockedUntil };
}

async function currentLock(identifier: string): Promise<number> {
  const res = await db.execute<{ locked_until: string | number }>(sql`select locked_until from bpz_login_attempts where identifier = ${identifier}`);
  return Number(res.rows[0]?.locked_until ?? 0);
}

async function clearAttempts(identifier: string): Promise<void> {
  await db.execute(sql`delete from bpz_login_attempts where identifier = ${identifier}`);
}

type LoginBody = { usernameOrEmail?: unknown; password?: unknown; workspace?: unknown; otp?: unknown };

/**
 * Sign-in.
 *
 * `workspace` is the client code from the sign-in link (`/?workspace=CODE`). When
 * it is supplied the account MUST belong to that workspace (or be the firm owner),
 * so a client can never open another entity's books — and a client link can never
 * drop a client straight into the owner's workspace.
 */
export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    console.error("database provisioning failed", e);
    return authJson(req, { ok: false, error: "The workspace database is unavailable. Please try again in a moment." }, { status: 503 });
  }
  try {
    let body: LoginBody | null = null;
    try {
      body = await readJsonBody<LoginBody>(req, BODY_LIMITS.login);
    } catch (error) {
      const status = error instanceof RequestBodyError ? error.status : 400;
      return authJson(req, { ok: false, error: "Invalid request body." }, { status });
    }
    const identifier = String(body?.usernameOrEmail || "").trim().toLowerCase();
    const password = String(body?.password || "");
    const workspaceCode = String(body?.workspace || "").trim().toUpperCase();
    if (!identifier || !password) {
      return authJson(req, { ok: false, error: "Username and password are required." }, { status: 400 });
    }

    const existingLock = await currentLock(identifier);
    if (existingLock > Date.now()) {
      return authJson(
        req,
        { ok: false, error: "Too many failed attempts. Wait 5 minutes before trying again.", retryAfterSeconds: Math.ceil((existingLock - Date.now()) / 1000) },
        { status: 429 }
      );
    }

    // Count the attempt BEFORE the slow password check (atomic DB upsert).
    const attempt = await registerAttempt(identifier);
    if (attempt.lockedUntil > Date.now() && attempt.attempts > MAX_FAILED_ATTEMPTS) {
      return authJson(
        req,
        { ok: false, error: "Too many failed attempts. Wait 5 minutes before trying again.", retryAfterSeconds: Math.ceil((attempt.lockedUntil - Date.now()) / 1000) },
        { status: 429 }
      );
    }

    const found = await db
      .select()
      .from(users)
      .where(or(sql`lower(${users.username}) = ${identifier}`, sql`lower(${users.email}) = ${identifier}`))
      .limit(1);
    const user = found[0];

    if (!user || !user.passwordHash || !user.passwordSalt || !(await verifyPassword(password, user.passwordSalt, user.passwordHash))) {
      return authJson(req, { ok: false, error: "Invalid username, email, or password." }, { status: 401 });
    }

    if (user.status === "restricted" || user.status === "suspended") {
      return authJson(
        req,
        { ok: false, error: `Account restricted by administrator.${user.restrictionReason ? ` Reason: "${user.restrictionReason}"` : ""}` },
        { status: 403 }
      );
    }

    // Workspace binding (checked only after the password, so it reveals nothing to a guesser).
    let workspace: { id: number; code: string; name: string } | null = null;
    if (workspaceCode) {
      const ws = (await db.select().from(clients).where(sql`upper(${clients.code}) = ${workspaceCode}`).limit(1))[0];
      if (!ws) {
        return authJson(req, { ok: false, error: "That workspace link is not recognised. Check the link your firm sent you." }, { status: 404 });
      }
      if (user.role !== "owner" && user.clientId !== ws.id) {
        return authJson(
          req,
          { ok: false, error: `This account does not belong to the ${ws.code} workspace. Sign in through your own firm's link.` },
          { status: 403 }
        );
      }
      workspace = { id: ws.id, code: ws.code, name: ws.name };
    }

    // Second factor (RFC 6238 TOTP). The password is already proven; without a
    // valid one-time code no session is issued.
    if (user.mfaEnabled && user.mfaSecret) {
      const otp = String(body?.otp ?? "").trim();
      if (!otp) {
        return authJson(req, { ok: false, mfaRequired: true, error: "Enter the 6-digit code from your authenticator app." }, { status: 401 });
      }
      if (!verifyTotp(user.mfaSecret, otp)) {
        // A supplied but wrong second factor is a failed authentication attempt,
        // not an endless free retry loop. Missing code is only the MFA challenge.
        const failedFactor = await registerAttempt(identifier);
        if (failedFactor.lockedUntil > Date.now()) {
          return authJson(req, { ok: false, error: "Too many failed attempts. Wait 5 minutes before trying again.", retryAfterSeconds: Math.ceil((failedFactor.lockedUntil - Date.now()) / 1000) }, { status: 429 });
        }
        return authJson(req, { ok: false, mfaRequired: true, error: "That authenticator code is not valid. Check the time on your phone and try again." }, { status: 401 });
      }
    }

    await clearAttempts(identifier);

    // Transparent credential upgrade: legacy SHA-256 hashes are re-hashed with scrypt
    // on a successful login, so nobody is locked out by the migration.
    if (needsRehash(user.passwordHash)) {
      const salt = newSalt();
      await db
        .update(users)
        .set({ passwordSalt: salt, passwordHash: await hashPassword(password, salt) })
        .where(eq(users.id, user.id));
    }

    const assignedClient = user.clientId
      ? (await db.select().from(clients).where(eq(clients.id, user.clientId)).limit(1))[0] ?? null
      : null;

    const token = await createSession(user.id);
    // Housekeeping — never allowed to fail the sign-in itself.
    void pruneExpiredSessions();

    /**
     * The token travels BOTH as an HttpOnly cookie and in the body (so the browser
     * client can also send it as a Bearer token).
     */
    return authJson(
      req,
      { ok: true, user: sanitizeUser(user), token, expiresInSeconds: SESSION_TTL_MS / 1000, workspace, client: assignedClient },
      { token }
    );
  } catch (e) {
    console.error("login error", e);
    return authJson(req, { ok: false, error: "Login failed." }, { status: 500 });
  }
}
