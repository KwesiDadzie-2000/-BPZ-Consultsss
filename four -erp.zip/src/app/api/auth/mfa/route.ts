import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { auditLog, users } from "@/db/schema";
import { authJson, getSessionUser } from "@/lib/auth";
import { newTotpSecret, otpauthUri, verifyTotp } from "@/lib/totp";
import { verifyPassword } from "@/lib/password";

export const dynamic = "force-dynamic";

/**
 * Self-service multi-factor authentication (RFC 6238 TOTP).
 *  GET    → status for the signed-in user.
 *  POST   { action: "begin" }                → new pending secret + otpauth URI.
 *  POST   { action: "confirm", code }        → enables MFA once a valid code proves the app is set up.
 *  POST   { action: "disable", code, password } → turns MFA off (needs BOTH factors).
 * Every change is written to the audit trail.
 */
async function load(req: Request) {
  await ensureDatabaseReady();
  const session = await getSessionUser(req);
  if (!session) return null;
  const row = (await db.select().from(users).where(eq(users.username, session.username)).limit(1))[0];
  return row ?? null;
}

async function audit(username: string, action: string, details: string, clientId: number | null) {
  try {
    await db.insert(auditLog).values({ id: randomUUID(), timestamp: new Date().toISOString(), userId: username, username, action, target: username, details, clientId });
  } catch (error) {
    console.error("mfa audit failed", error);
  }
}

export async function GET(req: Request) {
  const user = await load(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
  return authJson(req, { ok: true, mfaEnabled: Boolean(user.mfaEnabled), pending: Boolean(user.mfaPendingSecret) });
}

export async function POST(req: Request) {
  const user = await load(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
  let body: { action?: unknown; code?: unknown; password?: unknown };
  try {
    body = JSON.parse((await req.text()).slice(0, 4096));
  } catch {
    return authJson(req, { ok: false, error: "Invalid request body." }, { status: 400 });
  }
  const action = String(body?.action ?? "");
  const code = String(body?.code ?? "");

  if (action === "begin") {
    if (user.mfaEnabled) return authJson(req, { ok: false, error: "MFA is already enabled. Disable it first to re-enrol." }, { status: 409 });
    const secret = newTotpSecret();
    await db.update(users).set({ mfaPendingSecret: secret }).where(eq(users.id, user.id));
    return authJson(req, { ok: true, secret, otpauthUri: otpauthUri(secret, user.email || user.username) });
  }

  if (action === "confirm") {
    if (!user.mfaPendingSecret) return authJson(req, { ok: false, error: "Start enrolment first." }, { status: 409 });
    if (!verifyTotp(user.mfaPendingSecret, code)) return authJson(req, { ok: false, error: "That code does not match. Check the authenticator app and the time on your phone." }, { status: 400 });
    await db.update(users).set({ mfaSecret: user.mfaPendingSecret, mfaPendingSecret: null, mfaEnabled: true }).where(eq(users.id, user.id));
    await audit(user.username, "MFA_ENABLED", "TOTP second factor enrolled", user.clientId ?? null);
    return authJson(req, { ok: true, mfaEnabled: true });
  }

  if (action === "disable") {
    if (!user.mfaEnabled || !user.mfaSecret) return authJson(req, { ok: false, error: "MFA is not enabled." }, { status: 409 });
    const password = String(body?.password ?? "");
    const pwOk = user.passwordHash && user.passwordSalt ? await verifyPassword(password, user.passwordSalt, user.passwordHash) : false;
    if (!pwOk || !verifyTotp(user.mfaSecret, code)) return authJson(req, { ok: false, error: "Both your password and a current authenticator code are required." }, { status: 403 });
    await db.update(users).set({ mfaSecret: null, mfaPendingSecret: null, mfaEnabled: false }).where(eq(users.id, user.id));
    await audit(user.username, "MFA_DISABLED", "TOTP second factor removed by the account holder", user.clientId ?? null);
    return authJson(req, { ok: true, mfaEnabled: false });
  }

  return authJson(req, { ok: false, error: "Unknown action." }, { status: 400 });
}
