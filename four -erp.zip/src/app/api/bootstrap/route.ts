import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import {
  approvalRequests,
  bankAccounts,
  businessPartners,
  chartAccounts,
  closedPeriods,
  clients,
  companyProfiles,
  disclosureNotes,
  employees,
  journalLines,
  payrollRecords,
  prepaymentRecords,
  prepaymentSchedules,
  purchaseOrders,
  salesInvoices,
  stockItems,
  stockMovements,
  fixedAssets,
  taxScheduleEntries,
  users,
  systemSettings,
} from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope, sanitizeUser } from "@/lib/auth";
import { eq, inArray } from "drizzle-orm";
import { applyLedgerAuthority, ledgerTreasuryBalances } from "@/lib/treasuryAuthority";
import { visiblePostingDirectory } from "@/lib/postingControls";
import { canAccessFamily, type WorkspaceFamily } from "@/lib/workspaceScope";
import { maySeeSection } from "@/utils/access";
import type { ClientEntity } from "@/types/accounting";

export const dynamic = "force-dynamic";

/**
 * Returns the full workspace state for the authenticated user, tenant-scoped:
 * the owner receives every entity's books; other users receive only their own
 * entity's data (plus the firm-level chart of accounts and disclosure notes).
 */
export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    console.error("bootstrap: database unavailable", e);
    return authJson(req, { ok: false, error: "database-unavailable" }, { status: 503 });
  }

  let user;
  try {
    user = await getSessionUser(req);
  } catch (e) {
    // An infrastructure fault is NOT an expired session: answering 401 here is
    // what used to throw a signed-in user back to the login portal.
    console.error("bootstrap: session lookup failed", e);
    return authJson(req, { ok: false, error: "session-check-failed" }, { status: 503 });
  }
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });

  const firmWide = hasFirmWideScope(user);
  const clientId = user.clientId ?? null;

  const visibleClients = firmWide
    ? await db.select().from(clients)
    : clientId === null
      ? []
      : await db.select().from(clients).where(eq(clients.id, clientId));
  const visibleIds = visibleClients.map((c) => c.id);
  // Non-firm users read only their own entity at the database, not every tenant filtered in memory.
  const scopeIds = visibleIds.length ? visibleIds : [-1];
  // Firm-wide users load journals per entity (?entity=<id>) so a large practice
  // does not ship every client's ledger to the browser at sign-in. `entity=all`
  // (or no parameter, for older clients) returns every visible entity.
  const entityParam = new URL(req.url).searchParams.get("entity");
  const journalScope = firmWide && entityParam && entityParam !== "all" && visibleIds.includes(Number(entityParam)) ? [Number(entityParam)] : null;
  const scoped = <T extends { clientId: number | null }>(rows: T[]) =>
    firmWide ? rows : rows.filter((r) => r.clientId !== null && visibleIds.includes(r.clientId));

  const [
    allLines,
    allBanks,
    allPOs,
    allInvoices,
    allEmployees,
    allPartners,
    allPayroll,
    allApprovals,
    allClosed,
    allPrepayments,
    allPrepaymentSchedules,
    allTaxSchedules,
    allStockItems,
    allStockMovements,
    allFixedAssets,
  ] = await Promise.all([
    journalScope ? db.select().from(journalLines).where(inArray(journalLines.clientId, journalScope)) : firmWide ? db.select().from(journalLines) : db.select().from(journalLines).where(inArray(journalLines.clientId, scopeIds)),
    firmWide ? db.select().from(bankAccounts) : db.select().from(bankAccounts).where(inArray(bankAccounts.clientId, scopeIds)),
    firmWide ? db.select().from(purchaseOrders) : db.select().from(purchaseOrders).where(inArray(purchaseOrders.clientId, scopeIds)),
    firmWide ? db.select().from(salesInvoices) : db.select().from(salesInvoices).where(inArray(salesInvoices.clientId, scopeIds)),
    firmWide ? db.select().from(employees) : db.select().from(employees).where(inArray(employees.clientId, scopeIds)),
    firmWide ? db.select().from(businessPartners) : db.select().from(businessPartners).where(inArray(businessPartners.clientId, scopeIds)),
    firmWide ? db.select().from(payrollRecords) : db.select().from(payrollRecords).where(inArray(payrollRecords.clientId, scopeIds)),
    firmWide ? db.select().from(approvalRequests) : db.select().from(approvalRequests).where(inArray(approvalRequests.clientId, scopeIds)),
    firmWide ? db.select().from(closedPeriods) : db.select().from(closedPeriods).where(inArray(closedPeriods.clientId, scopeIds)),
    firmWide ? db.select().from(prepaymentRecords) : db.select().from(prepaymentRecords).where(inArray(prepaymentRecords.clientId, scopeIds)),
    firmWide ? db.select().from(prepaymentSchedules) : db.select().from(prepaymentSchedules).where(inArray(prepaymentSchedules.clientId, scopeIds)),
    firmWide ? db.select().from(taxScheduleEntries) : db.select().from(taxScheduleEntries).where(inArray(taxScheduleEntries.clientId, scopeIds)),
    firmWide ? db.select().from(stockItems) : db.select().from(stockItems).where(inArray(stockItems.clientId, scopeIds)),
    firmWide ? db.select().from(stockMovements) : db.select().from(stockMovements).where(inArray(stockMovements.clientId, scopeIds)),
    firmWide ? db.select().from(fixedAssets) : db.select().from(fixedAssets).where(inArray(fixedAssets.clientId, scopeIds)),
  ]);

  // Treasury balances come from the ledger, never from a stored browser figure.
  const treasuryLedger = await ledgerTreasuryBalances(db, visibleIds);
  const authoritativeBanks = applyLedgerAuthority(allBanks, treasuryLedger);

  const profiles = await db.select().from(companyProfiles);
  const allCoa = await db.select().from(chartAccounts);
  // Chart of accounts: firm master (clientId null) plus the user's own entity customs.
  const coa = firmWide ? allCoa : allCoa.filter((a) => a.clientId === null || a.clientId === clientId);
  const notes = await db.select().from(disclosureNotes);
  // The full administration directory remains owner-only. Every posting user,
  // however, needs the maker/checker identities relevant to their own books;
  // returning [] made every newly onboarded client fail local identity validation.
  const revisionSetting = (await db.select({ value: systemSettings.value }).from(systemSettings)
    .where(eq(systemSettings.key, 'workspace_state_revision')).limit(1))[0];
  const stateRevision = Number((revisionSetting?.value as { revision?: number } | undefined)?.revision ?? 0);
  const userDirectory = (await db.select().from(users)).map(sanitizeUser);
  const allUsers = visiblePostingDirectory(userDirectory, user).map((entry) =>
    firmWide || entry.username === user.username ? entry : {
      ...entry,
      email: '', // not needed to validate a maker or checker
      mfaEnabled: false,
      permissions: {
        canPostJournals: entry.permissions?.canPostJournals !== false,
        canApprovePayments: false, canRunPayroll: false, canClosePeriod: false, canModifyCOA: false,
      },
    });
  const entity = !firmWide ? visibleClients[0] as ClientEntity | undefined : undefined;
  const permitted = (family: WorkspaceFamily) => firmWide || canAccessFamily(user, entity ?? null, family, 'read');

  return authJson(req, {
    ok: true,
    state: {
      stateRevision,
      clients: visibleClients,
      // A financial dashboard still needs aggregate journal amounts. Payroll
      // narration is masked for users without the payroll module.
      journalLines: scoped(allLines).map((line) =>
        !firmWide && !permitted('payrollRecords') && line.module === 'HR'
          ? { ...line, description: 'Payroll posting (details restricted)', accountName: line.accountNo }
          : line),
      journalScope: journalScope ? journalScope[0] : "all",
      bankAccounts: permitted('bankAccounts') ? scoped(authoritativeBanks) : [],
      purchaseOrders: permitted('purchaseOrders') ? scoped(allPOs) : [],
      salesInvoices: permitted('salesInvoices') ? scoped(allInvoices) : [],
      employees: permitted('employees') ? scoped(allEmployees) : [],
      businessPartners: permitted('businessPartners') ? scoped(allPartners).map(({ sourceId, id, ...partner }) => ({ ...partner, id: sourceId ?? id })) : [],
      payrollRecords: permitted('payrollRecords') ? scoped(allPayroll).map((r) => r.record) : [],
      approvalRequests: permitted('approvalRequests') ? scoped(allApprovals) : [],
      prepaymentRecords: permitted('prepaymentRecords') ? scoped(allPrepayments).map((r) => r.record) : [],
      prepaymentSchedules: permitted('prepaymentSchedules') ? scoped(allPrepaymentSchedules).map((r) => r.line) : [],
      taxScheduleEntries: permitted('taxScheduleEntries') ? scoped(allTaxSchedules).map((t) => ({ ...t, sourceKey: t.sourceKey ?? undefined, note: t.note ?? undefined })) : [],
      stockItems: permitted('stockItems') ? scoped(allStockItems) : [],
      stockMovements: permitted('stockMovements') ? scoped(allStockMovements) : [],
      fixedAssets: permitted('fixedAssets') ? scoped(allFixedAssets) : [],
      companyProfiles: Object.fromEntries(
        profiles
          .filter((p) => firmWide || (p.clientId === clientId && entity && (
            maySeeSection(user, entity, 'company_profile') || maySeeSection(user, entity, 'ifrs_statements')
          )))
          .map((p) => [p.clientId, p])
      ),
      chartOfAccounts: coa,
      disclosureNotes: firmWide || (entity && maySeeSection(user, entity, 'disclosures')) ? notes : [],
      closedPeriods: scoped(allClosed).map((c) => ({ clientId: c.clientId, period: c.period })),
      users: allUsers,
    },
  });
}
