import { immutableJournalConflict } from '@/lib/immutableJournal';
import { BODY_LIMITS, RequestBodyError, readJsonBody } from "@/lib/http";
import { sequential } from '@/lib/sequential';
import { applyLedgerAuthority, ledgerTreasuryBalances } from '@/lib/treasuryAuthority';
import { registerSettlementError, stockRegisterError } from '@/lib/registerIntegrity';
import { reconcileControlAccounts, controlAccountSummary } from '@/utils/controlAccounts';
import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import {
  approvalRequests,
  auditLog,
  bankAccounts,
  businessPartners,
  chartAccounts,
  closedPeriods,
  clients,
  companyProfiles,
  disclosureNotes,
  employees,
  journalHeaders,
  journalLines,
  postingEvents,
  payrollRecords,
  prepaymentRecords,
  prepaymentSchedules,
  purchaseOrders,
  salesInvoices,
  stockItems,
  stockMovements,
  fixedAssets,
  taxScheduleEntries,
  users,
  systemSettings,
} from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope } from "@/lib/auth";
import { functionalCurrencyMap, validateJournalLines, validateMakerChecker, validatePostingIdentity } from "@/lib/journalValidation";
import { accountPostabilityFor, postingUserDirectory, sessionPostingRecord } from "@/lib/postingControls";
import { mayEditChartOfAccounts, maySeeSection } from "@/utils/access";
import { canAccessFamily, deniedStateWrite, type WorkspaceFamily } from "@/lib/workspaceScope";
import { buildJournalHeader, buildPostingEvent } from "@/lib/journalPosting";
import { prepareBusinessPartnersForStorage } from "@/lib/businessPartnerSync";
import { and, eq, inArray, sql } from "drizzle-orm";
import type {
  ACDOCALine,
  AccountMaster,
  ApprovalRequest,
  BankAccount,
  BusinessPartner,
  ClientEntity,
  DisclosureNote,
  EmployeeProfile,
  MonthlyPayrollRecord,
  PrepaymentRecord,
  PrepaymentScheduleLine,
  FixedAsset,
  PurchaseOrder,
  SalesInvoice,
  StockItem,
  StockMovement,
  TaxScheduleEntry,
} from "@/types/accounting";
import type { CompanyProfile } from "@/utils/persistentStorage";

export const dynamic = "force-dynamic";

class StateSyncConflict extends Error {}

/** Integer id list for a scoped IN (...) clause; ids come from the database. */
function intList(ids: readonly number[]): string {
  if (!ids.length || !ids.every((n) => Number.isSafeInteger(n))) throw new Error("Invalid client scope.");
  return ids.join(",");
}

/** Runs a lookup in parameter-safe chunks (PostgreSQL caps bind parameters at 65,535). */
async function chunked<T>(items: readonly string[], fetch: (chunk: string[]) => Promise<T[]>): Promise<T[]> {
  const out: T[] = [];
  for (let i = 0; i < items.length; i += 5000) out.push(...(await fetch(items.slice(i, i + 5000))));
  return out;
}

interface StatePayload {
  /** Revision returned by /api/bootstrap; stale snapshots cannot replace live registers. */
  stateRevision?: number;
  clients?: ClientEntity[];
  journalLines?: ACDOCALine[];
  bankAccounts?: BankAccount[];
  purchaseOrders?: PurchaseOrder[];
  salesInvoices?: SalesInvoice[];
  employees?: EmployeeProfile[];
  businessPartners?: BusinessPartner[];
  payrollRecords?: MonthlyPayrollRecord[];
  prepaymentRecords?: PrepaymentRecord[];
  prepaymentSchedules?: PrepaymentScheduleLine[];
  approvalRequests?: ApprovalRequest[];
  companyProfiles?: Record<number, CompanyProfile>;
  chartOfAccounts?: AccountMaster[];
  disclosureNotes?: DisclosureNote[];
  closedPeriods?: { clientId: number; period: string }[];
  /** Optional (older browsers may not send it); when present it is replaced tenant-scoped. */
  taxScheduleEntries?: TaxScheduleEntry[];
  /** Perpetual inventory + asset register (optional for older browsers). */
  stockItems?: StockItem[];
  stockMovements?: StockMovement[];
  fixedAssets?: FixedAsset[];
}

/**
 * Full-state sync. The server is authoritative: journal lines are validated
 * (tenant, open periods, COA existence, double entry) and the whole write is one
 * transaction. Firm-level masters (clients, COA, disclosures) are owner-writable
 * only; every operational row is tenant-filtered.
 */
export async function PUT(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    // Infrastructure fault → 503. Never 401: a 401 is what signs the user out.
    console.error("state sync: database unavailable", e);
    return authJson(req, { ok: false, error: "database-unavailable" }, { status: 503 });
  }
  try {
    return await handlePut(req);
  } catch (error) {
    if (error instanceof StateSyncConflict) {
      return authJson(req, { ok: false, error: error.message }, { status: 409 });
    }
    const reference = crypto.randomUUID();
    const cause = error instanceof Error ? error.cause : undefined;
    const candidate = error && typeof error === "object" && "code" in error
      ? (error as { code?: unknown }).code
      : cause && typeof cause === "object" && "code" in cause
        ? (cause as { code?: unknown }).code
        : undefined;
    const code = typeof candidate === "string" ? candidate : undefined;
    console.error(`[state-sync:${reference}] ${error instanceof Error ? error.name : "UnknownError"}${code ? ` code=${code}` : ""}`);
    return Response.json({
      ok: false,
      error: `Workspace sync failed. No changes were saved. Retry the sync; if it continues, share reference ${reference}.`,
      reference,
    }, { status: 500 });
  }
}

async function handlePut(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
  if (user.status !== 'active' || user.role === 'auditor') {
    return authJson(req, { ok: false, error: 'This account has read-only access to workspace state.' }, { status: 403 });
  }

  let body: StatePayload;
  try {
    body = await readJsonBody(req, BODY_LIMITS.state);
  } catch (error) {
    if (error instanceof RequestBodyError && error.status === 413) return Response.json({ ok: false, error: error.message }, { status: 413 });
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }

  // Full-state sync contract: partial payloads are rejected so a sync can never
  // silently wipe datasets the caller did not include.
  const coreFields: (keyof StatePayload)[] = [
    "journalLines", "bankAccounts", "purchaseOrders", "salesInvoices", "employees",
    "businessPartners", "payrollRecords", "prepaymentRecords", "prepaymentSchedules",
    "approvalRequests", "closedPeriods", "companyProfiles",
  ];
  if (!body || typeof body !== "object" || coreFields.some((f) => body[f] === undefined)) {
    return Response.json({ ok: false, error: "Partial state sync rejected — send the full workspace state." }, { status: 400 });
  }

  if (!body || typeof body !== 'object' || Array.isArray(body)) return Response.json({ ok: false, error: 'Invalid workspace object.' }, { status: 400 });
  const arrayFields = coreFields.filter((field) => field !== 'companyProfiles');
  if (arrayFields.some((field) => !Array.isArray(body[field])) || !body.companyProfiles || typeof body.companyProfiles !== 'object' || Array.isArray(body.companyProfiles)) {
    return Response.json({ ok: false, error: 'Invalid workspace data types.' }, { status: 400 });
  }
  if (body.journalLines!.some((line) => !line || typeof line.docNo !== 'string' || !line.docNo.trim() || typeof line.id !== 'string')) return Response.json({ ok: false, error: 'Invalid journal identity.' }, { status: 400 });
  if (!Number.isSafeInteger(body.stateRevision) || (body.stateRevision ?? -1) < 0) {
    return Response.json({ ok: false, error: 'This browser has no server snapshot revision. Reload your workspace before syncing; no books were changed.' }, { status: 428 });
  }
  const isOwner = user.role === "owner";
  const firmWide = hasFirmWideScope(user);
  const myClientId = user.clientId ?? null;

  // Tenant filter: non-owners may only touch their own entity (or untagged legacy rows).
  const tenantOk = (clientId: number | undefined | null): boolean =>
    firmWide || (myClientId !== null && clientId === myClientId);

  const lines = body.journalLines ?? [];
  const banks = body.bankAccounts ?? [];
  const pos = body.purchaseOrders ?? [];
  const invoices = body.salesInvoices ?? [];
  const emps = body.employees ?? [];
  const partners = body.businessPartners ?? [];
  const partnerPreparation = prepareBusinessPartnersForStorage(partners, firmWide ? null : myClientId);
  if (!partnerPreparation.ok) {
    return Response.json({ ok: false, error: partnerPreparation.error }, { status: partnerPreparation.status });
  }
  const storedPartners = partnerPreparation.rows;
  const payroll = body.payrollRecords ?? [];
  const prepayments = body.prepaymentRecords ?? [];
  const prepaidSchedules = body.prepaymentSchedules ?? [];
  const approvals = body.approvalRequests ?? [];
  const closed = body.closedPeriods ?? [];
  const profiles = body.companyProfiles ?? {};
  const taxEntries = body.taxScheduleEntries;
  const stock = body.stockItems;
  const movements = body.stockMovements;
  const assets = body.fixedAssets;

  if (!firmWide) {
    const rows: (number | undefined | null)[] = [
      ...lines.map((l) => l.clientId),
      ...banks.map((b) => b.clientId),
      ...pos.map((p) => p.clientId),
      ...invoices.map((i) => i.clientId),
      ...emps.map((e) => e.clientId),
      ...partners.map((p) => p.clientId),
      ...payroll.map((r) => r.clientId),
      ...prepayments.map((p) => p.clientId),
      ...prepaidSchedules.map((s) => s.clientId),
      ...approvals.map((a) => a.clientId),
      ...closed.map((c) => c.clientId),
      ...(taxEntries ?? []).map((t) => t.clientId),
      ...(stock ?? []).map((i) => i.clientId),
      ...(movements ?? []).map((m) => m.clientId),
      ...(assets ?? []).map((a) => a.clientId),
    ];
    if (rows.some((id) => !tenantOk(id))) {
      return Response.json({ ok: false, error: "Cross-tenant write rejected." }, { status: 403 });
    }
    if (Object.keys(profiles).some((id) => Number(id) !== myClientId)) {
      return Response.json({ ok: false, error: "Cross-tenant profile write rejected." }, { status: 403 });
    }
  }

  // Journal validation (tenant, periods, COA, double entry).
  const [allClients, allCoa, allClosed, allApprovals, allUsers] = await Promise.all([
    db.select().from(clients),
    db.select().from(chartAccounts),
    db.select().from(closedPeriods),
    db.select().from(approvalRequests),
    db.select().from(users),
  ]);
  const userDirectory = postingUserDirectory(allUsers);
  const functionalCurrencies = functionalCurrencyMap(allClients);
  const allowedClientIds = firmWide ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
  const ownEntity = allClients.find((c) => c.id === myClientId) as ClientEntity | undefined;
  const canWrite = (family: WorkspaceFamily) =>
    isOwner || (firmWide && myClientId === null) || canAccessFamily(user, ownEntity ?? null, family, 'write');
  if (!firmWide && !ownEntity) return authJson(req, { ok: false, error: 'No active client entity is assigned.' }, { status: 403 });
  const deniedFamily = !firmWide ? deniedStateWrite(user, ownEntity ?? null, {
    bankAccounts: banks, purchaseOrders: pos, salesInvoices: invoices, employees: emps,
    businessPartners: partners, payrollRecords: payroll, prepaymentRecords: prepayments,
    prepaymentSchedules: prepaidSchedules, approvalRequests: approvals, stockItems: stock,
    stockMovements: movements, fixedAssets: assets, taxScheduleEntries: taxEntries,
  }) : null;
  if (deniedFamily) return authJson(req, { ok: false, error: deniedFamily }, { status: 403 });
  if (!firmWide && Object.keys(profiles).length && !maySeeSection(user, ownEntity!, 'company_profile')) {
    return authJson(req, { ok: false, error: 'Company Profile is not assigned to this account.' }, { status: 403 });
  }
  // Periods are frozen per entity — key by client so one entity's close never blocks another.
  const closedKeys = new Set(
    allClosed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`)
  );
  // COA scope: firm master plus the writable entities' custom accounts.
  const coaNos = new Set(allCoa.filter((a) => a.clientId === null || allowedClientIds.includes(a.clientId)).map((a) => a.accountNo));
  // Duplicate document check against the server copy: documents already posted
  // are re-sent unchanged by the full-state sync; a conflict (same document
  // number, different lines) is rejected.
  // Journals are append-only: a sync never deletes or rewrites a posted
  // document, so only the documents IN THIS PAYLOAD are compared. Scanning the
  // whole multi-tenant journal here made every sync cost O(all books).
  const payloadDocNos = [...new Set(lines.map((l) => l.docNo))];
  const serverLines = allowedClientIds.length ? await chunked(payloadDocNos, (chunk) => db.select().from(journalLines)
    .where(and(inArray(journalLines.clientId, allowedClientIds), inArray(journalLines.docNo, chunk)))) : [];
  const existingDocs = new Set(serverLines.map((l) => `${l.clientId}:${l.docNo}`));
  const docs = new Map<string, ACDOCALine[]>();
  for (const l of lines) {
    const key = `${l.clientId}:${l.docNo}`;
    if (!docs.has(key)) docs.set(key, []);
    docs.get(key)!.push(l);
  }
  const recentCash = { rows: allowedClientIds.length ? (await db.execute<{ bank_account_id: number }>(sql`select distinct bank_account_id from trade_cash_movements
    where created_at > now() - interval '10 minutes' and client_id in (${sql.raw(intList(allowedClientIds))})`)).rows : [] };
  // Treasury: a cash movement posted by the server-side trade engine may not be
  // in a stale browser tab yet — keep the server balance for that account.
  if (recentCash.rows.length) {
    const serverBanks = await db.select().from(bankAccounts);
    for (const r of recentCash.rows) {
      const server = serverBanks.find((b) => b.id === r.bank_account_id);
      const idx = banks.findIndex((b) => b.id === r.bank_account_id);
      if (server && idx >= 0) banks[idx] = { ...banks[idx], balance: server.balance };
    }
  }
  const warnings: string[] = [];
  const immutableError = immutableJournalConflict(serverLines, lines);
  if (immutableError) return Response.json({ ok: false, error: immutableError }, { status: 409 });

  // Journal validation applies to NEW documents only — re-sent documents are
  // already in the books, so closing one of their periods afterwards must not
  // block the workspace sync (which would make the period impossible to reopen).
  let freshKeys = new Set([...docs.keys()].filter((key) => !existingDocs.has(key)));
  const freshLines = lines.filter((l) => freshKeys.has(`${l.clientId}:${l.docNo}`));
  // An empty journal list is valid for the full-state sync (nothing to validate) —
  // "no lines" is only an error for single-document posting.
  // New documents arriving through the workspace sync face exactly the same
  // controls as single-document posting: identity binding (maker or named
  // checker must be the signed-in user), document integrity, and the maker's
  // own limit with an independent, authorised checker above it.
  const identityError = freshLines.length
    ? validatePostingIdentity(freshLines, { session: sessionPostingRecord(user), users: userDirectory })
    : null;
  if (identityError) return authJson(req, { ok: false, error: identityError }, { status: 403 });
  const journalError = freshLines.length
    ? validateJournalLines(freshLines, { allowedClientIds, closedPeriodKeys: closedKeys, coaAccountNos: coaNos, isAccountPostable: accountPostabilityFor(allCoa) })
    : null;
  if (journalError) return Response.json({ ok: false, error: journalError }, { status: 409 });
  const sodError = freshLines.length
    ? validateMakerChecker(freshLines, { username: user.username, makerLimit: user.makerLimit, users: userDirectory, functionalCurrencies })
    : null;
  if (sodError) return Response.json({ ok: false, error: sodError }, { status: 409 });

  let transactionError: string | null = null;
  let committedRevision = 0;
  await db.transaction(async (tx) => {
    // Serialize full-state replacements so concurrent browser tabs cannot interleave deletes and inserts.
    await tx.execute(sql`select pg_advisory_xact_lock(4027332)`);
    const revisionRow = (await tx.select({ value: systemSettings.value }).from(systemSettings)
      .where(eq(systemSettings.key, 'workspace_state_revision')).limit(1))[0];
    const serverRevision = Number((revisionRow?.value as { revision?: number } | undefined)?.revision ?? 0);
    if (body.stateRevision !== serverRevision) {
      throw new StateSyncConflict(`This workspace was changed in another tab (server revision ${serverRevision}, your revision ${body.stateRevision}). Reload to see the latest records before saving; nothing was overwritten.`);
    }
    // Operational tables: tenant-scoped replace. The owner syncs the whole
    // workspace, so their replace clears the entire table first — legacy rows
    // outside the current client list must never survive to cause key collisions.
    const writableIds = firmWide ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
    const insertInBatches = async (table: any, rows: any[]) => {
      const batchSize = 250;
      for (let start = 0; start < rows.length; start += batchSize) {
        await tx.insert(table).values(rows.slice(start, start + batchSize));
      }
    };
    const replace = async (table: any, rows: any[], mapRow: (r: any) => Record<string, unknown>) => {
      if (isOwner) {
        await tx.delete(table);
      } else if (writableIds.length) {
        await tx.delete(table).where(inArray(table.clientId, writableIds));
      }
      if (rows.length) await insertInBatches(table, rows.map(mapRow));
    }; 

    // Recheck under the same lock as /api/journal. Missing browser records are
    // retained; neither posted lines nor their headers are ever replaced.
    const [latestCoa, latestClosed, latestUsers] = await sequential([
      tx.select().from(chartAccounts), tx.select().from(closedPeriods), tx.select().from(users),
    ]);
    const latestLines = allowedClientIds.length ? await chunked(payloadDocNos, (chunk) => tx.select().from(journalLines)
      .where(and(inArray(journalLines.clientId, allowedClientIds), inArray(journalLines.docNo, chunk)))) : [];
    // Production and trade stock movements are written on the server with their
    // journals. A stale browser tab must not overwrite them: under the shared
    // posting lock, carry forward any the payload omits and adopt the server row.
    if (movements && stock && allowedClientIds.length) {
      const scope = sql.raw(intList(allowedClientIds));
      const serverOwned = await tx.execute<{ id: string; client_id: number; date: string; item_code: string; description: string; type: string;
        quantity: number; unit_cost: number; total_value: number; uom: string; reference: string | null; doc_no: string | null; note: string | null }>(sql`
        select m.* from stock_movements m where m.client_id in (${scope}) and (
          m.id in (select stock_movement_id from production_issues where client_id in (${scope})
                   union all select stock_movement_id from production_receipts where client_id in (${scope}))
          or exists (select 1 from trade_documents d where d.client_id = m.client_id and d.doc_no = m.doc_no))`);
      const supplied = new Set(movements.map((m) => m.id));
      const affected = new Set<string>();
      for (const m of serverOwned.rows) {
        if (supplied.has(m.id)) continue;
        movements.push({ id: m.id, clientId: m.client_id, date: m.date, itemCode: m.item_code, description: m.description,
          type: m.type as StockMovement['type'], quantity: Number(m.quantity), unitCost: Number(m.unit_cost), totalValue: Number(m.total_value),
          uom: m.uom, reference: m.reference ?? undefined, docNo: m.doc_no ?? undefined, note: m.note ?? undefined });
        affected.add(`${m.client_id}:${m.item_code}`);
      }
      if (affected.size) {
        const latestItems = await tx.select().from(stockItems).where(inArray(stockItems.clientId, allowedClientIds));
        for (const identifier of affected) {
          const row = latestItems.find((i) => `${i.clientId}:${i.itemCode}` === identifier);
          if (!row) { transactionError = `A posted production/trade movement has no item master (${identifier}). Sync refused.`; return; }
          const canonical: StockItem = { id: row.id, clientId: row.clientId, itemCode: row.itemCode,
            description: row.description, category: row.category, uom: row.uom, quantityOnHand: row.quantityOnHand,
            unitCost: row.unitCost, totalValue: row.totalValue, reorderLevel: row.reorderLevel ?? undefined,
            location: row.location ?? undefined, glAccount: row.glAccount ?? undefined,
            costMethod: (row.costMethod ?? 'weighted_average') as StockItem['costMethod'],
            netRealisableValue: row.netRealisableValue ?? undefined };
          const at = stock.findIndex((i) => `${i.clientId}:${i.itemCode}` === identifier);
          if (at === -1) stock.push(canonical); else stock[at] = canonical;
        }
      }
    }
    transactionError = immutableJournalConflict(latestLines, lines);
    if (transactionError) return;
    const latestKeys = new Set(latestLines.map((line) => `${line.clientId}:${line.docNo}`));
    freshKeys = new Set([...docs.keys()].filter((key) => !latestKeys.has(key)));
    const newLines = lines.filter((line) => freshKeys.has(`${line.clientId}:${line.docNo}`));
    const latestDirectory = postingUserDirectory(latestUsers);
    if (newLines.length) {
      transactionError = validateJournalLines(newLines, {
        allowedClientIds, closedPeriodKeys: new Set(latestClosed.map((row) => `${row.clientId}:${row.period}`)),
        coaAccountNos: new Set(latestCoa.map((row) => row.accountNo)), isAccountPostable: accountPostabilityFor(latestCoa),
      }) || validatePostingIdentity(newLines, { session: sessionPostingRecord(user), users: latestDirectory })
        || validateMakerChecker(newLines, { username: user.username, makerLimit: user.makerLimit, users: latestDirectory, functionalCurrencies });
      if (transactionError) return;
      const taken = await chunked(newLines.map((line) => line.id), (chunk) =>
        tx.select({ id: journalLines.id }).from(journalLines).where(inArray(journalLines.id, chunk)));
      if (taken.length) { transactionError = 'Journal line id already exists.'; return; }
    }
    const previousPeriods = latestClosed.filter((row) => allowedClientIds.includes(row.clientId)).map((row) => `${row.clientId}:${row.period}`).sort();
    const nextPeriods = closed.map((row) => `${row.clientId}:${row.period}`).sort();
    const periodsChanged = JSON.stringify(previousPeriods) !== JSON.stringify(nextPeriods);
    if (periodsChanged && !isOwner && (user.permissions?.canClosePeriod !== true || (ownEntity && !maySeeSection(user, ownEntity, 'month_end')))) {
      transactionError = 'You do not have permission to close or reopen accounting periods.'; return;
    }
    const latestApprovals = await tx.select().from(approvalRequests).where(inArray(approvalRequests.clientId, writableIds.length ? writableIds : [-1]));
    const approvalIds = new Set(approvals.map((a) => a.id));
    for (const old of latestApprovals) {
      if (!approvalIds.has(old.id)) {
        // A different tab may have queued a request after this snapshot loaded.
        // An omitted request is retained, never deleted by a stale browser.
        approvals.push({ ...old, payload: old.payload as ApprovalRequest['payload'], reviewedBy: old.reviewedBy ?? undefined,
          reviewedAt: old.reviewedAt ?? undefined, rejectionReason: old.rejectionReason ?? undefined } as ApprovalRequest);
      }
    }
    for (const request of approvals) {
      const old = latestApprovals.find((row) => row.id === request.id);
      if (!old) {
        if (request.status !== 'pending' || request.payload?.lines?.some((line) =>
          line.createdBy !== user.username || line.docNo !== request.docNo || line.clientId !== request.clientId)) {
          transactionError = 'A new approval request must be pending and contain only the authenticated maker’s own document.'; return;
        }
        continue;
      }
      if (old.clientId !== request.clientId || old.docNo !== request.docNo || old.requestedBy !== request.requestedBy
        || Math.round(old.amount * 100) !== Math.round(request.amount * 100)
        || JSON.stringify(old.payload) !== JSON.stringify(request.payload)) {
        transactionError = `Approval request ${old.docNo} is immutable. Reload instead of changing the maker, amount or document payload.`; return;
      }
      if (old.status !== request.status) {
        if (old.status !== 'pending' || !['approved', 'rejected'].includes(request.status)
          || !(isOwner || user.canCheck) || request.reviewedBy !== user.username
          || request.payload?.lines?.some((line) => line.createdBy === user.username)) {
          transactionError = 'Approval decisions require an independent authenticated checker.'; return;
        }
        if (request.status === 'approved' && request.payload?.lines?.length) {
          const posted = await tx.select({ id: journalHeaders.id }).from(journalHeaders)
            .where(and(eq(journalHeaders.clientId, request.clientId), eq(journalHeaders.docNo, request.docNo))).limit(1);
          if (!posted.length) { transactionError = `Approval ${request.docNo} has no posted journal. Post it through the checker workflow before marking it approved.`; return; }
        }
        if (request.status === 'rejected' && !request.rejectionReason?.trim()) {
          transactionError = 'An independent checker must record a reason when rejecting an approval.'; return;
        }
      }
    }
    if (newLines.length) {
      await insertInBatches(journalLines, newLines.map((line) => ({ ...line, costCenter: line.costCenter ?? null, checkedBy: line.checkedBy ?? null, reference: line.reference ?? null })));
      const newDocuments = [...freshKeys].map((key) => docs.get(key)!);
      await insertInBatches(journalHeaders, newDocuments.map((document) => buildJournalHeader(document)));
      for (const document of newDocuments) await tx.insert(postingEvents).values(buildPostingEvent(document, user.username)).onConflictDoNothing();
    }
    // Working registers must follow posted documents. Neither a malicious client
    // nor a stale tab may mark a PO/invoice Paid, rewrite a posted amount, erase a
    // stock movement or change inventory value without corresponding GL evidence.
    if (canWrite('purchaseOrders') || canWrite('salesInvoices')) {
      const [storedOrders, storedInvoices] = await sequential([
        tx.select().from(purchaseOrders).where(inArray(purchaseOrders.clientId, writableIds.length ? writableIds : [-1])),
        tx.select().from(salesInvoices).where(inArray(salesInvoices.clientId, writableIds.length ? writableIds : [-1])),
      ]);
      const postedLedger = await tx.select().from(journalLines)
        .where(inArray(journalLines.clientId, writableIds.length ? writableIds : [-1]));
      const journal = postedLedger as unknown as ACDOCALine[];
      if (canWrite('purchaseOrders')) {
        const error = registerSettlementError(storedOrders as unknown as PurchaseOrder[], pos, journal, 'purchase order');
        if (error) throw new StateSyncConflict(error);
      }
      if (canWrite('salesInvoices')) {
        const error = registerSettlementError(storedInvoices as unknown as SalesInvoice[], invoices, journal, 'invoice');
        if (error) throw new StateSyncConflict(error);
      }
    }
    if (canWrite('stockItems') || canWrite('stockMovements')) {
      if (!stock || !movements) throw new StateSyncConflict('Stock sync requires both the item register and immutable movement history. Reload this workspace.');
      const scope = writableIds.length ? writableIds : [-1];
      const [priorItems, priorMovements, stockLedger] = await sequential([
        tx.select().from(stockItems).where(inArray(stockItems.clientId, scope)),
        tx.select().from(stockMovements).where(inArray(stockMovements.clientId, scope)),
        tx.select().from(journalLines).where(inArray(journalLines.clientId, scope)),
      ]);
      const error = stockRegisterError(priorItems as unknown as StockItem[], stock,
        priorMovements as unknown as StockMovement[], movements, stockLedger as unknown as ACDOCALine[]);
      if (error) throw new StateSyncConflict(error);
    }
    // Server authority: treasury balances are re-derived from the ledger INSIDE
    // this transaction (after this sync's new journals are inserted), so a
    // browser-edited balance can never be persisted out of agreement with the GL.
    const ledgerTreasury = await ledgerTreasuryBalances(tx, writableIds);
    const authoritative = applyLedgerAuthority(
      banks.map((b) => ({ ...b, clientId: b.clientId ?? null })),
      ledgerTreasury,
    );
    for (let i = 0; i < banks.length; i += 1) {
      if (Math.abs((authoritative[i].balance ?? 0) - (banks[i].balance ?? 0)) > 0.005) {
        warnings.push(`Treasury record ${banks[i].code} balance was reset to the ledger figure ${authoritative[i].balance.toFixed(2)} (browser sent ${Number(banks[i].balance ?? 0).toFixed(2)}). Post a journal to move cash.`);
      }
      banks[i] = { ...banks[i], balance: authoritative[i].balance };
    }
    // Server-enforced month-end gate: a non-owner cannot freeze a period while
    // any control account of that entity disagrees with its sub-ledger.
    if (!isOwner) {
      const prevClosedKeys = new Set(latestClosed.filter((row) => allowedClientIds.includes(row.clientId)).map((row) => `${row.clientId}:${row.period}`));
      const newlyClosedClients = [...new Set(closed.filter((c) => !prevClosedKeys.has(`${c.clientId}:${c.period}`)).map((c) => c.clientId))];
      for (const cid of newlyClosedClients) {
        const entityLines = await tx.select().from(journalLines).where(eq(journalLines.clientId, cid));
        const rows = reconcileControlAccounts({
          clientId: cid,
          // This sync's new journals were already inserted above in this transaction.
          lines: entityLines as unknown as ACDOCALine[],
          invoices, orders: pos, stockItems: stock ?? [], bankAccounts: banks, assets: assets ?? [],
          prepayments, prepaymentSchedules: prepaidSchedules, payrollRecords: payroll,
          partners: partners as never, taxEntries: taxEntries ?? [],
        });
        const summary = controlAccountSummary(rows);
        if (summary.outOfBalance > 0) {
          // A normal return here would COMMIT the new journal documents inserted
          // above despite telling the caller 409. Throw to roll back the entire
          // transaction, including its headers, posting events and balances.
          throw new StateSyncConflict(`Period close refused: ${summary.outOfBalance} control account(s) are out of balance with their sub-ledgers (${summary.exceptions.map((e) => `${e.label} ${e.difference.toFixed(2)}`).join('; ')}). Clear them on the Control Accounts desk or ask the Firm Owner to override.`);
        }
      }
    }
    // Settlement coherence: paid can never exceed the document total nor go
    // negative, and the status must agree with the amounts.
    for (const p of pos) {
      const total = Number(p.totalAmount) || 0;
      const paid = Math.min(Math.max(0, Number(p.paidAmount) || 0), total);
      p.paidAmount = Math.round(paid * 100) / 100;
      if (p.status === 'Paid' && paid + 0.009 < total) p.status = paid > 0 ? 'Invoiced' : (p.status === 'Paid' ? 'Invoiced' : p.status);
      if ((p.status === 'Invoiced') && total > 0 && paid + 0.009 >= total) p.status = 'Paid';
    }
    for (const inv of invoices) {
      const total = Number(inv.totalReceivable) || 0;
      const paid = Math.min(Math.max(0, Number(inv.paidAmount) || 0), total);
      inv.paidAmount = Math.round(paid * 100) / 100;
      if (inv.status === 'Paid' && paid + 0.009 < total) inv.status = paid > 0 ? 'Partial' : 'Open';
      if ((inv.status === 'Open' || inv.status === 'Partial') && total > 0 && paid + 0.009 >= total) inv.status = 'Paid';
    }
    if (canWrite('bankAccounts')) await replace(bankAccounts, banks, (b) => ({ 
      id: b.id, clientId: b.clientId ?? 0, code: b.code, name: b.name, bankName: b.bankName, accountNo: b.accountNo,
      currency: b.currency, balance: b.balance, kind: b.kind ?? null, glAccount: b.glAccount ?? null,
    }));
    if (canWrite('purchaseOrders')) await replace(purchaseOrders, pos, (p) => ({
      id: p.id, clientId: p.clientId ?? 0, poNo: p.poNo, vendorName: p.vendorName, itemType: p.itemType,
      itemDescription: p.itemDescription, qty: p.qty, unitPrice: p.unitPrice, vatRecoverable: p.vatRecoverable,
      totalAmount: p.totalAmount, paidAmount: p.paidAmount ?? 0, status: p.status, date: p.date,
      currency: p.currency ?? null, vatTreatment: p.vatTreatment ?? null, netAmount: p.netAmount ?? null,
      quotationRef: p.quotationRef ?? null, glAccount: p.glAccount, glAccountName: p.glAccountName,
      costCenter: p.costCenter, costCenterName: p.costCenterName,
    }));
    if (canWrite('salesInvoices')) await replace(salesInvoices, invoices, (i) => ({
      id: i.id, clientId: i.clientId ?? 0, invNo: i.invNo, customerName: i.customerName, revenueStream: i.revenueStream,
      netRevenue: i.netRevenue, vatOutput: i.vatOutput, cstAmount: i.cstAmount ?? null,
      tourismLevyAmount: i.tourismLevyAmount ?? null, vatWithheldByCustomer: i.vatWithheldByCustomer ?? null,
      totalReceivable: i.totalReceivable, paidAmount: i.paidAmount, status: i.status, date: i.date,
    }));
    if (canWrite('employees')) await replace(employees, emps, (e) => ({
      id: e.id, clientId: e.clientId ?? null, bpNo: e.bpNo, name: e.name, role: e.role, department: e.department,
      costCenter: e.costCenter ?? null, jurisdiction: e.jurisdiction, basicSalary: e.basicSalary, allowances: e.allowances, ssnitNumber: e.ssnitNumber,
      tin: e.tin, status: e.status, isResident: e.isResident ?? true, exemptTier1: e.exemptTier1 ?? false,
      exemptTier2: e.exemptTier2 ?? false, ssnitExempt: e.ssnitExempt ?? false,
      ssnitExemptionReason: e.ssnitExemptionReason ?? null, taxRelief: e.taxRelief ?? 0, reliefType: e.reliefType ?? null,
      deductions: e.deductions ?? null,
    }));
    if (canWrite('businessPartners')) await replace(businessPartners, storedPartners, (p) => ({
      id: p.id, sourceId: p.sourceId, clientId: p.clientId ?? null, code: p.code, name: p.name, type: p.type, tin: p.tin, email: p.email,
      phone: p.phone, address: p.address, currency: p.currency, isVatWithholdingAgent: p.isVatWithholdingAgent,
      vatWithholdingRate: p.vatWithholdingRate ?? null, isCstApplicable: p.isCstApplicable,
      isTourismLevyApplicable: p.isTourismLevyApplicable, isVatRegistered: p.isVatRegistered ?? null,
    }));
    // Only users with payroll permission (and payroll module ticked, if restricted) may overwrite payroll records.
    const mayWritePayroll = canWrite('payrollRecords');
    if (mayWritePayroll) {
      await replace(payrollRecords, payroll, (r) => ({ id: r.id, clientId: r.clientId ?? 0, record: r }));
    }
    if (canWrite('prepaymentRecords')) await replace(prepaymentRecords, prepayments, (p) => ({ id: p.id, clientId: p.clientId ?? 0, record: p }));
    if (canWrite('prepaymentSchedules')) await replace(prepaymentSchedules, prepaidSchedules, (s) => ({ id: s.id, prepaymentId: s.prepaymentId, clientId: s.clientId ?? 0, line: s }));
    if (canWrite('approvalRequests')) await replace(approvalRequests, approvals, (a) => ({
      id: a.id, clientId: a.clientId, clientCode: a.clientCode, clientName: a.clientName, docNo: a.docNo,
      docType: a.docType, amount: a.amount, requestedBy: a.requestedBy, requestedAt: a.requestedAt,
      description: a.description, reasonForApproval: a.reasonForApproval, status: a.status,
      reviewedBy: a.reviewedBy ?? null, reviewedAt: a.reviewedAt ?? null, rejectionReason: a.rejectionReason ?? null,
      payload: a.payload ?? null,
    }));
    // A routine sync must not rewrite the original close timestamp or maker.
    // New closes/reopens change only their own period; other entities stay intact.
    if (periodsChanged) {
      const prior = new Set(previousPeriods);
      const next = new Set(nextPeriods);
      for (const existing of latestClosed) {
        if (allowedClientIds.includes(existing.clientId) && !next.has(`${existing.clientId}:${existing.period}`)) {
          await tx.delete(closedPeriods).where(and(eq(closedPeriods.clientId, existing.clientId), eq(closedPeriods.period, existing.period)));
        }
      }
      for (const row of closed) {
        if (!prior.has(`${row.clientId}:${row.period}`)) {
          await tx.insert(closedPeriods).values({ clientId: row.clientId, period: row.period, closedAt: new Date().toISOString(), closedBy: user.username });
        }
      }
    }
    // Statutory schedule edits/additions (WHT & VAT) — only when the browser sent them.
    if (taxEntries && canWrite('taxScheduleEntries')) {
      await replace(taxScheduleEntries, taxEntries, (t) => ({
        id: t.id, clientId: t.clientId, kind: t.kind, source: t.source, sourceKey: t.sourceKey ?? null,
        period: t.period, date: t.date, docNo: t.docNo, partyName: t.partyName, partyTin: t.partyTin ?? "",
        nature: t.nature ?? "", grossAmount: t.grossAmount ?? 0, rate: t.rate ?? 0, taxAmount: t.taxAmount ?? 0,
        levyAmount: t.levyAmount ?? 0, reference: t.reference ?? "", status: t.status ?? "", note: t.note ?? null,
        createdBy: t.createdBy, updatedAt: t.updatedAt,
      }));
    }

    // Perpetual inventory: item master + movement history, tenant-scoped.
    if (stock && canWrite('stockItems')) {
      await replace(stockItems, stock, (i) => ({
        id: i.id, clientId: i.clientId, itemCode: i.itemCode, description: i.description, category: i.category,
        uom: i.uom, quantityOnHand: i.quantityOnHand, unitCost: i.unitCost, totalValue: i.totalValue,
        reorderLevel: i.reorderLevel ?? null, location: i.location ?? null, glAccount: i.glAccount ?? null,
        costMethod: i.costMethod ?? "weighted_average", netRealisableValue: i.netRealisableValue ?? null,
      }));
    }
    if (movements && canWrite('stockMovements')) {
      await replace(stockMovements, movements, (m) => ({
        id: m.id, clientId: m.clientId, date: m.date, itemCode: m.itemCode, description: m.description,
        type: m.type, quantity: m.quantity, unitCost: m.unitCost, totalValue: m.totalValue, uom: m.uom,
        reference: m.reference ?? null, docNo: m.docNo ?? null, note: m.note ?? null,
      }));
    }
    // Fixed asset register with tax base (capital allowances / IAS 12).
    if (assets && canWrite('fixedAssets')) {
      await replace(fixedAssets, assets, (a) => ({
        id: a.id, clientId: a.clientId ?? 0, assetTag: a.assetTag, name: a.name, classCode: a.classCode,
        cost: a.cost, accumDep: a.accumDep, usefulLife: a.usefulLife,
        depreciationRate: a.depreciationRate ?? null, depreciationMethod: a.depreciationMethod ?? null,
        capitalAllowanceClass: a.capitalAllowanceClass ?? null, capitalAllowanceRate: a.capitalAllowanceRate ?? null,
        accumCapitalAllowance: a.accumCapitalAllowance ?? 0, location: a.location ?? "",
        acquired: a.acquired ?? null, disposedDate: a.disposedDate ?? null, disposalProceeds: a.disposalProceeds ?? null,
      }));
    }

    // Profiles: owner writes all; non-owners only their own entity's profile.
    const profileRows = Object.values(profiles).filter((p) => firmWide || p.clientId === myClientId);
    for (const p of profileRows) {
      await tx.insert(companyProfiles).values({
        clientId: p.clientId, legalName: p.legalName, tradingName: p.tradingName, tin: p.tin, vatRegNo: p.vatRegNo,
        address: p.address, phone: p.phone, email: p.email, website: p.website, fiscalYearStart: p.fiscalYearStart,
        bankPaymentDetails: p.bankPaymentDetails,
      }).onConflictDoUpdate({
        target: companyProfiles.clientId,
        set: {
          legalName: p.legalName, tradingName: p.tradingName, tin: p.tin, vatRegNo: p.vatRegNo, address: p.address,
          phone: p.phone, email: p.email, website: p.website, fiscalYearStart: p.fiscalYearStart,
          bankPaymentDetails: p.bankPaymentDetails,
        },
      });
    }

    // Firm-level masters: owner-only.
    if (isOwner) {
      if (body.clients) {
        for (const c of body.clients) {
          await tx.insert(clients).values({
            id: c.id, code: c.code, name: c.name, sector: c.sector, currency: c.currency, jurisdiction: c.jurisdiction,
            regNumber: c.regNumber, isParent: c.isParent ?? false, assignedServices: c.assignedServices ?? null,
            adminUsername: c.adminUsername ?? null, adminEmail: c.adminEmail ?? null, loginUrl: c.loginUrl ?? null,
          }).onConflictDoUpdate({
            target: clients.id,
            set: {
              code: c.code, name: c.name, sector: c.sector, currency: c.currency, jurisdiction: c.jurisdiction,
              regNumber: c.regNumber, isParent: c.isParent ?? false, assignedServices: c.assignedServices ?? null,
              adminUsername: c.adminUsername ?? null, adminEmail: c.adminEmail ?? null, loginUrl: c.loginUrl ?? null,
            },
          });
        }
      }
      if (body.disclosureNotes) {
        await tx.delete(disclosureNotes);
        if (body.disclosureNotes.length) {
          await tx.insert(disclosureNotes).values(
            body.disclosureNotes.map((n) => ({
              key: n.key, noteNumber: n.noteNumber, title: n.title, standardRef: n.standardRef, applicable: n.applicable,
              notApplicableReason: n.notApplicableReason ?? null, body: n.body, tables: n.tables ?? null,
              editableOverride: n.editableOverride ?? null,
            }))
          );
        }
      }
    }

    // Chart of accounts: the owner maintains the whole chart (firm master plus every
    // entity's customs); non-owners maintain only their own entity's custom accounts.
    if (body.chartOfAccounts) {
      if (isOwner) {
        await tx.delete(chartAccounts);
        if (body.chartOfAccounts.length) {
          await tx.insert(chartAccounts).values(
            body.chartOfAccounts.map((a) => ({
              accountNo: a.accountNo, name: a.name, type: a.type, category: a.category,
              active: a.active, isCustom: a.isCustom ?? false, clientId: a.clientId ?? null,
            }))
          );
        }
      } else if (myClientId !== null && mayEditChartOfAccounts(user)) {
        // Mirror the exact UI authority, including canModifyCOA withdrawal.
        // Staff/review-only syncs leave the chart untouched.
        await tx.delete(chartAccounts).where(eq(chartAccounts.clientId, myClientId));
        const own = body.chartOfAccounts.filter((a) => a.clientId === myClientId);
        if (own.length) {
          await tx.insert(chartAccounts).values(
            own.map((a) => ({
              accountNo: a.accountNo, name: a.name, type: a.type, category: a.category,
              active: a.active, isCustom: a.isCustom ?? false, clientId: myClientId,
            }))
          );
        }
      }
    }

    // Audit trail: one entry per newly posted journal document.
    const now = new Date().toISOString();
    // Period freezes and reopens are audit events — the ledger can change hands
    // but the control history must be reviewable.
    const prevClosed = new Set(allClosed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`));
    const nextClosed = new Set(closed.map((c) => `${c.clientId}:${c.period}`));
    for (const key of nextClosed) {
      if (prevClosed.has(key)) continue;
      const [cid, p] = key.split(":");
      await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: "CLOSE_PERIOD", target: `${cid}:${p}`, details: `Period ${p} frozen for client ${cid}`, clientId: Number(cid) });
    }
    for (const key of prevClosed) {
      if (nextClosed.has(key)) continue;
      const [cid, p] = key.split(":");
      await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: "REOPEN_PERIOD", target: `${cid}:${p}`, details: `Period ${p} reopened for client ${cid}`, clientId: Number(cid) });
    }
    // Approval resolutions (pending → approved/rejected) are audit events too.
    const prevApprovalStatus = new Map(allApprovals.filter((a) => allowedClientIds.includes(a.clientId)).map((a) => [a.id, a.status]));
    for (const a of approvals) {
      const prev = prevApprovalStatus.get(a.id);
      if (prev && prev !== a.status) {
        await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: `APPROVAL_${a.status.toUpperCase()}`, target: a.docNo, details: `${a.clientCode} request by ${a.requestedBy} ${a.status}${a.rejectionReason ? ` — ${a.rejectionReason}` : ""}`, clientId: a.clientId });
      }
    }
    for (const key of freshKeys) {
      const docLines = docs.get(key)!;
      const dr = docLines.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
      await tx.insert(auditLog).values({
        id: crypto.randomUUID(),
        timestamp: now,
        userId: user.username,
        username: user.username,
        action: "POST_JOURNAL",
        target: key.split(":")[1],
        details: `${docLines.length} line(s), debits ${dr.toFixed(2)}`,
        clientId: Number(key.split(":")[0]),
      });
    }
    committedRevision = serverRevision + 1;
    await tx.insert(systemSettings).values({
      key: 'workspace_state_revision', value: { revision: committedRevision },
    }).onConflictDoUpdate({
      target: systemSettings.key,
      set: { value: { revision: committedRevision }, updatedAt: new Date() },
    });
  });

  if (transactionError) return Response.json({ ok: false, error: transactionError }, { status: 409 });
  return authJson(req, { ok: true, warnings, stateRevision: committedRevision });
}
