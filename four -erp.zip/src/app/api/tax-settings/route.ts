import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { auditLog, systemSettings } from "@/db/schema";
import { authJson, getSessionUser, requireOwner } from "@/lib/auth";
import { DEFAULT_GH_TAX_SETTINGS, type TaxSettings } from "@/utils/taxConfig";

export const dynamic = "force-dynamic";

const SETTINGS_KEY = "tax_settings_ghana";

/**
 * Server-authoritative firm-wide tax settings (VAT, levies, WHT components, and PAYE bands).
 *
 * All accountants, staff and clients share ONE unified tax regime maintained
 * on the firm's server. Edits require Firm Owner authority and are audit-logged
 * with the exact version, timestamp and user identifier.
 */
export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getSessionUser(req);
    if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });

    const row = (
      await db
        .select()
        .from(systemSettings)
        .where(eq(systemSettings.key, SETTINGS_KEY))
        .limit(1)
    )[0];

    const settings: TaxSettings = (row?.value as TaxSettings) ?? DEFAULT_GH_TAX_SETTINGS;
    return authJson(req, { ok: true, settings });
  } catch (error) {
    console.error("GET /api/tax-settings failed", error);
    return authJson(req, { ok: false, error: "Tax settings could not be retrieved." }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    await ensureDatabaseReady();
    const owner = await requireOwner(req);
    if (!owner) {
      return authJson(
        req,
        { ok: false, error: "Only the Firm Owner may modify firm-wide statutory tax rates and PAYE bands." },
        { status: 403 }
      );
    }

    let payload: { settings?: TaxSettings };
    try {
      const raw = await req.text();
      if (raw.length > 512 * 1024) return authJson(req, { ok: false, error: "Payload too large." }, { status: 413 });
      payload = JSON.parse(raw);
    } catch {
      return authJson(req, { ok: false, error: "Invalid JSON body." }, { status: 400 });
    }

    const incoming = payload?.settings;
    if (!incoming || !Array.isArray(incoming.payeBands) || !Array.isArray(incoming.components)) {
      return authJson(req, { ok: false, error: "Tax settings must include payeBands and components arrays." }, { status: 400 });
    }

    const nextVersion = (Number(incoming.version) || 1) + 1;
    const nowIso = new Date().toISOString();
    const sanitized: TaxSettings = {
      version: nextVersion,
      jurisdiction: String(incoming.jurisdiction || "GH").slice(0, 8),
      effectiveFrom: String(incoming.effectiveFrom || nowIso.slice(0, 10)).slice(0, 10),
      updatedAt: nowIso,
      payeBands: incoming.payeBands.map((b) => ({
        id: String(b.id || randomUUID()),
        name: String(b.name || "Band"),
        from: Number(b.from) || 0,
        to: b.to === null ? null : Number(b.to) || 0,
        rate: Math.max(0, Math.min(100, Number(b.rate) || 0)),
        effectiveFrom: String(b.effectiveFrom || nowIso.slice(0, 10)),
        isActive: Boolean(b.isActive),
      })),
      components: incoming.components.map((c) => ({
        id: String(c.id || randomUUID()),
        code: String(c.code || "TAX").toUpperCase().slice(0, 32),
        name: String(c.name || "Tax Component").slice(0, 120),
        rate: Math.max(0, Math.min(100, Number(c.rate) || 0)),
        type: c.type,
        appliesTo: c.appliesTo,
        isActive: Boolean(c.isActive),
        effectiveFrom: String(c.effectiveFrom || nowIso.slice(0, 10)),
      })),
    };

    await db
      .insert(systemSettings)
      .values({
        key: SETTINGS_KEY,
        value: sanitized,
      })
      .onConflictDoUpdate({
        target: systemSettings.key,
        set: { value: sanitized },
      });

    await db.insert(auditLog).values({
      id: randomUUID(),
      timestamp: nowIso,
      userId: owner.username,
      username: owner.username,
      action: "TAX_SETTINGS_UPDATED",
      target: SETTINGS_KEY,
      details: `Firm tax rates updated to version ${nextVersion} by ${owner.username}. ${sanitized.components.length} components, ${sanitized.payeBands.length} PAYE bands.`,
      clientId: null,
    });

    return authJson(req, { ok: true, settings: sanitized });
  } catch (error) {
    console.error("PUT /api/tax-settings failed", error);
    return authJson(req, { ok: false, error: "Failed to persist firm-wide tax settings." }, { status: 500 });
  }
}
