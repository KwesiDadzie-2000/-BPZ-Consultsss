import React, { useEffect, useMemo, useState } from 'react';
import { ClientEntity, UserAccount } from '../types/accounting';
import { maySeeSection } from '../utils/access';
import { useModalFocus } from '../utils/useModalFocus';
import {
  TrendingUp,
  BarChart3,
  LayoutDashboard,
  ShoppingCart,
  Tag,
  Users,
  CreditCard,
  Building,
  ShieldCheck,
  Boxes,
  Truck,
  Factory,
  PackagePlus,
  Compass,
  FileSpreadsheet,
  BookOpen,
  CalendarCheck,
  Briefcase,
  Layers,
  Globe,
  Radio,
  Server,
  Lock,
  Calculator,
  Settings,
  Scale,
  ShieldAlert,
  ChevronDown,
  ChevronRight,
  Search,
  Store,
  UserCog,
  ClipboardList,
  ListChecks,
  HeartHandshake,
  Wallet,
  Landmark,
  FileText,
  Network,
  PackageSearch,
  UserRound,
  PieChart,
  Hourglass,
  FolderKanban,
} from 'lucide-react';

interface AccountingSidebarProps {
  activeSection: string;
  onSelectSection: (section: string) => void;
  currentClient: ClientEntity;
  currentUser: UserAccount;
  /** Phones/tablets: the menu is an off-canvas drawer. */
  mobileOpen?: boolean;
  onCloseMobile?: () => void;
}

type NavItem = { id: string; label: string; icon: React.ComponentType<{ className?: string }>; code?: string };
type NavGroup = { id: string; name: string; icon: React.ComponentType<{ className?: string }>; items: NavItem[]; ownerOnly?: boolean };

/**
 * Navigation architecture.
 *
 * The system grew to 40+ modules, which made the flat menu unusable. Modules
 * are now grouped by business capability and each group is a collapsible
 * dropdown. The original module ids, labels, colour palette and layout are
 * preserved, so every existing deep link and permission still resolves.
 */
export const AccountingSidebar: React.FC<AccountingSidebarProps> = ({
  activeSection,
  onSelectSection,
  currentClient,
  currentUser,
  mobileOpen = false,
  onCloseMobile,
}) => {
  const isOwner = currentUser.role === 'owner';
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.matchMedia('(max-width: 767px)').matches);
  useEffect(() => {
    const media = window.matchMedia('(max-width: 767px)');
    const onChange = () => setIsMobile(media.matches);
    media.addEventListener('change', onChange);
    return () => media.removeEventListener('change', onChange);
  }, []);
  const navRef = useModalFocus<HTMLElement>(mobileOpen && isMobile, () => onCloseMobile?.());

  // The sector guidance lives in its own desk; it must not re-skin or replace
  // the working screens for procurement, payroll, inventory or finance.
  const groups: NavGroup[] = [
    {
      id: 'overview',
      name: 'Overview',
      icon: LayoutDashboard,
      items: [
        { id: 'dashboard', label: 'Command Center', icon: LayoutDashboard, code: 'HQ' },
        { id: 'sector_workflow', label: 'Sector Workflow Switcher', icon: Compass, code: 'SEC' },
        { id: 'company_profile', label: 'Company Profile & Backup', icon: Settings, code: 'SET' },
        { id: 'opening_balance', label: 'Opening Balances Setup', icon: Scale, code: 'OPN' },
        { id: 'my_security', label: 'My Account Security (MFA)', icon: Lock, code: 'MFA' },
      ],
    },
    {
      id: 'sales',
      name: 'Sales',
      icon: Tag,
      items: [
        { id: 'sales', label: 'Sales & Invoicing · O2C', icon: Tag, code: 'SD' },
      ],
    },
    {
      id: 'procurement',
      name: 'Procurement',
      icon: ShoppingCart,
      items: [
        { id: 'procurement', label: 'Procurement & P2P', icon: ShoppingCart, code: 'MM' },
      ],
    },
    {
      id: 'inventory',
      name: 'Inventory & Store',
      icon: Boxes,
      items: [
        { id: 'inventory', label: 'Inventory Command Desk', icon: Boxes, code: 'INV' },
        { id: 'inventory_ledger', label: 'Stock Ledger & Valuation', icon: ClipboardList, code: 'INV' },
      ],
    },
    {
      id: 'production',
      name: 'Manufacturing & Production',
      icon: Factory,
      items: [
        { id: 'boms', label: 'Bill of Materials', icon: PackagePlus, code: 'BOM' },
        { id: 'production_desk', label: 'Production Desk', icon: ClipboardList, code: 'PROD' },
      ],
    },
    {
      id: 'finance',
      name: 'Accounting & Finance',
      icon: BookOpen,
      items: [
        { id: 'ifrs_desk', label: 'IFRS Desk (Standards + Schedules)', icon: Layers, code: 'IFRS' },
        { id: 'ifrs_statements', label: 'Financial Statements & IFRS', icon: FileSpreadsheet, code: 'IAS1' },
        { id: 'general_ledger', label: 'General Ledger', icon: BookOpen, code: 'GL' },
        { id: 'coa_master', label: 'Chart of Accounts Master', icon: BookOpen, code: 'COA' },
        { id: 'universal_journal', label: 'Journals (Universal & Manual)', icon: BookOpen, code: 'JNL' },
        { id: 'adjustments', label: 'Adjustment of Accounts', icon: Scale, code: 'ADJ' },
        { id: 'banking', label: 'Banking & Reconcile', icon: Building, code: 'BANK' },
        { id: 'payment_desk', label: 'Payment Desk', icon: CreditCard, code: 'PMT' },
        { id: 'ageing', label: 'Ageing Analysis (AR & AP)', icon: Hourglass, code: 'AGE' },
        { id: 'control_accounts', label: 'Control Accounts Reconciliation', icon: Scale, code: 'REC' },
        { id: 'expenses', label: 'Expenses & Statutory', icon: ShieldCheck, code: 'EXP' },
        { id: 'assets', label: 'Fixed Assets Register', icon: Truck, code: 'AA' },
        { id: 'prepayments', label: 'Prepayments & Deferrals', icon: CalendarCheck, code: 'PRE' },
        { id: 'project_costing', label: 'Project Costing & Contracts', icon: FolderKanban, code: 'COST' },
        { id: 'tax_schedule', label: 'Tax Desk (Schedules, Returns & Filing)', icon: ShieldCheck, code: 'TAX' },
        { id: 'month_end', label: 'Month-End Close', icon: CalendarCheck, code: 'MCC' },
        { id: 'disclosures', label: 'Notes to Accounts', icon: FileSpreadsheet, code: 'NTS' },
        { id: 'loans_desk', label: 'Loan Amortisation Schedules', icon: Calculator, code: 'FIN' },
        { id: 'regulated_industries', label: 'Regulated Industries (IFRS 9/17, Royalties, Levies)', icon: Landmark, code: 'REG' },
        { id: 'compliance_review', label: 'Compliance Review & Gaps', icon: ShieldAlert, code: 'AUD' },
        { id: 'group_consolidation', label: 'Group Consolidation', icon: Layers, code: 'IFRS10' },
      ],
    },
    {
      id: 'hr',
      name: 'Human Resources',
      icon: UserRound,
      items: [
        { id: 'hr_desk', label: 'HR Management Desk', icon: UserRound, code: 'HR' },
        { id: 'hr_employees', label: 'Employees', icon: Users, code: 'HR' },
        { id: 'hr_structure', label: 'Organisational Structure', icon: Network, code: 'HR' },
        { id: 'hr_attendance', label: 'Employee Attendance', icon: CalendarCheck, code: 'HR' },
        { id: 'hr_requests', label: 'Employee Requests', icon: HeartHandshake, code: 'HR' },
        { id: 'hr_tasks', label: 'Task Management', icon: ListChecks, code: 'HR' },
        { id: 'payroll', label: 'Payroll Desk', icon: Wallet, code: 'PAY' },
      ],
    },
    {
      id: 'performance',
      name: 'Performance Management',
      icon: TrendingUp,
      items: [
        { id: 'performance', label: 'Budgeting, Forecast & Scenarios', icon: TrendingUp, code: 'EPM' },
        { id: 'analytics', label: 'Data Analytics & CAATs', icon: BarChart3, code: 'BI' },
      ],
    },
    {
      id: 'crm',
      name: 'Clients & CRM',
      icon: HeartHandshake,
      items: [
        { id: 'crm_desk', label: 'Client Relationship Desk', icon: HeartHandshake, code: 'CRM' },
        { id: 'business_partners_crm', label: 'Client Master File', icon: Users, code: 'BP' },
        ...(isOwner ? [{ id: 'clients_management', label: 'Client Workspaces', icon: Building, code: 'MGT' }] : []),
        ...(isOwner ? [{ id: 'advisory', label: 'Advisory & Timesheets', icon: Briefcase, code: 'AD' }] : []),
      ],
    },
    {
      id: 'reports',
      name: 'Reports',
      icon: FileText,
      items: [
        { id: 'reports', label: 'Reports Centre', icon: FileText, code: 'RPT' },
        { id: 'report_sales_r', label: 'Sales Reports', icon: Tag, code: 'RPT' },
        { id: 'report_purchases_r', label: 'Purchases Reports', icon: ShoppingCart, code: 'RPT' },
        { id: 'report_inventory_r', label: 'Inventory Reports', icon: Boxes, code: 'RPT' },
        { id: 'report_clients_r', label: 'Clients Reports', icon: Users, code: 'RPT' },
        { id: 'report_store_r', label: 'Store Reports', icon: Store, code: 'RPT' },
        { id: 'report_production_r', label: 'Production & WIP', icon: Factory, code: 'RPT' },
        { id: 'report_hr_r', label: 'HR & Payroll Reports', icon: UserRound, code: 'RPT' },
        { id: 'report_ageing_r', label: 'Ageing Analysis (AR & AP)', icon: Hourglass, code: 'RPT' },
        { id: 'report_financial_r', label: 'Financial Reports', icon: Landmark, code: 'RPT' },
      ],
    },
    {
      id: 'admin',
      name: 'Enterprise Administration',
      icon: ShieldAlert,
      ownerOnly: true,
      items: [
        { id: 'user_permissions', label: 'User Access & Restrictions', icon: UserCog, code: 'GOV' },
        { id: 'enterprise_sso', label: 'Enterprise SSO (SAML/SCIM)', icon: Lock, code: 'SSO' },
        { id: 'tax_settings', label: 'Tax Rates & Levy Settings', icon: Globe, code: 'TAX' },
        { id: 'global_tax', label: 'Global Tax Reference', icon: Globe, code: 'REF' },
        { id: 'soc_dr', label: 'SOC 2 & Disaster Recovery', icon: Server, code: 'SOC2' },
        { id: 'realtime_integrations', label: 'API & Webhooks Hub', icon: Radio, code: 'ENT' },
      ],
    },
  ];

  const visibleGroups = groups
    .filter((g) => !g.ownerOnly || isOwner)
    .map((g) => ({ ...g, items: g.items.filter((item) => maySeeSection(currentUser, currentClient, item.id)) }))
    .filter((g) => g.items.length > 0);

  /** Group containing the active module is opened automatically. */
  const activeGroup = visibleGroups.find((g) => g.items.some((i) => i.id === activeSection))?.id ?? 'overview';
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>(() => ({ [activeGroup]: true }));
  const [query, setQuery] = useState('');

  // The active group is open unless the user explicitly collapsed it (derived, no effect).
  const isGroupOpen = (id: string) => openGroups[id] ?? id === activeGroup;

  const filteredGroups = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return visibleGroups;
    return visibleGroups
      .map((g) => ({ ...g, items: g.items.filter((i) => `${i.label} ${i.code ?? ''} ${g.name}`.toLowerCase().includes(q)) }))
      .filter((g) => g.items.length > 0);
  }, [visibleGroups, query]);

  const toggleGroup = (id: string) => setOpenGroups((prev) => ({ ...prev, [id]: !(prev[id] ?? id === activeGroup) }));
  const choose = (id: string) => {
    onSelectSection(id);
    if (isMobile) onCloseMobile?.();
  };

  return (
    <>
      {/* Backdrop for the mobile drawer */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}
      <aside
        ref={navRef}
        id="workspace-navigation"
        inert={isMobile && !mobileOpen}
        role={isMobile && mobileOpen ? 'dialog' : undefined}
        aria-modal={isMobile && mobileOpen ? true : undefined}
        aria-label="Main navigation"
        className={`fixed inset-y-0 left-0 z-50 w-72 max-w-[85vw] transform transition-transform duration-200 md:static md:z-auto md:w-64 lg:w-72 md:max-w-none md:translate-x-0 shrink-0 border-r border-sky-200 bg-[#eef6fc] p-3.5 flex flex-col justify-between overflow-y-auto overscroll-contain ${mobileOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}`}
      >
        <div className="space-y-3">
          <button
            onClick={onCloseMobile}
            aria-label="Close navigation menu"
            className="md:hidden ml-auto block rounded-lg border border-sky-300 bg-white px-3 py-1 text-xs font-bold text-[#082f4f]"
          >
            Close
          </button>

          {/* Workspace Active Card */}
          <div className="rounded-xl border border-sky-300/80 bg-white p-3 shadow-xs">
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#355875]">
              Active Accounting Workspace
            </div>
            <div className="mt-1 flex items-center justify-between">
              <span className="font-bold text-[#082f4f] text-xs truncate max-w-[170px]">
                {currentClient.name}
              </span>
              <span className="font-mono text-xs font-black text-[#855b00]">
                {currentClient.code}
              </span>
            </div>
            <div className="mt-0.5 text-[11px] text-[#2d4f6d] font-mono">
              {currentClient.sector} · {currentClient.currency}
            </div>
          </div>

          {/* Module search — essential at 40+ modules */}
          <label className="relative block">
            <span className="sr-only">Find a module</span>
            <Search className="pointer-events-none absolute left-2.5 top-2 h-3.5 w-3.5 text-[#355875]" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Find a module…"
              className="w-full rounded-lg border border-sky-300 bg-white py-1.5 pl-8 pr-2 text-[11.5px] font-semibold text-[#082f4f] outline-none placeholder:text-[#355875]/70 focus:border-[#082f4f]"
            />
          </label>

          {/* Menu Navigation — categories with dropdowns */}
          <nav className="space-y-1.5" aria-label="Module categories">
            {filteredGroups.map((g) => {
              const GroupIcon = g.icon;
              const open = isGroupOpen(g.id) || Boolean(query.trim());
              const hasActive = g.items.some((i) => i.id === activeSection);
              return (
                <div key={g.id} className={`rounded-lg border ${hasActive ? 'border-sky-300 bg-white/70' : 'border-transparent'}`}>
                  <button
                    onClick={() => toggleGroup(g.id)}
                    aria-expanded={open}
                    aria-controls={`nav-group-${g.id}`}
                    className={`flex w-full items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-left transition hover:bg-sky-200/50 ${hasActive ? 'bg-white shadow-xs' : ''}`}
                  >
                    <span className="flex min-w-0 items-center gap-2">
                      <GroupIcon className={`h-4 w-4 shrink-0 ${hasActive ? 'text-[#855b00]' : 'text-[#355875]'}`} />
                      <span className={`truncate text-[11px] font-black uppercase tracking-wider ${hasActive ? 'text-[#082f4f]' : 'text-[#355875]'}`}>{g.name}</span>
                    </span>
                    <span className="flex shrink-0 items-center gap-1">
                      <span className="rounded bg-sky-200/70 px-1 font-mono text-[9.5px] font-bold text-[#355875]">{g.items.length}</span>
                      {open ? <ChevronDown className="h-3.5 w-3.5 text-[#355875]" /> : <ChevronRight className="h-3.5 w-3.5 text-[#355875]" />}
                    </span>
                  </button>

                  {open && (
                    <div id={`nav-group-${g.id}`} className="space-y-0.5 pb-1 pl-1 pr-0.5">
                      {g.items.map((item) => {
                        const Icon = item.icon;
                        const isActive = activeSection === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => choose(item.id)}
                            aria-current={isActive ? 'page' : undefined}
                            className={`w-full flex items-center justify-between rounded-lg px-2.5 py-2 md:py-1.5 text-left text-xs font-semibold transition ${isActive ? 'bg-[#082f4f] text-white shadow-xs font-bold' : 'text-[#163653] hover:bg-sky-200/60'}`}
                          >
                            <span className="flex items-center gap-2.5 min-w-0">
                              <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-[#f5b719]' : 'text-[#355875]'}`} />
                              <span className="truncate">{item.label}</span>
                            </span>
                            {item.code && (
                              <span className={`shrink-0 rounded px-1.5 py-0.2 font-mono text-[9.5px] font-bold ${isActive ? 'bg-white/20 text-white' : 'bg-sky-200/60 text-[#355875]'}`}>
                                {item.code}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
            {filteredGroups.length === 0 && (
              <p className="rounded-lg border border-sky-200 bg-white px-2 py-3 text-center text-[11px] font-semibold text-[#355875]">No module matches “{query}”.</p>
            )}
          </nav>
        </div>

        {/* User Session Footer */}
        <div className="mt-6 pt-3 border-t border-sky-200 text-xs">
          <div className="flex items-center justify-between">
            <div className="truncate">
              <div className="font-bold text-[#082f4f] text-xs truncate max-w-[160px]">{currentUser.name}</div>
              <div className="text-[10.5px] font-mono text-[#855b00] uppercase font-bold">{currentUser.role}</div>
            </div>
            <span className="rounded bg-sky-200/70 px-1.5 py-0.5 text-[10px] font-mono font-bold text-[#082f4f]">
              {currentUser.canCheck ? 'Checker Auth' : 'Maker Only'}
            </span>
          </div>
        </div>
      </aside>
    </>
  );
};
