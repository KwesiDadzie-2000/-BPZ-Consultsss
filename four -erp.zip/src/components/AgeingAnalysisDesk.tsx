"use client";

import { useMemo, useState } from "react";
import type { ACDOCALine, ClientEntity, PurchaseOrder, SalesInvoice } from "../types/accounting";
import { Badge, Card, PageHeader, Stat, formatGHS, numCls, rowCls, tdCls, thCls } from "./ui";
import { downloadCsv, useMoney } from "./DeskKit";
import { deriveExpenseBills } from "../utils/payables";
import { localToday } from "../utils/periods";

interface Props {
  currentClient: ClientEntity;
  invoices: SalesInvoice[];
  orders: PurchaseOrder[];
  lines: ACDOCALine[];
  onNavigate?: (section: string) => void;
}

const DAY_MS = 86_400_000;
const BUCKETS = ["Current", "1–30 days", "31–60 days", "61–90 days", "Over 90 days"] as const;

function parseDay(d: string): number {
  const t = Date.parse(`${d.slice(0, 10)}T00:00:00Z`);
  return Number.isFinite(t) ? t : Date.now();
}

function addDays(date: string, days: number): string {
  return new Date(parseDay(date) + days * DAY_MS).toISOString().slice(0, 10);
}

interface AgedItem {
  key: string;
  docNo: string;
  party: string;
  date: string;
  dueDate: string;
  daysOverdue: number;
  bucket: number;
  gross: number;
  paid: number;
  balance: number;
  status: string;
  kind: string;
}

function bucketFor(daysOverdue: number): number {
  if (daysOverdue <= 0) return 0;
  if (daysOverdue <= 30) return 1;
  if (daysOverdue <= 60) return 2;
  if (daysOverdue <= 90) return 3;
  return 4;
}

export function AgeingAnalysisDesk({ currentClient, invoices, orders, lines, onNavigate }: Props) {
  const { fmt, today } = useMoney();
  const [asOf, setAsOf] = useState(() => localToday());
  const [termsDays, setTermsDays] = useState(30);
  const [query, setQuery] = useState("");
  const [view, setView] = useState<"receivables" | "payables">("receivables");
  const [detail, setDetail] = useState(true);

  const asOfSafe = /^\d{4}-\d{2}-\d{2}$/.test(asOf) ? asOf : today();
  const asOfMs = parseDay(asOfSafe);

  const arItems = useMemo<AgedItem[]>(() => {
    return invoices
      .filter((i) => i.status !== "Draft" && i.status !== "Credited")
      .map((i) => {
        const balance = Math.round((i.totalReceivable - (i.paidAmount ?? 0)) * 100) / 100;
        const dueDate = addDays(i.date, termsDays);
        const daysOverdue = Math.floor((asOfMs - parseDay(dueDate)) / DAY_MS);
        return {
          key: `ar-${i.id}`,
          docNo: i.invNo,
          party: i.customerName,
          date: i.date,
          dueDate,
          daysOverdue,
          bucket: bucketFor(daysOverdue),
          gross: i.totalReceivable,
          paid: i.paidAmount ?? 0,
          balance,
          status: balance <= 0.009 ? "Settled" : i.status,
          kind: "Sales invoice",
        };
      })
      .filter((r) => r.balance > 0.009 && r.date <= asOfSafe);
  }, [invoices, termsDays, asOfMs, asOfSafe]);

  const apItems = useMemo<AgedItem[]>(() => {
    const supplier = orders
      .filter((o) => o.status !== "Open" && o.status !== "Debited")
      .map((o) => {
        const balance = Math.round((o.totalAmount - (o.paidAmount ?? 0)) * 100) / 100;
        const dueDate = addDays(o.date, termsDays);
        const daysOverdue = Math.floor((asOfMs - parseDay(dueDate)) / DAY_MS);
        return {
          key: `ap-${o.id}`,
          docNo: o.poNo,
          party: o.vendorName,
          date: o.date,
          dueDate,
          daysOverdue,
          bucket: bucketFor(daysOverdue),
          gross: o.totalAmount,
          paid: o.paidAmount ?? 0,
          balance,
          status: balance <= 0.009 ? "Settled" : o.status,
          kind: "Supplier bill",
        };
      })
      .filter((r) => r.balance > 0.009 && r.date <= asOfSafe);
    const expense = deriveExpenseBills(lines, currentClient.id)
      .filter((b) => b.outstanding > 0.009 && b.date <= asOfSafe)
      .map((b) => {
        const dueDate = addDays(b.date, termsDays);
        const daysOverdue = Math.floor((asOfMs - parseDay(dueDate)) / DAY_MS);
        return {
          key: `ex-${b.billNo}`,
          docNo: b.billNo,
          party: b.payee,
          date: b.date,
          dueDate,
          daysOverdue,
          bucket: bucketFor(daysOverdue),
          gross: b.gross,
          paid: b.paid,
          balance: b.outstanding,
          status: b.status,
          kind: "Expense bill",
        };
      });
    return [...supplier, ...expense];
  }, [orders, lines, currentClient.id, termsDays, asOfMs, asOfSafe]);

  const items = view === "receivables" ? arItems : apItems;
  const q = query.trim().toLowerCase();
  const filtered = q
    ? items.filter((r) => `${r.docNo} ${r.party} ${r.kind} ${r.status}`.toLowerCase().includes(q))
    : items;

  const totals = [0, 0, 0, 0, 0];
  let total = 0;
  let overdue = 0;
  for (const r of filtered) {
    totals[r.bucket] = Math.round((totals[r.bucket] + r.balance) * 100) / 100;
    total = Math.round((total + r.balance) * 100) / 100;
    if (r.daysOverdue > 0) overdue = Math.round((overdue + r.balance) * 100) / 100;
  }

  const byParty = useMemo(() => {
    const map = new Map<string, { balance: number; overdue: number; count: number; oldest: number; buckets: number[] }>();
    for (const r of filtered) {
      const row = map.get(r.party) ?? { balance: 0, overdue: 0, count: 0, oldest: r.daysOverdue, buckets: [0, 0, 0, 0, 0] };
      row.balance = Math.round((row.balance + r.balance) * 100) / 100;
      if (r.daysOverdue > 0) row.overdue = Math.round((row.overdue + r.balance) * 100) / 100;
      row.count += 1;
      row.oldest = Math.max(row.oldest, r.daysOverdue);
      row.buckets[r.bucket] = Math.round((row.buckets[r.bucket] + r.balance) * 100) / 100;
      map.set(r.party, row);
    }
    return [...map.entries()].sort((a, b) => b[1].balance - a[1].balance);
  }, [filtered]);

  const exportRows: (string | number)[][] = [
    [`${currentClient.name} (${currentClient.code}) — ${view === "receivables" ? "Receivables" : "Payables"} ageing as at ${asOfSafe} · ${termsDays}-day terms`],
    ["Document", "Party", "Type", "Date", "Due date", "Days overdue", "Bucket", "Gross", "Paid", "Outstanding", "Status"],
    ...filtered
      .sort((a, b) => b.daysOverdue - a.daysOverdue)
      .map((r) => [r.docNo, r.party, r.kind, r.date, r.dueDate, r.daysOverdue, BUCKETS[r.bucket], r.gross, r.paid, r.balance, r.status]),
  ];

  const maxBucket = Math.max(...totals, 1);
  const glControlBalance = useMemo(() => {
    const entityLines = lines.filter((l) => l.clientId === currentClient.id && l.date <= asOfSafe);
    if (view === "receivables") {
      return Math.round(entityLines.filter((l) => l.accountNo === "110000").reduce((s, l) => s + (l.debit - l.credit), 0) * 100) / 100;
    }
    return Math.round(entityLines.filter((l) => l.accountNo === "200000" || l.accountNo === "202000").reduce((s, l) => s + (l.credit - l.debit), 0) * 100) / 100;
  }, [lines, currentClient.id, asOfSafe, view]);
  const glDiff = Math.round((total - glControlBalance) * 100) / 100;

  return (
    <div>
      <PageHeader
        kicker={`${currentClient.code} · Accounting & Finance · Treasury`}
        title="Ageing Analysis — Receivables & Payables"
        desc="Every open customer, supplier and expense balance aged against its due date. Collect cash, prioritise payments and feed the IFRS 9 expected-credit-loss schedule — from one live position, not a month-old spreadsheet."
      >
        <Badge tone="fi">AGEING</Badge>
        <Badge tone="slate">As at {asOfSafe}</Badge>
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label={view === "receivables" ? "Receivables outstanding" : "Payables outstanding"} value={`GH₵ ${fmt(total)}`} sub={`${filtered.length} open posted item(s)`} />
        <Stat label="Overdue" value={`GH₵ ${fmt(overdue)}`} sub={total > 0 ? `${((overdue / total) * 100).toFixed(1)}% of outstanding` : "Nothing outstanding"} tone={overdue > 0 ? "text-[#b42318]" : "text-[#087a55]"} />
        <Stat label="Over 90 days" value={`GH₵ ${fmt(totals[4])}`} sub="Hardest to collect / most urgent to pay" tone={totals[4] > 0 ? "text-[#b42318]" : undefined} />
        <Stat label="Parties" value={byParty.length} sub={view === "receivables" ? "Customers with balances" : "Payees with balances"} />
        <Stat
          label={view === "receivables" ? "GL 110000 Control Tie-Out" : "GL 200000/202000 Tie-Out"}
          value={`GH₵ ${fmt(glControlBalance)}`}
          sub={Math.abs(glDiff) < 0.01 ? "Sub-ledger matches General Ledger" : `Diff GH₵ ${fmt(Math.abs(glDiff))} vs sub-ledger`}
          tone={Math.abs(glDiff) < 0.01 ? "text-[#087a55]" : "text-[#b42318]"}
        />
      </div>

      <Card
        title="Ageing controls"
        sub="The whole desk re-ages instantly when the as-of date or credit terms change."
        action={
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex overflow-hidden rounded-lg border border-sky-300" role="tablist" aria-label="Ageing side">
              {(["receivables", "payables"] as const).map((v) => (
                <button
                  key={v}
                  role="tab"
                  aria-selected={view === v}
                  onClick={() => setView(v)}
                  className={`px-3 py-1.5 text-[11px] font-bold ${view === v ? "bg-[#082f4f] text-white" : "bg-white text-[#082f4f] hover:bg-sky-50"}`}
                >
                  {v === "receivables" ? "Receivables (AR)" : "Payables (AP)"}
                </button>
              ))}
            </div>
            <button onClick={() => downloadCsv(`ageing-${view}-${asOfSafe}.csv`, exportRows)} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">
              Export CSV
            </button>
          </div>
        }
      >
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          <label className="block">
            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wider text-[#355875]">As-of date</span>
            <input type="date" value={asOfSafe} max={today()} onChange={(e) => setAsOf(e.target.value)} className="w-full rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]" />
          </label>
          <label className="block">
            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wider text-[#355875]">Credit terms</span>
            <select value={termsDays} onChange={(e) => setTermsDays(Number(e.target.value))} className="w-full rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]">
              {[0, 7, 14, 21, 30, 45, 60, 90].map((d) => (
                <option key={d} value={d}>{d === 0 ? "Due immediately" : `${d} days`}</option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="mb-1 block text-[10px] font-bold uppercase tracking-wider text-[#355875]">Search document / party</span>
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. INV-2026, Gold Coast…" className="w-full rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]" />
          </label>
          <div className="flex items-end gap-2">
            <button onClick={() => setDetail((d) => !d)} aria-pressed={detail} className="w-full rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">
              {detail ? "Hide document detail" : "Show document detail"}
            </button>
          </div>
        </div>

        <div className="mt-4 space-y-1.5">
          {BUCKETS.map((label, i) => (
            <div key={label}>
              <div className="flex justify-between text-[11px]">
                <span className={`font-bold ${i === 4 && totals[i] > 0 ? "text-rose-700" : "text-[#163653]"}`}>{label}{i === 0 ? ` (due after ${asOfSafe})` : ""}</span>
                <span className="ml-2 shrink-0 font-mono font-bold text-[#082f4f]">GH₵ {fmt(totals[i])}</span>
              </div>
              <div className="mt-0.5 h-1.5 rounded bg-sky-100">
                <div className={`h-1.5 rounded ${i === 4 ? "bg-[#b42318]" : i === 0 ? "bg-[#315f91]" : "bg-[#dd8d00]"}`} style={{ width: `${Math.max((totals[i] / maxBucket) * 100, totals[i] > 0 ? 2 : 0)}%` }} />
              </div>
            </div>
          ))}
        </div>
      </Card>

      <div className="mt-4 grid gap-4">
        <Card
          title={view === "receivables" ? "Balance by customer" : "Balance by payee"}
          sub="Ranked by outstanding balance — work the top of this list first."
        >
          {byParty.length === 0 ? (
            <div className="rounded-xl border border-dashed border-sky-300 bg-sky-50/50 px-4 py-8 text-center">
              <p className="text-xs font-bold text-[#082f4f]">{view === "receivables" ? "No open receivables" : "No open payables"} as at {asOfSafe}</p>
              <p className="mt-1 text-xs text-[#355875]">{view === "receivables" ? "Raise a sales invoice and it will age here automatically." : "Record a supplier or expense bill and it will age here automatically."}</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-lg border border-sky-200">
              <table className="w-full min-w-[860px] border-collapse">
                <thead>
                  <tr>
                    <th className={thCls}>{view === "receivables" ? "Customer" : "Payee"}</th>
                    <th className={thCls}>Items</th>
                    <th className={thCls}>Current</th>
                    <th className={thCls}>1–30</th>
                    <th className={thCls}>31–60</th>
                    <th className={thCls}>61–90</th>
                    <th className={thCls}>Over 90</th>
                    <th className={thCls}>Outstanding</th>
                    <th className={thCls}>Oldest</th>
                  </tr>
                </thead>
                <tbody>
                  {byParty.map(([party, v]) => (
                    <tr key={party} className={rowCls}>
                      <td className={tdCls}><span className="font-bold text-[#082f4f]">{party}</span></td>
                      <td className={numCls}>{v.count}</td>
                      <td className={numCls}>{fmt(v.buckets[0])}</td>
                      <td className={numCls}>{fmt(v.buckets[1])}</td>
                      <td className={numCls}>{fmt(v.buckets[2])}</td>
                      <td className={numCls}>{fmt(v.buckets[3])}</td>
                      <td className={numCls}>{fmt(v.buckets[4])}</td>
                      <td className={numCls}><span className={v.overdue > 0 ? "font-bold text-rose-700" : "font-bold text-emerald-700"}>{fmt(v.balance)}</span></td>
                      <td className={tdCls}><Badge tone={v.oldest > 90 ? "red" : v.oldest > 0 ? "amber" : "green"}>{v.oldest <= 0 ? "Current" : `${v.oldest}d overdue`}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        {detail && filtered.length > 0 && (
          <Card
            title="Document detail"
            sub="Oldest first — every line links back to the desk that settles it."
            action={onNavigate ? (
              <div className="flex flex-wrap gap-1.5">
                <button onClick={() => onNavigate("payment_desk")} className="rounded-lg bg-[#082f4f] px-2.5 py-1.5 text-[11px] font-bold text-white hover:bg-[#0c3f68]">Settle at Payment Desk →</button>
                <button onClick={() => onNavigate(view === "receivables" ? "sales" : "procurement")} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">
                  {view === "receivables" ? "Open Sales →" : "Open Procurement →"}
                </button>
                {view === "receivables" && (
                  <button onClick={() => onNavigate("ifrs_schedules")} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">IFRS 9 ECL schedule →</button>
                )}
              </div>
            ) : undefined}
          >
            <div className="overflow-x-auto rounded-lg border border-sky-200">
              <table className="w-full min-w-[900px] border-collapse">
                <thead>
                  <tr>
                    <th className={thCls}>Document</th>
                    <th className={thCls}>Party</th>
                    <th className={thCls}>Date / due</th>
                    <th className={thCls}>Bucket</th>
                    <th className={thCls}>Gross</th>
                    <th className={thCls}>Paid</th>
                    <th className={thCls}>Outstanding</th>
                    <th className={thCls}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {[...filtered].sort((a, b) => b.daysOverdue - a.daysOverdue).map((r) => (
                    <tr key={r.key} className={rowCls}>
                      <td className={tdCls}><span className="font-mono text-[11px] font-bold text-[#082f4f]">{r.docNo}</span><span className="block text-[10px] text-[#355875]">{r.kind}</span></td>
                      <td className={tdCls}>{r.party}</td>
                      <td className={tdCls}><span className="font-mono text-[11px]">{r.date}</span><span className="block font-mono text-[10.5px] text-[#355875]">due {r.dueDate}</span></td>
                      <td className={tdCls}><Badge tone={r.bucket === 4 ? "red" : r.bucket === 0 ? "green" : "amber"}>{BUCKETS[r.bucket]}</Badge><span className="block text-[10px] text-[#355875]">{r.daysOverdue <= 0 ? "not yet due" : `${r.daysOverdue}d overdue`}</span></td>
                      <td className={numCls}>{fmt(r.gross)}</td>
                      <td className={numCls}>{fmt(r.paid)}</td>
                      <td className={numCls}><span className="font-bold">{fmt(r.balance)}</span></td>
                      <td className={tdCls}>{r.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
