import React, { useState } from 'react';
import { ClientEntity, ACDOCALine, UserAccount, AccountMaster, FixedAsset, SalesInvoice, StockItem } from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import { currencySymbol } from '../utils/currency';
import {
  Calculator,
  Plus,
  CheckCircle,
  ArrowRight,
} from 'lucide-react';
import { currentYear, nextDocNo, uniqueId } from '../utils/ids';

interface ComprehensiveStandardsDeskProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines?: ACDOCALine[];
  /** Real entity registers — every figure on this desk is derived from these. */
  accounts?: AccountMaster[];
  assets?: FixedAsset[];
  invoices?: SalesInvoice[];
  stockItems?: StockItem[];
  onAddJournalLines: (lines: ACDOCALine[]) => void;
  onNavigateSection?: (section: string) => void;
}

type CntRow = { id: string; code: string; customer: string; description: string; contractValue: number; totalEstimatedCost: number; actualCostIncurred: number; billedToDate: number; status: string };

/** Ageing reference date, captured once at module load (pure inside render). */
const AGEING_TODAY_MS = Date.now();

export type StandardTab =
  | 'overview'
  | 'ifrs15_contracts'
  | 'ifrs16_leases'
  | 'ias36_impairment'
  | 'ias37_provisions'
  | 'ifrs9_instruments'
  | 'ifrs5_hfs'
  | 'ias12_deferred_tax'
  | 'ias19_benefits'
  | 'ifrs8_segments'
  | 'ias33_eps'
  | 'ifrs13_fairvalue'
  | 'ias29_hyperinflation';

export const ComprehensiveStandardsDesk: React.FC<ComprehensiveStandardsDeskProps> = ({
  currentClient,
  currentUser,
  lines = [],
  accounts = [],
  assets = [],
  invoices = [],
  stockItems = [],
  onAddJournalLines,
  onNavigateSection,
}) => {
  // Every figure below is derived from the entity's live registers. Nothing on
  // this desk is sample data: the working papers must be the client's books.
  const entityLines = React.useMemo(() => lines.filter((l) => l.clientId === currentClient.id), [lines, currentClient.id]);
  const glBalance = React.useMemo(() => {
    const m = new Map<string, number>();
    for (const l of entityLines) m.set(l.accountNo, (m.get(l.accountNo) ?? 0) + (l.debit - l.credit));
    return m;
  }, [entityLines]);
  const accountFor = React.useMemo(() => {
    const active = accounts.filter((a) => a.active !== false);
    return (re: RegExp, type?: string): AccountMaster | undefined =>
      active.find((a) => (!type || a.type === type) && re.test(`${a.name} ${a.category ?? ''}`));
  }, [accounts]);
  const balOf = (re: RegExp, type?: string) => {
    const acc = accountFor(re, type);
    return acc ? Math.round((glBalance.get(acc.accountNo) ?? 0) * 100) / 100 : 0;
  };
  const r2 = (n: number) => Math.round((Number.isFinite(n) ? n : 0) * 100) / 100;
  const [activeTab, setActiveTab] = useState<StandardTab>('overview');
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // ----------------------------------------------------
  // 1. IFRS 15 — CONTRACTS, CONTRACT ASSETS & LIABILITIES
  // ----------------------------------------------------
  const derivedContracts: CntRow[] = React.useMemo(() => {
    const groups = new Map<string, SalesInvoice[]>();
    for (const inv of invoices) {
      if (inv.status === 'Draft' || inv.status === 'Credited') continue;
      const key = inv.customerName?.trim() || 'Unnamed customer';
      const list = groups.get(key);
      if (list) list.push(inv); else groups.set(key, [inv]);
    }
    return [...groups.entries()].map(([customer, list], idx) => {
      const revenue = list.reduce((s, i) => s + (i.netRevenue || 0), 0);
      const billed = list.reduce((s, i) => s + (i.totalReceivable || 0), 0);
      const cost = list.reduce((s, i) => s + (i.cogsAmount || 0), 0);
      return {
        id: `CNT-LIVE-${idx + 1}`,
        code: `CNT-${String(idx + 1).padStart(3, '0')}`,
        customer,
        description: [...new Set(list.map((i) => i.revenueStream).filter(Boolean))].join(', ') || 'Contracts with customers',
        contractValue: r2(revenue),
        totalEstimatedCost: r2(cost),
        actualCostIncurred: r2(cost),
        billedToDate: r2(billed),
        status: list.some((i) => i.status !== 'Paid') ? 'In Progress' : 'Completed',
      } as CntRow;
    });
  }, [invoices]);
  const [extraContracts, setExtraContracts] = useState<CntRow[]>([]);
  const contracts: CntRow[] = [...derivedContracts, ...extraContracts];
  const setContracts = (next: CntRow[] | ((prev: CntRow[]) => CntRow[])) => {
    setExtraContracts((prev) => (typeof next === 'function' ? next([...derivedContracts, ...prev]).slice(derivedContracts.length) : next.slice(derivedContracts.length)));
  };

  // Form states for new contract
  const [newCust, setNewCust] = useState('Newmont Mining Ghana');
  const [newDesc, setNewDesc] = useState('Cyanide Tailings Extraction Agreement');
  const [newVal, setNewVal] = useState(600000);
  const [newEstCost, setNewEstCost] = useState(400000);
  const [newActualCost, setNewActualCost] = useState(200000);
  const [newBilled] = useState(250000);

  const handleRecogniseContractPOC = (cnt: typeof contracts[0]) => {
    const poc = cnt.totalEstimatedCost > 0
      ? Math.min(1, cnt.actualCostIncurred / cnt.totalEstimatedCost)
      : (cnt.billedToDate > 0 ? 1 : 0);
    const revenueEarned = cnt.contractValue * poc;
    const netContractBalance = revenueEarned - cnt.billedToDate; // > 0 => Contract Asset (140000), < 0 => Contract Liability (225000)
    const today = new Date().toISOString().split('T')[0];

    let newJournalLines: ACDOCALine[] = [];

    if (netContractBalance > 0) {
      // Contract Asset
      newJournalLines = [
        {
          id: uniqueId('JL-IFRS15'),
          docNo: `IFRS15-${cnt.code}`,
          period: new Date().toISOString().slice(0, 7),
          date: today,
          module: 'SD',
          docType: 'JE',
          accountNo: '141000',
          accountName: 'Contract Assets (IFRS 15 Unbilled Revenue Rights)',
          costCenter: 'CC-SLS',
          debit: netContractBalance,
          credit: 0,
          currency: currentClient.currency,
          description: `IFRS 15 POC Revenue recognition on ${cnt.code} (${(poc * 100).toFixed(1)}% POC)`,
          createdBy: currentUser.username,
          checkedBy: currentUser.canCheck ? currentUser.username : undefined,
          clientId: currentClient.id,
        },
        {
          id: uniqueId('JL-IFRS15'),
          docNo: `IFRS15-${cnt.code}`,
          period: new Date().toISOString().slice(0, 7),
          date: today,
          module: 'SD',
          docType: 'JE',
          accountNo: '400000',
          accountName: 'Revenue from Customer Contracts',
          costCenter: 'CC-SLS',
          debit: 0,
          credit: netContractBalance,
          currency: currentClient.currency,
          description: `Cumulative revenue adjustment per cost-to-cost POC (${cnt.code})`,
          createdBy: currentUser.username,
          checkedBy: currentUser.canCheck ? currentUser.username : undefined,
          clientId: currentClient.id,
        },
      ];
    } else {
      // Contract Liability (advance billings in excess of POC)
      const absLiability = Math.abs(netContractBalance);
      newJournalLines = [
        {
          id: uniqueId('JL-IFRS15'),
          docNo: `IFRS15-${cnt.code}`,
          period: new Date().toISOString().slice(0, 7),
          date: today,
          module: 'SD',
          docType: 'JE',
          accountNo: '400000',
          accountName: 'Revenue from Customer Contracts (Deferred)',
          costCenter: 'CC-SLS',
          debit: absLiability,
          credit: 0,
          currency: currentClient.currency,
          description: `IFRS 15 Deferral of customer advances over POC (${cnt.code})`,
          createdBy: currentUser.username,
          checkedBy: currentUser.canCheck ? currentUser.username : undefined,
          clientId: currentClient.id,
        },
        {
          id: uniqueId('JL-IFRS15'),
          docNo: `IFRS15-${cnt.code}`,
          period: new Date().toISOString().slice(0, 7),
          date: today,
          module: 'SD',
          docType: 'JE',
          accountNo: '225000',
          accountName: 'Contract Liabilities (IFRS 15 Advances Received)',
          costCenter: 'CC-SLS',
          debit: 0,
          credit: absLiability,
          currency: currentClient.currency,
          description: `Unearned customer consideration advance recognized as liability`,
          createdBy: currentUser.username,
          checkedBy: currentUser.canCheck ? currentUser.username : undefined,
          clientId: currentClient.id,
        },
      ];
    }

    onAddJournalLines(newJournalLines);
    setActionSuccess(
      `IFRS 15 Entry Posted! Cost-to-cost POC: ${(poc * 100).toFixed(1)}%. Revenue recognized: ₵${formatGHS(revenueEarned)}. Net ${netContractBalance >= 0 ? 'Contract Asset' : 'Contract Liability'}: ₵${formatGHS(Math.abs(netContractBalance))}.`
    );
    setTimeout(() => setActionSuccess(null), 5000);
  };

  const handleAddContract = (e: React.FormEvent) => {
    e.preventDefault();
    const newCnt = {
      id: `CNT-00${contracts.length + 1}`,
      code: nextDocNo(`CNT-${currentYear()}`, contracts.map((c) => c.code), 3),
      customer: newCust,
      description: newDesc,
      contractValue: newVal,
      totalEstimatedCost: newEstCost,
      actualCostIncurred: newActualCost,
      billedToDate: newBilled,
      status: 'In Progress',
    };
    setContracts([...contracts, newCnt]);
    setActionSuccess(`Added new contract ${newCnt.code}. Ready for IFRS 15 POC calculations.`);
    setTimeout(() => setActionSuccess(null), 4000);
  };

  // ----------------------------------------------------
  // 2. IFRS 16 — RIGHT-OF-USE ASSETS & LEASE LIABILITIES
  // ----------------------------------------------------
  const leases = React.useMemo(() => {
    const rouCost = r2(balOf(/right-of-use/i, 'Asset') - balOf(/accumulated depreciation.{0,20}(right-of-use|rou)|right-of-use.{0,30}accumulated/i, 'Asset'));
    const rouAccum = r2(-balOf(/right-of-use/i, 'Asset') + (rouCost + balOf(/right-of-use/i, 'Asset')));
    const liab = r2(-balOf(/lease liab/i, 'Liability'));
    const rouGross = r2(rouCost + Math.abs(balOf(/accumulated depreciation.{0,40}rou|rou.{0,40}accumulated/i, 'Asset')));
    if (Math.abs(rouGross) < 0.01 && Math.abs(liab) < 0.01) return [];
    return [{
      id: 'LSE-GL', code: 'LSE-LEDGER', lessor: 'Per lease register / journal',
      description: 'Right-of-use assets and lease liabilities recognised in the ledger (measure terms on the IFRS Schedules desk)',
      termMonths: 0, monthlyPayment: 0, discountRate: 0,
      rouCost: rouGross, rouAccumDep: r2(Math.max(0, rouGross - rouCost)), leaseLiability: liab, status: 'Active',
    }];
  }, [accounts, glBalance]);

  const handlePostLeaseMonthlyEntry = (lse: typeof leases[0]) => {
    const monthlyDep = lse.rouCost / lse.termMonths;
    // A lease posting needs measured terms. When the register carries only ledger
    // balances (no payment or rate yet), refuse rather than post a zero entry.
    if (!(lse.monthlyPayment > 0)) {
      setActionSuccess(`Lease ${lse.code}: no measured payment or discount rate. Enter the lease terms on the IFRS Schedules desk (IFRS 16 inputs) so the amortisation can be computed before posting.`);
      setTimeout(() => setActionSuccess(null), 7000);
      return;
    }
    const monthlyInterest = (lse.leaseLiability * (lse.discountRate / 100)) / 12;
    const principalPaid = lse.monthlyPayment - monthlyInterest;
    const today = new Date().toISOString().split('T')[0];

    const lines: ACDOCALine[] = [
      // 1. Depreciation of ROU Asset
      {
        id: uniqueId('JL-IFRS16'),
        docNo: `LSE-DEP-${lse.code}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI-AA',
        docType: 'DEP',
        accountNo: '610000',
        accountName: 'Depreciation Expense — Right-of-Use Assets',
        costCenter: 'CC-OPS',
        debit: monthlyDep,
        credit: 0,
        currency: currentClient.currency,
        description: `IFRS 16 Monthly ROU amortization on ${lse.code}`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      {
        id: uniqueId('JL-IFRS16'),
        docNo: `LSE-DEP-${lse.code}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI-AA',
        docType: 'DEP',
        accountNo: '159000',
        accountName: 'Accumulated Depreciation — ROU Assets',
        costCenter: 'CC-OPS',
        debit: 0,
        credit: monthlyDep,
        currency: currentClient.currency,
        description: `Accumulated depreciation contra-asset (${lse.code})`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      // 2. Lease Liability reduction & Finance Cost
      {
        id: uniqueId('JL-IFRS16'),
        docNo: `LSE-PMT-${lse.code}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI',
        docType: 'PAY',
        accountNo: '710000',
        accountName: 'Finance Cost — Lease Liability Interest',
        costCenter: 'CC-ADM',
        debit: monthlyInterest,
        credit: 0,
        currency: currentClient.currency,
        description: `Interest unwinding at ${lse.discountRate}% on ${lse.code}`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      {
        id: uniqueId('JL-IFRS16'),
        docNo: `LSE-PMT-${lse.code}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI',
        docType: 'PAY',
        accountNo: '230000',
        accountName: 'Lease Liabilities (IFRS 16 Principal)',
        costCenter: 'CC-ADM',
        debit: principalPaid,
        credit: 0,
        currency: currentClient.currency,
        description: `Principal lease liability settlement on ${lse.code}`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      {
        id: uniqueId('JL-IFRS16'),
        docNo: `LSE-PMT-${lse.code}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI',
        docType: 'PAY',
        accountNo: '100000',
        accountName: 'Cash at Bank (Ecobank Ghana)',
        costCenter: 'CC-ADM',
        debit: 0,
        credit: lse.monthlyPayment,
        currency: currentClient.currency,
        description: `Monthly lease payment settlement to ${lse.lessor}`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
    ];

    onAddJournalLines(lines);
    setActionSuccess(
      `IFRS 16 Monthly Entries Posted! ROU Depreciation: ₵${formatGHS(monthlyDep)}. Finance Interest: ₵${formatGHS(monthlyInterest)}. Principal Reduction: ₵${formatGHS(principalPaid)}. Bank Credit: ₵${formatGHS(lse.monthlyPayment)}.`
    );
    setTimeout(() => setActionSuccess(null), 5000);
  };

  // ----------------------------------------------------
  // 3. IAS 36 — IMPAIRMENT OF NON-FINANCIAL ASSETS & CGUs
  // ----------------------------------------------------
  const cguTests = React.useMemo(() => {
    const byClass = new Map<string, FixedAsset[]>();
    for (const a of assets) {
      if (a.disposedDate) continue;
      const key = a.classCode || 'Ungrouped assets';
      const list = byClass.get(key);
      if (list) list.push(a); else byClass.set(key, [a]);
    }
    return [...byClass.entries()].map(([cguName, list], idx) => {
      const carrying = r2(list.reduce((s, a) => s + (a.cost - a.accumDep), 0));
      // The recoverable amount is a MEASUREMENT (VIU or FVLCD), not an assumption.
      // Until it is measured on the IFRS Schedules desk no impairment is recognised.
      return {
        cguName, carryingAmount: carrying, valueInUse: 0, fairValueLessCosts: 0,
        recoverableAmount: 0, headroom: 0, impairmentRequired: 0,
        docNo: `IMP-${String(idx + 1).padStart(3, '0')}`,
      };
    });
  }, [assets]);

  const handlePostImpairmentEntry = (cgu: typeof cguTests[0]) => {
    if (cgu.impairmentRequired <= 0) return;
    const today = new Date().toISOString().split('T')[0];

    const lines: ACDOCALine[] = [
      {
        id: uniqueId('JL-IAS36'),
        docNo: cgu.docNo,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI-AA',
        docType: 'JE',
        accountNo: '690000',
        accountName: 'Impairment Loss on Non-Financial Assets (IAS 36 P&L)',
        costCenter: 'CC-OPS',
        debit: cgu.impairmentRequired,
        credit: 0,
        currency: currentClient.currency,
        description: `IAS 36 Impairment write-down on ${cgu.cguName} to recoverable amount ₵${formatGHS(cgu.recoverableAmount)}`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      {
        id: uniqueId('JL-IAS36'),
        docNo: cgu.docNo,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI-AA',
        docType: 'JE',
        accountNo: '139000',
        accountName: 'Accumulated Impairment Allowance (Contra Asset)',
        costCenter: 'CC-OPS',
        debit: 0,
        credit: cgu.impairmentRequired,
        currency: currentClient.currency,
        description: `Direct reduction of CGU carrying amount`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
    ];

    onAddJournalLines(lines);
    setActionSuccess(
      `IAS 36 Impairment Entry Posted! Debited Impairment Loss (₵${formatGHS(cgu.impairmentRequired)}) and credited Accumulated Impairment Allowance.`
    );
    setTimeout(() => setActionSuccess(null), 5000);
  };

  // ----------------------------------------------------
  // 4. IAS 37 — PROVISIONS, CONTINGENT LIABILITIES & ASSETS
  // ----------------------------------------------------
  const provisionsList = React.useMemo(() => {
    const carrying = r2(-balOf(/provision/i, 'Liability'));
    if (Math.abs(carrying) < 0.01) return [];
    return [{
      code: 'PRV-LEDGER', title: 'Provisions recognised in the ledger (IAS 37)', category: 'Present obligations',
      bestEstimate: carrying, probability: 100, discountRate: 0, yearsToSettlement: 0,
      presentValue: carrying, currentCarrying: carrying, unwindingInterest: 0,
      status: 'Recognised Provision (Present Obligation)',
    }];
  }, [accounts, glBalance]);

  const handlePostProvisionUnwinding = (prv: typeof provisionsList[0]) => {
    if (prv.unwindingInterest <= 0) return;
    const today = new Date().toISOString().split('T')[0];

    const lines: ACDOCALine[] = [
      {
        id: uniqueId('JL-IAS37'),
        docNo: `IAS37-${prv.code}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI',
        docType: 'JE',
        accountNo: '720000',
        accountName: 'Finance Cost — Unwinding of Discount on Provisions',
        costCenter: 'CC-ADM',
        debit: prv.unwindingInterest,
        credit: 0,
        currency: currentClient.currency,
        description: `IAS 37 Annual discount unwinding on ${prv.title}`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      {
        id: uniqueId('JL-IAS37'),
        docNo: `IAS37-${prv.code}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI',
        docType: 'JE',
        accountNo: '270000',
        accountName: 'Provisions for Mine Site Rehabilitation (Non-Current)',
        costCenter: 'CC-ADM',
        debit: 0,
        credit: prv.unwindingInterest,
        currency: currentClient.currency,
        description: `Accretion to present value of future decommissioning liability`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
    ];

    onAddJournalLines(lines);
    setActionSuccess(
      `IAS 37 Discount Unwinding Posted! Finance Cost ₵${formatGHS(prv.unwindingInterest)} debited; Rehabilitation Provision credited.`
    );
    setTimeout(() => setActionSuccess(null), 5000);
  };

  // ----------------------------------------------------
  // 5. IFRS 9 — ECL STAGING & FINANCIAL INSTRUMENTS
  // ----------------------------------------------------
  const eclMatrix = React.useMemo(() => {
    const DAY = 86400000;
    const todayMs = AGEING_TODAY_MS;
    const buckets = [
      { bucket: 'Current (0–30 days)', stage: 1, min: -1e9, max: 30, eclRate: 1 },
      { bucket: '31–60 days past due', stage: 2, min: 30, max: 60, eclRate: 3 },
      { bucket: '61–90 days past due', stage: 2, min: 60, max: 90, eclRate: 8 },
      { bucket: '90+ days (Credit-Impaired)', stage: 3, min: 90, max: 1e9, eclRate: 40 },
    ];
    return buckets.map((b) => {
      const exposure = invoices
        .filter((i) => i.status !== 'Draft' && i.status !== 'Credited')
        .map((i) => ({ bal: (i.totalReceivable || 0) - (i.paidAmount || 0), days: Math.floor((todayMs - Date.parse(i.date)) / DAY) }))
        .filter((x) => x.bal > 0.009 && x.days > b.min && x.days <= b.max)
        .reduce((s, x) => s + x.bal, 0);
      return { bucket: b.bucket, stage: b.stage, grossExposure: r2(exposure), eclRate: b.eclRate, allowance: r2(exposure * b.eclRate / 100) };
    });
  }, [invoices]);

  const totalEclAllowance = eclMatrix.reduce((s, b) => s + b.allowance, 0);

  const handlePostEclAdjustment = () => {
    const today = new Date().toISOString().split('T')[0];
    const lines: ACDOCALine[] = [
      {
        id: uniqueId('JL-IFRS9'),
        docNo: `ECL-${new Date().toISOString().slice(0, 7)}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI',
        docType: 'JE',
        accountNo: '680000',
        accountName: 'Impairment Loss on Financial Assets (ECL Charge)',
        costCenter: 'CC-ADM',
        debit: totalEclAllowance,
        credit: 0,
        currency: currentClient.currency,
        description: `IFRS 9 Expected credit loss quarterly matrix update`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      {
        id: uniqueId('JL-IFRS9'),
        docNo: `ECL-${new Date().toISOString().slice(0, 7)}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI',
        docType: 'JE',
        accountNo: '119000',
        accountName: 'Allowance for Expected Credit Losses (Contra AR)',
        costCenter: 'CC-ADM',
        debit: 0,
        credit: totalEclAllowance,
        currency: currentClient.currency,
        description: `Allowance across Stage 1, 2, and 3 credit risk exposures`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
    ];

    onAddJournalLines(lines);
    setActionSuccess(`IFRS 9 ECL Provision of ₵${formatGHS(totalEclAllowance)} posted to Universal Journal!`);
    setTimeout(() => setActionSuccess(null), 5000);
  };

  // ----------------------------------------------------
  // 6. IFRS 5 — NON-CURRENT ASSETS HELD FOR SALE
  // ----------------------------------------------------
  const hfsAssets = React.useMemo(() => {
    return assets
      .filter((a) => a.disposedDate || (a.disposalProceeds ?? 0) > 0)
      .map((a) => {
        const carrying = r2(a.cost - a.accumDep);
        const fvlcd = r2(a.disposalProceeds ?? carrying);
        return {
          tag: a.assetTag, name: a.name, carryingAmount: carrying, fairValueLessCosts: fvlcd,
          impairmentOnTransfer: r2(Math.max(0, carrying - fvlcd)),
          activePlanToSell: Boolean(a.disposedDate), buyerIdentified: a.disposedDate ? 'Disposal completed' : 'Under offer',
          status: a.disposedDate ? 'Disposed / held for sale' : 'Classified Held for Sale',
        };
      });
  }, [assets]);

  const handleClassifyHeldForSale = (item: typeof hfsAssets[0]) => {
    const today = new Date().toISOString().split('T')[0];
    const lines: ACDOCALine[] = [
      // Transfer to HFS Asset line
      {
        id: uniqueId('JL-IFRS5'),
        docNo: `HFS-${item.tag}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI-AA',
        docType: 'JE',
        accountNo: '180000',
        accountName: 'Non-Current Assets Held for Sale (IFRS 5 Current Asset)',
        costCenter: 'CC-OPS',
        debit: item.fairValueLessCosts,
        credit: 0,
        currency: currentClient.currency,
        description: `Transfer of ${item.name} to Held for Sale at lower of carrying & FV less costs`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      {
        id: uniqueId('JL-IFRS5'),
        docNo: `HFS-${item.tag}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI-AA',
        docType: 'JE',
        accountNo: '690000',
        accountName: 'Impairment Loss on Reclassification to IFRS 5',
        costCenter: 'CC-OPS',
        debit: item.impairmentOnTransfer,
        credit: 0,
        currency: currentClient.currency,
        description: `Immediate valuation write-down on transfer to HFS`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      {
        id: uniqueId('JL-IFRS5'),
        docNo: `HFS-${item.tag}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI-AA',
        docType: 'JE',
        accountNo: '130000',
        accountName: 'Property, Plant and Equipment (Derecognition)',
        costCenter: 'CC-OPS',
        debit: 0,
        credit: item.carryingAmount,
        currency: currentClient.currency,
        description: `Derecognition from operational PPE (depreciation ceased)`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
    ];

    onAddJournalLines(lines);
    setActionSuccess(
      `IFRS 5 Reclassification Complete! Asset transferred to Current HFS (₵${formatGHS(item.fairValueLessCosts)}), depreciation ceased, and valuation write-down recognized in P&L.`
    );
    setTimeout(() => setActionSuccess(null), 5000);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`IFRS & IAS COMPREHENSIVE RECOGNITION SUITE · ${currentClient.code}`}
        title="Comprehensive IFRS / IAS Accounting Desk"
        desc="IFRS 15 contracts, IFRS 16 leases, IAS 36 impairments, IAS 37 provisions, IFRS 9 ECL and IFRS 5 held-for-sale — all post to the Universal Journal."
      >
        <div className="flex gap-2">
          {onNavigateSection && (
            <button
              onClick={() => onNavigateSection('loans_desk')}
              className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
            >
              <Calculator className="h-4 w-4" />
              <span>Loan Amortisation Schedules</span>
            </button>
          )}
        </div>
      </PageHeader>

      {actionSuccess && (
        <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-xs font-bold text-emerald-900 flex items-center gap-2 shadow-xs">
          <CheckCircle className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* Standards Tab Strip */}
      <div className="flex flex-wrap gap-1 rounded-xl border border-sky-200 bg-white p-1.5 shadow-xs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition ${
            activeTab === 'overview' ? 'bg-[#082f4f] text-white shadow-xs' : 'text-[#2d4f6d] hover:bg-sky-50'
          }`}
        >
          Standards Overview
        </button>
        <button
          onClick={() => setActiveTab('ifrs15_contracts')}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition ${
            activeTab === 'ifrs15_contracts' ? 'bg-[#082f4f] text-white shadow-xs' : 'text-[#2d4f6d] hover:bg-sky-50'
          }`}
        >
          IFRS 15 Contracts (POC)
        </button>
        <button
          onClick={() => setActiveTab('ifrs16_leases')}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition ${
            activeTab === 'ifrs16_leases' ? 'bg-[#082f4f] text-white shadow-xs' : 'text-[#2d4f6d] hover:bg-sky-50'
          }`}
        >
          IFRS 16 Leases &amp; ROU
        </button>
        <button
          onClick={() => setActiveTab('ias36_impairment')}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition ${
            activeTab === 'ias36_impairment' ? 'bg-[#082f4f] text-white shadow-xs' : 'text-[#2d4f6d] hover:bg-sky-50'
          }`}
        >
          IAS 36 Impairments
        </button>
        <button
          onClick={() => setActiveTab('ias37_provisions')}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition ${
            activeTab === 'ias37_provisions' ? 'bg-[#082f4f] text-white shadow-xs' : 'text-[#2d4f6d] hover:bg-sky-50'
          }`}
        >
          IAS 37 Provisions &amp; Contingencies
        </button>
        <button
          onClick={() => setActiveTab('ifrs9_instruments')}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition ${
            activeTab === 'ifrs9_instruments' ? 'bg-[#082f4f] text-white shadow-xs' : 'text-[#2d4f6d] hover:bg-sky-50'
          }`}
        >
          IFRS 9 ECL Staging
        </button>
        <button
          onClick={() => setActiveTab('ifrs5_hfs')}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition ${
            activeTab === 'ifrs5_hfs' ? 'bg-[#082f4f] text-white shadow-xs' : 'text-[#2d4f6d] hover:bg-sky-50'
          }`}
        >
          IFRS 5 Assets Held for Sale
        </button>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* TAB 0: OVERVIEW                                               */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'overview' && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
            <Stat label="IFRS 15 Net Contracts" value={`₵${formatGHS(contracts.reduce((s, c) => s + c.contractValue, 0))}`} sub="POC recognized" tone="text-emerald-800" />
            <Stat label="IFRS 16 Total ROU NBV" value={`₵${formatGHS(leases.reduce((s, l) => s + l.rouCost - l.rouAccumDep, 0))}`} sub="Right-of-use carrying" tone="text-[#082f4f]" />
            <Stat label="IAS 37 Provisions PV" value={`₵${formatGHS(provisionsList.filter(p => p.currentCarrying > 0).reduce((s, p) => s + p.currentCarrying, 0))}`} sub="Discounted obligations" tone="text-rose-800" />
            <Stat label="IFRS 9 ECL Allowance" value={`₵${formatGHS(totalEclAllowance)}`} sub="Expected credit loss" tone="text-[#855b00]" />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card title="Standards Engine" sub="Each module posts directly to the Universal Journal">
              <ul className="list-disc pl-4 space-y-1.5 text-xs text-[#2d4f6d]">
                <li><strong>IFRS 15:</strong> Contracts, POC revenue, assets &amp; liabilities.</li>
                <li><strong>IFRS 16:</strong> Leases, ROU assets &amp; liabilities.</li>
                <li><strong>IAS 36:</strong> CGU impairment &amp; recoverable amount.</li>
                <li><strong>IAS 37:</strong> Provisions &amp; discount unwinding.</li>
                <li><strong>IFRS 9:</strong> 3-stage ECL matrix.</li>
                <li><strong>IFRS 5:</strong> Assets held for sale.</li>
              </ul>
            </Card>

            <Card title="Borrowings" sub="Full amortisation schedules">
              <div className="space-y-3 text-xs text-[#2d4f6d]">
                <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3 text-emerald-900">
                  <div className="font-bold mb-1">Active Facilities:</div>
                  <div className="text-[11.5px]">Ecobank Tailings: ₵1,200,000 · 21.5% · 60m</div>
                  <div className="text-[11.5px]">Stanbic Fleet: ₵350,000 · 18.0% · 36m</div>
                </div>
                {onNavigateSection && (
                  <button
                    onClick={() => onNavigateSection('loans_desk')}
                    className="w-full flex items-center justify-center gap-2 rounded-lg bg-[#082f4f] py-2 text-xs font-bold text-white hover:bg-[#0c3f68]"
                  >
                    <span>Open Loan Amortisation Schedules</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                )}
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 1: IFRS 15 CONTRACTS (POC)                                 */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'ifrs15_contracts' && (
        <div className="space-y-5">
          <Card
            title="IFRS 15 Contracts with Customers &amp; Performance Obligations"
            sub="Cost-to-Cost Percentage of Completion (POC) computation"
            action={
              <span className="text-xs font-bold text-[#082f4f] bg-sky-100 px-2.5 py-1 rounded">
                IAS 11 / IFRS 15 Engine
              </span>
            }
          >
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-sky-200 bg-sky-50/70">
                    <th className={thCls}>Contract Code</th>
                    <th className={thCls}>Customer</th>
                    <th className={thCls}>Total Price (₵)</th>
                    <th className={thCls + " text-right"}>Est. Cost (₵)</th>
                    <th className={thCls + " text-right"}>Actual Cost (₵)</th>
                    <th className={thCls + " text-center"}>POC %</th>
                    <th className={thCls + " text-right"}>POC Revenue (₵)</th>
                    <th className={thCls + " text-right"}>Billed (₵)</th>
                    <th className={thCls + " text-right"}>Contract Asset/(Liab)</th>
                    <th className={thCls + " text-center"}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {contracts.map((c) => {
                    const poc = c.totalEstimatedCost > 0
                      ? Math.min(1, c.actualCostIncurred / c.totalEstimatedCost)
                      : (c.billedToDate > 0 ? 1 : 0);
                    const pocRevenue = c.contractValue * poc;
                    const netPosition = pocRevenue - c.billedToDate;
                    const isAsset = netPosition >= 0;

                    return (
                      <tr key={c.id} className={rowCls}>
                        <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{c.code}</td>
                        <td className="px-3 py-2 font-bold text-[#082f4f]">{c.customer}</td>
                        <td className={numCls}>{formatGHS(c.contractValue)}</td>
                        <td className={numCls}>{formatGHS(c.totalEstimatedCost)}</td>
                        <td className={numCls}>{formatGHS(c.actualCostIncurred)}</td>
                        <td className="px-3 py-2 text-center font-bold font-mono text-[#006f98]">
                          {(poc * 100).toFixed(1)}%
                        </td>
                        <td className={numCls + " font-bold text-emerald-800"}>{formatGHS(pocRevenue)}</td>
                        <td className={numCls}>{formatGHS(c.billedToDate)}</td>
                        <td className={numCls + ` font-black ${isAsset ? 'text-emerald-800' : 'text-rose-800'}`}>
                          {isAsset ? `+₵${formatGHS(netPosition)} (Asset)` : `-₵${formatGHS(Math.abs(netPosition))} (Liab)`}
                        </td>
                        <td className="px-3 py-2 text-center">
                          <button
                            onClick={() => handleRecogniseContractPOC(c)}
                            className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] transition"
                          >
                            Post to ACDOCA
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>

          {/* New Contract Form */}
          <Card title="Add Long-Term Customer Contract" sub="Establish contract values and cost budgets">
            <form onSubmit={handleAddContract} className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Customer Name</label>
                <input
                  type="text"
                  value={newCust}
                  onChange={(e) => setNewCust(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                  required
                />
              </div>
              <div className="md:col-span-2">
                <label className="block font-bold text-[#0a253e] mb-1">Performance Obligation Description</label>
                <input
                  type="text"
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Contract Transaction Price (₵)</label>
                <input
                  type="number"
                  value={newVal}
                  onChange={(e) => setNewVal(Number(e.target.value))}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Total Estimated Costs to Complete (₵)</label>
                <input
                  type="number"
                  value={newEstCost}
                  onChange={(e) => setNewEstCost(Number(e.target.value))}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Actual Cumulative Costs Incurred (₵)</label>
                <input
                  type="number"
                  value={newActualCost}
                  onChange={(e) => setNewActualCost(Number(e.target.value))}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                  required
                />
              </div>
              <div className="md:col-span-3 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#0c3f68]"
                >
                  <Plus className="h-4 w-4" />
                  <span>Register Contract in IFRS 15 Engine</span>
                </button>
              </div>
            </form>
          </Card>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 2: IFRS 16 LEASES & ROU SCHEDULES                          */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'ifrs16_leases' && (
        <div className="space-y-5">
          <Card
            title="IFRS 16 Leases — Right-of-Use Assets &amp; Liabilities"
            sub="Automatic amortization of ROU assets and finance cost unwinding"
          >
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-sky-200 bg-sky-50/70">
                    <th className={thCls}>Lease Code</th>
                    <th className={thCls}>Lessor / Facility</th>
                    <th className={thCls + " text-right"}>Term (Months)</th>
                    <th className={thCls + " text-right"}>Discount Rate %</th>
                    <th className={thCls + " text-right"}>Monthly Rent (₵)</th>
                    <th className={thCls + " text-right"}>ROU Asset Cost (₵)</th>
                    <th className={thCls + " text-right"}>ROU Carrying NBV (₵)</th>
                    <th className={thCls + " text-right"}>Lease Liability (₵)</th>
                    <th className={thCls + " text-center"}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {leases.map((l) => {
                    const nbv = l.rouCost - l.rouAccumDep;
                    return (
                      <tr key={l.id} className={rowCls}>
                        <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{l.code}</td>
                        <td className="px-3 py-2 font-bold text-[#082f4f]">{l.description}</td>
                        <td className={numCls}>{l.termMonths}m</td>
                        <td className={numCls}>{l.discountRate}%</td>
                        <td className={numCls + " font-bold"}>{formatGHS(l.monthlyPayment)}</td>
                        <td className={numCls}>{formatGHS(l.rouCost)}</td>
                        <td className={numCls + " font-bold text-emerald-800"}>{formatGHS(nbv)}</td>
                        <td className={numCls + " font-bold text-rose-800"}>{formatGHS(l.leaseLiability)}</td>
                        <td className="px-3 py-2 text-center">
                          <button
                            onClick={() => handlePostLeaseMonthlyEntry(l)}
                            className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] transition"
                          >
                            Post Monthly Journal
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 3: IAS 36 IMPAIRMENTS & CGU RECOVERABLE AMOUNTS            */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'ias36_impairment' && (
        <div className="space-y-5">
          <Card
            title="IAS 36 Impairment of Assets &amp; Cash-Generating Units (CGUs)"
            sub="Recoverable amount = higher of Value in Use (VIU) and Fair Value less costs to sell"
          >
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-sky-200 bg-sky-50/70">
                    <th className={thCls}>CGU Description</th>
                    <th className={thCls + " text-right"}>Carrying Value (₵)</th>
                    <th className={thCls + " text-right"}>Value in Use (DCF) (₵)</th>
                    <th className={thCls + " text-right"}>Fair Value Less Costs (₵)</th>
                    <th className={thCls + " text-right"}>Recoverable Amount ({currencySymbol(currentClient.currency)})</th>
                    <th className={thCls + " text-right"}>Headroom / Deficit (₵)</th>
                    <th className={thCls + " text-center"}>Decision</th>
                    <th className={thCls + " text-center"}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {cguTests.map((t, idx) => (
                    <tr key={idx} className={rowCls}>
                      <td className="px-3 py-2 font-bold text-[#082f4f]">{t.cguName}</td>
                      <td className={numCls}>{formatGHS(t.carryingAmount)}</td>
                      <td className={numCls}>{formatGHS(t.valueInUse)}</td>
                      <td className={numCls}>{formatGHS(t.fairValueLessCosts)}</td>
                      <td className={numCls + " font-bold text-[#006f98]"}>{formatGHS(t.recoverableAmount)}</td>
                      <td className={numCls + ` font-black ${t.headroom >= 0 ? 'text-emerald-800' : 'text-rose-800'}`}>
                        {t.headroom >= 0 ? `+₵${formatGHS(t.headroom)}` : `-₵${formatGHS(Math.abs(t.headroom))}`}
                      </td>
                      <td className="px-3 py-2 text-center">
                        <span
                          className={`rounded px-2 py-0.5 text-[10.5px] font-bold ${
                            t.impairmentRequired === 0
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : 'bg-rose-100 text-rose-800 border border-rose-300'
                          }`}
                        >
                          {t.impairmentRequired === 0 ? 'No Impairment' : `Impairment: ₵${formatGHS(t.impairmentRequired)}`}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-center">
                        {t.impairmentRequired > 0 ? (
                          <button
                            onClick={() => handlePostImpairmentEntry(t)}
                            className="rounded bg-[#b42318] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-rose-800 transition"
                          >
                            Post Impairment
                          </button>
                        ) : (
                          <span className="text-[11px] text-emerald-700 font-semibold">Clean Headroom</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 4: IAS 37 PROVISIONS & REHABILITATION                      */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'ias37_provisions' && (
        <div className="space-y-5">
          <Card
            title="IAS 37 Provisions, Contingent Liabilities &amp; Assets"
            sub="Present obligations recognized at discounted present value with annual accretion"
          >
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-sky-200 bg-sky-50/70">
                    <th className={thCls}>Provision Code</th>
                    <th className={thCls}>Obligation Title</th>
                    <th className={thCls + " text-center"}>Probability</th>
                    <th className={thCls + " text-right"}>Best Estimate (₵)</th>
                    <th className={thCls + " text-right"}>Discount Rate %</th>
                    <th className={thCls + " text-right"}>Present Value (₵)</th>
                    <th className={thCls + " text-right"}>Unwinding Interest (₵)</th>
                    <th className={thCls}>IAS 37 Status</th>
                    <th className={thCls + " text-center"}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {provisionsList.map((p) => (
                    <tr key={p.code} className={rowCls}>
                      <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{p.code}</td>
                      <td className="px-3 py-2 font-bold text-[#082f4f]">{p.title}</td>
                      <td className="px-3 py-2 text-center font-bold font-mono">{p.probability}%</td>
                      <td className={numCls}>{formatGHS(p.bestEstimate)}</td>
                      <td className={numCls}>{p.discountRate}%</td>
                      <td className={numCls + " font-bold text-[#082f4f]"}>{formatGHS(p.presentValue)}</td>
                      <td className={numCls + " text-rose-700 font-bold"}>
                        {p.unwindingInterest > 0 ? `₵${formatGHS(p.unwindingInterest)}` : '—'}
                      </td>
                      <td className="px-3 py-2 text-[11px] text-[#2d4f6d]">{p.status}</td>
                      <td className="px-3 py-2 text-center">
                        {p.unwindingInterest > 0 ? (
                          <button
                            onClick={() => handlePostProvisionUnwinding(p)}
                            className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] transition"
                          >
                            Unwind Discount
                          </button>
                        ) : (
                          <span className="text-[11px] text-slate-500">Note Disclosure</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 5: IFRS 9 ECL STAGING                                     */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'ifrs9_instruments' && (
        <div className="space-y-5">
          <Card
            title="IFRS 9 Financial Instruments — Expected Credit Loss (ECL) Matrix"
            sub="Stage 1 (12-month ECL), Stage 2 (Significant Increase in Credit Risk), and Stage 3 (Credit-Impaired)"
            action={
              <button
                onClick={handlePostEclAdjustment}
                className="rounded bg-[#082f4f] px-3 py-1.5 text-xs font-bold text-white hover:bg-[#0c3f68]"
              >
                Post Total ECL to ACDOCA
              </button>
            }
          >
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-sky-200 bg-sky-50/70">
                    <th className={thCls}>Aging Exposure Bucket</th>
                    <th className={thCls + " text-center"}>IFRS 9 Stage</th>
                    <th className={thCls + " text-right"}>Gross Trade Receivables (₵)</th>
                    <th className={thCls + " text-right"}>Forward-Looking Loss Rate %</th>
                    <th className={thCls + " text-right"}>ECL Allowance (₵)</th>
                    <th className={thCls + " text-right"}>Net Carrying Amount ({currencySymbol(currentClient.currency)})</th>
                  </tr>
                </thead>
                <tbody>
                  {eclMatrix.map((m, idx) => (
                    <tr key={idx} className={rowCls}>
                      <td className="px-3 py-2 font-bold text-[#082f4f]">{m.bucket}</td>
                      <td className="px-3 py-2 text-center">
                        <span
                          className={`rounded px-2 py-0.5 font-mono text-[10.5px] font-bold ${
                            m.stage === 1
                              ? 'bg-emerald-100 text-emerald-800'
                              : m.stage === 2
                              ? 'bg-amber-100 text-[#855b00]'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          Stage {m.stage}
                        </span>
                      </td>
                      <td className={numCls}>{formatGHS(m.grossExposure)}</td>
                      <td className={numCls}>{m.eclRate}%</td>
                      <td className={numCls + " font-bold text-rose-800"}>₵{formatGHS(m.allowance)}</td>
                      <td className={numCls + " font-bold text-emerald-800"}>₵{formatGHS(m.grossExposure - m.allowance)}</td>
                    </tr>
                  ))}
                  <tr className="bg-sky-100 font-bold border-t-2 border-sky-300">
                    <td colSpan={2} className="px-3 py-2.5 text-[#082f4f]">Total Trade Receivables &amp; Lifetime ECL Allowance</td>
                    <td className="px-3 py-2.5 text-right font-mono font-bold">
                      ₵{formatGHS(eclMatrix.reduce((s, m) => s + m.grossExposure, 0))}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono">—</td>
                    <td className="px-3 py-2.5 text-right font-mono font-black text-rose-800">
                      ₵{formatGHS(totalEclAllowance)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono font-black text-emerald-800">
                      ₵{formatGHS(eclMatrix.reduce((s, m) => s + (m.grossExposure - m.allowance), 0))}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 6: IFRS 5 HELD FOR SALE                                   */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'ifrs5_hfs' && (
        <div className="space-y-5">
          <Card
            title="IFRS 5 Non-Current Assets Held for Sale &amp; Discontinued Operations"
            sub="Measured at lower of carrying amount and fair value less costs to sell; cessation of depreciation"
          >
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-sky-200 bg-sky-50/70">
                    <th className={thCls}>Asset Identifier</th>
                    <th className={thCls}>Asset Description</th>
                    <th className={thCls + " text-right"}>Original Carrying NBV (₵)</th>
                    <th className={thCls + " text-right"}>Fair Value Less Costs (₵)</th>
                    <th className={thCls + " text-right"}>Transfer Impairment (₵)</th>
                    <th className={thCls}>Committed Sale Plan</th>
                    <th className={thCls}>Status</th>
                    <th className={thCls + " text-center"}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {hfsAssets.map((a) => (
                    <tr key={a.tag} className={rowCls}>
                      <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{a.tag}</td>
                      <td className="px-3 py-2 font-bold text-[#082f4f]">{a.name}</td>
                      <td className={numCls}>{formatGHS(a.carryingAmount)}</td>
                      <td className={numCls + " font-bold text-emerald-800"}>{formatGHS(a.fairValueLessCosts)}</td>
                      <td className={numCls + " text-rose-800 font-bold"}>₵{formatGHS(a.impairmentOnTransfer)}</td>
                      <td className="px-3 py-2 text-[#2d4f6d]">{a.buyerIdentified}</td>
                      <td className="px-3 py-2">
                        <span className="rounded bg-sky-100 text-[#006f98] px-2 py-0.5 text-[10.5px] font-bold">
                          {a.status}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-center">
                        <button
                          onClick={() => handleClassifyHeldForSale(a)}
                          className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] transition"
                        >
                          Execute Transfer
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};
