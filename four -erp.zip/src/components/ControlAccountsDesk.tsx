"use client";

import { useMemo, useState } from "react";
import type {
  ACDOCALine,
  BankAccount,
  BusinessPartner,
  ClientEntity,
  FixedAsset,
  MonthlyPayrollRecord,
  PrepaymentRecord,
  PrepaymentScheduleLine,
  PurchaseOrder,
  SalesInvoice,
  StockItem,
  TaxScheduleEntry,
} from "../types/accounting";
import { Badge, Card, PageHeader, Stat, formatGHS, numCls, rowCls, tdCls, thCls } from "./ui";
import { downloadCsv } from "./DeskKit";
import { localToday } from "../utils/periods";
import { taxConfigStore } from "../utils/taxConfig";
import { persistentStorage } from "../utils/persistentStorage";
import {
  controlAccountSummary,
  reconcileControlAccounts,
  type ControlAccountReco,
} from "../utils/controlAccounts";
import { CheckCircle2, Scale, AlertTriangle } from "lucide-react";

interface Props {
  currentClient: ClientEntity;
  lines: ACDOCALine[];
  invoices: SalesInvoice[];
  orders: PurchaseOrder[];
  stockItems: StockItem[];
  bankAccounts: BankAccount[];
  assets: FixedAsset[];
  onNavigate?: (section: string) => void;
}

/**
 * Control Accounts & Sub-Ledger Reconciliation desk.
 *
 * For every balance that lives in a subsidiary ledger or operational register,
 * this desk computes the register total and the general-ledger control balance
 * from the posted journal (minor-unit exact) and compares them to the pesewa.
 * A red row is a reconciling item that must be investigated; the Month-End
 * close checklist refuses a clean close while any control is out of balance.
 */
export function ControlAccountsDesk({ currentClient, lines, invoices, orders, stockItems, bankAccounts, assets, onNavigate }: Props) {
  const [expanded, setExpanded] = useState<string | null>(null);
  const [asOf, setAsOf] = useState(() => localToday());

  const rows = useMemo<ControlAccountReco[]>(() => {
    const rates = {
      vat: taxConfigStore.rate("VAT"),
      nhil: taxConfigStore.rate("NHIL"),
      getfund: taxConfigStore.rate("GETFUND"),
      covid: taxConfigStore.rate("COVID"),
    };
    return reconcileControlAccounts({
      clientId: currentClient.id,
      lines,
      invoices,
      orders,
      stockItems,
      bankAccounts,
      assets,
      prepayments: persistentStorage.getPrepayments(),
      prepaymentSchedules: persistentStorage.getPrepaymentSchedules(),
      payrollRecords: persistentStorage.getPayrollRecords(),
      partners: persistentStorage.getBusinessPartners(),
      taxEntries: persistentStorage.getTaxScheduleEntries(),
      vatRates: rates,
      asOf,
    });
  }, [currentClient.id, lines, invoices, orders, stockItems, bankAccounts, assets, asOf]);

  const summary = useMemo(() => controlAccountSummary(rows), [rows]);
  const activeRows = rows.filter((r) => r.status !== "clear");
  const exceptions = activeRows.filter((r) => r.status === "out");
  const worst = exceptions.reduce((m, r) => Math.max(m, Math.abs(r.difference)), 0);

  const moduleFor = (key: string): string | null => {
    if (key.startsWith("inventory")) return "inventory";
    if (key.startsWith("treasury")) return "banking";
    if (key === "receivables" || key === "wht_receivable" || key === "ecl_allowance") return "ageing";
    if (key === "payables") return "procurement";
    if (key === "accrued_expenses") return "payment_desk";
    if (key === "net_salaries") return "payment_desk";
    if (key === "vat_net" || key === "wht_payable") return "tax_schedule";
    if (key.startsWith("ppe")) return "assets";
    if (key === "prepayments") return "prepayments";
    return null;
  };

  const exportRows: (string | number)[][] = [
    [`${currentClient.name} (${currentClient.code}) — Control account reconciliation as at ${asOf}`],
    ["GL account(s)", "Control", "Side", "GL balance", "Sub-ledger", "Difference", "Status", "IFRS basis"],
    ...activeRows.map((r) => [
      r.accountNo,
      r.accountName,
      r.side === "dr" ? "Asset" : "Liability",
      r.gl,
      r.subLedger,
      r.difference,
      r.status === "reconciled" ? "Reconciled" : "OUT OF BALANCE",
      r.basis,
    ]),
  ];

  return (
    <div className="space-y-5">
      <PageHeader
        kicker={`REC · Control Accounts · ${currentClient.code}`}
        title="Control Accounts & Sub-Ledger Reconciliation"
        desc="Every control account in the general ledger is reconciled to its subsidiary ledger or operational register — receivables, payables, inventory, treasury, PPE, prepayments, payroll, VAT, WHT and the IFRS 9 credit-loss allowance — computed from posted journals and live registers, to the pesewa."
      >
        <label className="text-[11px] font-bold text-[#355875]">
          As of
          <input type="date" value={asOf} max={localToday()} onChange={(e) => setAsOf(e.target.value)} className="ml-2 rounded-lg border border-sky-300 bg-white px-2 py-1.5 text-xs font-semibold text-[#082f4f]" />
        </label>
        <button onClick={() => downloadCsv(`${currentClient.code}_control_accounts_${asOf}.csv`, exportRows)} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">
          Export CSV
        </button>
      </PageHeader>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Controls monitored" value={activeRows.length} sub={`General ledger vs sub-ledgers as at ${asOf}`} />
        <Stat label="Reconciled" value={summary.reconciled} sub="No reconciling difference" tone="text-emerald-700" />
        <Stat
          label="Out of balance"
          value={summary.outOfBalance}
          sub={summary.outOfBalance ? `Largest difference GH₵ ${formatGHS(worst)}` : "Month-End close passes the control gate"}
          tone={summary.outOfBalance ? "text-[#b42318]" : "text-emerald-700"}
        />
        <Stat label="Inactive (nil both sides)" value={summary.clear} sub="No balances to reconcile" />
      </div>

      {summary.outOfBalance === 0 ? (
        <div className="flex items-center gap-2 rounded-xl border border-emerald-300 bg-emerald-50 p-3.5 text-xs font-bold text-emerald-900">
          <CheckCircle2 className="h-5 w-5 text-emerald-700" />
          Every control account agrees with its sub-ledger as at {asOf}. The Month-End close control gate is satisfied.
        </div>
      ) : (
        <div role="alert" className="flex items-start gap-2 rounded-xl border border-rose-300 bg-rose-50 p-3.5 text-xs font-bold text-rose-900">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-rose-700" />
          <div>
            {exceptions.length} control account{exceptions.length === 1 ? " is" : "s are"} out of balance. Investigate each reconciling item below, then post the correcting document through the module the row links to. The Month-End close remains gated until these clear (owner override excepted).
          </div>
        </div>
      )}

      <Card title="Reconciliation matrix" sub="GL control balance (posted journals) vs live sub-ledger register — expand a row to see the documents behind it">
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[960px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>GL account(s)</th>
                <th className={thCls}>Control</th>
                <th className={thCls}>IFRS / statutory basis</th>
                <th className={thCls + " text-right"}>GL balance (₵)</th>
                <th className={thCls + " text-right"}>Sub-ledger (₵)</th>
                <th className={thCls + " text-right"}>Difference (₵)</th>
                <th className={thCls}>Status</th>
                {onNavigate && <th className={thCls}>Fix at</th>}
              </tr>
            </thead>
            <tbody>
              {activeRows.map((r) => {
                const out = r.status === "out";
                const open = expanded === r.key;
                const target = moduleFor(r.key);
                return [
                  <tr key={r.key} onClick={() => setExpanded(open ? null : r.key)} className={`${rowCls} cursor-pointer ${out ? "bg-rose-50/60" : ""}`}>
                    <td className={tdCls}><span className="font-mono font-bold text-[#855b00]">{r.accountNo}</span></td>
                    <td className={tdCls}><span className="font-bold text-[#082f4f]">{r.accountName}</span></td>
                    <td className={tdCls}><span className="text-[#355875]">{r.basis}</span></td>
                    <td className={numCls}>{formatGHS(r.gl)}</td>
                    <td className={numCls}>{formatGHS(r.subLedger)}</td>
                    <td className={numCls + (out ? " font-black text-rose-700" : " text-emerald-700")}>
                      {r.difference > 0 ? "+" : ""}{formatGHS(r.difference)}
                    </td>
                    <td className={tdCls}>
                      {out ? <Badge tone="red">RECONCILING ITEM</Badge> : <Badge tone="green">Reconciled</Badge>}
                    </td>
                    {onNavigate && (
                      <td className={tdCls}>
                        {target && (
                          <button
                            onClick={(e) => { e.stopPropagation(); onNavigate(target); }}
                            className="rounded-lg bg-[#082f4f] px-2 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68]"
                          >
                            Open →
                          </button>
                        )}
                      </td>
                    )}
                  </tr>,
                  open && (
                    <tr key={`${r.key}-detail`} className="bg-sky-50/40">
                      <td colSpan={onNavigate ? 8 : 7} className="px-4 py-3">
                        <div className="space-y-2">
                          <div className="text-[11px] font-bold text-[#082f4f]">How to clear this difference: <span className="font-semibold text-[#2d4f6d]">{r.resolution}</span></div>
                          {r.subItems.length > 0 ? (
                            <div className="grid grid-cols-1 gap-1 sm:grid-cols-2 lg:grid-cols-3">
                              {r.subItems.map((s, i) => (
                                <div key={i} className="flex items-center justify-between rounded-lg border border-sky-200 bg-white px-2.5 py-1.5 text-[11px]">
                                  <span className="truncate font-semibold text-[#0a253e]">{s.label}</span>
                                  <span className="ml-2 shrink-0 font-mono font-bold text-[#082f4f]">₵{formatGHS(s.amount)}</span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-[11px] text-[#355875]">No live register items — the balance sits in opening or manual journals. Post the matching document or reverse the manual entry.</p>
                          )}
                        </div>
                      </td>
                    </tr>
                  ),
                ];
              })}
            </tbody>
          </table>
        </div>
      </Card>

      <Card title="Why control accounts exist (audit significance)" sub="The control structure protects the integrity of the entire workspace">
        <div className="grid gap-3 text-xs text-[#2d4f6d] lg:grid-cols-3">
          <div className="rounded-xl border border-sky-200 bg-sky-50/60 p-3">
            <div className="mb-1 flex items-center gap-1.5 font-bold text-[#082f4f]"><Scale className="h-4 w-4 text-[#006f98]" /> Completeness</div>
            A document that never posts (dropped invoice, reversed receipt, unposted stock movement) shows up immediately as a control difference rather than silently distorting the statement of financial position.
          </div>
          <div className="rounded-xl border border-sky-200 bg-sky-50/60 p-3">
            <div className="mb-1 flex items-center gap-1.5 font-bold text-[#082f4f]"><Scale className="h-4 w-4 text-[#006f98]" /> No double counting</div>
            Registers aggregate documents; the journal records value once. Reconciling them periodically means the Trade Receivables, Inventories and Trade Payables in the IFRS statements are defensible balances.
          </div>
          <div className="rounded-xl border border-sky-200 bg-sky-50/60 p-3">
            <div className="mb-1 flex items-center gap-1.5 font-bold text-[#082f4f]"><Scale className="h-4 w-4 text-[#006f98]" /> Month-end discipline</div>
            The Month-End Close checklist contains a control-account gate: a period should not be frozen while any control is out of balance, exactly as an external auditor would require.
          </div>
        </div>
      </Card>
    </div>
  );
}
