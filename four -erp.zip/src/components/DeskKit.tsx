"use client";

import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { apiFetch } from "../utils/session";
import { cn } from "./ui";

export type DeskName = "hr" | "crm" | "store" | "production" | "projects" | "finance";

export interface DeskRecord {
  id: string;
  [key: string]: unknown;
}

export function useDeskRecords<T extends DeskRecord>(desk: DeskName, clientId: number, kind: string) {
  const [records, setRecords] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const reload = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch(`/api/desk?desk=${desk}&kind=${kind}&clientId=${clientId}`);
      const body = await res.json().catch(() => null);
      if (!res.ok || !body?.ok) throw new Error(body?.error || "Unable to load this desk.");
      setRecords((body.records ?? []) as T[]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to load this desk.");
    } finally {
      setLoading(false);
    }
  }, [desk, kind, clientId]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void reload();
    }, 0);
    return () => window.clearTimeout(timer);
  }, [reload]);

  const save = useCallback(
    async (record: Partial<T>): Promise<T | null> => {
      setSaving(true);
      setError(null);
      try {
        const res = await apiFetch("/api/desk", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ desk, kind, clientId, id: record.id, record }),
        });
        const body = await res.json().catch(() => null);
        if (!res.ok || !body?.ok) throw new Error(body?.error || "The record could not be saved.");
        const saved = { ...(record as T), id: body.id as string };
        setRecords((prev) => {
          const exists = prev.some((r) => r.id === saved.id);
          return exists ? prev.map((r) => (r.id === saved.id ? saved : r)) : [...prev, saved];
        });
        return saved;
      } catch (e) {
        setError(e instanceof Error ? e.message : "The record could not be saved.");
        return null;
      } finally {
        setSaving(false);
      }
    },
    [desk, kind, clientId]
  );

  const remove = useCallback(
    async (id: string): Promise<boolean> => {
      setSaving(true);
      setError(null);
      try {
        const res = await apiFetch(`/api/desk?desk=${desk}&kind=${kind}&clientId=${clientId}&id=${encodeURIComponent(id)}`, {
          method: "DELETE",
        });
        const body = await res.json().catch(() => null);
        if (!res.ok || !body?.ok) throw new Error(body?.error || "The record could not be deleted.");
        setRecords((prev) => prev.filter((r) => r.id !== id));
        return true;
      } catch (e) {
        setError(e instanceof Error ? e.message : "The record could not be deleted.");
        return false;
      } finally {
        setSaving(false);
      }
    },
    [desk, kind, clientId]
  );

  return { records, loading, error, saving, reload, save, remove, setError };
}

export function DeskTabs({
  tabs,
  active,
  onChange,
}: {
  tabs: { id: string; label: string; badge?: string | number }[];
  active: string;
  onChange: (id: string) => void;
}) {
  return (
    <div role="tablist" aria-label="Desk sections" className="mb-4 flex gap-1 overflow-x-auto rounded-xl border border-sky-200 bg-[#eef6fc] p-1">
      {tabs.map((t) => (
        <button
          key={t.id}
          role="tab"
          aria-selected={active === t.id}
          onClick={() => onChange(t.id)}
          className={cn(
            "flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition",
            active === t.id ? "bg-[#082f4f] text-white shadow-sm" : "text-[#163653] hover:bg-sky-200/70"
          )}
        >
          {t.label}
          {t.badge !== undefined && t.badge !== 0 && t.badge !== "" && (
            <span className={cn("rounded px-1 font-mono text-[10px]", active === t.id ? "bg-white/20 text-white" : "bg-sky-200 text-[#082f4f]")}>
              {t.badge}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}

export const inputCls =
  "w-full rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-[#082f4f] outline-none focus:border-[#082f4f] focus:ring-1 focus:ring-sky-300";

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[10px] font-bold uppercase tracking-wider text-[#355875]">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[10px] text-[#355875]">{hint}</span>}
    </label>
  );
}

export function EmptyState({ title, detail }: { title: string; detail: string }) {
  return (
    <div className="rounded-xl border border-dashed border-sky-300 bg-sky-50/50 px-4 py-8 text-center">
      <p className="text-xs font-bold text-[#082f4f]">{title}</p>
      <p className="mt-1 text-xs text-[#355875]">{detail}</p>
    </div>
  );
}

export function Alert({ tone = "error", children }: { tone?: "error" | "info" | "success"; children: ReactNode }) {
  const tones = {
    error: "border-rose-300 bg-rose-50 text-rose-900",
    info: "border-sky-300 bg-sky-50 text-[#0a253e]",
    success: "border-emerald-300 bg-emerald-50 text-emerald-900",
  } as const;
  return <div role={tone === "error" ? "alert" : "status"} className={cn("mb-3 rounded-lg border px-3 py-2 text-xs font-semibold", tones[tone])}>{children}</div>;
}

export function useMoney() {
  return useMemo(
    () => ({
      fmt: (n: number) => new Intl.NumberFormat("en-GH", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number.isFinite(n) ? n : 0),
      today: () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); },
    }),
    []
  );
}

export function downloadCsv(filename: string, rows: (string | number)[][]) {
  // Neutralise spreadsheet formula injection (OWASP CSV injection).
  const safe = (v: string | number) => {
    const s = String(v ?? "");
    return /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
  };
  const csv = rows.map((r) => r.map((v) => `"${safe(v).replace(/"/g, '""')}"`).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/**
 * Sends a document by e-mail through the server channel. If SMTP is not
 * configured (or dispatch fails), the device mail client opens instead so the
 * document can never get stranded. Returns how it went out.
 */
export async function deliverEmail(opts: {
  clientId: number;
  to: string;
  subject: string;
  body: string;
  ref?: string;
}): Promise<{ status: "sent" | "queued" | "fallback"; message: string }> {
  const mailto = () => {
    window.location.href = `mailto:${encodeURIComponent(opts.to)}?subject=${encodeURIComponent(opts.subject)}&body=${encodeURIComponent(opts.body)}`;
  };
  try {
    const res = await apiFetch("/api/mail", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ clientId: opts.clientId, to: opts.to, subject: opts.subject, body: opts.body, ref: opts.ref }),
    });
    const data = await res.json().catch(() => null);
    if (res.ok && data?.ok && data.status === "sent") {
      return { status: "sent", message: `Sent to ${opts.to} via the mail server.` };
    }
    if (res.ok && data?.ok && data.status === "queued") {
      mailto();
      return { status: "queued", message: "Mail server not configured — opened your mail client; the dispatch is logged." };
    }
  } catch {
    /* fall through to mailto */
  }
  mailto();
  return { status: "fallback", message: "Opened your mail client to send the document." };
}

