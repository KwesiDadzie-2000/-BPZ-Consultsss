import React, { useMemo, useRef, useState } from 'react';
import type { ClientEntity, ACDOCALine, UserAccount, BankAccount, AccountMaster } from '../types/accounting';
import type { PaymentMethod } from '../utils/treasury';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls, Badge } from './ui';
import { Plus, CheckCircle, Download, Printer, Banknote, FileClock } from 'lucide-react';
import { nextDocNo, uniqueId } from '../utils/ids';
import { downloadCsv } from '../utils/printReport';
import { printModuleView } from '../utils/printModuleView';
import { localToday } from '../utils/periods';
import { useDeskRecords, type DeskRecord } from './DeskKit';
import {
  generateAmortisationSchedule,
  type AmortisationRow,
  type LoanFacility,
  type FacilityType,
} from '../utils/loans';

export type DebtServiceMode = 'pay' | 'accrue';

export interface DebtServiceRequest {
  facility: LoanFacility;
  row: AmortisationRow;
  mode: DebtServiceMode;
  bankId?: number;
  method?: PaymentMethod;
}

interface LoansAmortisationDeskProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  bankAccounts: BankAccount[];
  accounts?: AccountMaster[];
  isPeriodClosed?: boolean;
  /** Posts the debt service journal; 'pay' also settles treasury. Returns posted/queued/failed. */
  onPostDebtService: (req: DebtServiceRequest) => 'posted' | 'queued' | 'failed' | boolean;
  /** Books the borrowing: Dr treasury GL / Cr 250000. Returns false when refused. */
  onPostDrawdown?: (facility: LoanFacility, bankId: number) => boolean;
  onNavigate?: (section: string) => void;
}

export const LoansAmortisationDesk: React.FC<LoansAmortisationDeskProps> = ({
  currentClient,
  currentUser,
  lines,
  bankAccounts,
  accounts,
  isPeriodClosed = false,
  onPostDebtService,
  onPostDrawdown,
  onNavigate,
}) => {
  // Facilities are persisted per entity on the server (audited desk API) — they
  // used to be hard-coded component state shown in EVERY entity and lost on reload.
  const facilityStore = useDeskRecords<LoanFacility & DeskRecord>('finance', currentClient.id, 'loan_facility');
  const facilities: LoanFacility[] = facilityStore.records
    .map((f) => ({ ...f, principal: Number(f.principal) || 0, annualRatePct: Number(f.annualRatePct) || 0, termMonths: Number(f.termMonths) || 1 }))
    .sort((a, b) => a.code.localeCompare(b.code));

  const [pickedFacilityId, setSelectedFacilityId] = useState<string>('');
  const selectedFacilityId = pickedFacilityId || facilities[0]?.id || '';
  const [drawBankId, setDrawBankId] = useState<number>(bankAccounts[0]?.id ?? 0);
  const [postDrawdown, setPostDrawdown] = useState(true);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [showFullTerm, setShowFullTerm] = useState(false);
  // Debt-service decision state — pay now (treasury) or accrue as payable.
  const [decision, setDecision] = useState<{ row: AmortisationRow } | null>(null);
  const [payBankId, setPayBankId] = useState<number>(bankAccounts[0]?.id ?? 0);
  const [payMethod, setPayMethod] = useState<PaymentMethod>('bank_transfer');
  const scheduleRef = useRef<HTMLDivElement | null>(null);

  // New facility form
  const [showNewModal, setShowNewModal] = useState(false);
  const [fName, setFName] = useState('Working Capital Overdraft Line');
  const [fLender, setFLender] = useState('Absa Bank Ghana');
  const [fPrincipal, setFPrincipal] = useState(500000);
  const [fRate, setFRate] = useState(22.0);
  const [fTerm, setFTerm] = useState(24);
  const [fType, setFType] = useState<FacilityType>('amortising');

  const selectedFacility = facilities.find((f) => f.id === selectedFacilityId) || facilities[0];
  const entityLines = useMemo(() => lines.filter((l) => l.clientId === currentClient.id), [lines, currentClient.id]);

  const fullSchedule = selectedFacility ? generateAmortisationSchedule(selectedFacility) : [];
  const scheduleRows = showFullTerm ? fullSchedule : fullSchedule.slice(0, 24);

  /** Posting status of an instalment, derived from the posted journal. */
  const rowStatus = (row: AmortisationRow): 'posted' | 'accrued' | 'open' => {
    const payDoc = `LOAN-PMT-${selectedFacility!.code}-M${row.periodNum}`;
    const accDoc = `EXPB-LOAN-${selectedFacility!.code}-M${row.periodNum}`;
    if (entityLines.some((l) => l.docNo === payDoc && !l.isReversed)) return 'posted';
    if (entityLines.some((l) => l.docNo === accDoc && !l.isReversed)) return 'accrued';
    return 'open';
  };

  const paidToDate = selectedFacility ? entityLines.filter((l) => l.docNo.startsWith(`LOAN-PMT-${selectedFacility.code}-`) || l.docNo.startsWith(`EXPB-LOAN-${selectedFacility.code}-`)).length / 3 : 0;

  const openDecision = (row: AmortisationRow) => setDecision({ row });
  const submitDecision = (mode: DebtServiceMode) => {
    if (!decision || !selectedFacility) return;
    if (isPeriodClosed) { setActionSuccess(`Cannot post: the current period is closed for ${currentClient.code}.`); setTimeout(() => setActionSuccess(null), 5000); return; }
    const result = onPostDebtService({ facility: selectedFacility, row: decision.row, mode, bankId: payBankId, method: payMethod });
    if (result === 'posted' || result === true) {
      setActionSuccess(
        mode === 'pay'
          ? `Instalment M${decision.row.periodNum} PAID and posted: ₵${formatGHS(decision.row.totalPayment)} left the treasury account (principal ₵${formatGHS(decision.row.principalPayment)} + interest ₵${formatGHS(decision.row.interestExpense)}).`
          : `Instalment M${decision.row.periodNum} ACCRUED as payable: ₵${formatGHS(decision.row.totalPayment)} moved from the loan to accrued payables (202000). It now ages in Payables and settles from the Payment Desk.`
      );
    } else if (result === 'queued') {
      setActionSuccess(`Instalment M${decision.row.periodNum} is above your maker limit and was routed to the approvals queue; it posts on independent approval.`);
    } else {
      setActionSuccess('The journal controls refused this posting (closed period, authority or duplicate instalment). Nothing was posted.');
    }
    setTimeout(() => setActionSuccess(null), 7000);
    setDecision(null);
  };

  /** CSV the entity can open directly in Excel. */
  const exportSchedule = (facility: LoanFacility, rows: AmortisationRow[]) => {
    const totalInterest = rows.reduce((s, r) => s + r.interestExpense, 0);
    downloadCsv(`${currentClient.code}_${facility.code}_amortisation.csv`, [
      [`${currentClient.name} (${currentClient.code})`],
      [`Amortisation schedule — ${facility.facilityName}`],
      [`Lender: ${facility.lender} · Principal: ₵${formatGHS(facility.principal)} · Rate: ${facility.annualRatePct}% p.a. · Type: ${facility.facilityType} · Term: ${facility.termMonths} months`],
      [],
      ['Period', 'Payment date', 'Opening principal', 'Interest charge', 'Principal repaid', 'Total instalment', 'Closing principal', 'Status'],
      ...rows.map((r) => [`M${r.periodNum}`, r.date, r.openingBalance, r.interestExpense, r.principalPayment, r.totalPayment, r.closingBalance,
        rowStatus(r) === 'posted' ? 'Paid' : rowStatus(r) === 'accrued' ? 'Accrued (payable)' : 'Unpaid due']),
      ['', 'TOTAL', '', totalInterest.toFixed(2), rows.reduce((s, r) => s + r.principalPayment, 0).toFixed(2), rows.reduce((s, r) => s + r.totalPayment, 0).toFixed(2), ''],
    ]);
  };

  const handleCreateFacility = async (e: React.FormEvent) => {
    e.preventDefault();
    const newF: LoanFacility = {
      id: uniqueId(`LN-${currentClient.id}`),
      code: nextDocNo(`LN-${fLender.replace(/[^A-Za-z]/g, '').substring(0, 3).toUpperCase() || 'FAC'}`, facilities.map((f) => f.code), 3),
      facilityName: fName, lender: fLender, principal: fPrincipal, annualRatePct: fRate, termMonths: fTerm,
      frequency: 'monthly', facilityType: fType, arrangementFee: Math.round(fPrincipal * 0.015 * 100) / 100,
      startDate: localToday(), status: 'Active',
    };
    // Book the borrowing first: a facility with no liability in the ledger is a
    // misstatement (IFRS 9 — the loan is recognised when the cash is received).
    if (postDrawdown) {
      const ok = onPostDrawdown?.(newF, drawBankId);
      if (!ok) { setActionSuccess(`Facility not registered: the drawdown journal for ${newF.code} was refused (closed period, authority or bank currency).`); return; }
    }
    const saved = await facilityStore.save({ ...newF } as LoanFacility & DeskRecord);
    if (!saved) { setActionSuccess('The facility could not be saved on the server.'); return; }
    setSelectedFacilityId(newF.id);
    setShowNewModal(false);
    setActionSuccess(`Registered ${newF.code}${postDrawdown ? ` and posted the drawdown (Dr bank / Cr 250000 Borrowings ₵${formatGHS(newF.principal)})` : ''}. Amortisation schedule computed.`);
    setTimeout(() => setActionSuccess(null), 6000);
  };

  const treasuryAccounts = (accounts ?? []).filter((a) => a.accountNo.startsWith('10'));
  void treasuryAccounts;

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`FIN · BORROWINGS & LOAN AMORTISATION · ${currentClient.code}`}
        title="Loan Facilities & Amortisation Schedules (IFRS 9 & IAS 23)"
        desc="Borrowing facilities with exact two-decimal amortisation schedules (annuity, interest-only, bullet). Every instalment is either PAID out of treasury or ACCRUED as a payable — never silently dropped."
      >
        {selectedFacility && (
          <>
            <button
              onClick={() => exportSchedule(selectedFacility, fullSchedule)}
              className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"
            >
              <Download className="h-4 w-4" />
              <span>Export Excel (CSV)</span>
            </button>
            <button
              onClick={() => printModuleView({ title: `Amortisation Schedule — ${selectedFacility.facilityName}`, subtitle: `${selectedFacility.lender} · ${selectedFacility.principal.toLocaleString()} @ ${selectedFacility.annualRatePct}% p.a. · ${currentClient.name}`, root: scheduleRef.current, orientation: 'landscape' })}
              className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"
            >
              <Printer className="h-4 w-4" />
              <span>Print this schedule</span>
            </button>
          </>
        )}
        <button
          onClick={() => setShowNewModal(true)}
          className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
        >
          <Plus className="h-4 w-4" />
          <span>New Borrowing Facility</span>
        </button>
      </PageHeader>

      {actionSuccess && (
        <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-xs font-bold text-emerald-900 flex items-center gap-2 shadow-xs">
          <CheckCircle className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* Facility Selector Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {facilities.length === 0 && (
          <div className="col-span-full rounded-xl border border-dashed border-sky-300 bg-sky-50/50 px-4 py-8 text-center text-xs text-[#355875]">
            {facilityStore.loading ? 'Loading borrowing facilities from the server…' : <>No borrowing facilities registered for <strong>{currentClient.name}</strong>. Use <strong>New Borrowing Facility</strong> to register one — its drawdown is booked to the ledger and its schedule is computed to the pesewa.</>}
          </div>
        )}
        {facilities.map((f) => {
          const isSelected = f.id === selectedFacilityId;
          return (
            <div
              key={f.id}
              onClick={() => setSelectedFacilityId(f.id)}
              className={`cursor-pointer rounded-xl border p-4 transition shadow-xs ${
                isSelected ? 'border-[#082f4f] bg-sky-50 ring-1 ring-[#082f4f]' : 'border-sky-200 bg-white hover:bg-sky-50/50'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-mono text-[#355875]">
                <span className="font-bold text-[#855b00]">{f.code}</span>
                <span className="rounded bg-sky-100 px-1.5 py-0.5 text-[10px] text-[#006f98] font-bold">{f.facilityType.toUpperCase()}</span>
              </div>
              <h4 className="text-sm font-bold text-[#082f4f] mt-1">{f.facilityName}</h4>
              <div className="text-xs text-[#2d4f6d]">{f.lender} · {f.termMonths} Months</div>
              <div className="mt-3 flex items-center justify-between border-t border-sky-200 pt-2 text-xs font-mono">
                <span className="text-[#355875]">Principal:</span>
                <span className="font-bold text-[#082f4f]">₵{formatGHS(f.principal)}</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#355875]">Rate:</span>
                <span className="font-bold text-[#855b00]">{f.annualRatePct}% p.a.</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Schedule Table */}
      {selectedFacility && (
        <Card
          title={`Amortisation Schedule — ${selectedFacility.facilityName}`}
          sub={`Principal: ₵${formatGHS(selectedFacility.principal)} · Annual Rate: ${selectedFacility.annualRatePct}% · Method: ${selectedFacility.facilityType} · ${Math.round(paidToDate)} instalment(s) already recorded in the ledger`}
          action={
            fullSchedule.length > 24 ? (
              <button onClick={() => setShowFullTerm((v) => !v)} className="rounded border border-sky-300 bg-white px-2.5 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">
                {showFullTerm ? 'Show first 24 periods' : `Show all ${fullSchedule.length} periods`}
              </button>
            ) : undefined
          }
        >
          <div className="overflow-x-auto" ref={scheduleRef}>
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-sky-200 bg-sky-50/70">
                  <th className={thCls + ' text-center'}>Period</th>
                  <th className={thCls}>Payment Date</th>
                  <th className={thCls + ' text-right'}>Opening Principal (₵)</th>
                  <th className={thCls + ' text-right'}>Interest Charge (₵)</th>
                  <th className={thCls + ' text-right'}>Principal Repaid (₵)</th>
                  <th className={thCls + ' text-right'}>Total Instalment (₵)</th>
                  <th className={thCls + ' text-right'}>Closing Principal (₵)</th>
                  <th className={thCls + ' text-center'} data-print-hide>Status</th>
                  <th className={thCls + ' text-center'} data-print-hide>Accounting Action</th>
                </tr>
              </thead>
              <tbody>
                {scheduleRows.map((r) => {
                  const st = rowStatus(r);
                  return (
                    <tr key={r.periodNum} className={rowCls}>
                      <td className="px-3 py-2 text-center font-mono font-bold text-[#855b00]">M{r.periodNum}</td>
                      <td className="px-3 py-2 font-mono text-[#355875]">{r.date}</td>
                      <td className={numCls}>{formatGHS(r.openingBalance)}</td>
                      <td className={numCls + ' text-rose-700 font-bold'}>₵{formatGHS(r.interestExpense)}</td>
                      <td className={numCls + ' text-[#006f98] font-bold'}>₵{formatGHS(r.principalPayment)}</td>
                      <td className={numCls + ' font-black text-[#082f4f]'}>₵{formatGHS(r.totalPayment)}</td>
                      <td className={numCls + ' font-bold text-emerald-800'}>₵{formatGHS(r.closingBalance)}</td>
                      <td className="px-3 py-2 text-center" data-print-hide>
                        {st === 'posted' ? <Badge tone="green">Paid · ledger</Badge> : st === 'accrued' ? <Badge tone="amber">Accrued — payable</Badge> : <Badge tone="slate">Open</Badge>}
                      </td>
                      <td className="px-3 py-2 text-center" data-print-hide>
                        {st === 'open' ? (
                          <button
                            onClick={() => openDecision(r)}
                            disabled={isPeriodClosed}
                            className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] transition disabled:opacity-40"
                          >
                            Post Debt Service
                          </button>
                        ) : st === 'accrued' ? (
                          onNavigate ? (
                            <button onClick={() => onNavigate('payment_desk')} className="rounded border border-amber-400 bg-amber-50 px-2.5 py-1 text-[11px] font-bold text-[#855b00] hover:bg-amber-100">
                              Settle at Payment Desk →
                            </button>
                          ) : (
                            <span className="text-[11px] font-bold text-[#855b00]">At Payment Desk</span>
                          )
                        ) : (
                          <span className="text-[11px] font-bold text-emerald-700">Posted to ACDOCA</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Debt-service decision modal: PAY out of treasury now, or ACCRUE as payable */}
      {decision && selectedFacility && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-lg rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">
              Debt service decision — {selectedFacility.code}, instalment M{decision.row.periodNum}
            </h3>
            <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
              <div className="rounded-lg bg-sky-50 p-2"><div className="text-[#355875]">Instalment</div><div className="font-black text-[#082f4f]">₵{formatGHS(decision.row.totalPayment)}</div></div>
              <div className="rounded-lg bg-sky-50 p-2"><div className="text-[#355875]">Interest</div><div className="font-bold text-rose-700">₵{formatGHS(decision.row.interestExpense)}</div></div>
              <div className="rounded-lg bg-sky-50 p-2"><div className="text-[#355875]">Principal</div><div className="font-bold text-[#006f98]">₵{formatGHS(decision.row.principalPayment)}</div></div>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="rounded-xl border border-emerald-300 bg-emerald-50/60 p-3 space-y-3">
                <div className="flex items-center gap-1.5 font-bold text-emerald-900 text-xs"><Banknote className="h-4 w-4" /> Pay now — settle from treasury</div>
                <label className="block text-[11px] font-bold text-[#355875]">Treasury record
                  <select value={payBankId} onChange={(e) => setPayBankId(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 bg-white px-2 py-1.5 text-xs font-semibold text-[#082f4f]">
                    {bankAccounts.filter((b) => b.currency === currentClient.currency).map((b) => (
                      <option key={b.id} value={b.id}>{b.name} · {b.currency} {formatGHS(b.balance)}</option>
                    ))}
                  </select>
                </label>
                <label className="block text-[11px] font-bold text-[#355875]">Method
                  <select value={payMethod} onChange={(e) => setPayMethod(e.target.value as PaymentMethod)} className="mt-1 block w-full rounded border border-sky-300 bg-white px-2 py-1.5 text-xs font-semibold text-[#082f4f]">
                    <option value="bank_transfer">Bank transfer</option><option value="cheque">Cheque</option><option value="cash">Cash</option><option value="mobile_money">Mobile money</option>
                  </select>
                </label>
                <button onClick={() => submitDecision('pay')} className="w-full rounded-lg bg-emerald-700 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-800">
                  Pay & post ({selectedFacility.code} instalment M{decision.row.periodNum})
                </button>
              </div>
              <div className="rounded-xl border border-amber-300 bg-amber-50/60 p-3 space-y-3">
                <div className="flex items-center gap-1.5 font-bold text-amber-900 text-xs"><FileClock className="h-4 w-4" /> Accrue — record the liability, pay later</div>
                <p className="text-[11px] text-[#2d4f6d] leading-relaxed">
                  The contractual instalment is released from the loan into <strong>Accrued Expenses & Payables (202000)</strong>: interest charges to the P&amp;L, principal reclasses out of <strong>250000</strong>. The payable ages in AP &amp; Expense Bills and is settled from the <strong>Payment Desk</strong>.
                </p>
                <button onClick={() => submitDecision('accrue')} className="w-full rounded-lg bg-amber-700 px-3 py-2 text-xs font-bold text-white hover:bg-amber-800">
                  Create payable (accrual)
                </button>
              </div>
            </div>
            <div className="flex justify-end pt-2 border-t border-sky-100">
              <button onClick={() => setDecision(null)} className="rounded px-3 py-1.5 text-xs font-semibold text-[#2d4f6d] hover:bg-sky-50">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* New Facility Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleCreateFacility} className="w-full max-w-lg rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Register Borrowing Facility</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Facility Name / Purpose</label>
                <input type="text" value={fName} onChange={(e) => setFName(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none" required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Lending Financial Institution</label>
                  <input type="text" value={fLender} onChange={(e) => setFLender(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none" required />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Facility Type</label>
                  <select value={fType} onChange={(e) => setFType(e.target.value as any)} className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none">
                    <option value="amortising">Amortising (Annuity Equal Payments)</option>
                    <option value="interest_only">Interest-Only (Bullet Principal)</option>
                    <option value="bullet">Bullet (Interest + Principal at Maturity)</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Principal (₵)</label>
                  <input type="number" min="1000" value={fPrincipal} onChange={(e) => setFPrincipal(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none" required />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Annual Rate (%)</label>
                  <input type="number" step="0.1" value={fRate} onChange={(e) => setFRate(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none" required />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Term (Months)</label>
                  <input type="number" min="1" value={fTerm} onChange={(e) => setFTerm(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none" required />
                </div>
              </div>
              <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-3 space-y-2">
                <label className="flex items-center gap-2 font-bold text-[#082f4f]">
                  <input type="checkbox" checked={postDrawdown} onChange={(e) => setPostDrawdown(e.target.checked)} />
                  Post the drawdown now (Dr bank / Cr 250000 Commercial Borrowings)
                </label>
                {postDrawdown && (
                  <label className="block font-bold text-[#355875]">Proceeds received into
                    <select value={drawBankId} onChange={(e) => setDrawBankId(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 bg-white px-2 py-1.5">
                      {bankAccounts.filter((b) => b.currency === currentClient.currency).map((b) => <option key={b.id} value={b.id}>{b.name} · {b.currency}</option>)}
                    </select>
                  </label>
                )}
                <p className="text-[10.5px] text-[#355875]">Untick only when the loan was already brought in through Opening Balances.</p>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setShowNewModal(false)} className="rounded px-3 py-1.5 text-xs font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 text-xs font-bold text-white">Generate Schedule</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
