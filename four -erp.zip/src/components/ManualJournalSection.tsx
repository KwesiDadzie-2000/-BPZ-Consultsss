import { localToday } from '../utils/periods';
import React, { useEffect, useState } from 'react';
import { ClientEntity, UserAccount, ACDOCALine, AccountMaster, ApprovalRequest } from '../types/accounting';
import { persistentStorage } from '../utils/persistentStorage';
import { apiFetch } from '../utils/session';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { Plus, RotateCcw, AlertCircle, Check, Send, ScrollText } from 'lucide-react';
import { uniqueId, nextDocNo } from '../utils/ids';
import { printReport } from '../utils/printReport';
import { toPrintEntity } from '../utils/printEntity';
import { persistentStorage as profileStore } from '../utils/persistentStorage';
import { Printer } from 'lucide-react';
import { useModalFocus } from '../utils/useModalFocus';

import { currencySymbol, formatMoney, parseAccountOption, POSTABLE_CURRENCIES } from '../utils/currency';

interface ManualJournalSectionProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  /** `docCurrency` is the DOCUMENT currency; it may differ from the entity's functional currency. */
  onAddJournalLines: (lines: ACDOCALine[], docCurrency?: string) => boolean | void;
  /** Last exact posting-control message raised by the workspace, if any. */
  postingNotice?: string | null;
  /** Reverses a posted document into the CURRENT period and flags the original (returns false when blocked). */
  onReverseDocument?: (docNo: string) => boolean;
  isPeriodClosed?: boolean;
  accounts?: AccountMaster[];
  onApprovalSubmitted?: () => void;
}

export const ManualJournalSection: React.FC<ManualJournalSectionProps> = ({
  currentClient,
  currentUser,
  lines,
  onAddJournalLines,
  onReverseDocument,
  isPeriodClosed = false,
  accounts = [],
  onApprovalSubmitted,
  postingNotice = null,
}) => {
  const [auditEvents, setAuditEvents] = useState<{ timestamp: string; username: string; action: string; target: string; details: string; clientId: number | null }[]>([]);

  const clientLines = lines.filter((l) => l.clientId === currentClient.id);
  const reversedDocNos = new Set(
    clientLines.filter((l) => l.docType === 'REV').map((l) => (l.reference || l.docNo.replace(/^REV-/, '')))
  );

  const refreshAuditTrail = () => {
    apiFetch('/api/audit')
      .then((r) => (r.ok ? r.json() : null))
      .then((b) => {
        if (b?.ok && Array.isArray(b.events)) {
          setAuditEvents(b.events.filter((e: { clientId: number | null }) => e.clientId === currentClient.id).slice(0, 12));
        }
      })
      .catch(() => {});
  };

  useEffect(() => {
    refreshAuditTrail();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentClient.id, clientLines.length]);

  const [showModal, setShowModal] = useState(false);
  const [docType, setDocType] = useState<'JE' | 'DEP' | 'STAT'>('JE');
  const [postingDate, setPostingDate] = useState(() => localToday());
  const period = postingDate.slice(0, 7);
  const accountLabel = (number: string) => {
    const account = accounts.find((item) => item.accountNo === number && item.active) || accounts.find((item) => item.active);
    return account ? `${account.accountNo} · ${account.name}` : '';
  };
  const [drAccount, setDrAccount] = useState(() => accountLabel('600000'));
  const [crAccount, setCrAccount] = useState(() => accountLabel('100000'));
  // The DOCUMENT currency, not the entity's functional currency: an entity with
  // GBP functional currency still pays GHS suppliers and posts GHS bank entries.
  const [docCurrency, setDocCurrency] = useState<string>(currentClient.currency);
  const [amount, setAmount] = useState(15000);
  const [description, setDescription] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [canSubmitApproval, setCanSubmitApproval] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const modalRef = useModalFocus<HTMLFormElement>(showModal, () => setShowModal(false));

  const isUserRestricted =
    currentUser.status === 'restricted' ||
    currentUser.status === 'suspended' ||
    (currentUser.permissions && currentUser.permissions.canPostJournals === false);

  const handlePostEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (isUserRestricted) {
      setError(
        `Action Blocked: Your posting authority has been restricted by the Firm Owner. ${
          currentUser.restrictionReason ? `(${currentUser.restrictionReason})` : ''
        }`
      );
      setCanSubmitApproval(false);
      return;
    }

    if ((persistentStorage.getClosedPeriods()[currentClient.id] || []).includes(period)) {
      setError('Posting blocked: selected fiscal period is currently closed & frozen by Month-End Close control.');
      setCanSubmitApproval(false);
      return;
    }
    if (!Number.isFinite(amount) || amount <= 0) {
      setError('Amount must be greater than zero.');
      return;
    }
    if (drAccount === crAccount) { setError('Choose different debit and credit accounts.'); return; }
    const drOpt = parseAccountOption(drAccount);
    const crOpt = parseAccountOption(crAccount);
    if (![drOpt, crOpt].every((opt) => accounts.some((account) => account.active && account.accountNo === opt.accountNo))) {
      setError('Select an active debit and credit account from this entity chart.'); return;
    }

    // Maker-limit / foreign-currency gate. A maker limit is expressed in the
    // entity's functional currency and is never translated, so a document in any
    // other currency always needs an independent checker — matching the server.
    const foreignCurrency = docCurrency !== currentClient.currency;
    if (foreignCurrency || (currentUser.makerLimit > 0 && amount > currentUser.makerLimit)) {
      setError(
        foreignCurrency
          ? `${docCurrency} ${formatMoney(amount, docCurrency)} is a foreign-currency entry for an entity reporting in ${currentClient.currency}. Submit it for independent checker approval.`
          : `Posting limit exceeded: this ${docCurrency} entry of ${formatMoney(amount, docCurrency)} needs Partner/Checker review. Your maker threshold is ${formatMoney(currentUser.makerLimit, currentClient.currency)}.`
      );
      setCanSubmitApproval(true);
      return;
    }

    const docNo = nextDocNo(`${docType}-${period}`, lines.filter((l) => l.clientId === currentClient.id).map((l) => l.docNo));
    const today = postingDate;
    const dr = parseAccountOption(drAccount);
    const cr = parseAccountOption(crAccount);

    const drLine: ACDOCALine = {
      id: `${uniqueId('JL')}-1`,
      docNo,
      period,
      date: today,
      module: 'FI',
      docType,
      accountNo: dr.accountNo,
      accountName: dr.accountName,
      costCenter: 'CC-ADM',
      debit: amount,
      credit: 0,
      currency: docCurrency,
      description: description || `Manual journal entry ${docNo}`,
      createdBy: currentUser.username,
      checkedBy: currentUser.canCheck ? currentUser.username : undefined,
      clientId: currentClient.id,
    };

    const crLine: ACDOCALine = {
      id: `${uniqueId('JL')}-2`,
      docNo,
      period,
      date: today,
      module: 'FI',
      docType,
      accountNo: cr.accountNo,
      accountName: cr.accountName,
      costCenter: 'CC-ADM',
      debit: 0,
      credit: amount,
      currency: docCurrency,
      description: description || `Manual journal entry ${docNo}`,
      createdBy: currentUser.username,
      checkedBy: currentUser.canCheck ? currentUser.username : undefined,
      clientId: currentClient.id,
    };

    const ok = onAddJournalLines([drLine, crLine], docCurrency);
    if (ok === false) {
      // Surface the exact refusal — never a guessed cause. The workspace raises the
      // real posting-control reason (closed period, unknown maker, duplicate doc, …).
      setError(`Posting refused for ${docNo}: ${postingNotice || 'the posting controls rejected this entry. Check the System Notices bar for the precise rule.'}`);
      setCanSubmitApproval(false);
      return;
    }
    setShowModal(false);
    setDescription('');
    setError(null);
    setCanSubmitApproval(false);
    setSuccessToast(`Journal ${docNo} posted in ${docCurrency}: ${formatMoney(amount, docCurrency)} Dr ${dr.accountNo} / Cr ${cr.accountNo}.`);
    setTimeout(() => setSuccessToast(null), 6000);
    setTimeout(refreshAuditTrail, 1200);
  };

  const buildProposedLines = (): ACDOCALine[] => {
    const docNo = nextDocNo(`${docType}-${period}`, [
      ...lines.filter((l) => l.clientId === currentClient.id).map((l) => l.docNo),
      ...persistentStorage.getApprovalRequests().filter((r) => r.clientId === currentClient.id).map((r) => r.docNo),
    ]);
    const today = postingDate;
    const dr = parseAccountOption(drAccount);
    const cr = parseAccountOption(crAccount);
    return [
      {
        id: `${uniqueId('JL')}-1`,
        docNo,
        period,
        date: today,
        module: 'FI',
        docType,
        accountNo: dr.accountNo,
        accountName: dr.accountName,
        costCenter: 'CC-ADM',
        debit: amount,
        credit: 0,
        currency: docCurrency,
        description: description || `Manual journal entry ${docNo}`,
        createdBy: currentUser.username,
        checkedBy: undefined,
        clientId: currentClient.id,
      },
      {
        id: `${uniqueId('JL')}-2`,
        docNo,
        period,
        date: today,
        module: 'FI',
        docType,
        accountNo: cr.accountNo,
        accountName: cr.accountName,
        costCenter: 'CC-ADM',
        debit: 0,
        credit: amount,
        currency: docCurrency,
        description: description || `Manual journal entry ${docNo}`,
        createdBy: currentUser.username,
        checkedBy: undefined,
        clientId: currentClient.id,
      },
    ];
  };

  const handleSubmitForApproval = () => {
    const proposedLines = buildProposedLines();
    const docNo = proposedLines[0].docNo;
    const newReq: ApprovalRequest = {
      id: `${uniqueId('APP')}`,
      clientId: currentClient.id,
      clientCode: currentClient.code,
      clientName: currentClient.name,
      docNo,
      docType: 'JE',
      amount,
      requestedBy: `${currentUser.name} (${currentUser.username})`,
      requestedAt: new Date().toISOString().replace('T', ' ').slice(0, 16) + ' GMT',
      description: description || `Manual journal entry ${docNo} (${drAccount} / ${crAccount})`,
      reasonForApproval: docCurrency !== currentClient.currency
        ? `${docCurrency} ${formatMoney(amount, docCurrency)} is a foreign-currency entry for an entity reporting in ${currentClient.currency}; independent approval is always required.`
        : `Amount ${formatMoney(amount, docCurrency)} exceeds maker limit (${formatMoney(currentUser.makerLimit, currentClient.currency)})`,
      status: 'pending',
      payload: { lines: proposedLines },
    };

    persistentStorage.addApprovalRequest(newReq);
    setShowModal(false);
    setError(null);
    setCanSubmitApproval(false);
    setSuccessToast(
      `Approval Request Submitted! Document ${docNo} routed to Owner/Checker Queue for sign-off.`
    );
    setTimeout(() => setSuccessToast(null), 5000);
    if (onApprovalSubmitted) onApprovalSubmitted();
  };

  const handleReverseDoc = (docNo: string) => {
    // The reversal is built for the CURRENT period, posted as one balanced
    // document (REV-<docNo>) and the original lines are flagged isReversed so
    // a document can never be reversed twice.
    const ok = onReverseDocument ? onReverseDocument(docNo) : false;
    if (ok) {
      setSuccessToast(`Reversal posted: REV-${docNo} (counter-entries in the current period). Original document is now flagged as reversed.`);
      setTimeout(() => setSuccessToast(null), 6000);
      setTimeout(refreshAuditTrail, 1200);
    } else {
      setSuccessToast(null);
      setError(`Reversal blocked: ${docNo} is already reversed, or the current period is frozen. Reopen the period by the Owner to correct the error.`);
      setTimeout(() => setError(null), 8000);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`FI · Manual Journal & Reversals · ${currentClient.code}`}
        title="Manual Journal Entries"
        desc="Free-entry journals, opening balances and adjustments (Dr = Cr enforced)."
      >
        <button
          onClick={() => printReport({
            kicker: 'Universal journal', title: 'Universal Journal — posted lines', subtitle: `${clientLines.length} line(s) · ${new Set(clientLines.map((l) => l.docNo)).size} document(s) · ${currentClient.currency}`,
            entity: toPrintEntity(currentClient, profileStore.getCompanyProfiles()[currentClient.id]), periodLabel: 'All posted periods', preparedBy: `${currentUser.name} (${currentUser.username})`, orientation: 'landscape',
            sections: [{ columns: [{ key: 'docNo', label: 'Document' }, { key: 'date', label: 'Date' }, { key: 'module', label: 'Module' }, { key: 'account', label: 'Account' }, { key: 'description', label: 'Narrative' }, { key: 'debit', label: 'Debit', numeric: true }, { key: 'credit', label: 'Credit', numeric: true }, { key: 'maker', label: 'Maker / Checker' }],
              rows: clientLines.map((l) => ({ docNo: `${l.docNo}${l.isReversed ? ' (reversed)' : ''}`, date: l.date, module: l.module, account: `${l.accountNo} · ${l.accountName}`, description: l.description, debit: l.debit || '', credit: l.credit || '', maker: `${l.createdBy}${l.checkedBy ? ` / ${l.checkedBy}` : ''}` })),
              totals: { docNo: 'TOTAL', debit: clientLines.reduce((n, l) => n + l.debit, 0), credit: clientLines.reduce((n, l) => n + l.credit, 0) } }],
          })}
          className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"
        >
          <Printer className="h-4 w-4" />
          <span>Print journal</span>
        </button>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
        >
          <Plus className="h-4 w-4" />
          <span>Post Manual Journal</span>
        </button>
      </PageHeader>

      {successToast && (
        <div role="status" className="rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-xs font-bold text-emerald-900 flex items-center gap-2 shadow-xs">
          <Check className="h-5 w-5 text-emerald-700 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {isPeriodClosed && (
        <div className="rounded-lg border border-rose-300 bg-rose-50 p-3 text-xs text-rose-900 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-rose-700 shrink-0" />
            <span><strong>Period {period} Locked:</strong> Month-End Close has frozen this fiscal period. Regular postings are disabled until reopened by Owner.</span>
          </div>
          <span className="font-mono text-[11px] font-bold uppercase text-rose-800 bg-rose-100 px-2 py-0.5 rounded">FROZEN</span>
        </div>
      )}

      <Card title="Universal Journal General Ledger Lines" sub="Immutable append-only entries">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Doc No</th>
                <th className={thCls}>Date</th>
                <th className={thCls}>Module</th>
                <th className={thCls}>Account No &amp; Name</th>
                <th className={thCls}>Currency</th>
                <th className={thCls + " text-right"}>Debit</th>
                <th className={thCls + " text-right"}>Credit</th>
                <th className={thCls}>Description</th>
                <th className={thCls}>Maker / Checker</th>
                <th className={thCls + " text-center"}>Control</th>
              </tr>
            </thead>
            <tbody>
              {clientLines.map((l) => {
                const isRev = l.docType === 'REV';
                const isReversed = !!l.isReversed || reversedDocNos.has(l.docNo);
                return (
                  <tr key={l.id} className={`${rowCls} ${isRev ? 'bg-rose-50/60' : ''} ${isReversed && !isRev ? 'opacity-60' : ''}`}>
                    <td className="px-3 py-2 font-mono font-bold text-[#855b00]">
                      {l.docNo}
                      {isReversed && (
                        <span className="ml-1.5 rounded bg-rose-100 border border-rose-300 px-1 py-0 text-[9px] font-bold text-rose-800 align-middle">
                          REVERSED
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2 font-mono text-[#2d4f6d]">{l.date}</td>
                    <td className="px-3 py-2 font-mono font-semibold">{l.module}</td>
                    <td className="px-3 py-2">
                      <span className="font-mono font-bold text-[#082f4f]">{l.accountNo}</span>
                      <div className="text-[11px] text-[#355875] truncate max-w-[140px]">{l.accountName}</div>
                    </td>
                    <td className="px-3 py-2 font-mono font-semibold text-[#006f98]">{l.currency}</td>
                    <td className={numCls + " font-bold text-[#8a5d00]"}>
                      {l.debit > 0 ? formatMoney(l.debit, l.currency) : '—'}
                    </td>
                    <td className={numCls + " font-bold text-[#087a55]"}>
                      {l.credit > 0 ? formatMoney(l.credit, l.currency) : '—'}
                    </td>
                    <td className="px-3 py-2 text-[#2d4f6d] truncate max-w-[200px]">{l.description}</td>
                    <td className="px-3 py-2 text-[11px]">
                      <div>M: {l.createdBy}</div>
                      {l.checkedBy ? (
                        <div className="text-emerald-700 font-semibold flex items-center gap-0.5">
                          <Check className="h-3 w-3" />
                          <span>C: {l.checkedBy}</span>
                        </div>
                      ) : (
                        <div className="text-[#855b00]">Pending Checker</div>
                      )}
                    </td>
                    <td className="px-3 py-2 text-center">
                      {!isRev && (
                        <button
                          onClick={() => handleReverseDoc(l.docNo)}
                          disabled={isReversed}
                          className="rounded border border-rose-300 bg-rose-50 px-2 py-0.5 text-[10.5px] font-bold text-rose-800 hover:bg-rose-100 transition disabled:opacity-40 disabled:cursor-not-allowed"
                          title={isReversed ? 'Document already reversed — corrections post as new adjusting entries' : 'Post a balanced counter-reversal in the current period'}
                        >
                          <RotateCcw className="h-3 w-3 inline mr-1" />
                          Reverse
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Audit trail — who posted, froze, reversed or approved what, from the server log */}
      <Card
        title="Audit Trail (server log)"
        sub="Immutable control history for this entity — postings, period freezes/reopens, reversals and approvals"
        action={<ScrollText className="h-4 w-4 text-[#006f98]" />}
      >
        {auditEvents.length === 0 ? (
          <div className="p-4 text-xs text-[#355875] border border-dashed border-sky-200 rounded-lg bg-sky-50/40">
            No audit events recorded for this entity yet. Every posted document, period freeze, reversal and
            approval decision is logged here by the server.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-xs">
              <thead>
                <tr className="border-b border-sky-200 bg-sky-50/70">
                  <th className={thCls}>When (UTC)</th>
                  <th className={thCls}>User</th>
                  <th className={thCls}>Action</th>
                  <th className={thCls}>Target</th>
                  <th className={thCls}>Details</th>
                </tr>
              </thead>
              <tbody>
                {auditEvents.map((e, i) => (
                  <tr key={i} className={rowCls}>
                    <td className="px-3 py-1.5 font-mono text-[#2d4f6d] whitespace-nowrap">{e.timestamp.replace('T', ' ').slice(0, 19)}</td>
                    <td className="px-3 py-1.5 font-bold text-[#082f4f]">{e.username}</td>
                    <td className="px-3 py-1.5">
                      <span
                        className={`rounded px-1.5 py-0.5 text-[10px] font-bold font-mono ${
                          e.action === 'REOPEN_PERIOD' || e.action === 'APPROVAL_REJECTED'
                            ? 'bg-amber-100 text-[#855b00] border border-amber-300'
                            : e.action === 'CLOSE_PERIOD'
                            ? 'bg-rose-100 text-rose-800 border border-rose-300'
                            : 'bg-sky-100 text-[#006f98] border border-sky-300'
                        }`}
                      >
                        {e.action}
                      </span>
                    </td>
                    <td className="px-3 py-1.5 font-mono text-[#855b00]">{e.target}</td>
                    <td className="px-3 py-1.5 text-[#2d4f6d]">{e.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form ref={modalRef} role="dialog" aria-modal="true" aria-labelledby="journal-entry-title" tabIndex={-1} onSubmit={handlePostEntry} className="w-full max-w-lg rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4">
            <h3 id="journal-entry-title" className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Post Manual Journal Entry</h3>

            {error && (
              <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 p-3 text-xs text-rose-800 flex items-start gap-2">
                <AlertCircle className="h-4 w-4 text-rose-700 shrink-0 mt-0.5" />
                <div>{error}</div>
              </div>
            )}

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="journal-doc-type" className="block font-bold text-[#0a253e] mb-1">Doc Type</label>
                  <select
                    id="journal-doc-type"
                    value={docType}
                    onChange={(e) => setDocType(e.target.value as any)}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none"
                  >
                    <option value="JE">JE · General Journal</option>
                    <option value="DEP">DEP · Depreciation</option>
                    <option value="STAT">STAT · Statutory Expense</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="journal-date" className="block font-bold text-[#0a253e] mb-1">Posting Date</label>
                  <input
                    id="journal-date"
                    type="date"
                    value={postingDate}
                    onChange={(e) => setPostingDate(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono"
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="journal-currency" className="block font-bold text-[#0a253e] mb-1">Document currency</label>
                  <select
                    id="journal-currency"
                    value={docCurrency}
                    onChange={(e) => setDocCurrency(e.target.value)}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-mono font-bold"
                    required
                  >
                    {Array.from(new Set([currentClient.currency, ...POSTABLE_CURRENCIES])).map((code) => (
                      <option key={code} value={code}>
                        {code}{code === currentClient.currency ? ' · functional currency' : ''}
                      </option>
                    ))}
                  </select>
                  <p className="mt-1 text-[10px] text-[#355875]">The entity reports in {currentClient.currency}.</p>
                </div>
                <div>
                  <label htmlFor="journal-amount" className="block font-bold text-[#0a253e] mb-1">Amount ({docCurrency})</label>
                  <input
                    id="journal-amount"
                    type="number"
                    min="0.01"
                    step="0.01"
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono"
                    required
                  />
                  <p className="mt-1 text-[10px] text-[#355875]">{formatMoney(amount, docCurrency)}</p>
                </div>
              </div>

              <div>
                <label htmlFor="journal-debit" className="block font-bold text-[#0a253e] mb-1">Debit Account (Dr)</label>
                <select
                  id="journal-debit"
                  value={drAccount}
                  onChange={(e) => setDrAccount(e.target.value)}
                  className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none"
                >
                  {accounts.length > 0 ? (
                    accounts.filter((a) => a.active).map((a) => (
                      <option key={a.accountNo} value={`${a.accountNo} · ${a.name}`}>
                        {a.accountNo} · {a.name} ({a.type})
                      </option>
                    ))
                  ) : (
                    <>
                      <option value="600000 · Operating Expenses">600000 · Operating Expenses</option>
                      <option value="120000 · Raw Materials & Inventory">120000 · Raw Materials &amp; Inventory</option>
                      <option value="130000 · Property, Plant & Equipment">130000 · Property, Plant &amp; Equipment</option>
                      <option value="110000 · Trade Receivables">110000 · Trade Receivables</option>
                      <option value="100000 · Cash at Bank">100000 · Cash at Bank</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label htmlFor="journal-credit" className="block font-bold text-[#0a253e] mb-1">Credit Account (Cr)</label>
                <select
                  id="journal-credit"
                  value={crAccount}
                  onChange={(e) => setCrAccount(e.target.value)}
                  className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none"
                >
                  {accounts.length > 0 ? (
                    accounts.filter((a) => a.active).map((a) => (
                      <option key={a.accountNo} value={`${a.accountNo} · ${a.name}`}>
                        {a.accountNo} · {a.name} ({a.type})
                      </option>
                    ))
                  ) : (
                    <>
                      <option value="100000 · Cash at Bank">100000 · Cash at Bank</option>
                      <option value="200000 · Trade Payables">200000 · Trade Payables</option>
                      <option value="400000 · Revenue from Gold Bullion">400000 · Revenue from Gold Bullion</option>
                      <option value="220000 · VAT Output Liability">220000 · VAT Output Liability</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label htmlFor="journal-narration" className="block font-bold text-[#0a253e] mb-1">Narration / Justification</label>
                <input
                  id="journal-narration"
                  type="text"
                  placeholder="e.g. Fuel usage adjustment for extraction truck"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                  required
                />
              </div>

              <div className="rounded bg-sky-50 border border-sky-200 p-2 text-[11px] text-[#2d4f6d]">
                <span className="block">Auto-balances Dr = Cr ({formatMoney(amount, docCurrency)}). Maker limit: {formatMoney(currentUser.makerLimit, currentClient.currency)} in {currentClient.currency}.</span>
                {docCurrency !== currentClient.currency && (
                  <span className="mt-1 block font-bold text-[#855b00]">
                    Foreign-currency entry: it will be routed for independent checker approval regardless of amount, and the maker limit is not translated into {docCurrency}.
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-sky-100">
              {canSubmitApproval ? (
                <button
                  type="button"
                  onClick={handleSubmitForApproval}
                  className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-bold text-[#082f4f] hover:bg-amber-400 transition shadow-xs"
                >
                  <Send className="h-3.5 w-3.5" />
                  <span>Submit for Reviewer / Owner Sign-Off</span>
                </button>
              ) : <div />}

              <div className="flex gap-2">
                <button type="button" onClick={() => setShowModal(false)} className="rounded px-3 py-1.5 text-xs font-semibold text-[#2d4f6d]">Cancel</button>
                <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 text-xs font-bold text-white">Post Entry</button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
