import { useMemo, useState } from 'react';
import type { ACDOCALine, AccountMaster, ClientEntity, UserAccount } from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS } from './ui';
import { ModulePrintButton } from './ModulePrintButton';
import { CheckCircle2, Lock, Unlock, Archive } from 'lucide-react';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  /** Closed periods for this entity (e.g. ["2026-03"]). */
  closedPeriods: string[];
  lines: ACDOCALine[];
  onTogglePeriodClose: (period: string) => void;
  accounts?: AccountMaster[];
  /** Posts the year-end close (P/L → retained earnings 310000); returns the result or null. */
  onPostYearEndClose?: (year: number) => { net: number; accounts: number } | null;
  /** Control accounts that are out of balance with their sub-ledgers (computed on the server snapshot). */
  controlExceptions?: { key: string; label: string; difference: number }[];
}

export const MonthEndSection = ({ currentClient, currentUser, closedPeriods, lines, onTogglePeriodClose, accounts = [], onPostYearEndClose, controlExceptions = [] }: Props) => {
  const [period, setPeriod] = useState(() => new Date().toISOString().slice(0, 7));
  const [closeYear, setCloseYear] = useState(() => Number(new Date().toISOString().slice(0, 4)));
  const [closeMsg, setCloseMsg] = useState<string | null>(null);
  const isPeriodClosed = closedPeriods.includes(period);

  const clientLines = lines.filter(l => l.clientId === currentClient.id);
  const debit = clientLines.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
  const credit = clientLines.reduce((n, l) => n + Math.round(l.credit * 100), 0) / 100;
  const diff = Math.round((debit - credit) * 100) / 100;
  const balanced = Math.abs(diff) < 0.01;

  const checks = useMemo(() => {
    const periodLines = clientLines.filter(l => l.period === period);
    const hasPosting = periodLines.length > 0;
    const hasDocuments = new Set(periodLines.map(l => l.docNo)).size;
    const accountsTouched = new Set(periodLines.map(l => l.accountNo)).size;
    const sorted = periodLines.map(l => Math.round((l.debit - l.credit) * 100));
    const outOfBalance = sorted.length > 0 && sorted.reduce((s, x) => s + x, 0) !== 0;
    return [
      { label: `Period ${period} has posted journal lines`, done: hasPosting, hint: `${periodLines.length} lines across ${hasDocuments} documents` },
      { label: 'Double-entry balance (Dr = Cr)', done: balanced, hint: balanced ? 'All accounts balance' : `Out of balance by ₵${formatGHS(diff)}` },
      { label: 'Ledger coverage', done: accountsTouched > 0, hint: `${accountsTouched} nominal accounts used` },
      { label: 'Period isolation', done: !outOfBalance, hint: 'No unbalanced documents in this period' },
      {
        label: 'Control accounts reconcile to sub-ledgers',
        done: controlExceptions.length === 0,
        hint: controlExceptions.length === 0
          ? 'Receivables, payables, inventory, treasury, PPE, payroll, VAT & WHT all tie to the ledger'
          : `${controlExceptions.length} out of balance: ${controlExceptions.map((c) => `${c.label} (₵${formatGHS(c.difference)})`).join(', ')} — open the Control Accounts desk`,
      },
    ];
  }, [clientLines, balanced, diff, period, controlExceptions]);

  const canToggle = currentUser.role === 'owner' || currentUser.permissions?.canClosePeriod === true;
  // Only the Firm Owner may override aperiod close while a control account is out of balance.
  const controlGateBlocked = controlExceptions.length > 0 && currentUser.role !== 'owner';

  return (
    <div className="space-y-6">
      <PageHeader kicker={`MCC · Period Freeze · ${currentClient.code}`} title="Period Close Checklist" desc="Verify and freeze a fiscal period so prior periods cannot be amended. Freezing is enforced by the server: journal postings dated inside a closed period are rejected at the API boundary, not just hidden in the browser.">
        <ModulePrintButton title={`Month-end close checklist — ${currentClient.name}`} subtitle={`Period ${period}`} />
      </PageHeader>

      <div className="flex flex-wrap items-end gap-3 bg-white p-4 rounded-xl border border-sky-200">
        <label className="text-xs font-bold">Fiscal period
          <input type="month" value={period} onChange={e => setPeriod(e.target.value)} className="block mt-1 p-2 border border-sky-300 rounded" />
        </label>
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Active period" value={period} sub="ISO calendar month" />
        <Stat label="Trial balance diff" value={formatGHS(diff)} tone={balanced ? 'text-emerald-700' : 'text-rose-700'} sub={balanced ? 'Dr = Cr validated' : 'Resolve imbalance before closing'} />
        <Stat label="Ledger status" value={isPeriodClosed ? 'FROZEN' : 'OPEN'} tone={isPeriodClosed ? 'text-rose-700' : 'text-emerald-700'} sub={isPeriodClosed ? 'Period locked' : 'Normal operation'} />
        <Stat label="Freeze authority" value={canToggle ? 'Owner / Senior' : 'Restricted'} tone={canToggle ? 'text-emerald-700' : 'text-rose-700'} sub={canToggle ? 'May freeze this period' : 'Requires owner or close-permission user'} />
      </div>

      <Card title={`Checklist for ${period}`} sub="All five prerequisites must be green before freezing">
        <ul className="space-y-2 text-xs">
          {checks.map(c => (
            <li key={c.label} className="flex items-center justify-between p-3 rounded-lg border border-sky-200 bg-sky-50/50">
              <div>
                <div className="font-bold text-[#082f4f]">{c.label}</div>
                <div className="text-[11px] text-[#2d4f6d]">{c.hint}</div>
              </div>
              {c.done ? (
                <span className="text-xs font-bold text-emerald-700 flex items-center gap-1"><CheckCircle2 className="h-4 w-4" /> Confirmed</span>
              ) : (
                <span className="text-xs font-bold text-rose-700">Action required</span>
              )}
            </li>
          ))}
        </ul>

        <div className="mt-4 pt-4 border-t border-sky-100 flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-[#2d4f6d]">
            {isPeriodClosed
              ? `Period ${period} is locked. New postings in this month are blocked.`
              : 'Confirm all checks are green before freezing.'}
          </div>
          <div className="flex gap-2">
            {isPeriodClosed ? (
              <button onClick={() => onTogglePeriodClose(period)} disabled={!canToggle} className="rounded-lg bg-amber-600 text-white text-xs font-bold px-4 py-2 hover:bg-amber-700 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5">
                <Unlock className="h-3.5 w-3.5" /> Reopen period (owner override)
              </button>
            ) : (
              <button onClick={() => onTogglePeriodClose(period)} disabled={!canToggle || !balanced || controlGateBlocked} className="rounded-lg bg-rose-700 text-white text-xs font-bold px-4 py-2 hover:bg-rose-800 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
                title={controlGateBlocked ? 'A control account is out of balance with its sub-ledger. Only the Firm Owner may override. Open the Control Accounts desk to investigate.' : undefined}>
                <Lock className="h-3.5 w-3.5" /> Freeze & close period
              </button>
            )}
          </div>
        </div>
      </Card>

      {/* Year-end close: transfer the fiscal year's profit or loss to retained earnings */}
      <Card
        title="Year-End Close"
        sub="Zero every P/L account's fiscal-year balance into Retained Earnings (310000) with one balanced document"
      >
        {(() => {
          const yearPrefix = `${closeYear}-`;
          const yearLines = clientLines.filter((l) => l.period.startsWith(yearPrefix));
          const balances = new Map<string, number>();
          for (const l of yearLines) balances.set(l.accountNo, (balances.get(l.accountNo) ?? 0) + l.debit - l.credit);
          const typeOf = (code: string) => accounts.find((a) => a.accountNo === code)?.type;
          const plAccounts = [...balances.entries()].filter(([c, b]) => Math.abs(b) >= 0.005 && (typeOf(c) === 'Income' || typeOf(c) === 'Expense'));
          const net = Math.round(plAccounts.reduce((s, [, b]) => s - b, 0) * 100) / 100;
          const alreadyClosed = clientLines.some((l) => l.docNo === `YE-CLOSE-${closeYear}`);
          return (
            <div className="space-y-3">
              <div className="flex flex-wrap items-end gap-3">
                <label className="text-xs font-bold">Fiscal year
                  <input type="number" min={2020} max={2100} value={closeYear} onChange={(e) => setCloseYear(Number(e.target.value))} className="block mt-1 p-2 border border-sky-300 rounded w-28 font-mono" />
                </label>
                <div className="flex items-center gap-4 pb-1 font-mono text-xs">
                  <span>P/L accounts with balances: <strong className="text-[#082f4f]">{plAccounts.length}</strong></span>
                  <span>Result: <strong className={net >= 0 ? 'text-emerald-700' : 'text-rose-700'}>{net >= 0 ? 'Profit' : 'Loss'} ₵{formatGHS(Math.abs(net))}</strong></span>
                  {alreadyClosed && <span className="rounded bg-emerald-100 border border-emerald-300 px-2 py-0.5 text-[10px] font-bold text-emerald-800">YE-CLOSE-{closeYear} already posted</span>}
                </div>
              </div>
              {closeMsg && (
                <div className="rounded-lg border border-emerald-300 bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-900">{closeMsg}</div>
              )}
              <div className="flex items-center justify-between gap-3 border-t border-sky-100 pt-3">
                <p className="text-[11px] text-[#2d4f6d]">
                  Posts document <span className="font-mono font-bold text-[#082f4f]">YE-CLOSE-{closeYear}</span> in the last posted month of the year,
                  transferring {net >= 0 ? 'the profit' : 'the loss'} to Retained Earnings. Post all periods of the year and freeze prior periods first.
                </p>
                <button
                  disabled={!canToggle || !onPostYearEndClose || plAccounts.length === 0 || alreadyClosed}
                  onClick={() => {
                    const res = onPostYearEndClose?.(closeYear);
                    if (res) {
                      setCloseMsg(`Year-end close posted: ${res.net >= 0 ? 'profit of' : 'loss of'} ₵${formatGHS(Math.abs(res.net))} transferred to Retained Earnings across ${res.accounts} P/L accounts.`);
                    } else {
                      setCloseMsg('Year-end close could not be posted — nothing to close, or the target period is frozen. Reopen the final month if needed.');
                    }
                    setTimeout(() => setCloseMsg(null), 8000);
                  }}
                  className="shrink-0 rounded-lg bg-[#082f4f] text-white text-xs font-bold px-4 py-2 hover:bg-[#0c3f68] disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
                >
                  <Archive className="h-3.5 w-3.5" /> Post year-end close
                </button>
              </div>
            </div>
          );
        })()}
      </Card>
    </div>
  );
};
