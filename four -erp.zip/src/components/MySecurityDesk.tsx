'use client';

import { useEffect, useState } from 'react';
import { ShieldCheck, KeyRound, Smartphone } from 'lucide-react';
import type { UserAccount } from '../types/accounting';
import { apiFetch } from '../utils/session';
import { Card, PageHeader, Badge } from './ui';

/**
 * Self-service account security: TOTP multi-factor authentication.
 * Works with Google Authenticator, Microsoft Authenticator, Authy, 1Password.
 */
export function MySecurityDesk({ currentUser }: { currentUser: UserAccount }) {
  const [enabled, setEnabled] = useState<boolean>(Boolean(currentUser.mfaEnabled));
  const [secret, setSecret] = useState<string | null>(null);
  const [uri, setUri] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    apiFetch('/api/auth/mfa').then((r) => r.json()).then((b) => { if (!cancelled && b?.ok) setEnabled(Boolean(b.mfaEnabled)); }).catch(() => {});
    return () => { cancelled = true; };
  }, []);

  const call = async (payload: Record<string, unknown>) => {
    setBusy(true);
    setMsg(null);
    try {
      const r = await apiFetch('/api/auth/mfa', { method: 'POST', body: JSON.stringify(payload) });
      const b = await r.json().catch(() => null);
      return { ok: r.ok && b?.ok, body: b };
    } finally {
      setBusy(false);
    }
  };

  const begin = async () => {
    const { ok, body } = await call({ action: 'begin' });
    if (!ok) { setMsg({ ok: false, text: body?.error || 'Could not start enrolment.' }); return; }
    setSecret(body.secret);
    setUri(body.otpauthUri);
  };
  const confirm = async () => {
    const { ok, body } = await call({ action: 'confirm', code });
    if (!ok) { setMsg({ ok: false, text: body?.error || 'Code not accepted.' }); return; }
    setEnabled(true); setSecret(null); setUri(null); setCode('');
    setMsg({ ok: true, text: 'Multi-factor authentication is ON. From your next sign-in you will be asked for a 6-digit code.' });
  };
  const disable = async () => {
    const { ok, body } = await call({ action: 'disable', code, password });
    if (!ok) { setMsg({ ok: false, text: body?.error || 'MFA was not disabled.' }); return; }
    setEnabled(false); setCode(''); setPassword('');
    setMsg({ ok: true, text: 'Multi-factor authentication has been turned off for your account.' });
  };

  const grouped = secret ? secret.match(/.{1,4}/g)?.join(' ') : '';

  return (
    <div className="space-y-5">
      <PageHeader kicker="SEC · Account security" title="My Account Security" desc="Protect your sign-in with a second factor (RFC 6238 time-based one-time codes). Strongly recommended for owners, partners and anyone who can post or approve.">
        {enabled ? <Badge tone="green">MFA ON</Badge> : <Badge tone="amber">MFA OFF</Badge>}
      </PageHeader>
      {msg && <div role="alert" className={`rounded-xl border p-3 text-xs font-bold ${msg.ok ? 'border-emerald-300 bg-emerald-50 text-emerald-900' : 'border-rose-300 bg-rose-50 text-rose-900'}`}>{msg.text}</div>}

      <Card title={`Signed in as ${currentUser.name}`} sub={`${currentUser.username} · ${currentUser.email} · ${currentUser.role}`}>
        {!enabled && !secret && (
          <div className="space-y-3 text-xs text-[#2d4f6d]">
            <p className="flex items-start gap-2"><Smartphone className="h-4 w-4 shrink-0 text-[#006f98]" /> Install an authenticator app (Google Authenticator, Microsoft Authenticator, Authy or 1Password) on your phone, then start enrolment.</p>
            <button onClick={begin} disabled={busy} className="rounded-lg bg-[#082f4f] px-4 py-2 font-bold text-white disabled:opacity-50">Set up multi-factor authentication</button>
          </div>
        )}
        {!enabled && secret && (
          <div className="space-y-3 text-xs">
            <p className="text-[#2d4f6d]">In your authenticator app choose <strong>Add account → Enter a setup key</strong>, then type this key (time-based):</p>
            <div className="rounded-lg border border-sky-300 bg-sky-50 p-3 font-mono text-base font-black tracking-wider text-[#082f4f] select-all">{grouped}</div>
            {uri && <a href={uri} className="inline-block text-[11px] font-bold text-[#006f98] underline">Open in authenticator (mobile)</a>}
            <label className="block font-bold text-[#355875]">Enter the 6-digit code the app now shows
              <input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} maxLength={6} inputMode="numeric" className="mt-1 block w-48 rounded border border-sky-300 px-3 py-2 text-center font-mono text-lg tracking-[0.3em] font-bold" />
            </label>
            <button onClick={confirm} disabled={busy || code.length !== 6} className="rounded-lg bg-emerald-700 px-4 py-2 font-bold text-white disabled:opacity-50">Confirm & turn on</button>
          </div>
        )}
        {enabled && (
          <div className="space-y-3 text-xs">
            <p className="flex items-center gap-2 font-bold text-emerald-800"><ShieldCheck className="h-4 w-4" /> Your account requires a 6-digit authenticator code at every sign-in.</p>
            <div className="rounded-xl border border-rose-200 bg-rose-50/50 p-3 space-y-2">
              <div className="flex items-center gap-1.5 font-bold text-rose-900"><KeyRound className="h-4 w-4" /> Turn MFA off (needs password + current code)</div>
              <div className="flex flex-wrap gap-2">
                <input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="rounded border border-sky-300 px-3 py-1.5" />
                <input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} maxLength={6} inputMode="numeric" placeholder="6-digit code" className="w-32 rounded border border-sky-300 px-3 py-1.5 font-mono" />
                <button onClick={disable} disabled={busy || !password || code.length !== 6} className="rounded-lg bg-[#b42318] px-3 py-1.5 font-bold text-white disabled:opacity-50">Disable MFA</button>
              </div>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
