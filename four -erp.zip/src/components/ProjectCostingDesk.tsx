'use client';

import React, { useMemo, useRef, useState } from 'react';
import type { ACDOCALine, AccountMaster, ClientEntity, SalesInvoice, UserAccount } from '../types/accounting';
import { Badge, Card, PageHeader, Stat, formatGHS, numCls, rowCls, tdCls, thCls } from './ui';
import { Download, FolderKanban, Plus, Printer } from 'lucide-react';
import { useDeskRecords, type DeskRecord } from './DeskKit';
import { downloadCsv } from '../utils/printReport';
import { printModuleView } from '../utils/printModuleView';
import { uniqueId } from '../utils/ids';
import { localToday } from '../utils/periods';
import { money } from '../utils/trading';

export interface ProjectRecord extends DeskRecord {
  code: string;
  projectName: string;
  customerName: string;
  status: 'Quote' | 'Active' | 'Suspended' | 'Completed';
  contractValue: number;
  estimatedCost: number;
  startDate: string;
  endDate: string;
  costCenter: string;
}

interface ProjectCostingDeskProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  invoices: SalesInvoice[];
  accounts?: AccountMaster[];
  isPeriodClosed?: boolean;
  onAddJournalLines: (lines: ACDOCALine[]) => boolean;
  onNavigate?: (section: string) => void;
}

/**
 * Project Costing & Contracts desk (job costing for construction, engineering,
 * logistics and professional-service engagements).
 *
 * Every figure is DERIVED from the ledger: direct costs accumulate from posted
 * journals that carry the project's cost centre or reference its project code;
 * billings accumulate from posted sales invoices to the project's customer.
 * Progress revenue is the IFRS 15 percentage-of-completion input measure, and the
 * resulting contract asset/liability posts into the ledger (118100 / 225000) so
 * the IFRS Desk, the statements and the control accounts all pick it up.
 */
export const ProjectCostingDesk: React.FC<ProjectCostingDeskProps> = ({
  currentClient, currentUser, lines, invoices, accounts, isPeriodClosed = false, onAddJournalLines, onNavigate,
}) => {
  const { records, saving, error } = useDeskRecords<ProjectRecord>('projects', currentClient.id, 'project');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [pCode, setPCode] = useState('PRJ-2026-01');
  const [pName, setPName] = useState('');
  const [pCustomer, setPCustomer] = useState('');
  const [pContract, setPContract] = useState(250000);
  const [pEstimated, setPEstimated] = useState(180000);
  const [pCenter, setPCenter] = useState('CC-PRJ');
  const [pEnd, setPEnd] = useState('2026-12-31');
  const detailRef = useRef<HTMLDivElement | null>(null);

  const entityLines = useMemo(() => lines.filter((l) => l.clientId === currentClient.id && !l.isReversed), [lines, currentClient.id]);

  const projects = useMemo(() =>
    records
      .map((p) => ({ ...p, contractValue: Number(p.contractValue) || 0, estimatedCost: Number(p.estimatedCost) || 0 }))
      .sort((a, b) => a.code.localeCompare(b.code)),
    [records]
  );

  /** Per-project ledger-derived position. */
  const positions = useMemo(() => projects.map((p) => {
    const projLines = entityLines.filter(
      (l) => l.costCenter === p.costCenter || l.reference === p.code || l.docNo.startsWith(`POC-${p.code}-`)
    );
    const pocLines = projLines.filter((l) => l.docNo.startsWith(`POC-${p.code}-`));
    const costLines = projLines.filter((l) => !l.docNo.startsWith(`POC-${p.code}-`) && l.accountNo.startsWith('5') || !l.docNo.startsWith(`POC-${p.code}-`) && (l.accountNo.startsWith('60') || l.accountNo.startsWith('61') || l.accountNo.startsWith('62')));
    const directCosts = costLines.reduce((s, l) => s + (l.debit - l.credit), 0);
    const postedRevenue = pocLines.filter((l) => l.accountNo.startsWith('4')).reduce((s, l) => s + (l.credit - l.debit), 0);
    const billed = invoices.filter((i) => i.clientId === currentClient.id && i.customerName === p.customerName && i.status !== 'Draft' && i.status !== 'Credited').reduce((s, i) => s + i.netRevenue, 0);
    const costs = directCosts;
    const poc = p.estimatedCost > 0 ? Math.min(1, costs / p.estimatedCost) : 0;
    const earned = money(p.contractValue * poc);
    const billedNet = money(billed);
    const contractPosition = money(earned - billedNet); // +ve asset, -ve liability
    const profitToDate = money(earned - costs);
    const forecastMargin = p.contractValue > 0 ? ((p.contractValue - p.estimatedCost) / p.contractValue) * 100 : 0;
    return { p, costs: money(costs), poc, earned, billed: billedNet, postedRevenue: money(postedRevenue), contractPosition, profitToDate, forecastMargin };
  }), [projects, entityLines, invoices, currentClient.id]);

  const totals = useMemo(() => ({
    contract: positions.reduce((s, x) => s + x.p.contractValue, 0),
    costs: positions.reduce((s, x) => s + x.costs, 0),
    earned: positions.reduce((s, x) => s + x.earned, 0),
    profit: positions.reduce((s, x) => s + x.profitToDate, 0),
  }), [positions]);

  const recognisedPeriod = localToday().slice(0, 7);

  const handleRecognisePoc = (x: (typeof positions)[number]) => {
    if (isPeriodClosed) { setFeedback(`Cannot recognise POC: the current period is closed for ${currentClient.code}.`); return; }
    // Post only the UNEARNED delta not yet in the ledger, so rerunning is safe.
    const outstanding = money(x.earned - x.postedRevenue);
    if (Math.abs(outstanding) < 0.01) { setFeedback(`${x.p.code}: revenue to date (₵${formatGHS(x.earned)}) is already fully recognised in the ledger.`); return; }
    const date = localToday();
    const docNo = `POC-${x.p.code}-${recognisedPeriod}`;
    if (entityLines.some((l) => l.docNo === docNo)) { setFeedback(`${x.p.code}: POC already recognised for ${recognisedPeriod} (document ${docNo}). Reverse it first to change the amount.`); return; }
    const revenueAccount = accounts?.find((a) => a.accountNo === '400000' && a.active) ? '400000' : (accounts?.find((a) => a.accountNo.startsWith('4') && a.active)?.accountNo ?? '400000');
    const revenueName = accounts?.find((a) => a.accountNo === revenueAccount)?.name ?? 'Revenue from Contracts with Customers';
    const entries: ACDOCALine[] = outstanding > 0 ? [
      { id: uniqueId('JL-POC'), docNo, period: recognisedPeriod, date, module: 'FI', docType: 'JE', accountNo: '118100', accountName: 'Unbilled Contract Assets — Revenue Recognised', costCenter: x.p.costCenter, debit: outstanding, credit: 0, currency: currentClient.currency, description: `IFRS 15 POC contract asset — ${x.p.projectName} (${(x.poc * 100).toFixed(1)}% complete)`, createdBy: currentUser.username, checkedBy: currentUser.canCheck ? currentUser.username : undefined, clientId: currentClient.id, reference: x.p.code },
      { id: uniqueId('JL-POC'), docNo, period: recognisedPeriod, date, module: 'FI', docType: 'JE', accountNo: revenueAccount, accountName: revenueName, costCenter: x.p.costCenter, debit: 0, credit: outstanding, currency: currentClient.currency, description: `Progress revenue on ${x.p.projectName} (POC ${(x.poc * 100).toFixed(1)}%)`, createdBy: currentUser.username, checkedBy: currentUser.canCheck ? currentUser.username : undefined, clientId: currentClient.id, reference: x.p.code },
    ] : [
      { id: uniqueId('JL-POC'), docNo, period: recognisedPeriod, date, module: 'FI', docType: 'JE', accountNo: revenueAccount, accountName: revenueName, costCenter: x.p.costCenter, debit: money(-outstanding), credit: 0, currency: currentClient.currency, description: `POC revenue correction — ${x.p.projectName}`, createdBy: currentUser.username, checkedBy: currentUser.canCheck ? currentUser.username : undefined, clientId: currentClient.id, reference: x.p.code },
      { id: uniqueId('JL-POC'), docNo, period: recognisedPeriod, date, module: 'FI', docType: 'JE', accountNo: '118100', accountName: 'Unbilled Contract Assets — Revenue Recognised', costCenter: x.p.costCenter, debit: 0, credit: money(-outstanding), currency: currentClient.currency, description: `Reduce contract asset — ${x.p.projectName}`, createdBy: currentUser.username, checkedBy: currentUser.canCheck ? currentUser.username : undefined, clientId: currentClient.id, reference: x.p.code },
    ];
    const ok = onAddJournalLines(entries);
    setFeedback(ok
      ? `${x.p.code}: recognised ₵${formatGHS(Math.abs(outstanding))} POC revenue via ${docNo} (${(x.poc * 100).toFixed(1)}% of ₵${formatGHS(x.p.contractValue)} contract). Contract asset/liability now feeds the IFRS 15 schedule and the statements.`
      : `${x.p.code}: the journal controls refused the POC posting (closed period, authority or duplicate). Nothing was posted.`);
  };

  const { save } = useDeskRecords<ProjectRecord>('projects', currentClient.id, 'project');

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    const record: ProjectRecord = {
      id: uniqueId('PRJ'), code: pCode.trim().toUpperCase(), projectName: pName.trim() || pCode, customerName: pCustomer.trim() || 'Unassigned',
      status: 'Active', contractValue: pContract, estimatedCost: pEstimated, startDate: localToday(), endDate: pEnd, costCenter: pCenter.trim() || 'CC-PRJ',
    };
    if (projects.some((p) => p.code === record.code)) { setFeedback(`Project code ${record.code} already exists in this workspace.`); return; }
    const saved = await save(record);
    setFeedback(saved ? `Project ${record.code} opened. Post costs against cost centre ${record.costCenter} or reference ${record.code}; invoice ${record.customerName} and both accrue here automatically.` : 'The project could not be saved on the server.');
    setShowModal(false);
  };

  const exportPortfolio = () => {
    downloadCsv(`${currentClient.code}_project_costing.csv`, [
      [`${currentClient.name} (${currentClient.code}) — Project Costing & Contracts (IFRS 15 POC)`],
      [],
      ['Project', 'Name', 'Customer', 'Status', 'Contract value', 'Estimated cost', 'Actual costs to date', 'POC %', 'Earned revenue (POC)', 'Billed to date (net)', 'Contract position (asset +/liab −)', 'Profit to date', 'Forecast margin %'],
      ...positions.map((x) => [x.p.code, x.p.projectName, x.p.customerName, x.p.status, x.p.contractValue, x.p.estimatedCost, x.costs, (x.poc * 100).toFixed(2), x.earned, x.billed, x.contractPosition, x.profitToDate, x.forecastMargin.toFixed(1)]),
      ['TOTAL', '', '', '', totals.contract, positions.reduce((s, x) => s + x.p.estimatedCost, 0), totals.costs, '', totals.earned, positions.reduce((s, x) => s + x.billed, 0), positions.reduce((s, x) => s + x.contractPosition, 0), totals.profit, ''],
    ]);
  };

  const readOnly = currentUser.role === 'auditor' || (currentUser.status ?? 'active') !== 'active';

  return (
    <div className="space-y-6" ref={detailRef}>
      <PageHeader
        kicker={`COST · Job & Contract Costing · ${currentClient.code}`}
        title="Project Costing & Contracts"
        desc="Job costing with IFRS 15 percentage-of-completion: costs accumulate from journals tagged with the project code or its cost centre; billings accumulate from invoices to the customer; POC revenue posts into the ledger as a contract asset/liability."
      >
        <button onClick={exportPortfolio} disabled={!positions.length} className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs disabled:opacity-50">
          <Download className="h-4 w-4" />
          <span>Export Excel (CSV)</span>
        </button>
        {!readOnly && (
          <button onClick={() => setShowModal(true)} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs">
            <Plus className="h-4 w-4" />
            <span>New Project / Contract</span>
          </button>
        )}
      </PageHeader>

      {feedback && (
        <div role="alert" className="rounded-xl border border-sky-300 bg-sky-50 p-3.5 text-xs font-bold text-[#0a4a6e]">{feedback}</div>
      )}
      {error && <div role="alert" className="rounded-xl border border-rose-300 bg-rose-50 p-3.5 text-xs font-bold text-rose-900">{error} <span className="font-semibold">Changes are saved on the firm&rsquo;s server.</span></div>}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Portfolio contract value" value={`₵${formatGHS(totals.contract)}`} sub={`${positions.length} active contracts`} />
        <Stat label="Costs accumulated to date" value={`₵${formatGHS(totals.costs)}`} sub="Direct journals on project codes & centres" />
        <Stat label="Earned revenue (POC)" value={`₵${formatGHS(totals.earned)}`} sub="Input measure: actual ÷ estimated cost" />
        <Stat label="Realised margin to date" value={`₵${formatGHS(totals.profit)}`} sub="Earned revenue less accumulated costs" tone={totals.profit < 0 ? 'text-rose-700' : 'text-emerald-700'} />
      </div>

      <Card title={`Contracts register (${positions.length})`} sub="Ledger-derived position of every project — expand a row for the IFRS 15 percentage-of-completion detail">
        {positions.length === 0 ? (
          <div className="rounded-xl border border-dashed border-sky-300 bg-sky-50/50 px-4 py-10 text-center">
            <FolderKanban className="mx-auto h-8 w-8 text-sky-300" />
            <p className="mt-2 text-xs font-bold text-[#082f4f]">No projects opened yet</p>
            <p className="mt-1 text-xs text-[#355875]">Create a project or contract above. Post costs against its cost centre or project code and bill its customer; the register computes everything else.</p>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-lg border border-sky-200">
            <table className="w-full min-w-[1100px] text-xs">
              <thead>
                <tr className="border-b border-sky-200 bg-sky-50/70">
                  <th className={thCls}>Project</th>
                  <th className={thCls}>Customer</th>
                  <th className={thCls}>Status</th>
                  <th className={thCls + ' text-right'}>Contract Value (₵)</th>
                  <th className={thCls + ' text-right'}>Cost to Date (₵)</th>
                  <th className={thCls + ' text-center'}>POC</th>
                  <th className={thCls + ' text-right'}>Earned Revenue (₵)</th>
                  <th className={thCls + ' text-right'}>Billed (Net) (₵)</th>
                  <th className={thCls + ' text-right'}>Contract Asset/(Liability) (₵)</th>
                  <th className={thCls + ' text-right'}>Profit to Date (₵)</th>
                  <th className={thCls + ' text-center'} data-print-hide>Actions</th>
                </tr>
              </thead>
              <tbody>
                {positions.map((x) => (
                  <tr key={x.p.id} className={rowCls}>
                    <td className={tdCls}>
                      <div className="font-mono font-bold text-[#855b00]">{x.p.code}</div>
                      <div className="font-bold text-[#082f4f]">{x.p.projectName}</div>
                      <div className="text-[10px] text-[#355875] font-mono">Cost centre {x.p.costCenter} · due {x.p.endDate}</div>
                    </td>
                    <td className={tdCls}>{x.p.customerName}</td>
                    <td className={tdCls}>
                      <Badge tone={x.p.status === 'Active' ? 'green' : x.p.status === 'Completed' ? 'slate' : x.p.status === 'Suspended' ? 'red' : 'amber'}>{x.p.status}</Badge>
                    </td>
                    <td className={numCls}>{formatGHS(x.p.contractValue)}</td>
                    <td className={numCls + (x.costs > x.p.estimatedCost ? ' font-black text-rose-700' : '')}>{formatGHS(x.costs)}</td>
                    <td className="px-3 py-2 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <div className="h-1.5 w-12 rounded bg-sky-100"><div className="h-1.5 rounded bg-[#315f91]" style={{ width: `${Math.min(100, x.poc * 100)}%` }} /></div>
                        <span className="font-mono text-[10.5px] font-bold text-[#082f4f]">{(x.poc * 100).toFixed(1)}%</span>
                      </div>
                    </td>
                    <td className={numCls}>{formatGHS(x.earned)}</td>
                    <td className={numCls}>{formatGHS(x.billed)}</td>
                    <td className={numCls + (x.contractPosition < 0 ? ' text-rose-700' : ' text-[#006f98]')}>{formatGHS(x.contractPosition)}</td>
                    <td className={numCls + (x.profitToDate < 0 ? ' font-black text-rose-700' : ' font-bold text-emerald-800')}>{formatGHS(x.profitToDate)}</td>
                    <td className="px-3 py-2 text-center" data-print-hide>
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => handleRecognisePoc(x)}
                          disabled={readOnly || isPeriodClosed || x.p.status !== 'Active'}
                          title={x.p.status !== 'Active' ? 'Only active contracts accrue POC revenue' : `Post ₵${formatGHS(x.earned - x.postedRevenue)} POC adjustment into the ledger`}
                          className="rounded bg-[#082f4f] px-2 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] disabled:opacity-40"
                        >
                          Recognise POC
                        </button>
                        <button
                          onClick={() => printModuleView({ title: `Project cost sheet — ${x.p.projectName}`, subtitle: `${x.p.code} · ${x.p.customerName} · ${currentClient.name}`, root: document.querySelector(`#pcard-${x.p.code}`) as HTMLElement | null ?? detailRef.current, orientation: 'landscape' })}
                          className="rounded border border-sky-300 bg-white px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50"
                        >
                          <Printer className="inline h-3 w-3" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Per-project working papers (also the precise print targets). */}
      {positions.map((x) => (
        <Card key={`card-${x.p.id}`} id={`pcard-${x.p.code}`} title={`Working paper — ${x.p.code} · ${x.p.projectName}`} sub={`IFRS 15 input measure · direct costs from the project code / cost centre · billings from invoices to ${x.p.customerName}`}>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 text-xs">
            <div className="rounded-lg bg-sky-50 p-3"><div className="text-[#355875] font-bold">Contract value</div><div className="font-black text-[#082f4f]">₵{formatGHS(x.p.contractValue)}</div></div>
            <div className="rounded-lg bg-sky-50 p-3"><div className="text-[#355875] font-bold">Budgeted cost</div><div className="font-black text-[#082f4f]">₵{formatGHS(x.p.estimatedCost)}</div><div className="text-[10.5px] text-[#355875]">Forecast margin {x.forecastMargin.toFixed(1)}%</div></div>
            <div className="rounded-lg bg-sky-50 p-3"><div className="text-[#355875] font-bold">Actual cost / POC</div><div className="font-black text-[#082f4f]">₵{formatGHS(x.costs)}</div><div className="text-[10.5px] text-[#355875]">{(x.poc * 100).toFixed(1)}% complete {x.costs > x.p.estimatedCost ? '· OVERRUN' : ''}</div></div>
            <div className="rounded-lg bg-sky-50 p-3"><div className="text-[#355875] font-bold">Earned vs billed</div><div className="font-black text-[#082f4f]">₵{formatGHS(x.earned)} / ₵{formatGHS(x.billed)}</div><div className="text-[10.5px] text-[#355875]">{x.contractPosition >= 0 ? `Contract asset ₵${formatGHS(x.contractPosition)}` : `Contract liability ₵${formatGHS(-x.contractPosition)}`}</div></div>
          </div>
          {recognisedPeriod && x.poc >= 1 && <p className="mt-2 text-[11px] font-bold text-[#855b00]">Contract 100% complete by the input measure — review actual vs budget and complete the contract before final settlement.</p>}
        </Card>
      ))}

      {/* New project modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleCreateProject} className="w-full max-w-lg rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Open Project / Contract</h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Project code</label>
                <input value={pCode} onChange={(e) => setPCode(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono font-bold text-[#855b00] outline-none" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Project / contract name</label>
                <input value={pName} onChange={(e) => setPName(e.target.value)} placeholder="Tailings Dam Phase 2" className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none" />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Customer (matches sales invoices)</label>
                <input value={pCustomer} onChange={(e) => setPCustomer(e.target.value)} placeholder="Exact invoice customer name" className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none" />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Cost centre (cost accumulation key)</label>
                <input value={pCenter} onChange={(e) => setPCenter(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono outline-none" />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Contract value (₵)</label>
                <input type="number" min="0" step="0.01" value={pContract} onChange={(e) => setPContract(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono outline-none" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Estimated total cost (₵)</label>
                <input type="number" min="0" step="0.01" value={pEstimated} onChange={(e) => setPEstimated(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-1.5 font-mono outline-none" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Target completion</label>
                <input type="date" value={pEnd} onChange={(e) => setPEnd(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none" required />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setShowModal(false)} disabled={saving} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" disabled={saving} className="rounded bg-[#082f4f] px-4 py-1.5 font-bold text-white disabled:opacity-50">{saving ? 'Saving…' : 'Open Project'}</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
