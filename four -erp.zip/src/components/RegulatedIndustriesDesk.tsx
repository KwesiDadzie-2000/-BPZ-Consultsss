'use client';

import { useMemo, useState } from 'react';
import type { ACDOCALine, ClientEntity, StockItem, UserAccount } from '../types/accounting';
import { Badge, Card, PageHeader, Stat, formatGHS, numCls, rowCls, tdCls, thCls } from './ui';
import { Download } from 'lucide-react';
import { uniqueId } from '../utils/ids';
import { localToday } from '../utils/periods';
import { downloadCsv } from '../utils/printReport';
import { profileForClientSector } from '../data/sectorProfiles';
import {
  GOLD_ROYALTY_BANDS_LI2588,
  DEFAULT_FUEL_LEVIES,
  computeMineralRoyalty,
  computePetroleumRoyalty,
  computeFuelLevies,
  buildEirSchedule,
  computeIfrs17Paa,
  computeIfrs17Gmm,
  computePensionNav,
  computeBiologicalMovement,
  explodeMrp,
  goldRoyaltyRate,
  type EirLoanInput,
  type FuelLevyComponent,
  type Ifrs17PaaInput,
} from '../utils/regulated';

type Tab = 'royalty' | 'petroleum' | 'fuel' | 'ifrs9' | 'ifrs17' | 'pension' | 'ias41' | 'mrp';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  stockItems: StockItem[];
  isPeriodClosed?: boolean;
  onAddJournalLines: (lines: ACDOCALine[]) => boolean;
}

function tabForSector(sector: string): Tab {
  const code = profileForClientSector(sector).sectorCode;
  if (code.startsWith('mining')) return 'royalty';
  if (code === 'oil_gas_upstream') return 'petroleum';
  if (code === 'oil_gas_downstream') return 'fuel';
  if (code.includes('bank') || code.includes('micro') || code.includes('fintech') || code.includes('financial')) return 'ifrs9';
  if (code.includes('insur')) return 'ifrs17';
  if (code.includes('pension')) return 'pension';
  if (code.includes('agric') || code.includes('fish') || code.includes('livestock')) return 'ias41';
  if (code.includes('manufact') || code.includes('agro_processing')) return 'mrp';
  return 'royalty';
}

const TABS: { id: Tab; label: string }[] = [
  { id: 'royalty', label: 'Mineral royalty' },
  { id: 'petroleum', label: 'Petroleum royalty' },
  { id: 'fuel', label: 'Fuel / ESLA levies' },
  { id: 'ifrs9', label: 'IFRS 9 EIR & ECL' },
  { id: 'ifrs17', label: 'IFRS 17 insurance' },
  { id: 'pension', label: 'IAS 26 pensions' },
  { id: 'ias41', label: 'IAS 41 biological' },
  { id: 'mrp', label: 'Manufacturing MRP' },
];

export function RegulatedIndustriesDesk({ currentClient, currentUser, lines, stockItems, isPeriodClosed = false, onAddJournalLines }: Props) {
  const [tab, setTab] = useState<Tab>(() => tabForSector(currentClient.sector));
  const [msg, setMsg] = useState<string | null>(null);
  const today = localToday();
  const period = today.slice(0, 7);
  const readOnly = currentUser.role === 'auditor' || currentUser.status !== 'active';

  const stamp = (docNo: string, extra: Partial<ACDOCALine> = {}): Omit<ACDOCALine, 'id' | 'accountNo' | 'accountName' | 'debit' | 'credit' | 'description'> => ({
    docNo, period, date: today, module: 'FI', docType: extra.docType ?? 'JE', costCenter: extra.costCenter ?? 'CC-OPS',
    currency: currentClient.currency, createdBy: currentUser.username, checkedBy: currentUser.canCheck ? currentUser.username : undefined,
    clientId: currentClient.id, reference: extra.reference,
  });

  const post = (entries: ACDOCALine[], okText: string) => {
    if (isPeriodClosed) { setMsg(`Period ${period} is closed — nothing posted.`); return; }
    if (readOnly) { setMsg('Your role is read-only.'); return; }
    const ok = onAddJournalLines(entries);
    setMsg(ok ? okText : 'The journal controls refused the posting (closed period, authority, duplicate or chart). Nothing was posted.');
  };

  /* ---- royalty ---- */
  const [mineral, setMineral] = useState<'gold' | 'bauxite' | 'manganese' | 'lithium' | 'other'>('gold');
  const [grossRev, setGrossRev] = useState(8_000_000);
  const [usdOz, setUsdOz] = useState(2650);
  const royalty = useMemo(() => computeMineralRoyalty({ mineral, grossRevenue: grossRev, usdPerOz: usdOz }), [mineral, grossRev, usdOz]);

  const postRoyalty = () => {
    const docNo = `ROY-${mineral.toUpperCase()}-${period}`;
    post([
      { ...stamp(docNo), id: uniqueId('JL-ROY'), accountNo: '507000', accountName: 'Mineral Royalty Expense (GRA)', debit: royalty.royalty, credit: 0, description: `${royalty.basis}` },
      { ...stamp(docNo), id: uniqueId('JL-ROY'), accountNo: '227000', accountName: 'Mineral Royalty & Sector Levies Payable', debit: 0, credit: royalty.royalty, description: `Royalty payable — remittance via Payment Desk` },
    ], `Royalty ₵${formatGHS(royalty.royalty)} (${royalty.ratePct}%) posted to 507000/227000. Remit from the Payment Desk.`);
  };

  /* ---- petroleum ---- */
  const [petGross, setPetGross] = useState(12_000_000);
  const [petRate, setPetRate] = useState(5);
  const [aoeRate, setAoeRate] = useState(0);
  const pet = useMemo(() => computePetroleumRoyalty({ grossProductionValue: petGross, royaltyRatePct: petRate, additionalOilEntitlementPct: aoeRate }), [petGross, petRate, aoeRate]);

  const postPetroleum = () => {
    const docNo = `PETROY-${period}`;
    const total = pet.totalStateTake;
    post([
      { ...stamp(docNo), id: uniqueId('JL-PET'), accountNo: '507000', accountName: 'Mineral Royalty Expense (GRA)', debit: total, credit: 0, description: `Petroleum royalty ${petRate}% + AOE ${aoeRate}% on production value ₵${formatGHS(pet.base)}` },
      { ...stamp(docNo), id: uniqueId('JL-PET'), accountNo: '227000', accountName: 'Mineral Royalty & Sector Levies Payable', debit: 0, credit: total, description: 'Petroleum state take payable' },
    ], `Petroleum state take ₵${formatGHS(total)} posted.`);
  };

  /* ---- fuel ---- */
  const [litres, setLitres] = useState(50_000);
  const [levyRates, setLevyRates] = useState<FuelLevyComponent[]>(DEFAULT_FUEL_LEVIES);
  const fuel = useMemo(() => computeFuelLevies(litres, levyRates), [litres, levyRates]);

  const postFuel = () => {
    const docNo = `ESLA-${period}`;
    post([
      { ...stamp(docNo), id: uniqueId('JL-ESLA'), accountNo: '506500', accountName: 'Energy Sector Levies (ESLA / NPA) Expense', debit: fuel.total, credit: 0, description: `ESLA/NPA levies on ${litres.toLocaleString()} litres` },
      { ...stamp(docNo), id: uniqueId('JL-ESLA'), accountNo: '228000', accountName: 'Energy Sector Levies Payable (ESLA / NPA)', debit: 0, credit: fuel.total, description: fuel.lines.map((l) => `${l.code} ₵${formatGHS(l.amount)}`).join(' · ') },
    ], `Fuel levies ₵${formatGHS(fuel.total)} posted to 506500/228000.`);
  };

  /* ---- IFRS 9 ---- */
  const [loan, setLoan] = useState<EirLoanInput>({
    id: 'LN-BOOK-1', borrower: 'SME Customer Ltd', principal: 500_000, feesNet: 7_500,
    annualContractualRatePct: 28, termMonths: 24, paymentsPerYear: 12, startDate: today,
    pd12Pct: 3, pdLifetimePct: 12, lgdPct: 45, stage: 1,
  });
  const eir = useMemo(() => buildEirSchedule(loan), [loan]);
  const nextEir = eir.rows.find((r) => !lines.some((l) => l.clientId === currentClient.id && l.docNo === `EIR-${loan.id}-P${r.n}`)) ?? eir.rows[0];

  const postEirInterest = () => {
    if (!nextEir) return;
    const docNo = `EIR-${loan.id}-P${nextEir.n}`;
    post([
      { ...stamp(docNo), id: uniqueId('JL-EIR'), accountNo: '111500', accountName: 'Loans and Advances to Customers (IFRS 9 amortised cost)', debit: nextEir.interest, credit: 0, description: `IFRS 9 EIR interest ${eir.eirAnnualPct}% p.a. — ${loan.borrower} P${nextEir.n}` },
      { ...stamp(docNo), id: uniqueId('JL-EIR'), accountNo: '419000', accountName: 'Interest Income on Loans and Advances (IFRS 9 EIR)', debit: 0, credit: nextEir.interest, description: `EIR unwind P${nextEir.n}` },
    ], `EIR interest ₵${formatGHS(nextEir.interest)} recognised (effective ${eir.eirAnnualPct}% p.a.).`);
  };
  const postEirReceipt = () => {
    if (!nextEir) return;
    const docNo = `EIR-RCPT-${loan.id}-P${nextEir.n}`;
    post([
      { ...stamp(docNo, { docType: 'PAY' }), id: uniqueId('JL-EIR'), accountNo: '100000', accountName: 'Cash at Bank — Operating Account (GHS)', debit: nextEir.instalment, credit: 0, description: `Instalment received — ${loan.borrower} P${nextEir.n}` },
      { ...stamp(docNo, { docType: 'PAY' }), id: uniqueId('JL-EIR'), accountNo: '111500', accountName: 'Loans and Advances to Customers (IFRS 9 amortised cost)', debit: 0, credit: nextEir.instalment, description: `Apply instalment to amortised-cost carrying amount` },
    ], `Instalment ₵${formatGHS(nextEir.instalment)} applied to the loan carrying amount.`);
  };
  const postEcl = () => {
    if (!nextEir) return;
    const booked = lines.filter((l) => l.clientId === currentClient.id && l.accountNo === '111600').reduce((s, l) => s + l.credit - l.debit, 0);
    const required = nextEir.ecl;
    const delta = Math.round((required - booked) * 100) / 100;
    if (Math.abs(delta) < 0.01) { setMsg('ECL allowance already equals the staged IFRS 9 requirement.'); return; }
    const docNo = `ECL-${loan.id}-${period}`;
    const loss = delta > 0;
    post([
      { ...stamp(docNo), id: uniqueId('JL-ECL'), accountNo: '690000', accountName: 'Impairment Loss on Non-Financial Assets', debit: loss ? delta : 0, credit: loss ? 0 : -delta, description: `IFRS 9 stage ${loan.stage} ECL true-up (${loan.borrower})` },
      { ...stamp(docNo), id: uniqueId('JL-ECL'), accountNo: '111600', accountName: 'ECL Allowance on Loans and Advances', debit: loss ? 0 : -delta, credit: loss ? delta : 0, description: `Stage ${loan.stage} PD ${loan.stage === 1 ? loan.pd12Pct : loan.pdLifetimePct}% × LGD ${loan.lgdPct}%` },
    ], `ECL allowance moved by ₵${formatGHS(Math.abs(delta))} to required ₵${formatGHS(required)} (stage ${loan.stage}).`);
  };

  /* ---- IFRS 17 ---- */
  const [paa, setPaa] = useState<Ifrs17PaaInput>({
    id: 'POL-001', product: 'Motor comprehensive (12 months)', coverageStart: `${period}-01`, coverageEnd: '',
    premiumsReceived: 240_000, acquisitionCosts: 24_000, expectedClaims: 150_000, actualClaims: 40_000,
    riskAdjustment: 8_000, coverageElapsedPct: 0.25, onerous: false,
  });
  const paaR = useMemo(() => computeIfrs17Paa(paa), [paa]);
  const gmm = useMemo(() => computeIfrs17Gmm({ fulfilmentCashFlows: 800_000, riskAdjustment: 40_000, csmOpening: 120_000, coverageUnitsThisPeriod: 1, coverageUnitsRemaining: 4, financeRatePct: 8 }), []);

  const postPaaRevenue = () => {
    const docNo = `IFRS17-REV-${paa.id}-${period}`;
    post([
      { ...stamp(docNo), id: uniqueId('JL-17'), accountNo: '231000', accountName: 'Insurance Contract Liabilities (IFRS 17)', debit: paaR.insuranceRevenue, credit: 0, description: `PAA revenue — ${paa.product} (${(paa.coverageElapsedPct * 100).toFixed(0)}% elapsed)` },
      { ...stamp(docNo), id: uniqueId('JL-17'), accountNo: '415000', accountName: 'Insurance Premium Income (IFRS 17)', debit: 0, credit: paaR.insuranceRevenue, description: `IFRS 17 insurance revenue (PAA)` },
    ], `IFRS 17 PAA revenue ₵${formatGHS(paaR.insuranceRevenue)} released from LRC.`);
  };
  const postPaaClaims = () => {
    const docNo = `IFRS17-CLM-${paa.id}-${period}`;
    post([
      { ...stamp(docNo), id: uniqueId('JL-17'), accountNo: '585000', accountName: 'Insurance Claims & Benefits Paid (IFRS 17)', debit: paaR.insuranceServiceExpense, credit: 0, description: `PAA service expense — claims + acquisition amortisation + onerous` },
      { ...stamp(docNo), id: uniqueId('JL-17'), accountNo: '231000', accountName: 'Insurance Contract Liabilities (IFRS 17)', debit: 0, credit: paaR.insuranceServiceExpense, description: `LIC / loss component` },
    ], `IFRS 17 service expense ₵${formatGHS(paaR.insuranceServiceExpense)} posted.`);
  };

  /* ---- pension ---- */
  const [units, setUnits] = useState(10_000);
  const [ee, setEe] = useState(40_000);
  const [er, setEr] = useState(40_000);
  const [invFv, setInvFv] = useState(1_250_000);
  const [othAst, setOthAst] = useState(80_000);
  const [penPay, setPenPay] = useState(15_000);
  const nav = useMemo(() => computePensionNav([{ id: 'm', name: 'Scheme', units, employeeContribution: ee, employerContribution: er }], invFv, othAst, penPay), [units, ee, er, invFv, othAst, penPay]);

  const postPensionContrib = () => {
    const total = nav.contributions;
    const docNo = `PEN-CONT-${period}`;
    post([
      { ...stamp(docNo), id: uniqueId('JL-PEN'), accountNo: '100000', accountName: 'Cash at Bank — Operating Account (GHS)', debit: total, credit: 0, description: 'Member + sponsor contributions received' },
      { ...stamp(docNo), id: uniqueId('JL-PEN'), accountNo: '218000', accountName: 'Pension Member Benefits Payable (IAS 26)', debit: 0, credit: total, description: `Allocated to member accounts (${units.toLocaleString()} units)` },
    ], `Contributions ₵${formatGHS(total)} allocated. Unit price ₵${formatGHS(nav.unitPrice)}.`);
  };

  /* ---- IAS 41 ---- */
  const [bioOpen, setBioOpen] = useState(180_000);
  const [bioAdd, setBioAdd] = useState(20_000);
  const [bioHarvest, setBioHarvest] = useState(50_000);
  const [bioClose, setBioClose] = useState(175_000);
  const [bioCts, setBioCts] = useState(5_000);
  const bio = useMemo(() => computeBiologicalMovement(bioOpen, bioAdd, bioHarvest, bioClose, bioCts), [bioOpen, bioAdd, bioHarvest, bioClose, bioCts]);

  const postBio = () => {
    const gain = bio.fairValueGain;
    if (Math.abs(gain) < 0.01) { setMsg('No fair-value movement to post.'); return; }
    const docNo = `IAS41-${period}`;
    const up = gain > 0;
    post([
      { ...stamp(docNo), id: uniqueId('JL-41'), accountNo: '124000', accountName: 'Biological Assets — Crops & Livestock (IAS 41)', debit: up ? gain : 0, credit: up ? 0 : -gain, description: 'IAS 41 FV less costs to sell — period movement' },
      { ...stamp(docNo), id: uniqueId('JL-41'), accountNo: '417000', accountName: 'Fair Value Gains on Biological Assets (IAS 41)', debit: up ? 0 : -gain, credit: up ? gain : 0, description: 'P&L — biological transformation' },
    ], `IAS 41 fair-value ${up ? 'gain' : 'loss'} ₵${formatGHS(Math.abs(gain))} posted.`);
  };

  /* ---- MRP ---- */
  const [parent, setParent] = useState('FG-RACE');
  const [mrpQty, setMrpQty] = useState(100);
  const mrp = useMemo(() => explodeMrp(parent, mrpQty, [], stockItems.map((s) => ({ itemCode: s.itemCode, quantityOnHand: s.quantityOnHand }))), [parent, mrpQty, stockItems]);

  const inputCls = 'mt-1 w-full rounded border border-sky-300 bg-white px-2 py-1.5 text-xs font-semibold text-[#082f4f]';

  return (
    <div className="space-y-5">
      <PageHeader
        kicker={`REG · Native industry calculators · ${currentClient.code}`}
        title="Regulated Industries — Native Measurement"
        desc="Banks, insurers, pension funds, miners, oil & gas, fuel retail, agriculture and manufacturers: royalties, levies, IFRS 9 EIR, IFRS 17 PAA/GMM, IAS 26 NAV, IAS 41 fair value and MRP are computed here and posted through the same journal controls as every other desk."
      >
        <Badge tone="fi">{profileForClientSector(currentClient.sector).manualRef}</Badge>
      </PageHeader>
      {msg && <div role="alert" className="rounded-xl border border-sky-300 bg-sky-50 p-3 text-xs font-bold text-[#0a4a6e]">{msg}</div>}

      <div className="flex flex-wrap gap-1.5">
        {TABS.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`rounded-lg px-3 py-1.5 text-[11px] font-bold ${tab === t.id ? 'bg-[#082f4f] text-white' : 'border border-sky-300 bg-white text-[#082f4f] hover:bg-sky-50'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'royalty' && (
        <Card title="Mineral royalty (L.I. 2588 sliding scale)" sub="Gold is price-linked; other minerals default to 5% of gross revenue. Override the rate if the concession agreement differs.">
          <div className="grid gap-3 sm:grid-cols-4 text-xs">
            <label className="font-bold text-[#355875]">Mineral
              <select value={mineral} onChange={(e) => setMineral(e.target.value as typeof mineral)} className={inputCls}>
                <option value="gold">Gold</option><option value="bauxite">Bauxite</option><option value="manganese">Manganese</option><option value="lithium">Lithium</option><option value="other">Other</option>
              </select>
            </label>
            <label className="font-bold text-[#355875]">Gross revenue (₵)<input type="number" value={grossRev} onChange={(e) => setGrossRev(Number(e.target.value))} className={inputCls} /></label>
            {mineral === 'gold' && <label className="font-bold text-[#355875]">Gold price (USD/oz)<input type="number" value={usdOz} onChange={(e) => setUsdOz(Number(e.target.value))} className={inputCls} /></label>}
            <div className="rounded-lg bg-sky-50 p-3"><div className="text-[#355875]">Royalty due</div><div className="font-black text-[#082f4f]">₵{formatGHS(royalty.royalty)}</div><div className="text-[10.5px]">{royalty.ratePct}% · {royalty.basis}</div></div>
          </div>
          {mineral === 'gold' && (
            <table className="mt-3 w-full text-xs">
              <thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Gold USD/oz up to</th><th className={thCls}>Rate</th><th className={thCls}>Applies</th></tr></thead>
              <tbody>{GOLD_ROYALTY_BANDS_LI2588.map((b) => (
                <tr key={String(b.upToUsdPerOz)} className={rowCls}>
                  <td className={tdCls}>{b.upToUsdPerOz ?? 'and above'}</td>
                  <td className={numCls}>{b.ratePct}%</td>
                  <td className={tdCls}>{goldRoyaltyRate(usdOz) === b.ratePct ? '← current price' : ''}</td>
                </tr>
              ))}</tbody>
            </table>
          )}
          <button onClick={postRoyalty} disabled={readOnly} className="mt-3 rounded-lg bg-[#082f4f] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">Post royalty journal (507000 / 227000)</button>
        </Card>
      )}

      {tab === 'petroleum' && (
        <Card title="Petroleum royalty & additional oil entitlement" sub="Upstream production-sharing / royalty — rates follow the petroleum agreement; defaults 5% royalty.">
          <div className="grid gap-3 sm:grid-cols-4 text-xs">
            <label className="font-bold text-[#355875]">Gross production value (₵)<input type="number" value={petGross} onChange={(e) => setPetGross(Number(e.target.value))} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Royalty %<input type="number" step="0.1" value={petRate} onChange={(e) => setPetRate(Number(e.target.value))} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">AOE %<input type="number" step="0.1" value={aoeRate} onChange={(e) => setAoeRate(Number(e.target.value))} className={inputCls} /></label>
            <div className="rounded-lg bg-sky-50 p-3"><div className="text-[#355875]">State take</div><div className="font-black text-[#082f4f]">₵{formatGHS(pet.totalStateTake)}</div><div className="text-[10.5px]">Royalty ₵{formatGHS(pet.royalty)} · AOE ₵{formatGHS(pet.additionalOilEntitlement)}</div></div>
          </div>
          <button onClick={postPetroleum} disabled={readOnly} className="mt-3 rounded-lg bg-[#082f4f] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">Post petroleum royalty</button>
        </Card>
      )}

      {tab === 'fuel' && (
        <Card title="NPA / ESLA fuel levies (per litre)" sub="Defaults are 2026 working rates — replace them from the current NPA price build-up before you file. Volume × rate posts as a payable.">
          <label className="text-xs font-bold text-[#355875]">Litres sold / lifted<input type="number" value={litres} onChange={(e) => setLitres(Number(e.target.value))} className={inputCls + ' max-w-xs'} /></label>
          <table className="mt-3 w-full text-xs">
            <thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Levy</th><th className={thCls}>GHS / litre</th><th className={thCls}>Amount (₵)</th></tr></thead>
            <tbody>
              {fuel.lines.map((l, i) => (
                <tr key={l.code} className={rowCls}>
                  <td className={tdCls}>{l.label}</td>
                  <td className={tdCls}><input type="number" step="0.01" value={levyRates[i].ratePerLitre} onChange={(e) => setLevyRates((prev) => prev.map((c, j) => j === i ? { ...c, ratePerLitre: Number(e.target.value) } : c))} className="w-24 rounded border border-sky-300 px-2 py-1 font-mono" /></td>
                  <td className={numCls}>{formatGHS(l.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-2 flex items-center justify-between text-xs font-bold"><span>Total levies ₵{formatGHS(fuel.total)}</span>
            <button onClick={postFuel} disabled={readOnly} className="rounded-lg bg-[#082f4f] px-3 py-2 text-white disabled:opacity-40">Post ESLA payable (506500 / 228000)</button></div>
        </Card>
      )}

      {tab === 'ifrs9' && (
        <Card title="IFRS 9 amortised-cost loans (banks & microfinance)" sub="Effective interest is solved from net amount advanced vs contractual instalments. Staged ECL = carrying × PD × LGD.">
          <div className="grid gap-3 sm:grid-cols-4 text-xs">
            <label className="font-bold text-[#355875]">Borrower<input value={loan.borrower} onChange={(e) => setLoan({ ...loan, borrower: e.target.value })} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Principal (₵)<input type="number" value={loan.principal} onChange={(e) => setLoan({ ...loan, principal: Number(e.target.value) })} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Fees / costs (₵)<input type="number" value={loan.feesNet} onChange={(e) => setLoan({ ...loan, feesNet: Number(e.target.value) })} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Contractual % p.a.<input type="number" step="0.1" value={loan.annualContractualRatePct} onChange={(e) => setLoan({ ...loan, annualContractualRatePct: Number(e.target.value) })} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Term (months)<input type="number" value={loan.termMonths} onChange={(e) => setLoan({ ...loan, termMonths: Number(e.target.value) })} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Stage
              <select value={loan.stage} onChange={(e) => setLoan({ ...loan, stage: Number(e.target.value) as 1 | 2 | 3 })} className={inputCls}>
                <option value={1}>1 — 12-month ECL</option><option value={2}>2 — lifetime ECL</option><option value={3}>3 — credit-impaired</option>
              </select>
            </label>
            <label className="font-bold text-[#355875]">PD 12-month %<input type="number" step="0.1" value={loan.pd12Pct} onChange={(e) => setLoan({ ...loan, pd12Pct: Number(e.target.value) })} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">LGD %<input type="number" step="0.1" value={loan.lgdPct} onChange={(e) => setLoan({ ...loan, lgdPct: Number(e.target.value) })} className={inputCls} /></label>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="Effective rate (annualised)" value={`${eir.eirAnnualPct}%`} sub={`vs contractual ${loan.annualContractualRatePct}%`} />
            <Stat label="Contractual instalment" value={`₵${formatGHS(eir.instalment)}`} />
            <Stat label="Next interest (EIR)" value={`₵${formatGHS(nextEir?.interest ?? 0)}`} />
            <Stat label="Required ECL" value={`₵${formatGHS(nextEir?.ecl ?? 0)}`} sub={`Stage ${loan.stage}`} />
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <button onClick={postEirInterest} disabled={readOnly} className="rounded-lg bg-[#082f4f] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">Recognise EIR interest</button>
            <button onClick={postEirReceipt} disabled={readOnly} className="rounded-lg border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f]">Apply instalment receipt</button>
            <button onClick={postEcl} disabled={readOnly} className="rounded-lg border border-amber-400 bg-amber-50 px-3 py-2 text-xs font-bold text-[#855b00]">True-up staged ECL</button>
            <button onClick={() => downloadCsv(`${currentClient.code}_ifrs9_eir.csv`, [['n', 'date', 'opening', 'interest', 'instalment', 'closing', 'ecl'], ...eir.rows.map((r) => [r.n, r.date, r.opening, r.interest, r.instalment, r.closing, r.ecl])])} className="rounded-lg border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f]"><Download className="mr-1 inline h-3.5 w-3.5" />Excel</button>
          </div>
          <div className="mt-3 max-h-64 overflow-auto">
            <table className="w-full text-xs">
              <thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>n</th><th className={thCls}>Date</th><th className={thCls}>Opening</th><th className={thCls}>EIR interest</th><th className={thCls}>Instalment</th><th className={thCls}>Closing</th><th className={thCls}>ECL</th></tr></thead>
              <tbody>{eir.rows.slice(0, 24).map((r) => (
                <tr key={r.n} className={rowCls}><td className={tdCls}>{r.n}</td><td className={tdCls}>{r.date}</td><td className={numCls}>{formatGHS(r.opening)}</td><td className={numCls}>{formatGHS(r.interest)}</td><td className={numCls}>{formatGHS(r.instalment)}</td><td className={numCls}>{formatGHS(r.closing)}</td><td className={numCls}>{formatGHS(r.ecl)}</td></tr>
              ))}</tbody>
            </table>
          </div>
        </Card>
      )}

      {tab === 'ifrs17' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Premium Allocation Approach (PAA)" sub="Default for contracts of 12 months or less. Revenue = premiums × coverage elapsed.">
            <div className="grid grid-cols-2 gap-3 text-xs">
              <label className="font-bold text-[#355875]">Premiums received<input type="number" value={paa.premiumsReceived} onChange={(e) => setPaa({ ...paa, premiumsReceived: Number(e.target.value) })} className={inputCls} /></label>
              <label className="font-bold text-[#355875]">Acquisition costs<input type="number" value={paa.acquisitionCosts} onChange={(e) => setPaa({ ...paa, acquisitionCosts: Number(e.target.value) })} className={inputCls} /></label>
              <label className="font-bold text-[#355875]">Actual claims<input type="number" value={paa.actualClaims} onChange={(e) => setPaa({ ...paa, actualClaims: Number(e.target.value) })} className={inputCls} /></label>
              <label className="font-bold text-[#355875]">Coverage elapsed %<input type="number" step="1" value={Math.round(paa.coverageElapsedPct * 100)} onChange={(e) => setPaa({ ...paa, coverageElapsedPct: Number(e.target.value) / 100 })} className={inputCls} /></label>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
              <Stat label="LRC" value={`₵${formatGHS(paaR.lrc)}`} /><Stat label="LIC" value={`₵${formatGHS(paaR.lic)}`} />
              <Stat label="Insurance revenue" value={`₵${formatGHS(paaR.insuranceRevenue)}`} /><Stat label="Service expense" value={`₵${formatGHS(paaR.insuranceServiceExpense)}`} />
            </div>
            <div className="mt-3 flex gap-2">
              <button onClick={postPaaRevenue} disabled={readOnly} className="rounded-lg bg-[#082f4f] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">Post insurance revenue</button>
              <button onClick={postPaaClaims} disabled={readOnly} className="rounded-lg border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f]">Post service expense</button>
            </div>
          </Card>
          <Card title="General Measurement Model — CSM roll" sub="Fulfilment cash flows + risk adjustment + contractual service margin. CSM is released in proportion to coverage units.">
            <div className="grid grid-cols-2 gap-2 text-xs">
              <Stat label="CSM opening" value={`₵${formatGHS(gmm.csmOpening)}`} /><Stat label="Finance unwind" value={`₵${formatGHS(gmm.financeUnwind)}`} />
              <Stat label="CSM released (revenue)" value={`₵${formatGHS(gmm.csmRelease)}`} /><Stat label="CSM closing / liability" value={`₵${formatGHS(gmm.csmClosing)} / ₵${formatGHS(gmm.liability)}`} />
            </div>
            <p className="mt-2 text-[11px] text-[#355875]">Post the CSM release through the IFRS Schedules Desk or as a journal Dr 233000 / Cr 415000. Long-duration life books still need an actuary&apos;s fulfilment cash flows; this roll is the accounting engine those cash flows feed.</p>
          </Card>
        </div>
      )}

      {tab === 'pension' && (
        <Card title="IAS 26 pension fund — net assets available for benefits" sub="Contributions, investments at fair value, unitised NAV. Member benefits payable is the control account.">
          <div className="grid gap-3 sm:grid-cols-3 text-xs">
            <label className="font-bold text-[#355875]">Units in issue<input type="number" value={units} onChange={(e) => setUnits(Number(e.target.value))} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Employee contributions<input type="number" value={ee} onChange={(e) => setEe(Number(e.target.value))} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Sponsor contributions<input type="number" value={er} onChange={(e) => setEr(Number(e.target.value))} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Investments at FV<input type="number" value={invFv} onChange={(e) => setInvFv(Number(e.target.value))} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Other assets<input type="number" value={othAst} onChange={(e) => setOthAst(Number(e.target.value))} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Payables<input type="number" value={penPay} onChange={(e) => setPenPay(Number(e.target.value))} className={inputCls} /></label>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="NAV" value={`₵${formatGHS(nav.nav)}`} /><Stat label="Unit price" value={`₵${formatGHS(nav.unitPrice)}`} />
            <Stat label="Contributions this period" value={`₵${formatGHS(nav.contributions)}`} /><Stat label="Assets" value={`₵${formatGHS(nav.assets)}`} />
          </div>
          <button onClick={postPensionContrib} disabled={readOnly} className="mt-3 rounded-lg bg-[#082f4f] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">Post contributions (bank / member benefits)</button>
        </Card>
      )}

      {tab === 'ias41' && (
        <Card title="IAS 41 biological assets — fair value less costs to sell" sub="Crops, livestock, tree crops. Period movement goes through P&L; harvest transfers to IAS 2 inventory at FV less costs to sell.">
          <div className="grid gap-3 sm:grid-cols-5 text-xs">
            <label className="font-bold text-[#355875]">Opening FV<input type="number" value={bioOpen} onChange={(e) => setBioOpen(Number(e.target.value))} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Additions<input type="number" value={bioAdd} onChange={(e) => setBioAdd(Number(e.target.value))} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Harvest at FV<input type="number" value={bioHarvest} onChange={(e) => setBioHarvest(Number(e.target.value))} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Closing FV (gross)<input type="number" value={bioClose} onChange={(e) => setBioClose(Number(e.target.value))} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Costs to sell<input type="number" value={bioCts} onChange={(e) => setBioCts(Number(e.target.value))} className={inputCls} /></label>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-3">
            <Stat label="Closing FV less CTS" value={`₵${formatGHS(bio.closing)}`} /><Stat label="Fair-value gain / (loss)" value={`₵${formatGHS(bio.fairValueGain)}`} tone={bio.fairValueGain < 0 ? 'text-rose-700' : 'text-emerald-700'} />
            <Stat label="Harvested (to IAS 2)" value={`₵${formatGHS(bio.harvest)}`} />
          </div>
          <button onClick={postBio} disabled={readOnly} className="mt-3 rounded-lg bg-[#082f4f] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">Post FV movement (124000 / 417000)</button>
        </Card>
      )}

      {tab === 'mrp' && (
        <Card title="Manufacturing MRP — BOM explosion vs stock on hand" sub="Enter a finished-goods code and planned quantity. Shortage lines are the purchase requisition the Production Desk already consumes.">
          <div className="grid gap-3 sm:grid-cols-3 text-xs">
            <label className="font-bold text-[#355875]">Parent item code<input value={parent} onChange={(e) => setParent(e.target.value)} className={inputCls} /></label>
            <label className="font-bold text-[#355875]">Planned output qty<input type="number" value={mrpQty} onChange={(e) => setMrpQty(Number(e.target.value))} className={inputCls} /></label>
            <Stat label="Components" value={mrp.lines.length} sub={mrp.allCovered ? 'All covered' : 'Shortages exist'} />
          </div>
          <p className="mt-2 text-[11px] text-[#355875]">Load the Bill of Materials on the BOM desk, then explode here. Shortages are covered by raising a purchase order on Procurement — the Production Desk already refuses issues that would take stock negative.</p>
          {mrp.lines.length === 0 && <p className="mt-2 text-xs text-[#355875]">No BOM lines in this view (BOMs live on the server-side production desk). Open Bill of Materials, then Production, to run the live explosion against on-hand stock.</p>}
        </Card>
      )}
    </div>
  );
}
