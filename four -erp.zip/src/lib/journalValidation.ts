import type { ACDOCALine } from "@/types/accounting";

const toMinor = (n: number) => Math.round(n * 100);

export interface JournalValidationContext {
  /** Client ids the session user may post to (owner: all; others: their own). */
  allowedClientIds: number[];
  /**
   * Frozen periods as `${clientId}:${period}` keys (e.g. "2:2026-03"). Periods are
   * closed per entity — a period frozen for one client must never block another.
   */
  closedPeriodKeys: Set<string>;
  /** Account numbers that exist in the chart of accounts. */
  coaAccountNos: Set<string>;
  /**
   * Optional fine-grained account check: is `accountNo` an ACTIVE account that is
   * visible to `clientId` (firm master or that entity's own tailored account)?
   * When supplied it is applied in addition to `coaAccountNos`.
   */
  isAccountPostable?: (accountNo: string, clientId: number) => boolean;
}

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const ISO_PERIOD = /^\d{4}-(0[1-9]|1[0-2])$/;
const ISO_CURRENCY = /^[A-Z]{3}$/;

/** True for a real calendar date in YYYY-MM-DD form (rejects 2026-02-30, "garbage", etc.). */
export function isValidIsoDate(value: unknown): value is string {
  if (typeof value !== "string" || !ISO_DATE.test(value)) return false;
  const [y, m, d] = value.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

export function isValidPeriod(value: unknown): value is string {
  return typeof value === "string" && ISO_PERIOD.test(value);
}

/**
 * Server-side posting validation: tenant ownership, open periods, chart-of-accounts
 * existence, non-negative finite amounts, and per-document double-entry balance in
 * minor units. Returns the first violation found, or null when the batch is valid.
 */
/** clientId → functional currency, for the maker-limit rule in `validateMakerChecker`. */
export function functionalCurrencyMap(
  rows: readonly { id: number; currency: string | null | undefined }[],
): Map<number | null, string> {
  const map = new Map<number | null, string>();
  for (const row of rows) map.set(row.id, String(row.currency || 'GHS').toUpperCase());
  return map;
}

export interface JournalLineIdentity {
  id: string;
  docNo: string;
  period: string;
  date: string;
  module: string;
  docType: string;
  accountNo: string;
  accountName: string;
  costCenter?: string | null;
  debit: number;
  credit: number;
  currency: string;
  description: string;
  createdBy: string;
  checkedBy?: string | null;
  isReversed?: boolean;
  reference?: string | null;
  clientId: number;
}

/** Canonical content identity used for replay detection; amounts compare in cents. */
export function journalLinesFingerprint(lines: readonly JournalLineIdentity[]): string {
  return JSON.stringify(lines.map((line) => ({
    id: line.id,
    docNo: line.docNo,
    period: line.period,
    date: line.date,
    module: line.module,
    docType: line.docType,
    accountNo: line.accountNo,
    accountName: line.accountName,
    costCenter: line.costCenter ?? null,
    debitMinor: toMinor(line.debit),
    creditMinor: toMinor(line.credit),
    currency: line.currency,
    description: line.description,
    createdBy: line.createdBy,
    checkedBy: line.checkedBy ?? null,
    isReversed: line.isReversed ?? false,
    reference: line.reference ?? null,
    clientId: line.clientId,
  })).sort((a, b) => a.id.localeCompare(b.id)));
}

export function sameJournalLines(existing: readonly JournalLineIdentity[], incoming: readonly JournalLineIdentity[]): boolean {
  return journalLinesFingerprint(existing) === journalLinesFingerprint(incoming);
}

export function validateJournalLines(lines: ACDOCALine[], ctx: JournalValidationContext): string | null {
  if (!Array.isArray(lines) || !lines.length) return "No journal lines provided.";
  if (lines.some((line) => !line || typeof line.id !== 'string' || !line.id.trim() || typeof line.docNo !== 'string' || !line.docNo.trim())) return 'Every journal line needs an id and document number.';
  if (new Set(lines.map((line) => line.id)).size !== lines.length) return 'Duplicate journal line ids are not allowed.';
  for (const l of lines) {
    if (!ctx.allowedClientIds.includes(l.clientId)) return "Transaction belongs to a different client.";
    if (!isValidPeriod(l.period)) return `Document ${l.docNo}: "${String(l.period)}" is not a valid accounting period (YYYY-MM).`;
    if (!isValidIsoDate(l.date)) return `Document ${l.docNo}: "${String(l.date)}" is not a valid posting date (YYYY-MM-DD).`;
    if (l.date.slice(0, 7) !== l.period) return `Document ${l.docNo}: the posting date must fall within its accounting period.`;
    if (ctx.closedPeriodKeys.has(`${l.clientId}:${l.period}`)) return `Period ${l.period} is closed and frozen for this entity.`;
    if (typeof l.currency !== "string" || !ISO_CURRENCY.test(l.currency)) return `Document ${l.docNo}: currency must be an ISO 4217 code (e.g. GHS).`;
    if (typeof l.accountNo !== "string" || !ctx.coaAccountNos.has(l.accountNo)) return `Account ${l.accountNo} does not exist in the chart of accounts.`;
    if (ctx.isAccountPostable && !ctx.isAccountPostable(l.accountNo, l.clientId)) {
      return `Account ${l.accountNo} is inactive or not available to this entity — postings to it are blocked.`;
    }
    if (typeof l.debit !== "number" || typeof l.credit !== "number" || !Number.isFinite(l.debit) || !Number.isFinite(l.credit) || l.debit < 0 || l.credit < 0) {
      return "Invalid amounts.";
    }
    const dr = toMinor(l.debit);
    const cr = toMinor(l.credit);
    if (![dr, cr].every(Number.isSafeInteger)) return 'Amounts exceed the safe accounting range.';
    if (Math.abs(l.debit * 100 - dr) > 0.000001 || Math.abs(l.credit * 100 - cr) > 0.000001) return 'Amounts must have no more than two decimal places.';
    // One-sided lines only: a line that is both debited and credited (or neither)
    // nets to nothing on its own and hides the true gross movement of the account.
    if (dr > 0 && cr > 0) return `Document ${l.docNo}: a journal line must be either a debit or a credit, not both.`;
    if (dr === 0 && cr === 0) return `Document ${l.docNo}: zero-value journal lines are not allowed.`;
  }
  const byDoc = new Map<string, { dr: number; cr: number; n: number; period: string; date: string; currency: string; maker: string; checker: string | null }>();
  for (const l of lines) {
    const key = `${l.clientId}:${l.docNo}`;
    const agg = byDoc.get(key) ?? { dr: 0, cr: 0, n: 0, period: l.period, date: l.date, currency: l.currency, maker: l.createdBy, checker: l.checkedBy || null };
    agg.dr += toMinor(l.debit);
    agg.cr += toMinor(l.credit);
    agg.n += 1;
    // Document header integrity: one period, one posting date, one currency and one
    // maker per document — mixed values would let part of a document escape a
    // period freeze or a currency revaluation and break the audit trail.
    if (l.period !== agg.period) return `Document ${l.docNo} mixes accounting periods (${agg.period} and ${l.period}).`;
    if (l.date !== agg.date) return `Document ${l.docNo} mixes posting dates (${agg.date} and ${l.date}).`;
    if (l.currency !== agg.currency) return `Document ${l.docNo} mixes currencies (${agg.currency} and ${l.currency}); post one document per currency.`;
    if (l.createdBy !== agg.maker) return `Document ${l.docNo} names more than one maker.`;
    if ((l.checkedBy || null) !== agg.checker) return `Document ${l.docNo} has inconsistent checker identities.`;
    if (!Number.isSafeInteger(agg.dr) || !Number.isSafeInteger(agg.cr)) return 'Document totals exceed the safe accounting range.';
    byDoc.set(key, agg);
  }
  for (const [key, agg] of byDoc) {
    const docNo = key.split(":")[1];
    if (agg.n < 2) return `Document ${docNo} needs at least two lines (double entry).`;
    if (agg.dr <= 0 || agg.dr !== agg.cr) return `Document ${docNo} is not balanced (Dr = Cr required).`;
  }
  return null;
}

/** True when every line of the batch belongs to a single client (entity-private documents). */
export function isSingleClient(lines: ACDOCALine[]): boolean {
  return new Set(lines.map((l) => l.clientId)).size === 1;
}

export interface PostingUserRecord {
  username: string;
  role: string;
  makerLimit: number;
  canCheck: boolean;
  status?: string | null;
  clientId?: number | null;
  canPostJournals?: boolean;
}

export interface MakerCheckerContext {
  /** The session user posting the batch. */
  username: string;
  /** The session user's posting threshold in major units (0 = no threshold set). */
  makerLimit: number;
  /** Known user accounts by username — used to resolve the MAKER's own limit and to vet checkers. */
  users?: Map<string, PostingUserRecord>;
  /**
   * Each entity's FUNCTIONAL currency, keyed by clientId. A maker limit is
   * expressed in that currency; comparing it numerically to a foreign-currency
   * document would let a large GBP/USD entry escape escalation on a GHS entity
   * (or vice versa). When supplied, a document denominated in any other currency
   * always requires an independent authorised checker, whatever the amount.
   */
  functionalCurrencies?: Map<number | null, string>;
}

/** True when the account may act as an independent checker (approver). */
export function isAuthorisedChecker(user: PostingUserRecord | undefined | null): boolean {
  if (!user) return false;
  if (user.status && user.status !== "active") return false;
  return user.role === "owner" || user.canCheck === true;
}

export interface PostingIdentityContext {
  /** The signed-in user that submitted the request. */
  session: PostingUserRecord;
  /** Known user accounts by username. */
  users: Map<string, PostingUserRecord>;
}

/**
 * Binds the document's maker / checker stamps to real, authorised identities:
 *  • the signed-in user must be the document's maker, OR its named checker
 *    (an approver posting a request on the maker's behalf);
 *  • the maker must be a known account;
 *  • a named checker must be a known, active account that is authorised to check.
 * Without this a caller could stamp any `createdBy` and sidestep the maker limit.
 */
export function validatePostingIdentity(lines: ACDOCALine[], ctx: PostingIdentityContext): string | null {
  if (ctx.session.status && ctx.session.status !== 'active') return 'Your posting authority is restricted.';
  if (ctx.session.canPostJournals === false) return 'You do not have permission to post journals.';
  const seen = new Set<string>();
  for (const l of lines) {
    const key = `${l.clientId}:${l.docNo}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const maker = typeof l.createdBy === "string" ? l.createdBy.trim() : "";
    const checker = typeof l.checkedBy === "string" && l.checkedBy.trim() ? l.checkedBy.trim() : null;
    if (!maker) return `Document ${l.docNo} has no maker (createdBy).`;
    if (!ctx.users.has(maker)) return `Document ${l.docNo}: maker "${maker}" is not a known user account.`;
    const makerUser = ctx.users.get(maker)!;
    if (!Number.isFinite(makerUser.makerLimit) || makerUser.makerLimit <= 0) return `Document ${l.docNo}: the maker has a read-only posting limit.`;
    if ((makerUser.status && makerUser.status !== 'active') || makerUser.canPostJournals === false) return `Document ${l.docNo}: the maker does not have posting authority.`;
    if (makerUser.clientId != null && makerUser.clientId !== l.clientId) return `Document ${l.docNo}: the maker belongs to another entity.`;
    if (checker) {
      const checkerUser = ctx.users.get(checker);
      if (!checkerUser) return `Document ${l.docNo}: checker "${checker}" is not a known user account.`;
      if (!isAuthorisedChecker(checkerUser)) return `Document ${l.docNo}: "${checker}" is not authorised to check documents.`;
      if (checkerUser.clientId != null && checkerUser.clientId !== l.clientId) return `Document ${l.docNo}: the checker belongs to another entity.`;
      if (checker !== maker && checker !== ctx.session.username) return `Document ${l.docNo}: approval must be submitted by the authenticated checker, not supplied by its maker.`;
    }
    const sessionIsMaker = maker === ctx.session.username;
    const sessionIsChecker = checker === ctx.session.username && isAuthorisedChecker(ctx.session);
    if (!sessionIsMaker && !sessionIsChecker) {
      return `Document ${l.docNo} was prepared by "${maker}" — only its maker, or an authorised checker named on it, may post it.`;
    }
  }
  return null;
}

/**
 * Segregation of duties: a document whose total exceeds ITS MAKER's limit must carry
 * an independent checker (a different, authorised user). Self-checking above the
 * limit — or posting above the limit unchecked — is rejected server-side so one
 * person can never both make and approve an oversized entry. The maker's own limit
 * is used (not the submitter's), so an approver posting on a maker's behalf cannot
 * lend the maker a higher threshold.
 */
export function validateMakerChecker(lines: ACDOCALine[], ctx: MakerCheckerContext): string | null {
  const byDoc = new Map<string, { docNo: string; clientId: number; total: number; currency: string; maker: string; checker?: string }>();
  for (const l of lines) {
    const key = `${l.clientId}:${l.docNo}`;
    const agg = byDoc.get(key) ?? { docNo: l.docNo, clientId: l.clientId, total: 0, currency: l.currency, maker: l.createdBy, checker: l.checkedBy };
    agg.total += toMinor(l.debit);
    if (l.checkedBy) agg.checker = l.checkedBy;
    byDoc.set(key, agg);
  }
  for (const agg of byDoc.values()) {
    const docNo = agg.docNo;
    const makerRecord = ctx.users?.get(agg.maker);
    const limit = makerRecord ? makerRecord.makerLimit : agg.maker === ctx.username ? ctx.makerLimit : 0;
    if (!Number.isFinite(limit) || limit <= 0) return `Document ${docNo}: the maker has a read-only posting limit.`;

    // A maker limit is denominated in the entity's functional currency. A foreign
    // currency document cannot be compared to it numerically, so it is always
    // treated as requiring independent approval (conservative by design).
    const functional = ctx.functionalCurrencies?.get(agg.clientId) ?? ctx.functionalCurrencies?.get(null);
    const foreign = Boolean(functional && functional !== agg.currency);
    const overLimit = agg.total / 100 > limit;
    if (!foreign && !overLimit) continue;

    const reason = foreign
      ? `Document ${docNo} is denominated in ${agg.currency} while the entity reports in ${functional}.`
      : `Document ${docNo} exceeds the maker limit.`;
    if (!agg.checker) {
      return `${reason} Independent checker approval is required; there is no checker named on it.`;
    }
    if (agg.checker === agg.maker) {
      return `${reason} The maker cannot check their own document.`;
    }
    if (ctx.users && !isAuthorisedChecker(ctx.users.get(agg.checker))) {
      return `${reason} Its checker "${agg.checker}" is not an authorised, active checker.`;
    }
  }
  return null;
}
