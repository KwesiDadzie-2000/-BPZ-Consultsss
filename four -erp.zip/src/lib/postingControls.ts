import type { chartAccounts, users } from "@/db/schema";
import type { UserAccount } from "@/types/accounting";
import type { PostingUserRecord } from "@/lib/journalValidation";
import { hasFirmWideScope } from "@/utils/access";

type UserRow = typeof users.$inferSelect;
type AccountRow = typeof chartAccounts.$inferSelect;

/** Username → posting record, for maker-limit resolution and checker vetting. */
export function postingUserDirectory(rows: readonly UserRow[]): Map<string, PostingUserRecord> {
  return new Map(
    rows.map((row) => [
      row.username,
      { username: row.username, role: row.role, makerLimit: row.makerLimit, canCheck: row.canCheck, status: row.status, clientId: row.clientId, canPostJournals: (row.permissions as UserAccount['permissions'])?.canPostJournals },
    ]),
  );
}

export function sessionPostingRecord(user: UserAccount): PostingUserRecord {
  return { username: user.username, role: user.role, makerLimit: user.makerLimit, canCheck: user.canCheck, status: user.status ?? "active", clientId: user.clientId, canPostJournals: user.permissions?.canPostJournals };
}

/**
 * The browser needs enough of the directory to validate the documents it creates.
 * Firm-wide reviewers receive all accounts; an entity-bound client receives its
 * own colleagues and the firm staff who may prepare/review its books. This is
 * deliberately NOT the owner-only user-administration directory.
 */
export function visiblePostingDirectory(
  rows: readonly UserAccount[],
  viewer: UserAccount,
): UserAccount[] {
  if (hasFirmWideScope(viewer)) return [...rows];
  if (!viewer.clientId) return rows.filter((row) => row.username === viewer.username);
  return rows.filter((row) => row.clientId == null || row.clientId === viewer.clientId);
}

/** Add the authenticated account last so a stale/partial cache can never erase it. */
export function browserPostingDirectory(
  rows: readonly UserAccount[],
  session: UserAccount,
): Map<string, PostingUserRecord> {
  const directory = new Map(rows.map((row) => [row.username, sessionPostingRecord(row)]));
  directory.set(session.username, sessionPostingRecord(session));
  return directory;
}

/**
 * Account postability: an account may be posted to by an entity only when it is
 * ACTIVE and is either a firm-master account (clientId null) or that entity's own
 * tailored account. Where an entity has tailored a master account, the entity's
 * version governs (a deactivated tailored copy blocks posting for that entity).
 */
export function accountPostabilityFor(accounts: readonly AccountRow[]): (accountNo: string, clientId: number) => boolean {
  const master = new Map<string, boolean>();
  const tailored = new Map<string, boolean>();
  for (const account of accounts) {
    if (account.clientId === null) master.set(account.accountNo, account.active);
    else tailored.set(`${account.clientId}:${account.accountNo}`, account.active);
  }
  return (accountNo, clientId) => {
    const own = tailored.get(`${clientId}:${accountNo}`);
    if (own !== undefined) return own;
    const shared = master.get(accountNo);
    return shared === true;
  };
}
