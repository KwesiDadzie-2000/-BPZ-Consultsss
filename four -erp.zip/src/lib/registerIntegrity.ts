import type { ACDOCALine, PurchaseOrder, SalesInvoice, StockItem, StockMovement } from '@/types/accounting';

const cents = (n: number) => Math.round(Number(n) * 100);
const qtyUnits = (n: number) => Math.round(Number(n) * 1000);

/** Match a source document reference as a whole token, not INV-1 inside INV-10. */
function mentions(line: Pick<ACDOCALine, 'reference' | 'description'>, docNo: string): boolean {
  if (line.reference === docNo) return true;
  const text = String(line.description ?? '');
  let index = text.indexOf(docNo);
  while (index !== -1) {
    const before = text[index - 1] ?? '';
    const after = text[index + docNo.length] ?? '';
    if (!/[A-Za-z0-9_-]/.test(before) && !/[A-Za-z0-9_-]/.test(after)) return true;
    index = text.indexOf(docNo, index + docNo.length);
  }
  return false;
}

/**
 * A browser can never declare an invoice or PO paid without posted settlement
 * evidence. Legacy records are retained unchanged even if imported without
 * document-level references; changing such records requires a real journal.
 */
export function registerSettlementError(
  before: readonly (SalesInvoice | PurchaseOrder)[],
  after: readonly (SalesInvoice | PurchaseOrder)[],
  ledger: readonly ACDOCALine[],
  kind: 'invoice' | 'purchase order',
): string | null {
  const oldById = new Map(before.map((r) => [r.id, r]));
  const nextIds = new Set(after.map((r) => r.id));
  for (const previous of before) {
    if (nextIds.has(previous.id)) continue;
    const docNo = kind === 'invoice' ? (previous as SalesInvoice).invNo : (previous as PurchaseOrder).poNo;
    if (ledger.some((l) => l.clientId === previous.clientId && l.docNo === docNo)) {
      return `Posted ${kind} ${docNo} cannot be deleted by a browser snapshot. Reverse it and issue a correcting document.`;
    }
  }
  for (const record of after) {
    const previous = oldById.get(record.id);
    const docNo = kind === 'invoice' ? (record as SalesInvoice).invNo : (record as PurchaseOrder).poNo;
    const total = kind === 'invoice' ? (record as SalesInvoice).totalReceivable : (record as PurchaseOrder).totalAmount;
    const paid = Number(record.paidAmount ?? 0);
    if (!Number.isFinite(total) || !Number.isFinite(paid) || total < 0 || paid < 0 || cents(paid) > cents(total)) {
      return `${kind} ${docNo}: amounts must be finite, nonnegative and the settlement cannot exceed the document total.`;
    }
    const issued = ledger.some((l) => l.docNo === docNo && l.clientId === record.clientId);
    if (!previous) {
      if (paid > 0 && !issued) return `${kind} ${docNo} has a settlement without a posted source document.`;
      if (kind === 'invoice' && (record as SalesInvoice).status !== 'Draft' && !issued) {
        return `Invoice ${docNo} cannot leave Draft until its balanced invoice journal has posted.`;
      }
      if (kind === 'purchase order' && ['Invoiced', 'Paid', 'Debited'].includes((record as PurchaseOrder).status) && !issued) {
        return `Purchase order ${docNo} cannot be invoiced or settled before receipt/invoice posting.`;
      }
    } else if (issued) {
      // Changing the nominal value or identity of a posted document would make
      // the register disagree with an immutable invoice/purchase journal.
      if (previous.clientId !== record.clientId || (kind === 'invoice'
        ? (previous as SalesInvoice).invNo !== docNo || cents((previous as SalesInvoice).totalReceivable) !== cents(total)
        : (previous as PurchaseOrder).poNo !== docNo || cents((previous as PurchaseOrder).totalAmount) !== cents(total))) {
        return `${kind} ${docNo} is posted and its entity, number and gross amount are immutable; reverse and issue a correcting document.`;
      }
    }
    if (!previous || cents(Number(previous.paidAmount ?? 0)) !== cents(paid)) {
      const account = kind === 'invoice' ? '110000' : '200000';
      const matching = ledger.filter((l) => l.accountNo === account && l.docNo !== docNo
        && l.clientId === record.clientId && mentions(l, docNo));
      const fromJournal = matching.reduce((s, l) => s + (kind === 'invoice' ? l.credit - l.debit : l.debit - l.credit), 0);
      if (cents(fromJournal) !== cents(paid)) {
        return `${kind} ${docNo}: paid ${paid.toFixed(2)} does not match posted settlement journals ${fromJournal.toFixed(2)}. Post the receipt/payment at the Payment Desk before updating its status.`;
      }
    }
  }
  return null;
}

/** Original stock movement rows are immutable accounting evidence. */
export function stockMovementError(before: readonly StockMovement[], after: readonly StockMovement[]): string | null {
  const incoming = new Map(after.map((r) => [r.id, r]));
  for (const old of before) {
    const next = incoming.get(old.id);
    if (!next) return `Posted stock movement ${old.id} is missing. Reverse via a new adjustment; do not erase history.`;
    if (old.clientId !== next.clientId || old.itemCode !== next.itemCode || old.type !== next.type || (old.docNo ?? '') !== (next.docNo ?? '')
      || qtyUnits(old.quantity) !== qtyUnits(next.quantity) || cents(old.totalValue) !== cents(next.totalValue)
      || cents(old.unitCost) !== cents(next.unitCost)) {
      return `Posted stock movement ${old.id} was changed. Reversal/adjustment is required.`;
    }
  }
  return null;
}

export function stockRegisterError(
  beforeItems: readonly StockItem[],
  afterItems: readonly StockItem[],
  beforeMovements: readonly StockMovement[],
  afterMovements: readonly StockMovement[],
  ledger: readonly ACDOCALine[],
): string | null {
  const movementError = stockMovementError(beforeMovements, afterMovements);
  if (movementError) return movementError;
  const previous = new Map(beforeItems.map((i) => [`${i.clientId}:${i.itemCode}`, i]));
  const newMovements = afterMovements.filter((m) => !beforeMovements.some((x) => x.id === m.id));
  const afterKeys = new Set(afterItems.map((i) => `${i.clientId}:${i.itemCode}`));
  for (const old of beforeItems) {
    if (!afterKeys.has(`${old.clientId}:${old.itemCode}`)) {
      return `Stock item ${old.itemCode} cannot be removed by snapshot sync. Close it with an audited adjustment.`;
    }
  }
  for (const item of afterItems) {
    const key = `${item.clientId}:${item.itemCode}`;
    const old = previous.get(key);
    if (!Number.isFinite(item.quantityOnHand) || !Number.isFinite(item.totalValue) || item.quantityOnHand < -0.0005 || item.totalValue < -0.005) {
      return `Stock item ${item.itemCode}: negative or non-finite stock is forbidden.`;
    }
    const events = newMovements.filter((m) => `${m.clientId}:${m.itemCode}` === key);
    const quantityDelta = events.reduce((n, m) => n + (
      m.type === 'Issue' || m.type === 'ReturnOut' ? -Math.abs(m.quantity) : m.quantity
    ), 0);
    const valueDelta = events.reduce((n, m) => n + (m.type === 'Issue' || m.type === 'ReturnOut' || m.type === 'WriteDown'
      ? -Math.abs(m.totalValue) : m.type === 'Adjustment' ? m.totalValue : Math.abs(m.totalValue)), 0);
    if (Math.abs(qtyUnits(item.quantityOnHand) - qtyUnits((old?.quantityOnHand ?? 0) + quantityDelta)) > 1
      || Math.abs(cents(item.totalValue) - cents((old?.totalValue ?? 0) + valueDelta)) > 1) {
      return `Stock item ${item.itemCode}: quantity/value changed without the corresponding immutable stock movements. Post through Inventory, Procurement, Sales or Production.`;
    }
  }
  const grouped = new Map<string, number>();
  for (const m of newMovements) {
    if (!m.docNo || !Number.isFinite(m.quantity) || !Number.isFinite(m.totalValue)) {
      return `Stock movement ${m.id} needs a posted document number and finite quantity/value.`;
    }
    const item = afterItems.find((i) => i.clientId === m.clientId && i.itemCode === m.itemCode);
    if (!item) return `Stock movement ${m.id} has no item master.`;
    const account = item.glAccount || '120000';
    const key = `${m.clientId}:${m.docNo}:${account}`;
    const delta = m.type === 'Issue' || m.type === 'ReturnOut' || m.type === 'WriteDown'
      ? -Math.abs(m.totalValue) : m.type === 'Adjustment' ? m.totalValue : Math.abs(m.totalValue);
    grouped.set(key, (grouped.get(key) ?? 0) + delta);
  }
  for (const [key, delta] of grouped) {
    const [client, docNo, account] = key.split(':');
    const posted = ledger.filter((l) => l.clientId === Number(client) && l.docNo === docNo && l.accountNo === account);
    const glDelta = posted.reduce((sum, l) => sum + l.debit - l.credit, 0);
    if (cents(glDelta) !== cents(delta)) {
      return `Stock movement for ${docNo} does not agree with its posted inventory control account ${account}.`;
    }
  }
  return null;
}
