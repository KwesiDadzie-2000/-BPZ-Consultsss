import { sql } from "drizzle-orm";
import type { db as Db } from "@/db";

/**
 * The general ledger is the ONLY authority for treasury balances.
 *
 * A bank / cash / wallet record that owns its treasury GL account (one record
 * per entity · GL · currency) has its balance DERIVED from posted journals on
 * every read (bootstrap) and every write (state sync). A browser therefore can
 * no longer save a bank balance that disagrees with the ledger: a direct edit is
 * simply replaced by the ledger figure. Records that share a GL with another
 * record (legacy set-ups) keep their stored value and are flagged by the
 * Control Accounts desk.
 */
type Executor = Pick<typeof Db, "execute">;

export interface TreasuryRecord {
  id: number;
  clientId: number | null | undefined;
  glAccount?: string | null;
  kind?: string | null;
  currency: string;
  balance: number;
}

export const treasuryGlFor = (b: Pick<TreasuryRecord, "glAccount" | "kind">) =>
  b.glAccount || (b.kind === "cash" ? "102000" : "100000");

const key = (clientId: number, gl: string, currency: string) => `${clientId}:${gl}:${currency}`;

/** Ledger balance of every treasury (10xxxx) GL, per entity and currency. */
export async function ledgerTreasuryBalances(exec: Executor, clientIds: number[]): Promise<Map<string, number>> {
  const map = new Map<string, number>();
  if (!clientIds.length) return map;
  const ids = clientIds.filter((n) => Number.isInteger(n)).join(",") || "-1";
  const res = await exec.execute<{ client_id: number; account_no: string; currency: string; bal: string | number }>(sql`
    select client_id, account_no, currency, round(sum(debit - credit)::numeric, 2) as bal
      from journal_lines
     where account_no like '10%' and client_id in (${sql.raw(ids)})
     group by client_id, account_no, currency`);
  for (const r of res.rows) map.set(key(Number(r.client_id), r.account_no, r.currency), Number(r.bal));
  return map;
}

/** Replace each uniquely-mapped treasury record's balance with the ledger balance. */
export function applyLedgerAuthority<T extends TreasuryRecord>(records: T[], ledger: Map<string, number>): T[] {
  const groups = new Map<string, number>();
  for (const b of records) {
    if (b.clientId == null) continue;
    const k = key(b.clientId, treasuryGlFor(b), b.currency);
    groups.set(k, (groups.get(k) ?? 0) + 1);
  }
  return records.map((b) => {
    if (b.clientId == null) return b;
    const k = key(b.clientId, treasuryGlFor(b), b.currency);
    if (groups.get(k) !== 1) return b; // shared GL — cannot attribute, keep stored
    return { ...b, balance: Math.round((ledger.get(k) ?? 0) * 100) / 100 };
  });
}
