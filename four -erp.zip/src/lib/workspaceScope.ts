import type { ClientEntity, UserAccount } from '@/types/accounting';
import { hasFirmWideScope, maySeeSection } from '@/utils/access';

/** A browser snapshot must never grant itself access by adding a row to a denied register. */
export type WorkspaceFamily =
  | 'bankAccounts' | 'purchaseOrders' | 'salesInvoices' | 'employees'
  | 'businessPartners' | 'payrollRecords' | 'prepaymentRecords'
  | 'prepaymentSchedules' | 'approvalRequests' | 'stockItems'
  | 'stockMovements' | 'fixedAssets' | 'taxScheduleEntries';

/** Read scopes include information needed by downstream reporting; writes are narrower. */
const READ_SECTIONS: Record<WorkspaceFamily, string[]> = {
  bankAccounts: ['banking', 'payment_desk', 'loans_desk', 'prepayments', 'assets'],
  purchaseOrders: ['procurement', 'payment_desk', 'ageing', 'reports', 'ifrs_desk', 'project_costing'],
  salesInvoices: ['sales', 'payment_desk', 'ageing', 'reports', 'ifrs_desk', 'project_costing'],
  employees: ['payroll', 'hr_desk', 'hr_employees', 'report_hr_r'],
  businessPartners: ['business_partners_crm', 'procurement', 'sales', 'payment_desk', 'crm_desk', 'tax_schedule'],
  payrollRecords: ['payroll', 'report_hr_r'],
  prepaymentRecords: ['prepayments', 'ifrs_desk'],
  prepaymentSchedules: ['prepayments', 'ifrs_desk'],
  approvalRequests: ['universal_journal', 'manual_journal', 'payment_desk', 'procurement', 'sales', 'payroll'],
  stockItems: ['inventory', 'inventory_ledger', 'production_desk', 'boms', 'sales', 'procurement', 'ifrs_desk'],
  stockMovements: ['inventory', 'inventory_ledger', 'production_desk', 'sales', 'procurement', 'ifrs_desk'],
  fixedAssets: ['assets', 'ifrs_desk'],
  taxScheduleEntries: ['tax_schedule'],
};

const WRITE_SECTIONS: Record<WorkspaceFamily, string[]> = {
  bankAccounts: ['banking', 'payment_desk', 'loans_desk', 'prepayments', 'assets'],
  purchaseOrders: ['procurement', 'payment_desk'],
  salesInvoices: ['sales', 'payment_desk'],
  employees: ['payroll', 'hr_desk', 'hr_employees'],
  businessPartners: ['business_partners_crm', 'procurement', 'sales', 'payment_desk', 'crm_desk'],
  payrollRecords: ['payroll'],
  prepaymentRecords: ['prepayments'],
  prepaymentSchedules: ['prepayments'],
  approvalRequests: ['universal_journal', 'manual_journal', 'payment_desk', 'procurement', 'sales', 'payroll'],
  stockItems: ['inventory', 'production_desk', 'sales', 'procurement'],
  stockMovements: ['inventory', 'production_desk', 'sales', 'procurement'],
  fixedAssets: ['assets'],
  taxScheduleEntries: ['tax_schedule'],
};

export function canAccessFamily(user: UserAccount, client: ClientEntity | null, family: WorkspaceFamily, access: 'read' | 'write'): boolean {
  if (!client || user.status === 'restricted' || user.status === 'suspended') return false;
  if (!hasFirmWideScope(user) && user.clientId !== client.id) return false;
  if (access === 'write' && user.role === 'auditor') return false;
  if (user.role === 'owner') return true;
  if (family === 'payrollRecords' && user.permissions?.canRunPayroll === false) return false;
  const allowed = (access === 'read' ? READ_SECTIONS : WRITE_SECTIONS)[family];
  return allowed.some((section) => maySeeSection(user, client, section));
}

/** The server skips denied empty arrays but must explicitly refuse forged rows. */
export function deniedStateWrite(
  user: UserAccount,
  client: ClientEntity | null,
  payload: Partial<Record<WorkspaceFamily, readonly unknown[]>>,
): string | null {
  if (user.role === 'owner') return null;
  for (const family of Object.keys(WRITE_SECTIONS) as WorkspaceFamily[]) {
    if (!canAccessFamily(user, client, family, 'write') && (payload[family]?.length ?? 0) > 0) {
      return `${family} is outside the modules and services assigned to this account.`;
    }
  }
  return null;
}
