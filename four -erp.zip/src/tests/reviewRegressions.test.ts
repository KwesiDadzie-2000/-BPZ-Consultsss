import assert from 'node:assert/strict';
import { test } from 'node:test';
import { INITIAL_CLIENTS } from '../data/accountingSeed';
import type { ACDOCALine } from '../types/accounting';
import { validateJournalLines, validateMakerChecker, validatePostingIdentity, type PostingUserRecord } from '../lib/journalValidation';
import { parseAccountOption, formatMoney, currencySymbol } from '../utils/currency';
import { immutableJournalConflict } from '../lib/immutableJournal';
import { dashboardModel } from '../utils/dashboardModel';
import { csvCell } from '../utils/printReport';
import { persistentStorage } from '../utils/persistentStorage';
import { browserStorage } from '../utils/browserStorage';
import { maySeeSection, mayUseDesk } from '../utils/access';
import { OWNER_ONLY_MODULES } from '../utils/moduleCatalog';
import { reconcileControlAccounts, controlAccountSummary } from '../utils/controlAccounts';
import { generateAmortisationSchedule, buildDebtServiceAccrualJournal, buildDebtServicePaymentJournal, normalizeJournalAmounts } from '../utils/loans';
import { goldRoyaltyRate, computeMineralRoyalty, computeFuelLevies, solveEffectiveRate, contractualInstalment, buildEirSchedule, computeIfrs17Paa, computePetroleumRoyalty, computeBiologicalMovement, computePensionNav, explodeMrp } from '../utils/regulated';
import { validateJournalLines as validateJournalAmounts } from '../lib/journalValidation';
import type { BankAccount, SalesInvoice, StockItem } from '../types/accounting';

const base: ACDOCALine = {
  id: 'line-a', docNo: 'TEST-001', period: '2026-10', date: '2026-10-29', module: 'FI',
  docType: 'JE', accountNo: '100000', accountName: 'Bank', debit: 100, credit: 0,
  currency: 'GHS', description: 'Review regression', createdBy: 'maker', clientId: 2,
};
const pair = (): ACDOCALine[] => [ { ...base }, { ...base, id: 'line-b', accountNo: '400000', debit: 0, credit: 100 } ];
const context = { allowedClientIds: [2], closedPeriodKeys: new Set<string>(), coaAccountNos: new Set(['100000', '400000']) };
const maker: PostingUserRecord = { username: 'maker', role: 'accountant', makerLimit: 50, canCheck: false, status: 'active', clientId: 2 };
const checker: PostingUserRecord = { username: 'checker', role: 'manager', makerLimit: 10000, canCheck: true, status: 'active', clientId: 2 };
const users = new Map([['maker', maker], ['checker', checker]]);

test('valid balanced document is accepted', () => assert.equal(validateJournalLines(pair(), context), null));
test('invalid collection is rejected without crashing', () => assert.ok(validateJournalLines(null as unknown as ACDOCALine[], context)));
test('null lines are rejected without crashing', () => assert.ok(validateJournalLines([null] as unknown as ACDOCALine[], context)));
test('duplicate line identifiers are refused', () => assert.match(validateJournalLines([base, { ...base }], context)!, /Duplicate/));
test('blank document numbers are refused', () => assert.ok(validateJournalLines(pair().map((line) => ({ ...line, docNo: '' })), context)));
test('date cannot escape the accounting period freeze', () => assert.match(validateJournalLines(pair().map((line) => ({ ...line, period: '2026-09' })), context)!, /posting date/));
test('impossible calendar dates are refused', () => assert.ok(validateJournalLines(pair().map((line) => ({ ...line, date: '2026-02-30', period: '2026-02' })), context)));
test('fractional pennies cannot silently round to a balanced document', () => assert.ok(validateJournalLines(pair().map((line) => ({ ...line, debit: line.debit ? 100.001 : 0 })), context)));
test('non-finite money is refused', () => assert.ok(validateJournalLines([{ ...base, debit: Infinity }, pair()[1]], context)));
test('money beyond the integer precision boundary is refused', () => assert.ok(validateJournalLines([{ ...base, debit: Number.MAX_SAFE_INTEGER }, pair()[1]], context)));
test('legitimate floating point representation is tolerated', () => assert.equal(validateJournalLines([{ ...base, debit: 0.1 + 0.2 }, { ...pair()[1], credit: 0.3 }], context), null));
test('different checker stamps within one document are refused', () => assert.match(validateJournalLines([{ ...base, checkedBy: 'checker' }, pair()[1]], context)!, /checker/));
test('a maker cannot claim the approval of a real checker', () => assert.match(validatePostingIdentity(pair().map((line) => ({ ...line, checkedBy: 'checker' })), { session: maker, users })!, /authenticated checker/));
test('the authenticated checker can submit the approved document', () => assert.equal(validatePostingIdentity(pair().map((line) => ({ ...line, checkedBy: 'checker' })), { session: checker, users }), null));
test('a checker cannot approve another tenant record', () => {
  const outside = { ...checker, clientId: 3 };
  assert.match(validatePostingIdentity(pair().map((line) => ({ ...line, checkedBy: 'checker' })), { session: outside, users: new Map([...users, ['checker', outside]]) })!, /another entity/);
});
test('revoked posting permission is enforced', () => assert.match(validatePostingIdentity(pair(), { session: { ...maker, canPostJournals: false }, users })!, /permission/));
test('a foreign-currency document always needs an independent checker, whatever the amount', () => {
  const functionalCurrencies = new Map<number | null, string>([[2, 'GHS']]);
  const roomy = new Map([['maker', { ...maker, makerLimit: 50000 }], ['checker', checker]]);
  // Numerically far below the maker limit, but the limit is stated in GHS and is
  // never translated — so a USD document must still route for independent approval.
  const smallUsd = pair().map((line) => ({ ...line, currency: 'USD', debit: line.debit ? 5 : 0, credit: line.credit ? 5 : 0 }));
  assert.match(validateMakerChecker(smallUsd, { username: 'maker', makerLimit: 50000, users: roomy, functionalCurrencies })!, /denominated in USD/);
  // With an independent authorised checker named, it is accepted.
  const approved = smallUsd.map((line) => ({ ...line, checkedBy: 'checker' }));
  assert.equal(validateMakerChecker(approved, { username: 'maker', makerLimit: 50000, users: roomy, functionalCurrencies }), null);
  // The maker may not check their own foreign-currency document.
  const selfChecked = smallUsd.map((line) => ({ ...line, checkedBy: 'maker' }));
  assert.match(validateMakerChecker(selfChecked, { username: 'maker', makerLimit: 50000, users: roomy, functionalCurrencies })!, /cannot check their own/);
  // Same-currency documents below the limit still post without a checker.
  const ghsDoc = pair().map((line) => ({ ...line, currency: 'GHS' }));
  assert.equal(validateMakerChecker(ghsDoc, { username: 'maker', makerLimit: 50000, users: roomy, functionalCurrencies }), null);
});

test('account option parsing survives names that contain the separator', () => {
  const label = '104000 · Mobile Money — MTN / Vodafone · AirtelTigo';
  const parsed = parseAccountOption(label);
  assert.equal(parsed.accountNo, '104000');
  assert.equal(parsed.accountName, 'Mobile Money — MTN / Vodafone · AirtelTigo');
  // Truncation at the first separator used to post the wrong account name.
  assert.equal(parsed.accountName.split(' · ').length, 2);
  assert.equal(currencySymbol('GBP'), '£');
  assert.equal(formatMoney(15000, 'GBP'), '£15,000.00');
  assert.equal(formatMoney(15000, 'GHS'), '₵15,000.00');
});

test('zero maker limit means read-only, not unlimited', () => assert.match(validatePostingIdentity(pair(), { session: maker, users: new Map([...users, ['maker', { ...maker, makerLimit: 0 }]]) })!, /read-only/));
test('inactive maker cannot be posted on behalf of', () => assert.ok(validatePostingIdentity(pair().map((line) => ({ ...line, checkedBy: 'checker' })), { session: checker, users: new Map([...users, ['maker', { ...maker, status: 'suspended' }]]) })));
test('replaying a posted document is safe', () => assert.equal(immutableJournalConflict(pair(), pair()), null));
test('reordering a replay is safe', () => assert.equal(immutableJournalConflict(pair(), pair().reverse()), null));
test('a changed amount cannot replace a posted document', () => assert.match(immutableJournalConflict(pair(), pair().map((line) => ({ ...line, debit: line.debit * 2, credit: line.credit * 2 })))!, /immutable/));
test('removing one line of a posted document is refused', () => assert.ok(immutableJournalConflict(pair(), [base])));
test('reversal is a new document, not mutation of the old document', () => assert.equal(immutableJournalConflict(pair(), pair().map((line) => ({ ...line, id: `rev-${line.id}`, docNo: 'REV-TEST-001', debit: line.credit, credit: line.debit, docType: 'REV', reference: 'TEST-001' }))), null));
test('missing documents do not request deletion', () => assert.equal(immutableJournalConflict(pair(), []), null));
test('tenant-scoped dashboard excludes another entity', () => assert.equal(dashboardModel([...pair(), ...pair().map((line) => ({ ...line, clientId: 3 }))], INITIAL_CLIENTS[1]).cashBank, 100));
test('dashboard never adds foreign currency without a rate', () => {
  const model = dashboardModel([...pair(), ...pair().map((line) => ({ ...line, currency: 'USD' }))], INITIAL_CLIENTS[1]);
  assert.equal(model.cashBank, 100); assert.equal(model.excludedLines, 2);
});
test('opposite currency imbalances cannot cancel each other', () => assert.equal(dashboardModel([base, { ...pair()[1], currency: 'USD' }], INITIAL_CLIENTS[1]).isBalanced, false));
test('recent activity sorts by date without mutating the ledger', () => {
  const rows = [base, { ...base, id: 'old', date: '2026-01-01' }, { ...base, id: 'new', date: '2026-10-30' }];
  assert.equal(dashboardModel(rows, INITIAL_CLIENTS[1]).recent[0].id, 'new');
  assert.equal(rows[0].id, 'line-a');
});
test('empty entities have a balanced zero-value model', () => {
  const model = dashboardModel([], INITIAL_CLIENTS[1]); assert.equal(model.isBalanced, true); assert.equal(model.recent.length, 0);
});
for (const value of ['=1+1', '+SUM(A1:A2)', '-1+1', '@SUM(A1:A2)', '\t=1+1', '  =1+1']) {
  test(`CSV neutralises formula-like text ${JSON.stringify(value)}`, () => assert.ok(csvCell(value).startsWith('"\'')));
}
test('CSV preserves negative numeric amounts', () => assert.equal(csvCell(-12.5), '"-12.5"'));
test('CSV quotes names safely', () => assert.equal(csvCell('The "Mining", Co.'), '"The ""Mining"", Co."'));

class MemoryStorage implements Storage {
  values = new Map<string, string>();
  failKey: string | null = null;
  get length() { return this.values.size; }
  clear() { this.values.clear(); }
  key(index: number) { return [...this.values.keys()][index] || null; }
  getItem(key: string) { return this.values.get(key) ?? null; }
  setItem(key: string, value: string) {
    if (this.failKey === key) { this.failKey = null; throw new Error('Quota exceeded'); }
    this.values.set(key, String(value));
  }
  removeItem(key: string) { this.values.delete(key); }
}
test('backup includes all operational registers', () => {
  const data = JSON.parse(persistentStorage.exportFullBackup());
  assert.equal(data.version, '2026.5');
  for (const key of ['stockItems', 'stockMovements', 'fixedAssets', 'approvalRequests', 'taxScheduleEntries', 'prepaymentRecords', 'prepaymentSchedules']) assert.ok(Array.isArray(data[key]), key);
});
test('full backup restores inventory, assets and prepayments', () => {
  const store = new MemoryStorage();
  Object.defineProperty(globalThis, 'localStorage', { value: store, configurable: true });
  const backup = persistentStorage.exportFullBackup();
  assert.equal(persistentStorage.restoreFullBackup(backup), true);
  const original = JSON.parse(backup);
  assert.deepEqual(persistentStorage.getStockItems(), original.stockItems);
  assert.deepEqual(persistentStorage.getAssets(), original.fixedAssets);
  assert.deepEqual(persistentStorage.getPrepayments(), original.prepaymentRecords);
});
test('incomplete new backups are refused before any write', () => {
  const before = persistentStorage.exportFullBackup();
  const backup = JSON.parse(before); delete backup.stockItems;
  assert.equal(persistentStorage.restoreFullBackup(JSON.stringify(backup)), false);
  assert.deepEqual(JSON.parse(persistentStorage.exportFullBackup()).stockItems, JSON.parse(before).stockItems);
});
test('backup restore rolls back if a storage write fails', () => {
  const store = new MemoryStorage();
  Object.defineProperty(globalThis, 'localStorage', { value: store, configurable: true });
  store.setItem('bpz_clients_v1', JSON.stringify(INITIAL_CLIENTS));
  const previous = new Map(store.values);
  store.failKey = 'bpz_employees_v1';
  assert.equal(persistentStorage.restoreFullBackup(persistentStorage.exportFullBackup()), false);
  assert.deepEqual(store.values, previous);
});
test('malformed saved arrays are quarantined rather than crashing', () => {
  const store = new MemoryStorage();
  Object.defineProperty(globalThis, 'localStorage', { value: store, configurable: true });
  store.setItem('bpz_clients_v1', '[null]');
  assert.equal(browserStorage.getItem('bpz_clients_v1'), null);
  assert.equal(store.getItem('bpz_clients_v1:quarantined'), '[null]');
});
test('passwords are not written to browser user storage', () => {
  const store = new MemoryStorage();
  Object.defineProperty(globalThis, 'localStorage', { value: store, configurable: true });
  persistentStorage.saveUserAccounts([{ username: 'fixture', name: 'Fixture', role: 'accountant', email: '', makerLimit: 1, canCheck: false, password: 'NotARealPassword' }]);
  assert.ok(!store.getItem('bpz_user_accounts_v1')!.includes('NotARealPassword'));
});
test('owner-only modules are blocked for every non-owner role', () => {
  const clientUser = {
    username: 'client.admin',
    name: 'Client Admin',
    role: 'manager' as const,
    email: 'admin@client.gh',
    makerLimit: 50000,
    canCheck: true,
    clientId: INITIAL_CLIENTS[1].id,
    status: 'active' as const,
  };
  for (const mod of OWNER_ONLY_MODULES) {
    assert.equal(maySeeSection(clientUser, INITIAL_CLIENTS[1], mod), false);
  }
});
test('control accounts reconcile when registers match the ledger', () => {
  const cid = 9;
  const inv: SalesInvoice = {
    id: 'i1', invNo: 'INV-CTRL-1', customerName: 'Ctrl Customer', revenueStream: 'Services',
    netRevenue: 1000, vatOutput: 0, totalReceivable: 1000, paidAmount: 0, status: 'Open',
    date: '2026-11-02', clientId: cid,
  } as unknown as SalesInvoice;
  const stock: StockItem = {
    id: 's1', itemCode: 'RM-CTRL', description: 'Control material', category: 'Raw Materials', uom: 'kg',
    quantityOnHand: 10, unitCost: 50, totalValue: 500, glAccount: '120000', clientId: cid,
  } as unknown as StockItem;
  const bank: BankAccount = {
    id: 1, code: 'BNK-1', name: 'Operating', bankName: 'GCB', accountNo: '001', currency: 'GHS',
    balance: 7000, kind: 'bank', glAccount: '100000', clientId: cid,
  };
  const lines: ACDOCALine[] = [
    { id: 'c1', docNo: 'CTRL-AR', period: '2026-11', date: '2026-11-02', module: 'SD', docType: 'INV', accountNo: '110000', accountName: 'Trade Receivables', debit: 1000, credit: 0, currency: 'GHS', description: 'AR', createdBy: 'owner', clientId: cid },
    { id: 'c2', docNo: 'CTRL-AR', period: '2026-11', date: '2026-11-02', module: 'SD', docType: 'INV', accountNo: '400000', accountName: 'Revenue', debit: 0, credit: 1000, currency: 'GHS', description: 'AR', createdBy: 'owner', clientId: cid },
    { id: 'c7', docNo: 'CTRL-ECL', period: '2026-11', date: '2026-11-02', module: 'FI', docType: 'JE', accountNo: '501000', accountName: 'Impairment charge', debit: 10, credit: 0, currency: 'GHS', description: 'ECL charge', createdBy: 'owner', clientId: cid },
    { id: 'c8', docNo: 'CTRL-ECL', period: '2026-11', date: '2026-11-02', module: 'FI', docType: 'JE', accountNo: '119000', accountName: 'ECL allowance', debit: 0, credit: 10, currency: 'GHS', description: 'ECL charge', createdBy: 'owner', clientId: cid },
    { id: 'c3', docNo: 'CTRL-ST', period: '2026-11', date: '2026-11-02', module: 'MM', docType: 'PO', accountNo: '120000', accountName: 'Inventory', debit: 500, credit: 0, currency: 'GHS', description: 'Stock', createdBy: 'owner', clientId: cid },
    { id: 'c4', docNo: 'CTRL-ST', period: '2026-11', date: '2026-11-02', module: 'MM', docType: 'PO', accountNo: '200000', accountName: 'Payables', debit: 0, credit: 500, currency: 'GHS', description: 'Stock', createdBy: 'owner', clientId: cid },
    { id: 'c5', docNo: 'CTRL-BK', period: '2026-11', date: '2026-11-02', module: 'FI', docType: 'JE', accountNo: '100000', accountName: 'Bank', debit: 7000, credit: 0, currency: 'GHS', description: 'Bank', createdBy: 'owner', clientId: cid },
    { id: 'c6', docNo: 'CTRL-BK', period: '2026-11', date: '2026-11-02', module: 'FI', docType: 'JE', accountNo: '300000', accountName: 'Capital', debit: 0, credit: 7000, currency: 'GHS', description: 'Bank', createdBy: 'owner', clientId: cid },
  ];
  const ctrlOrder = {
    id: 'po1', poNo: 'PO-CTRL-1', vendorName: 'Ctrl Supplier', itemType: 'material', itemDescription: 'Control material',
    qty: 10, unitPrice: 50, vatRecoverable: 0, totalAmount: 500, paidAmount: 0, status: 'Invoiced', date: '2026-11-02',
    glAccount: '120000', glAccountName: 'Inventory', costCenter: '', costCenterName: '', clientId: cid,
  } as unknown as import('../types/accounting').PurchaseOrder;
  const rows = reconcileControlAccounts({
    clientId: cid, lines, invoices: [inv], orders: [ctrlOrder], stockItems: [stock], bankAccounts: [bank],
    assets: [], prepayments: [], prepaymentSchedules: [], payrollRecords: [], partners: [], taxEntries: [],
    asOf: '2026-11-05',
  });
  const summary = controlAccountSummary(rows);
  assert.equal(summary.outOfBalance, 0, JSON.stringify(summary.exceptions));
  // An invoice that never posted (sub-ledger without a journal) is flagged at once.
  const rows2 = reconcileControlAccounts({
    clientId: cid, lines, invoices: [inv, { ...inv, id: 'i2', invNo: 'INV-UNPOSTED' }], orders: [ctrlOrder], stockItems: [stock], bankAccounts: [bank],
    assets: [], prepayments: [], prepaymentSchedules: [], payrollRecords: [], partners: [], taxEntries: [],
  });
  const reco = rows2.find((r) => r.key === 'receivables')!;
  assert.equal(reco.status, 'out');
  assert.equal(reco.difference, -1000);
});

test('loan amortisation is pesewa-exact and amortises the full principal', () => {
  const schedule = generateAmortisationSchedule({
    id: 'LN-T', code: 'LN-TEST', facilityName: 'Test facility', lender: 'Ecobank Ghana Ltd',
    principal: 1200000, annualRatePct: 21.5, termMonths: 60, frequency: 'monthly',
    facilityType: 'amortising', arrangementFee: 24000, startDate: '2026-01-31', status: 'Active',
  });
  assert.equal(schedule.length, 60);
  // Every scheduled figure is exactly two decimal places (the ledger never inherits float noise).
  for (const r of schedule) {
    for (const v of [r.openingBalance, r.interestExpense, r.principalPayment, r.totalPayment, r.closingBalance]) {
      assert.ok(Math.abs(v - Math.round(v * 100) / 100) < 1e-9, `not 2dp: ${v}`);
    }
  }
  // Closing principal of the final instalment is zero — the loan amortises completely.
  assert.equal(schedule[schedule.length - 1].closingBalance, 0);
  // Total principal repaid equals the facility principal.
  assert.equal(Math.round(schedule.reduce((s, r) => s + r.principalPayment, 0) * 100), 1200000 * 100);
  // Instalment dates follow the facility start date and advance by real months.
  assert.equal(schedule[0].date, '2026-02-28');
  assert.equal(schedule[12].date, '2027-02-28');
});

test('debt service journals are balanced and two-decimal from the start (pay and accrue legs)', () => {
  const facility = {
    id: 'LN-T', code: 'LN-TEST', facilityName: 'Tailings extension', lender: 'Ecobank Ghana Ltd',
    principal: 1200000, annualRatePct: 21.5, termMonths: 60, frequency: 'monthly' as const,
    facilityType: 'amortising' as const, arrangementFee: 24000, startDate: '2026-01-31', status: 'Active' as const,
  };
  const row = generateAmortisationSchedule(facility)[1]; // the row from the screenshot (M2)
  const spec = { facility, row, clientId: 2, currency: 'GHS', date: '2026-03-28', username: 'owner', canCheck: true, treasuryAccountNo: '100000', treasuryAccountName: 'Cash at Bank' };
  for (const lines of [buildDebtServicePaymentJournal(spec), buildDebtServiceAccrualJournal(spec)]) {
    const dr = lines.reduce((s, l) => s + l.debit, 0);
    const cr = lines.reduce((s, l) => s + l.credit, 0);
    assert.equal(Math.round(dr * 100), Math.round(cr * 100));
    for (const l of lines) {
      for (const v of [l.debit, l.credit]) assert.ok(Math.abs(v - Math.round(v * 100) / 100) < 1e-9);
    }
  }
  // The accrual leg releases the instalment into accrued payables (settles at the Payment Desk).
  const accrual = buildDebtServiceAccrualJournal(spec);
  assert.ok(accrual.some((l) => l.accountNo === '202000' && l.docNo.startsWith('EXPB-LOAN-')));
  assert.ok(accrual.every((l) => !l.accountNo.startsWith('10')), 'accrual must not touch treasury');
  // The payment leg settles treasury and is refused without it.
  const payment = buildDebtServicePaymentJournal(spec);
  assert.ok(payment.some((l) => l.accountNo === '100000' && l.credit > 0));
});

test('normalizeJournalAmounts rectifies computed schedules that arrive sub-pesewa and slightly unbalanced', () => {
  const raw: ACDOCALine[] = [
    { ...base, debit: 21297.497000000003, credit: 0 },
    { ...base, id: 'l2', accountNo: '400000', debit: 0, credit: 21297.497000000003 },
  ];
  const fixed = normalizeJournalAmounts(raw);
  assert.ok(validateJournalAmounts(fixed, context) === null);
  const unbalanced: ACDOCALine[] = [
    { ...base, debit: 100.004, credit: 0 },
    { ...base, id: 'l2', accountNo: '400000', debit: 0, credit: 100 },
  ];
  const settled = normalizeJournalAmounts(unbalanced);
  const dr = settled.reduce((s, l) => s + l.debit, 0);
  const cr = settled.reduce((s, l) => s + l.credit, 0);
  assert.equal(Math.round(dr * 100), Math.round(cr * 100));
});

test('TOTP matches the RFC 6238 SHA-1 reference vector and rejects wrong codes', async () => {
  const { totpAt, verifyTotp, base32Encode } = await import('../lib/totp');
  // RFC 6238 Appendix B: secret "12345678901234567890", T=59s → 94287082 (8 digits) → 287082 (6 digits).
  const secret = base32Encode(Buffer.from('12345678901234567890'));
  assert.equal(totpAt(secret, 59_000), '287082');
  assert.equal(totpAt(secret, 1111111109_000), '081804');
  assert.ok(verifyTotp(secret, '287082', 59_000));
  assert.ok(!verifyTotp(secret, '000000', 59_000));
  assert.ok(!verifyTotp(secret, 'abc', 59_000));
});

test('treasury balances are derived from the ledger; shared-GL records keep their stored value', async () => {
  const { applyLedgerAuthority } = await import('../lib/treasuryAuthority');
  const ledger = new Map([['2:100000:GHS', 2190000], ['2:101000:USD', 185000]]);
  const out = applyLedgerAuthority([
    { id: 1, clientId: 2, glAccount: '100000', currency: 'GHS', balance: 999 },        // browser-edited → ledger wins
    { id: 2, clientId: 2, glAccount: '101000', currency: 'USD', balance: 185000 },
    { id: 3, clientId: 2, glAccount: '104000', currency: 'GHS', balance: 25000 },      // no GL movement → 0
    { id: 4, clientId: 3, glAccount: '100000', currency: 'GHS', balance: 10 },
    { id: 5, clientId: 3, glAccount: '100000', currency: 'GHS', balance: 20 },         // shared GL → stored kept
  ], ledger);
  assert.equal(out[0].balance, 2190000);
  assert.equal(out[1].balance, 185000);
  assert.equal(out[2].balance, 0);
  assert.equal(out[3].balance, 10);
  assert.equal(out[4].balance, 20);
});

/** Minimal account set + context so IFRS schedules can be computed in tests. */
const ifrsAccounts = (rows: [string, string, string][]) =>
  rows.map(([accountNo, name, type]) => ({ accountNo, name, type, category: 'Test', active: true })) as never[];


test('IAS 36 computes impairment AND proposes the recognition entry', async () => {
  const { buildIfrsSchedules, DEFAULT_IFRS_INPUTS } = await import('../utils/ifrsSchedules');
  const accounts = ifrsAccounts([
    ['690000', 'Impairment Loss on Non-Financial Assets', 'Expense'],
    ['139000', 'Accumulated Depreciation & Impairment — PPE', 'Asset'],
    ['132000', 'PPE — Plant & Machinery', 'Asset'],
  ]);
  const schedules = buildIfrsSchedules({
    lines: [], accounts, clientId: 9, currency: 'GHS', from: '2026-01-01', through: '2026-12-31',
    assets: [], stockItems: [], stockMovements: [], invoices: [], orders: [], payroll: [], citRatePct: 25,
    inputs: { ...DEFAULT_IFRS_INPUTS, impairments: [{ id: 'c1', cgu: 'Mine CGU', carryingAmount: 1000, cashFlows: '100,100', growthPct: 0, discountPct: 20, fvlcd: 500 }] },
    noteFor: () => undefined,
  } as never);
  const s = schedules.find((x) => x.id === 'ias36')!;
  assert.ok(s.kpis.some((k) => k.label === 'Impairment loss' && Number(k.value) > 0), 'impairment must be computed');
  const entry = s.entries.find((e) => e.key.startsWith('IAS36-IMP-'));
  assert.ok(entry, 'impairment recognition entry must be proposed');
  assert.equal(entry!.blockedReason, undefined);
  const dr = entry!.lines.reduce((n, l) => n + l.debit, 0);
  const cr = entry!.lines.reduce((n, l) => n + l.credit, 0);
  assert.equal(Math.round(dr * 100), Math.round(cr * 100));
});

test('IFRS 16 initial recognition books the full ROU cost including advance payment and IDC', async () => {
  const { buildIfrsSchedules, DEFAULT_IFRS_INPUTS, computeLease } = await import('../utils/ifrsSchedules');
  const lease = { id: 'L1', name: 'Yard', lessor: 'Port', commencement: '2026-01-01', termMonths: 12, payment: 1000, frequency: 'monthly', timing: 'advance', ratePct: 12, initialDirectCosts: 500 };
  const calc = computeLease(lease as never);
  const rouCost = calc.rouCost;
  assert.ok(rouCost > calc.initialLiability + 1400, `ROU must include payment + IDC (${rouCost} vs ${calc.initialLiability})`);
  const accounts = ifrsAccounts([
    ['150000', 'Right-of-Use Assets (IFRS 16)', 'Asset'],
    ['159000', 'Accumulated Depreciation — ROU Assets', 'Asset'],
    ['230000', 'Lease Liabilities (IFRS 16 Principal)', 'Liability'],
    ['116000', 'Prepayments & Deferred Charges', 'Asset'],
    ['700000', 'Finance Costs on Commercial Loans', 'Expense'],
    ['600000', 'Depreciation Expense', 'Expense'],
  ]);
  const schedules = buildIfrsSchedules({
    lines: [], accounts, clientId: 9, currency: 'GHS', from: '2026-01-01', through: '2026-12-31',
    assets: [], stockItems: [], stockMovements: [], invoices: [], orders: [], payroll: [], citRatePct: 25,
    inputs: { ...DEFAULT_IFRS_INPUTS, leases: [lease] as never },
    noteFor: () => undefined,
  } as never);
  const s = schedules.find((x) => x.id === 'ifrs16')!;
  const init = s.entries.find((e) => e.key.startsWith('IFRS16-INIT-'))!;
  assert.equal(init.blockedReason, undefined);
  const rouLine = init.lines.find((l) => l.accountNo === '150000')!;
  assert.equal(rouLine.debit, rouCost, 'ROU asset must be booked at full ROU cost');
  const dr = init.lines.reduce((n, l) => n + l.debit, 0);
  const cr = init.lines.reduce((n, l) => n + l.credit, 0);
  assert.equal(Math.round(dr * 100), Math.round(cr * 100));
});

test('IFRS 15 reclassifies unbilled revenue into contract assets without touching revenue', async () => {
  const { buildIfrsSchedules, DEFAULT_IFRS_INPUTS } = await import('../utils/ifrsSchedules');
  const accounts = ifrsAccounts([
    ['400000', 'Revenue from Contracts with Customers', 'Income'],
    ['110000', 'Trade & Other Receivables', 'Asset'],
    ['118100', 'Unbilled Contract Assets — Revenue Recognised', 'Asset'],
    ['225000', 'Contract Liabilities (IFRS 15 Advances)', 'Liability'],
  ]);
  const line = (id: string, accountNo: string, debit: number, credit: number) => ({
    id, docNo: 'D1', period: '2026-01', date: '2026-01-15', module: 'FI', docType: 'JE', accountNo,
    accountName: accountNo, debit, credit, currency: 'GHS', description: 'x', createdBy: 'o', clientId: 9,
  });
  // Revenue of 500 recognised in the GL, only 200 billed through invoices.
  const schedules = buildIfrsSchedules({
    lines: [line('a', '400000', 0, 500), line('b', '110000', 200, 0), line('c', '300000', 300, 0)],
    accounts, clientId: 9, currency: 'GHS', from: '2026-01-01', through: '2026-12-31',
    assets: [], stockItems: [], stockMovements: [],
    invoices: [{ id: 'i1', invNo: 'INV-1', customerName: 'C', revenueStream: 'Services', netRevenue: 200, vatOutput: 0, totalReceivable: 200, paidAmount: 0, status: 'Open', date: '2026-01-10', clientId: 9 }] as never,
    orders: [], payroll: [], citRatePct: 25, inputs: DEFAULT_IFRS_INPUTS, noteFor: () => undefined,
  } as never);
  const s = schedules.find((x) => x.id === 'ifrs15')!;
  const entry = s.entries.find((e) => e.key.startsWith('IFRS15-CA-'));
  assert.ok(entry, 'contract-asset reclassification must be proposed');
  assert.equal(entry!.blockedReason, undefined);
  // Reclassification only: no line may touch a revenue account.
  assert.ok(entry!.lines.every((l) => l.accountNo !== '400000'), 'must not re-open revenue');
  const dr = entry!.lines.reduce((n, l) => n + l.debit, 0);
  assert.equal(Math.round(dr * 100), 30000, 'unbilled 300 is reclassified to contract assets');
});

test('IAS 37 provision movements propose raised / unwound / reversed entries', async () => {
  const { buildIfrsSchedules, DEFAULT_IFRS_INPUTS } = await import('../utils/ifrsSchedules');
  const accounts = ifrsAccounts([
    ['234000', 'Provisions', 'Liability'],
    ['620000', 'Environmental & Decommissioning Costs', 'Expense'],
    ['700000', 'Finance Costs on Commercial Loans', 'Expense'],
  ]);
  const schedules = buildIfrsSchedules({
    lines: [], accounts, clientId: 9, currency: 'GHS', from: '2026-01-01', through: '2026-12-31',
    assets: [], stockItems: [], stockMovements: [], invoices: [], orders: [], payroll: [], citRatePct: 25,
    inputs: { ...DEFAULT_IFRS_INPUTS, provisions: [{ id: 'p1', name: 'Rehabilitation', category: 'Decommissioning', opening: 100, additions: 50, utilised: 10, reversed: 5, unwinding: 20, expectedTiming: '2030' }] },
    noteFor: () => undefined,
  } as never);
  const s = schedules.find((x) => x.id === 'ias37')!;
  const keys = s.entries.map((e) => e.key);
  assert.ok(keys.some((k) => k.startsWith('IAS37-ADD-')), 'additions entry');
  assert.ok(keys.some((k) => k.startsWith('IAS37-UNW-')), 'unwinding entry');
  assert.ok(keys.some((k) => k.startsWith('IAS37-REV-')), 'reversal entry');
  for (const e of s.entries) {
    assert.equal(e.blockedReason, undefined, e.key);
    const dr = e.lines.reduce((n, l) => n + l.debit, 0);
    const cr = e.lines.reduce((n, l) => n + l.credit, 0);
    assert.equal(Math.round(dr * 100), Math.round(cr * 100), e.key);
  }
});

test('opening balance schedule normalises junk input and balances to equity', async () => {
  const { normaliseOpeningSchedule, openingScheduleTotals, balanceOpeningScheduleToEquity, openingScheduleBlockers } = await import('../utils/openingBalances');
  const cleaned = normaliseOpeningSchedule({
    '100000': { dr: Number('1e999'), cr: -50 },
    '300000': { dr: 10.015, cr: 2 },
  });
  assert.deepEqual(cleaned['100000'], { dr: 0, cr: 0 });
  assert.deepEqual(cleaned['300000'], { dr: 10.02, cr: 0 });
  const balanced = balanceOpeningScheduleToEquity({ '100000': { dr: 1000, cr: 0 } });
  const totals = openingScheduleTotals(balanced);
  assert.equal(totals.balanced, true);
  assert.deepEqual(balanced['309000'], { dr: 0, cr: 1000 });
  const blockers = openingScheduleBlockers({ '100000': { dr: 100, cr: 0 } }, [{ accountNo: '100000', name: 'Bank', type: 'Asset', category: 'Bank', active: true }] as never, '2026-02-28', ['2026-02']);
  assert.ok(blockers.some((b) => b.includes('Period 2026-02 is closed')));
  assert.ok(blockers.some((b) => b.includes('differ by')));
  const badDate = openingScheduleBlockers({ '100000': { dr: 100, cr: 100 } }, [{ accountNo: '100000', name: 'Bank', type: 'Asset', category: 'Bank', active: true }] as never, '2026-02-30', []);
  assert.ok(badDate.some((b) => b.includes('cut-over date')), 'impossible calendar dates are rejected');
});

test('posting directory for a client includes its own admin plus firm staff, and always the session user', async () => {
  const { visiblePostingDirectory, browserPostingDirectory, sessionPostingRecord } = await import('../lib/postingControls');
  const rows = [
    { username: 'owner', role: 'owner', makerLimit: 1e9, canCheck: true, email: 'o@x', clientId: undefined },
    { username: 'bpz_consults', role: 'manager', makerLimit: 5e4, canCheck: true, email: 'c@x', clientId: 6 },
    { username: 'other_client', role: 'accountant', makerLimit: 1e4, canCheck: false, email: 'x@x', clientId: 7 },
  ] as unknown as import('../types/accounting').UserAccount[];
  const clientUser = rows[1];
  const visible = visiblePostingDirectory(rows, clientUser);
  const names = visible.map((u) => u.username);
  assert.ok(names.includes('bpz_consults'));
  assert.ok(names.includes('owner'));
  assert.ok(!names.includes('other_client'));
  const directory = browserPostingDirectory([], clientUser);
  assert.ok(directory.has('bpz_consults'), 'the session user is always present even on an empty cache');
  assert.equal(directory.get('bpz_consults')!.username, 'bpz_consults');
});

test('tax settings structure conforms to statutory format', async () => {
  const { DEFAULT_GH_TAX_SETTINGS } = await import('../utils/taxConfig');
  assert.equal(DEFAULT_GH_TAX_SETTINGS.jurisdiction, 'GH');
  assert.ok(DEFAULT_GH_TAX_SETTINGS.payeBands.length >= 7);
  assert.ok(DEFAULT_GH_TAX_SETTINGS.components.some((c) => c.code === 'VAT' && c.rate === 15));
  assert.ok(DEFAULT_GH_TAX_SETTINGS.components.some((c) => c.code === 'NHIL' && c.rate === 2.5));
  assert.ok(DEFAULT_GH_TAX_SETTINGS.components.some((c) => c.code === 'GETFUND' && c.rate === 2.5));
});

test('the master chart of accounts has no duplicate account numbers', async () => {
  const { INITIAL_CHART_OF_ACCOUNTS } = await import('../data/accountingSeed');
  const seen = new Set<string>();
  const dupes = INITIAL_CHART_OF_ACCOUNTS.map((a) => a.accountNo).filter((n) => (seen.has(n) ? true : (seen.add(n), false)));
  assert.deepEqual(dupes, []);
});

test('gold royalty L.I. 2588 sliding scale is native and price-linked', () => {
  assert.equal(goldRoyaltyRate(1200), 3);
  assert.equal(goldRoyaltyRate(1400), 3.5);
  assert.equal(goldRoyaltyRate(2000), 4);
  assert.equal(goldRoyaltyRate(2400), 4.5);
  assert.equal(goldRoyaltyRate(2650), 5);
  const r = computeMineralRoyalty({ mineral: 'gold', grossRevenue: 8_000_000, usdPerOz: 2650 });
  assert.equal(r.ratePct, 5);
  assert.equal(r.royalty, 400_000);
  const baux = computeMineralRoyalty({ mineral: 'bauxite', grossRevenue: 1_000_000 });
  assert.equal(baux.royalty, 50_000);
});

test('NPA/ESLA fuel levies are volume × rate, two decimal places', () => {
  const f = computeFuelLevies(10_000, [{ code: 'EDRL', label: 'EDRL', ratePerLitre: 0.49 }, { code: 'ROAD', label: 'Road', ratePerLitre: 0.46 }]);
  assert.equal(f.total, 9500);
});

test('IFRS 9 EIR solves so PV of instalments equals net amount advanced', () => {
  const principal = 100_000;
  const n = 12;
  const instalment = contractualInstalment(principal, 24, n, 12);
  const eir = solveEffectiveRate(principal, instalment, n);
  // At the contractual rate with no fees, EIR ≈ contractual periodic rate.
  assert.ok(Math.abs(eir * 12 * 100 - 24) < 0.15, `eir annual ${eir * 12 * 100}`);
  const withFees = buildEirSchedule({
    id: 'L', borrower: 'X', principal: 100_000, feesNet: 2_000, annualContractualRatePct: 24, termMonths: 12,
    paymentsPerYear: 12, startDate: '2026-01-31', pd12Pct: 2, pdLifetimePct: 8, lgdPct: 40, stage: 1,
  });
  // Fees increase the effective rate above the contractual rate.
  assert.ok(withFees.eirAnnualPct > 24, `eir ${withFees.eirAnnualPct}`);
  assert.equal(withFees.rows[withFees.rows.length - 1].closing, 0);
});

test('IFRS 17 PAA allocates premium over coverage elapsed and builds LRC/LIC', () => {
  const r = computeIfrs17Paa({
    id: 'p', product: 'motor', coverageStart: '2026-01-01', coverageEnd: '2026-12-31',
    premiumsReceived: 120_000, acquisitionCosts: 12_000, expectedClaims: 80_000, actualClaims: 20_000,
    riskAdjustment: 4_000, coverageElapsedPct: 0.25, onerous: false,
  });
  assert.equal(r.insuranceRevenue, 30_000);
  assert.ok(r.lrc > 0);
  assert.equal(r.lic, 24_000);
});

test('petroleum royalty and AOE, IAS 41 FV movement, pension NAV and MRP explosion', () => {
  const p = computePetroleumRoyalty({ grossProductionValue: 10_000_000, royaltyRatePct: 5, additionalOilEntitlementPct: 2 });
  assert.equal(p.royalty, 500_000);
  assert.equal(p.totalStateTake, 700_000);
  const b = computeBiologicalMovement(100, 10, 20, 130, 5);
  assert.equal(b.closing, 125);
  assert.equal(b.fairValueGain, 35);
  const nav = computePensionNav([{ id: 'a', name: 'A', units: 100, employeeContribution: 10, employerContribution: 10 }], 1000, 50, 50);
  assert.equal(nav.nav, 1000);
  assert.equal(nav.unitPrice, 10);
  const mrp = explodeMrp('FG', 10, [{ parentItemCode: 'FG', componentItemCode: 'RM', qtyPerUnit: 2, wastePct: 10 }], [{ itemCode: 'RM', quantityOnHand: 15 }]);
  assert.equal(mrp.lines[0].required, 22);
  assert.equal(mrp.lines[0].shortage, 7);
});

test('ticked allowedModules restrict a client user to only those modules', () => {
  const clientEntity = {
    ...INITIAL_CLIENTS[1],
    assignedServices: ['bookkeeping', 'payroll', 'tax_compliance', 'management_accounts', 'ifrs_reporting'],
  };
  const tickedUser = {
    username: 'client.ticked',
    name: 'Ticked Client',
    role: 'accountant' as const,
    email: 'ticked@client.gh',
    makerLimit: 25000,
    canCheck: false,
    clientId: clientEntity.id,
    status: 'active' as const,
    permissions: {
      canPostJournals: true,
      canApprovePayments: false,
      canRunPayroll: true,
      canClosePeriod: false,
      canModifyCOA: false,
      allowedModules: ['sales', 'procurement'],
    },
  };
  assert.equal(maySeeSection(tickedUser, clientEntity, 'sales'), true);
  assert.equal(maySeeSection(tickedUser, clientEntity, 'procurement'), true);
  assert.equal(maySeeSection(tickedUser, clientEntity, 'payroll'), false);
  assert.equal(maySeeSection(tickedUser, clientEntity, 'ifrs_statements'), false);
  assert.equal(mayUseDesk(tickedUser, clientEntity, 'hr'), false);
  assert.equal(mayUseDesk(tickedUser, clientEntity, 'crm'), false);
  assert.equal(mayUseDesk(tickedUser, clientEntity, 'store'), true);
});