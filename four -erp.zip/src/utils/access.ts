import type { ClientEntity, UserAccount } from '../types/accounting';
import { OWNER_ONLY_MODULES, CLIENT_MODULE_IDS, ALWAYS_AVAILABLE_MODULES } from './moduleCatalog';

// UI-level scoping for the demo. The production API must independently enforce every rule.
export const serviceForSection: Record<string, string> = {
  procurement: 'bookkeeping', sales: 'bookkeeping', business_partners: 'bookkeeping',
  payment_desk: 'management_accounts', banking: 'management_accounts', expenses: 'bookkeeping',
  ageing: 'management_accounts', report_ageing_r: 'management_accounts', control_accounts: 'management_accounts',
  inventory: 'bookkeeping', inventory_ledger: 'bookkeeping', assets: 'bookkeeping', prepayments: 'management_accounts', payroll: 'payroll',
  hr_desk: 'payroll', hr_employees: 'payroll', hr_structure: 'payroll', hr_attendance: 'payroll', hr_requests: 'payroll', hr_tasks: 'payroll',
  crm_desk: 'bookkeeping', business_partners_crm: 'bookkeeping', ifrs_desk: 'ifrs_reporting',
  tax_schedule: 'tax_compliance', tax_schedules: 'tax_compliance', coa_master: 'management_accounts',
  general_ledger: 'management_accounts',
  universal_journal: 'management_accounts', manual_journal: 'management_accounts',
  adjustments: 'management_accounts',
  opening_balance: 'management_accounts', month_end: 'management_accounts', sector_workflow: 'bookkeeping',
  project_costing: 'management_accounts',
  regulated_industries: 'ifrs_reporting',
  boms: 'bookkeeping', production_desk: 'bookkeeping', report_production_r: 'management_accounts',
  financial_reports: 'management_accounts', standards_desk: 'ifrs_reporting',
  loans_desk: 'ifrs_reporting', disclosures: 'ifrs_reporting',
  ifrs_statements: 'ifrs_reporting', compliance_review: 'ifrs_reporting',
};

// Treasury desks (banking, payments, ageing) serve both bookkeeping and finance
// contracts: a client with EITHER service keeps treasury visible so live books
// never lose the cash gateway after a service change.
const TREASURY_SECTIONS = new Set(['payment_desk', 'banking', 'ageing', 'report_ageing_r']);
export const maySeeSection = (user: UserAccount, client: ClientEntity, section: string) => {
  if (user.role === 'owner') return true;
  // Firm administration is never shown to anyone but the Firm Owner.
  if (OWNER_ONLY_MODULES.has(section)) return false;
  if (user.status === 'restricted' || user.status === 'suspended') return false;
  // Firm-level partners/managers may work across their assigned practice's
  // entities. Only client-bound accounts require the exact entity match.
  if (!hasFirmWideScope(user) && (!user.clientId || user.clientId !== client.id)) return false;
  // Everyone can open their own security desk, even on a narrowly ticked contract.
  if (ALWAYS_AVAILABLE_MODULES.has(section)) return true;
  // Per-user module ticks: when the owner has ticked specific modules, only those open.
  const allowed = user.permissions?.allowedModules;
  if (Array.isArray(allowed) && CLIENT_MODULE_IDS.has(section) && !allowed.includes(section)) return false;
  const service = serviceForSection[section];
  if (service && client.assignedServices) {
    if (TREASURY_SECTIONS.has(section)) {
      if (!client.assignedServices.includes('management_accounts') && !client.assignedServices.includes('bookkeeping')) return false;
    } else if (!client.assignedServices.includes(service)) return false;
  }
  if ((section === 'payroll' || section === 'report_hr_r') && user.permissions?.canRunPayroll === false) return false;
  if (section === 'month_end' && user.permissions?.canClosePeriod === false) return false;
  if (section === 'coa_master' && user.permissions?.canModifyCOA === false) return false;
  return true;
};
/**
 * Firm-wide data scope: the owner plus firm-level partner/manager accounts that
 * are not bound to a client entity. Shared by the API (tenant filtering) and the
 * UI (entity switcher) so both apply exactly the same rule.
 */
export function hasFirmWideScope(user: { role: string; clientId?: number | null }): boolean {
  if (user.role === 'owner') return true;
  return (user.clientId === undefined || user.clientId === null) && (user.role === 'partner' || user.role === 'manager');
}

/**
 * Who may rename / re-categorise / deactivate general ledger (chart of
 * accounts) names.
 *
 * Account names are reporting-critical master data: a rename changes every
 * statement caption the account feeds. Authority is therefore limited to
 *   • the Firm Owner (firm master chart and any entity), and
 *   • the client entity's own owner/manager (their entity only).
 * Operational staff — accountants, auditors and firm partners acting as
 * reviewers — may read the chart and post to it, but never edit its names.
 * The Firm Owner can additionally withdraw the right from a manager through
 * `permissions.canModifyCOA`.
 */
export const mayEditChartOfAccounts = (user: {
  role: string;
  status?: string;
  permissions?: { canModifyCOA?: boolean };
}): boolean => {
  if (user.status === 'restricted' || user.status === 'suspended') return false;
  if (user.role === 'owner') return true;
  if (user.role !== 'manager') return false;
  return user.permissions?.canModifyCOA !== false;
};

const DESK_SECTIONS: Record<string, string[]> = {
  hr: ['hr_desk', 'hr_employees', 'hr_attendance', 'hr_requests', 'hr_structure', 'hr_tasks', 'payroll'],
  crm: ['crm_desk', 'business_partners_crm'],
  store: ['inventory', 'inventory_ledger', 'procurement'],
  projects: ['project_costing'],
  finance: ['loans_desk'],
  workbook_ifrs: ['ifrs_desk', 'ifrs_statements', 'standards_desk'],
  workbook_planning: ['performance'],
  workbook_regulated: ['regulated_industries'],
};

/** Server-side check that a user's ticked modules and contracted services allow a desk API. */
export const mayUseDesk = (user: UserAccount, client: ClientEntity | undefined | null, deskKey: string): boolean => {
  if (user.role === 'owner' || hasFirmWideScope(user)) return true;
  if (!client) return false;
  const sections = DESK_SECTIONS[deskKey];
  if (!sections) return true;
  return sections.some((section) => maySeeSection(user, client, section));
};

/** Human-readable reason shown when the chart of accounts is read-only. */
export const chartEditDenialReason = (user: { role: string; status?: string; permissions?: { canModifyCOA?: boolean } }): string => {
  if (user.status === 'restricted' || user.status === 'suspended') return 'Your account is restricted, so master data cannot be changed.';
  if (user.role === 'owner' || user.role === 'manager') return 'Your chart-of-accounts rights have been withdrawn by the Firm Owner.';
  return 'Only the Firm Owner or the entity\'s owner/manager may edit general ledger account names. Your role has read and posting access only.';
};
