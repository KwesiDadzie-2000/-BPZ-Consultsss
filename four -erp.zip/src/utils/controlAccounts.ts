/**
 * Control account reconciliation engine.
 *
 * PURPOSE (IAS 1.117 / double-entry bookkeeping practice): every balance that is
 * tracked in a subsidiary ledger, register or document store must agree with its
 * control account in the general ledger, to the pesewa — Trade Receivables vs the
 * open invoice ledger, Inventories vs the perpetual item master, Trade Payables vs
 * open supplier bills, Treasury vs cash/bank records, PPE vs the fixed-asset
 * register, statutory liabilities vs tax schedules, and the IFRS 9 ECL allowance
 * vs the required simplified-model provision.
 *
 * MULTI-CURRENCY RULE: a control is reconciled PER CURRENCY. Summing a GHS bank
 * balance with a GBP one produces a number that matches nothing, so a multi-currency
 * entity would show permanent false differences. Each currency gets its own row:
 * the GL balance in that currency against the sub-ledger balance in that currency.
 * A currency that appears only in the GL is surfaced as its own reconciling row
 * rather than being folded into another currency's figure.
 *
 * Every figure here is COMPUTED, not displayed: the GL side sums posted journal
 * lines in minor units; the sub-ledger side aggregates live registers from the
 * very same modules that produced the postings. A non-zero difference is a
 * reconciling item that must be investigated — the Month-End close checklist and
 * the Control Accounts desk both surface it.
 */
import type {
  ACDOCALine,
  BankAccount,
  FixedAsset,
  MonthlyPayrollRecord,
  PrepaymentRecord,
  PrepaymentScheduleLine,
  PurchaseOrder,
  SalesInvoice,
  StockItem,
  TaxScheduleEntry,
  BusinessPartner,
} from '../types/accounting';
import { deriveExpenseBills } from './payables';
import { treasuryGl } from './treasury';
import {
  deriveVatInput,
  deriveVatOutput,
  deriveWhtDeductions,
  mergeScheduleRows,
  r2,
  type ScheduleRow,
  type VatRates,
} from './ledger';
import { DEFAULT_IFRS_INPUTS, ECL_BUCKETS } from './ifrsSchedules';

export const CONTROL_TOLERANCE = 0.005;

export interface ControlSubItem {
  label: string;
  amount: number;
}

export type ControlStatus = 'reconciled' | 'out' | 'clear';

export interface ControlAccountReco {
  key: string;
  accountNo: string;
  accountName: string;
  /** dr = debit-normality control, cr = credit-normality control. */
  side: 'dr' | 'cr';
  /** ISO 4217 code this row reconciles. Multi-currency entities get one row per currency. */
  currency: string;
  /** Balance of the GL control account in `currency` (normalised to the control's side). */
  gl: number;
  /** Balance computed from the sub-ledger / operational register in `currency`. */
  subLedger: number;
  /** gl - subLedger (positive on the control's normal side). */
  difference: number;
  status: ControlStatus;
  /** IFRS / statutory basis for this control. */
  basis: string;
  /** What to do when the two sides disagree. */
  resolution: string;
  subItems: ControlSubItem[];
}

export interface ControlRecoInput {
  clientId: number;
  lines: ACDOCALine[];
  invoices: SalesInvoice[];
  orders: PurchaseOrder[];
  stockItems: StockItem[];
  bankAccounts: BankAccount[];
  assets: FixedAsset[];
  prepayments: PrepaymentRecord[];
  prepaymentSchedules: PrepaymentScheduleLine[];
  payrollRecords: MonthlyPayrollRecord[];
  partners: BusinessPartner[];
  taxEntries?: TaxScheduleEntry[];
  /** The entity's reporting currency. Currency-less registers (PPE, stock, prepayments) are measured in it. */
  functionalCurrency?: string;
  /** VAT stack rates used by the tax schedules (defaults to 2026 Ghana rules). */
  vatRates?: VatRates;
  /** Optional as-of cut-off (YYYY-MM-DD). Limits the GL side; registers are current. */
  asOf?: string;
  /** Simplified IFRS 9 matrix (defaults to the IFRS Desk defaults). */
  eclRates?: number[];
  eclCreditTermsDays?: number;
}

const DEFAULT_VAT_RATES: VatRates = { vat: 15, nhil: 2.5, getfund: 2.5, covid: 0 };

type CurrencyBucket = { currency: string; amount: number; items: ControlSubItem[] };

export function reconcileControlAccounts(input: ControlRecoInput): ControlAccountReco[] {
  const {
    clientId,
    invoices,
    orders,
    stockItems,
    bankAccounts,
    assets,
    prepayments,
    prepaymentSchedules,
    payrollRecords,
    partners,
    asOf,
  } = input;
  const taxEntries = input.taxEntries ?? [];
  const rates = input.vatRates ?? DEFAULT_VAT_RATES;
  const eclRates = input.eclRates ?? DEFAULT_IFRS_INPUTS.ecl.rates;
  const eclTerms = input.eclCreditTermsDays ?? DEFAULT_IFRS_INPUTS.ecl.creditTermsDays;
  const home = (input.functionalCurrency ?? 'GHS').toUpperCase();

  const own = <T extends { clientId?: number | null }>(rows: T[]): T[] =>
    rows.filter((r) => (r.clientId ?? clientId) === clientId);

  const entityLines = input.lines.filter(
    (l) => l.clientId === clientId && (!asOf || l.date <= asOf)
  );

  /** Normalised control balance in one currency (debit-credit for assets, credit-debit for liabilities). */
  const glBal = (accountNo: string, side: 'dr' | 'cr', currency?: string): number => {
    const net = entityLines.reduce((n, l) => {
      if (l.accountNo !== accountNo) return n;
      if (currency && String(l.currency).toUpperCase() !== currency) return n;
      return n + (side === 'dr' ? l.debit - l.credit : l.credit - l.debit);
    }, 0);
    return r2(net);
  };
  const glBalRange = (lo: string, hi: string, side: 'dr' | 'cr', currency?: string): number => {
    const net = entityLines.reduce((n, l) => {
      if (l.accountNo < lo || l.accountNo > hi) return n;
      if (currency && String(l.currency).toUpperCase() !== currency) return n;
      return n + (side === 'dr' ? l.debit - l.credit : l.credit - l.debit);
    }, 0);
    return r2(net);
  };
  /** Every currency that has GL activity on an account — each needs its own row. */
  const glCurrencies = (...accountNos: string[]): string[] => {
    const set = new Set<string>();
    for (const l of entityLines) if (accountNos.includes(l.accountNo)) set.add(String(l.currency).toUpperCase());
    return [...set];
  };
  const rangeCurrencies = (lo: string, hi: string): string[] => {
    const set = new Set<string>();
    for (const l of entityLines) if (l.accountNo >= lo && l.accountNo <= hi) set.add(String(l.currency).toUpperCase());
    return [...set];
  };

  /** Registers like SalesInvoice/ScheduleRow carry no currency column: they are functional-currency. */
  const ccy = (row: unknown): string => String((row as { currency?: string | null })?.currency ?? home).toUpperCase();

  const rows: ControlAccountReco[] = [];
  const push = (spec: Omit<ControlAccountReco, 'difference' | 'status'>) => {
    const difference = r2(spec.gl - spec.subLedger);
    const status: ControlStatus =
      Math.abs(spec.gl) < CONTROL_TOLERANCE && Math.abs(spec.subLedger) < CONTROL_TOLERANCE
        ? 'clear'
        : Math.abs(difference) < CONTROL_TOLERANCE
          ? 'reconciled'
          : 'out';
    rows.push({ ...spec, difference, status });
  };

  /**
   * Emits one row per currency the sub-ledger or the GL uses. A currency held
   * only in the GL (e.g. a manual foreign-currency posting with no register)
   * gets its own row so it can never inflate or hide another currency's figure.
   */
  const pushPerCurrency = (
    base: { key: string; accountNo: string; accountName: string; side: 'dr' | 'cr'; basis: string; resolution: string },
    buckets: CurrencyBucket[],
    extraGlCurrencies: string[],
    glFrom: (currency: string) => number,
  ) => {
    const seen = new Set(buckets.map((b) => b.currency));
    for (const bucket of buckets) push({ ...base, currency: bucket.currency, gl: glFrom(bucket.currency), subLedger: bucket.amount, subItems: bucket.items.slice(0, 12) });
    for (const currency of extraGlCurrencies) {
      if (seen.has(currency)) continue;
      push({ ...base, currency, gl: glFrom(currency), subLedger: 0, subItems: [{ label: 'No register rows in this currency', amount: 0 }] });
    }
  };

  /** Group sub-ledger rows by currency so multi-currency entities reconcile per currency. */
  const byCurrency = (items: { currency?: string; label: string; amount: number }[], fallback = home) => {
    const map = new Map<string, CurrencyBucket>();
    for (const item of items) {
      const currency = String(item.currency ?? fallback).toUpperCase();
      const bucket = map.get(currency) ?? { currency, amount: 0, items: [] };
      bucket.amount = r2(bucket.amount + item.amount);
      bucket.items.push({ label: item.label, amount: item.amount });
      map.set(currency, bucket);
    }
    return [...map.values()];
  };

  /* 1 · Trade Receivables (IFRS 15 / IFRS 9) — open posted invoice ledger. */
  const openInvoices = own(invoices).filter(
    (i) => i.status !== 'Draft' && i.status !== 'Credited'
  );
  const arSub = openInvoices
    .map((i) => ({
      currency: ccy(i),
      label: `${i.invNo} · ${i.customerName}`,
      amount: r2(i.totalReceivable - (i.paidAmount ?? 0)),
    }))
    .filter((x) => Math.abs(x.amount) > CONTROL_TOLERANCE)
    .sort((a, b) => Math.abs(b.amount) - Math.abs(a.amount));
  pushPerCurrency(
    {
      key: 'receivables',
      accountNo: '110000',
      accountName: 'Trade Receivables Control',
      side: 'dr',
      basis: 'IFRS 15 contract receivables; IFRS 9 classification',
      resolution:
        'Identify unposted invoices, reversed receipts and VAT-withheld settlements; post the missing document or the reversal.',
    },
    byCurrency(arSub),
    glCurrencies('110000'),
    (currency) => glBal('110000', 'dr', currency),
  );

  /* 2 · WHT Receivable — GRA credit-note register. */
  const whtCreditOpen = openInvoices
    .filter((i) => (i.vatWithheldByCustomer ?? 0) > CONTROL_TOLERANCE)
    .map((i) => {
      const outstanding = r2(i.totalReceivable - (i.paidAmount ?? 0));
      const claimed = outstanding > CONTROL_TOLERANCE ? r2(i.vatWithheldByCustomer ?? 0) : 0;
      return { currency: ccy(i), label: `${i.invNo} · ${i.customerName} (WHT credit note)`, amount: claimed };
    })
    .filter((x) => x.amount > CONTROL_TOLERANCE);
  pushPerCurrency(
    {
      key: 'wht_receivable',
      accountNo: '115000',
      accountName: 'Withholding Tax Receivable — GRA Credits',
      side: 'dr',
      basis: 'Act 896 withholding certificates receivable',
      resolution: 'Follow up unissued GRA credit certificates or reverse credits not recoverable.',
    },
    byCurrency(whtCreditOpen),
    glCurrencies('115000'),
    (currency) => glBal('115000', 'dr', currency),
  );

  /* 3 · IFRS 9 ECL allowance — required simplified-model provision vs booked. */
  const requiredEcl: { currency?: string; label: string; amount: number }[] = openInvoices
    .map((i) => {
      const balance = r2(i.totalReceivable - (i.paidAmount ?? 0));
      if (balance <= CONTROL_TOLERANCE) return null;
      const dueMs = Date.parse(`${i.date}T00:00:00Z`) + eclTerms * 86_400_000;
      const today = asOf ?? new Date().toISOString().slice(0, 10);
      const daysPastDue = Math.max(0, Math.floor((Date.parse(`${today}T00:00:00Z`) - dueMs) / 86_400_000));
      const bucket = daysPastDue <= 0 ? 0 : daysPastDue <= 30 ? 1 : daysPastDue <= 60 ? 2 : daysPastDue <= 90 ? 3 : 4;
      const ratePct = eclRates[bucket] ?? eclRates[eclRates.length - 1] ?? 0;
      return {
        currency: ccy(i),
        label: `${i.invNo} · ${i.customerName} [${ECL_BUCKETS[bucket]} @ ${ratePct}%]`,
        amount: r2((balance * ratePct) / 100),
      };
    })
    .filter((x): x is NonNullable<typeof x> => x !== null);
  pushPerCurrency(
    {
      key: 'ecl_allowance',
      accountNo: '119000',
      accountName: 'Allowance for Expected Credit Losses (Control)',
      side: 'cr',
      basis: 'IFRS 9 simplified ECL model (lifetime expected credit losses)',
      resolution:
        'Post the under/over-provision through the IFRS Schedules Desk proposed entry (it routes through journal controls).',
    },
    byCurrency(requiredEcl).filter((b) => b.amount > CONTROL_TOLERANCE),
    glCurrencies('119000'),
    (currency) => glBal('119000', 'cr', currency),
  );

  /* 4 · Prepayments — unamortised balances of live prepayment schedules (functional currency). */
  const prepaidOpen = own(prepayments)
    .map((p) => {
      const posted = own(prepaymentSchedules)
        .filter((s) => s.prepaymentId === p.id && s.status === 'posted')
        .reduce((s, x) => s + x.amount, 0);
      return { label: `${p.code} · ${p.title} (${p.vendorName})`, amount: r2(p.totalAmount - posted) };
    })
    .filter((x) => x.amount > CONTROL_TOLERANCE);
  pushPerCurrency(
    {
      key: 'prepayments',
      accountNo: '116000',
      accountName: 'Prepayments & Deferred Charges Control',
      side: 'dr',
      basis: 'Accruals concept; expense recognised over the benefit period',
      resolution: 'Run the Prepayments & Deferrals desk to post outstanding monthly releases.',
    },
    byCurrency(prepaidOpen),
    glCurrencies('116000'),
    (currency) => glBal('116000', 'dr', currency),
  );

  /* 5 · Fixed Assets — register cost and accumulated depreciation roll-forward. */
  const ownAssets = own(assets);
  const ppeCostOpen = ownAssets
    .map((a) => ({ label: `${a.assetTag} · ${a.name}`, amount: r2(a.cost) }))
    .filter((x) => x.amount > CONTROL_TOLERANCE);
  pushPerCurrency(
    {
      key: 'ppe_cost',
      accountNo: '130000–136000',
      accountName: 'Property, Plant & Equipment @ Cost (all classes)',
      side: 'dr',
      basis: 'IAS 16.73(e) cost roll-forward (register held in the entity functional currency)',
      resolution:
        'Reconcile acquisitions/disposals: every purchase, capitalisation and disposal must hit a 13x cost account in the register currency.',
    },
    byCurrency(ppeCostOpen),
    rangeCurrencies('130000', '136999'),
    (currency) => glBalRange('130000', '136999', 'dr', currency),
  );
  const ppeDepOpen = ownAssets
    .map((a) => ({ label: `${a.assetTag} · ${a.name}`, amount: r2(a.accumDep) }))
    .filter((x) => x.amount > CONTROL_TOLERANCE);
  pushPerCurrency(
    {
      key: 'ppe_depreciation',
      accountNo: '139000',
      accountName: 'Accumulated Depreciation & Impairment — PPE',
      side: 'cr',
      basis: 'IAS 16.73(e) accumulated depreciation roll-forward (register held in the entity functional currency)',
      resolution: 'Run the fixed-asset periodic depreciation posting; post any missing depreciation charge.',
    },
    byCurrency(ppeDepOpen),
    glCurrencies('139000'),
    (currency) => glBal('139000', 'cr', currency),
  );

  /* 6 · Inventories — perpetual item master per control account (IAS 2). */
  const itemControls = ['120000', '121000', '122000', '123000', '124000'] as const;
  const controlNames: Record<string, string> = {
    '120000': 'Inventories — Raw Materials & Spares',
    '121000': 'Inventories — Finished Goods',
    '122000': 'Inventories — Work in Progress',
    '123000': 'Inventories — Spare Parts & Consumables',
    '124000': 'Biological Assets — Crops & Livestock (IAS 41)',
  };
  for (const control of itemControls) {
    const itemsAtControl = own(stockItems).filter((i) => (i.glAccount || '120000') === control);
    const subItems = itemsAtControl
      .map((i) => ({ label: `${i.itemCode} · ${i.description}`, amount: r2(i.totalValue) }))
      .filter((x) => Math.abs(x.amount) > CONTROL_TOLERANCE);
    const gl = glBal(control, 'dr', home);
    const sub = r2(subItems.reduce((s, x) => s + x.amount, 0));
    const foreign = glCurrencies(control).filter((c) => c !== home);
    if (Math.abs(gl) < CONTROL_TOLERANCE && Math.abs(sub) < CONTROL_TOLERANCE && itemsAtControl.length === 0 && foreign.length === 0) continue;
    pushPerCurrency(
      {
        key: `inventory_${control}`,
        accountNo: control,
        accountName: `${controlNames[control]} Control`,
        side: 'dr',
        basis: 'IAS 2 perpetual inventory with weighted-average / FIFO costing (register in functional currency)',
        resolution:
          'Only post stock movements through Procurement, Sales or Production; investigate manual postings directly to this control account.',
      },
      [{ currency: home, amount: sub, items: subItems }],
      foreign,
      (currency) => glBal(control, 'dr', currency),
    );
  }

  /* 7 · Treasury — each cash/bank ledger account AND currency vs its operational
   * funds record. One row per (GL, currency): a currency held only in the GL gets
   * its own row, and every currency appears exactly once. */
  const treasuryBuckets = new Map<string, CurrencyBucket>();
  const treasuryBucket = (glNo: string, currency: string): CurrencyBucket => {
    const key = `${glNo}|${currency}`;
    let bucket = treasuryBuckets.get(key);
    if (!bucket) { bucket = { currency, amount: 0, items: [] }; treasuryBuckets.set(key, bucket); }
    return bucket;
  };
  for (const b of own(bankAccounts)) {
    const glNo = treasuryGl(b);
    const currency = String(b.currency || home).toUpperCase();
    const bucket = treasuryBucket(glNo, currency);
    bucket.amount = r2(bucket.amount + r2(b.balance));
    bucket.items.push({ label: `${b.code} · ${b.name} (${b.bankName})`, amount: r2(b.balance) });
  }
  // GL-only currencies (a manual foreign-currency posting with no treasury record)
  // must surface as their own reconciling row, never folded into another currency.
  for (const l of entityLines) {
    if (!/^10\d{4}$/.test(l.accountNo)) continue;
    treasuryBucket(l.accountNo, String(l.currency).toUpperCase());
  }
  for (const key of [...treasuryBuckets.keys()].sort()) {
    const [glNo, currency] = key.split('|');
    const bucket = treasuryBuckets.get(key)!;
    push({
      key: `treasury_${glNo}_${currency}`,
      accountNo: glNo,
      accountName: `Treasury Control — GL ${glNo}`,
      side: 'dr',
      currency,
      gl: glBal(glNo, 'dr', currency),
      subLedger: bucket.amount,
      basis: 'Cash & bank per ledger must equal operational treasury records (matched currency by currency)',
      resolution:
        'Reconcile in Banking & Reconcile: identify unposted receipts/payments and journal any opening-balance difference in this currency.',
      subItems: bucket.items,
    });
  }

  /* 8 · Trade Payables — open received supplier bills. */
  const openBills = own(orders).filter((o) => o.status === 'Invoiced' || o.status === 'Paid');
  const apSub = openBills
    .map((o) => ({
      currency: o.currency,
      label: `${o.poNo} · ${o.vendorName}`,
      amount: r2(o.totalAmount - (o.paidAmount ?? 0)),
    }))
    .filter((x) => Math.abs(x.amount) > CONTROL_TOLERANCE)
    .sort((a, b) => Math.abs(b.amount) - Math.abs(a.amount));
  pushPerCurrency(
    {
      key: 'payables',
      accountNo: '200000',
      accountName: 'Trade Payables Control',
      side: 'cr',
      basis: 'Trade payables — receipts against invoiced purchase orders',
      resolution: 'Identify supplier postings made directly to GL without a purchase order, or unreceived invoices.',
    },
    byCurrency(apSub),
    glCurrencies('200000'),
    (currency) => glBal('200000', 'cr', currency),
  );

  /* 9 · Accrued expenses — expense bill register (derived from the journal). */
  const expenseBills = deriveExpenseBills(entityLines, clientId).filter((b) => b.outstanding > CONTROL_TOLERANCE);
  pushPerCurrency(
    {
      key: 'accrued_expenses',
      accountNo: '202000',
      accountName: 'Accrued Expenses & Other Payables Control',
      side: 'cr',
      basis: 'Accruals — expense bills awaiting settlement',
      resolution: 'Settle open bills at the Payment Desk or reverse stale accruals with a journal.',
    },
    byCurrency(expenseBills.map((b) => ({ currency: b.currency, label: `${b.billNo} · ${b.payee}`, amount: r2(b.outstanding) }))),
    glCurrencies('202000'),
    (currency) => glBal('202000', 'cr', currency),
  );

  /* 10 · Net Salary Payable — posted payroll less disbursed releases. */
  const postedPayroll = own(payrollRecords).filter((r) => r.status === 'Posted');
  const releasedByCurrency = new Map<string, number>();
  for (const l of entityLines) {
    if (l.accountNo !== '205000' || !l.docNo.startsWith('PAY-SAL-')) continue;
    const c = String(l.currency).toUpperCase();
    releasedByCurrency.set(c, r2((releasedByCurrency.get(c) ?? 0) + l.debit - l.credit));
  }
  const payrollBuckets = byCurrency(
    postedPayroll.map((r) => ({ currency: r.currency, label: `${r.period} · ${r.name}`, amount: r2(r.netSalary) })),
  ).map((b) => ({ ...b, amount: r2(b.amount - (releasedByCurrency.get(b.currency) ?? 0)) }));
  pushPerCurrency(
    {
      key: 'net_salaries',
      accountNo: '205000',
      accountName: 'Net Salaries Payable Control',
      side: 'cr',
      basis: 'IAS 19 short-term employee benefits — net pay outstanding',
      resolution: 'Disburse the outstanding payroll at the Payment Desk; investigate any salary accrual opened by journal.',
    },
    payrollBuckets,
    glCurrencies('205000'),
    (currency) => glBal('205000', 'cr', currency),
  );

  /* 11 · VAT net position — output stack + customer-facing withholding less unreclaimed input. */
  const openTaxStatuses = (r: ScheduleRow) => r.status !== 'Filed' && r.status !== 'Remitted';
  const taxPlusLevy = (r: ScheduleRow) => r.taxAmount + (r.levyAmount ?? 0);
  const vatOutRows = mergeScheduleRows(deriveVatOutput(entityLines, clientId, null, invoices, partners, rates), taxEntries, 'vat_output', clientId, null);
  const vatInRows = mergeScheduleRows(deriveVatInput(entityLines, clientId, null, orders, partners, rates), taxEntries, 'vat_input', clientId, null);
  const vatOutByCurrency = new Map<string, number>();
  for (const r of vatOutRows.filter(openTaxStatuses)) { const c = ccy(r); vatOutByCurrency.set(c, r2((vatOutByCurrency.get(c) ?? 0) + taxPlusLevy(r))); }
  const vatInByCurrency = new Map<string, number>();
  for (const r of vatInRows.filter(openTaxStatuses)) { const c = ccy(r); vatInByCurrency.set(c, r2((vatInByCurrency.get(c) ?? 0) + taxPlusLevy(r))); }
  const vatAccounts = ['220000', '221000', '223000', '224000', '125000'];
  const vatBuckets: CurrencyBucket[] = [...new Set([...vatOutByCurrency.keys(), ...vatInByCurrency.keys(), home])]
    .map((currency) => ({
      currency,
      amount: r2((vatOutByCurrency.get(currency) ?? 0) - (vatInByCurrency.get(currency) ?? 0)),
      items: [
        { label: 'Output VAT & levies — open items', amount: r2(vatOutByCurrency.get(currency) ?? 0) },
        { label: 'Input VAT unreclaimed', amount: r2(-(vatInByCurrency.get(currency) ?? 0)) },
      ],
    }))
    .filter((b) => Math.abs(b.amount) > CONTROL_TOLERANCE || b.currency === home);
  pushPerCurrency(
    {
      key: 'vat_net',
      accountNo: '125000/220000–224000',
      accountName: 'VAT & Levies Net Liability Control',
      side: 'cr',
      basis: 'VAT Act 2013 (Act 870) with NHIL/GETFund/COVID/CST/tourism stack — open return position',
      resolution: 'File/remit open return items at the Tax Desk; manual VAT postings must also be recorded in the schedule.',
    },
    vatBuckets,
    [...new Set(vatAccounts.flatMap((a) => glCurrencies(a)))],
    (currency) =>
      r2(glBal('220000', 'cr', currency) + glBal('221000', 'cr', currency) + glBal('223000', 'cr', currency) + glBal('224000', 'cr', currency) - glBal('125000', 'dr', currency)),
  );

  /* 12 · Income WHT payable — deducted, unremitted schedules. */
  const whtPayRows = mergeScheduleRows(deriveWhtDeductions(entityLines, clientId, null, partners), taxEntries, 'wht', clientId, null);
  const whtOpenRows = whtPayRows.filter((r) => r.status === 'Deducted' || r.status === 'Pending' || r.status === 'Certificate issued');
  pushPerCurrency(
    {
      key: 'wht_payable',
      accountNo: '209000',
      accountName: 'Income Withholding Tax Payable Control',
      side: 'cr',
      basis: 'Act 896 — tax withheld at source, remittable to GRA by the 15th of the following month',
      resolution: 'Remit open withholdings at the Payment Desk (Statutory remittance) with the WHT schedule as support.',
    },
    byCurrency(whtOpenRows.map((r) => ({ currency: ccy(r), label: `${r.docNo} · ${r.partyName}`, amount: r2(r.taxAmount) }))),
    glCurrencies('209000'),
    (currency) => glBal('209000', 'cr', currency),
  );

  return rows;
}

/** Grand summary used by dashboards and the month-end close gate. */
export function controlAccountSummary(rows: ControlAccountReco[]) {
  const out = rows.filter((r) => r.status === 'out');
  return {
    total: rows.length,
    reconciled: rows.filter((r) => r.status === 'reconciled').length,
    clear: rows.filter((r) => r.status === 'clear').length,
    outOfBalance: out.length,
    exceptions: out.map((r) => ({ key: r.key, label: `${r.accountNo} ${r.accountName}`, difference: r.difference })),
  };
}
