/**
 * Currency presentation and parsing helpers shared by every posting desk.
 *
 * A Ghana practice keeps books in several currencies (GHS functional, USD/GBP/EUR
 * transactions). Hard-coding "₵" or the entity's functional currency into a
 * posting form is wrong: the operator must choose the DOCUMENT currency, and the
 * amount label must follow that choice. These helpers centralise the formatting
 * and the option-string parsing so no desk can silently mislabel or truncate.
 */

const SYMBOLS: Record<string, string> = {
  GHS: "\u20b5",
  USD: "$",
  GBP: "\u00a3",
  EUR: "\u20ac",
  NGN: "\u20a6",
  ZAR: "R",
  KES: "KSh",
  XOF: "CFA ",
  XAF: "FCFA ",
  CNY: "\u00a5",
  JPY: "\u00a5",
  CHF: "CHF ",
  CAD: "C$",
  AUD: "A$",
  SAR: "SR ",
  AED: "AED ",
};

/** ISO 4217 currencies the workspace offers alongside the entity's functional currency. */
export const POSTABLE_CURRENCIES = ["GHS", "USD", "GBP", "EUR", "NGN", "ZAR", "XOF", "CNY", "CHF", "CAD"] as const;

export function currencySymbol(code: string | undefined | null): string {
  const iso = String(code ?? "").toUpperCase();
  return SYMBOLS[iso] ?? `${iso} `;
}

/** ₵1,234.50 / $1,234.50 — two decimals, symbol of the DOCUMENT currency. */
export function formatMoney(value: number, currency: string | undefined | null): string {
  const n = Number.isFinite(value) ? value : 0;
  return `${currencySymbol(currency)}${n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/**
 * The journal selects are rendered as `"<accountNo> · <name>"`. An account name
 * may itself contain the separator (e.g. "Mobile Money — MTN / Vodafone · AirtelTigo"),
 * so splitting on the first separator truncated the name and posted a wrong caption.
 */
export function parseAccountOption(value: string): { accountNo: string; accountName: string } {
  const idx = value.indexOf(" \u00b7 ");
  if (idx === -1) return { accountNo: value.trim(), accountName: value.trim() };
  return {
    accountNo: value.slice(0, idx).trim(),
    accountName: value.slice(idx + 3).trim(),
  };
}

export function formatAccountOption(accountNo: string, name: string): string {
  return `${accountNo} \u00b7 ${name}`;
}
