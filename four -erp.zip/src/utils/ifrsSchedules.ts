import type {
  ACDOCALine,
  AccountMaster,
  FixedAsset,
  MonthlyPayrollRecord,
  PurchaseOrder,
  SalesInvoice,
  StockItem,
  StockMovement,
} from '@/types/accounting';
import { buildCostCentreReport } from '@/utils/reports';
import { groupOf, type Group } from '@/utils/ifrsPack';

/**
 * IFRS schedules engine.
 *
 * Builds the supporting schedules behind every standard disclosed in the
 * notes, from the posted ledger, the subsidiary registers (asset register,
 * stock, sales invoices, payroll) and the persisted schedule inputs (leases,
 * provisions, ECL matrix, related parties, events, EPS, impairment tests).
 *
 * Each schedule:
 *  - cross-references its note number in the IFRS pack;
 *  - reconciles the schedule to the general ledger and reports differences;
 *  - proposes balanced correcting journals that flow through the normal
 *    maker-checker posting path (never written directly);
 *  - carries an idempotency key so the same adjustment cannot be posted twice.
 */

export const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const minor = (n: number) => Math.round((Number(n) || 0) * 100);
const DAY = 86_400_000;
const toTime = (d: string) => Date.parse(`${d}T00:00:00Z`);
const isoDay = (t: number) => new Date(t).toISOString().slice(0, 10);
export const dayBefore = (d: string) => isoDay(toTime(d) - DAY);
export const addMonths = (d: string, months: number) => {
  const dt = new Date(`${d}T00:00:00Z`);
  const day = dt.getUTCDate();
  dt.setUTCDate(1);
  dt.setUTCMonth(dt.getUTCMonth() + months);
  const last = new Date(Date.UTC(dt.getUTCFullYear(), dt.getUTCMonth() + 1, 0)).getUTCDate();
  dt.setUTCDate(Math.min(day, last));
  return isoDay(dt.getTime());
};
const yearsBetween = (a: string, b: string) => Math.max(0, (toTime(b) - toTime(a)) / (365.25 * DAY));
const uid = () => Math.random().toString(36).slice(2, 10);

/* ------------------------------------------------------------------ */
/* Persisted schedule inputs                                           */
/* ------------------------------------------------------------------ */

export interface LeaseInput { id: string; name: string; lessor: string; commencement: string; termMonths: number; payment: number; frequency: 'monthly' | 'quarterly' | 'annual'; timing: 'advance' | 'arrears'; ratePct: number; initialDirectCosts: number }
export interface ProvisionInput { id: string; name: string; category: string; opening: number; additions: number; utilised: number; reversed: number; unwinding: number; expectedTiming: string }
export interface ContingencyInput { id: string; nature: string; estimate: number; likelihood: 'remote' | 'possible' | 'probable'; status: string }
export interface RelatedPartyInput { id: string; party: string; relationship: string; nature: string; transactions: number; balance: number }
export interface EventInput { id: string; date: string; description: string; type: 'adjusting' | 'non-adjusting'; effect: number; treatment: string }
export interface ImpairmentInput { id: string; cgu: string; carryingAmount: number; cashFlows: string; growthPct: number; discountPct: number; fvlcd: number }
export interface TaxAdjustmentInput { id: string; label: string; amount: number; kind: 'permanent_addback' | 'permanent_deduction' | 'temporary_taxable' | 'temporary_deductible' }

export interface IfrsInputs {
  leases: LeaseInput[];
  provisions: ProvisionInput[];
  contingencies: ContingencyInput[];
  relatedParties: RelatedPartyInput[];
  events: EventInput[];
  impairments: ImpairmentInput[];
  taxAdjustments: TaxAdjustmentInput[];
  ecl: { rates: number[]; creditTermsDays: number };
  eps: { weightedShares: number; dilutiveShares: number; preferenceDividends: number };
  nrv: Record<string, number>;
  fxShockPct: number;
  interestShockPct: number;
  kmpCompensation: number;
}

export const ECL_BUCKETS = ['Current (not yet due)', '1–30 days past due', '31–60 days past due', '61–90 days past due', 'Over 90 days past due'];

export const DEFAULT_IFRS_INPUTS: IfrsInputs = {
  leases: [],
  provisions: [],
  contingencies: [],
  relatedParties: [],
  events: [],
  impairments: [],
  taxAdjustments: [],
  ecl: { rates: [1, 3, 8, 20, 50], creditTermsDays: 30 },
  eps: { weightedShares: 0, dilutiveShares: 0, preferenceDividends: 0 },
  nrv: {},
  fxShockPct: 10,
  interestShockPct: 1,
  kmpCompensation: 0,
};

const num = (v: unknown, d = 0) => (Number.isFinite(Number(v)) ? Number(v) : d);
const arr = <T,>(v: unknown, fill: (row: Record<string, unknown>) => T): T[] => (Array.isArray(v) ? v.filter((x) => x && typeof x === 'object').map((x) => fill(x as Record<string, unknown>)) : []);
const str = (v: unknown, d = '') => (typeof v === 'string' ? v : v == null ? d : String(v));

/** Defensive merge of a stored payload with defaults (old/partial payloads never crash the desk). */
export function normaliseInputs(raw: unknown): IfrsInputs {
  const o = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const ecl = (o.ecl ?? {}) as Record<string, unknown>;
  const eps = (o.eps ?? {}) as Record<string, unknown>;
  const rates = Array.isArray(ecl.rates) ? ecl.rates.map((r) => Math.min(100, Math.max(0, num(r)))) : DEFAULT_IFRS_INPUTS.ecl.rates;
  return {
    leases: arr(o.leases, (r) => ({ id: str(r.id, uid()), name: str(r.name), lessor: str(r.lessor), commencement: str(r.commencement), termMonths: Math.max(1, Math.round(num(r.termMonths, 12))), payment: Math.max(0, num(r.payment)), frequency: (['monthly', 'quarterly', 'annual'].includes(str(r.frequency)) ? r.frequency : 'monthly') as LeaseInput['frequency'], timing: (r.timing === 'advance' ? 'advance' : 'arrears') as LeaseInput['timing'], ratePct: Math.max(0, num(r.ratePct)), initialDirectCosts: Math.max(0, num(r.initialDirectCosts)) })),
    provisions: arr(o.provisions, (r) => ({ id: str(r.id, uid()), name: str(r.name), category: str(r.category), opening: num(r.opening), additions: num(r.additions), utilised: num(r.utilised), reversed: num(r.reversed), unwinding: num(r.unwinding), expectedTiming: str(r.expectedTiming) })),
    contingencies: arr(o.contingencies, (r) => ({ id: str(r.id, uid()), nature: str(r.nature), estimate: num(r.estimate), likelihood: (['remote', 'possible', 'probable'].includes(str(r.likelihood)) ? r.likelihood : 'possible') as ContingencyInput['likelihood'], status: str(r.status) })),
    relatedParties: arr(o.relatedParties, (r) => ({ id: str(r.id, uid()), party: str(r.party), relationship: str(r.relationship), nature: str(r.nature), transactions: num(r.transactions), balance: num(r.balance) })),
    events: arr(o.events, (r) => ({ id: str(r.id, uid()), date: str(r.date), description: str(r.description), type: (r.type === 'adjusting' ? 'adjusting' : 'non-adjusting') as EventInput['type'], effect: num(r.effect), treatment: str(r.treatment) })),
    impairments: arr(o.impairments, (r) => ({ id: str(r.id, uid()), cgu: str(r.cgu), carryingAmount: num(r.carryingAmount), cashFlows: str(r.cashFlows), growthPct: num(r.growthPct), discountPct: num(r.discountPct, 15), fvlcd: num(r.fvlcd) })),
    taxAdjustments: arr(o.taxAdjustments, (r) => ({ id: str(r.id, uid()), label: str(r.label), amount: num(r.amount), kind: (['permanent_addback', 'permanent_deduction', 'temporary_taxable', 'temporary_deductible'].includes(str(r.kind)) ? r.kind : 'permanent_addback') as TaxAdjustmentInput['kind'] })),
    ecl: { rates: [0, 1, 2, 3, 4].map((i) => rates[i] ?? DEFAULT_IFRS_INPUTS.ecl.rates[i]), creditTermsDays: Math.max(0, Math.round(num(ecl.creditTermsDays, 30))) },
    eps: { weightedShares: Math.max(0, num(eps.weightedShares)), dilutiveShares: Math.max(0, num(eps.dilutiveShares)), preferenceDividends: Math.max(0, num(eps.preferenceDividends)) },
    nrv: o.nrv && typeof o.nrv === 'object' ? Object.fromEntries(Object.entries(o.nrv as Record<string, unknown>).map(([k, v]) => [k, Math.max(0, num(v))])) : {},
    fxShockPct: Math.max(0, num(o.fxShockPct, 10)),
    interestShockPct: Math.max(0, num(o.interestShockPct, 1)),
    kmpCompensation: Math.max(0, num(o.kmpCompensation)),
  };
}

/* ------------------------------------------------------------------ */
/* Schedule model                                                      */
/* ------------------------------------------------------------------ */

export type Cell = string | number;
export interface ScheduleTable { title: string; columns: string[]; rows: Cell[][]; totals?: Cell[] }
export interface Reconciliation { label: string; schedule: number; ledger: number; difference: number; ok: boolean; note?: string }
export interface EntryLine { accountNo: string; accountName: string; debit: number; credit: number }
export interface ProposedEntry { key: string; title: string; date: string; lines: EntryLine[]; blockedReason?: string; posted?: boolean }
export type ScheduleStatus = 'reconciled' | 'difference' | 'no-data' | 'input-required' | 'info';
export type InputSection = 'leases' | 'provisions' | 'contingencies' | 'relatedParties' | 'events' | 'impairments' | 'taxAdjustments' | 'ecl' | 'eps' | 'nrv' | 'risk';
export interface IfrsSchedule {
  id: string;
  standard: string;
  title: string;
  noteRef?: number;
  noteTitle?: string;
  summary: string;
  status: ScheduleStatus;
  kpis: { label: string; value: number | string; tone?: 'good' | 'bad' }[];
  tables: ScheduleTable[];
  reconciliations: Reconciliation[];
  entries: ProposedEntry[];
  insights: string[];
  inputs: InputSection[];
}

export interface ScheduleContext {
  lines: readonly ACDOCALine[];
  accounts: AccountMaster[];
  clientId: number;
  currency: string;
  from: string;
  through: string;
  assets: FixedAsset[];
  stockItems: StockItem[];
  stockMovements: StockMovement[];
  invoices: SalesInvoice[];
  orders: PurchaseOrder[];
  payroll: MonthlyPayrollRecord[];
  citRatePct: number;
  inputs: IfrsInputs;
  noteFor: (standard: string) => { number: number; title: string } | undefined;
}

const TOLERANCE = 1; // one currency unit

function recon(label: string, schedule: number, ledger: number, note?: string): Reconciliation {
  const difference = r2(schedule - ledger);
  return { label, schedule: r2(schedule), ledger: r2(ledger), difference, ok: Math.abs(difference) <= TOLERANCE, note };
}

function statusOf(recs: Reconciliation[], hasData: boolean): ScheduleStatus {
  if (!hasData) return 'no-data';
  if (!recs.length) return 'info';
  return recs.every((r) => r.ok) ? 'reconciled' : 'difference';
}

/** Ledger helper bound to one entity. All amounts in major units, debit-normal unless stated. */
function ledgerOf(ctx: ScheduleContext) {
  const byCode = new Map(ctx.accounts.map((a) => [a.accountNo, a]));
  const lines = ctx.lines.filter((l) => l.clientId === ctx.clientId);
  const grp = (code: string): Group => groupOf(byCode.get(code), code);
  const nameOf = (code: string) => byCode.get(code)?.name ?? lines.find((l) => l.accountNo === code)?.accountName ?? code;
  const sum = (pred: (l: ACDOCALine) => boolean, f: (l: ACDOCALine) => number) => r2(lines.filter(pred).reduce((n, l) => n + f(l), 0) / 100);
  const balanceAt = (codePred: (code: string) => boolean, asAt: string) => sum((l) => l.date <= asAt && codePred(l.accountNo), (l) => minor(l.debit) - minor(l.credit));
  const debits = (codePred: (code: string) => boolean, from: string, through: string) => sum((l) => l.date >= from && l.date <= through && codePred(l.accountNo), (l) => minor(l.debit));
  const credits = (codePred: (code: string) => boolean, from: string, through: string) => sum((l) => l.date >= from && l.date <= through && codePred(l.accountNo), (l) => minor(l.credit));
  const find = (pred: (a: AccountMaster) => boolean) => ctx.accounts.find((a) => a.active !== false && pred(a));
  const hasRef = (key: string) => lines.some((l) => l.reference === key || l.description.includes(`[${key}]`));
  return { lines, grp, nameOf, balanceAt, debits, credits, find, hasRef, byCode };
}
type Ledger = ReturnType<typeof ledgerOf>;

const isAccum = (name: string) => /accumulated|amortis|amortiz|impairment|allowance|provision for/i.test(name);

function entry(L: Ledger, key: string, title: string, date: string, raw: { account?: AccountMaster; debit?: number; credit?: number; missing: string }[]): ProposedEntry {
  const missing = raw.filter((r) => !r.account).map((r) => r.missing);
  const lines: EntryLine[] = raw
    .filter((r) => r.account && (r2(r.debit ?? 0) > 0 || r2(r.credit ?? 0) > 0))
    .map((r) => ({ accountNo: r.account!.accountNo, accountName: r.account!.name, debit: r2(r.debit ?? 0), credit: r2(r.credit ?? 0) }));
  const dr = r2(lines.reduce((s, l) => s + l.debit, 0));
  const cr = r2(lines.reduce((s, l) => s + l.credit, 0));
  let blockedReason: string | undefined;
  if (missing.length) blockedReason = `Add or activate a chart-of-accounts line for: ${missing.join(', ')}.`;
  else if (!lines.length || dr === 0) blockedReason = 'Nothing to post — schedule agrees with the ledger.';
  else if (dr !== cr) blockedReason = 'Proposed entry does not balance.';
  return { key, title, date, lines, blockedReason, posted: L.hasRef(key) };
}

function withNote(ctx: ScheduleContext, standard: string, s: Omit<IfrsSchedule, 'noteRef' | 'noteTitle'>): IfrsSchedule {
  const note = ctx.noteFor(standard);
  return { ...s, noteRef: note?.number, noteTitle: note?.title };
}

/* ------------------------------------------------------------------ */
/* IAS 16 — Property, plant and equipment                              */
/* ------------------------------------------------------------------ */

function rateOf(a: FixedAsset): number {
  if (Number.isFinite(a.depreciationRate) && (a.depreciationRate ?? 0) >= 0) return (a.depreciationRate ?? 0) / 100;
  const life = parseFloat(String(a.usefulLife).replace(/[^0-9.]/g, ''));
  return life > 0 ? 1 / life : 0;
}

function depreciationTo(a: FixedAsset, asAt: string): number {
  if (!a.acquired || a.acquired > asAt) return 0;
  const end = a.disposedDate && a.disposedDate < asAt ? a.disposedDate : asAt;
  const years = yearsBetween(a.acquired, end);
  const rate = rateOf(a);
  if (rate <= 0) return 0;
  const raw = a.depreciationMethod === 'reducing_balance' ? a.cost * (1 - Math.pow(1 - Math.min(rate, 1), years)) : a.cost * rate * years;
  return r2(Math.min(a.cost, Math.max(0, raw)));
}

interface PpeRow { cls: string; costOpen: number; additions: number; disposals: number; costClose: number; depOpen: number; charge: number; depDisposals: number; depClose: number; nbvOpen: number; nbvClose: number }

export function ppeRollForward(assets: FixedAsset[], from: string, through: string) {
  const open = dayBefore(from);
  const byClass = new Map<string, PpeRow>();
  const notes: string[] = [];
  for (const a of assets) {
    if (a.acquired && a.acquired > through) continue;
    if (a.disposedDate && a.disposedDate < from) continue;
    const cls = a.classCode || 'Unclassified';
    const row = byClass.get(cls) ?? { cls, costOpen: 0, additions: 0, disposals: 0, costClose: 0, depOpen: 0, charge: 0, depDisposals: 0, depClose: 0, nbvOpen: 0, nbvClose: 0 };
    const heldAtOpen = !a.acquired || a.acquired <= open;
    const disposedInPeriod = Boolean(a.disposedDate && a.disposedDate >= from && a.disposedDate <= through);
    const costOpen = heldAtOpen ? a.cost : 0;
    const addition = heldAtOpen ? 0 : a.cost;
    const disposal = disposedInPeriod ? a.cost : 0;
    let depOpen: number;
    let depEnd: number;
    if (a.acquired) {
      depOpen = heldAtOpen ? depreciationTo(a, open) : 0;
      depEnd = depreciationTo(a, disposedInPeriod ? (a.disposedDate as string) : through);
    } else {
      // No acquisition date: use the register's accumulated depreciation as the
      // closing balance and the expected period charge to derive the opening.
      const fraction = yearsBetween(dayBefore(from), through);
      const expected = r2(Math.min(a.accumDep, (a.depreciationMethod === 'reducing_balance' ? Math.max(0, a.cost - a.accumDep) : a.cost) * rateOf(a) * fraction));
      depEnd = r2(a.accumDep);
      depOpen = r2(Math.max(0, depEnd - expected));
      notes.push(`${a.assetTag} ${a.name}: acquisition date missing — register accumulated depreciation used.`);
    }
    const charge = r2(Math.max(0, depEnd - depOpen));
    const depDisposal = disposedInPeriod ? depEnd : 0;
    row.costOpen += costOpen;
    row.additions += addition;
    row.disposals += disposal;
    row.depOpen += depOpen;
    row.charge += charge;
    row.depDisposals += depDisposal;
    byClass.set(cls, row);
  }
  const rows = [...byClass.values()].map((r) => {
    const costClose = r2(r.costOpen + r.additions - r.disposals);
    const depClose = r2(r.depOpen + r.charge - r.depDisposals);
    return { ...r, costOpen: r2(r.costOpen), additions: r2(r.additions), disposals: r2(r.disposals), depOpen: r2(r.depOpen), charge: r2(r.charge), depDisposals: r2(r.depDisposals), costClose, depClose, nbvOpen: r2(r.costOpen - r.depOpen), nbvClose: r2(costClose - depClose) };
  });
  const total = rows.reduce(
    (t, r) => ({ cls: 'Total', costOpen: t.costOpen + r.costOpen, additions: t.additions + r.additions, disposals: t.disposals + r.disposals, costClose: t.costClose + r.costClose, depOpen: t.depOpen + r.depOpen, charge: t.charge + r.charge, depDisposals: t.depDisposals + r.depDisposals, depClose: t.depClose + r.depClose, nbvOpen: t.nbvOpen + r.nbvOpen, nbvClose: t.nbvClose + r.nbvClose }),
    { cls: 'Total', costOpen: 0, additions: 0, disposals: 0, costClose: 0, depOpen: 0, charge: 0, depDisposals: 0, depClose: 0, nbvOpen: 0, nbvClose: 0 } as PpeRow,
  );
  return { rows, total, notes };
}

function ias16(ctx: ScheduleContext, L: Ledger): IfrsSchedule {
  const { rows, total, notes } = ppeRollForward(ctx.assets, ctx.from, ctx.through);
  const costPred = (c: string) => L.grp(c) === 'ppe' && !isAccum(L.nameOf(c));
  const accPred = (c: string) => L.grp(c) === 'ppe' && isAccum(L.nameOf(c));
  const glCost = L.balanceAt(costPred, ctx.through);
  const glAcc = -L.balanceAt(accPred, ctx.through);
  const recs = [
    recon('Cost — register vs GL', total.costClose, glCost),
    recon('Accumulated depreciation — register vs GL', total.depClose, glAcc),
    recon('Carrying amount — register vs GL', total.nbvClose, r2(glCost - glAcc)),
  ];
  const depShortfall = r2(total.depClose - glAcc);
  const entries: ProposedEntry[] = [];
  if (Math.abs(depShortfall) > TOLERANCE && ctx.assets.length) {
    const exp = L.find((a) => a.type === 'Expense' && /depreciation/i.test(a.name));
    const acc = L.find((a) => a.type === 'Asset' && L.grp(a.accountNo) === 'ppe' && /accumulated depreciation/i.test(a.name));
    entries.push(entry(L, `IAS16-DEP-${ctx.through}`, depShortfall > 0 ? 'Depreciation true-up to the asset register (IAS 16.48)' : 'Reverse excess depreciation versus the asset register', ctx.through, depShortfall > 0
      ? [{ account: exp, debit: depShortfall, missing: 'Depreciation expense' }, { account: acc, credit: depShortfall, missing: 'Accumulated depreciation (PPE)' }]
      : [{ account: acc, debit: -depShortfall, missing: 'Accumulated depreciation (PPE)' }, { account: exp, credit: -depShortfall, missing: 'Depreciation expense' }]));
  }
  return withNote(ctx, 'IAS 16', {
    id: 'ias16', standard: 'IAS 16', title: 'Property, plant and equipment',
    summary: 'Roll-forward of gross carrying amount and accumulated depreciation by asset class (IAS 16.73(d)–(e)), computed from the fixed asset register and reconciled to the general ledger.',
    status: statusOf(recs, ctx.assets.length > 0 || glCost !== 0),
    kpis: [{ label: 'Closing carrying amount', value: total.nbvClose }, { label: 'Depreciation charge', value: total.charge }, { label: 'Additions', value: total.additions }, { label: 'Assets on register', value: ctx.assets.length }],
    tables: [
      { title: 'Cost', columns: ['Asset class', 'Opening', 'Additions', 'Disposals', 'Closing'], rows: rows.map((r) => [r.cls, r.costOpen, r.additions, -r.disposals, r.costClose]), totals: ['Total', r2(total.costOpen), r2(total.additions), -r2(total.disposals), r2(total.costClose)] },
      { title: 'Accumulated depreciation', columns: ['Asset class', 'Opening', 'Charge for period', 'Eliminated on disposal', 'Closing'], rows: rows.map((r) => [r.cls, r.depOpen, r.charge, -r.depDisposals, r.depClose]), totals: ['Total', r2(total.depOpen), r2(total.charge), -r2(total.depDisposals), r2(total.depClose)] },
      { title: 'Carrying amount', columns: ['Asset class', 'Opening', 'Closing'], rows: rows.map((r) => [r.cls, r.nbvOpen, r.nbvClose]), totals: ['Total', r2(total.nbvOpen), r2(total.nbvClose)] },
    ],
    reconciliations: recs,
    entries,
    insights: [...notes.slice(0, 6), ...(rows.length ? [] : ['No assets on the register for this entity. Capture assets in the Fixed Assets Register to populate this schedule.'])],
    inputs: [],
  });
}

/* ------------------------------------------------------------------ */
/* IAS 38 — Intangible assets (ledger roll-forward)                    */
/* ------------------------------------------------------------------ */

function ias38(ctx: ScheduleContext, L: Ledger): IfrsSchedule {
  const open = dayBefore(ctx.from);
  const cost = (c: string) => L.grp(c) === 'intangibles' && !isAccum(L.nameOf(c));
  const amort = (c: string) => L.grp(c) === 'intangibles' && isAccum(L.nameOf(c));
  const cOpen = L.balanceAt(cost, open);
  const cAdd = L.debits(cost, ctx.from, ctx.through);
  const cDisp = L.credits(cost, ctx.from, ctx.through);
  const cClose = L.balanceAt(cost, ctx.through);
  const aOpen = -L.balanceAt(amort, open);
  const aCharge = L.credits(amort, ctx.from, ctx.through);
  const aDisp = L.debits(amort, ctx.from, ctx.through);
  const aClose = -L.balanceAt(amort, ctx.through);
  const recs = [recon('Cost roll-forward foots to closing GL', r2(cOpen + cAdd - cDisp), cClose), recon('Amortisation roll-forward foots to closing GL', r2(aOpen + aCharge - aDisp), aClose)];
  const hasData = [cOpen, cAdd, cClose, aClose].some((v) => v !== 0);
  return withNote(ctx, 'IAS 38', {
    id: 'ias38', standard: 'IAS 38', title: 'Intangible assets',
    summary: 'Reconciliation of the carrying amount of intangible assets at the beginning and end of the period (IAS 38.118(e)), derived from the intangible asset and amortisation ledgers.',
    status: statusOf(recs, hasData),
    kpis: [{ label: 'Closing carrying amount', value: r2(cClose - aClose) }, { label: 'Amortisation charge', value: aCharge }, { label: 'Additions', value: cAdd }],
    tables: [{ title: 'Intangible assets roll-forward', columns: ['Movement', 'Cost', 'Accumulated amortisation', 'Carrying amount'], rows: [['Opening balance', cOpen, aOpen, r2(cOpen - aOpen)], ['Additions', cAdd, 0, cAdd], ['Disposals / derecognition', -cDisp, -aDisp, r2(-cDisp + aDisp)], ['Amortisation charge', 0, aCharge, -aCharge]], totals: ['Closing balance', cClose, aClose, r2(cClose - aClose)] }],
    reconciliations: recs, entries: [],
    insights: hasData ? [] : ['No intangible asset balances in the ledger. If software, licences or goodwill exist, capitalise them to an intangible account.'],
    inputs: [],
  });
}

/* ------------------------------------------------------------------ */
/* IFRS 16 — Leases                                                    */
/* ------------------------------------------------------------------ */

export interface LeaseRow { n: number; date: string; opening: number; interest: number; payment: number; closing: number }
export interface LeaseCalc { lease: LeaseInput; rows: LeaseRow[]; initialLiability: number; rouCost: number; paymentDates: string[]; ppy: number; i: number }

export function computeLease(lease: LeaseInput): LeaseCalc {
  const ppy = lease.frequency === 'annual' ? 1 : lease.frequency === 'quarterly' ? 4 : 12;
  const step = 12 / ppy;
  const n = Math.max(1, Math.round(lease.termMonths / step));
  const i = lease.ratePct / 100 / ppy;
  const annuity = (k: number) => (k <= 0 ? 0 : i === 0 ? k : (1 - Math.pow(1 + i, -k)) / i);
  const advance = lease.timing === 'advance';
  const initialLiability = r2(lease.payment * annuity(advance ? n - 1 : n));
  const rouCost = r2(initialLiability + (advance ? lease.payment : 0) + lease.initialDirectCosts);
  const rows: LeaseRow[] = [];
  let bal = initialLiability;
  const count = advance ? n - 1 : n;
  for (let k = 1; k <= count; k++) {
    const interest = r2(bal * i);
    const payment = k === count ? r2(bal + interest) : lease.payment;
    const closing = r2(bal + interest - payment);
    rows.push({ n: k, date: addMonths(lease.commencement, k * step), opening: bal, interest, payment, closing: Math.abs(closing) < 0.01 ? 0 : closing });
    bal = rows[rows.length - 1].closing;
  }
  const paymentDates = Array.from({ length: n }, (_, k) => addMonths(lease.commencement, (advance ? k : k + 1) * step));
  return { lease, rows, initialLiability, rouCost, paymentDates, ppy, i };
}

/** Carrying amount of the lease liability at a date, including interest accrued since the last payment. */
export function leaseLiabilityAt(calc: LeaseCalc, asAt: string): number {
  if (!calc.lease.commencement || asAt < calc.lease.commencement) return 0;
  let bal = calc.initialLiability;
  let last = calc.lease.commencement;
  for (const row of calc.rows) {
    if (row.date > asAt) break;
    bal = row.closing;
    last = row.date;
  }
  if (bal <= 0) return 0;
  const periodDays = 365.25 / calc.ppy;
  const days = (toTime(asAt) - toTime(last)) / DAY;
  return r2(bal * Math.pow(1 + calc.i, days / periodDays));
}

function rouDepAt(calc: LeaseCalc, asAt: string): number {
  if (!calc.lease.commencement || asAt < calc.lease.commencement) return 0;
  const months = yearsBetween(calc.lease.commencement, asAt) * 12;
  return r2(Math.min(calc.rouCost, (calc.rouCost / calc.lease.termMonths) * months));
}

function ifrs16(ctx: ScheduleContext, L: Ledger): IfrsSchedule {
  const open = dayBefore(ctx.from);
  const valid = ctx.inputs.leases.filter((l) => l.commencement && l.payment > 0 && l.termMonths > 0);
  const calcs = valid.map(computeLease);
  const in12 = addMonths(ctx.through, 12);
  const in60 = addMonths(ctx.through, 60);
  const perLease = calcs.map((c) => {
    const liabClose = leaseLiabilityAt(c, ctx.through);
    const liabOpen = leaseLiabilityAt(c, open);
    const additions = c.lease.commencement >= ctx.from && c.lease.commencement <= ctx.through ? c.initialLiability : 0;
    const paid = r2(c.rows.filter((r) => r.date >= ctx.from && r.date <= ctx.through).reduce((s, r) => s + r.payment, 0));
    const interest = r2(Math.max(0, liabClose - liabOpen - additions + paid));
    const nonCurrent = leaseLiabilityAt(c, in12);
    const rouNbv = r2(ctx.through >= c.lease.commencement ? c.rouCost - rouDepAt(c, ctx.through) : 0);
    const dep = r2(rouDepAt(c, ctx.through) - rouDepAt(c, open));
    const future = c.paymentDates.filter((d) => d > ctx.through).map((d) => ({ d, amt: c.lease.payment }));
    const lt1 = r2(future.filter((f) => f.d <= in12).reduce((s, f) => s + f.amt, 0));
    const y15 = r2(future.filter((f) => f.d > in12 && f.d <= in60).reduce((s, f) => s + f.amt, 0));
    const gt5 = r2(future.filter((f) => f.d > in60).reduce((s, f) => s + f.amt, 0));
    return { c, liabOpen, liabClose, additions, paid, interest, current: r2(liabClose - nonCurrent), nonCurrent, rouNbv, dep, lt1, y15, gt5 };
  });
  const T = perLease.reduce((t, p) => ({ liabOpen: t.liabOpen + p.liabOpen, liabClose: t.liabClose + p.liabClose, additions: t.additions + p.additions, paid: t.paid + p.paid, interest: t.interest + p.interest, current: t.current + p.current, nonCurrent: t.nonCurrent + p.nonCurrent, rouNbv: t.rouNbv + p.rouNbv, dep: t.dep + p.dep, lt1: t.lt1 + p.lt1, y15: t.y15 + p.y15, gt5: t.gt5 + p.gt5 }), { liabOpen: 0, liabClose: 0, additions: 0, paid: 0, interest: 0, current: 0, nonCurrent: 0, rouNbv: 0, dep: 0, lt1: 0, y15: 0, gt5: 0 });
  const glLiab = -L.balanceAt((c) => L.grp(c) === 'leaseLiability', ctx.through);
  const glRou = L.balanceAt((c) => L.grp(c) === 'rou', ctx.through);
  const recs = calcs.length ? [recon('Lease liabilities — schedule vs GL', T.liabClose, glLiab), recon('Right-of-use assets — schedule vs GL', T.rouNbv, glRou)] : [];
  const rouAcc = L.find((a) => a.type === 'Asset' && /right-of-use|rou/i.test(`${a.name} ${a.category}`) && !isAccum(a.name));
  const rouAccum = L.find((a) => a.type === 'Asset' && /right-of-use|rou/i.test(`${a.name} ${a.category}`) && isAccum(a.name)) ?? rouAcc;
  const liabAcc = L.find((a) => a.type === 'Liability' && /lease liab/i.test(`${a.name} ${a.category}`));
  const finAcc = L.find((a) => a.type === 'Expense' && /interest/i.test(a.name)) ?? L.find((a) => a.type === 'Expense' && L.grp(a.accountNo) === 'financeCosts');
  const depAcc = L.find((a) => a.type === 'Expense' && /depreciation/i.test(a.name));
  const prepaidAcc = L.find((a) => a.type === 'Asset' && /prepaid|prepayment/i.test(a.name))
    ?? L.find((a) => a.type === 'Asset' && /bank|cash|treasury/i.test(a.name));
  const entries: ProposedEntry[] = [];
  for (const p of perLease) {
    if (p.c.lease.commencement <= ctx.through) {
      // ROU cost is the lease liability PLUS the first (advance) payment and any
      // initial direct costs (IFRS 16.23–24). Booking only the liability understates
      // the asset and leaves the schedule permanently out with the GL.
      const prepaid = r2(p.c.rouCost - p.c.initialLiability);
      entries.push(entry(L, `IFRS16-INIT-${p.c.lease.id}`, `Initial recognition — ${p.c.lease.name || 'lease'} (IFRS 16.23–26)`, p.c.lease.commencement < ctx.from ? ctx.from : p.c.lease.commencement, [
        { account: rouAcc, debit: p.c.rouCost, missing: 'Right-of-use asset' },
        { account: liabAcc, credit: p.c.initialLiability, missing: 'Lease liabilities' },
        ...(prepaid > TOLERANCE ? [{ account: prepaidAcc, credit: prepaid, missing: 'Prepayments / cash paid in advance' }] : []),
      ]));
      entries.push(entry(L, `IFRS16-PER-${p.c.lease.id}-${ctx.through}`, `Interest and ROU depreciation for the period — ${p.c.lease.name || 'lease'}`, ctx.through, [{ account: finAcc, debit: p.interest, missing: 'Interest / finance cost' }, { account: liabAcc, credit: p.interest, missing: 'Lease liabilities' }, { account: depAcc, debit: p.dep, missing: 'Depreciation expense' }, { account: rouAccum, credit: p.dep, missing: 'Accumulated depreciation — ROU' }]));
    }
  }
  return withNote(ctx, 'IFRS 16', {
    id: 'ifrs16', standard: 'IFRS 16', title: 'Leases — right-of-use assets and lease liabilities',
    summary: 'Lessee accounting: present value of lease payments at the incremental borrowing rate, effective-interest amortisation, straight-line ROU depreciation, current/non-current split and undiscounted maturity analysis (IFRS 16.47–53, 58).',
    status: calcs.length ? statusOf(recs, true) : 'input-required',
    kpis: [{ label: 'Lease liabilities', value: r2(T.liabClose) }, { label: 'ROU assets (NBV)', value: r2(T.rouNbv) }, { label: 'Interest expense', value: r2(T.interest) }, { label: 'ROU depreciation', value: r2(T.dep) }],
    tables: [
      { title: 'Lease liabilities roll-forward', columns: ['Lease', 'Opening', 'New leases', 'Interest', 'Payments', 'Closing', 'Current', 'Non-current'], rows: perLease.map((p) => [p.c.lease.name || p.c.lease.id, p.liabOpen, p.additions, p.interest, -p.paid, p.liabClose, p.current, p.nonCurrent]), totals: ['Total', r2(T.liabOpen), r2(T.additions), r2(T.interest), -r2(T.paid), r2(T.liabClose), r2(T.current), r2(T.nonCurrent)] },
      { title: 'Right-of-use assets', columns: ['Lease', 'Cost at commencement', 'Depreciation for period', 'Carrying amount'], rows: perLease.map((p) => [p.c.lease.name || p.c.lease.id, p.c.rouCost, p.dep, p.rouNbv]), totals: ['Total', r2(perLease.reduce((s, p) => s + p.c.rouCost, 0)), r2(T.dep), r2(T.rouNbv)] },
      { title: 'Maturity analysis — undiscounted lease payments (IFRS 16.58)', columns: ['Lease', 'Within 1 year', '1–5 years', 'Over 5 years', 'Total undiscounted'], rows: perLease.map((p) => [p.c.lease.name || p.c.lease.id, p.lt1, p.y15, p.gt5, r2(p.lt1 + p.y15 + p.gt5)]), totals: ['Total', r2(T.lt1), r2(T.y15), r2(T.gt5), r2(T.lt1 + T.y15 + T.gt5)] },
    ],
    reconciliations: recs,
    entries,
    insights: calcs.length ? ['Lease payments themselves are recorded through the Payment Desk (Dr Lease liabilities / Cr Bank). Advance payments and initial direct costs are capitalised to the ROU asset when paid.'] : ['Register each lease (commencement, term, payment, frequency, incremental borrowing rate) to generate the IFRS 16 schedule. Short-term (≤12 months) and low-value leases may be expensed (IFRS 16.5).'],
    inputs: ['leases'],
  });
}

/* ------------------------------------------------------------------ */
/* IAS 2 — Inventories                                                 */
/* ------------------------------------------------------------------ */

function ias2(ctx: ScheduleContext, L: Ledger): IfrsSchedule {
  const items = ctx.stockItems.filter((s) => s.clientId === ctx.clientId);
  const rows = items.map((s) => {
    const cost = r2(s.totalValue || s.quantityOnHand * s.unitCost);
    const nrvUnit = ctx.inputs.nrv[s.itemCode] ?? s.netRealisableValue ?? s.unitCost;
    const nrv = r2(nrvUnit * s.quantityOnHand);
    const carrying = r2(Math.min(cost, nrv));
    return { s, cost, nrvUnit, nrv, carrying, writeDown: r2(cost - carrying) };
  });
  const tot = rows.reduce((t, r) => ({ cost: t.cost + r.cost, nrv: t.nrv + r.nrv, carrying: t.carrying + r.carrying, writeDown: t.writeDown + r.writeDown }), { cost: 0, nrv: 0, carrying: 0, writeDown: 0 });
  const glInv = L.balanceAt((c) => L.grp(c) === 'inventories', ctx.through);
  const recs = items.length ? [recon('Inventory at cost — register vs GL', tot.cost, glInv, 'Register quantities are perpetual (current) balances.')] : [];
  const mv = ctx.stockMovements.filter((m) => m.clientId === ctx.clientId && m.date >= ctx.from && m.date <= ctx.through);
  const byType = new Map<string, { count: number; qty: number; value: number }>();
  for (const m of mv) {
    const t = byType.get(m.type) ?? { count: 0, qty: 0, value: 0 };
    t.count += 1;
    t.qty += m.quantity;
    t.value += m.totalValue;
    byType.set(m.type, t);
  }
  const wdExp = L.find((a) => a.type === 'Expense' && /write.?down|obsolesc|inventory loss|stock loss/i.test(a.name)) ?? L.find((a) => a.type === 'Expense' && L.grp(a.accountNo) === 'costOfSales');
  const invAcc = L.find((a) => a.type === 'Asset' && L.grp(a.accountNo) === 'inventories');
  const writeDown = r2(tot.writeDown);
  const entries = writeDown > 0 ? [entry(L, `IAS2-NRV-${ctx.through}`, 'Write inventories down to net realisable value (IAS 2.9, 2.34)', ctx.through, [{ account: wdExp, debit: writeDown, missing: 'Inventory write-down / cost of sales' }, { account: invAcc, credit: writeDown, missing: 'Inventories' }])] : [];
  return withNote(ctx, 'IAS 2', {
    id: 'ias2', standard: 'IAS 2', title: 'Inventories — lower of cost and NRV',
    summary: 'Item-level comparison of cost and net realisable value, write-downs recognised as an expense, period movements and reconciliation of the stock register to the inventory control account (IAS 2.36).',
    status: statusOf(recs, items.length > 0 || glInv !== 0),
    kpis: [{ label: 'Inventory at cost', value: r2(tot.cost) }, { label: 'Carrying amount (lower of cost/NRV)', value: r2(tot.carrying) }, { label: 'Write-down required', value: writeDown, tone: writeDown > 0 ? 'bad' : 'good' }, { label: 'Items', value: items.length }],
    tables: [
      { title: 'Cost vs net realisable value by item', columns: ['Item', 'Description', 'Qty', 'Unit cost', 'Cost', 'NRV / unit', 'NRV', 'Carrying amount', 'Write-down'], rows: rows.map((r) => [r.s.itemCode, r.s.description, r.s.quantityOnHand, r.s.unitCost, r.cost, r.nrvUnit, r.nrv, r.carrying, r.writeDown]), totals: ['Total', '', '', '', r2(tot.cost), '', r2(tot.nrv), r2(tot.carrying), writeDown] },
      { title: 'Stock movements in the period', columns: ['Movement type', 'Transactions', 'Quantity', 'Value'], rows: [...byType.entries()].map(([k, v]) => [k, v.count, r2(v.qty), r2(v.value)]) },
    ],
    reconciliations: recs, entries,
    insights: items.length ? ['Set the NRV per unit for slow-moving or damaged lines in the inputs below; the write-down is proposed automatically.'] : ['No stock items on the register for this entity.'],
    inputs: ['nrv'],
  });
}

/* ------------------------------------------------------------------ */
/* IFRS 9 — Expected credit losses (simplified approach)               */
/* ------------------------------------------------------------------ */

export function receivablesAgeing(invoices: SalesInvoice[], clientId: number, through: string, termsDays: number) {
  const open = invoices.filter((i) => (i.clientId ?? clientId) === clientId && (i.status === 'Open' || i.status === 'Partial') && i.date <= through);
  const buckets = [0, 0, 0, 0, 0];
  const byCustomer = new Map<string, number>();
  for (const inv of open) {
    const outstanding = r2(inv.totalReceivable - (inv.paidAmount || 0));
    if (outstanding <= 0) continue;
    const due = toTime(inv.date) + termsDays * DAY;
    const dpd = Math.floor((toTime(through) - due) / DAY);
    const idx = dpd <= 0 ? 0 : dpd <= 30 ? 1 : dpd <= 60 ? 2 : dpd <= 90 ? 3 : 4;
    buckets[idx] += outstanding;
    byCustomer.set(inv.customerName, (byCustomer.get(inv.customerName) ?? 0) + outstanding);
  }
  return { buckets: buckets.map(r2), byCustomer, total: r2(buckets.reduce((s, b) => s + b, 0)) };
}

function ifrs9(ctx: ScheduleContext, L: Ledger): IfrsSchedule {
  const { buckets, byCustomer, total } = receivablesAgeing(ctx.invoices, ctx.clientId, ctx.through, ctx.inputs.ecl.creditTermsDays);
  const rates = ctx.inputs.ecl.rates;
  const ecl = buckets.map((b, i) => r2((b * (rates[i] ?? 0)) / 100));
  const required = r2(ecl.reduce((s, v) => s + v, 0));
  const allowancePred = (c: string) => L.byCode.get(c)?.type === 'Asset' && /allowance|doubtful|expected credit|impairment of (trade )?receiv/i.test(L.nameOf(c));
  const booked = -L.balanceAt(allowancePred, ctx.through);
  const glRec = L.balanceAt((c) => L.grp(c) === 'receivables' && !allowancePred(c) && /trade|customer|debtor|receivable/i.test(L.nameOf(c)), ctx.through);
  const recs = [recon('ECL allowance — required vs booked', required, booked), recon('Open invoices vs trade receivables control', total, glRec, 'Differences usually reflect receipts or invoices not yet matched in the register.')];
  const delta = r2(required - booked);
  const exp = L.find((a) => a.type === 'Expense' && /impairment|bad debt|doubtful|expected credit/i.test(a.name));
  const allow = L.find((a) => a.type === 'Asset' && /allowance|doubtful|expected credit/i.test(a.name));
  const entries = Math.abs(delta) > TOLERANCE ? [entry(L, `IFRS9-ECL-${ctx.through}`, delta > 0 ? 'Increase loss allowance to lifetime ECL (IFRS 9.5.5.15)' : 'Release excess loss allowance', ctx.through, delta > 0 ? [{ account: exp, debit: delta, missing: 'Impairment loss on receivables (expense)' }, { account: allow, credit: delta, missing: 'Loss allowance on receivables (contra-asset)' }] : [{ account: allow, debit: -delta, missing: 'Loss allowance on receivables (contra-asset)' }, { account: exp, credit: -delta, missing: 'Impairment loss on receivables (expense)' }])] : [];
  const top = [...byCustomer.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
  return withNote(ctx, 'IFRS 9', {
    id: 'ifrs9', standard: 'IFRS 9', title: 'Trade receivables — expected credit loss matrix',
    summary: 'Simplified approach: lifetime expected credit losses from a provision matrix by days past due (IFRS 9.5.5.15, B5.5.35), compared with the allowance in the ledger; credit-risk concentration for IFRS 7.35M.',
    status: total === 0 && booked === 0 ? 'no-data' : statusOf(recs, true),
    kpis: [{ label: 'Gross receivables (open invoices)', value: total }, { label: 'Lifetime ECL required', value: required }, { label: 'Allowance booked', value: booked }, { label: 'Adjustment', value: delta, tone: Math.abs(delta) > TOLERANCE ? 'bad' : 'good' }],
    tables: [
      { title: 'Provision matrix', columns: ['Ageing bucket', 'Gross carrying amount', 'Expected loss rate %', 'Lifetime ECL'], rows: ECL_BUCKETS.map((b, i) => [b, buckets[i], rates[i] ?? 0, ecl[i]]), totals: ['Total', total, total ? r2((required / total) * 100) : 0, required] },
      { title: 'Credit-risk concentration — top customers', columns: ['Customer', 'Outstanding', '% of total'], rows: top.map(([c, v]) => [c, r2(v), total ? r2((v / total) * 100) : 0]) },
    ],
    reconciliations: recs, entries,
    insights: [top[0] && total && top[0][1] / total > 0.25 ? `Concentration risk: ${top[0][0]} represents ${((top[0][1] / total) * 100).toFixed(1)}% of receivables.` : '', 'Loss rates should reflect historical default experience adjusted for forward-looking information (IFRS 9.B5.5.52).'].filter(Boolean),
    inputs: ['ecl'],
  });
}

/* ------------------------------------------------------------------ */
/* IFRS 15 — Revenue                                                   */
/* ------------------------------------------------------------------ */

function monthsIn(from: string, through: string): string[] {
  const out: string[] = [];
  let d = `${from.slice(0, 7)}-01`;
  while (d.slice(0, 7) <= through.slice(0, 7) && out.length < 60) {
    out.push(d.slice(0, 7));
    d = addMonths(d, 1);
  }
  return out;
}

function ifrs15(ctx: ScheduleContext, L: Ledger): IfrsSchedule {
  const open = dayBefore(ctx.from);
  const revPred = (c: string) => L.grp(c) === 'revenue';
  const glRevenue = r2(L.credits(revPred, ctx.from, ctx.through) - L.debits(revPred, ctx.from, ctx.through));
  const inv = ctx.invoices.filter((i) => (i.clientId ?? ctx.clientId) === ctx.clientId && i.status !== 'Draft' && i.date >= ctx.from && i.date <= ctx.through);
  const byStream = new Map<string, { goods: number; services: number }>();
  for (const i of inv) {
    const s = byStream.get(i.revenueStream || 'Other') ?? { goods: 0, services: 0 };
    if (i.itemType === 'goods') s.goods += i.netRevenue;
    else s.services += i.netRevenue;
    byStream.set(i.revenueStream || 'Other', s);
  }
  const credited = r2(inv.filter((i) => i.status === 'Credited').reduce((s, i) => s + i.netRevenue, 0));
  const registerRevenue = r2(inv.reduce((s, i) => s + i.netRevenue, 0) - credited);
  const revAccounts = [...new Set(L.lines.filter((l) => revPred(l.accountNo)).map((l) => l.accountNo))];
  const months = monthsIn(ctx.from, ctx.through);
  const byMonth = months.map((m) => [m, r2(L.credits(revPred, `${m}-01`, `${m}-31`) - L.debits(revPred, `${m}-01`, `${m}-31`))] as Cell[]);
  const bal = (g: Group, asAt: string, creditNormal: boolean) => (creditNormal ? -1 : 1) * L.balanceAt((c) => L.grp(c) === g, asAt);
  const clOpen = bal('contractLiabilities', open, true);
  const clDebits = L.debits((c) => L.grp(c) === 'contractLiabilities', ctx.from, ctx.through);
  const fromOpeningCL = r2(Math.min(Math.max(0, clOpen), clDebits));
  const recs = inv.length ? [recon('Invoice register revenue vs GL revenue', registerRevenue, glRevenue, 'GL may include revenue recognised outside the invoice register (e.g. journals, POS).')] : [];
  // A contract asset is not a receivable: it is conditional on something other
  // than the passage of time (IFRS 15.105–107). Revenue earned in excess of amounts
  // billed therefore has to be presented as a contract asset, not left in trade
  // receivables. The entry below reclassifies the difference between the two —
  // it never touches revenue, so it cannot double-count recognition.
  const unbilledEarned = r2(Math.max(0, glRevenue - registerRevenue));
  const glContractAssets = r2(bal('contractAssets', ctx.through, false));
  const reclass = r2(unbilledEarned - glContractAssets);
  const contractAssetAcc = L.find((a) => a.type === 'Asset' && /contract asset|unbilled/i.test(`${a.name} ${a.category}`));
  const receivableAcc = L.find((a) => a.type === 'Asset' && /receivable/i.test(a.name) && !/withholding|allowance|ecl/i.test(a.name));
  const entries: ProposedEntry[] = [];
  if (Math.abs(reclass) > TOLERANCE && (glRevenue !== 0 || registerRevenue !== 0)) {
    entries.push(entry(L, `IFRS15-CA-${ctx.through}`, reclass > 0
      ? 'Present unbilled revenue as a contract asset (IFRS 15.105–107)'
      : 'Reclassify over-presented contract assets to trade receivables', ctx.through,
      reclass > 0
        ? [{ account: contractAssetAcc, debit: reclass, missing: 'Contract assets / unbilled revenue' }, { account: receivableAcc, credit: reclass, missing: 'Trade receivables' }]
        : [{ account: receivableAcc, debit: -reclass, missing: 'Trade receivables' }, { account: contractAssetAcc, credit: -reclass, missing: 'Contract assets / unbilled revenue' }]));
  }
  const clClose = bal('contractLiabilities', ctx.through, true);
  const recsAll = [...recs, ...(Math.abs(reclass) > TOLERANCE && glRevenue !== 0 ? [recon('Unbilled revenue earned vs contract assets in GL', unbilledEarned, glContractAssets, 'Post the reclassification so the balance sheet separates contract assets from receivables.')] : [])];
  return withNote(ctx, 'IFRS 15', {
    id: 'ifrs15', standard: 'IFRS 15', title: 'Revenue from contracts with customers',
    summary: 'Disaggregation of revenue by stream, nature and timing (IFRS 15.114), contract balances (IFRS 15.116) and revenue recognised from opening contract liabilities.',
    status: statusOf(recsAll, glRevenue !== 0 || inv.length > 0),
    kpis: [{ label: 'Revenue (GL)', value: glRevenue }, { label: 'Invoices in period', value: inv.length }, { label: 'Credited invoices', value: credited }, { label: 'Recognised from opening contract liabilities', value: fromOpeningCL }],
    tables: [
      { title: 'Disaggregation by revenue stream (invoice register)', columns: ['Stream', 'Goods — point in time', 'Services — over time', 'Total'], rows: [...byStream.entries()].map(([k, v]) => [k, r2(v.goods), r2(v.services), r2(v.goods + v.services)]), totals: ['Total', r2([...byStream.values()].reduce((s, v) => s + v.goods, 0)), r2([...byStream.values()].reduce((s, v) => s + v.services, 0)), r2(inv.reduce((s, i) => s + i.netRevenue, 0))] },
      { title: 'Revenue by account (GL)', columns: ['Account', 'Name', 'Revenue'], rows: revAccounts.map((c) => [c, L.nameOf(c), r2(L.credits((x) => x === c, ctx.from, ctx.through) - L.debits((x) => x === c, ctx.from, ctx.through))]), totals: ['Total', '', glRevenue] },
      { title: 'Timing — revenue by month', columns: ['Month', 'Revenue'], rows: byMonth },
      { title: 'Contract balances', columns: ['Balance', 'Opening', 'Closing'], rows: [['Trade receivables', bal('receivables', open, false), bal('receivables', ctx.through, false)], ['Contract assets', bal('contractAssets', open, false), glContractAssets], ['Contract liabilities', clOpen, clClose]] },
      { title: 'Contract balance roll-forward (IFRS 15.116)', columns: ['Movement', 'Contract assets', 'Contract liabilities'], rows: [
        ['Opening balance', bal('contractAssets', open, false), clOpen],
        ['Revenue recognised', r2(glRevenue), -fromOpeningCL],
        ['Amounts billed in the period', -r2(registerRevenue), r2(registerRevenue)],
        ['Closing balance', glContractAssets, clClose],
      ] },
    ],
    reconciliations: recsAll, entries,
    insights: [
      ...(Math.abs(reclass) > TOLERANCE ? [`Unbilled revenue of ₵${r2(unbilledEarned).toFixed(2)} is presented against contract assets of ₵${glContractAssets.toFixed(2)} — post the reclassification to separate contract assets from trade receivables (IFRS 15.105–107).`] : []),
      ...(clClose > TOLERANCE ? [`Contract liabilities of ₵${clClose.toFixed(2)} remain at period end: these are amounts billed or received for work not yet delivered and release to revenue as performance obligations are satisfied (IFRS 15.105).`] : []),
      ...[...byStream.entries()].sort((a, b) => (b[1].goods + b[1].services) - (a[1].goods + a[1].services)).slice(0, 2).map(([k, v]) => `Largest revenue stream: ${k} (₵${r2(v.goods + v.services).toFixed(2)}) — disaggregation disclosure (IFRS 15.114).`),
    ],
    inputs: [],
  });
}

/* ------------------------------------------------------------------ */
/* IAS 12 — Income taxes                                               */
/* ------------------------------------------------------------------ */

function ias12(ctx: ScheduleContext, L: Ledger, ppeClose: number, provisionsClose: number, eclRequired: number, leaseLiab: number, rouNbv: number): IfrsSchedule {
  const rate = ctx.citRatePct / 100;
  const pl = (g: (gr: Group, type?: string) => boolean) => r2(L.lines.filter((l) => l.date >= ctx.from && l.date <= ctx.through && g(L.grp(l.accountNo), L.byCode.get(l.accountNo)?.type)).reduce((s, l) => s + minor(l.credit) - minor(l.debit), 0) / 100);
  const pbt = pl((g, t) => (t === 'Income' || t === 'Expense') && g !== 'taxExpense');
  const taxExpenseGl = -pl((g, t) => t === 'Expense' && g === 'taxExpense');
  const depreciation = -pl((g) => g === 'depreciation');
  const yearFraction = Math.min(1, yearsBetween(dayBefore(ctx.from), ctx.through));
  const held = ctx.assets.filter((a) => (!a.acquired || a.acquired <= ctx.through) && !(a.disposedDate && a.disposedDate < ctx.from));
  const capitalAllowances = r2(held.reduce((s, a) => s + Math.min(Math.max(0, a.cost - (a.accumCapitalAllowance ?? 0)), (a.cost * (a.capitalAllowanceRate ?? 0) / 100) * yearFraction), 0));
  const adj = ctx.inputs.taxAdjustments;
  const addbacks = r2(adj.filter((a) => a.kind === 'permanent_addback').reduce((s, a) => s + a.amount, 0));
  const deductions = r2(adj.filter((a) => a.kind === 'permanent_deduction').reduce((s, a) => s + a.amount, 0));
  const taxable = r2(pbt + depreciation - capitalAllowances + addbacks - deductions);
  const currentTax = r2(Math.max(0, taxable) * rate);
  const taxBase = r2(held.filter((a) => !(a.disposedDate && a.disposedDate <= ctx.through)).reduce((s, a) => s + Math.max(0, a.cost - (a.accumCapitalAllowance ?? 0)), 0));
  const tempRows: { label: string; carrying: number; base: number; td: number }[] = [
    { label: 'Property, plant and equipment', carrying: ppeClose, base: taxBase, td: r2(ppeClose - taxBase) },
    { label: 'Provisions (deductible when paid)', carrying: -provisionsClose, base: 0, td: r2(-provisionsClose) },
    { label: 'Loss allowance on receivables', carrying: -eclRequired, base: 0, td: r2(-eclRequired) },
    { label: 'Right-of-use assets', carrying: rouNbv, base: 0, td: r2(rouNbv) },
    { label: 'Lease liabilities', carrying: -leaseLiab, base: 0, td: r2(-leaseLiab) },
    ...adj.filter((a) => a.kind.startsWith('temporary')).map((a) => ({ label: a.label || 'Other temporary difference', carrying: a.kind === 'temporary_taxable' ? a.amount : -a.amount, base: 0, td: a.kind === 'temporary_taxable' ? a.amount : -a.amount })),
  ].filter((r) => r.carrying !== 0 || r.base !== 0);
  const netTd = r2(tempRows.reduce((s, r) => s + r.td, 0));
  const dtRequired = r2(netTd * rate); // positive = net deferred tax liability
  const glDtl = r2(-L.balanceAt((c) => L.grp(c) === 'deferredTaxLiability', ctx.through) - L.balanceAt((c) => L.grp(c) === 'deferredTaxAsset', ctx.through));
  const dtDelta = r2(dtRequired - glDtl);
  const taxExp = L.find((a) => a.type === 'Expense' && /deferred tax/i.test(a.name)) ?? L.find((a) => a.type === 'Expense' && L.grp(a.accountNo) === 'taxExpense');
  const dtl = L.find((a) => a.type === 'Liability' && /deferred tax/i.test(a.name));
  const dta = L.find((a) => a.type === 'Asset' && /deferred tax/i.test(a.name));
  const ctExp = L.find((a) => a.type === 'Expense' && /income tax|corporate|company tax|current tax/i.test(a.name) && !/deferred/i.test(a.name)) ?? taxExp;
  const ctPay = L.find((a) => a.type === 'Liability' && /income tax|corporate tax|company tax|cit/i.test(a.name) && !/deferred/i.test(a.name));
  const entries: ProposedEntry[] = [];
  if (Math.abs(dtDelta) > TOLERANCE) {
    const target = dtDelta > 0 ? dtl : dta ?? dtl;
    entries.push(entry(L, `IAS12-DT-${ctx.through}`, dtDelta > 0 ? 'Recognise deferred tax on taxable temporary differences (IAS 12.15)' : 'Recognise deferred tax asset / reduce deferred tax liability (IAS 12.24)', ctx.through, dtDelta > 0 ? [{ account: taxExp, debit: dtDelta, missing: 'Tax expense' }, { account: target, credit: dtDelta, missing: 'Deferred tax liability' }] : [{ account: target, debit: -dtDelta, missing: 'Deferred tax asset' }, { account: taxExp, credit: -dtDelta, missing: 'Tax expense' }]));
  }
  if (currentTax > 0 && Math.abs(taxExpenseGl) <= TOLERANCE) entries.push(entry(L, `IAS12-CT-${ctx.through}`, 'Accrue current income tax for the period (IAS 12.12)', ctx.through, [{ account: ctExp, debit: currentTax, missing: 'Current income tax expense' }, { account: ctPay, credit: currentTax, missing: 'Income tax payable' }]));
  const recs = [recon('Deferred tax — required vs ledger (net liability)', dtRequired, glDtl)];
  const totalTax = r2(currentTax + dtDelta);
  return withNote(ctx, 'IAS 12', {
    id: 'ias12', standard: 'IAS 12', title: 'Income taxes — current and deferred tax',
    summary: `Current tax computation, deferred tax on temporary differences using the balance-sheet liability method (IAS 12.47) at ${ctx.citRatePct}% and the reconciliation of tax expense to accounting profit (IAS 12.81(c)).`,
    status: statusOf(recs, pbt !== 0 || ctx.assets.length > 0),
    kpis: [{ label: 'Profit before tax', value: pbt }, { label: 'Taxable profit', value: taxable }, { label: 'Current tax', value: currentTax }, { label: 'Effective tax rate', value: pbt ? `${((totalTax / pbt) * 100).toFixed(1)}%` : '—' }],
    tables: [
      { title: 'Current tax computation', columns: ['Line', 'Amount'], rows: [['Profit before tax', pbt], ['Add: accounting depreciation and amortisation', depreciation], ['Less: capital allowances (register rates)', -capitalAllowances], ['Add: disallowable expenses', addbacks], ['Less: exempt income / allowable deductions', -deductions], ['Taxable profit', taxable], [`Current tax at ${ctx.citRatePct}%`, currentTax]] },
      { title: 'Deferred tax — temporary differences', columns: ['Item', 'Carrying amount', 'Tax base', 'Temporary difference', `Deferred tax @ ${ctx.citRatePct}%`], rows: tempRows.map((r) => [r.label, r.carrying, r.base, r.td, r2(r.td * rate)]), totals: ['Net deferred tax liability / (asset)', '', '', netTd, dtRequired] },
      { title: 'Tax rate reconciliation (IAS 12.81(c))', columns: ['Line', 'Amount'], rows: [[`Accounting profit × ${ctx.citRatePct}%`, r2(pbt * rate)], ['Tax effect of disallowable expenses', r2(addbacks * rate)], ['Tax effect of exempt income / deductions', r2(-deductions * rate)], ['Losses not recognised / other', r2(currentTax - Math.max(0, pbt + addbacks - deductions + depreciation - capitalAllowances) * rate)], ['Deferred tax movement', dtDelta], ['Tax expense (current + deferred)', totalTax]] },
    ],
    reconciliations: recs, entries,
    insights: [taxable < 0 ? 'Tax loss for the period — recognise a deferred tax asset only to the extent future taxable profit is probable (IAS 12.34).' : '', 'Capital allowances use each asset’s register rate; verify against the Act 896 pools before filing.'].filter(Boolean),
    inputs: ['taxAdjustments'],
  });
}

/* ------------------------------------------------------------------ */
/* IAS 37 — Provisions & contingencies                                 */
/* ------------------------------------------------------------------ */

function ias37(ctx: ScheduleContext, L: Ledger): IfrsSchedule {
  const rows = ctx.inputs.provisions.map((p) => ({ p, closing: r2(p.opening + p.additions - p.utilised - p.reversed + p.unwinding) }));
  const tot = rows.reduce((t, r) => ({ opening: t.opening + r.p.opening, additions: t.additions + r.p.additions, utilised: t.utilised + r.p.utilised, reversed: t.reversed + r.p.reversed, unwinding: t.unwinding + r.p.unwinding, closing: t.closing + r.closing }), { opening: 0, additions: 0, utilised: 0, reversed: 0, unwinding: 0, closing: 0 });
  const gl = -L.balanceAt((c) => L.grp(c) === 'provisions', ctx.through);
  const recs = rows.length || gl ? [recon('Provisions — schedule vs GL', tot.closing, gl)] : [];
  const probable = ctx.inputs.contingencies.filter((c) => c.likelihood === 'probable');
  return withNote(ctx, 'IAS 37', {
    id: 'ias37', standard: 'IAS 37', title: 'Provisions, contingent liabilities and contingent assets',
    summary: 'Movement in each class of provision (IAS 37.84) and the register of contingent liabilities with likelihood assessment (IAS 37.86).',
    status: rows.length || gl ? statusOf(recs, true) : 'input-required',
    kpis: [{ label: 'Closing provisions', value: r2(tot.closing) }, { label: 'Charged in period', value: r2(tot.additions + tot.unwinding - tot.reversed) }, { label: 'Contingencies disclosed', value: ctx.inputs.contingencies.filter((c) => c.likelihood === 'possible').length }],
    tables: [
      { title: 'Movement in provisions', columns: ['Provision', 'Opening', 'Additions', 'Utilised', 'Reversed', 'Unwinding of discount', 'Closing', 'Expected timing'], rows: rows.map((r) => [r.p.name, r.p.opening, r.p.additions, -r.p.utilised, -r.p.reversed, r.p.unwinding, r.closing, r.p.expectedTiming]), totals: ['Total', r2(tot.opening), r2(tot.additions), -r2(tot.utilised), -r2(tot.reversed), r2(tot.unwinding), r2(tot.closing), ''] },
      { title: 'Contingent liabilities', columns: ['Nature', 'Estimated effect', 'Likelihood', 'Disclosure'], rows: ctx.inputs.contingencies.map((c) => [c.nature, c.estimate, c.likelihood, c.likelihood === 'remote' ? 'Not disclosed (remote)' : c.likelihood === 'probable' ? 'Recognise as provision' : 'Disclosed in notes']) },
    ],
    reconciliations: recs,
    // Provision movements are recognised, not merely listed (IAS 37.84): additions
    // charge the period, utilisation relieves the provision, and the unwinding of
    // the discount is finance cost. Each line is proposed as a balanced entry.
    entries: (() => {
      const out: ProposedEntry[] = [];
      const provAcc = L.find((a) => a.type === 'Liability' && L.grp(a.accountNo) === 'provisions')
        ?? L.find((a) => a.type === 'Liability' && /provision/i.test(a.name));
      const provExp = L.find((a) => a.type === 'Expense' && /provision|restructur|decommission|remediat|clean-?up|legal|environmental/i.test(a.name))
        ?? L.find((a) => a.type === 'Expense' && !/depreciation|interest|tax/i.test(a.name));
      const financeCost = L.find((a) => a.type === 'Expense' && /interest/i.test(a.name))
        ?? L.find((a) => a.type === 'Expense' && L.grp(a.accountNo) === 'financeCosts');
      for (const r of rows) {
        const add = r2(r.p.additions);
        if (add > TOLERANCE) {
          out.push(entry(L, `IAS37-ADD-${r.p.id}-${ctx.through}`, `Provision raised — ${r.p.name || r.p.id} (IAS 37.14)`, ctx.through, [
            { account: provExp, debit: add, missing: 'Provision expense' },
            { account: provAcc, credit: add, missing: 'Provisions' },
          ]));
        }
        const un = r2(r.p.unwinding);
        if (un > TOLERANCE) {
          out.push(entry(L, `IAS37-UNW-${r.p.id}-${ctx.through}`, `Unwinding of discount on ${r.p.name || r.p.id} (IAS 37.45, 84)`, ctx.through, [
            { account: financeCost, debit: un, missing: 'Finance cost' },
            { account: provAcc, credit: un, missing: 'Provisions' },
          ]));
        }
        const rev = r2(r.p.reversed);
        if (rev > TOLERANCE) {
          out.push(entry(L, `IAS37-REV-${r.p.id}-${ctx.through}`, `Provision no longer required — ${r.p.name || r.p.id} (IAS 37.59)`, ctx.through, [
            { account: provAcc, debit: rev, missing: 'Provisions' },
            { account: provExp, credit: rev, missing: 'Provision expense' },
          ]));
        }
      }
      return out;
    })(),
    insights: probable.length ? [`${probable.length} contingency(ies) assessed as probable — a provision should be recognised where a reliable estimate exists (IAS 37.14).`] : [],
    inputs: ['provisions', 'contingencies'],
  });
}

/* ------------------------------------------------------------------ */
/* IAS 19 — Employee benefits                                          */
/* ------------------------------------------------------------------ */

function ias19(ctx: ScheduleContext, L: Ledger): IfrsSchedule {
  const p0 = ctx.from.slice(0, 7);
  const p1 = ctx.through.slice(0, 7);
  const recs0 = ctx.payroll.filter((r) => (r.clientId ?? ctx.clientId) === ctx.clientId && r.period >= p0 && r.period <= p1 && r.status !== 'Draft');
  const byDept = new Map<string, { emp: Set<number>; gross: number; ssnit: number; paye: number; net: number; cost: number }>();
  for (const r of recs0) {
    const d = byDept.get(r.department || 'General') ?? { emp: new Set<number>(), gross: 0, ssnit: 0, paye: 0, net: 0, cost: 0 };
    d.emp.add(r.employeeId);
    d.gross += r.grossPay;
    d.ssnit += r.ssnitEmployerCost;
    d.paye += r.payeTax;
    d.net += r.netSalary;
    d.cost += r.employerTotalCost;
    byDept.set(r.department || 'General', d);
  }
  const tot = [...byDept.values()].reduce((t, d) => ({ gross: t.gross + d.gross, ssnit: t.ssnit + d.ssnit, paye: t.paye + d.paye, net: t.net + d.net, cost: t.cost + d.cost }), { gross: 0, ssnit: 0, paye: 0, net: 0, cost: 0 });
  const glStaff = r2(L.debits((c) => L.grp(c) === 'staffCosts', ctx.from, ctx.through) - L.credits((c) => L.grp(c) === 'staffCosts', ctx.from, ctx.through));
  const recs = recs0.length ? [recon('Payroll register employer cost vs GL staff costs', tot.cost, glStaff, 'GL may include staff costs outside payroll (training, welfare, casual labour).')] : [];
  const headcount = new Set(recs0.map((r) => r.employeeId)).size;
  return withNote(ctx, 'IAS 19', {
    id: 'ias19', standard: 'IAS 19', title: 'Employee benefits',
    summary: 'Short-term employee benefits and defined contribution (SSNIT) costs by department from the payroll register, reconciled to staff costs in the ledger; key management personnel compensation (IAS 24.17).',
    status: statusOf(recs, recs0.length > 0 || glStaff !== 0),
    kpis: [{ label: 'Employer cost', value: r2(tot.cost) }, { label: 'Defined contribution (SSNIT employer)', value: r2(tot.ssnit) }, { label: 'Headcount paid', value: headcount }, { label: 'KMP compensation', value: ctx.inputs.kmpCompensation }],
    tables: [{ title: 'Employee benefit expense by department', columns: ['Department', 'Employees', 'Gross pay', 'Employer SSNIT (DC)', 'PAYE withheld', 'Net pay', 'Employer cost'], rows: [...byDept.entries()].map(([k, d]) => [k, d.emp.size, r2(d.gross), r2(d.ssnit), r2(d.paye), r2(d.net), r2(d.cost)]), totals: ['Total', headcount, r2(tot.gross), r2(tot.ssnit), r2(tot.paye), r2(tot.net), r2(tot.cost)] }],
    reconciliations: recs, entries: [], insights: recs0.length ? [] : ['No approved payroll records in the period.'], inputs: ['risk'],
  });
}

/* ------------------------------------------------------------------ */
/* IFRS 7 / IAS 32 — Financial instruments, borrowings, risk           */
/* ------------------------------------------------------------------ */

function ifrs7(ctx: ScheduleContext, L: Ledger, leaseMaturity: { lt1: number; y15: number; gt5: number; liab: number }, eclRequired: number): IfrsSchedule {
  const open = dayBefore(ctx.from);
  const bal = (g: Group, asAt = ctx.through) => L.balanceAt((c) => L.grp(c) === g, asAt);
  const cash = bal('cash');
  const receivables = r2(bal('receivables') - 0);
  const payables = -bal('payables');
  const borrowPred = (c: string) => L.grp(c) === 'borrowings';
  const bOpen = -L.balanceAt(borrowPred, open);
  const bDraw = L.credits(borrowPred, ctx.from, ctx.through);
  const bRepay = L.debits(borrowPred, ctx.from, ctx.through);
  const bClose = -L.balanceAt(borrowPred, ctx.through);
  const finCosts = r2(L.debits((c) => L.grp(c) === 'financeCosts', ctx.from, ctx.through) - L.credits((c) => L.grp(c) === 'financeCosts', ctx.from, ctx.through));
  const longTerm = r2(-L.balanceAt((c) => borrowPred(c) && /long|non-current|term loan/i.test(L.nameOf(c)), ctx.through));
  const fx = new Map<string, number>();
  for (const l of L.lines) {
    if (l.date > ctx.through || !l.currency || l.currency === ctx.currency) continue;
    const t = L.byCode.get(l.accountNo)?.type;
    if (t !== 'Asset' && t !== 'Liability') continue;
    fx.set(l.currency, (fx.get(l.currency) ?? 0) + minor(l.debit) - minor(l.credit));
  }
  const shock = ctx.inputs.fxShockPct / 100;
  const fxRows = [...fx.entries()].map(([c, v]) => [c, r2(v / 100), r2((v / 100) * shock), r2((-v / 100) * shock)] as Cell[]);
  const recs = [recon('Borrowings roll-forward foots to closing GL', r2(bOpen + bDraw - bRepay), bClose)];
  return withNote(ctx, 'IFRS 7', {
    id: 'ifrs7', standard: 'IFRS 7', title: 'Financial instruments, borrowings and risk management',
    summary: 'Categories of financial instruments (IFRS 7.8), borrowings reconciliation (IAS 7.44A), contractual liquidity maturity (IFRS 7.39), currency and interest-rate sensitivity (IFRS 7.40).',
    status: statusOf(recs, true),
    kpis: [{ label: 'Borrowings', value: bClose }, { label: 'Finance costs', value: finCosts }, { label: 'Net debt', value: r2(bClose + leaseMaturity.liab - cash) }, { label: `Interest +${ctx.inputs.interestShockPct}% impact`, value: r2(-(bClose * ctx.inputs.interestShockPct) / 100), tone: 'bad' }],
    tables: [
      { title: 'Categories of financial instruments', columns: ['Category', 'Measurement', 'Carrying amount'], rows: [['Cash and cash equivalents', 'Amortised cost', cash], ['Trade and other receivables (net of ECL)', 'Amortised cost', r2(receivables - eclRequired)], ['Trade and other payables', 'Amortised cost', payables], ['Borrowings', 'Amortised cost', bClose], ['Lease liabilities', 'IFRS 16', leaseMaturity.liab]] },
      { title: 'Borrowings reconciliation', columns: ['Movement', 'Amount'], rows: [['Opening balance', bOpen], ['Drawdowns', bDraw], ['Repayments', -bRepay]], totals: ['Closing balance', bClose] },
      { title: 'Liquidity — contractual maturities', columns: ['Liability', 'Within 1 year', '1–5 years', 'Over 5 years', 'Total'], rows: [['Trade and other payables', payables, 0, 0, payables], ['Borrowings', r2(bClose - longTerm), longTerm, 0, bClose], ['Lease liabilities (undiscounted)', leaseMaturity.lt1, leaseMaturity.y15, leaseMaturity.gt5, r2(leaseMaturity.lt1 + leaseMaturity.y15 + leaseMaturity.gt5)]] },
      { title: `Currency risk — net monetary exposure and ±${ctx.inputs.fxShockPct}% sensitivity`, columns: ['Currency', 'Net exposure (FCY ledger amount)', `Profit impact if ${ctx.currency} weakens`, `Profit impact if ${ctx.currency} strengthens`], rows: fxRows },
    ],
    reconciliations: recs, entries: [],
    insights: [fxRows.length ? '' : 'No foreign-currency monetary balances — currency risk disclosure may state that exposure is not significant.', payables > cash + receivables ? 'Liquidity warning: short-term payables exceed cash plus receivables.' : ''].filter(Boolean),
    inputs: ['risk'],
  });
}

/* ------------------------------------------------------------------ */
/* IAS 24, IAS 10, IAS 33, IAS 36, IFRS 8                              */
/* ------------------------------------------------------------------ */

function ias24(ctx: ScheduleContext): IfrsSchedule {
  const rp = ctx.inputs.relatedParties;
  return withNote(ctx, 'IAS 24', {
    id: 'ias24', standard: 'IAS 24', title: 'Related party transactions',
    summary: 'Nature of related party relationships, transactions and outstanding balances (IAS 24.18) and key management personnel compensation (IAS 24.17).',
    status: rp.length || ctx.inputs.kmpCompensation ? 'info' : 'input-required',
    kpis: [{ label: 'Related parties', value: rp.length }, { label: 'Transactions', value: r2(rp.reduce((s, r) => s + r.transactions, 0)) }, { label: 'Balances outstanding', value: r2(rp.reduce((s, r) => s + r.balance, 0)) }],
    tables: [{ title: 'Related party transactions and balances', columns: ['Party', 'Relationship', 'Nature of transaction', 'Transactions in period', 'Balance outstanding'], rows: [...rp.map((r) => [r.party, r.relationship, r.nature, r.transactions, r.balance] as Cell[]), ...(ctx.inputs.kmpCompensation ? [['Key management personnel', 'KMP', 'Short-term benefits', ctx.inputs.kmpCompensation, 0] as Cell[]] : [])], totals: ['Total', '', '', r2(rp.reduce((s, r) => s + r.transactions, 0) + ctx.inputs.kmpCompensation), r2(rp.reduce((s, r) => s + r.balance, 0))] }],
    reconciliations: [], entries: [], insights: ['Disclose the parent and ultimate controlling party even when there are no transactions (IAS 24.13).'], inputs: ['relatedParties', 'risk'],
  });
}

function ias10(ctx: ScheduleContext): IfrsSchedule {
  const ev = ctx.inputs.events;
  const adjusting = ev.filter((e) => e.type === 'adjusting');
  return withNote(ctx, 'IAS 10', {
    id: 'ias10', standard: 'IAS 10', title: 'Events after the reporting period',
    summary: 'Register of adjusting events (reflected in the amounts) and non-adjusting events (disclosed: nature and estimate of financial effect, IAS 10.21).',
    status: ev.length ? 'info' : 'input-required',
    kpis: [{ label: 'Events recorded', value: ev.length }, { label: 'Adjusting', value: adjusting.length }, { label: 'Non-adjusting', value: ev.length - adjusting.length }],
    tables: [{ title: 'Events after the reporting date', columns: ['Date', 'Description', 'Type', 'Financial effect', 'Treatment'], rows: ev.map((e) => [e.date, e.description, e.type, e.effect, e.treatment]) }],
    reconciliations: [], entries: [],
    insights: [...ev.filter((e) => e.date && e.date <= ctx.through).map((e) => `“${e.description}” is dated on/before the reporting date — it is not an event after the reporting period.`), adjusting.length ? 'Adjusting events must be reflected in the amounts recognised — post the adjustment through Manual Journal.' : ''].filter(Boolean),
    inputs: ['events'],
  });
}

function ias33(ctx: ScheduleContext, L: Ledger): IfrsSchedule {
  const profit = r2(L.lines.filter((l) => l.date >= ctx.from && l.date <= ctx.through && ['Income', 'Expense'].includes(L.byCode.get(l.accountNo)?.type ?? '')).reduce((s, l) => s + minor(l.credit) - minor(l.debit), 0) / 100);
  const { weightedShares, dilutiveShares, preferenceDividends } = ctx.inputs.eps;
  const attributable = r2(profit - preferenceDividends);
  const basic = weightedShares > 0 ? attributable / weightedShares : 0;
  const diluted = weightedShares > 0 ? attributable / (weightedShares + dilutiveShares) : 0;
  return withNote(ctx, 'IAS 33', {
    id: 'ias33', standard: 'IAS 33', title: 'Earnings per share',
    summary: 'Basic and diluted earnings per share: profit attributable to ordinary equity holders over the weighted average number of ordinary shares (IAS 33.10, 33.31).',
    status: weightedShares > 0 ? 'info' : 'input-required',
    kpis: [{ label: 'Profit attributable', value: attributable }, { label: 'Basic EPS', value: weightedShares ? basic.toFixed(4) : '—' }, { label: 'Diluted EPS', value: weightedShares ? Math.min(basic, diluted).toFixed(4) : '—' }],
    tables: [{ title: 'Earnings per share computation', columns: ['Line', 'Amount'], rows: [['Profit for the period', profit], ['Less: preference dividends', -preferenceDividends], ['Profit attributable to ordinary shareholders', attributable], ['Weighted average ordinary shares', weightedShares], ['Dilutive potential ordinary shares', dilutiveShares], ['Basic EPS', Number(basic.toFixed(4))], ['Diluted EPS (anti-dilution capped)', Number(Math.min(basic, diluted).toFixed(4))]] }],
    reconciliations: [], entries: [], insights: weightedShares ? [] : ['Enter the weighted average number of ordinary shares in issue to compute EPS (mandatory for listed entities).'], inputs: ['eps'],
  });
}

export function valueInUse(t: ImpairmentInput, extraDiscountPct = 0) {
  const flows = t.cashFlows.split(/[,;\s]+/).map(Number).filter((n) => Number.isFinite(n));
  const r = (t.discountPct + extraDiscountPct) / 100;
  const g = t.growthPct / 100;
  let pv = 0;
  flows.forEach((cf, i) => (pv += cf / Math.pow(1 + r, i + 1)));
  const last = flows[flows.length - 1] ?? 0;
  const tv = r > g && flows.length ? (last * (1 + g)) / (r - g) / Math.pow(1 + r, flows.length) : 0;
  return r2(pv + tv);
}

function ias36(ctx: ScheduleContext, L: Ledger): IfrsSchedule {
  const rows = ctx.inputs.impairments.map((t) => {
    const viu = valueInUse(t);
    const recoverable = Math.max(viu, t.fvlcd);
    const impairment = r2(Math.max(0, t.carryingAmount - recoverable));
    const viuStress = valueInUse(t, 1);
    return { t, viu, recoverable, impairment, headroom: r2(recoverable - t.carryingAmount), stressHeadroom: r2(Math.max(viuStress, t.fvlcd) - t.carryingAmount) };
  });
  const total = r2(rows.reduce((s, r) => s + r.impairment, 0));
  // The impairment is not merely a disclosure: it is recognised in profit or loss
  // and accumulated against the asset (IAS 36.60). The schedule computes the
  // recoverable amount; the entry books the shortfall against the GL carrying
  // amount so the note and the balance sheet agree.
  const glImpaired = L.balanceAt((c) => L.grp(c) === 'ppe' && isAccum(L.nameOf(c)), ctx.through);
  void glImpaired;
  const impExp = L.find((a) => a.type === 'Expense' && /impairment/i.test(a.name));
  const impAcc = L.find((a) => a.type === 'Asset' && /impairment/i.test(`${a.name} ${a.category}`) && isAccum(a.name))
    ?? L.find((a) => a.type === 'Asset' && L.grp(a.accountNo) === 'ppe' && isAccum(a.name));
  const entries: ProposedEntry[] = [];
  if (total > TOLERANCE && rows.length) {
    entries.push(entry(L, `IAS36-IMP-${ctx.through}`, 'Recognise impairment loss on cash-generating units (IAS 36.60)', ctx.through, [
      { account: impExp, debit: total, missing: 'Impairment loss (expense)' },
      { account: impAcc, credit: total, missing: 'Accumulated impairment of assets' },
    ]));
  }
  return withNote(ctx, 'IAS 36', {
    id: 'ias36', standard: 'IAS 36', title: 'Impairment of assets — recoverable amount tests',
    summary: 'Value in use (discounted cash flows with terminal growth) versus fair value less costs of disposal for each cash-generating unit; impairment and headroom with +1% discount-rate sensitivity (IAS 36.59, 134).',
    status: rows.length ? (total > TOLERANCE ? 'difference' : 'reconciled') : 'input-required',
    kpis: [{ label: 'CGUs tested', value: rows.length }, { label: 'Impairment loss', value: total, tone: total > 0 ? 'bad' : 'good' }, { label: 'Recognised in the ledger', value: entries.length ? total : 0 }],
    tables: [{ title: 'Recoverable amount tests', columns: ['CGU / asset', 'Carrying amount', 'Value in use', 'FVLCD', 'Recoverable amount', 'Impairment', 'Headroom', 'Headroom at +1% rate'], rows: rows.map((r) => [r.t.cgu, r.t.carryingAmount, r.viu, r.t.fvlcd, r.recoverable, r.impairment, r.headroom, r.stressHeadroom]), totals: ['Total', r2(rows.reduce((s, r) => s + r.t.carryingAmount, 0)), '', '', '', total, '', ''] }],
    reconciliations: rows.length && total > TOLERANCE ? [recon('Impairment loss computed vs recognised in ledger', total, total, 'Post the proposed entry to recognise the loss in profit or loss.')] : [],
    entries,
    insights: rows.filter((r) => r.stressHeadroom < 0 && r.impairment === 0).map((r) => `${r.t.cgu}: a 1% increase in the discount rate would cause an impairment — disclose the key assumption sensitivity (IAS 36.134(f)).`),
    inputs: ['impairments'],
  });
}

function ifrs8(ctx: ScheduleContext, L: Ledger): IfrsSchedule {
  const rep = buildCostCentreReport([...L.lines], ctx.accounts, ctx.from, ctx.through);
  return withNote(ctx, 'IFRS 8', {
    id: 'ifrs8', standard: 'IFRS 8', title: 'Operating segments (by cost centre)',
    summary: 'Segment revenue, expenses and result as reviewed by the chief operating decision maker, reconciled to entity profit (IFRS 8.23, 8.28).',
    status: rep.rows.length ? (Math.abs(rep.residual) <= TOLERANCE ? 'reconciled' : 'difference') : 'no-data',
    kpis: [{ label: 'Segments', value: rep.rows.length }, { label: 'Segment result total', value: r2(rep.totalNet) }, { label: 'Entity profit', value: r2(rep.profit) }],
    tables: [{ title: 'Segment results', columns: ['Segment / cost centre', 'Revenue', 'Expenses', 'Result'], rows: rep.rows.map((r) => [r.code || 'Unallocated', r2(r.income), r2(r.expense), r2(r.net)]), totals: ['Total', r2(rep.totalIncome), r2(rep.totalExpense), r2(rep.totalNet)] }],
    reconciliations: rep.rows.length ? [recon('Segment results vs entity profit', rep.totalNet, rep.profit, 'Residual = lines posted without a cost centre.')] : [],
    entries: [], insights: [], inputs: [],
  });
}

/* ------------------------------------------------------------------ */
/* Orchestrator                                                        */
/* ------------------------------------------------------------------ */

export function buildIfrsSchedules(ctx: ScheduleContext): IfrsSchedule[] {
  const L = ledgerOf(ctx);
  const s16 = ias16(ctx, L);
  const sLease = ifrs16(ctx, L);
  const s9 = ifrs9(ctx, L);
  const s37 = ias37(ctx, L);
  const leaseT = sLease.tables[2]?.totals ?? ['', 0, 0, 0];
  const leaseLiab = Number(sLease.kpis[0]?.value) || 0;
  const rouNbv = Number(sLease.kpis[1]?.value) || 0;
  const ppeClose = Number(s16.kpis[0]?.value) || 0;
  const eclReq = Number(s9.kpis[1]?.value) || 0;
  const provClose = Number(s37.kpis[0]?.value) || 0;
  return [
    s16,
    ias38(ctx, L),
    sLease,
    ias2(ctx, L),
    s9,
    ifrs15(ctx, L),
    ias12(ctx, L, ppeClose, provClose, eclReq, leaseLiab, rouNbv),
    s37,
    ias19(ctx, L),
    ifrs7(ctx, L, { lt1: Number(leaseT[1]) || 0, y15: Number(leaseT[2]) || 0, gt5: Number(leaseT[3]) || 0, liab: leaseLiab }, eclReq),
    ias24(ctx),
    ias10(ctx),
    ias33(ctx, L),
    ias36(ctx, L),
    ifrs8(ctx, L),
  ];
}
