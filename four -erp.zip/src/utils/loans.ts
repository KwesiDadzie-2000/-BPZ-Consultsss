/**
 * Loan amortisation engine (IAS 23 finance costs, IFRS 9 debt at amortised cost).
 *
 * Money arithmetic is done in MINOR UNITS, and every scheduled figure is exactly
 * two decimal places before it ever reaches the journal — the schedule used to
 * feed raw annuity floats into posting, so the journal controls rejected it with
 * "Amounts must have no more than two decimal places."
 *
 * Both legs of the debt-service workflow are modelled here:
 *  - PAY:    Dr Interest expense + Dr Borrowings (principal) / Cr treasury GL.
 *  - ACCRUE: the instalment falls due but is NOT paid — the contractual amount is
 *            reclassified from the loan into a current payable (202000) so it
 *            ages in payables and is settled later at the Payment Desk.
 */
import type { ACDOCALine } from '../types/accounting';
import { money } from './trading';
import { uniqueId } from './ids';
import { shiftMonth } from './planning';

/** Last calendar day of an ISO month (YYYY-MM). Instalments fall at month-end. */
export const lastDayOfMonth = (ym: string): string => {
  const [y, m] = ym.split('-').map(Number);
  return `${ym}-${String(new Date(Date.UTC(y, m, 0)).getUTCDate()).padStart(2, '0')}`;
};

export type FacilityType = 'amortising' | 'interest_only' | 'bullet';
export type RepaymentFrequency = 'monthly' | 'quarterly';

export interface LoanFacility {
  id: string;
  code: string;
  facilityName: string;
  lender: string;
  principal: number;
  annualRatePct: number;
  termMonths: number;
  frequency: RepaymentFrequency;
  facilityType: FacilityType;
  arrangementFee: number;
  startDate: string;
  status: 'Active' | 'Closed';
}

export interface AmortisationRow {
  periodNum: number;
  date: string;
  openingBalance: number;
  interestExpense: number;
  principalPayment: number;
  totalPayment: number;
  closingBalance: number;
}

/** Months between instalments (monthly = 1, quarterly = 3). */
const stepFor = (f: RepaymentFrequency) => (f === 'quarterly' ? 3 : 1);

/**
 * Full amortisation schedule, pesewa-exact. The final scheduled instalment takes
 * any rounding residue so the schedule always amortises to a zero balance.
 */
export function generateAmortisationSchedule(loan: LoanFacility): AmortisationRow[] {
  const rows: AmortisationRow[] = [];
  const step = stepFor(loan.frequency);
  const periodsPerYear = 12 / step;
  const ratePerPeriod = loan.annualRatePct / 100 / periodsPerYear;
  const n = Math.max(1, Math.round(loan.termMonths / step));
  const startMonth = loan.startDate.slice(0, 7);

  // Annuity constant instalment: P * i / (1 - (1+i)^-n)
  const factor = Math.pow(1 + ratePerPeriod, n);
  const annuity =
    loan.facilityType === 'amortising'
      ? money((loan.principal * ratePerPeriod * factor) / (factor - 1))
      : money(loan.principal * ratePerPeriod);

  let balance = money(loan.principal);
  for (let i = 1; i <= n; i += 1) {
    const paymentMonth = shiftMonth(startMonth, i * step);
    const interest = money(balance * ratePerPeriod);
    let principalPmt = 0;
    let totalPmt = 0;
    if (loan.facilityType === 'amortising') {
      const isLast = i === n;
      principalPmt = isLast ? balance : Math.min(balance, money(annuity - interest));
      totalPmt = money(interest + principalPmt);
    } else if (loan.facilityType === 'interest_only') {
      principalPmt = i === n ? balance : 0;
      totalPmt = money(interest + principalPmt);
    } else {
      principalPmt = i === n ? balance : 0;
      totalPmt = money(i === n ? balance + interest : interest);
    }
    const closing = money(balance - principalPmt);
    rows.push({
      periodNum: i,
      date: lastDayOfMonth(paymentMonth),
      openingBalance: balance,
      interestExpense: interest,
      principalPayment: principalPmt,
      totalPayment: totalPmt,
      closingBalance: closing,
    });
    balance = closing;
    if (balance <= 0.009) break;
  }
  return rows;
}

export interface DebtServiceSpec {
  facility: LoanFacility;
  row: AmortisationRow;
  clientId: number;
  currency: string;
  date: string;
  username: string;
  canCheck?: boolean;
  /** Treasury GL the cash leaves from (pay mode only). */
  treasuryAccountNo: string;
  treasuryAccountName: string;
  costCenter?: string;
}

/** Journal for an instalment PAID out of treasury now. */
export function buildDebtServicePaymentJournal(spec: DebtServiceSpec): ACDOCALine[] {
  const { facility, row, clientId, currency, date, username, canCheck } = spec;
  const docNo = `LOAN-PMT-${facility.code}-M${row.periodNum}`;
  const period = date.slice(0, 7);
  const cc = spec.costCenter ?? 'CC-ADM';
  const stamp = { createdBy: username, checkedBy: canCheck ? username : undefined, clientId, costCenter: cc, module: 'FI' as const, docType: 'PAY' as const, currency, period, date };
  return [
    { ...stamp, id: uniqueId('JL-LOAN'), docNo, accountNo: '700000', accountName: 'Finance Costs on Commercial Loans', debit: row.interestExpense, credit: 0, description: `Interest charge on ${facility.facilityName} (instalment ${row.periodNum})` },
    { ...stamp, id: uniqueId('JL-LOAN'), docNo, accountNo: '250000', accountName: 'Commercial Borrowings (Ecobank / Stanbic)', debit: row.principalPayment, credit: 0, description: `Principal repaid on ${facility.code} (instalment ${row.periodNum})` },
    { ...stamp, id: uniqueId('JL-LOAN'), docNo, accountNo: spec.treasuryAccountNo, accountName: spec.treasuryAccountName, debit: 0, credit: row.totalPayment, description: `Debt service instalment paid to ${facility.lender} — ${facility.code}` },
  ];
}

/**
 * Journal for an instalment ACCRUED (not yet paid): the contractual instalment
 * is released from the loan into Accrued Expenses & Other Payables (202000) under
 * the EXPB- expense-bill convention, so it appears in AP ageing and is settled
 * later at the Payment Desk.
 */
export function buildDebtServiceAccrualJournal(spec: DebtServiceSpec): ACDOCALine[] {
  const { facility, row, clientId, currency, date, username, canCheck } = spec;
  const docNo = `EXPB-LOAN-${facility.code}-M${row.periodNum}`;
  const period = date.slice(0, 7);
  const cc = spec.costCenter ?? 'CC-ADM';
  const stamp = { createdBy: username, checkedBy: canCheck ? username : undefined, clientId, costCenter: cc, module: 'FI' as const, docType: 'JE' as const, currency, period, date };
  return [
    { ...stamp, id: uniqueId('JL-LOAN'), docNo, accountNo: '700000', accountName: 'Finance Costs on Commercial Loans', debit: row.interestExpense, credit: 0, description: `Accrued interest on ${facility.facilityName} (instalment ${row.periodNum} due, unpaid)` },
    { ...stamp, id: uniqueId('JL-LOAN'), docNo, accountNo: '250000', accountName: 'Commercial Borrowings (Ecobank / Stanbic)', debit: row.principalPayment, credit: 0, description: `Instalment principal ${row.periodNum} on ${facility.code} fallen due — reclassified to current payables` },
    { ...stamp, id: uniqueId('JL-LOAN'), docNo, reference: docNo, accountNo: '202000', accountName: `Accrued Expenses & Other Payables (${facility.lender})`, debit: 0, credit: row.totalPayment, description: `Unpaid debt service instalment payable to ${facility.lender} — settle at the Payment Desk` },
  ];
}

/** Round every debit/credit to two decimals and re-balance each document by
 *  settling any pesewa residue on the largest line. Defensive layer so a
 *  schedule-like computation can never be refused for sub-pesewa amounts. */
export function normalizeJournalAmounts(lineItems: ACDOCALine[]): ACDOCALine[] {
  const out = lineItems.map((l) => ({ ...l, debit: money(l.debit), credit: money(l.credit) }));
  const docs = new Map<string, ACDOCALine[]>();
  for (const l of out) {
    const key = `${l.clientId}:${l.docNo}`;
    if (!docs.has(key)) docs.set(key, []);
    docs.get(key)!.push(l);
  }
  for (const lines of docs.values()) {
    const debits = lines.reduce((s, l) => s + l.debit, 0);
    const credits = lines.reduce((s, l) => s + l.credit, 0);
    const residue = money(debits - credits);
    if (Math.abs(residue) < 0.005) continue;
    if (residue > 0) {
      // debits exceed credits — settle the pesewa(s) on the largest credit line.
      const target = lines.reduce((best, l) => (l.credit > best.credit ? l : best), lines[0]);
      target.credit = money(target.credit + residue);
    } else {
      const target = lines.reduce((best, l) => (l.debit > best.debit ? l : best), lines[0]);
      target.debit = money(target.debit - residue);
    }
  }
  return out;
}
