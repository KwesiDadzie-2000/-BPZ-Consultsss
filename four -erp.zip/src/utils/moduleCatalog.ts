/**
 * Single source of truth for workspace modules (sidebar section ids).
 *
 * Used by:
 *  - `maySeeSection` (utils/access.ts) — UI and sidebar visibility for every user,
 *  - the User Access & Restrictions desk — the owner ticks which modules a client
 *    user may open (`permissions.allowedModules`),
 *  - the server (api/users) — validates the ticked list before it is stored.
 *
 * OWNER_ONLY_MODULES are firm administration. They are never shown to clients,
 * regardless of contract services or per-user ticks.
 */

export interface ModuleCatalogEntry {
  id: string;
  label: string;
  group: string;
}

/** Modules that only the Firm Owner can open. */
export const OWNER_ONLY_MODULES: ReadonlySet<string> = new Set([
  'clients_management',
  'advisory',
  'user_permissions',
  'group_consolidation',
  'enterprise_sso',
  'global_tax',
  'tax_settings',
  'soc_dr',
  'realtime_integrations',
]);

/** Client-facing modules a firm can tick for a client user. Dashboard is always visible. */
export const CLIENT_MODULE_CATALOG: ModuleCatalogEntry[] = [
  { id: 'company_profile', label: 'Company Profile & Backup', group: 'Setup' },
  { id: 'sector_workflow', label: 'Sector Workflow Switcher', group: 'Setup' },
  { id: 'opening_balance', label: 'Opening Balances Setup', group: 'Setup' },
  { id: 'coa_master', label: 'Chart of Accounts Master', group: 'Setup' },
  { id: 'universal_journal', label: 'Journals (Universal & Manual)', group: 'Ledger' },
  { id: 'general_ledger', label: 'General Ledger', group: 'Ledger' },
  { id: 'adjustments', label: 'Adjustment of Accounts', group: 'Ledger' },
  { id: 'control_accounts', label: 'Control Accounts Reconciliation', group: 'Ledger' },
  { id: 'month_end', label: 'Month-End Close', group: 'Ledger' },
  { id: 'procurement', label: 'Procurement & P2P', group: 'Trade' },
  { id: 'sales', label: 'Sales & Invoicing · O2C', group: 'Trade' },
  { id: 'business_partners_crm', label: 'Client Master File', group: 'Trade' },
  { id: 'expenses', label: 'Expenses & Statutory', group: 'Trade' },
  { id: 'payment_desk', label: 'Payment Desk', group: 'Treasury' },
  { id: 'banking', label: 'Banking & Reconcile', group: 'Treasury' },
  { id: 'ageing', label: 'Ageing Analysis (AR & AP)', group: 'Treasury' },
  { id: 'inventory', label: 'Inventory Command Desk', group: 'Operations' },
  { id: 'inventory_ledger', label: 'Stock Ledger & Valuation', group: 'Operations' },
  { id: 'boms', label: 'Bill of Materials', group: 'Operations' },
  { id: 'production_desk', label: 'Production Desk', group: 'Operations' },
  { id: 'assets', label: 'Fixed Assets Register', group: 'Operations' },
  { id: 'prepayments', label: 'Prepayments & Deferrals', group: 'Operations' },
  { id: 'project_costing', label: 'Project Costing & Contracts', group: 'Ledger' },
  { id: 'payroll', label: 'Payroll Desk', group: 'People' },
  { id: 'hr_desk', label: 'HR Management Desk', group: 'People' },
  { id: 'hr_employees', label: 'Employees', group: 'People' },
  { id: 'hr_attendance', label: 'Employee Attendance', group: 'People' },
  { id: 'hr_requests', label: 'Employee Requests', group: 'People' },
  { id: 'hr_structure', label: 'Organisational Structure', group: 'People' },
  { id: 'hr_tasks', label: 'Task Management', group: 'People' },
  { id: 'tax_schedule', label: 'Tax Desk (Schedules, Returns & Filing)', group: 'Tax & Compliance' },
  { id: 'ifrs_desk', label: 'IFRS Desk (Standards + Schedules)', group: 'Reporting' },
  { id: 'ifrs_statements', label: 'Financial Statements & IFRS', group: 'Reporting' },
  { id: 'disclosures', label: 'Notes to Accounts', group: 'Reporting' },
  { id: 'loans_desk', label: 'Loan Amortisation Schedules', group: 'Reporting' },
  { id: 'regulated_industries', label: 'Regulated Industries (IFRS 9/17, Royalties, Levies)', group: 'Reporting' },
  { id: 'compliance_review', label: 'Compliance Review & Gaps', group: 'Reporting' },
  { id: 'reports', label: 'Reports Centre', group: 'Reports' },
  { id: 'report_sales_r', label: 'Sales Reports', group: 'Reports' },
  { id: 'report_purchases_r', label: 'Purchases Reports', group: 'Reports' },
  { id: 'report_inventory_r', label: 'Inventory Reports', group: 'Reports' },
  { id: 'report_clients_r', label: 'Clients Reports', group: 'Reports' },
  { id: 'report_store_r', label: 'Store Reports', group: 'Reports' },
  { id: 'report_production_r', label: 'Production & WIP', group: 'Reports' },
  { id: 'report_hr_r', label: 'HR & Payroll Reports', group: 'Reports' },
  { id: 'report_ageing_r', label: 'Ageing Analysis (AR & AP)', group: 'Reports' },
  { id: 'report_financial_r', label: 'Financial Reports', group: 'Reports' },
  { id: 'crm_desk', label: 'Client Relationship Desk', group: 'Clients & CRM' },
  { id: 'performance', label: 'Budgeting, Forecast & Scenarios', group: 'Analytics' },
  { id: 'analytics', label: 'Data Analytics & CAATs', group: 'Analytics' },
];

/** Ids a per-user module tick can refer to. */
export const CLIENT_MODULE_IDS: ReadonlySet<string> = new Set(CLIENT_MODULE_CATALOG.map((m) => m.id));

/**
 * Every signed-in person may secure their own account. This module is never
 * removed by client-service selection or a restricted module-tick list.
 */
export const ALWAYS_AVAILABLE_MODULES: ReadonlySet<string> = new Set(['dashboard', 'my_security']);

/** Upper bound on the ticked list, so a crafted payload cannot bloat the user record. */
export const MAX_ALLOWED_MODULES = 200;
