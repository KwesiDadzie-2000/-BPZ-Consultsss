import type { AccountMaster } from '../types/accounting';
import { isValidIsoDate } from '../lib/journalValidation';

export type OpeningEntry = { dr: number; cr: number };
export type OpeningSchedule = Record<string, OpeningEntry>;

export const OPENING_EQUITY_ACCOUNT = '309000';

const money = (value: unknown): number => {
  const n = Number(value);
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : 0;
};

/** Never let NaN, Infinity, negative inputs or sub-pesewa values poison a draft. */
export function normaliseOpeningSchedule(raw: unknown): OpeningSchedule {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const result: OpeningSchedule = {};
  for (const [account, value] of Object.entries(raw as Record<string, unknown>)) {
    if (!value || typeof value !== 'object') continue;
    const row = value as Record<string, unknown>;
    const dr = Math.max(0, money(row.dr));
    const cr = Math.max(0, money(row.cr));
    // A balance-sheet account has one normal-side opening balance, never both.
    result[account] = dr >= cr ? { dr, cr: 0 } : { dr: 0, cr };
  }
  return result;
}

export function openingScheduleTotals(schedule: OpeningSchedule) {
  let drMinor = 0;
  let crMinor = 0;
  let populated = 0;
  for (const row of Object.values(schedule)) {
    const dr = Math.max(0, Math.round((Number(row.dr) || 0) * 100));
    const cr = Math.max(0, Math.round((Number(row.cr) || 0) * 100));
    drMinor += dr;
    crMinor += cr;
    if (dr || cr) populated += 1;
  }
  return {
    totalDr: drMinor / 100,
    totalCr: crMinor / 100,
    difference: (drMinor - crMinor) / 100,
    populated,
    balanced: populated > 0 && drMinor === crMinor,
  };
}

/**
 * Add/update the take-on equity line so Dr = Cr exactly. This is an explicit
 * owner/accountant action, not a silent plug: the schedule shows the line before
 * posting and its description identifies it as opening-balance equity.
 */
export function balanceOpeningScheduleToEquity(
  raw: OpeningSchedule,
  equityAccount = OPENING_EQUITY_ACCOUNT,
): OpeningSchedule {
  const schedule = normaliseOpeningSchedule(raw);
  const before = openingScheduleTotals(schedule);
  if (!before.populated) return schedule;
  delete schedule[equityAccount];
  const totals = openingScheduleTotals(schedule);
  if (totals.difference > 0) schedule[equityAccount] = { dr: 0, cr: totals.difference };
  else if (totals.difference < 0) schedule[equityAccount] = { dr: -totals.difference, cr: 0 };
  return schedule;
}

/** Explain the real failure instead of always blaming an imbalance. */
export function openingScheduleBlockers(
  raw: OpeningSchedule,
  accounts: readonly AccountMaster[],
  cutOverDate: string,
  closedPeriods: readonly string[],
): string[] {
  const schedule = normaliseOpeningSchedule(raw);
  const totals = openingScheduleTotals(schedule);
  const blockers: string[] = [];
  if (!totals.populated) blockers.push('Enter at least one opening balance.');
  if (!totals.balanced) blockers.push(`Debits (${totals.totalDr.toFixed(2)}) and credits (${totals.totalCr.toFixed(2)}) differ by ${Math.abs(totals.difference).toFixed(2)}. Balance the schedule to Opening Balance Equity or correct the source figures.`);
  if (!isValidIsoDate(cutOverDate)) {
    blockers.push('Choose a valid financial cut-over date (a real calendar date, YYYY-MM-DD).');
  } else if (closedPeriods.includes(cutOverDate.slice(0, 7))) {
    blockers.push(`Period ${cutOverDate.slice(0, 7)} is closed. Reopen it in Month-End Close or choose an open cut-over period.`);
  }
  const available = new Map(accounts.filter((a) => a.active !== false).map((a) => [a.accountNo, a]));
  for (const [accountNo, row] of Object.entries(schedule)) {
    if (!row.dr && !row.cr) continue;
    const account = available.get(accountNo);
    if (!account) blockers.push(`Account ${accountNo} is missing or inactive in this entity's chart.`);
    else if (!['Asset', 'Liability', 'Equity'].includes(account.type)) blockers.push(`Account ${accountNo} is not a balance-sheet account; opening cut-over cannot carry profit-and-loss balances.`);
  }
  return blockers;
}
