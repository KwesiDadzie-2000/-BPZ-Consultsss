/**
 * Native calculators for regulated Ghanaian industries.
 *
 * These replace "post a journal of a number computed outside the system" for:
 *  · mineral royalties (Minerals Commission / L.I. 2588 sliding scale);
 *  · petroleum royalty & additional oil entitlement;
 *  · NPA / ESLA fuel-station levies (per litre);
 *  · IFRS 9 effective-interest amortised-cost loans (banks & microfinance);
 *  · staged ECL (IFRS 9 stages 1–3) on those loans;
 *  · IFRS 17 Premium Allocation Approach (and a simplified GMM CSM roll);
 *  · IAS 26 pension-fund NAV;
 *  · IAS 41 biological-asset fair-value movement;
 *  · manufacturing material-requirements planning from the BOM.
 *
 * Every money figure is rounded to two decimal places (pesewas). Rates are
 * parameters so a GRA / Minerals Commission / NPA instrument change is a
 * settings edit, not a code change. Proposed journals go through the same
 * posting controls as every other desk.
 */
import { money } from './trading';

export const r2 = (n: number) => money(Number.isFinite(n) ? n : 0);

/* =============================================================================
 * 1. Mineral royalties — Ghana L.I. 2588 sliding scale (gold) + 5% other minerals
 * ========================================================================== */

export interface GoldRoyaltyBand {
  upToUsdPerOz: number | null;
  ratePct: number;
}

/** L.I. 2588 (2023) gold royalty bands — the instrument in force as understood in 2026. */
export const GOLD_ROYALTY_BANDS_LI2588: GoldRoyaltyBand[] = [
  { upToUsdPerOz: 1300, ratePct: 3.0 },
  { upToUsdPerOz: 1449.99, ratePct: 3.5 },
  { upToUsdPerOz: 2299.99, ratePct: 4.0 },
  { upToUsdPerOz: 2549.99, ratePct: 4.5 },
  { upToUsdPerOz: null, ratePct: 5.0 },
];

export function goldRoyaltyRate(usdPerOz: number, bands: GoldRoyaltyBand[] = GOLD_ROYALTY_BANDS_LI2588): number {
  const price = Math.max(0, usdPerOz);
  for (const b of bands) {
    if (b.upToUsdPerOz === null || price <= b.upToUsdPerOz) return b.ratePct;
  }
  return bands[bands.length - 1]?.ratePct ?? 5;
}

export interface MineralRoyaltyInput {
  mineral: 'gold' | 'bauxite' | 'manganese' | 'lithium' | 'other';
  /** Gross revenue in entity currency (the royalty base). */
  grossRevenue: number;
  /** Benchmark price (USD/oz for gold; ignored for flat-rate minerals). */
  usdPerOz?: number;
  /** Override rate %; when omitted, the statutory rate is used. */
  ratePct?: number;
  ounces?: number;
}

export interface MineralRoyaltyResult {
  mineral: string;
  ratePct: number;
  base: number;
  royalty: number;
  basis: string;
  bandsApplied?: GoldRoyaltyBand[];
}

export function computeMineralRoyalty(input: MineralRoyaltyInput): MineralRoyaltyResult {
  const base = r2(Math.max(0, input.grossRevenue));
  if (input.mineral === 'gold') {
    const rate = input.ratePct ?? goldRoyaltyRate(input.usdPerOz ?? 0);
    return {
      mineral: 'gold',
      ratePct: rate,
      base,
      royalty: r2(base * rate / 100),
      basis: `L.I. 2588 sliding scale at USD ${r2(input.usdPerOz ?? 0)}/oz → ${rate}% of gross revenue`,
      bandsApplied: GOLD_ROYALTY_BANDS_LI2588,
    };
  }
  const rate = input.ratePct ?? 5;
  return {
    mineral: input.mineral,
    ratePct: rate,
    base,
    royalty: r2(base * rate / 100),
    basis: `Minerals and Mining Act — ${rate}% of gross revenue (${input.mineral})`,
  };
}

/* =============================================================================
 * 2. Petroleum royalty (upstream) — typically 5% of gross production value
 * ========================================================================== */

export interface PetroleumRoyaltyInput {
  grossProductionValue: number;
  royaltyRatePct: number;
  additionalOilEntitlementPct: number;
}

export function computePetroleumRoyalty(input: PetroleumRoyaltyInput) {
  const base = r2(Math.max(0, input.grossProductionValue));
  const royalty = r2(base * Math.max(0, input.royaltyRatePct) / 100);
  const aoe = r2(base * Math.max(0, input.additionalOilEntitlementPct) / 100);
  return { base, royalty, additionalOilEntitlement: aoe, totalStateTake: r2(royalty + aoe) };
}

/* =============================================================================
 * 3. NPA / ESLA fuel-station levies — per litre, posted as a payable
 * ========================================================================== */

export interface FuelLevyComponent {
  code: string;
  label: string;
  /** GHS per litre. */
  ratePerLitre: number;
}

/** 2026 working defaults — override from NPA price build-up before filing. */
export const DEFAULT_FUEL_LEVIES: FuelLevyComponent[] = [
  { code: 'EDRL', label: 'Energy Debt Recovery Levy', ratePerLitre: 0.49 },
  { code: 'PSRL', label: 'Price Stabilisation & Recovery Levy', ratePerLitre: 0.16 },
  { code: 'ROAD', label: 'Road Fund Levy', ratePerLitre: 0.46 },
  { code: 'ENF', label: 'Energy Fund Levy', ratePerLitre: 0.05 },
  { code: 'SPL', label: 'Sanitation & Pollution Levy', ratePerLitre: 0.10 },
  { code: 'UPPF', label: 'Unified Petroleum Price Fund', ratePerLitre: 0.08 },
];

export function computeFuelLevies(litres: number, components: FuelLevyComponent[] = DEFAULT_FUEL_LEVIES) {
  const volume = Math.max(0, litres);
  const lines = components.map((c) => ({
    ...c,
    amount: r2(volume * Math.max(0, c.ratePerLitre)),
  }));
  const total = r2(lines.reduce((s, l) => s + l.amount, 0));
  return { litres: volume, lines, total };
}

/* =============================================================================
 * 4. IFRS 9 effective interest — amortised-cost loans (banks / microfinance)
 * ========================================================================== */

export interface EirLoanInput {
  id: string;
  borrower: string;
  /** Gross amount advanced. */
  principal: number;
  /** Fees / transaction costs that form part of EIR (reduce net carrying at t0). */
  feesNet: number;
  annualContractualRatePct: number;
  termMonths: number;
  paymentsPerYear: 12 | 4 | 1;
  startDate: string;
  /** 12-month PD (stage 1). */
  pd12Pct: number;
  /** Lifetime PD (stage 2 / 3). */
  pdLifetimePct: number;
  lgdPct: number;
  stage: 1 | 2 | 3;
}

export interface EirPeriod {
  n: number;
  date: string;
  opening: number;
  interest: number;
  instalment: number;
  closing: number;
  ecl: number;
  carryingNetOfEcl: number;
}

/** Solve EIR so PV of contractual instalments equals net amount advanced. */
export function solveEffectiveRate(netAdvanced: number, instalment: number, n: number): number {
  if (n <= 0 || instalment <= 0 || netAdvanced <= 0) return 0;
  let lo = 0;
  let hi = 1; // 100% per period
  const pv = (r: number) => {
    if (r === 0) return instalment * n;
    let s = 0;
    const g = 1 + r;
    let d = g;
    for (let t = 1; t <= n; t += 1) {
      s += instalment / d;
      d *= g;
    }
    return s;
  };
  // Expand upper bound if needed.
  while (pv(hi) > netAdvanced && hi < 5) hi *= 2;
  for (let i = 0; i < 60; i += 1) {
    const mid = (lo + hi) / 2;
    if (pv(mid) > netAdvanced) lo = mid;
    else hi = mid;
  }
  return (lo + hi) / 2;
}

export function contractualInstalment(principal: number, annualRatePct: number, n: number, ppy: number): number {
  const r = annualRatePct / 100 / ppy;
  if (r === 0) return r2(principal / n);
  const f = Math.pow(1 + r, n);
  return r2((principal * r * f) / (f - 1));
}

export function buildEirSchedule(loan: EirLoanInput): { eirPerPeriod: number; eirAnnualPct: number; instalment: number; rows: EirPeriod[] } {
  const ppy = loan.paymentsPerYear;
  const n = Math.max(1, Math.round(loan.termMonths * ppy / 12));
  const instalment = contractualInstalment(loan.principal, loan.annualContractualRatePct, n, ppy);
  const netAdvanced = r2(Math.max(0.01, loan.principal - loan.feesNet));
  const eir = solveEffectiveRate(netAdvanced, instalment, n);
  const rows: EirPeriod[] = [];
  let carrying = netAdvanced;
  const start = loan.startDate.slice(0, 7);
  const step = 12 / ppy;
  const pd = (loan.stage === 1 ? loan.pd12Pct : loan.pdLifetimePct) / 100;
  const lgd = Math.max(0, loan.lgdPct) / 100;
  for (let i = 1; i <= n; i += 1) {
    const interest = r2(carrying * eir);
    const isLast = i === n;
    const prin = isLast ? carrying : Math.min(carrying, r2(instalment - interest));
    const paid = r2(interest + prin);
    const closing = r2(carrying + interest - paid);
    const ecl = r2(closing * pd * lgd);
    const [y, m] = start.split('-').map(Number);
    const dt = new Date(Date.UTC(y, m - 1 + Math.round(i * step), 0));
    const date = dt.toISOString().slice(0, 10);
    rows.push({
      n: i,
      date,
      opening: carrying,
      interest,
      instalment: paid,
      closing,
      ecl,
      carryingNetOfEcl: r2(closing - ecl),
    });
    carrying = closing;
    if (carrying <= 0.009) break;
  }
  return { eirPerPeriod: eir, eirAnnualPct: r2(eir * ppy * 100), instalment, rows };
}

/* =============================================================================
 * 5. IFRS 17 — Premium Allocation Approach (contracts ≤ 12 months) + CSM roll
 * ========================================================================== */

export interface Ifrs17PaaInput {
  id: string;
  product: string;
  coverageStart: string;
  coverageEnd: string;
  premiumsReceived: number;
  acquisitionCosts: number;
  expectedClaims: number;
  actualClaims: number;
  riskAdjustment: number;
  /** 0–1 portion of coverage elapsed this period. */
  coverageElapsedPct: number;
  onerous: boolean;
}

export interface Ifrs17PaaResult {
  lrc: number;
  lic: number;
  insuranceRevenue: number;
  insuranceServiceExpense: number;
  lossComponent: number;
  netResult: number;
}

export function computeIfrs17Paa(input: Ifrs17PaaInput): Ifrs17PaaResult {
  const elapsed = Math.min(1, Math.max(0, input.coverageElapsedPct));
  const premiums = r2(Math.max(0, input.premiumsReceived));
  const acq = r2(Math.max(0, input.acquisitionCosts));
  const expected = r2(Math.max(0, input.expectedClaims));
  const actual = r2(Math.max(0, input.actualClaims));
  const ra = r2(Math.max(0, input.riskAdjustment));
  const insuranceRevenue = r2(premiums * elapsed);
  const remainingPremium = r2(premiums - insuranceRevenue);
  const remainingAcq = r2(acq * (1 - elapsed));
  const lrc = r2(Math.max(0, remainingPremium - remainingAcq));
  const lic = r2(actual + ra);
  const serviceExpense = r2(actual + r2(acq * elapsed));
  const lossComponent = input.onerous ? r2(Math.max(0, expected - (premiums - acq))) : 0;
  return {
    lrc: r2(lrc + lossComponent),
    lic,
    insuranceRevenue,
    insuranceServiceExpense: r2(serviceExpense + lossComponent),
    lossComponent,
    netResult: r2(insuranceRevenue - serviceExpense - lossComponent),
  };
}

export interface Ifrs17GmmInput {
  fulfilmentCashFlows: number;
  riskAdjustment: number;
  csmOpening: number;
  coverageUnitsThisPeriod: number;
  coverageUnitsRemaining: number;
  financeRatePct: number;
}

export function computeIfrs17Gmm(input: Ifrs17GmmInput) {
  const fcf = r2(input.fulfilmentCashFlows);
  const ra = r2(input.riskAdjustment);
  const opening = r2(input.csmOpening);
  const unitsThis = Math.max(0, input.coverageUnitsThisPeriod);
  const unitsLeft = Math.max(0, input.coverageUnitsRemaining);
  const totalUnits = unitsThis + unitsLeft;
  const unwind = r2(opening * Math.max(0, input.financeRatePct) / 100);
  const csmBeforeRelease = r2(opening + unwind);
  const release = totalUnits > 0 ? r2(csmBeforeRelease * (unitsThis / totalUnits)) : 0;
  const csmClosing = r2(csmBeforeRelease - release);
  const liability = r2(fcf + ra + csmClosing);
  return { csmOpening: opening, financeUnwind: unwind, csmRelease: release, csmClosing, liability, insuranceRevenueFromCsm: release };
}

/* =============================================================================
 * 6. IAS 26 pension-fund NAV
 * ========================================================================== */

export interface PensionMemberInput {
  id: string;
  name: string;
  units: number;
  employeeContribution: number;
  employerContribution: number;
}

export function computePensionNav(
  members: PensionMemberInput[],
  investmentFv: number,
  otherAssets: number,
  payables: number,
) {
  const contributions = r2(members.reduce((s, m) => s + m.employeeContribution + m.employerContribution, 0));
  const units = members.reduce((s, m) => s + m.units, 0);
  const assets = r2(investmentFv + otherAssets);
  const nav = r2(assets - payables);
  const unitPrice = units > 0 ? r2(nav / units) : 0;
  return { contributions, units: r2(units), assets, payables: r2(payables), nav, unitPrice };
}

/* =============================================================================
 * 7. IAS 41 biological assets
 * ========================================================================== */

export function computeBiologicalMovement(openingFv: number, additions: number, harvestAtFv: number, closingFv: number, costsToSell: number) {
  const opening = r2(openingFv);
  const add = r2(additions);
  const harvest = r2(harvestAtFv);
  const closing = r2(closingFv);
  const cts = r2(Math.max(0, costsToSell));
  const fvLessCtsClosing = r2(closing - cts);
  const fairValueGain = r2(fvLessCtsClosing - (opening + add - harvest));
  return { opening, additions: add, harvest, closing: fvLessCtsClosing, fairValueGain };
}

/* =============================================================================
 * 8. Manufacturing MRP — BOM explosion vs on-hand
 * ========================================================================== */

export interface BomLine {
  parentItemCode: string;
  componentItemCode: string;
  qtyPerUnit: number;
  wastePct: number;
}

export interface StockOnHand {
  itemCode: string;
  quantityOnHand: number;
}

export function explodeMrp(parentItemCode: string, qty: number, boms: BomLine[], stock: StockOnHand[]) {
  const onHand = (code: string) => stock.find((s) => s.itemCode === code)?.quantityOnHand ?? 0;
  const lines = boms
    .filter((b) => b.parentItemCode === parentItemCode)
    .map((b) => {
      const required = r2(qty * b.qtyPerUnit * (1 + Math.max(0, b.wastePct) / 100));
      const available = onHand(b.componentItemCode);
      const shortage = r2(Math.max(0, required - available));
      return {
        componentItemCode: b.componentItemCode,
        required,
        available: r2(available),
        shortage,
        status: shortage > 0.0005 ? 'short' as const : 'covered' as const,
      };
    });
  return { parentItemCode, qty, lines, allCovered: lines.every((l) => l.status === 'covered') };
}
