import type { ACDOCALine, AccountMaster } from '../types/accounting';
import { GHANA_ECONOMY_SECTORS } from '../data/ghanaSectors';
import { docSuffix, uniqueId } from './ids';

/**
 * Shared, ledger-derived reporting engine for the BPZ Consult ERP.
 * Every figure is computed strictly from posted journal lines — no hard-coded amounts.
 */

export const CASH_ACCOUNTS = ['100000', '101000', '102000', '103000', '104000'];

/** Non-cash expenses added back in the IAS 7 indirect operating section. */
const ADD_BACK_EXPENSE = ['600000', '610000', '611000', '612000', '680000', '690000', '698000', '731000'];
/** Non-cash credit movements added back (provision increases). */
const ADD_BACK_CREDIT = ['240000', '270000', '271000'];
/** Gains on disposal removed from operating (presented in investing). */
const REMOVE_GAIN = ['492000'];
/** Working-capital asset groups (debit-normal). */
const RECEIVABLE_ACCOUNTS = ['110000', '111000', '112000', '113000', '114000', '115000', '118000', '141000'];
const INVENTORY_ACCOUNTS = ['120000', '121000', '122000', '123000', '124000'];
const PREPAID_ACCOUNTS = ['116000'];
/** Working-capital liability groups (credit-normal). */
const PAYABLE_ACCOUNTS = ['200000', '201000', '202000', '203000', '205000', '206000', '206100', '207000', '208000', '209000', '212000', '220000', '221000', '223000', '224000'];
/** Investing (debit-normal non-current assets). */
const INVESTING_ACCOUNTS = ['130000', '131000', '132000', '133000', '134000', '135000', '136000', '142000', '143000', '144000', '150000', '152000', '160000', '161000', '162000', '180000'];
/** Financing (credit-normal borrowings, leases, equity, dividends payable). */
const FINANCING_ACCOUNTS = ['210000', '211000', '226000', '230000', '250000', '300000', '301000', '311000', '313000'];

const toMinor = (n: number) => Math.round(n * 100);
const toMajor = (minor: number) => Math.round(minor) / 100;
const inCents = (n: number) => Math.round(n * 100) / 100; // round to 2dp in major units

export const classifyAccount = (accounts: AccountMaster[], code: string): AccountMaster['type'] => {
  const master = accounts.find((a) => a.accountNo === code);
  if (master) return master.type;
  return code.startsWith('1') ? 'Asset'
    : code.startsWith('2') ? 'Liability'
    : code.startsWith('3') ? 'Equity'
    : code.startsWith('4') ? 'Income' : 'Expense';
};

export interface TbRow {
  code: string;
  name: string;
  type: AccountMaster['type'];
  dr: number;
  cr: number;
}

/** Aggregates journal lines into trial-balance rows (amounts in major units). */
export function aggregateTrialBalance(lines: ACDOCALine[], accounts: AccountMaster[]): TbRow[] {
  const map = new Map<string, TbRow>();
  for (const l of lines) {
    const row = map.get(l.accountNo) ?? {
      code: l.accountNo,
      name: accounts.find((a) => a.accountNo === l.accountNo)?.name || l.accountName,
      type: classifyAccount(accounts, l.accountNo),
      dr: 0,
      cr: 0,
    };
    row.dr += toMinor(l.debit);
    row.cr += toMinor(l.credit);
    map.set(l.accountNo, row);
  }
  return [...map.values()].sort((a, b) => a.code.localeCompare(b.code));
}

const netDrCr = (lines: ACDOCALine[], accountNos: string[]): number =>
  toMajor(lines.filter((l) => accountNos.includes(l.accountNo)).reduce((n, l) => n + toMinor(l.debit) - toMinor(l.credit), 0));

const netCrDr = (lines: ACDOCALine[], accountNos: string[]): number =>
  toMajor(lines.filter((l) => accountNos.includes(l.accountNo)).reduce((n, l) => n + toMinor(l.credit) - toMinor(l.debit), 0));

const profitOf = (lines: ACDOCALine[], accounts: AccountMaster[]): number => {
  const rows = aggregateTrialBalance(lines, accounts);
  // Profit = income - expenses = -(sum of P&L debit-minus-credit), rows are in minor units.
  return toMajor(rows
    .filter((r) => r.type === 'Income' || r.type === 'Expense')
    .reduce((n, r) => n - (r.dr - r.cr), 0));
};

export interface CashFlowStatement {
  profitBeforeTax: number;
  addBacks: number;
  removeGains: number;
  deltaReceivables: number;
  deltaInventory: number;
  deltaPrepaids: number;
  deltaPayables: number;
  operating: number;
  investing: number;
  financing: number;
  netChange: number;
  openingCash: number;
  closingCash: number;
  cashMovement: number;
  residual: number;
}

/**
 * IAS 7 indirect-method statement of cash flows derived from the posted journal.
 * `residual` must equal zero — it proves the classification covers every movement.
 */
export function buildCashFlow(lines: ACDOCALine[], accounts: AccountMaster[], from: string, through: string): CashFlowStatement {
  const scoped = lines.filter((l) => l.date <= through);
  const movement = scoped.filter((l) => l.date >= from);
  const prior = scoped.filter((l) => l.date < from);

  const profitBeforeTax = profitOf(movement, accounts);
  const addBacks = netDrCr(movement, ADD_BACK_EXPENSE) + netCrDr(movement, ADD_BACK_CREDIT);
  const removeGains = netCrDr(movement, REMOVE_GAIN);

  // Working-capital movements = closing balance minus opening balance per group.
  const deltaOf = (group: string[], crNormal: boolean) => {
    const closing = crNormal ? netCrDr(scoped, group) : netDrCr(scoped, group);
    const opening = crNormal ? netCrDr(prior, group) : netDrCr(prior, group);
    return inCents(closing - opening);
  };
  const dReceivables = deltaOf(RECEIVABLE_ACCOUNTS, false);
  const dInventory = deltaOf(INVENTORY_ACCOUNTS, false);
  const dPrepaids = deltaOf(PREPAID_ACCOUNTS, false);
  const dPayables = deltaOf(PAYABLE_ACCOUNTS, true);

  const operating = inCents(profitBeforeTax + addBacks - removeGains - dReceivables - dInventory - dPrepaids + dPayables);
  const investing = inCents(-deltaOf(INVESTING_ACCOUNTS, false));
  const financing = inCents(deltaOf(FINANCING_ACCOUNTS, true));
  const netChange = inCents(operating + investing + financing);

  const openingCash = netDrCr(prior, CASH_ACCOUNTS);
  const closingCash = netDrCr(scoped, CASH_ACCOUNTS);
  const cashMovement = inCents(closingCash - openingCash);
  const residual = inCents(cashMovement - netChange);
  return {
    profitBeforeTax, addBacks, removeGains,
    deltaReceivables: dReceivables, deltaInventory: dInventory, deltaPrepaids: dPrepaids, deltaPayables: dPayables,
    operating, investing, financing, netChange,
    openingCash, closingCash, cashMovement, residual,
  };
}

export interface AgingBuckets {
  current: number;
  days31to60: number;
  days61to90: number;
  over90: number;
  total: number;
  overdueCount: number;
}

const dayMs = 86400000;
/** Ages open items into 30-day buckets as at a date (30-day credit terms assumed). */
export function ageIntoBuckets(asOf: string, items: { date: string; amount: number }[]): AgingBuckets {
  const asOfMs = new Date(`${asOf}T00:00:00.000Z`).getTime();
  const buckets = { current: 0, days31to60: 0, days61to90: 0, over90: 0, total: 0, overdueCount: 0 };
  for (const item of items) {
    const age = Math.max(0, Math.floor((asOfMs - new Date(`${item.date}T00:00:00.000Z`).getTime()) / dayMs));
    buckets.total = inCents(buckets.total + item.amount);
    if (age > 90) buckets.over90 = inCents(buckets.over90 + item.amount);
    else if (age > 60) buckets.days61to90 = inCents(buckets.days61to90 + item.amount);
    else if (age > 30) buckets.days31to60 = inCents(buckets.days31to60 + item.amount);
    else buckets.current = inCents(buckets.current + item.amount);
    if (age > 30) buckets.overdueCount += 1;
  }
  return buckets;
}

/** Maps a client sector description to the CIT rate of the matching Ghanaian sector. */
export function sectorCitRate(sector: string): { rate: number; sectorName: string } {
  const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter((w) => w.length > 3 && !['with', 'from', 'other'].includes(w));
  const clientWords = new Set(normalize(sector));
  let best: { rate: number; sectorName: string; score: number } = { rate: 25, sectorName: 'General commerce & services (standard CIT)', score: 0 };
  for (const def of GHANA_ECONOMY_SECTORS) {
    const score = normalize(def.name).filter((w) => clientWords.has(w)).length;
    if (score > best.score) best = { rate: def.citRate, sectorName: def.name, score };
  }
  return { rate: best.rate, sectorName: best.sectorName };
}

/** CIT working paper: gross CIT on taxable profit less WHT credits already withheld. */
export function computeCit(profitBeforeTax: number, citRatePct: number, whtCredits: number) {
  const taxableProfit = Math.max(0, inCents(profitBeforeTax));
  const grossCit = inCents(taxableProfit * citRatePct / 100);
  const netPayable = inCents(Math.max(0, grossCit - Math.max(0, whtCredits)));
  return { taxableProfit, citRatePct, grossCit, whtCredits: Math.max(0, inCents(whtCredits)), netPayable };
}

export interface FxRevaluationRow {
  accountNo: string;
  accountName: string;
  fcyBalance: number;
  bookRate: number;
  closingRate: number;
  revaluedGhs: number;
  gainLoss: number; // positive = gain
}

/**
 * IAS 21 unrealised FX revaluation of foreign-currency monetary items in the journal.
 * gain/loss (GHS) = FCY net balance x (closing rate - book rate).
 */
/**
 * IAS 21.23: only MONETARY items are retranslated at the closing rate. Property,
 * plant and equipment (13xxxx), inventories (12xxxx), right-of-use and intangible
 * assets (15xxxx), equity and the income statement are measured at historical
 * cost or fair value and are never retranslated — an "unrealised FX gain" booked
 * to PPE cost is a misstatement, not a valuation. Unknown accounts are skipped:
 * the engine must never invent a revaluation on an account it cannot classify.
 */
const FX_NON_MONETARY_TYPES = new Set(['Income', 'Expense', 'Equity']);
const FX_NON_MONETARY_PREFIXES = ['12', '13', '15'];
export function isMonetaryForFx(account: AccountMaster | undefined): boolean {
  if (!account) return false;
  if (FX_NON_MONETARY_TYPES.has(account.type)) return false;
  if (FX_NON_MONETARY_PREFIXES.includes(account.accountNo.slice(0, 2))) return false;
  return account.type === 'Asset' || account.type === 'Liability';
}

export function buildFxRevaluation(
  lines: ACDOCALine[],
  accounts: AccountMaster[],
  ccy: string,
  bookRate: number,
  closingRate: number
): FxRevaluationRow[] {
  const fcyLines = lines.filter((l) => l.currency === ccy);
  const byAccount = new Map<string, number>();
  for (const l of fcyLines) {
    if (!isMonetaryForFx(accounts.find((a) => a.accountNo === l.accountNo))) continue;
    byAccount.set(l.accountNo, inCents((byAccount.get(l.accountNo) ?? 0) + l.debit - l.credit));
  }
  const rows: FxRevaluationRow[] = [];
  for (const [accountNo, fcyBalance] of [...byAccount.entries()].sort()) {
    if (Math.abs(fcyBalance) < 0.005) continue;
    const gainLoss = inCents(fcyBalance * (closingRate - bookRate));
    rows.push({
      accountNo,
      accountName: accounts.find((a) => a.accountNo === accountNo)?.name || accountNo,
      fcyBalance,
      bookRate,
      closingRate,
      revaluedGhs: inCents(fcyBalance * closingRate),
      gainLoss,
    });
  }
  return rows;
}

export interface StatementLine {
  date: string;
  description: string;
  debit: number;
  credit: number;
}

export interface StatementMatchResult {
  line: StatementLine;
  matched: boolean;
  matchedDocNo?: string;
}

/**
 * Matches imported bank statement lines to posted journal cash lines:
 * same account, same direction and amount, within a 3-day value-date window.
 */
export function matchStatementLines(statement: StatementLine[], journalLines: ACDOCALine[], glAccount: string): StatementMatchResult[] {
  const pool = journalLines.filter((l) => l.accountNo === glAccount && !l.isReversed);
  const used = new Set<string>();
  return statement.map((s) => {
    const hit = pool.find((l) => {
      if (used.has(l.id)) return false;
      const amount = s.debit > 0 ? l.debit : l.credit;
      const stmtAmount = s.debit > 0 ? s.debit : s.credit;
      if (Math.abs(amount - stmtAmount) > 0.009) return false;
      if (s.debit > 0 && l.debit <= 0) return false;
      if (s.credit > 0 && l.credit <= 0) return false;
      const days = Math.abs(new Date(`${s.date}T00:00:00.000Z`).getTime() - new Date(`${l.date}T00:00:00.000Z`).getTime()) / dayMs;
      return days <= 3;
    });
    if (hit) used.add(hit.id);
    return { line: s, matched: !!hit, matchedDocNo: hit?.docNo };
  });
}

/** Builds the balanced disposal journal for a fixed asset (IAS 16 derecognition). */
export function buildDisposalEntries(
  asset: { assetTag: string; name: string; cost: number; accumDep: number },
  proceeds: number,
  date: string,
  currency: string,
  clientId: number,
  createdBy: string
): ACDOCALine[] {
  const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
  const period = date.slice(0, 7);
  const docNo = `DISP-${asset.assetTag}-${docSuffix()}`;
  const nbv = round2(asset.cost - asset.accumDep);
  const gain = round2(proceeds - nbv);
  const entries: ACDOCALine[] = [
    { id: `${uniqueId('JL-DISP')}-1`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '100000', accountName: 'Cash at Bank (Operating)', costCenter: 'CC-OPS', debit: round2(proceeds), credit: 0, currency, description: `Disposal proceeds ${asset.assetTag}`, createdBy, clientId },
    { id: `${uniqueId('JL-DISP')}-2`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '130000', accountName: `PPE — ${asset.name}`, costCenter: 'CC-OPS', debit: 0, credit: round2(asset.cost), currency, description: `Cost of disposed asset ${asset.assetTag}`, createdBy, clientId },
  ];
  if (asset.accumDep > 0) entries.push({ id: `${uniqueId('JL-DISP')}-3`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '139000', accountName: 'Accumulated Depreciation — PPE', costCenter: 'CC-OPS', debit: round2(asset.accumDep), credit: 0, currency, description: `Accumulated depreciation reversal ${asset.assetTag}`, createdBy, clientId });
  if (gain > 0) entries.push({ id: `${uniqueId('JL-DISP')}-4`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '492000', accountName: 'Gain on Disposal of PPE', costCenter: 'CC-OPS', debit: 0, credit: gain, currency, description: `Gain on disposal ${asset.assetTag}`, createdBy, clientId });
  if (gain < 0) entries.push({ id: `${uniqueId('JL-DISP')}-4`, docNo, period, date, module: 'FI-AA', docType: 'STAT', accountNo: '698000', accountName: 'Loss on Disposal of PPE', costCenter: 'CC-OPS', debit: round2(-gain), credit: 0, currency, description: `Loss on disposal ${asset.assetTag}`, createdBy, clientId });
  return entries;
}

/** Builds the balanced debit-note (purchase return) journal reversing a purchase order. */
export function buildDebitNoteEntries(
  po: { poNo: string; vendorName: string; glAccount: string; glAccountName: string; costCenter: string; netAmount?: number; qty: number; unitPrice: number; vatRecoverable: number; totalAmount: number },
  date: string,
  currency: string,
  clientId: number,
  createdBy: string
): ACDOCALine[] {
  const period = date.slice(0, 7);
  const docNo = `DN-${po.poNo.replace('PO-', '')}-${docSuffix()}`;
  const net = po.netAmount ?? Math.round((po.qty * po.unitPrice) * 100) / 100;
  const entries: ACDOCALine[] = [
    { id: `${uniqueId('JL-DN')}-1`, docNo, period, date, module: 'MM', docType: 'REV', accountNo: '200000', accountName: `Trade Payables (${po.vendorName})`, costCenter: po.costCenter, debit: po.totalAmount, credit: 0, currency, description: `Debit note for ${po.poNo} — payable reversal`, createdBy, clientId },
    { id: `${uniqueId('JL-DN')}-2`, docNo, period, date, module: 'MM', docType: 'REV', accountNo: po.glAccount, accountName: po.glAccountName, costCenter: po.costCenter, debit: 0, credit: net, currency, description: `Debit note for ${po.poNo} — ${po.glAccountName} reversal`, createdBy, clientId },
  ];
  if (po.vatRecoverable > 0) entries.push({ id: `${uniqueId('JL-DN')}-3`, docNo, period, date, module: 'MM', docType: 'REV', accountNo: '125000', accountName: 'VAT Input Tax Recoverable', costCenter: po.costCenter, debit: 0, credit: po.vatRecoverable, currency, description: `Input VAT reversal on ${po.poNo}`, createdBy, clientId });
  return entries;
}

export interface CostCentreRow {
  code: string;
  income: number;
  expense: number;
  net: number;
}

export interface CostCentreReport {
  rows: CostCentreRow[];
  totalIncome: number;
  totalExpense: number;
  totalNet: number;
  profit: number;
  residual: number;
}

/** P&L by cost centre for the entity's movement window, derived from posted lines. */
export function buildCostCentreReport(lines: ACDOCALine[], accounts: AccountMaster[], from: string, through: string): CostCentreReport {
  const scoped = lines.filter((l) => l.date >= from && l.date <= through);
  const rows = aggregateTrialBalance(scoped, accounts).filter((r) => r.type === 'Income' || r.type === 'Expense');
  const byCc = new Map<string, CostCentreRow>();
  for (const l of scoped) {
    const type = classifyAccount(accounts, l.accountNo);
    if (type !== 'Income' && type !== 'Expense') continue;
    const code = l.costCenter || 'UNASSIGNED';
    const row = byCc.get(code) ?? { code, income: 0, expense: 0, net: 0 };
    const amount = Math.round((l.credit - l.debit) * 100) / 100;
    if (type === 'Income') row.income = Math.round((row.income + amount) * 100) / 100;
    else row.expense = Math.round((row.expense - amount) * 100) / 100;
    row.net = Math.round((row.income - row.expense) * 100) / 100;
    byCc.set(code, row);
  }
  const sorted = [...byCc.values()].sort((a, b) => a.code.localeCompare(b.code));
  const totalIncome = Math.round(sorted.reduce((n, r) => n + r.income, 0) * 100) / 100;
  const totalExpense = Math.round(sorted.reduce((n, r) => n + r.expense, 0) * 100) / 100;
  const totalNet = Math.round((totalIncome - totalExpense) * 100) / 100;
  const profit = rows.reduce((n, r) => n - (r.dr - r.cr), 0) / 100;
  return { rows: sorted, totalIncome, totalExpense, totalNet, profit, residual: Math.round((totalNet - profit) * 100) / 100 };
}

/** Builds the balanced credit-note (sales return) journal reversing an invoice. */
export function buildCreditNoteEntries(
  inv: { invNo: string; customerName: string; revenueStream: string; netRevenue: number; vatOutput: number; cstAmount?: number; tourismLevyAmount?: number; totalReceivable: number },
  date: string,
  currency: string,
  clientId: number,
  createdBy: string
): ACDOCALine[] {
  const period = date.slice(0, 7);
  const docNo = `CN-${inv.invNo.replace('INV-', '')}-${docSuffix()}`;
  const entries: ACDOCALine[] = [
    { id: `${uniqueId('JL-CN')}-1`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '400000', accountName: 'Revenue from Contracts with Customers', costCenter: 'CC-SLS', debit: inv.netRevenue, credit: 0, currency, description: `Credit note for ${inv.invNo} — revenue reversal`, createdBy, clientId },
    { id: `${uniqueId('JL-CN')}-2`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '110000', accountName: `Trade Receivables (${inv.customerName})`, costCenter: 'CC-SLS', debit: 0, credit: inv.totalReceivable, currency, description: `Credit note for ${inv.invNo} (${inv.revenueStream})`, createdBy, clientId },
  ];
  if (inv.vatOutput > 0) entries.push({ id: `${uniqueId('JL-CN')}-3`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '220000', accountName: 'VAT/NHIL/GETFund Output Liability', costCenter: 'CC-SLS', debit: inv.vatOutput, credit: 0, currency, description: `Output VAT reversal on ${inv.invNo}`, createdBy, clientId });
  if ((inv.cstAmount || 0) > 0) entries.push({ id: `${uniqueId('JL-CN')}-4`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '223000', accountName: 'Communication Service Tax Payable', costCenter: 'CC-SLS', debit: inv.cstAmount || 0, credit: 0, currency, description: `CST reversal on ${inv.invNo}`, createdBy, clientId });
  if ((inv.tourismLevyAmount || 0) > 0) entries.push({ id: `${uniqueId('JL-CN')}-5`, docNo, period, date, module: 'SD', docType: 'REV', accountNo: '224000', accountName: 'Tourism Levy Payable', costCenter: 'CC-SLS', debit: inv.tourismLevyAmount || 0, credit: 0, currency, description: `Tourism levy reversal on ${inv.invNo}`, createdBy, clientId });
  return entries;
}

/** Parses a bank statement CSV: Date,Description,Debit,Credit (header optional). */
export function parseStatementCsv(text: string): StatementLine[] {
  const rows = text.split(/\r?\n/).map((r) => r.trim()).filter(Boolean);
  const out: StatementLine[] = [];
  for (const row of rows) {
    const cols = row.split(',').map((c) => c.trim().replace(/^"|"$/g, ''));
    if (cols.length < 4) continue;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(cols[0])) continue; // skip header
    const debit = Number(cols[2]) || 0;
    const credit = Number(cols[3]) || 0;
    if (debit < 0 || credit < 0) continue;
    out.push({ date: cols[0], description: cols[1], debit, credit });
  }
  return out;
}
