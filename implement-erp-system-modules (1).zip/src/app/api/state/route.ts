import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import {
  approvalRequests,
  auditLog,
  bankAccounts,
  businessPartners,
  chartAccounts,
  closedPeriods,
  clients,
  companyProfiles,
  disclosureNotes,
  employees,
  journalHeaders,
  journalLines,
  postingEvents,
  payrollRecords,
  prepaymentRecords,
  prepaymentSchedules,
  purchaseOrders,
  salesInvoices,
  stockItems,
  stockMovements,
  fixedAssets,
  taxScheduleEntries,
} from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope } from "@/lib/auth";
import { sameJournalLines, validateJournalLines } from "@/lib/journalValidation";
import { buildJournalHeader, buildPostingEvent } from "@/lib/journalPosting";
import { prepareBusinessPartnersForStorage } from "@/lib/businessPartnerSync";
import { eq, inArray, sql } from "drizzle-orm";
import type {
  ACDOCALine,
  AccountMaster,
  ApprovalRequest,
  BankAccount,
  BusinessPartner,
  ClientEntity,
  DisclosureNote,
  EmployeeProfile,
  MonthlyPayrollRecord,
  PrepaymentRecord,
  PrepaymentScheduleLine,
  FixedAsset,
  PurchaseOrder,
  SalesInvoice,
  StockItem,
  StockMovement,
  TaxScheduleEntry,
} from "@/types/accounting";
import type { CompanyProfile } from "@/utils/persistentStorage";

export const dynamic = "force-dynamic";

interface StatePayload {
  clients?: ClientEntity[];
  journalLines?: ACDOCALine[];
  bankAccounts?: BankAccount[];
  purchaseOrders?: PurchaseOrder[];
  salesInvoices?: SalesInvoice[];
  employees?: EmployeeProfile[];
  businessPartners?: BusinessPartner[];
  payrollRecords?: MonthlyPayrollRecord[];
  prepaymentRecords?: PrepaymentRecord[];
  prepaymentSchedules?: PrepaymentScheduleLine[];
  approvalRequests?: ApprovalRequest[];
  companyProfiles?: Record<number, CompanyProfile>;
  chartOfAccounts?: AccountMaster[];
  disclosureNotes?: DisclosureNote[];
  closedPeriods?: { clientId: number; period: string }[];
  /** Optional (older browsers may not send it); when present it is replaced tenant-scoped. */
  taxScheduleEntries?: TaxScheduleEntry[];
  /** Perpetual inventory + asset register (optional for older browsers). */
  stockItems?: StockItem[];
  stockMovements?: StockMovement[];
  fixedAssets?: FixedAsset[];
}

/**
 * Full-state sync. The server is authoritative: journal lines are validated
 * (tenant, open periods, COA existence, double entry) and the whole write is one
 * transaction. Firm-level masters (clients, COA, disclosures) are owner-writable
 * only; every operational row is tenant-filtered.
 */
export async function PUT(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    // Infrastructure fault → 503. Never 401: a 401 is what signs the user out.
    console.error("state sync: database unavailable", e);
    return authJson(req, { ok: false, error: "database-unavailable" }, { status: 503 });
  }
  try {
    return await handlePut(req);
  } catch (error) {
    const reference = crypto.randomUUID();
    const cause = error instanceof Error ? error.cause : undefined;
    const candidate = error && typeof error === "object" && "code" in error
      ? (error as { code?: unknown }).code
      : cause && typeof cause === "object" && "code" in cause
        ? (cause as { code?: unknown }).code
        : undefined;
    const code = typeof candidate === "string" ? candidate : undefined;
    console.error(`[state-sync:${reference}] ${error instanceof Error ? error.name : "UnknownError"}${code ? ` code=${code}` : ""}`);
    return Response.json({
      ok: false,
      error: `Workspace sync failed. No changes were saved. Retry the sync; if it continues, share reference ${reference}.`,
      reference,
    }, { status: 500 });
  }
}

async function handlePut(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });

  let body: StatePayload;
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }

  // Full-state sync contract: partial payloads are rejected so a sync can never
  // silently wipe datasets the caller did not include.
  const coreFields: (keyof StatePayload)[] = [
    "journalLines", "bankAccounts", "purchaseOrders", "salesInvoices", "employees",
    "businessPartners", "payrollRecords", "prepaymentRecords", "prepaymentSchedules",
    "approvalRequests", "closedPeriods", "companyProfiles",
  ];
  if (coreFields.some((f) => body[f] === undefined)) {
    return Response.json({ ok: false, error: "Partial state sync rejected — send the full workspace state." }, { status: 400 });
  }

  const isOwner = user.role === "owner";
  const firmWide = hasFirmWideScope(user);
  const myClientId = user.clientId ?? null;

  // Tenant filter: non-owners may only touch their own entity (or untagged legacy rows).
  const tenantOk = (clientId: number | undefined | null): boolean =>
    firmWide || clientId === myClientId || clientId === undefined || clientId === null;

  const lines = body.journalLines ?? [];
  const banks = body.bankAccounts ?? [];
  const pos = body.purchaseOrders ?? [];
  const invoices = body.salesInvoices ?? [];
  const emps = body.employees ?? [];
  const partners = body.businessPartners ?? [];
  const partnerPreparation = prepareBusinessPartnersForStorage(partners, firmWide ? null : myClientId);
  if (!partnerPreparation.ok) {
    return Response.json({ ok: false, error: partnerPreparation.error }, { status: partnerPreparation.status });
  }
  const storedPartners = partnerPreparation.rows;
  const payroll = body.payrollRecords ?? [];
  const prepayments = body.prepaymentRecords ?? [];
  const prepaidSchedules = body.prepaymentSchedules ?? [];
  const approvals = body.approvalRequests ?? [];
  const closed = body.closedPeriods ?? [];
  const profiles = body.companyProfiles ?? {};
  const taxEntries = body.taxScheduleEntries;
  const stock = body.stockItems;
  const movements = body.stockMovements;
  const assets = body.fixedAssets;

  if (!firmWide) {
    const rows: (number | undefined | null)[] = [
      ...lines.map((l) => l.clientId),
      ...banks.map((b) => b.clientId),
      ...pos.map((p) => p.clientId),
      ...invoices.map((i) => i.clientId),
      ...emps.map((e) => e.clientId),
      ...partners.map((p) => p.clientId),
      ...payroll.map((r) => r.clientId),
      ...prepayments.map((p) => p.clientId),
      ...prepaidSchedules.map((s) => s.clientId),
      ...approvals.map((a) => a.clientId),
      ...closed.map((c) => c.clientId),
      ...(taxEntries ?? []).map((t) => t.clientId),
      ...(stock ?? []).map((i) => i.clientId),
      ...(movements ?? []).map((m) => m.clientId),
      ...(assets ?? []).map((a) => a.clientId),
    ];
    if (rows.some((id) => !tenantOk(id))) {
      return Response.json({ ok: false, error: "Cross-tenant write rejected." }, { status: 403 });
    }
    if (Object.keys(profiles).some((id) => Number(id) !== myClientId)) {
      return Response.json({ ok: false, error: "Cross-tenant profile write rejected." }, { status: 403 });
    }
  }

  // Journal validation (tenant, periods, COA, double entry).
  const [allClients, allCoa, allClosed, allApprovals] = await Promise.all([
    db.select().from(clients),
    db.select().from(chartAccounts),
    db.select().from(closedPeriods),
    db.select().from(approvalRequests),
  ]);
  const allowedClientIds = firmWide ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
  // Periods are frozen per entity — key by client so one entity's close never blocks another.
  const closedKeys = new Set(
    allClosed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`)
  );
  // COA scope: firm master plus the writable entities' custom accounts.
  const coaNos = new Set(allCoa.filter((a) => a.clientId === null || allowedClientIds.includes(a.clientId)).map((a) => a.accountNo));
  // Duplicate document check against the server copy: documents already posted
  // are re-sent unchanged by the full-state sync; a conflict (same document
  // number, different lines) is rejected.
  const existingDocs = new Set((await db.select().from(journalLines)).map((l) => `${l.clientId}:${l.docNo}`));
  const docs = new Map<string, ACDOCALine[]>();
  for (const l of lines) {
    const key = `${l.clientId}:${l.docNo}`;
    if (!docs.has(key)) docs.set(key, []);
    docs.get(key)!.push(l);
  }
  for (const key of docs.keys()) {
    if (!existingDocs.has(key)) continue;
    const existing = (await db.select().from(journalLines).where(eq(journalLines.docNo, key.split(":")[1]))).filter((l) => l.clientId === Number(key.split(":")[0]));
    const same = sameJournalLines(existing, docs.get(key)!);
    if (!same) return Response.json({ ok: false, error: `Document ${key.split(":")[1]} already posted with different content.` }, { status: 409 });
  }

  // Journal validation applies to NEW documents only — re-sent documents are
  // already in the books, so closing one of their periods afterwards must not
  // block the workspace sync (which would make the period impossible to reopen).
  const freshKeys = new Set([...docs.keys()].filter((key) => !existingDocs.has(key)));
  const freshLines = lines.filter((l) => freshKeys.has(`${l.clientId}:${l.docNo}`));
  // An empty journal list is valid for the full-state sync (nothing to validate) —
  // "no lines" is only an error for single-document posting.
  const journalError = freshLines.length
    ? validateJournalLines(freshLines, { allowedClientIds, closedPeriodKeys: closedKeys, coaAccountNos: coaNos })
    : null;
  if (journalError) return Response.json({ ok: false, error: journalError }, { status: 409 });

  await db.transaction(async (tx) => {
    // Serialize full-state replacements so concurrent browser tabs cannot interleave deletes and inserts.
    await tx.execute(sql`select pg_advisory_xact_lock(4027332)`);
    // Operational tables: tenant-scoped replace. The owner syncs the whole
    // workspace, so their replace clears the entire table first — legacy rows
    // outside the current client list must never survive to cause key collisions.
    const writableIds = firmWide ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
    const insertInBatches = async (table: any, rows: any[]) => {
      const batchSize = 250;
      for (let start = 0; start < rows.length; start += batchSize) {
        await tx.insert(table).values(rows.slice(start, start + batchSize));
      }
    };
    const replace = async (table: any, rows: any[], mapRow: (r: any) => Record<string, unknown>) => {
      if (isOwner) {
        await tx.delete(table);
      } else if (writableIds.length) {
        await tx.delete(table).where(inArray(table.clientId, writableIds));
      }
      if (rows.length) await insertInBatches(table, rows.map(mapRow));
    }; 

    await replace(journalLines, lines, (l) => ({
      id: l.id, docNo: l.docNo, period: l.period, date: l.date, module: l.module, docType: l.docType,
      accountNo: l.accountNo, accountName: l.accountName, costCenter: l.costCenter ?? null, debit: l.debit,
      credit: l.credit, currency: l.currency, description: l.description, createdBy: l.createdBy,
      checkedBy: l.checkedBy ?? null, isReversed: l.isReversed ?? false, reference: l.reference ?? null, clientId: l.clientId,
    }));
    const previousHeaders = await tx.select().from(journalHeaders);
    const headerRows = [...docs.values()].map((documentLines) => {
      const first = documentLines[0];
      const existingHeader = previousHeaders.find((header) => header.clientId === first.clientId && header.docNo === first.docNo);
      return buildJournalHeader(documentLines, existingHeader?.postedAt ?? new Date());
    });
    await replace(journalHeaders, headerRows, (header) => header);
    const postingReceipts = [...docs.values()].map((documentLines) =>
      buildPostingEvent(documentLines, documentLines[0].createdBy)
    );
    for (let start = 0; start < postingReceipts.length; start += 250) {
      await tx.insert(postingEvents).values(postingReceipts.slice(start, start + 250)).onConflictDoNothing();
    }
    await replace(bankAccounts, banks, (b) => ({ 
      id: b.id, clientId: b.clientId ?? 0, code: b.code, name: b.name, bankName: b.bankName, accountNo: b.accountNo,
      currency: b.currency, balance: b.balance, kind: b.kind ?? null, glAccount: b.glAccount ?? null,
    }));
    await replace(purchaseOrders, pos, (p) => ({
      id: p.id, clientId: p.clientId ?? 0, poNo: p.poNo, vendorName: p.vendorName, itemType: p.itemType,
      itemDescription: p.itemDescription, qty: p.qty, unitPrice: p.unitPrice, vatRecoverable: p.vatRecoverable,
      totalAmount: p.totalAmount, paidAmount: p.paidAmount ?? 0, status: p.status, date: p.date,
      currency: p.currency ?? null, vatTreatment: p.vatTreatment ?? null, netAmount: p.netAmount ?? null,
      quotationRef: p.quotationRef ?? null, glAccount: p.glAccount, glAccountName: p.glAccountName,
      costCenter: p.costCenter, costCenterName: p.costCenterName,
    }));
    await replace(salesInvoices, invoices, (i) => ({
      id: i.id, clientId: i.clientId ?? 0, invNo: i.invNo, customerName: i.customerName, revenueStream: i.revenueStream,
      netRevenue: i.netRevenue, vatOutput: i.vatOutput, cstAmount: i.cstAmount ?? null,
      tourismLevyAmount: i.tourismLevyAmount ?? null, vatWithheldByCustomer: i.vatWithheldByCustomer ?? null,
      totalReceivable: i.totalReceivable, paidAmount: i.paidAmount, status: i.status, date: i.date,
    }));
    await replace(employees, emps, (e) => ({
      id: e.id, clientId: e.clientId ?? null, bpNo: e.bpNo, name: e.name, role: e.role, department: e.department,
      costCenter: e.costCenter ?? null, jurisdiction: e.jurisdiction, basicSalary: e.basicSalary, allowances: e.allowances, ssnitNumber: e.ssnitNumber,
      tin: e.tin, status: e.status, isResident: e.isResident ?? true, exemptTier1: e.exemptTier1 ?? false,
      exemptTier2: e.exemptTier2 ?? false, ssnitExempt: e.ssnitExempt ?? false,
      ssnitExemptionReason: e.ssnitExemptionReason ?? null, taxRelief: e.taxRelief ?? 0, reliefType: e.reliefType ?? null,
      deductions: e.deductions ?? null,
    }));
    await replace(businessPartners, storedPartners, (p) => ({
      id: p.id, sourceId: p.sourceId, clientId: p.clientId ?? null, code: p.code, name: p.name, type: p.type, tin: p.tin, email: p.email,
      phone: p.phone, address: p.address, currency: p.currency, isVatWithholdingAgent: p.isVatWithholdingAgent,
      vatWithholdingRate: p.vatWithholdingRate ?? null, isCstApplicable: p.isCstApplicable,
      isTourismLevyApplicable: p.isTourismLevyApplicable, isVatRegistered: p.isVatRegistered ?? null,
    }));
    await replace(payrollRecords, payroll, (r) => ({ id: r.id, clientId: r.clientId ?? 0, record: r }));
    await replace(prepaymentRecords, prepayments, (p) => ({ id: p.id, clientId: p.clientId ?? 0, record: p }));
    await replace(prepaymentSchedules, prepaidSchedules, (s) => ({ id: s.id, prepaymentId: s.prepaymentId, clientId: s.clientId ?? 0, line: s }));
    await replace(approvalRequests, approvals, (a) => ({
      id: a.id, clientId: a.clientId, clientCode: a.clientCode, clientName: a.clientName, docNo: a.docNo,
      docType: a.docType, amount: a.amount, requestedBy: a.requestedBy, requestedAt: a.requestedAt,
      description: a.description, reasonForApproval: a.reasonForApproval, status: a.status,
      reviewedBy: a.reviewedBy ?? null, reviewedAt: a.reviewedAt ?? null, rejectionReason: a.rejectionReason ?? null,
      payload: a.payload ?? null,
    }));
    await replace(closedPeriods, closed.map((c) => ({ ...c, closedAt: new Date().toISOString(), closedBy: user.username })), (c) => ({
      clientId: c.clientId, period: c.period, closedAt: c.closedAt, closedBy: c.closedBy,
    }));
    // Statutory schedule edits/additions (WHT & VAT) — only when the browser sent them.
    if (taxEntries) {
      await replace(taxScheduleEntries, taxEntries, (t) => ({
        id: t.id, clientId: t.clientId, kind: t.kind, source: t.source, sourceKey: t.sourceKey ?? null,
        period: t.period, date: t.date, docNo: t.docNo, partyName: t.partyName, partyTin: t.partyTin ?? "",
        nature: t.nature ?? "", grossAmount: t.grossAmount ?? 0, rate: t.rate ?? 0, taxAmount: t.taxAmount ?? 0,
        levyAmount: t.levyAmount ?? 0, reference: t.reference ?? "", status: t.status ?? "", note: t.note ?? null,
        createdBy: t.createdBy, updatedAt: t.updatedAt,
      }));
    }

    // Perpetual inventory: item master + movement history, tenant-scoped.
    if (stock) {
      await replace(stockItems, stock, (i) => ({
        id: i.id, clientId: i.clientId, itemCode: i.itemCode, description: i.description, category: i.category,
        uom: i.uom, quantityOnHand: i.quantityOnHand, unitCost: i.unitCost, totalValue: i.totalValue,
        reorderLevel: i.reorderLevel ?? null, location: i.location ?? null, glAccount: i.glAccount ?? null,
        costMethod: i.costMethod ?? "weighted_average", netRealisableValue: i.netRealisableValue ?? null,
      }));
    }
    if (movements) {
      await replace(stockMovements, movements, (m) => ({
        id: m.id, clientId: m.clientId, date: m.date, itemCode: m.itemCode, description: m.description,
        type: m.type, quantity: m.quantity, unitCost: m.unitCost, totalValue: m.totalValue, uom: m.uom,
        reference: m.reference ?? null, docNo: m.docNo ?? null, note: m.note ?? null,
      }));
    }
    // Fixed asset register with tax base (capital allowances / IAS 12).
    if (assets) {
      await replace(fixedAssets, assets, (a) => ({
        id: a.id, clientId: a.clientId ?? 0, assetTag: a.assetTag, name: a.name, classCode: a.classCode,
        cost: a.cost, accumDep: a.accumDep, usefulLife: a.usefulLife,
        depreciationRate: a.depreciationRate ?? null, depreciationMethod: a.depreciationMethod ?? null,
        capitalAllowanceClass: a.capitalAllowanceClass ?? null, capitalAllowanceRate: a.capitalAllowanceRate ?? null,
        accumCapitalAllowance: a.accumCapitalAllowance ?? 0, location: a.location ?? "",
        acquired: a.acquired ?? null, disposedDate: a.disposedDate ?? null, disposalProceeds: a.disposalProceeds ?? null,
      }));
    }

    // Profiles: owner writes all; non-owners only their own entity's profile.
    const profileRows = Object.values(profiles).filter((p) => firmWide || p.clientId === myClientId);
    for (const p of profileRows) {
      await tx.insert(companyProfiles).values({
        clientId: p.clientId, legalName: p.legalName, tradingName: p.tradingName, tin: p.tin, vatRegNo: p.vatRegNo,
        address: p.address, phone: p.phone, email: p.email, website: p.website, fiscalYearStart: p.fiscalYearStart,
        bankPaymentDetails: p.bankPaymentDetails,
      }).onConflictDoUpdate({
        target: companyProfiles.clientId,
        set: {
          legalName: p.legalName, tradingName: p.tradingName, tin: p.tin, vatRegNo: p.vatRegNo, address: p.address,
          phone: p.phone, email: p.email, website: p.website, fiscalYearStart: p.fiscalYearStart,
          bankPaymentDetails: p.bankPaymentDetails,
        },
      });
    }

    // Firm-level masters: owner-only.
    if (isOwner) {
      if (body.clients) {
        for (const c of body.clients) {
          await tx.insert(clients).values({
            id: c.id, code: c.code, name: c.name, sector: c.sector, currency: c.currency, jurisdiction: c.jurisdiction,
            regNumber: c.regNumber, isParent: c.isParent ?? false, assignedServices: c.assignedServices ?? null,
            adminUsername: c.adminUsername ?? null, adminEmail: c.adminEmail ?? null, loginUrl: c.loginUrl ?? null,
          }).onConflictDoUpdate({
            target: clients.id,
            set: {
              code: c.code, name: c.name, sector: c.sector, currency: c.currency, jurisdiction: c.jurisdiction,
              regNumber: c.regNumber, isParent: c.isParent ?? false, assignedServices: c.assignedServices ?? null,
              adminUsername: c.adminUsername ?? null, adminEmail: c.adminEmail ?? null, loginUrl: c.loginUrl ?? null,
            },
          });
        }
      }
      if (body.disclosureNotes) {
        await tx.delete(disclosureNotes);
        if (body.disclosureNotes.length) {
          await tx.insert(disclosureNotes).values(
            body.disclosureNotes.map((n) => ({
              key: n.key, noteNumber: n.noteNumber, title: n.title, standardRef: n.standardRef, applicable: n.applicable,
              notApplicableReason: n.notApplicableReason ?? null, body: n.body, tables: n.tables ?? null,
              editableOverride: n.editableOverride ?? null,
            }))
          );
        }
      }
    }

    // Chart of accounts: the owner maintains the whole chart (firm master plus every
    // entity's customs); non-owners maintain only their own entity's custom accounts.
    if (body.chartOfAccounts) {
      if (isOwner) {
        await tx.delete(chartAccounts);
        if (body.chartOfAccounts.length) {
          await tx.insert(chartAccounts).values(
            body.chartOfAccounts.map((a) => ({
              accountNo: a.accountNo, name: a.name, type: a.type, category: a.category,
              active: a.active, isCustom: a.isCustom ?? false, clientId: a.clientId ?? null,
            }))
          );
        }
      } else if (myClientId !== null && user.role === "manager") {
        // Server-side authority check: only the entity's owner/manager may
        // maintain its account names. Staff syncs leave the chart untouched.
        await tx.delete(chartAccounts).where(eq(chartAccounts.clientId, myClientId));
        const own = body.chartOfAccounts.filter((a) => a.clientId === myClientId);
        if (own.length) {
          await tx.insert(chartAccounts).values(
            own.map((a) => ({
              accountNo: a.accountNo, name: a.name, type: a.type, category: a.category,
              active: a.active, isCustom: a.isCustom ?? false, clientId: myClientId,
            }))
          );
        }
      }
    }

    // Audit trail: one entry per newly posted journal document.
    const now = new Date().toISOString();
    // Period freezes and reopens are audit events — the ledger can change hands
    // but the control history must be reviewable.
    const prevClosed = new Set(allClosed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`));
    const nextClosed = new Set(closed.map((c) => `${c.clientId}:${c.period}`));
    for (const key of nextClosed) {
      if (prevClosed.has(key)) continue;
      const [cid, p] = key.split(":");
      await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: "CLOSE_PERIOD", target: `${cid}:${p}`, details: `Period ${p} frozen for client ${cid}`, clientId: Number(cid) });
    }
    for (const key of prevClosed) {
      if (nextClosed.has(key)) continue;
      const [cid, p] = key.split(":");
      await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: "REOPEN_PERIOD", target: `${cid}:${p}`, details: `Period ${p} reopened for client ${cid}`, clientId: Number(cid) });
    }
    // Approval resolutions (pending → approved/rejected) are audit events too.
    const prevApprovalStatus = new Map(allApprovals.filter((a) => allowedClientIds.includes(a.clientId)).map((a) => [a.id, a.status]));
    for (const a of approvals) {
      const prev = prevApprovalStatus.get(a.id);
      if (prev && prev !== a.status) {
        await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: `APPROVAL_${a.status.toUpperCase()}`, target: a.docNo, details: `${a.clientCode} request by ${a.requestedBy} ${a.status}${a.rejectionReason ? ` — ${a.rejectionReason}` : ""}`, clientId: a.clientId });
      }
    }
    for (const key of freshKeys) {
      const docLines = docs.get(key)!;
      const dr = docLines.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
      await tx.insert(auditLog).values({
        id: crypto.randomUUID(),
        timestamp: now,
        userId: user.username,
        username: user.username,
        action: "POST_JOURNAL",
        target: key.split(":")[1],
        details: `${docLines.length} line(s), debits ${dr.toFixed(2)}`,
        clientId: Number(key.split(":")[0]),
      });
    }
  });

  return Response.json({ ok: true });
}
