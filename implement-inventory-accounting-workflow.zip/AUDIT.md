# BPZ Consult ERP — responsiveness, Payment Desk & system audit

Source: `fix-login-redirection-bug.zip` (latest upload in the GitHub repo), ported into this Next.js + PostgreSQL project.

## Reported problems

### 1. "Pages are not responsive when you click"
Four root causes, all fixed:

| Cause | Symptom | Fix |
| --- | --- | --- |
| **Release payroll** posted instantly and its result banner rendered at the *top* of a long page | Click appeared to do nothing | Opens a confirmation modal; results show in a floating toast visible anywhere |
| **Payroll statutory due** pill was plain text | Click did nothing | Now a button: scrolls to and highlights the due payroll obligations |
| Payment-modal validation errors (bad amount, low balance…) were written *behind* the modal overlay | "Effect payment" looked dead | Errors appear inside the modal next to the button |
| Sidebar stacked above content on phones/tablets (30-item list) and was not fixed on desktop; modals taller than the screen had unreachable buttons | Click a menu item → page changed far below the fold; Save/Create buttons off-screen | Off-canvas menu drawer on mobile, independently scrolling menu/content on desktop, scroll-to-top on every navigation, every modal overlay scrolls ("safe center"), dense dialog grids stack on narrow phones, tables get horizontal scroll |

### 2. Payment Desk — method, payee, withholding tax
Every payment modal (supplier, expense bill, statutory remittance, payroll release; method also on customer receipts) now has:

1. **Payment method** (bank transfer / cash / mobile money / cheque) and **pay-from account**, with the treasury record that will really move shown before you confirm.
2. **Person or company receiving the money** — the document's payee, any saved supplier, any active employee (payroll) or "Other" (typed name) — plus a **Company / Individual** switch. A payee is mandatory and is written into the journal descriptions and the payment voucher.
3. **Withholding tax: Apply / No withholding tax** (suppliers and expense bills). *No* deducts nothing (income WHT and VAT withholding), shows a compliance warning and records an optional exemption reference in the audit trail. Statutory remittances and payroll explain why WHT is not applicable.

Payroll release can pay the whole batch or a single employee (net pay pre-filled).

## System audit — other defects found and fixed
- 2 stale unit tests (reversal flag, idempotent-DDL assertion) corrected; 2 new tests for payee/WHT logic → **88/88 pass**.
- `POST /api/auth/login` returned HTTP 500 "Login failed." for a malformed body → now 400.
- ESLint: 1 error (`<a>` instead of `<Link>`) + 2 warnings → **0 problems**.
- Print stylesheet no longer clips vouchers/invoices inside the fixed-height app shell.
- `scripts/render-audit.tsx`: all 35 modules × 5 entities render. API audit: 5 seeded logins, session, tenant-scoped bootstrap, state round-trip, journal validation (unbalanced rejected), unauthenticated access rejected.

## Sign-in
See `FIXES.md` for seeded credentials (e.g. `owner` / `BpzOwner2026!`).
