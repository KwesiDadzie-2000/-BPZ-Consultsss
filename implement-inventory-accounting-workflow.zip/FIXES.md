# BPZ Consult ERP — bug-fix report

This build is **your original system** from `resolve-payroll-system-bugs.zip`
(all 36 components, the API layer, schema, seed data and test suite). Nothing was
redesigned; only defects were fixed. My earlier replacement app was discarded.

## Sign-in credentials (from the original seed — no reset was needed)

| Username | Email | Password | Role | Scope |
| --- | --- | --- | --- | --- |
| `owner` | k.dadzie@bpzconsult.com | `BpzOwner2026!` | owner | all entities + owner administration |
| `manager_ama` | a.owusu@bpzconsult.com | `BpzAma2026!` | partner | firm |
| `checker_kofi` | k.mensah@bpzconsult.com | `BpzKofi2026!` | manager (checker) | firm |
| `demo` | demo@bpzconsult.com | `BpzDemo2026!` | accountant | client 2 |
| `agro_accountant` | e.mensimah@voltariveragro.com | `BpzAgro2026!` | accountant | client 3 |

Rotate passwords in-app via **Owner Administration → User Permissions**, or, if
the owner account itself is locked out:

```bash
npx tsx src/db/reset-password.ts owner 'YourNewPassword1!'
```

## Root cause of "Login failed."

`/api/auth/login` returns "Login failed." only when the server throws. On the
deployed database **the tables had never been created** — the app silently relied
on someone running `drizzle-kit push` and `tsx src/db/seed.ts` by hand. The login
query failed with `relation "users" does not exist` (HTTP 500). With tables but no
seed, every credential was rejected instead.

**Fix:** `src/db/bootstrap.ts` → `ensureDatabaseReady()` runs before every API
route. Inside one transaction holding a PostgreSQL advisory lock it creates any
missing tables (`src/db/ddl.ts`, generated from `schema.ts` with
`drizzle-kit export`) and seeds the workspace once if no user exists. Verified:
0 tables → first login creates all 18 and succeeds; 8 simultaneous first logins →
seeded exactly once.

## Other defects fixed

| # | Defect | Effect | Fix |
| --- | --- | --- | --- |
| 1 | Failed `/api/bootstrap` still marked the workspace hydrated | The 800 ms auto-sync PUT this browser's stale localStorage copy; for the owner the server **replaced every table** with it | Sync now requires a successful server load (`serverStateLoaded`) and shows a notice otherwise (`App.tsx`) |
| 2 | New client / bank account / employee ids = `Date.now()` | Overflows PostgreSQL `integer` → sync rejected; new records could never be saved | `nextIntId()` (int32-safe, collision-checked) |
| 3 | Journal ids `JL-…-${Date.now()}-n` across 13 files | Duplicate primary keys in batch posting ("Post all due" prepayments, approvals) → whole sync rolled back | `uniqueId()` — unique even within one millisecond |
| 4 | Invoice/PO/contract/loan numbers `…-${random}`; doc numbers `Date.now() % N` | Repeats → "Document already posted with different content" | Sequential `nextDocNo()`; `docSuffix()` |
| 5 | Client counted 5xx errors as failed passwords | A server outage locked correct passwords out for 5 minutes | Only HTTP 401 counts toward the lockout (`LoginScreen.tsx`) |
| 6 | Server lockout count never reset after expiry | One typo after a lockout re-locked the account immediately | Expired lock starts a fresh window (`api/auth/login`) |
| 7 | Login banner said credentials are "checked on this device" | Inaccurate — they are verified server-side with scrypt | Text corrected; design unchanged |
| 8 | Prepayment selection fixed up via setState-in-effect | Extra render pass on every change | Derived during render |
| 10 | Only `owner` had firm-wide data scope | Partner `manager_ama` and reviewer `checker_kofi` (no client binding) got an **empty workspace**, no entity switcher, and every posting was rejected as "Cross-tenant write rejected" | `hasFirmWideScope()` in `utils/access.ts`, shared by the API and the entity switcher; user admin and firm masters stay owner-only |
| 9 | Seed was not transactional | A failure part-way left a half-seeded database that never re-seeded | Seed runs in one transaction |

## Verification

- Original test suite: **81/81 pass**; plus `tests/regression-fixes.test.ts` (5 new) → **86/86**
  (`npx tsx --test tests/*.test.ts`).
- ESLint: 30 problems in the original → **0**. `tsc --noEmit` clean. `next build` clean.
- API end-to-end: login for all five accounts (username and email), session,
  tenant-scoped bootstrap (owner/partner/manager: 4 entities; demo: 1), full-state
  save round-trip for every role, integer-overflow regression
  (old id → HTTP 500, new id → HTTP 200), break-glass reset.
