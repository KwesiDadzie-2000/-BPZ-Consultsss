import type { ACDOCALine } from "@/types/accounting";

const toMinor = (n: number) => Math.round(n * 100);

export interface JournalValidationContext {
  /** Client ids the session user may post to (owner: all; others: their own). */
  allowedClientIds: number[];
  /**
   * Frozen periods as `${clientId}:${period}` keys (e.g. "2:2026-03"). Periods are
   * closed per entity — a period frozen for one client must never block another.
   */
  closedPeriodKeys: Set<string>;
  /** Account numbers that exist in the chart of accounts. */
  coaAccountNos: Set<string>;
}

/**
 * Server-side posting validation: tenant ownership, open periods, chart-of-accounts
 * existence, non-negative finite amounts, and per-document double-entry balance in
 * minor units. Returns the first violation found, or null when the batch is valid.
 */
export function validateJournalLines(lines: ACDOCALine[], ctx: JournalValidationContext): string | null {
  if (!lines.length) return "No journal lines provided.";
  for (const l of lines) {
    if (!ctx.allowedClientIds.includes(l.clientId)) return "Transaction belongs to a different client.";
    if (ctx.closedPeriodKeys.has(`${l.clientId}:${l.period}`)) return `Period ${l.period} is closed and frozen for this entity.`;
    if (!ctx.coaAccountNos.has(l.accountNo)) return `Account ${l.accountNo} does not exist in the chart of accounts.`;
    if (!Number.isFinite(l.debit) || !Number.isFinite(l.credit) || l.debit < 0 || l.credit < 0) {
      return "Invalid amounts.";
    }
  }
  const byDoc = new Map<string, { dr: number; cr: number }>();
  for (const l of lines) {
    const key = `${l.clientId}:${l.docNo}`;
    const agg = byDoc.get(key) ?? { dr: 0, cr: 0 };
    agg.dr += toMinor(l.debit);
    agg.cr += toMinor(l.credit);
    byDoc.set(key, agg);
  }
  for (const [key, agg] of byDoc) {
    if (agg.dr <= 0 || agg.dr !== agg.cr) return `Document ${key.split(":")[1]} is not balanced (Dr = Cr required).`;
  }
  return null;
}

/** True when every line of the batch belongs to a single client (entity-private documents). */
export function isSingleClient(lines: ACDOCALine[]): boolean {
  return new Set(lines.map((l) => l.clientId)).size === 1;
}

export interface MakerCheckerContext {
  /** The session user posting the batch (the maker). */
  username: string;
  /** The maker's posting threshold in major units (0 = no threshold set). */
  makerLimit: number;
}

/**
 * Segregation of duties: a document the maker posts above their maker limit must
 * carry a checker who is NOT the maker. Self-checking above the limit — or posting
 * above the limit unchecked — is rejected server-side so one person can never
 * both make and approve an oversized entry.
 */
export function validateMakerChecker(lines: ACDOCALine[], ctx: MakerCheckerContext): string | null {
  const byDoc = new Map<string, { total: number; maker: string; checker?: string }>();
  for (const l of lines) {
    const key = `${l.clientId}:${l.docNo}`;
    const agg = byDoc.get(key) ?? { total: 0, maker: l.createdBy, checker: l.checkedBy };
    agg.total += toMinor(l.debit);
    if (l.checkedBy) agg.checker = l.checkedBy;
    byDoc.set(key, agg);
  }
  for (const [key, agg] of byDoc) {
    if (agg.maker !== ctx.username) continue; // rule applies to documents the posting session itself made
    if (ctx.makerLimit <= 0) continue; // no threshold configured for this user
    if (agg.total / 100 > ctx.makerLimit) {
      if (!agg.checker) {
        return `Document ${key.split(":")[1]} exceeds the maker limit and has no independent checker.`;
      }
      if (agg.checker === agg.maker) {
        return `Document ${key.split(":")[1]} exceeds the maker limit — the maker cannot check their own document.`;
      }
    }
  }
  return null;
}
