import assert from 'node:assert/strict';
import test from 'node:test';
import { calculateProgressivePaye, GHANA_PAYE_BANDS_MONTHLY } from '../src/utils/payrollCalculator';
import { maySeeSection } from '../src/utils/access';
import { persistentStorage } from '../src/utils/persistentStorage';
import type { ClientEntity, UserAccount } from '../src/types/accounting';

test('PAYE bracket boundaries supplied for the Ghana demo', () => {
  const samples = [
    [588, 0], [668, 4], [768, 14], [3668, 521.5],
    [19668, 4521.5], [50000, 13621.1], [50001, 13621.45],
  ];
  for (const [income, expected] of samples) assert.equal(calculateProgressivePaye(income), expected);
  assert.equal(GHANA_PAYE_BANDS_MONTHLY.at(-1)?.lower, 50000);
});

test('demo client can see only assigned services in its workspace', () => {
  const client: ClientEntity = { id: 12, code: 'C12', name: 'Example', sector: 'Services', currency: 'GHS', jurisdiction: 'GH', regNumber: '', assignedServices: ['bookkeeping'] };
  const user: UserAccount = { username: 'client', email: 'client@example.test', name: 'Client', role: 'accountant', clientId: 12, makerLimit: 1000, canCheck: false };
  assert.equal(maySeeSection(user, client, 'sales'), true);
  assert.equal(maySeeSection(user, client, 'payroll'), false);
  assert.equal(maySeeSection({ ...user, clientId: 13 }, client, 'sales'), false);
  assert.equal(maySeeSection({ ...user, status: 'restricted' }, client, 'sales'), false);
});

test('local demo backup rejects an unbalanced journal without changing stored data', () => {
  const data = new Map<string, string>();
  Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: {
    getItem: (key: string) => data.get(key) ?? null,
    setItem: (key: string, value: string) => { data.set(key, value); },
  } });
  const original = persistentStorage.exportFullBackup();
  const broken = JSON.parse(original);
  broken.journalLines[0].debit += 1;
  assert.equal(persistentStorage.restoreFullBackup(JSON.stringify(broken)), false);
  assert.deepEqual(persistentStorage.getJournalLines(), JSON.parse(original).journalLines);
  assert.equal(persistentStorage.restoreFullBackup(original), true);
});
import { computeOutputLevies } from '../src/utils/taxConfig';
import { calculateSupplierSettlement, isBalancedDocument } from '../src/utils/transactionMath';
import { INITIAL_ACDOCA_LINES } from '../src/data/accountingSeed';

test('2026 VAT configuration calculates VAT stack and optional sector levies', () => {
  const standard = computeOutputLevies(100, { cst: false, tourism: false }, '2026-10-15');
  assert.deepEqual(standard, { vat: 15, nhil: 2.5, getfund: 2.5, cst: 0, tourism: 0, total: 20 });
  // CST cascades into the VAT/NHIL/GETFund base (VAT Act 2025 s.15.3): 15.75 + 2.63 + 2.63 + 5.
  const telecom = computeOutputLevies(100, { cst: true, tourism: false }, '2026-10-15');
  assert.equal(telecom.total, 26.01);
});

test('partial supplier settlement reconciles AP, income WHT, VAT WHT and cash', () => {
  const payment = calculateSupplierSettlement({ invoiceGross: 120, invoiceTaxableValue: 100, alreadyPaid: 0, paymentGross: 60, incomeWhtRate: 3, vatWithholdingRate: 7 });
  assert.deepEqual(payment, { outstanding: 120, taxablePaymentBase: 50, incomeWht: 1.5, vatWithheld: 3.5, cash: 55, resultingPaid: 60, resultingOutstanding: 60 });
  assert.equal(isBalancedDocument([{ debit: 60, credit: 0 }, { debit: 0, credit: 1.5 }, { debit: 0, credit: 3.5 }, { debit: 0, credit: 55 }]), true);
});

test('seeded journal documents are individually balanced', () => {
  const docs = new Map<string, typeof INITIAL_ACDOCA_LINES>();
  for (const line of INITIAL_ACDOCA_LINES) docs.set(line.docNo, [...(docs.get(line.docNo) || []), line]);
  for (const [docNo, lines] of docs) assert.equal(isBalancedDocument(lines), true, `${docNo} is unbalanced`);
});
