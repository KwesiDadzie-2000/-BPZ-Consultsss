import assert from 'node:assert/strict';
import test from 'node:test';

// In-memory localStorage mock (must exist before any store call).
const memory = new Map<string, string>();
Object.defineProperty(globalThis, 'localStorage', {
  configurable: true,
  value: {
    getItem: (k: string) => memory.get(k) ?? null,
    setItem: (k: string, v: string) => memory.set(k, v),
    removeItem: (k: string) => memory.delete(k),
  },
});

import {
  INITIAL_ACDOCA_LINES,
  INITIAL_BANK_ACCOUNTS,
  INITIAL_CHART_OF_ACCOUNTS,
  INITIAL_CLIENTS,
  INITIAL_PURCHASE_ORDERS,
} from '../src/data/accountingSeed';
import { GHANA_ECONOMY_SECTORS, SECTOR_SPEND_ACCOUNTS } from '../src/data/ghanaSectors';
import { computeOutputLevies, DEFAULT_GH_TAX_SETTINGS, taxConfigStore } from '../src/utils/taxConfig';
import { persistentStorage } from '../src/utils/persistentStorage';
import { isBalancedDocument } from '../src/utils/transactionMath';

/* ---------- Chart of accounts: expansion, integrity & scrutiny ---------- */

test('chart of accounts is expanded, unique and internally consistent', () => {
  const numbers = INITIAL_CHART_OF_ACCOUNTS.map((a) => a.accountNo);
  assert.equal(new Set(numbers).size, numbers.length, 'account numbers must be unique');
  const validTypes = new Set(['Asset', 'Liability', 'Equity', 'Income', 'Expense']);
  for (const a of INITIAL_CHART_OF_ACCOUNTS) {
    assert.ok(validTypes.has(a.type), `${a.accountNo} has a valid classification`);
    assert.ok(a.name.length > 0 && a.category.length > 0, `${a.accountNo} is fully described`);
  }
  // The expansion must materially grow the ledger (50 seed accounts -> 140+).
  assert.ok(INITIAL_CHART_OF_ACCOUNTS.length >= 140, `expected an expanded COA, found ${INITIAL_CHART_OF_ACCOUNTS.length}`);
});

test('every account referenced by seeded journals and purchase orders exists in the COA', () => {
  const ledger = new Set(INITIAL_CHART_OF_ACCOUNTS.map((a) => a.accountNo));
  for (const line of INITIAL_ACDOCA_LINES) {
    assert.ok(ledger.has(line.accountNo), `journal line ${line.id} references unknown GL ${line.accountNo}`);
  }
  for (const po of INITIAL_PURCHASE_ORDERS) {
    assert.ok(ledger.has(po.glAccount), `${po.poNo} references unknown GL ${po.glAccount}`);
  }
  // Payroll-posted accounts must exist (511000 employer SSNIT, 208000 staff recoveries).
  assert.ok(ledger.has('511000'), 'employer SSNIT expense account exists');
  assert.ok(ledger.has('208000'), 'staff loan recoveries payable account exists');
  // Service procurement fallback GL must be a real service expense account.
  assert.ok(ledger.has('621000'), 'contracted services expense account exists');
});

test('every seeded journal document still balances after the COA expansion', () => {
  const grouped = new Map<string, typeof INITIAL_ACDOCA_LINES>();
  for (const line of INITIAL_ACDOCA_LINES) grouped.set(line.docNo, [...(grouped.get(line.docNo) || []), line]);
  for (const [doc, lines] of grouped) assert.equal(isBalancedDocument(lines), true, `${doc} must balance`);
});

/* ---------- Cash is separated from bank ---------- */

test('cash and bank are separate GL accounts so opening balances can be captured for both', () => {
  const byNo = new Map(INITIAL_CHART_OF_ACCOUNTS.map((a) => [a.accountNo, a]));
  const operating = byNo.get('100000');
  assert.ok(operating, 'operating account exists');
  assert.ok(/bank/i.test(operating!.name) && !/cash and bank/i.test(operating!.name), '100000 is a bank account, not a combined cash-and-bank account');
  assert.equal(operating!.category, 'Bank Accounts');
  const fcy = byNo.get('101000');
  assert.ok(fcy && /foreign currency/i.test(fcy.name), '101000 remains the foreign currency bank account (not mobile money)');
  assert.ok(byNo.has('102000') && /petty cash/i.test(byNo.get('102000')!.name), 'petty cash safe float exists');
  assert.ok(byNo.has('103000') && /cash on hand/i.test(byNo.get('103000')!.name), 'separate cash-on-hand account exists');
  assert.ok(byNo.has('104000') && /mobile money/i.test(byNo.get('104000')!.name), 'mobile money clearing account exists');
  for (const no of ['102000', '103000', '104000']) assert.equal(byNo.get(no)!.category, 'Cash on Hand');
});

test('treasury records are classified bank vs cash and map to distinct GL accounts', () => {
  const kinds = new Set(INITIAL_BANK_ACCOUNTS.map((b) => b.kind ?? 'bank'));
  assert.ok(kinds.has('bank') && kinds.has('cash'), 'both bank and cash treasury records exist');
  for (const b of INITIAL_BANK_ACCOUNTS) {
    assert.ok(b.glAccount, `${b.code} maps to a GL account`);
  }
  const bankGl = INITIAL_BANK_ACCOUNTS.filter((b) => (b.kind ?? 'bank') === 'bank').map((b) => b.glAccount);
  const cashGl = INITIAL_BANK_ACCOUNTS.filter((b) => b.kind === 'cash').map((b) => b.glAccount);
  assert.equal(new Set([...bankGl, ...cashGl]).size, [...bankGl, ...cashGl].length, 'each treasury record maps to its own GL');
  assert.ok(cashGl.includes('102000') || cashGl.includes('104000'), 'cash records map to cash GL accounts');
  assert.ok(bankGl.includes('100000'), 'bank record maps to the bank GL account');
});

/* ---------- Spendable accounts tailored to every sector ---------- */

test('every Ghanaian economic sector has tailored spendable expense accounts in the COA', () => {
  const expenses = new Set(
    INITIAL_CHART_OF_ACCOUNTS.filter((a) => a.type === 'Expense').map((a) => a.accountNo)
  );
  assert.equal(Object.keys(SECTOR_SPEND_ACCOUNTS).length, GHANA_ECONOMY_SECTORS.length, 'mapping covers every sector');
  for (const sector of GHANA_ECONOMY_SECTORS) {
    const accounts = SECTOR_SPEND_ACCOUNTS[sector.code];
    assert.ok(Array.isArray(accounts) && accounts.length >= 3, `${sector.code} has tailored spend accounts`);
    for (const no of accounts) {
      assert.ok(expenses.has(no), `${sector.code} spend account ${no} exists in the COA as an expense`);
    }
  }
});

/* ---------- Each entity owns its own trial balance ---------- */

test('trial balances are owned per entity and never mix entities', () => {
  const clientIds = new Set(INITIAL_CLIENTS.map((c) => c.id));
  for (const line of INITIAL_ACDOCA_LINES) {
    assert.ok(clientIds.has(line.clientId), `line ${line.id} belongs to a known entity`);
  }
  for (const client of INITIAL_CLIENTS) {
    const own = INITIAL_ACDOCA_LINES.filter((l) => l.clientId === client.id);
    const others = INITIAL_ACDOCA_LINES.filter((l) => l.clientId !== client.id);
    // Strict scoping: the entity's trial balance is built only from its own lines.
    assert.ok(own.every((l) => l.clientId === client.id));
    assert.ok(others.every((l) => l.clientId !== client.id));
    const dr = own.reduce((n, l) => n + Math.round(l.debit * 100), 0);
    const cr = own.reduce((n, l) => n + Math.round(l.credit * 100), 0);
    assert.equal(dr, cr, `${client.code} owns a balanced trial balance (Dr ${dr} = Cr ${cr})`);
    // Documents are entity-private: no docNo spans two entities.
    const docs = new Set(own.map((l) => l.docNo));
    for (const doc of docs) {
      assert.ok(INITIAL_ACDOCA_LINES.filter((l) => l.docNo === doc).every((l) => l.clientId === client.id), `${doc} stays within ${client.code}`);
    }
  }
});

/* ---------- Owner can set the fiscal year for all entities ---------- */

test('owner can set the fiscal year start for all entities at once', () => {
  memory.clear();
  const ids = INITIAL_CLIENTS.map((c) => c.id);
  const updated = persistentStorage.setFiscalYearStartForAll('April', ids);
  for (const id of ids) {
    assert.equal(updated[id].fiscalYearStart, 'April', `entity ${id} fiscal year updated`);
  }
  const stored = persistentStorage.getCompanyProfiles();
  for (const id of ids) {
    assert.equal(stored[id].fiscalYearStart, 'April', `entity ${id} persisted`);
  }
  // Per-entity override still possible afterwards.
  const profiles = persistentStorage.getCompanyProfiles();
  persistentStorage.saveCompanyProfiles({ ...profiles, [ids[0]]: { ...profiles[ids[0]], fiscalYearStart: 'July' } });
  assert.equal(persistentStorage.getCompanyProfiles()[ids[0]].fiscalYearStart, 'July');
  assert.equal(persistentStorage.getCompanyProfiles()[ids[1]].fiscalYearStart, 'April');
});

/* ---------- GRA 2026 indirect tax computations ---------- */

test('VAT stack, CST cascade and tourism levy follow the 2026 GRA rules', () => {
  taxConfigStore.reset();
  assert.deepEqual(computeOutputLevies(1000, { cst: false, tourism: false }, '2026-10-15'),
    { vat: 150, nhil: 25, getfund: 25, cst: 0, tourism: 0, total: 200 });
  const telecom = computeOutputLevies(1000, { cst: true, tourism: false }, '2026-10-15');
  assert.deepEqual(telecom, { vat: 157.5, nhil: 26.25, getfund: 26.25, cst: 50, tourism: 0, total: 260 });
  const hotel = computeOutputLevies(1000, { cst: false, tourism: true }, '2026-10-15');
  assert.deepEqual(hotel, { vat: 150, nhil: 25, getfund: 25, cst: 0, tourism: 10, total: 210 });
});

test('VAT withholding is 7% of taxable value and the full WHT schedule is captured', () => {
  taxConfigStore.reset();
  assert.equal(taxConfigStore.rate('VAT_WHT'), 7, 'VAT withholding rate is 7% (not 0.07%)');
  const codes = new Set(DEFAULT_GH_TAX_SETTINGS.components.map((c) => c.code));
  const expected = [
    'WHT_GOODS', 'WHT_WORKS', 'WHT_SERVICES', 'WHT_PROFESSIONAL',
    'WHT_PETROLEUM_SUB', 'WHT_PRECIOUS_MINERALS', 'WHT_REALISATION',
    'WHT_DIVIDEND', 'WHT_INTEREST', 'WHT_RENT_RESIDENTIAL', 'WHT_RENT_COMMERCIAL',
    'WHT_ROYALTY', 'WHT_DIRECTOR_FEES', 'WHT_AGENT_COMMISSION', 'WHT_EXAMINER_TEACHER',
    'WHT_NON_RESIDENT', 'WHT_NONRES_MGMT_TECH', 'WHT_NONRES_ROYALTY_RENT', 'WHT_NONRES_TELECOM_TRANSPORT',
    'WHT_NONRES_PETROLEUM_SUB', 'WHT_NONRES_INSURANCE', 'WHT_NONRES_BRANCH',
    'WHT_NONRES_INTEREST', 'WHT_NONRES_DIVIDEND', 'WHT_NONRES_REALISATION', 'VAT_WHT',
  ];
  for (const code of expected) assert.ok(codes.has(code), `WHT schedule captures ${code}`);
  // Spot-check GRA rates.
  const rateOf = (code: string) => DEFAULT_GH_TAX_SETTINGS.components.find((c) => c.code === code)!.rate;
  assert.equal(rateOf('WHT_GOODS'), 3);
  assert.equal(rateOf('WHT_WORKS'), 5);
  assert.equal(rateOf('WHT_SERVICES'), 7.5);
  assert.equal(rateOf('WHT_ROYALTY'), 15);
  assert.equal(rateOf('WHT_DIVIDEND'), 8);
  assert.equal(rateOf('WHT_INTEREST'), 8);
  assert.equal(rateOf('WHT_RENT_RESIDENTIAL'), 8);
  assert.equal(rateOf('WHT_RENT_COMMERCIAL'), 15);
  assert.equal(rateOf('WHT_DIRECTOR_FEES'), 20);
  assert.equal(rateOf('WHT_AGENT_COMMISSION'), 10);
  assert.equal(rateOf('WHT_EXAMINER_TEACHER'), 10);
  assert.equal(rateOf('WHT_PETROLEUM_SUB'), 7.5);
  assert.equal(rateOf('WHT_PRECIOUS_MINERALS'), 3);
  assert.equal(rateOf('WHT_NON_RESIDENT'), 20);
  assert.equal(rateOf('WHT_NONRES_MGMT_TECH'), 20);
  assert.equal(rateOf('WHT_NONRES_ROYALTY_RENT'), 15);
  assert.equal(rateOf('WHT_NONRES_TELECOM_TRANSPORT'), 15);
  assert.equal(rateOf('WHT_NONRES_PETROLEUM_SUB'), 15);
  assert.equal(rateOf('WHT_NONRES_INSURANCE'), 5);
  assert.equal(rateOf('WHT_NONRES_BRANCH'), 8);
  assert.equal(rateOf('WHT_NONRES_INTEREST'), 8);
  assert.equal(rateOf('WHT_NONRES_DIVIDEND'), 8);
  assert.equal(rateOf('WHT_NONRES_REALISATION'), 10);
  assert.equal(rateOf('CST'), 5);
  assert.equal(rateOf('TOURISM_LEVY'), 1);
  // Tourism levy is active so hospitality billings can apply it.
  assert.equal(taxConfigStore.rate('TOURISM_LEVY'), 1);
});
