import assert from 'node:assert/strict';
import test from 'node:test';

import { buildReversalLines, buildYearEndCloseEntries } from '../src/utils/journalControls';
import { validateMakerChecker } from '../src/lib/journalValidation';
import { INITIAL_CHART_OF_ACCOUNTS } from '../src/data/accountingSeed';
import type { ACDOCALine } from '../src/types/accounting';

let seq = 0;
const line = (over: Partial<ACDOCALine>): ACDOCALine => ({
  id: `C-${++seq}`,
  docNo: over.docNo ?? 'JE-1',
  period: over.period ?? '2026-10',
  date: over.date ?? '2026-10-15',
  module: over.module ?? 'FI',
  docType: over.docType ?? 'JE',
  accountNo: over.accountNo ?? '600000',
  accountName: over.accountName ?? 'Operating Expenses',
  costCenter: 'CC-ADM',
  debit: over.debit ?? 0,
  credit: over.credit ?? 0,
  currency: 'GHS',
  description: over.description ?? 'control test',
  createdBy: over.createdBy ?? 'maker1',
  checkedBy: over.checkedBy,
  clientId: over.clientId ?? 2,
  isReversed: over.isReversed,
  reference: over.reference,
});

test('reversal mirrors every line, posts to the current period and references the original', () => {
  const original = [
    line({ docNo: 'JE-100', period: '2026-01', date: '2026-01-10', accountNo: '600000', debit: 2500, credit: 0 }),
    line({ docNo: 'JE-100', period: '2026-01', date: '2026-01-10', accountNo: '100000', debit: 0, credit: 2500 }),
  ];
  const rev = buildReversalLines(original, { username: 'senior1', canCheck: true, period: '2026-10', date: '2026-10-20' });
  assert.equal(rev.length, 2);
  assert.ok(rev.every((l) => l.docNo === 'REV-JE-100'), 'all reversal lines share REV-<docNo>');
  assert.ok(rev.every((l) => l.period === '2026-10' && l.date === '2026-10-20'), 'reversal posts to the CURRENT period, not the frozen original');
  assert.ok(rev.every((l) => l.reference === 'JE-100' && l.docType === 'REV' && l.isReversed !== true), 'reversal lines reference the original and are not themselves flagged reversed');
  const dr = rev.reduce((n, l) => n + l.debit, 0);
  const cr = rev.reduce((n, l) => n + l.credit, 0);
  assert.equal(dr, cr, 'reversal document balances');
  assert.equal(rev[0].debit, 0);
  assert.equal(rev[0].credit, 2500, 'debit lines invert to credits');
});

test('maker/checker: within limit self-check passes; over limit an independent checker is mandatory', () => {
  const within = [line({ docNo: 'JE-10', debit: 500 }), line({ docNo: 'JE-10', accountNo: '100000', credit: 500, debit: 0 })];
  assert.equal(validateMakerChecker(within.map((l) => ({ ...l, checkedBy: 'maker1' })), { username: 'maker1', makerLimit: 1000 }), null);

  const over = [line({ docNo: 'JE-11', debit: 5000 }), line({ docNo: 'JE-11', accountNo: '100000', credit: 5000, debit: 0 })];
  assert.match(validateMakerChecker(over, { username: 'maker1', makerLimit: 1000 })!, /no independent checker/);
  assert.match(validateMakerChecker(over.map((l) => ({ ...l, checkedBy: 'maker1' })), { username: 'maker1', makerLimit: 1000 })!, /cannot check their own/);
  assert.equal(validateMakerChecker(over.map((l) => ({ ...l, checkedBy: 'checker_kofi' })), { username: 'maker1', makerLimit: 1000 }), null);

  // No threshold configured — nothing to enforce.
  assert.equal(validateMakerChecker(over, { username: 'maker1', makerLimit: 0 }), null);
});

test('year-end close transfers the fiscal year result to retained earnings and balances', () => {
  const yearLines = [
    // Revenue 1,000,000 (credit) and COGS 600,000 (debit)
    line({ period: '2026-03', docNo: 'SLS-1', accountNo: '400000', accountName: 'Revenue from Customer Contracts (IFRS 15)', debit: 0, credit: 1000000 }),
    line({ period: '2026-03', docNo: 'COGS-1', accountNo: '500000', accountName: 'Cost of Extraction & Processing', debit: 600000, credit: 0 }),
    line({ period: '2026-03', docNo: 'COGS-1', accountNo: '120000', debit: 0, credit: 600000 }),
  ];
  const result = buildYearEndCloseEntries(yearLines, INITIAL_CHART_OF_ACCOUNTS, {
    year: 2026, period: '2026-12', date: '2026-12-31', currency: 'GHS', username: 'owner', canCheck: true, clientId: 2,
  });
  assert.ok(result, 'a profitable year must produce a close document');
  assert.equal(result.net, 400000, 'profit = revenue - cogs transferred to retained earnings');
  const dr = result.lines.reduce((n, l) => n + Math.round(l.debit * 100), 0);
  const cr = result.lines.reduce((n, l) => n + Math.round(l.credit * 100), 0);
  assert.equal(dr, cr, 'year-end close document balances in cents');
  const re = result.lines.find((l) => l.accountNo === '310000');
  assert.ok(re && re.credit === 400000, 'profit credits retained earnings');
  const revenue = result.lines.find((l) => l.accountNo === '400000');
  assert.ok(revenue && revenue.debit === 1000000 && revenue.credit === 0, 'revenue balance is zeroed');
  assert.equal(result.lines.every((l) => l.docNo === 'YE-CLOSE-2026'), true);
});

test('year-end close for a loss debits retained earnings; no activity returns null', () => {
  const lossYear = [
    line({ period: '2026-02', docNo: 'EXP-1', accountNo: '600000', accountName: 'Operating Expenses', debit: 900, credit: 0 }),
    line({ period: '2026-02', docNo: 'EXP-1', accountNo: '100000', debit: 0, credit: 900 }),
    line({ period: '2026-02', docNo: 'SLS-1', accountNo: '400000', accountName: 'Revenue from Customer Contracts (IFRS 15)', debit: 0, credit: 100 }),
    line({ period: '2026-02', docNo: 'SLS-1', accountNo: '110000', debit: 100, credit: 0 }),
  ];
  const loss = buildYearEndCloseEntries(lossYear, INITIAL_CHART_OF_ACCOUNTS, { year: 2026, period: '2026-12', date: '2026-12-31', currency: 'GHS', username: 'owner', canCheck: true, clientId: 2 });
  assert.ok(loss && loss.net === -800, 'loss of 800 transferred');
  const re = loss!.lines.find((l) => l.accountNo === '310000');
  assert.ok(re && re.debit === 800, 'loss debits retained earnings');

  const none = buildYearEndCloseEntries([], INITIAL_CHART_OF_ACCOUNTS, { year: 2027, period: '2027-12', date: '2027-12-31', currency: 'GHS', username: 'owner', canCheck: true, clientId: 2 });
  assert.equal(none, null, 'no P/L activity — nothing to close');
});
