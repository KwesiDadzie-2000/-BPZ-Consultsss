import assert from 'node:assert/strict';
import test from 'node:test';

import {
  INITIAL_CHART_OF_ACCOUNTS,
  INITIAL_EMPLOYEES,
  SEED_OPENING_ENTRIES,
} from '../src/data/accountingSeed';
import {
  computeEmployeeMonthlyPayroll,
  normalizePayrollRecord,
  round2,
  SSNIT_EMPLOYEE_RATE,
  SSNIT_EMPLOYER_RATE,
} from '../src/utils/payrollCalculator';
import { validateJournalLines } from '../src/lib/journalValidation';
import {
  isBalancedDocument,
  calculateSupplierSettlement,
  computePoVat,
  r2,
} from '../src/utils/transactionMath';
import {
  aggregateTrialBalance,
  buildCashFlow,
  buildCostCentreReport,
  sectorCitRate,
} from '../src/utils/reports';
import { buildPrepaymentSchedule, validateSchedule } from '../src/utils/prepayments';
import type { ACDOCALine, EmployeeProfile } from '../src/types/accounting';

const memory = new Map<string, string>();
Object.defineProperty(globalThis, 'localStorage', {
  configurable: true,
  value: {
    getItem: (k: string) => memory.get(k) ?? null,
    setItem: (k: string, v: string) => void memory.set(k, v),
    removeItem: (k: string) => void memory.delete(k),
  },
});

const COA_ACCOUNTS = new Set(INITIAL_CHART_OF_ACCOUNTS.map((a) => a.accountNo));
const PERIOD = '2026-10';
const DATE = '2026-10-15';

let lineSeq = 0;
const line = (clientId: number, docNo: string, accountNo: string, debit: number, credit: number, extra?: Partial<ACDOCALine>): ACDOCALine => ({
  id: `E2E-${++lineSeq}`,
  docNo,
  period: PERIOD,
  date: DATE,
  module: 'FI',
  docType: 'JE',
  accountNo,
  accountName: 'Test account',
  costCenter: 'CC-OPS',
  debit,
  credit,
  currency: 'GHS',
  description: 'sector e2e transaction',
  createdBy: 'owner',
  clientId,
  ...extra,
});

const assertPostable = (lines: ACDOCALine[], allowedClientIds: number[] = [1, 2, 3, 4], closedPeriodKeys: Set<string> = new Set()) => {
  for (const l of lines) assert.ok(COA_ACCOUNTS.has(l.accountNo), `account ${l.accountNo} must exist in the firm COA`);
  assert.equal(isBalancedDocument(lines), true, `document ${lines[0].docNo} must balance in the ledger`);
  const error = validateJournalLines(lines, { allowedClientIds, closedPeriodKeys, coaAccountNos: COA_ACCOUNTS });
  assert.equal(error, null, `document ${lines[0].docNo} must be postable server-side`);
};

const tbBalances = (lines: ACDOCALine[]) => {
  const dr = lines.reduce((n, l) => n + Math.round(l.debit * 100), 0);
  const cr = lines.reduce((n, l) => n + Math.round(l.credit * 100), 0);
  assert.equal(dr, cr, 'entity trial balance must have Dr = Cr');
};

const buildPayrollDocument = (clientId: number, employees: EmployeeProfile[], currency: string) => {
  const records = employees.filter((e) => e.status === 'active').map((e) =>
    computeEmployeeMonthlyPayroll({ employee: e, period: PERIOD })
  );
  const gross = round2(records.reduce((s, r) => s + r.grossPay, 0));
  const erSsnit = round2(records.reduce((s, r) => s + r.ssnitEmployerCost, 0));
  const eeSsnit = round2(records.reduce((s, r) => s + r.ssnitTier1Employee, 0));
  const paye = round2(records.reduce((s, r) => s + r.payeTax, 0));
  const other = round2(records.reduce((s, r) => s + r.totalCustomDeductions, 0));
  const net = round2(records.reduce((s, r) => s + r.netSalary, 0));
  const docNo = `PAYROLL-${PERIOD}`;
  const base = { period: PERIOD, date: DATE, module: 'HR' as const, docType: 'STAT' as const, costCenter: 'CC-HR', currency, description: 'payroll', createdBy: 'owner', clientId };
  const lines: ACDOCALine[] = [
    line(clientId, docNo, '510000', gross, 0, { ...base }),
    line(clientId, docNo, '511000', erSsnit, 0, { ...base }),
    line(clientId, docNo, '205000', 0, net, { ...base }),
    line(clientId, docNo, '206000', 0, round2(eeSsnit + erSsnit), { ...base }),
    line(clientId, docNo, '207000', 0, paye, { ...base }),
    ...(other > 0 ? [line(clientId, docNo, '208000', 0, other, { ...base })] : []),
  ];
  return { records, lines, gross, erSsnit, eeSsnit, paye, other, net };
};

/* ============================ MINING (CLI-001, GHS) ============================ */

test('mining: capex purchase, ore sales, COGS, receipt & WHT settlement form a closed loop', () => {
  const clientId = 2;
  // 1. Capital equipment on credit, standard 20% VAT recoverable.
  const capex = computePoVat(1, 416666.67, 'standard', 20);
  assertPostable([
    line(clientId, 'PO-E2E-MIN-1', '132000', capex.net, 0),
    line(clientId, 'PO-E2E-MIN-1', '125000', capex.vat, 0),
    line(clientId, 'PO-E2E-MIN-1', '200000', 0, capex.gross),
  ], [clientId]);

  // 2. Ore sales on credit with output VAT.
  assertPostable([
    line(clientId, 'SLS-E2E-MIN-1', '110000', 1200000, 0),
    line(clientId, 'SLS-E2E-MIN-1', '400000', 0, 1000000),
    line(clientId, 'SLS-E2E-MIN-1', '220000', 0, 200000),
  ], [clientId]);

  // 3. Cost of goods extracted.
  assertPostable([
    line(clientId, 'COGS-E2E-MIN-1', '500000', 300000, 0),
    line(clientId, 'COGS-E2E-MIN-1', '120000', 0, 300000),
  ], [clientId]);

  // 4. Customer receipt to bank.
  assertPostable([
    line(clientId, 'RCV-E2E-MIN-1', '100000', 1200000, 0),
    line(clientId, 'RCV-E2E-MIN-1', '110000', 0, 1200000),
  ], [clientId]);

  // 5. Supplier settlement with 3% income WHT and 7% VAT withholding.
  const settleGross = r2(capex.gross * 0.5);
  const settlement = calculateSupplierSettlement({ invoiceGross: capex.gross, invoiceTaxableValue: capex.net, alreadyPaid: 0, paymentGross: settleGross, incomeWhtRate: 3, vatWithholdingRate: 7 });
  const cashTotal = r2(settlement.cash + settlement.incomeWht + settlement.vatWithheld);
  assert.equal(cashTotal, settleGross, 'settlement cash + WHT must equal the payment');
  assertPostable([
    line(clientId, 'PAY-E2E-MIN-1', '200000', settleGross, 0),
    line(clientId, 'PAY-E2E-MIN-1', '209000', 0, settlement.incomeWht),
    line(clientId, 'PAY-E2E-MIN-1', '221000', 0, settlement.vatWithheld),
    line(clientId, 'PAY-E2E-MIN-1', '100000', 0, settlement.cash),
  ], [clientId]);

  // 6. Mining CIT uses the sector rate (35% under Act 729).
  const cit = sectorCitRate('Mining');
  assert.equal(cit.rate, 35);
});

test('mining payroll: statutory 18.5% SSNIT split and a balanced PAYROLL document', () => {
  const clientId = 2;
  // Untagged seeded employees belong to the demonstration client (CLI-001, id 2).
  const { records, lines } = buildPayrollDocument(clientId, INITIAL_EMPLOYEES.filter((e) => (e.clientId ?? 2) === clientId), 'GHS');
  assert.ok(records.length > 0, 'seeded mining employees must exist');
  for (const r of records) {
    if (r.ssnitExempt || r.exemptTier1 || r.exemptTier2) {
      // Documented exemptions (e.g. expatriate) zero out the applicable pension lines.
      if (r.ssnitExempt || r.exemptTier1) {
        assert.equal(r.ssnitTier1Employee, 0);
        assert.equal(r.ssnitEmployerCost, 0);
        assert.equal(r.ssnitTier1Allocation, 0);
      }
      if (r.ssnitExempt || r.exemptTier2) assert.equal(r.ssnitTier2Allocation, 0);
      if (!r.isResident) assert.equal(r.payeTax, round2(r.grossPay * 0.2), 'non-resident flat 20%');
      continue;
    }
    // Statutory split: 5.5% employee deduction + 13% employer cost of the insurable basic.
    assert.equal(r.ssnitTier1Employee, round2((r.ssnitInsurableBase * SSNIT_EMPLOYEE_RATE) / 100));
    assert.equal(r.ssnitEmployerCost, round2((r.ssnitInsurableBase * SSNIT_EMPLOYER_RATE) / 100));
    // Tier 2 5% mandatory allocation funded inside the 18.5% — never a separate deduction.
    assert.equal(r.ssnitTier2Employee, 0);
    assert.equal(r.ssnitTier1Allocation + r.ssnitTier2Allocation, r.ssnitTier1Employee + r.ssnitEmployerCost);
  }
  assertPostable(lines, [clientId]);
});

/* ============================ AGRIBUSINESS (CLI-002, GHS) ============================ */

test('agribusiness: biological asset growth, input purchase, crop sales and prepayment amortisation', () => {
  const clientId = 3;
  // 1. Seasonal crop growth recognised in biological assets (IAS 41).
  assertPostable([
    line(clientId, 'BIO-E2E-AG-1', '124000', 250000, 0),
    line(clientId, 'BIO-E2E-AG-1', '400000', 0, 250000),
  ], [clientId]);

  // 2. Fertiliser input on credit, standard VAT.
  const fert = computePoVat(200, 350, 'standard', 20);
  assertPostable([
    line(clientId, 'PO-E2E-AG-1', '120000', fert.net, 0),
    line(clientId, 'PO-E2E-AG-1', '125000', fert.vat, 0),
    line(clientId, 'PO-E2E-AG-1', '200000', 0, fert.gross),
  ], [clientId]);

  // 3. Crop sales.
  assertPostable([
    line(clientId, 'SLS-E2E-AG-1', '110000', 640000, 0),
    line(clientId, 'SLS-E2E-AG-1', '400000', 0, 533333.33),
    line(clientId, 'SLS-E2E-AG-1', '220000', 0, 106666.67),
  ], [clientId]);

  // 4. Six-month insurance premium prepaid and straight-line amortised.
  const schedule = buildPrepaymentSchedule({ prepaymentId: 'PRE-E2E-AG', clientId, totalAmount: 60000, benefitStart: '2026-07-01', termMonths: 6, method: 'straight_line' });
  assert.equal(round2(schedule.reduce((n, l) => n + l.amount, 0)), 60000, 'schedule must reconcile to the premium');
  const record = {
    id: 'PRE-E2E-AG', clientId, code: 'PRE-E2E-AG', title: 'Crop insurance', category: 'Insurance' as const,
    vendorName: 'V', reference: 'R', paymentDate: '2026-07-01', benefitStart: '2026-07-01', benefitEnd: '2026-12-31',
    termMonths: 6, totalAmount: 60000, prepaidAccountNo: '116000', prepaidAccountName: 'Prepayments',
    expenseAccountNo: '630000', expenseAccountName: 'Insurance', costCenter: 'CC-OPS',
    method: 'straight_line' as const, source: 'bank' as const, status: 'active' as const, createdBy: 'owner', createdAt: '2026-07-01T00:00:00.000Z',
  };
  assert.equal(validateSchedule(record, schedule), null);
  assertPostable([
    line(clientId, 'PRE-E2E-AG-REC', '630000', schedule[0].amount, 0),
    line(clientId, 'PRE-E2E-AG-REC', '116000', 0, schedule[0].amount),
  ], [clientId]);
});

/* ============================ LOGISTICS (CLI-003, GBP) ============================ */

test('logistics (UK): transactions post in the GBP functional currency and balance', () => {
  const clientId = 4;
  const gbp = { currency: 'GBP' };
  assertPostable([
    line(clientId, 'SLS-E2E-UK-1', '110000', 180000, 0, gbp),
    line(clientId, 'SLS-E2E-UK-1', '400000', 0, 150000, gbp),
    line(clientId, 'SLS-E2E-UK-1', '220000', 0, 30000, gbp),
  ], [clientId]);
  assertPostable([
    line(clientId, 'RCV-E2E-UK-1', '100000', 180000, 0, gbp),
    line(clientId, 'RCV-E2E-UK-1', '110000', 0, 180000, gbp),
  ], [clientId]);
});

/* ============================ CROSS-ENTITY INTEGRITY ============================ */

test('per-entity period freeze: closing a period for one entity never freezes another', () => {
  const closed = new Set(['2:2026-10']);
  const miningFrozen = [line(2, 'JE-E2E-F1', '510000', 100, 0), line(2, 'JE-E2E-F1', '202000', 0, 100)];
  assert.match(validateJournalLines(miningFrozen, { allowedClientIds: [2, 3], closedPeriodKeys: closed, coaAccountNos: COA_ACCOUNTS })!, /closed and frozen for this entity/);
  const agroOpen = [line(3, 'JE-E2E-F2', '510000', 100, 0), line(3, 'JE-E2E-F2', '202000', 0, 100)];
  assert.equal(validateJournalLines(agroOpen, { allowedClientIds: [2, 3], closedPeriodKeys: closed, coaAccountNos: COA_ACCOUNTS }), null);
});

test('entity isolation: a client session may only post to its own entity', () => {
  const lines = [line(2, 'JE-E2E-ISO-1', '510000', 100, 0), line(2, 'JE-E2E-ISO-1', '202000', 0, 100)];
  const asAgroSession = validateJournalLines(lines, { allowedClientIds: [3], closedPeriodKeys: new Set(), coaAccountNos: COA_ACCOUNTS });
  assert.match(asAgroSession!, /different client/);
  const asOwn = validateJournalLines(lines, { allowedClientIds: [2], closedPeriodKeys: new Set(), coaAccountNos: COA_ACCOUNTS });
  assert.equal(asOwn, null);
});

test('trial balances are computed from each entity own lines only and balance', () => {
  const mining = [
    line(2, 'JE-E2E-TB-1', '100000', 50000, 0),
    line(2, 'JE-E2E-TB-1', '200000', 0, 50000),
  ];
  const agro = [
    line(3, 'JE-E2E-TB-2', '100000', 75000, 0),
    line(3, 'JE-E2E-TB-2', '200000', 0, 75000),
  ];
  const combined = [...mining, ...agro];
  const tbMin = aggregateTrialBalance(combined.filter((l) => l.clientId === 2), INITIAL_CHART_OF_ACCOUNTS);
  const dr = tbMin.reduce((n, r) => n + r.dr, 0);
  const cr = tbMin.reduce((n, r) => n + r.cr, 0);
  assert.equal(dr, cr, 'mining trial balance must balance from its own lines');
  assert.ok(dr / 100 === 50000, 'mining TB must not include agro lines');
  const flow = buildCashFlow(mining, INITIAL_CHART_OF_ACCOUNTS, '2026-10-01', '2026-10-31');
  assert.ok(Math.abs(flow.residual) < 0.01, 'cash flow must reconcile to the cash ledger (residual 0)');
  const cc = buildCostCentreReport(mining, INITIAL_CHART_OF_ACCOUNTS, '2026-10-01', '2026-10-31');
  assert.ok(Math.abs(cc.residual) < 0.01, 'cost-centre P&L must reconcile to entity profit');
});

test('every seeded opening balance schedule is balanced before first post (Dr = Cr)', () => {
  for (const [clientId, entries] of Object.entries(SEED_OPENING_ENTRIES)) {
    const dr = Object.values(entries).reduce((n, e) => n + e.dr, 0);
    const cr = Object.values(entries).reduce((n, e) => n + e.cr, 0);
    assert.equal(round2(dr), round2(cr), `client ${clientId} opening schedule must have Dr = Cr`);
    assert.ok(dr > 0, `client ${clientId} opening schedule must not be empty`);
  }
});

test('legacy payroll records saved under the old model migrate to the statutory 18.5% model', () => {
  // Simulates a record persisted before the fix: SSNIT on gross, extra T2 deduction.
  const legacy = {
    id: 'PAY-2026-05-E001', clientId: 2, employeeId: 1, bpNo: 'E001', name: 'Legacy', department: 'Ops',
    role: 'Staff', period: '2026-05', currency: 'GHS', isResident: true, exemptTier1: false, exemptTier2: false,
    ssnitExempt: false, basicSalary: 10000, allowances: 2000, bonusAdditions: 0, grossPay: 12000,
    taxRelief: 0, ssnitTier1Employee: 660, ssnitTier2Employee: 600, ssnitEmployerCost: 1300,
    taxableIncome: 10740, payeTax: 2200, customDeductions: [], totalCustomDeductions: 0,
    totalEmployeeDeductions: 3460, netSalary: 8540, employerTotalCost: 13300, status: 'Posted',
  } as any;
  const migrated = normalizePayrollRecord(legacy);
  assert.equal(migrated.ssnitInsurableBase, 10000, 'base must move from gross to basic');
  assert.equal(migrated.ssnitTier1Employee, 550);
  assert.equal(migrated.ssnitTier2Employee, 0, 'the extra Tier 2 employee deduction is removed');
  assert.equal(migrated.ssnitEmployerCost, 1300);
  assert.equal(migrated.ssnitTier2Allocation, 500);
  assert.equal(migrated.ssnitTier1Allocation + migrated.ssnitTier2Allocation, 1850, '18.5% of basic must be preserved');
  // PAYE and net re-derive from the statutory base.
  assert.equal(migrated.totalEmployeeDeductions, round2(migrated.ssnitTier1Employee + migrated.payeTax));
  assert.equal(migrated.netSalary, round2(migrated.grossPay - migrated.totalEmployeeDeductions));
  // Idempotent for already-migrated records.
  assert.equal(normalizePayrollRecord(migrated), migrated);
});

test('all 2026 payroll documents balance in cents and carry statutory payable accounts', () => {
  for (const clientId of [2]) {
    const { lines, gross, erSsnit, eeSsnit, paye, other, net } = buildPayrollDocument(clientId, INITIAL_EMPLOYEES.filter((e) => (e.clientId ?? 2) === clientId), 'GHS');
    const dr = lines.reduce((n, l) => n + Math.round(l.debit * 100), 0);
    const cr = lines.reduce((n, l) => n + Math.round(l.credit * 100), 0);
    assert.equal(dr, cr, 'payroll document must balance exactly in cents');
    assert.equal(round2(gross + erSsnit), round2(net + eeSsnit + erSsnit + paye + other), 'gross + employer SSNIT = net + all payables');
  }
});
