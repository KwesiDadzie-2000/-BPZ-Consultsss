import assert from 'node:assert/strict';
import test from 'node:test';

import {
  INITIAL_CHART_OF_ACCOUNTS,
  INITIAL_CLIENTS,
  INITIAL_PURCHASE_ORDERS,
  SEED_OPENING_ENTRIES,
} from '../src/data/accountingSeed';
import {
  computeCustomerVatWithholding,
  computeExpenseVatSplit,
  computePoVat,
} from '../src/utils/transactionMath';

/* ---------- Vendor VAT treatments on purchase orders ---------- */

test('PO VAT treatment: standard adds 20% input VAT on the quotation', () => {
  const v = computePoVat(40, 2000, 'standard', 20);
  assert.deepEqual(v, { net: 80000, vat: 16000, gross: 96000 });
});

test('PO VAT treatment: VAT-inclusive quotation splits the input VAT out of the price', () => {
  const v = computePoVat(40, 2400, 'inclusive', 20); // quoted 96,000 incl. VAT
  assert.deepEqual(v, { net: 80000, vat: 16000, gross: 96000 });
});

test('PO VAT treatment: non-VAT vendor and zero-rated bills carry no input VAT', () => {
  assert.deepEqual(computePoVat(10, 500, 'none', 20), { net: 5000, vat: 0, gross: 5000 });
  assert.deepEqual(computePoVat(10, 500, 'zero_rated', 20), { net: 5000, vat: 0, gross: 5000 });
});

test('seeded purchase orders carry standard VAT treatment and a net amount', () => {
  for (const po of INITIAL_PURCHASE_ORDERS) {
    assert.equal(po.vatTreatment, 'standard', `${po.poNo} is standard-rated`);
    assert.equal(po.netAmount, po.qty * po.unitPrice, `${po.poNo} net amount is the VAT-exclusive consideration`);
    const v = computePoVat(po.qty, po.unitPrice, po.vatTreatment!, 20);
    assert.equal(v.vat, po.vatRecoverable, `${po.poNo} input VAT matches`);
    assert.equal(v.gross, po.totalAmount, `${po.poNo} gross matches`);
    assert.ok(po.quotationRef, `${po.poNo} references its quotation/tender`);
  }
});

/* ---------- VAT-inclusive expense bills ---------- */

test('expense VAT split: VAT-inclusive bill splits recoverable input VAT; non-VAT bill does not', () => {
  assert.deepEqual(computeExpenseVatSplit(1200, true, 20), { net: 1000, vat: 200, gross: 1200 });
  assert.deepEqual(computeExpenseVatSplit(1200, false, 20), { net: 1200, vat: 0, gross: 1200 });
});

/* ---------- Customer VAT withholding at source ---------- */

test('customer VAT withholding settles the receivable exactly across partial receipts', () => {
  // Invoice: net 100,000 + 20% VAT stack = 120,000 gross; agent withholds 7% of net = 7,000.
  const gross = 120000;
  const invWht = 7000;
  // Full settlement in one receipt: customer pays 113,000 cash.
  assert.equal(computeCustomerVatWithholding(invWht, gross, 120000, 113000), 7000);
  // Two partial receipts: 50,000 then 63,000 cash — withholding sums to the full 7,000.
  const w1 = computeCustomerVatWithholding(invWht, gross, 120000, 50000);
  const paidAfter1 = 50000 + w1;
  const w2 = computeCustomerVatWithholding(invWht, gross, gross - paidAfter1, 63000);
  assert.equal(Math.round((w1 + w2) * 100) / 100, 7000, 'withholding across receipts sums to the invoice total');
  assert.equal(Math.round((paidAfter1 + 63000 + w2) * 100) / 100, gross, 'receivable fully settled');
  // No withholding for non-agent invoices.
  assert.equal(computeCustomerVatWithholding(0, gross, gross, 113000), 0);
});

/* ---------- Per-entity opening trial balances (never pooled) ---------- */

test('every entity owns a balanced, distinct opening trial balance schedule', () => {
  const ledger = new Set(INITIAL_CHART_OF_ACCOUNTS.map((a) => a.accountNo));
  for (const client of INITIAL_CLIENTS) {
    const entries = SEED_OPENING_ENTRIES[client.id];
    assert.ok(entries, `${client.code} has its own opening schedule`);
    let dr = 0;
    let cr = 0;
    for (const [accNo, v] of Object.entries(entries)) {
      assert.ok(ledger.has(accNo), `${client.code} opening account ${accNo} exists in the COA`);
      dr += v.dr;
      cr += v.cr;
    }
    assert.ok(dr > 0, `${client.code} opening schedule has debits`);
    assert.equal(dr, cr, `${client.code} opening schedule balances (Dr = Cr)`);
  }
  // Schedules are distinct per entity (not one pooled schedule).
  const signatures = new Set(INITIAL_CLIENTS.map((c) => JSON.stringify(SEED_OPENING_ENTRIES[c.id])));
  assert.equal(signatures.size, INITIAL_CLIENTS.length, 'each entity has a distinct opening schedule');
});

test('opening schedules capture bank and cash as separate accounts', () => {
  for (const client of INITIAL_CLIENTS) {
    const entries = SEED_OPENING_ENTRIES[client.id];
    assert.ok(entries['100000'], `${client.code} captures a bank opening balance`);
    assert.ok(entries['103000'], `${client.code} captures a cash-on-hand opening balance`);
  }
});
