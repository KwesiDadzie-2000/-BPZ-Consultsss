import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import { auditLog, chartAccounts, closedPeriods, clients, journalEntries, journalLines } from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope } from "@/lib/auth";
import { validateJournalLines, validateMakerChecker } from "@/lib/journalValidation";
import { exactToMinor } from "@/lib/exactMoney";
import { and, eq, inArray, sql } from "drizzle-orm";
import { createHash } from "node:crypto";
import type { ACDOCALine } from "@/types/accounting";

/** Exact document total in integer minor units (no floating-point drift). */
const sumMinor = (amounts: number[]) => amounts.reduce((total, amount) => total + exactToMinor(amount), BigInt(0));

export const dynamic = "force-dynamic";

/**
 * Server-side posting service: validates the document (tenant ownership, open
 * period, chart-of-accounts existence, double entry in minor units, idempotent
 * document number) and inserts it with an audit-trail entry in one transaction.
 */
export async function POST(req: Request) {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });

  let lines: ACDOCALine[];
  try {
    const body = await req.json();
    lines = body?.lines;
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  if (!Array.isArray(lines)) return Response.json({ ok: false, error: "No journal lines provided." }, { status: 400 });

  const isOwner = user.role === "owner";
  const myClientId = user.clientId ?? null;
  const allClients = await db.select().from(clients);
  const allowedClientIds = hasFirmWideScope(user) ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
  const [coa, closed] = await Promise.all([
    db.select().from(chartAccounts),
    db.select().from(closedPeriods),
  ]);
  // Periods are frozen per entity: only the periods closed for this user's own
  // writable clients constrain posting.
  const closedKeys = new Set(
    closed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`)
  );
  // COA scope: firm master plus the writable entities' custom accounts.
  const coaNos = new Set(coa.filter((a) => a.clientId === null || allowedClientIds.includes(a.clientId)).map((a) => a.accountNo));

  const error = validateJournalLines(lines, { allowedClientIds, closedPeriodKeys: closedKeys, coaAccountNos: coaNos });
  if (error) return Response.json({ ok: false, error }, { status: 409 });

  // Segregation of duties: above the maker limit an independent checker is required.
  const mcError = validateMakerChecker(lines, { username: user.username, makerLimit: user.makerLimit });
  if (mcError) return Response.json({ ok: false, error: mcError }, { status: 409 });

  // Group by document: one controlled header per document, one atomic posting.
  const byDocument = new Map<string, ACDOCALine[]>();
  for (const line of lines) {
    const key = `${line.clientId}:${line.docNo}`;
    byDocument.set(key, [...(byDocument.get(key) ?? []), line]);
  }

  for (const [key, documentLines] of byDocument) {
    const [clientIdText, docNo] = key.split(":");
    const clientId = Number(clientIdText);
    // Validate, balance, authorise and write the ledger in ONE transaction.
    // Period locks and account existence are re-read inside the transaction so a
    // concurrent close or account change cannot slip between check and post.
    const outcome = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${key}))`);
      const closed = await tx
        .select()
        .from(closedPeriods)
        .where(inArray(closedPeriods.clientId, allowedClientIds))
        .for("update");
      if (closed.some((c) => c.clientId === clientId && c.period === documentLines[0].period)) {
        return Response.json({ ok: false, error: `Period ${documentLines[0].period} is closed and frozen for this entity.` }, { status: 409 });
      }
      const accounts = await tx.select().from(chartAccounts);
      const accountNos = new Set(accounts.filter((a) => a.active && (a.clientId === null || a.clientId === clientId)).map((a) => a.accountNo));
      const unknown = documentLines.find((l) => !accountNos.has(l.accountNo));
      if (unknown) {
        return Response.json({ ok: false, error: `Account ${unknown.accountNo} does not exist in the chart of accounts for this entity.` }, { status: 409 });
      }

      // Exact balancing in integer minor units; no floating-point drift.
      const drMinor = sumMinor(documentLines.map((l) => l.debit));
      const crMinor = sumMinor(documentLines.map((l) => l.credit));
      if (drMinor <= BigInt(0) || drMinor !== crMinor) {
        return Response.json({ ok: false, error: `Document ${docNo} is not balanced (Dr = Cr required).` }, { status: 409 });
      }

      // Idempotent header: a repeated import or a retried request cannot post the
      // same document twice, and conflicting content is rejected rather than merged.
      const headerId = `jrn_${createHash("sha256").update(`${clientId}:${docNo}`).digest("hex").slice(0, 32)}`;
      const payloadHash = createHash("sha256")
        .update(JSON.stringify(documentLines.map((l) => [l.accountNo, l.debit, l.credit, l.description, l.id])))
        .digest("hex");
      const inserted = await tx
        .insert(journalEntries)
        .values({
          id: headerId,
          clientId,
          docNo,
          period: documentLines[0].period,
          entryDate: documentLines[0].date,
          module: documentLines[0].module,
          docType: documentLines[0].docType,
          currency: documentLines[0].currency,
          description: documentLines[0].description,
          status: "posted",
          version: 1,
          createdBy: documentLines[0].createdBy,
          checkedBy: documentLines[0].checkedBy ?? null,
          postedBy: user.username,
          postedAt: new Date().toISOString(),
          payloadHash,
        })
        .onConflictDoNothing({ target: [journalEntries.clientId, journalEntries.docNo] })
        .returning({ id: journalEntries.id });

      if (!inserted.length) {
        const [existing] = await tx.select().from(journalEntries)
          .where(and(eq(journalEntries.clientId, clientId), eq(journalEntries.docNo, docNo)))
          .limit(1);
        if (existing?.payloadHash === payloadHash) return { idempotent: true as const };
        return Response.json({ ok: false, error: `Document ${docNo} already posted with different content.` }, { status: 409 });
      }

      const sentIds = new Set(documentLines.map((l) => l.id));
      const alreadyThere = await tx.select({ id: journalLines.id }).from(journalLines)
        .where(and(eq(journalLines.clientId, clientId), eq(journalLines.docNo, docNo)));
      if (alreadyThere.length) {
        const same = alreadyThere.length === sentIds.size && alreadyThere.every((l) => sentIds.has(l.id));
        if (same) return { idempotent: true as const };
        return Response.json({ ok: false, error: `Document ${docNo} already posted with different content.` }, { status: 409 });
      }

      await tx.insert(journalLines).values(
        documentLines.map((l, index) => ({
          id: l.id, journalEntryId: headerId, lineNo: index + 1,
          docNo: l.docNo, period: l.period, date: l.date, module: l.module, docType: l.docType,
          accountNo: l.accountNo, accountName: l.accountName, costCenter: l.costCenter ?? null, debit: l.debit,
          credit: l.credit, currency: l.currency, description: l.description, createdBy: l.createdBy,
          checkedBy: l.checkedBy ?? null, isReversed: l.isReversed ?? false, reference: l.reference ?? null,
          clientId: l.clientId,
        }))
      );
      await tx.insert(auditLog).values({
        id: crypto.randomUUID(),
        timestamp: new Date().toISOString(),
        userId: user.username,
        username: user.username,
        action: "POST_JOURNAL",
        target: docNo,
        details: `${documentLines.length} line(s), debits ${(Number(drMinor) / 100).toFixed(2)}`,
        clientId,
        entityType: "journal_entry",
        entityId: headerId,
        correlationId: payloadHash.slice(0, 16),
      });
      return { idempotent: false as const };
    });

    if (outcome instanceof Response) return outcome;
    if (outcome.idempotent) return Response.json({ ok: true, idempotent: true });
  }

  return Response.json({ ok: true, lines });
}

/* ------------------------------------------------------------------------- *
 * Document maintenance (General Ledger desk)
 * ------------------------------------------------------------------------- */

interface DocumentScope {
  user: NonNullable<Awaited<ReturnType<typeof getSessionUser>>>;
  clientId: number;
  docNo: string;
  existing: (typeof journalLines.$inferSelect)[];
}

/**
 * Loads a document and applies the shared maintenance rules:
 *  - tenant ownership, open period, not reversed / not a reversal;
 *  - restricted or suspended users may not maintain documents;
 *  - a maker may only maintain their own documents within their maker limit;
 *    checkers (and the owner) may maintain any document of their entities.
 */
async function loadDocumentScope(req: Request, body: { clientId?: number; docNo?: string }): Promise<DocumentScope | Response> {
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
  if (user.status === "restricted" || user.status === "suspended") {
    return Response.json({ ok: false, error: "Your posting authority is restricted — document maintenance is not permitted." }, { status: 403 });
  }
  const clientId = Number(body?.clientId);
  const docNo = String(body?.docNo || "").trim();
  if (!Number.isFinite(clientId) || !docNo) return Response.json({ ok: false, error: "clientId and docNo are required." }, { status: 400 });

  const allClients = await db.select().from(clients);
  const allowedClientIds = hasFirmWideScope(user) ? allClients.map((c) => c.id) : user.clientId == null ? [] : [user.clientId];
  if (!allowedClientIds.includes(clientId)) return Response.json({ ok: false, error: "Document belongs to a different client." }, { status: 403 });

  const existing = (await db.select().from(journalLines).where(eq(journalLines.docNo, docNo))).filter((l) => l.clientId === clientId);
  if (!existing.length) return Response.json({ ok: false, error: `Document ${docNo} was not found on the server.` }, { status: 404 });
  if (existing.some((l) => l.isReversed)) return Response.json({ ok: false, error: `Document ${docNo} has been reversed and is frozen.` }, { status: 409 });
  if (existing.some((l) => l.docType === "REV")) return Response.json({ ok: false, error: `Reversal documents are immutable.` }, { status: 409 });

  const closed = await db.select().from(closedPeriods);
  const frozen = new Set(closed.map((c) => `${c.clientId}:${c.period}`));
  if (existing.some((l) => frozen.has(`${l.clientId}:${l.period}`))) {
    return Response.json({ ok: false, error: `Period ${existing[0].period} is closed and frozen for this entity.` }, { status: 409 });
  }

  const total = existing.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
  const privileged = user.role === "owner" || user.canCheck;
  if (!privileged) {
    if (existing.some((l) => l.createdBy !== user.username)) {
      return Response.json({ ok: false, error: "Only the maker of a document (or a checker) may maintain it." }, { status: 403 });
    }
    if (user.makerLimit > 0 && total > user.makerLimit) {
      return Response.json({ ok: false, error: "This document exceeds your maker limit — ask a checker to maintain it." }, { status: 403 });
    }
  }
  return { user, clientId, docNo, existing };
}

const audit = (tx: Parameters<Parameters<typeof db.transaction>[0]>[0], user: { username: string }, action: string, target: string, details: string, clientId: number) =>
  tx.insert(auditLog).values({
    id: crypto.randomUUID(), timestamp: new Date().toISOString(), userId: user.username, username: user.username,
    action, target, details, clientId,
  });

/**
 * Replaces the lines of ONE posted document (General Ledger "edit document").
 * The document number is kept; new lines must balance, reference existing
 * accounts, stay in the same entity and in an open period.
 */
export async function PATCH(req: Request) {
  await ensureDatabaseReady();
  let body: { clientId?: number; docNo?: string; lines?: ACDOCALine[]; reason?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  const scope = await loadDocumentScope(req, body);
  if (scope instanceof Response) return scope;
  const { user, clientId, docNo, existing } = scope;
  const lines = Array.isArray(body.lines) ? body.lines : [];
  if (!lines.length) return Response.json({ ok: false, error: "No journal lines provided." }, { status: 400 });
  if (lines.some((l) => l.docNo !== docNo || l.clientId !== clientId)) {
    return Response.json({ ok: false, error: "Edited lines must keep the document number and entity." }, { status: 400 });
  }

  const allClients = await db.select().from(clients);
  const allowedClientIds = hasFirmWideScope(user) ? allClients.map((c) => c.id) : user.clientId == null ? [] : [user.clientId];
  const [coa, closed] = await Promise.all([db.select().from(chartAccounts), db.select().from(closedPeriods)]);
  const closedKeys = new Set(closed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`));
  const coaNos = new Set(coa.filter((a) => a.clientId === null || allowedClientIds.includes(a.clientId)).map((a) => a.accountNo));
  const error = validateJournalLines(lines, { allowedClientIds, closedPeriodKeys: closedKeys, coaAccountNos: coaNos });
  if (error) return Response.json({ ok: false, error }, { status: 409 });
  // Above the maker limit the edited document still needs an independent checker.
  const privileged = user.role === "owner" || user.canCheck;
  const total = lines.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
  if (!privileged && user.makerLimit > 0 && total > user.makerLimit) {
    return Response.json({ ok: false, error: "The edited document exceeds your maker limit — submit it for approval instead." }, { status: 403 });
  }
  // Line ids must stay unique across the ledger.
  const incomingIds = new Set(lines.map((l) => l.id));
  if (incomingIds.size !== lines.length) return Response.json({ ok: false, error: "Duplicate line ids in the edited document." }, { status: 400 });

  await db.transaction(async (tx) => {
    await tx.delete(journalLines).where(inArray(journalLines.id, existing.map((l) => l.id)));
    await tx.insert(journalLines).values(
      lines.map((l) => ({
        id: l.id, docNo: l.docNo, period: l.period, date: l.date, module: l.module, docType: l.docType,
        accountNo: l.accountNo, accountName: l.accountName, costCenter: l.costCenter ?? null, debit: l.debit,
        credit: l.credit, currency: l.currency, description: l.description, createdBy: l.createdBy,
        checkedBy: l.checkedBy ?? null, isReversed: false, reference: l.reference ?? null, clientId: l.clientId,
      }))
    );
    const before = existing.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
    await audit(tx, user, "EDIT_JOURNAL", docNo, `${existing.length} → ${lines.length} line(s), debits ${before.toFixed(2)} → ${total.toFixed(2)}${body.reason ? ` · ${body.reason}` : ""}`, clientId);
  });
  return Response.json({ ok: true, lines });
}

/** Deletes ONE posted document (owner or checker only; open periods only). */
export async function DELETE(req: Request) {
  await ensureDatabaseReady();
  let body: { clientId?: number; docNo?: string; reason?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  const scope = await loadDocumentScope(req, body);
  if (scope instanceof Response) return scope;
  const { user, clientId, docNo, existing } = scope;
  if (!(user.role === "owner" || user.canCheck)) {
    return Response.json({ ok: false, error: "Only the firm owner or a checker may delete a posted document. Makers should reverse it instead." }, { status: 403 });
  }
  await db.transaction(async (tx) => {
    await tx.delete(journalLines).where(inArray(journalLines.id, existing.map((l) => l.id)));
    const total = existing.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
    await audit(tx, user, "DELETE_JOURNAL", docNo, `${existing.length} line(s) removed, debits ${total.toFixed(2)}${body.reason ? ` · ${body.reason}` : ""}`, clientId);
  });
  return Response.json({ ok: true });
}
