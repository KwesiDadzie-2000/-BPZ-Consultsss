/**
 * Idempotent DDL generated from `src/db/schema.ts` with `drizzle-kit export`.
 *
 * Regenerate after schema changes:
 *   npx drizzle-kit export --sql > /tmp/ddl.sql   (then convert to IF NOT EXISTS)
 *
 * Applied automatically by `ensureDatabaseReady()` so a fresh database never
 * produces `relation "users" does not exist` (the original "Login failed." bug).
 */
export const SCHEMA_DDL: string[] = [
  "CREATE TABLE IF NOT EXISTS \"approval_requests\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"client_code\" text NOT NULL,\n\t\"client_name\" text NOT NULL,\n\t\"doc_no\" text NOT NULL,\n\t\"doc_type\" text NOT NULL,\n\t\"amount\" double precision NOT NULL,\n\t\"requested_by\" text NOT NULL,\n\t\"requested_at\" text NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"reason_for_approval\" text NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"reviewed_by\" text,\n\t\"reviewed_at\" text,\n\t\"rejection_reason\" text,\n\t\"payload\" jsonb\n)",
  "CREATE TABLE IF NOT EXISTS \"audit_log\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"timestamp\" text NOT NULL,\n\t\"user_id\" text NOT NULL,\n\t\"username\" text NOT NULL,\n\t\"action\" text NOT NULL,\n\t\"target\" text NOT NULL,\n\t\"details\" text NOT NULL,\n\t\"client_id\" integer\n)",
  "CREATE TABLE IF NOT EXISTS \"bank_accounts\" (\n\t\"id\" integer PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"code\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"bank_name\" text NOT NULL,\n\t\"account_no\" text NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"balance\" double precision DEFAULT 0 NOT NULL,\n\t\"kind\" text,\n\t\"gl_account\" text\n)",
  "CREATE TABLE IF NOT EXISTS \"business_partners\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer,\n\t\"code\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"type\" text NOT NULL,\n\t\"tin\" text NOT NULL,\n\t\"email\" text NOT NULL,\n\t\"phone\" text NOT NULL,\n\t\"address\" text NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"is_vat_withholding_agent\" boolean DEFAULT false NOT NULL,\n\t\"vat_withholding_rate\" double precision,\n\t\"is_cst_applicable\" boolean DEFAULT false NOT NULL,\n\t\"is_tourism_levy_applicable\" boolean DEFAULT false NOT NULL,\n\t\"is_vat_registered\" boolean\n)",
  "CREATE TABLE IF NOT EXISTS \"chart_accounts\" (\n\t\"id\" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name \"chart_accounts_id_seq\" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),\n\t\"account_no\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"type\" text NOT NULL,\n\t\"category\" text NOT NULL,\n\t\"active\" boolean DEFAULT true NOT NULL,\n\t\"is_custom\" boolean DEFAULT false NOT NULL,\n\t\"client_id\" integer\n)",
  "CREATE TABLE IF NOT EXISTS \"clients\" (\n\t\"id\" integer PRIMARY KEY NOT NULL,\n\t\"code\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"sector\" text NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"jurisdiction\" text NOT NULL,\n\t\"reg_number\" text NOT NULL,\n\t\"is_parent\" boolean DEFAULT false NOT NULL,\n\t\"assigned_services\" jsonb,\n\t\"admin_username\" text,\n\t\"admin_email\" text,\n\t\"login_url\" text\n)",
  "CREATE TABLE IF NOT EXISTS \"closed_periods\" (\n\t\"id\" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name \"closed_periods_id_seq\" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),\n\t\"client_id\" integer NOT NULL,\n\t\"period\" text NOT NULL,\n\t\"closed_at\" text NOT NULL,\n\t\"closed_by\" text NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"company_profiles\" (\n\t\"client_id\" integer PRIMARY KEY NOT NULL,\n\t\"legal_name\" text NOT NULL,\n\t\"trading_name\" text NOT NULL,\n\t\"tin\" text NOT NULL,\n\t\"vat_reg_no\" text NOT NULL,\n\t\"address\" text NOT NULL,\n\t\"phone\" text NOT NULL,\n\t\"email\" text NOT NULL,\n\t\"website\" text NOT NULL,\n\t\"fiscal_year_start\" text NOT NULL,\n\t\"bank_payment_details\" text NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"disclosure_notes\" (\n\t\"id\" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name \"disclosure_notes_id_seq\" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),\n\t\"key\" text NOT NULL,\n\t\"note_number\" integer NOT NULL,\n\t\"title\" text NOT NULL,\n\t\"standard_ref\" text NOT NULL,\n\t\"applicable\" boolean NOT NULL,\n\t\"not_applicable_reason\" text,\n\t\"body\" text NOT NULL,\n\t\"tables\" jsonb,\n\t\"editable_override\" boolean\n)",
  "CREATE TABLE IF NOT EXISTS \"employees\" (\n\t\"id\" integer PRIMARY KEY NOT NULL,\n\t\"client_id\" integer,\n\t\"bp_no\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"role\" text NOT NULL,\n\t\"department\" text NOT NULL,\n\t\"cost_center\" text,\n\t\"jurisdiction\" text NOT NULL,\n\t\"basic_salary\" double precision NOT NULL,\n\t\"allowances\" double precision DEFAULT 0 NOT NULL,\n\t\"ssnit_number\" text NOT NULL,\n\t\"tin\" text NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"is_resident\" boolean DEFAULT true NOT NULL,\n\t\"exempt_tier1\" boolean DEFAULT false NOT NULL,\n\t\"exempt_tier2\" boolean DEFAULT false NOT NULL,\n\t\"ssnit_exempt\" boolean DEFAULT false NOT NULL,\n\t\"ssnit_exemption_reason\" text,\n\t\"tax_relief\" double precision DEFAULT 0 NOT NULL,\n\t\"relief_type\" text,\n\t\"deductions\" jsonb\n)",
  "CREATE TABLE IF NOT EXISTS \"journal_lines\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"doc_no\" text NOT NULL,\n\t\"period\" text NOT NULL,\n\t\"date\" text NOT NULL,\n\t\"module\" text NOT NULL,\n\t\"doc_type\" text NOT NULL,\n\t\"account_no\" text NOT NULL,\n\t\"account_name\" text NOT NULL,\n\t\"cost_center\" text,\n\t\"debit\" double precision DEFAULT 0 NOT NULL,\n\t\"credit\" double precision DEFAULT 0 NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"created_by\" text NOT NULL,\n\t\"checked_by\" text,\n\t\"is_reversed\" boolean DEFAULT false NOT NULL,\n\t\"reference\" text,\n\t\"client_id\" integer NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"payroll_records\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"record\" jsonb NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"prepayment_records\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"record\" jsonb NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"prepayment_schedules\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"prepayment_id\" text NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"line\" jsonb NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"purchase_orders\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"po_no\" text NOT NULL,\n\t\"vendor_name\" text NOT NULL,\n\t\"item_type\" text NOT NULL,\n\t\"item_description\" text NOT NULL,\n\t\"qty\" double precision NOT NULL,\n\t\"unit_price\" double precision NOT NULL,\n\t\"vat_recoverable\" double precision DEFAULT 0 NOT NULL,\n\t\"total_amount\" double precision NOT NULL,\n\t\"paid_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"date\" text NOT NULL,\n\t\"currency\" text,\n\t\"vat_treatment\" text,\n\t\"net_amount\" double precision,\n\t\"quotation_ref\" text,\n\t\"gl_account\" text NOT NULL,\n\t\"gl_account_name\" text NOT NULL,\n\t\"cost_center\" text NOT NULL,\n\t\"cost_center_name\" text NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"sales_invoices\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"inv_no\" text NOT NULL,\n\t\"customer_name\" text NOT NULL,\n\t\"revenue_stream\" text NOT NULL,\n\t\"net_revenue\" double precision NOT NULL,\n\t\"vat_output\" double precision DEFAULT 0 NOT NULL,\n\t\"cst_amount\" double precision,\n\t\"tourism_levy_amount\" double precision,\n\t\"vat_withheld_by_customer\" double precision,\n\t\"total_receivable\" double precision NOT NULL,\n\t\"paid_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"date\" text NOT NULL\n)",
  // Sessions live in a dedicated table: a `sessions` table left behind by an
  // earlier build (or another app on the same database) has an incompatible
  // shape, and `CREATE TABLE IF NOT EXISTS` would keep it — which broke session
  // lookups and bounced signed-in users back to the login screen.
  "CREATE TABLE IF NOT EXISTS \"bpz_sessions\" (\n\t\"token\" text PRIMARY KEY NOT NULL,\n\t\"user_id\" text NOT NULL,\n\t\"expires_at\" bigint NOT NULL,\n\t\"last_seen_at\" bigint,\n\t\"created_at\" timestamp with time zone DEFAULT now() NOT NULL\n)",
  "CREATE INDEX IF NOT EXISTS \"bpz_sessions_user_idx\" ON \"bpz_sessions\" USING btree (\"user_id\")",
  "CREATE INDEX IF NOT EXISTS \"bpz_sessions_expiry_idx\" ON \"bpz_sessions\" USING btree (\"expires_at\")",
  "CREATE TABLE IF NOT EXISTS \"users\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"username\" text NOT NULL,\n\t\"email\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"role\" text NOT NULL,\n\t\"maker_limit\" double precision DEFAULT 0 NOT NULL,\n\t\"can_check\" boolean DEFAULT false NOT NULL,\n\t\"client_id\" integer,\n\t\"password_hash\" text,\n\t\"password_salt\" text,\n\t\"status\" text DEFAULT 'active' NOT NULL,\n\t\"restriction_reason\" text,\n\t\"permissions\" jsonb,\n\t\"created_at\" timestamp with time zone DEFAULT now() NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"tax_schedule_entries\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"kind\" text NOT NULL,\n\t\"source\" text NOT NULL,\n\t\"source_key\" text,\n\t\"period\" text NOT NULL,\n\t\"date\" text NOT NULL,\n\t\"doc_no\" text NOT NULL,\n\t\"party_name\" text NOT NULL,\n\t\"party_tin\" text DEFAULT '' NOT NULL,\n\t\"nature\" text DEFAULT '' NOT NULL,\n\t\"gross_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"rate\" double precision DEFAULT 0 NOT NULL,\n\t\"tax_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"levy_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"reference\" text DEFAULT '' NOT NULL,\n\t\"status\" text DEFAULT '' NOT NULL,\n\t\"note\" text,\n\t\"created_by\" text NOT NULL,\n\t\"updated_at\" text NOT NULL\n)",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"chart_accounts_no_idx\" ON \"chart_accounts\" USING btree (\"account_no\")",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"closed_periods_client_period_idx\" ON \"closed_periods\" USING btree (\"client_id\",\"period\")",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"users_username_idx\" ON \"users\" USING btree (\"username\")",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"users_email_idx\" ON \"users\" USING btree (\"email\")",
  // --- Idempotent in-place migrations for databases created by earlier builds ---
  // Employee cost centre (payroll cost allocation by responsibility centre).
  "ALTER TABLE \"employees\" ADD COLUMN IF NOT EXISTS \"cost_center\" text",
  // The chart of accounts is scoped per entity: the same account number may
  // exist as a firm-master account AND as a client's own custom account, so the
  // uniqueness constraint must include the owning entity (0 = firm master).
  "DROP INDEX IF EXISTS \"chart_accounts_no_idx\"",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"chart_accounts_scope_idx\" ON \"chart_accounts\" (\"account_no\", COALESCE(\"client_id\", 0))",
  // Tenant column repairs. Databases created before multi-entity isolation had
  // no `client_id` on the operational tables; a `select` of that column then
  // failed with HTTP 500 on /api/bootstrap and /api/state, which the browser
  // could not distinguish from a broken sign-in. Added as NULLABLE so existing
  // rows are never rejected; new writes always carry the owning entity.
  "ALTER TABLE \"journal_lines\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"bank_accounts\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"purchase_orders\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"employees\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"business_partners\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"approval_requests\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"payroll_records\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"prepayment_records\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"prepayment_schedules\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"closed_periods\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"audit_log\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  // Session/user columns the auth layer depends on. Repaired in place so a
  // partially migrated database can never 401 a freshly issued session.
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"status\" text DEFAULT 'active'",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"restriction_reason\" text",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"permissions\" jsonb",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"password_hash\" text",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"password_salt\" text",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",

  /* --------------------------------------------------------------------- *
   * Trading subsystem: perpetual inventory + tax-aware fixed asset register.
   * --------------------------------------------------------------------- */
  "CREATE TABLE IF NOT EXISTS \"stock_items\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"item_code\" text NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"category\" text NOT NULL,\n\t\"uom\" text NOT NULL,\n\t\"quantity_on_hand\" double precision DEFAULT 0 NOT NULL,\n\t\"unit_cost\" double precision DEFAULT 0 NOT NULL,\n\t\"total_value\" double precision DEFAULT 0 NOT NULL,\n\t\"reorder_level\" double precision,\n\t\"location\" text,\n\t\"gl_account\" text,\n\t\"cost_method\" text,\n\t\"net_realisable_value\" double precision\n)",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"stock_items_scope_idx\" ON \"stock_items\" (\"client_id\",\"item_code\")",
  "CREATE TABLE IF NOT EXISTS \"stock_movements\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"date\" text NOT NULL,\n\t\"item_code\" text NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"type\" text NOT NULL,\n\t\"quantity\" double precision DEFAULT 0 NOT NULL,\n\t\"unit_cost\" double precision DEFAULT 0 NOT NULL,\n\t\"total_value\" double precision DEFAULT 0 NOT NULL,\n\t\"uom\" text NOT NULL,\n\t\"reference\" text,\n\t\"doc_no\" text,\n\t\"note\" text\n)",
  "CREATE INDEX IF NOT EXISTS \"stock_movements_client_idx\" ON \"stock_movements\" (\"client_id\")",
  "CREATE TABLE IF NOT EXISTS \"fixed_assets\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"asset_tag\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"class_code\" text NOT NULL,\n\t\"cost\" double precision DEFAULT 0 NOT NULL,\n\t\"accum_dep\" double precision DEFAULT 0 NOT NULL,\n\t\"useful_life\" text NOT NULL,\n\t\"depreciation_rate\" double precision,\n\t\"depreciation_method\" text,\n\t\"capital_allowance_class\" text,\n\t\"capital_allowance_rate\" double precision,\n\t\"accum_capital_allowance\" double precision DEFAULT 0 NOT NULL,\n\t\"location\" text DEFAULT '' NOT NULL,\n\t\"acquired\" text,\n\t\"disposed_date\" text,\n\t\"disposal_proceeds\" double precision\n)",
  "CREATE INDEX IF NOT EXISTS \"fixed_assets_client_idx\" ON \"fixed_assets\" (\"client_id\")",
  // Sales invoice: exact revenue account + trading-goods cost of sales fields.
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"revenue_account\" text",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"revenue_account_name\" text",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"item_type\" text",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"item_code\" text",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"quantity\" double precision",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"unit_selling_price\" double precision",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"unit_cost\" double precision",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"cogs_amount\" double precision",
  // Purchase order: stock item received and capitalised inward freight.
  "ALTER TABLE \"fixed_assets\" ADD COLUMN IF NOT EXISTS \"capital_allowance_class\" text",
  "ALTER TABLE \"purchase_orders\" ADD COLUMN IF NOT EXISTS \"item_code\" text",
  "ALTER TABLE \"purchase_orders\" ADD COLUMN IF NOT EXISTS \"inward_freight\" double precision",

  /* ======================================================================= *
   * PHASE ONE REMEDIATION
   * 1. Exact decimal storage (numeric) with a reconciliation guard.
   * 2. Controlled journal header + posting lifecycle.
   * 3. Tenant-safe foreign keys and chart-of-accounts precedence.
   * 4. Trading subledgers: receipts, invoices, payments, allocations, valuation.
   * ======================================================================= */

  // ---- 1. Exact decimal storage -------------------------------------------
  // Converting binary floating point to `numeric` is a data migration, not a
  // cast: every affected column is reconciled before and after, and the
  // migration aborts if any total moves. Scales differ by field — currency
  // amounts keep 2 decimals, unit costs/quantities/rates keep more.
  `
DO $remediation$
DECLARE
  col record;
  before_sum numeric;
  after_sum numeric;
BEGIN
  FOR col IN
    SELECT * FROM (VALUES
      ('users','maker_limit',2),
      ('journal_lines','debit',2), ('journal_lines','credit',2),
      ('bank_accounts','balance',2),
      ('purchase_orders','qty',6), ('purchase_orders','unit_price',6),
      ('purchase_orders','vat_recoverable',2), ('purchase_orders','total_amount',2),
      ('purchase_orders','paid_amount',2), ('purchase_orders','net_amount',2),
      ('purchase_orders','inward_freight',2),
      ('sales_invoices','net_revenue',2), ('sales_invoices','vat_output',2),
      ('sales_invoices','cst_amount',2), ('sales_invoices','tourism_levy_amount',2),
      ('sales_invoices','vat_withheld_by_customer',2), ('sales_invoices','total_receivable',2),
      ('sales_invoices','paid_amount',2), ('sales_invoices','quantity',6),
      ('sales_invoices','unit_selling_price',6), ('sales_invoices','unit_cost',6),
      ('sales_invoices','cogs_amount',2),
      ('employees','basic_salary',2), ('employees','allowances',2), ('employees','tax_relief',2),
      ('business_partners','vat_withholding_rate',6),
      ('approval_requests','amount',2),
      ('tax_schedule_entries','gross_amount',2), ('tax_schedule_entries','rate',6),
      ('tax_schedule_entries','tax_amount',2), ('tax_schedule_entries','levy_amount',2),
      ('stock_items','quantity_on_hand',6), ('stock_items','unit_cost',6),
      ('stock_items','total_value',2), ('stock_items','reorder_level',6),
      ('stock_items','net_realisable_value',2),
      ('stock_movements','quantity',6), ('stock_movements','unit_cost',6), ('stock_movements','total_value',2),
      ('fixed_assets','cost',2), ('fixed_assets','accum_dep',2),
      ('fixed_assets','depreciation_rate',6), ('fixed_assets','capital_allowance_rate',6),
      ('fixed_assets','accum_capital_allowance',2), ('fixed_assets','disposal_proceeds',2)
    ) AS source(table_name, column_name, num_scale)
  LOOP
    IF EXISTS (
      SELECT 1 FROM information_schema.columns
       WHERE table_schema = 'public' AND table_name = col.table_name
         AND column_name = col.column_name AND data_type = 'double precision'
    ) THEN
      EXECUTE format('SELECT coalesce(sum(%I::numeric(38,10)), 0) FROM %I', col.column_name, col.table_name) INTO before_sum;
      EXECUTE format('ALTER TABLE %I ALTER COLUMN %I TYPE numeric(20,%s) USING (%I::numeric(20,%s))',
        col.table_name, col.column_name, col.num_scale, col.column_name, col.num_scale);
      EXECUTE format('SELECT coalesce(sum(%I::numeric(38,10)), 0) FROM %I', col.column_name, col.table_name) INTO after_sum;
      IF before_sum <> after_sum THEN
        RAISE EXCEPTION 'Money conversion changed %.%: % -> % — reconcile historical balances before migrating.',
          col.table_name, col.column_name, before_sum, after_sum;
      END IF;
    END IF;
  END LOOP;
END
$remediation$`,

  // ---- 2. Controlled journal header and reversal trail --------------------
  `CREATE TABLE IF NOT EXISTS "journal_entries" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"doc_no" text NOT NULL,
\t"period" text NOT NULL,
\t"entry_date" text NOT NULL,
\t"module" text NOT NULL,
\t"doc_type" text NOT NULL,
\t"currency" text NOT NULL,
\t"description" text DEFAULT '' NOT NULL,
\t"status" text DEFAULT 'draft' NOT NULL,
\t"version" integer DEFAULT 1 NOT NULL,
\t"approved_version" integer,
\t"created_by" text NOT NULL,
\t"checked_by" text,
\t"posted_by" text,
\t"posted_at" text,
\t"reverses_journal_id" text,
\t"reversal_reason" text,
\t"idempotency_key" text,
\t"payload_hash" text,
\t"created_at" timestamp with time zone DEFAULT now() NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "journal_reversals" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"original_journal_id" text NOT NULL,
\t"reversal_journal_id" text NOT NULL,
\t"reason" text NOT NULL,
\t"created_by" text NOT NULL,
\t"created_at" timestamp with time zone DEFAULT now() NOT NULL
)`,
  `ALTER TABLE "journal_lines" ADD COLUMN IF NOT EXISTS "journal_entry_id" text`,
  `ALTER TABLE "journal_lines" ADD COLUMN IF NOT EXISTS "line_no" integer`,

  // ---- 3. Trading subledgers ---------------------------------------------
  `CREATE TABLE IF NOT EXISTS "goods_receipts" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"receipt_no" text NOT NULL,
\t"purchase_order_id" text,
\t"received_on" text NOT NULL,
\t"status" text DEFAULT 'draft' NOT NULL,
\t"created_by" text NOT NULL,
\t"created_at" timestamp with time zone DEFAULT now() NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "goods_receipt_lines" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"goods_receipt_id" text NOT NULL,
\t"line_no" integer NOT NULL,
\t"item_code" text NOT NULL,
\t"quantity_received" numeric(20,6) NOT NULL,
\t"unit_cost" numeric(20,6) NOT NULL,
\t"inward_freight" numeric(20,2) DEFAULT 0 NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "supplier_invoices" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"invoice_no" text NOT NULL,
\t"supplier_invoice_ref" text NOT NULL,
\t"vendor_id" text,
\t"vendor_name" text NOT NULL,
\t"purchase_order_id" text,
\t"invoice_date" text NOT NULL,
\t"due_date" text,
\t"currency" text NOT NULL,
\t"net_amount" numeric(20,2) NOT NULL,
\t"vat_amount" numeric(20,2) DEFAULT 0 NOT NULL,
\t"total_amount" numeric(20,2) NOT NULL,
\t"status" text DEFAULT 'draft' NOT NULL,
\t"journal_entry_id" text,
\t"created_by" text NOT NULL,
\t"created_at" timestamp with time zone DEFAULT now() NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "supplier_invoice_lines" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"supplier_invoice_id" text NOT NULL,
\t"line_no" integer NOT NULL,
\t"item_code" text,
\t"description" text NOT NULL,
\t"quantity" numeric(20,6) NOT NULL,
\t"unit_cost" numeric(20,6) NOT NULL,
\t"tax_rate" numeric(20,6) DEFAULT 0 NOT NULL,
\t"net_amount" numeric(20,2) NOT NULL,
\t"tax_amount" numeric(20,2) DEFAULT 0 NOT NULL,
\t"goods_receipt_line_id" text
)`,
  `CREATE TABLE IF NOT EXISTS "supplier_payments" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"payment_no" text NOT NULL,
\t"vendor_id" text,
\t"vendor_name" text NOT NULL,
\t"bank_account_id" integer,
\t"paid_on" text NOT NULL,
\t"currency" text NOT NULL,
\t"amount" numeric(20,2) NOT NULL,
\t"journal_entry_id" text,
\t"created_by" text NOT NULL,
\t"created_at" timestamp with time zone DEFAULT now() NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "supplier_payment_allocations" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"payment_id" text NOT NULL,
\t"supplier_invoice_id" text NOT NULL,
\t"amount" numeric(20,2) NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "sales_invoice_lines" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"sales_invoice_id" text NOT NULL,
\t"line_no" integer NOT NULL,
\t"item_code" text,
\t"description" text NOT NULL,
\t"revenue_account" text,
\t"quantity" numeric(20,6) NOT NULL,
\t"unit_price" numeric(20,6) NOT NULL,
\t"tax_rate" numeric(20,6) DEFAULT 0 NOT NULL,
\t"net_amount" numeric(20,2) NOT NULL,
\t"tax_amount" numeric(20,2) DEFAULT 0 NOT NULL,
\t"cogs_amount" numeric(20,2) DEFAULT 0 NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "customer_receipts" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"receipt_no" text NOT NULL,
\t"customer_id" text,
\t"customer_name" text NOT NULL,
\t"bank_account_id" integer,
\t"received_on" text NOT NULL,
\t"currency" text NOT NULL,
\t"amount" numeric(20,2) NOT NULL,
\t"journal_entry_id" text,
\t"created_by" text NOT NULL,
\t"created_at" timestamp with time zone DEFAULT now() NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "customer_receipt_allocations" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"receipt_id" text NOT NULL,
\t"sales_invoice_id" text NOT NULL,
\t"amount" numeric(20,2) NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "bank_statement_lines" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"bank_account_id" integer NOT NULL,
\t"statement_reference" text NOT NULL,
\t"statement_date" text NOT NULL,
\t"statement_amount" numeric(20,2) NOT NULL,
\t"imported_running_balance" numeric(20,2),
\t"matched_journal_entry_id" text,
\t"imported_at" timestamp with time zone DEFAULT now() NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "stock_cost_layers" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"item_code" text NOT NULL,
\t"receipt_movement_id" text NOT NULL,
\t"received_on" text NOT NULL,
\t"quantity_received" numeric(20,6) NOT NULL,
\t"quantity_remaining" numeric(20,6) NOT NULL,
\t"unit_cost" numeric(20,6) NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "stock_cost_allocations" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"issue_movement_id" text NOT NULL,
\t"cost_layer_id" text NOT NULL,
\t"quantity" numeric(20,6) NOT NULL,
\t"unit_cost" numeric(20,6) NOT NULL,
\t"allocated_cost" numeric(20,2) NOT NULL
)`,
  `CREATE TABLE IF NOT EXISTS "stock_counts" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"count_no" text NOT NULL,
\t"count_date" text NOT NULL,
\t"status" text DEFAULT 'draft' NOT NULL,
\t"created_by" text NOT NULL,
\t"approved_by" text,
\t"approved_at" text,
\t"journal_entry_id" text
)`,
  `CREATE TABLE IF NOT EXISTS "stock_count_lines" (
\t"id" text PRIMARY KEY NOT NULL,
\t"client_id" integer NOT NULL,
\t"stock_count_id" text NOT NULL,
\t"line_no" integer NOT NULL,
\t"item_code" text NOT NULL,
\t"quantity_before_count" numeric(20,6) NOT NULL,
\t"quantity_counted" numeric(20,6) NOT NULL,
\t"adjustment_reason" text
)`,
  `CREATE TABLE IF NOT EXISTS "client_disclosure_notes" (
\t"id" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name "client_disclosure_notes_id_seq" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),
\t"client_id" integer NOT NULL,
\t"template_key" text NOT NULL,
\t"period" text NOT NULL,
\t"body" text NOT NULL,
\t"tables" jsonb,
\t"updated_by" text,
\t"updated_at" timestamp with time zone DEFAULT now() NOT NULL
)`,

  // ---- 4. Columns that carry tenant-safe references and lifecycle data ----
  `ALTER TABLE "bank_accounts" ADD COLUMN IF NOT EXISTS "balance_rebuilt_at" timestamp with time zone`,
  `ALTER TABLE "purchase_orders" ADD COLUMN IF NOT EXISTS "vendor_id" text`,
  `ALTER TABLE "sales_invoices" ADD COLUMN IF NOT EXISTS "customer_id" text`,
  `ALTER TABLE "sales_invoices" ADD COLUMN IF NOT EXISTS "due_date" text`,
  `ALTER TABLE "sales_invoices" ADD COLUMN IF NOT EXISTS "currency" text`,
  `ALTER TABLE "sales_invoices" ADD COLUMN IF NOT EXISTS "journal_entry_id" text`,
  `ALTER TABLE "approval_requests" ADD COLUMN IF NOT EXISTS "currency" text`,
  `ALTER TABLE "approval_requests" ADD COLUMN IF NOT EXISTS "payload_version" integer`,
  `ALTER TABLE "approval_requests" ADD COLUMN IF NOT EXISTS "payload_hash" text`,
  `ALTER TABLE "approval_requests" ADD COLUMN IF NOT EXISTS "approved_journal_entry_id" text`,
  `ALTER TABLE "audit_log" ADD COLUMN IF NOT EXISTS "entity_type" text`,
  `ALTER TABLE "audit_log" ADD COLUMN IF NOT EXISTS "entity_id" text`,
  `ALTER TABLE "audit_log" ADD COLUMN IF NOT EXISTS "correlation_id" text`,
  `ALTER TABLE "audit_log" ADD COLUMN IF NOT EXISTS "occurred_at" timestamp with time zone DEFAULT now() NOT NULL`,
  `ALTER TABLE "tax_schedule_entries" ADD COLUMN IF NOT EXISTS "adjustment_reason" text`,
  `ALTER TABLE "tax_schedule_entries" ADD COLUMN IF NOT EXISTS "original_tax_amount" numeric(20,2)`,
  `ALTER TABLE "stock_movements" ADD COLUMN IF NOT EXISTS "direction" text`,
  `ALTER TABLE "stock_movements" ADD COLUMN IF NOT EXISTS "goods_receipt_line_id" text`,
  `ALTER TABLE "stock_movements" ADD COLUMN IF NOT EXISTS "sales_invoice_line_id" text`,
  `ALTER TABLE "stock_movements" ADD COLUMN IF NOT EXISTS "stock_count_line_id" text`,
  `ALTER TABLE "stock_movements" ADD COLUMN IF NOT EXISTS "cost_layer_id" text`,
  `ALTER TABLE "stock_movements" ADD COLUMN IF NOT EXISTS "journal_entry_id" text`,
  `ALTER TABLE "payroll_records" ADD COLUMN IF NOT EXISTS "period" text`,
  `ALTER TABLE "payroll_records" ADD COLUMN IF NOT EXISTS "gross_pay" numeric(20,2)`,
  `ALTER TABLE "payroll_records" ADD COLUMN IF NOT EXISTS "paye_tax" numeric(20,2)`,
  `ALTER TABLE "payroll_records" ADD COLUMN IF NOT EXISTS "net_pay" numeric(20,2)`,
  `ALTER TABLE "payroll_records" ADD COLUMN IF NOT EXISTS "employee_id" integer`,
  `ALTER TABLE "payroll_records" ADD COLUMN IF NOT EXISTS "journal_entry_id" text`,
  `ALTER TABLE "prepayment_records" ADD COLUMN IF NOT EXISTS "original_amount" numeric(20,2)`,
  `ALTER TABLE "prepayment_records" ADD COLUMN IF NOT EXISTS "start_date" text`,
  `ALTER TABLE "prepayment_records" ADD COLUMN IF NOT EXISTS "end_date" text`,
  `ALTER TABLE "prepayment_records" ADD COLUMN IF NOT EXISTS "journal_entry_id" text`,
  `ALTER TABLE "prepayment_schedules" ADD COLUMN IF NOT EXISTS "line_no" integer`,
  `ALTER TABLE "prepayment_schedules" ADD COLUMN IF NOT EXISTS "amount" numeric(20,2)`,
  `ALTER TABLE "prepayment_schedules" ADD COLUMN IF NOT EXISTS "schedule_date" text`,

  // ---- 5. Indexes ---------------------------------------------------------
  // Sessions: several concurrent sessions per user are legitimate, so the
  // former unique index is replaced by a lookup index with explicit revocation.
  `DROP INDEX IF EXISTS "bpz_sessions_user_unique_idx"`,
  `DROP INDEX IF EXISTS "bpz_sessions_user_idx"`,
  `CREATE INDEX IF NOT EXISTS "bpz_sessions_user_idx" ON "bpz_sessions" ("user_id")`,
  // Chart of accounts: master rows (client_id null) and client rows are each
  // protected, so a duplicate master account number is impossible.
  `DROP INDEX IF EXISTS "chart_accounts_coalesce_idx"`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "chart_accounts_master_no_idx" ON "chart_accounts" ("account_no") WHERE "client_id" IS NULL`,
  `DROP INDEX IF EXISTS "chart_accounts_scope_idx"`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "chart_accounts_scope_idx" ON "chart_accounts" ("client_id", "account_no") WHERE "client_id" IS NOT NULL`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "journal_entries_client_doc_no_uq" ON "journal_entries" ("client_id", "doc_no")`,
  `CREATE INDEX IF NOT EXISTS "journal_entries_client_status_idx" ON "journal_entries" ("client_id", "status")`,
  `CREATE INDEX IF NOT EXISTS "journal_lines_doc_idx" ON "journal_lines" ("client_id", "doc_no")`,
  `CREATE INDEX IF NOT EXISTS "journal_lines_client_account_idx" ON "journal_lines" ("client_id", "account_no")`,
  `CREATE INDEX IF NOT EXISTS "journal_lines_client_period_idx" ON "journal_lines" ("client_id", "period")`,
  `CREATE INDEX IF NOT EXISTS "audit_log_client_occurred_idx" ON "audit_log" ("client_id", "occurred_at")`,
  `CREATE INDEX IF NOT EXISTS "audit_log_entity_idx" ON "audit_log" ("client_id", "entity_type", "entity_id")`,
  `CREATE INDEX IF NOT EXISTS "stock_movements_client_item_date_idx" ON "stock_movements" ("client_id", "item_code", "date")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "stock_cost_layers_receipt_movement_idx" ON "stock_cost_layers" ("client_id", "receipt_movement_id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "stock_cost_allocations_movement_layer_idx" ON "stock_cost_allocations" ("client_id", "issue_movement_id", "cost_layer_id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "bank_statement_lines_ref_uq" ON "bank_statement_lines" ("client_id", "bank_account_id", "statement_reference")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "supplier_payment_allocation_uq" ON "supplier_payment_allocations" ("client_id", "payment_id", "supplier_invoice_id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "customer_receipt_allocation_uq" ON "customer_receipt_allocations" ("client_id", "receipt_id", "sales_invoice_id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "supplier_invoices_vendor_ref_idx" ON "supplier_invoices" ("client_id", "vendor_id", "supplier_invoice_ref")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "tax_schedule_source_key_idx" ON "tax_schedule_entries" ("client_id", "kind", "source_key")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "client_disclosure_notes_scope_idx" ON "client_disclosure_notes" ("client_id", "template_key", "period")`,
  `CREATE INDEX IF NOT EXISTS "goods_receipt_lines_no_idx" ON "goods_receipt_lines" ("client_id", "goods_receipt_id", "line_no")`,
  `CREATE INDEX IF NOT EXISTS "supplier_invoice_lines_no_idx" ON "supplier_invoice_lines" ("client_id", "supplier_invoice_id", "line_no")`,
  `CREATE INDEX IF NOT EXISTS "sales_invoice_lines_no_idx" ON "sales_invoice_lines" ("client_id", "sales_invoice_id", "line_no")`,
  `CREATE INDEX IF NOT EXISTS "stock_count_lines_no_idx" ON "stock_count_lines" ("client_id", "stock_count_id", "line_no")`,

  // ---- 6. Backfill: give existing documents a controlled header ----------
  // Historical ledger rows are grouped into journal_entries so the lifecycle,
  // reversal links and idempotent re-import apply to them too.
  `
INSERT INTO "journal_entries" (
  "id", "client_id", "doc_no", "period", "entry_date", "module", "doc_type",
  "currency", "description", "status", "version", "created_by", "checked_by", "posted_by", "posted_at"
)
SELECT
  'jrn_' || md5(history."client_id"::text || ':' || history."doc_no"),
  history."client_id", history."doc_no", min("journal_lines"."period"), min("journal_lines"."date"),
  min("journal_lines"."module"), min("journal_lines"."doc_type"), min("journal_lines"."currency"),
  '', 'posted', 1, min("journal_lines"."created_by"), max("journal_lines"."checked_by"),
  min("journal_lines"."created_by"), min("journal_lines"."date")
FROM "journal_lines"
JOIN (SELECT DISTINCT "client_id", "doc_no" FROM "journal_lines" WHERE "client_id" IS NOT NULL) AS history
  ON "journal_lines"."client_id" = history."client_id" AND "journal_lines"."doc_no" = history."doc_no"
GROUP BY history."client_id", history."doc_no"
ON CONFLICT ("client_id", "doc_no") DO NOTHING`,
  `
UPDATE "journal_lines" jl
   SET "journal_entry_id" = je."id",
       "line_no" = numbered.rn
  FROM (SELECT "id", "client_id", "doc_no",
               row_number() OVER (PARTITION BY "client_id", "doc_no" ORDER BY "id") AS rn
          FROM "journal_lines") AS numbered
  JOIN "journal_entries" je
    ON je."client_id" = numbered."client_id" AND je."doc_no" = numbered."doc_no"
 WHERE jl."id" = numbered."id"`,

  // ---- 7. Tenant-safe foreign keys and posting integrity -----------------
  // Composite foreign keys must reference a unique parent key, so each parent
  // exposes (client_id, id) — ownership and identity together.
  `CREATE UNIQUE INDEX IF NOT EXISTS "journal_entries_client_id_id_uq" ON "journal_entries" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "journal_lines_client_id_id_uq" ON "journal_lines" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "bank_accounts_client_id_id_uq" ON "bank_accounts" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "purchase_orders_client_id_id_uq" ON "purchase_orders" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "goods_receipts_client_id_id_uq" ON "goods_receipts" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "goods_receipt_lines_client_id_id_uq" ON "goods_receipt_lines" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "supplier_invoices_client_id_id_uq" ON "supplier_invoices" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "supplier_invoice_lines_client_id_id_uq" ON "supplier_invoice_lines" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "supplier_payments_client_id_id_uq" ON "supplier_payments" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "supplier_payment_allocations_client_id_id_uq" ON "supplier_payment_allocations" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "sales_invoices_client_id_id_uq" ON "sales_invoices" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "sales_invoice_lines_client_id_id_uq" ON "sales_invoice_lines" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "customer_receipts_client_id_id_uq" ON "customer_receipts" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "customer_receipt_allocations_client_id_id_uq" ON "customer_receipt_allocations" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "bank_statement_lines_client_id_id_uq" ON "bank_statement_lines" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "stock_movements_client_id_id_uq" ON "stock_movements" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "stock_cost_layers_client_id_id_uq" ON "stock_cost_layers" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "stock_cost_allocations_client_id_id_uq" ON "stock_cost_allocations" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "stock_counts_client_id_id_uq" ON "stock_counts" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "stock_count_lines_client_id_id_uq" ON "stock_count_lines" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "employees_client_id_id_uq" ON "employees" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "business_partners_client_id_id_uq" ON "business_partners" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "payroll_records_client_id_id_uq" ON "payroll_records" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "prepayment_records_client_id_id_uq" ON "prepayment_records" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "prepayment_schedules_client_id_id_uq" ON "prepayment_schedules" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "approval_requests_client_id_id_uq" ON "approval_requests" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "tax_schedule_entries_client_id_id_uq" ON "tax_schedule_entries" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "fixed_assets_client_id_id_uq" ON "fixed_assets" ("client_id", "id")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "clients_code_idx" ON "clients" ("code")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "bank_accounts_client_code_idx" ON "bank_accounts" ("client_id", "code")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "purchase_orders_client_po_no_idx" ON "purchase_orders" ("client_id", "po_no")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "goods_receipts_client_no_idx" ON "goods_receipts" ("client_id", "receipt_no")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "supplier_invoices_client_no_idx" ON "supplier_invoices" ("client_id", "invoice_no")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "supplier_payments_client_no_idx" ON "supplier_payments" ("client_id", "payment_no")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "sales_invoices_client_inv_no_idx" ON "sales_invoices" ("client_id", "inv_no")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "customer_receipts_client_no_idx" ON "customer_receipts" ("client_id", "receipt_no")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "stock_counts_client_no_idx" ON "stock_counts" ("client_id", "count_no")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "employees_client_bp_no_idx" ON "employees" ("client_id", "bp_no")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "business_partners_client_code_idx" ON "business_partners" ("client_id", "code")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "fixed_assets_client_tag_idx" ON "fixed_assets" ("client_id", "asset_tag")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "disclosure_notes_key_idx" ON "disclosure_notes" ("key")`,
  // Each rule is added only when the existing data satisfies it. A legacy
  // database that still contains orphaned rows keeps working, is told exactly
  // what to clean, and gains the constraint on the next successful run.
  `
DO $constraints$
DECLARE
  rule record;
BEGIN
  FOR rule IN
    SELECT * FROM (VALUES
      ('journal_lines_one_sided_check', 'journal_lines',
       '((debit > 0 AND credit = 0) OR (credit > 0 AND debit = 0))'),
      ('journal_lines_line_no_check', 'journal_lines', '(line_no IS NULL OR line_no > 0)'),
      ('users_maker_limit_check', 'users', '(maker_limit >= 0)'),
      ('users_role_check', 'users',
       '(role IN (''owner'',''partner'',''manager'',''accountant'',''auditor''))'),
      ('bank_accounts_kind_check', 'bank_accounts', '(kind IS NULL OR kind IN (''bank'',''cash''))'),
      ('purchase_orders_amounts_check', 'purchase_orders',
       '(qty > 0 AND unit_price >= 0 AND total_amount >= 0 AND paid_amount >= 0 AND paid_amount <= total_amount)'),
      ('sales_invoices_amounts_check', 'sales_invoices',
       '(net_revenue >= 0 AND total_receivable >= 0 AND paid_amount >= 0 AND paid_amount <= total_receivable)'),
      ('sales_invoices_dates_check', 'sales_invoices', '(due_date IS NULL OR due_date >= date)'),
      ('supplier_invoices_dates_check', 'supplier_invoices', '(due_date IS NULL OR due_date >= invoice_date)'),
      ('supplier_payments_amount_check', 'supplier_payments', '(amount > 0)'),
      ('customer_receipts_amount_check', 'customer_receipts', '(amount > 0)'),
      ('stock_items_values_check', 'stock_items',
       '(quantity_on_hand >= 0 AND unit_cost >= 0 AND total_value >= 0)'),
      ('stock_cost_layers_quantities_check', 'stock_cost_layers',
       '(quantity_received > 0 AND quantity_remaining >= 0 AND quantity_remaining <= quantity_received)'),
      ('stock_cost_allocations_values_check', 'stock_cost_allocations',
       '(quantity > 0 AND allocated_cost >= 0)'),
      ('stock_count_lines_quantities_check', 'stock_count_lines',
       '(line_no > 0 AND quantity_before_count >= 0 AND quantity_counted >= 0)'),
      ('journal_reversals_distinct_check', 'journal_reversals', '(original_journal_id <> reversal_journal_id)'),
      ('closed_periods_client_period_check', 'closed_periods', '(period ~ ''^[0-9]{4}-[0-9]{2}$'')')
    ) AS source(constraint_name, table_name, definition)
  LOOP
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = rule.constraint_name) THEN
      BEGIN
        EXECUTE format('ALTER TABLE %I ADD CONSTRAINT %I CHECK %s', rule.table_name, rule.constraint_name, rule.definition);
      EXCEPTION WHEN undefined_table THEN
        NULL; -- table not created yet in this database
        WHEN others THEN
          RAISE WARNING 'Check constraint % not applied: %', rule.constraint_name, SQLERRM;
      END;
    END IF;
  END LOOP;
END
$constraints$`,
  `
DO $foreign_keys$
DECLARE
  rule record;
BEGIN
  FOR rule IN
    SELECT * FROM (VALUES
      ('bpz_sessions_user_fk', 'bpz_sessions', '(user_id)', 'users', '(id)', 'cascade'),
      ('journal_entries_client_fk', 'journal_entries', '(client_id)', 'clients', '(id)', 'restrict'),
      ('journal_lines_client_fk', 'journal_lines', '(client_id)', 'clients', '(id)', 'restrict'),
      ('journal_lines_entry_fk', 'journal_lines', '(client_id, journal_entry_id)', 'journal_entries', '(client_id, id)', 'restrict'),
      ('journal_reversals_original_fk', 'journal_reversals', '(client_id, original_journal_id)', 'journal_entries', '(client_id, id)', 'restrict'),
      ('journal_reversals_reversal_fk', 'journal_reversals', '(client_id, reversal_journal_id)', 'journal_entries', '(client_id, id)', 'restrict'),
      ('bank_accounts_client_fk', 'bank_accounts', '(client_id)', 'clients', '(id)', 'restrict'),
      ('bank_statement_lines_account_fk', 'bank_statement_lines', '(client_id, bank_account_id)', 'bank_accounts', '(client_id, id)', 'restrict'),
      ('bank_statement_lines_journal_fk', 'bank_statement_lines', '(client_id, matched_journal_entry_id)', 'journal_entries', '(client_id, id)', 'restrict'),
      ('purchase_orders_client_fk', 'purchase_orders', '(client_id)', 'clients', '(id)', 'restrict'),
      ('purchase_orders_vendor_fk', 'purchase_orders', '(client_id, vendor_id)', 'business_partners', '(client_id, id)', 'restrict'),
      ('goods_receipts_order_fk', 'goods_receipts', '(client_id, purchase_order_id)', 'purchase_orders', '(client_id, id)', 'restrict'),
      ('goods_receipt_lines_receipt_fk', 'goods_receipt_lines', '(client_id, goods_receipt_id)', 'goods_receipts', '(client_id, id)', 'restrict'),
      ('goods_receipt_lines_item_fk', 'goods_receipt_lines', '(client_id, item_code)', 'stock_items', '(client_id, item_code)', 'restrict'),
      ('supplier_invoices_order_fk', 'supplier_invoices', '(client_id, purchase_order_id)', 'purchase_orders', '(client_id, id)', 'restrict'),
      ('supplier_invoices_vendor_fk', 'supplier_invoices', '(client_id, vendor_id)', 'business_partners', '(client_id, id)', 'restrict'),
      ('supplier_invoice_lines_invoice_fk', 'supplier_invoice_lines', '(client_id, supplier_invoice_id)', 'supplier_invoices', '(client_id, id)', 'restrict'),
      ('supplier_invoice_lines_receipt_line_fk', 'supplier_invoice_lines', '(client_id, goods_receipt_line_id)', 'goods_receipt_lines', '(client_id, id)', 'restrict'),
      ('supplier_payments_vendor_fk', 'supplier_payments', '(client_id, vendor_id)', 'business_partners', '(client_id, id)', 'restrict'),
      ('supplier_payments_bank_account_fk', 'supplier_payments', '(client_id, bank_account_id)', 'bank_accounts', '(client_id, id)', 'restrict'),
      ('supplier_payment_allocations_payment_fk', 'supplier_payment_allocations', '(client_id, payment_id)', 'supplier_payments', '(client_id, id)', 'restrict'),
      ('supplier_payment_allocations_invoice_fk', 'supplier_payment_allocations', '(client_id, supplier_invoice_id)', 'supplier_invoices', '(client_id, id)', 'restrict'),
      ('sales_invoices_client_fk', 'sales_invoices', '(client_id)', 'clients', '(id)', 'restrict'),
      ('sales_invoices_customer_fk', 'sales_invoices', '(client_id, customer_id)', 'business_partners', '(client_id, id)', 'restrict'),
      ('sales_invoice_lines_invoice_fk', 'sales_invoice_lines', '(client_id, sales_invoice_id)', 'sales_invoices', '(client_id, id)', 'restrict'),
      ('sales_invoice_lines_item_fk', 'sales_invoice_lines', '(client_id, item_code)', 'stock_items', '(client_id, item_code)', 'restrict'),
      ('customer_receipts_customer_fk', 'customer_receipts', '(client_id, customer_id)', 'business_partners', '(client_id, id)', 'restrict'),
      ('customer_receipts_bank_account_fk', 'customer_receipts', '(client_id, bank_account_id)', 'bank_accounts', '(client_id, id)', 'restrict'),
      ('customer_receipt_allocations_receipt_fk', 'customer_receipt_allocations', '(client_id, receipt_id)', 'customer_receipts', '(client_id, id)', 'restrict'),
      ('customer_receipt_allocations_invoice_fk', 'customer_receipt_allocations', '(client_id, sales_invoice_id)', 'sales_invoices', '(client_id, id)', 'restrict'),
      ('employees_client_fk', 'employees', '(client_id)', 'clients', '(id)', 'restrict'),
      ('company_profiles_client_fk', 'company_profiles', '(client_id)', 'clients', '(id)', 'restrict'),
      ('chart_accounts_client_fk', 'chart_accounts', '(client_id)', 'clients', '(id)', 'restrict'),
      ('business_partners_client_fk', 'business_partners', '(client_id)', 'clients', '(id)', 'restrict'),
      ('payroll_records_client_fk', 'payroll_records', '(client_id)', 'clients', '(id)', 'restrict'),
      ('payroll_records_employee_fk', 'payroll_records', '(client_id, employee_id)', 'employees', '(client_id, id)', 'restrict'),
      ('prepayment_records_client_fk', 'prepayment_records', '(client_id)', 'clients', '(id)', 'restrict'),
      ('prepayment_schedules_prepayment_fk', 'prepayment_schedules', '(client_id, prepayment_id)', 'prepayment_records', '(client_id, id)', 'restrict'),
      ('approval_requests_client_fk', 'approval_requests', '(client_id)', 'clients', '(id)', 'restrict'),
      ('closed_periods_client_fk', 'closed_periods', '(client_id)', 'clients', '(id)', 'restrict'),
      ('tax_schedule_entries_client_fk', 'tax_schedule_entries', '(client_id)', 'clients', '(id)', 'restrict'),
      ('stock_items_client_fk', 'stock_items', '(client_id)', 'clients', '(id)', 'restrict'),
      ('stock_movements_item_fk', 'stock_movements', '(client_id, item_code)', 'stock_items', '(client_id, item_code)', 'restrict'),
      ('stock_movements_journal_fk', 'stock_movements', '(client_id, journal_entry_id)', 'journal_entries', '(client_id, id)', 'restrict'),
      ('stock_counts_client_fk', 'stock_counts', '(client_id)', 'clients', '(id)', 'restrict'),
      ('stock_count_lines_count_fk', 'stock_count_lines', '(client_id, stock_count_id)', 'stock_counts', '(client_id, id)', 'restrict'),
      ('stock_count_lines_item_fk', 'stock_count_lines', '(client_id, item_code)', 'stock_items', '(client_id, item_code)', 'restrict'),
      ('stock_cost_layers_movement_fk', 'stock_cost_layers', '(client_id, receipt_movement_id)', 'stock_movements', '(client_id, id)', 'restrict'),
      ('stock_cost_layers_item_fk', 'stock_cost_layers', '(client_id, item_code)', 'stock_items', '(client_id, item_code)', 'restrict'),
      ('stock_cost_allocations_issue_fk', 'stock_cost_allocations', '(client_id, issue_movement_id)', 'stock_movements', '(client_id, id)', 'restrict'),
      ('stock_cost_allocations_layer_fk', 'stock_cost_allocations', '(client_id, cost_layer_id)', 'stock_cost_layers', '(client_id, id)', 'restrict'),
      ('fixed_assets_client_fk', 'fixed_assets', '(client_id)', 'clients', '(id)', 'restrict'),
      ('audit_log_client_fk', 'audit_log', '(client_id)', 'clients', '(id)', 'restrict'),
      ('client_disclosure_notes_client_fk', 'client_disclosure_notes', '(client_id)', 'clients', '(id)', 'restrict')
    ) AS source(constraint_name, table_name, columns, ref_table, ref_columns, on_delete)
  LOOP
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = rule.constraint_name) THEN
      BEGIN
        EXECUTE format(
          'ALTER TABLE %I ADD CONSTRAINT %I FOREIGN KEY %s REFERENCES %I %s ON DELETE %s',
          rule.table_name, rule.constraint_name, rule.columns, rule.ref_table, rule.ref_columns, rule.on_delete
        );
      EXCEPTION WHEN undefined_table THEN
        NULL; -- referenced table not created yet in this database
        WHEN duplicate_object THEN
          NULL; -- already applied by a concurrent instance
        WHEN foreign_key_violation THEN
          RAISE WARNING 'Foreign key % skipped: existing rows reference another entity or a missing parent. Tenant safety will apply once those rows are cleaned up.', rule.constraint_name;
      END;
    END IF;
  END LOOP;
END
$foreign_keys$`,
];
