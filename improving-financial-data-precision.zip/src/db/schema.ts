import { customType, check, foreignKey, index, integer, jsonb, pgTable, text, timestamp, unique, uniqueIndex, bigint, boolean } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { numberToExactString } from "@/lib/exactMoney";

/**
 * BPZ Consult ERP — production schema.
 *
 * Monetary exactness: every currency amount is stored as PostgreSQL `numeric`
 * (exact decimal), never as binary floating point. Precision and scale are chosen
 * per field rather than applied uniformly — final invoice amounts and journal
 * lines carry the currency scale (2), while unit costs, quantities, exchange and
 * tax rates keep the greater precision they need. Values cross into JavaScript
 * through `exactMoney.ts`, and exact arithmetic uses integer minor units.
 *
 * Every business table is tenant-scoped by `clientId`; relationships are declared
 * as composite foreign keys so a child row can never reference another entity's
 * account, partner or document.
 */

/** Exact decimal column: `numeric(precision, scale)` with integer minor-unit conversion. */
function exactNumeric(name: string, scale: number, precision = 20) {
  return customType<{ data: number; driverData: string; config: { precision: number; scale: number } }>({
    dataType(config) {
      return `numeric(${config?.precision ?? precision},${config?.scale ?? scale})`;
    },
    fromDriver(value) {
      return Number(exactToMinorString(value, scale)) / Number(BigInt(10) ** BigInt(scale));
    },
    toDriver(value) {
      return numberToExactString(value, scale);
    },
  })(name, { precision, scale });
}

function exactToMinorString(value: string, scale: number): string {
  const match = /^(-?)(\d+)(?:\.(\d+))?$/.exec(String(value).trim());
  if (!match) throw new Error(`Invalid exact decimal from database: ${value}`);
  const fraction = (match[3] ?? "").padEnd(scale, "0").slice(0, scale);
  const minor = BigInt(match[2]) * BigInt(10) ** BigInt(scale) + BigInt(fraction || "0");
  return `${match[1] === "-" ? "-" : ""}${minor}`;
}

/** Currency amounts: the functional-currency scale of the entity. */
const money = (name: string) => exactNumeric(name, 2);
/** Unit costs and selling prices: greater precision than final document amounts. */
const unitRate = (name: string) => exactNumeric(name, 6);
/** Quantities: not a currency amount, so it keeps its own scale. */
const quantity = (name: string) => exactNumeric(name, 6);
/** Percentage rates such as VAT, capital allowance and depreciation rates. */
const rate = (name: string) => exactNumeric(name, 6);

export const users = pgTable("users", {
  id: text("id").primaryKey(),
  username: text("username").notNull(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(), // owner | partner | manager | accountant | auditor
  makerLimit: money("maker_limit").notNull().default(0),
  canCheck: boolean("can_check").notNull().default(false),
  clientId: integer("client_id"),
  passwordHash: text("password_hash"),
  passwordSalt: text("password_salt"),
  status: text("status").notNull().default("active"),
  restrictionReason: text("restriction_reason"),
  permissions: jsonb("permissions"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("users_username_idx").on(t.username),
  uniqueIndex("users_email_idx").on(t.email),
  // Approval limits are expressed in a defined currency scale and cannot be negative.
  check("users_maker_limit_check", sql`${t.makerLimit} >= 0`),
  check("users_role_check", sql`${t.role} in ('owner', 'partner', 'manager', 'accountant', 'auditor')`),
  check("users_status_check", sql`${t.status} in ('active', 'restricted', 'suspended')`),
]);

/**
 * Session store.
 *
 * The table is named `bpz_sessions` (not the generic `sessions`) on purpose:
 * databases provisioned by an earlier build may already contain a `sessions`
 * table with an incompatible shape. A dedicated name guarantees the shape below.
 * `lastSeenAt` powers the "active sessions" owner view and session sliding.
 */
export const sessions = pgTable("bpz_sessions", {
  token: text("token").primaryKey(),
  userId: text("user_id").notNull(),
  expiresAt: bigint("expires_at", { mode: "number" }).notNull(),
  lastSeenAt: bigint("last_seen_at", { mode: "number" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  // Many concurrent sessions per user are legitimate; revocation is explicit.
  index("bpz_sessions_user_idx").on(t.userId),
  index("bpz_sessions_expiry_idx").on(t.expiresAt),
  // Tenant-safe ownership: a session can only exist for a real user account.
  foreignKey({ columns: [t.userId], foreignColumns: [users.id], name: "bpz_sessions_user_fk" }).onDelete("cascade"),
]);

export const clients = pgTable("clients", {
  id: integer("id").primaryKey(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  sector: text("sector").notNull(),
  currency: text("currency").notNull(),
  jurisdiction: text("jurisdiction").notNull(),
  regNumber: text("reg_number").notNull(),
  isParent: boolean("is_parent").notNull().default(false),
  assignedServices: jsonb("assigned_services"),
  adminUsername: text("admin_username"),
  adminEmail: text("admin_email"),
  loginUrl: text("login_url"),
}, (t) => [
  uniqueIndex("clients_code_idx").on(t.code),
  check("clients_currency_check", sql`${t.currency} ~ '^[A-Z]{3}$'`),
]);

/**
 * Controlled journal header (Phase One remediation).
 *
 * One row per accounting document: source, period, lifecycle status and the
 * maker/checker trail. `journal_lines` references this header, so period, date,
 * module and document type are declared once instead of being repeated — and can
 * no longer disagree between lines of the same document.
 *
 * Idempotency: `(clientId, docNo)` is unique, so a repeated import or a retried
 * request can never post the same document twice.
 */
export const journalEntries = pgTable("journal_entries", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  docNo: text("doc_no").notNull(),
  period: text("period").notNull(),
  entryDate: text("entry_date").notNull(),
  module: text("module").notNull(),
  docType: text("doc_type").notNull(),
  currency: text("currency").notNull(),
  description: text("description").notNull().default(""),
  // draft | pending_approval | approved | posted
  status: text("status").notNull().default("draft"),
  version: integer("version").notNull().default(1),
  approvedVersion: integer("approved_version"),
  createdBy: text("created_by").notNull(),
  checkedBy: text("checked_by"),
  postedBy: text("posted_by"),
  postedAt: text("posted_at"),
  reversesJournalId: text("reverses_journal_id"),
  reversalReason: text("reversal_reason"),
  idempotencyKey: text("idempotency_key"),
  payloadHash: text("payload_hash"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  unique("journal_entries_client_id_id_uq").on(t.clientId, t.id),
  unique("journal_entries_client_doc_no_uq").on(t.clientId, t.docNo),
  index("journal_entries_client_status_idx").on(t.clientId, t.status),
  index("journal_entries_client_period_idx").on(t.clientId, t.period),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "journal_entries_client_fk" }).onDelete("restrict"),
  check("journal_entries_status_check", sql`${t.status} in ('draft', 'pending_approval', 'approved', 'posted')`),
  check("journal_entries_doc_type_check", sql`${t.docType} <> 'REV' or ${t.reversesJournalId} is not null`),
  check("journal_entries_reversal_reason_check", sql`${t.reversesJournalId} is null or ${t.reversalReason} is not null`),
  check("journal_entries_currency_check", sql`${t.currency} ~ '^[A-Z]{3}$'`),
]);

/** Complete reversal trail: original entry, reversing entry, reason and actor. */
export const journalReversals = pgTable("journal_reversals", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  originalJournalId: text("original_journal_id").notNull(),
  reversalJournalId: text("reversal_journal_id").notNull(),
  reason: text("reason").notNull(),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  unique("journal_reversals_client_id_uq").on(t.clientId, t.id),
  unique("journal_reversals_original_uq").on(t.clientId, t.originalJournalId),
  unique("journal_reversals_reversal_uq").on(t.clientId, t.reversalJournalId),
  foreignKey({ columns: [t.clientId, t.originalJournalId], foreignColumns: [journalEntries.clientId, journalEntries.id], name: "journal_reversals_original_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.reversalJournalId], foreignColumns: [journalEntries.clientId, journalEntries.id], name: "journal_reversals_reversal_fk" }).onDelete("restrict"),
  check("journal_reversals_distinct_check", sql`${t.originalJournalId} <> ${t.reversalJournalId}`),
]);

export const journalLines = pgTable("journal_lines", {
  id: text("id").primaryKey(),
  journalEntryId: text("journal_entry_id"),
  lineNo: integer("line_no"),
  docNo: text("doc_no").notNull(),
  period: text("period").notNull(),
  date: text("date").notNull(),
  module: text("module").notNull(),
  docType: text("doc_type").notNull(),
  accountNo: text("account_no").notNull(),
  accountName: text("account_name").notNull(),
  costCenter: text("cost_center"),
  debit: money("debit").notNull().default(0),
  credit: money("credit").notNull().default(0),
  currency: text("currency").notNull(),
  description: text("description").notNull(),
  createdBy: text("created_by").notNull(),
  checkedBy: text("checked_by"),
  isReversed: boolean("is_reversed").notNull().default(false),
  reference: text("reference"),
  clientId: integer("client_id").notNull(),
}, (t) => [
  unique("journal_lines_client_id_id_uq").on(t.clientId, t.id),
  index("journal_lines_doc_idx").on(t.clientId, t.docNo),
  index("journal_lines_client_account_idx").on(t.clientId, t.accountNo),
  index("journal_lines_client_period_idx").on(t.clientId, t.period),
  // Tenant-safe links: the header and the posting account must belong to the
  // same entity as the line itself.
  foreignKey({ columns: [t.clientId, t.journalEntryId], foreignColumns: [journalEntries.clientId, journalEntries.id], name: "journal_lines_entry_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "journal_lines_client_fk" }).onDelete("restrict"),
  check("journal_lines_line_no_check", sql`${t.lineNo} is null or ${t.lineNo} > 0`),
  // Conventional double entry: exactly one positive side per line. Negative and
  // zero-value posting lines are rejected by the database, not just the screen.
  check("journal_lines_one_sided_check", sql`(${t.debit} > 0 and ${t.credit} = 0) or (${t.credit} > 0 and ${t.debit} = 0)`),
]);

export const bankAccounts = pgTable("bank_accounts", {
  id: integer("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  bankName: text("bank_name").notNull(),
  accountNo: text("account_no").notNull(),
  currency: text("currency").notNull(),
  // Cached book balance. It is a controlled cache of posted ledger movements
  // (see `reconcileBankBalances`), never the imported statement balance.
  balance: money("balance").notNull().default(0),
  balanceRebuiltAt: timestamp("balance_rebuilt_at", { withTimezone: true }),
  kind: text("kind"), // 'bank' | 'cash'
  glAccount: text("gl_account"),
}, (t) => [
  unique("bank_accounts_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("bank_accounts_client_code_idx").on(t.clientId, t.code),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "bank_accounts_client_fk" }).onDelete("restrict"),
  check("bank_accounts_kind_check", sql`${t.kind} is null or ${t.kind} in ('bank', 'cash')`),
]);

export const purchaseOrders = pgTable("purchase_orders", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  poNo: text("po_no").notNull(),
  vendorId: text("vendor_id"),
  vendorName: text("vendor_name").notNull(),
  itemType: text("item_type").notNull(),
  itemDescription: text("item_description").notNull(),
  qty: quantity("qty").notNull(),
  unitPrice: unitRate("unit_price").notNull(),
  vatRecoverable: money("vat_recoverable").notNull().default(0),
  totalAmount: money("total_amount").notNull(),
  paidAmount: money("paid_amount").notNull().default(0),
  status: text("status").notNull(),
  date: text("date").notNull(),
  currency: text("currency"),
  vatTreatment: text("vat_treatment"),
  netAmount: money("net_amount"),
  quotationRef: text("quotation_ref"),
  glAccount: text("gl_account").notNull(),
  glAccountName: text("gl_account_name").notNull(),
  costCenter: text("cost_center").notNull(),
  costCenterName: text("cost_center_name").notNull(),
  // Trading purchases: the stock item received and the inward freight that is
  // capitalised into the inventory cost (IAS 2.11).
  itemCode: text("item_code"),
  inwardFreight: money("inward_freight"),
}, (t) => [
  unique("purchase_orders_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("purchase_orders_client_po_no_idx").on(t.clientId, t.poNo),
  index("purchase_orders_client_status_idx").on(t.clientId, t.status),
  // A counterparty reference must resolve inside the same entity.
  foreignKey({ columns: [t.clientId, t.vendorId], foreignColumns: [businessPartners.clientId, businessPartners.id], name: "purchase_orders_vendor_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "purchase_orders_client_fk" }).onDelete("restrict"),
  check("purchase_orders_amounts_check", sql`${t.qty} > 0 and ${t.unitPrice} >= 0 and ${t.totalAmount} >= 0 and ${t.paidAmount} >= 0 and ${t.paidAmount} <= ${t.totalAmount}`),
  check("purchase_orders_status_check", sql`${t.status} in ('draft', 'approved', 'sent', 'partially_received', 'received', 'invoiced', 'paid', 'cancelled', 'closed')`),
]);

/**
 * Goods received note. Receiving is a distinct event from ordering and from
 * recognising a supplier payable, so receipts are held separately and may be
 * partial against the purchase order.
 */
export const goodsReceipts = pgTable("goods_receipts", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  receiptNo: text("receipt_no").notNull(),
  purchaseOrderId: text("purchase_order_id"),
  receivedOn: text("received_on").notNull(),
  status: text("status").notNull().default("draft"),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  unique("goods_receipts_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("goods_receipts_client_no_idx").on(t.clientId, t.receiptNo),
  foreignKey({ columns: [t.clientId, t.purchaseOrderId], foreignColumns: [purchaseOrders.clientId, purchaseOrders.id], name: "goods_receipts_order_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "goods_receipts_client_fk" }).onDelete("restrict"),
  check("goods_receipts_status_check", sql`${t.status} in ('draft', 'posted', 'cancelled')`),
]);

export const goodsReceiptLines = pgTable("goods_receipt_lines", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  goodsReceiptId: text("goods_receipt_id").notNull(),
  lineNo: integer("line_no").notNull(),
  itemCode: text("item_code").notNull(),
  quantityReceived: quantity("quantity_received").notNull(),
  unitCost: unitRate("unit_cost").notNull(),
  inwardFreight: money("inward_freight").notNull().default(0),
}, (t) => [
  unique("goods_receipt_lines_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("goods_receipt_lines_no_idx").on(t.clientId, t.goodsReceiptId, t.lineNo),
  foreignKey({ columns: [t.clientId, t.goodsReceiptId], foreignColumns: [goodsReceipts.clientId, goodsReceipts.id], name: "goods_receipt_lines_receipt_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.itemCode], foreignColumns: [stockItems.clientId, stockItems.itemCode], name: "goods_receipt_lines_item_fk" }).onDelete("restrict"),
  check("goods_receipt_lines_values_check", sql`${t.lineNo} > 0 and ${t.quantityReceived} > 0 and ${t.unitCost} >= 0 and ${t.inwardFreight} >= 0`),
]);

/**
 * Supplier invoice: the event that recognises a payable, kept apart from the
 * purchase order and from the goods receipt. One payable may be raised against
 * several receipts, and an order may be invoiced in instalments.
 */
export const supplierInvoices = pgTable("supplier_invoices", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  invoiceNo: text("invoice_no").notNull(),
  supplierInvoiceRef: text("supplier_invoice_ref").notNull(),
  vendorId: text("vendor_id"),
  vendorName: text("vendor_name").notNull(),
  purchaseOrderId: text("purchase_order_id"),
  invoiceDate: text("invoice_date").notNull(),
  dueDate: text("due_date"),
  currency: text("currency").notNull(),
  netAmount: money("net_amount").notNull(),
  vatAmount: money("vat_amount").notNull().default(0),
  totalAmount: money("total_amount").notNull(),
  status: text("status").notNull().default("draft"),
  journalEntryId: text("journal_entry_id"),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  unique("supplier_invoices_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("supplier_invoices_client_no_idx").on(t.clientId, t.invoiceNo),
  uniqueIndex("supplier_invoices_vendor_ref_idx").on(t.clientId, t.vendorId, t.supplierInvoiceRef),
  foreignKey({ columns: [t.clientId, t.vendorId], foreignColumns: [businessPartners.clientId, businessPartners.id], name: "supplier_invoices_vendor_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.purchaseOrderId], foreignColumns: [purchaseOrders.clientId, purchaseOrders.id], name: "supplier_invoices_order_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "supplier_invoices_client_fk" }).onDelete("restrict"),
  check("supplier_invoices_dates_check", sql`${t.dueDate} is null or ${t.dueDate} >= ${t.invoiceDate}`),
  check("supplier_invoices_amounts_check", sql`${t.netAmount} >= 0 and ${t.vatAmount} >= 0 and ${t.totalAmount} >= 0`),
  check("supplier_invoices_status_check", sql`${t.status} in ('draft', 'posted', 'void')`),
]);

export const supplierInvoiceLines = pgTable("supplier_invoice_lines", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  supplierInvoiceId: text("supplier_invoice_id").notNull(),
  lineNo: integer("line_no").notNull(),
  itemCode: text("item_code"),
  description: text("description").notNull(),
  quantity: quantity("quantity").notNull(),
  unitCost: unitRate("unit_cost").notNull(),
  taxRate: rate("tax_rate").notNull().default(0),
  netAmount: money("net_amount").notNull(),
  taxAmount: money("tax_amount").notNull().default(0),
  goodsReceiptLineId: text("goods_receipt_line_id"),
}, (t) => [
  unique("supplier_invoice_lines_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("supplier_invoice_lines_no_idx").on(t.clientId, t.supplierInvoiceId, t.lineNo),
  foreignKey({ columns: [t.clientId, t.supplierInvoiceId], foreignColumns: [supplierInvoices.clientId, supplierInvoices.id], name: "supplier_invoice_lines_invoice_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.goodsReceiptLineId], foreignColumns: [goodsReceiptLines.clientId, goodsReceiptLines.id], name: "supplier_invoice_lines_receipt_line_fk" }).onDelete("restrict"),
  check("supplier_invoice_lines_values_check", sql`${t.lineNo} > 0 and ${t.quantity} > 0 and ${t.unitCost} >= 0 and ${t.netAmount} >= 0 and ${t.taxAmount} >= 0`),
]);

/**
 * Payment allocation. A payment may settle several invoices and an invoice may be
 * settled by several payments, so `paidAmount` on a document is derived from this
 * table rather than being maintained independently.
 */
export const supplierPayments = pgTable("supplier_payments", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  paymentNo: text("payment_no").notNull(),
  vendorId: text("vendor_id"),
  vendorName: text("vendor_name").notNull(),
  bankAccountId: integer("bank_account_id"),
  paidOn: text("paid_on").notNull(),
  currency: text("currency").notNull(),
  amount: money("amount").notNull(),
  journalEntryId: text("journal_entry_id"),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  unique("supplier_payments_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("supplier_payments_client_no_idx").on(t.clientId, t.paymentNo),
  foreignKey({ columns: [t.clientId, t.vendorId], foreignColumns: [businessPartners.clientId, businessPartners.id], name: "supplier_payments_vendor_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.bankAccountId], foreignColumns: [bankAccounts.clientId, bankAccounts.id], name: "supplier_payments_bank_account_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "supplier_payments_client_fk" }).onDelete("restrict"),
  check("supplier_payments_amount_check", sql`${t.amount} > 0`),
]);

export const supplierPaymentAllocations = pgTable("supplier_payment_allocations", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  paymentId: text("payment_id").notNull(),
  supplierInvoiceId: text("supplier_invoice_id").notNull(),
  amount: money("amount").notNull(),
}, (t) => [
  unique("supplier_payment_allocations_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("supplier_payment_allocation_uq").on(t.clientId, t.paymentId, t.supplierInvoiceId),
  foreignKey({ columns: [t.clientId, t.paymentId], foreignColumns: [supplierPayments.clientId, supplierPayments.id], name: "supplier_payment_allocations_payment_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.supplierInvoiceId], foreignColumns: [supplierInvoices.clientId, supplierInvoices.id], name: "supplier_payment_allocations_invoice_fk" }).onDelete("restrict"),
  check("supplier_payment_allocations_amount_check", sql`${t.amount} > 0`),
]);

export const salesInvoices = pgTable("sales_invoices", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  invNo: text("inv_no").notNull(),
  customerId: text("customer_id"),
  customerName: text("customer_name").notNull(),
  revenueStream: text("revenue_stream").notNull(),
  netRevenue: money("net_revenue").notNull(),
  vatOutput: money("vat_output").notNull().default(0),
  cstAmount: money("cst_amount"),
  tourismLevyAmount: money("tourism_levy_amount"),
  vatWithheldByCustomer: money("vat_withheld_by_customer"),
  totalReceivable: money("total_receivable").notNull(),
  paidAmount: money("paid_amount").notNull().default(0),
  status: text("status").notNull(),
  date: text("date").notNull(),
  dueDate: text("due_date"),
  currency: text("currency"),
  // Exact revenue account selected on the invoice (chart of accounts), plus the
  // trading-goods fields that drive the perpetual cost-of-sales posting.
  revenueAccount: text("revenue_account"),
  revenueAccountName: text("revenue_account_name"),
  itemType: text("item_type"),
  itemCode: text("item_code"),
  quantity: quantity("quantity"),
  unitSellingPrice: unitRate("unit_selling_price"),
  unitCost: unitRate("unit_cost"),
  cogsAmount: money("cogs_amount"),
  journalEntryId: text("journal_entry_id"),
}, (t) => [
  unique("sales_invoices_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("sales_invoices_client_inv_no_idx").on(t.clientId, t.invNo),
  index("sales_invoices_client_status_idx").on(t.clientId, t.status),
  foreignKey({ columns: [t.clientId, t.customerId], foreignColumns: [businessPartners.clientId, businessPartners.id], name: "sales_invoices_customer_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "sales_invoices_client_fk" }).onDelete("restrict"),
  check("sales_invoices_dates_check", sql`${t.dueDate} is null or ${t.dueDate} >= ${t.date}`),
  check("sales_invoices_amounts_check", sql`${t.netRevenue} >= 0 and ${t.totalReceivable} >= 0 and ${t.paidAmount} >= 0 and ${t.paidAmount} <= ${t.totalReceivable}`),
  check("sales_invoices_status_check", sql`${t.status} in ('draft', 'posted', 'partially_paid', 'paid', 'void')`),
]);

/**
 * Sales invoice lines: one legal invoice may contain several independently priced
 * products, which a single header row cannot represent.
 */
export const salesInvoiceLines = pgTable("sales_invoice_lines", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  salesInvoiceId: text("sales_invoice_id").notNull(),
  lineNo: integer("line_no").notNull(),
  itemCode: text("item_code"),
  description: text("description").notNull(),
  revenueAccount: text("revenue_account"),
  quantity: quantity("quantity").notNull(),
  unitPrice: unitRate("unit_price").notNull(),
  taxRate: rate("tax_rate").notNull().default(0),
  netAmount: money("net_amount").notNull(),
  taxAmount: money("tax_amount").notNull().default(0),
  cogsAmount: money("cogs_amount").notNull().default(0),
}, (t) => [
  unique("sales_invoice_lines_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("sales_invoice_lines_no_idx").on(t.clientId, t.salesInvoiceId, t.lineNo),
  foreignKey({ columns: [t.clientId, t.salesInvoiceId], foreignColumns: [salesInvoices.clientId, salesInvoices.id], name: "sales_invoice_lines_invoice_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.itemCode], foreignColumns: [stockItems.clientId, stockItems.itemCode], name: "sales_invoice_lines_item_fk" }).onDelete("restrict"),
  check("sales_invoice_lines_values_check", sql`${t.lineNo} > 0 and ${t.quantity} > 0 and ${t.unitPrice} >= 0 and ${t.netAmount} >= 0 and ${t.taxAmount} >= 0 and ${t.cogsAmount} >= 0`),
]);

export const customerReceipts = pgTable("customer_receipts", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  receiptNo: text("receipt_no").notNull(),
  customerId: text("customer_id"),
  customerName: text("customer_name").notNull(),
  bankAccountId: integer("bank_account_id"),
  receivedOn: text("received_on").notNull(),
  currency: text("currency").notNull(),
  amount: money("amount").notNull(),
  journalEntryId: text("journal_entry_id"),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  unique("customer_receipts_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("customer_receipts_client_no_idx").on(t.clientId, t.receiptNo),
  foreignKey({ columns: [t.clientId, t.customerId], foreignColumns: [businessPartners.clientId, businessPartners.id], name: "customer_receipts_customer_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.bankAccountId], foreignColumns: [bankAccounts.clientId, bankAccounts.id], name: "customer_receipts_bank_account_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "customer_receipts_client_fk" }).onDelete("restrict"),
  check("customer_receipts_amount_check", sql`${t.amount} > 0`),
]);

/** Many-to-many settlement: one receipt across several invoices. */
export const customerReceiptAllocations = pgTable("customer_receipt_allocations", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  receiptId: text("receipt_id").notNull(),
  salesInvoiceId: text("sales_invoice_id").notNull(),
  amount: money("amount").notNull(),
}, (t) => [
  unique("customer_receipt_allocations_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("customer_receipt_allocation_uq").on(t.clientId, t.receiptId, t.salesInvoiceId),
  foreignKey({ columns: [t.clientId, t.receiptId], foreignColumns: [customerReceipts.clientId, customerReceipts.id], name: "customer_receipt_allocations_receipt_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.salesInvoiceId], foreignColumns: [salesInvoices.clientId, salesInvoices.id], name: "customer_receipt_allocations_invoice_fk" }).onDelete("restrict"),
  check("customer_receipt_allocations_amount_check", sql`${t.amount} > 0`),
]);

/**
 * Imported bank statement lines. Deliberately separate from `bank_accounts.balance`:
 * a statement balance is evidence, not the ledger figure, and the two must be
 * reconciled rather than conflated.
 */
export const bankStatementLines = pgTable("bank_statement_lines", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  bankAccountId: integer("bank_account_id").notNull(),
  statementReference: text("statement_reference").notNull(),
  statementDate: text("statement_date").notNull(),
  statementAmount: money("statement_amount").notNull(),
  importedRunningBalance: money("imported_running_balance"),
  matchedJournalEntryId: text("matched_journal_entry_id"),
  importedAt: timestamp("imported_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  unique("bank_statement_lines_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("bank_statement_lines_ref_uq").on(t.clientId, t.bankAccountId, t.statementReference),
  foreignKey({ columns: [t.clientId, t.bankAccountId], foreignColumns: [bankAccounts.clientId, bankAccounts.id], name: "bank_statement_lines_account_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.matchedJournalEntryId], foreignColumns: [journalEntries.clientId, journalEntries.id], name: "bank_statement_lines_journal_fk" }).onDelete("restrict"),
]);

export const employees = pgTable("employees", {
  id: integer("id").primaryKey(),
  clientId: integer("client_id"),
  bpNo: text("bp_no").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  department: text("department").notNull(),
  costCenter: text("cost_center"),
  jurisdiction: text("jurisdiction").notNull(),
  basicSalary: money("basic_salary").notNull(),
  allowances: money("allowances").notNull().default(0),
  ssnitNumber: text("ssnit_number").notNull(),
  tin: text("tin").notNull(),
  status: text("status").notNull(),
  isResident: boolean("is_resident").notNull().default(true),
  exemptTier1: boolean("exempt_tier1").notNull().default(false),
  exemptTier2: boolean("exempt_tier2").notNull().default(false),
  ssnitExempt: boolean("ssnit_exempt").notNull().default(false),
  ssnitExemptionReason: text("ssnit_exemption_reason"),
  taxRelief: money("tax_relief").notNull().default(0),
  reliefType: text("relief_type"),
  deductions: jsonb("deductions"),
}, (t) => [
  uniqueIndex("employees_client_bp_no_idx").on(t.clientId, t.bpNo),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "employees_client_fk" }).onDelete("restrict"),
  check("employees_amounts_check", sql`${t.basicSalary} >= 0 and ${t.allowances} >= 0 and ${t.taxRelief} >= 0`),
  check("employees_status_check", sql`${t.status} in ('active', 'inactive', 'terminated')`),
]);

export const companyProfiles = pgTable("company_profiles", {
  clientId: integer("client_id").primaryKey(),
  legalName: text("legal_name").notNull(),
  tradingName: text("trading_name").notNull(),
  tin: text("tin").notNull(),
  vatRegNo: text("vat_reg_no").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  website: text("website").notNull(),
  fiscalYearStart: text("fiscal_year_start").notNull(),
  bankPaymentDetails: text("bank_payment_details").notNull(),
}, (t) => [
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "company_profiles_client_fk" }).onDelete("restrict"),
]);

export const chartAccounts = pgTable("chart_accounts", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  accountNo: text("account_no").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  category: text("category").notNull(),
  active: boolean("active").notNull().default(true),
  isCustom: boolean("is_custom").notNull().default(false),
  clientId: integer("client_id"), // null = firm master chart shared by all entities
}, (t) => [
  // Master rows (client_id null) must be unique too: PostgreSQL's default NULL
  // semantics would otherwise allow duplicate master account numbers. Two partial
  // unique indexes give the master chart and each client's custom accounts their
  // own protected key, and also define the precedence rule — a client account with
  // the same number overrides the master for that entity only.
  uniqueIndex("chart_accounts_master_no_idx").on(t.accountNo).where(sql`${t.clientId} is null`),
  uniqueIndex("chart_accounts_scope_idx").on(t.clientId, t.accountNo).where(sql`${t.clientId} is not null`),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "chart_accounts_client_fk" }).onDelete("restrict"),
  check("chart_accounts_type_check", sql`${t.type} in ('asset', 'liability', 'equity', 'revenue', 'expense')`),
]);

export const businessPartners = pgTable("business_partners", {
  id: text("id").primaryKey(),
  clientId: integer("client_id"),
  code: text("code").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  tin: text("tin").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  currency: text("currency").notNull(),
  isVatWithholdingAgent: boolean("is_vat_withholding_agent").notNull().default(false),
  vatWithholdingRate: rate("vat_withholding_rate"),
  isCstApplicable: boolean("is_cst_applicable").notNull().default(false),
  isTourismLevyApplicable: boolean("is_tourism_levy_applicable").notNull().default(false),
  isVatRegistered: boolean("is_vat_registered"),
}, (t) => [
  unique("business_partners_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("business_partners_client_code_idx").on(t.clientId, t.code),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "business_partners_client_fk" }).onDelete("restrict"),
  check("business_partners_type_check", sql`${t.type} in ('customer', 'supplier', 'both')`),
]);

export const payrollRecords = pgTable("payroll_records", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  record: jsonb("record").notNull(),
  // Key payroll figures are promoted out of the JSON snapshot so they can be
  // constrained, aggregated and reconciled to the ledger.
  period: text("period"),
  grossPay: money("gross_pay"),
  payeTax: money("paye_tax"),
  netPay: money("net_pay"),
  employeeId: integer("employee_id"),
  journalEntryId: text("journal_entry_id"),
}, (t) => [
  unique("payroll_records_client_id_id_uq").on(t.clientId, t.id),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "payroll_records_client_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.employeeId], foreignColumns: [employees.clientId, employees.id], name: "payroll_records_employee_fk" }).onDelete("restrict"),
  check("payroll_records_amounts_check", sql`${t.grossPay} is null or (${t.grossPay} >= 0 and ${t.payeTax} >= 0 and ${t.netPay} >= 0)`),
]);

export const prepaymentRecords = pgTable("prepayment_records", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  record: jsonb("record").notNull(),
  originalAmount: money("original_amount"),
  startDate: text("start_date"),
  endDate: text("end_date"),
  journalEntryId: text("journal_entry_id"),
}, (t) => [
  unique("prepayment_records_client_id_id_uq").on(t.clientId, t.id),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "prepayment_records_client_fk" }).onDelete("restrict"),
  check("prepayment_records_amount_check", sql`${t.originalAmount} is null or ${t.originalAmount} > 0`),
]);

export const prepaymentSchedules = pgTable("prepayment_schedules", {
  id: text("id").primaryKey(),
  prepaymentId: text("prepayment_id").notNull(),
  clientId: integer("client_id").notNull(),
  line: jsonb("line").notNull(),
  lineNo: integer("line_no"),
  amount: money("amount"),
  scheduleDate: text("schedule_date"),
}, (t) => [
  unique("prepayment_schedules_client_id_id_uq").on(t.clientId, t.id),
  // A schedule line can only belong to a prepayment of the same entity.
  foreignKey({ columns: [t.clientId, t.prepaymentId], foreignColumns: [prepaymentRecords.clientId, prepaymentRecords.id], name: "prepayment_schedules_prepayment_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "prepayment_schedules_client_fk" }).onDelete("restrict"),
  check("prepayment_schedules_amount_check", sql`${t.amount} is null or ${t.amount} >= 0`),
]);

export const approvalRequests = pgTable("approval_requests", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  clientCode: text("client_code").notNull(),
  clientName: text("client_name").notNull(),
  docNo: text("doc_no").notNull(),
  docType: text("doc_type").notNull(),
  amount: money("amount").notNull(),
  currency: text("currency"),
  requestedBy: text("requested_by").notNull(),
  requestedAt: text("requested_at").notNull(),
  description: text("description").notNull(),
  reasonForApproval: text("reason_for_approval").notNull(),
  status: text("status").notNull(),
  reviewedBy: text("reviewed_by"),
  reviewedAt: text("reviewed_at"),
  rejectionReason: text("rejection_reason"),
  // Proposed journal lines awaiting sign-off; posted exactly once on approval.
  // The approval binds to a specific version and hash of that proposal, so a
  // material change invalidates the earlier approval.
  payload: jsonb("payload"),
  payloadVersion: integer("payload_version"),
  payloadHash: text("payload_hash"),
  approvedJournalEntryId: text("approved_journal_entry_id"),
}, (t) => [
  unique("approval_requests_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("approval_requests_client_doc_idx").on(t.clientId, t.docNo, t.docType, t.payloadVersion),
  uniqueIndex("approval_requests_posted_journal_idx").on(t.clientId, t.approvedJournalEntryId),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "approval_requests_client_fk" }).onDelete("restrict"),
  check("approval_requests_amount_check", sql`${t.amount} > 0`),
  check("approval_requests_status_check", sql`${t.status} in ('pending', 'approved', 'rejected', 'cancelled')`),
  check("approval_requests_reviewed_check", sql`(${t.status} in ('pending', 'cancelled') and ${t.reviewedBy} is null) or (${t.status} in ('approved', 'rejected') and ${t.reviewedBy} is not null and ${t.reviewedBy} <> ${t.requestedBy})`),
]);

export const disclosureNotes = pgTable("disclosure_notes", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  key: text("key").notNull(),
  noteNumber: integer("note_number").notNull(),
  title: text("title").notNull(),
  standardRef: text("standard_ref").notNull(),
  applicable: boolean("applicable").notNull(),
  notApplicableReason: text("not_applicable_reason"),
  body: text("body").notNull(),
  tables: jsonb("tables"),
  editableOverride: boolean("editable_override"),
}, (t) => [uniqueIndex("disclosure_notes_key_idx").on(t.key)]);

/**
 * Tenant-owned disclosure note instances. `disclosure_notes` holds the shared
 * reporting template; anything an entity actually discloses lives here, scoped by
 * entity and period.
 */
export const clientDisclosureNotes = pgTable("client_disclosure_notes", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  clientId: integer("client_id").notNull(),
  templateKey: text("template_key").notNull(),
  period: text("period").notNull(),
  body: text("body").notNull(),
  tables: jsonb("tables"),
  updatedBy: text("updated_by"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("client_disclosure_notes_scope_idx").on(t.clientId, t.templateKey, t.period),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "client_disclosure_notes_client_fk" }).onDelete("restrict"),
]);

export const closedPeriods = pgTable("closed_periods", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  clientId: integer("client_id").notNull(),
  period: text("period").notNull(), // e.g. "2026-03"
  closedAt: text("closed_at").notNull(),
  closedBy: text("closed_by").notNull(),
}, (t) => [
  uniqueIndex("closed_periods_client_period_idx").on(t.clientId, t.period),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "closed_periods_client_fk" }).onDelete("restrict"),
]);

/**
 * Statutory schedule lines (withholding tax & VAT). Journal-derived rows live in
 * the ledger; this table stores user EDITS of derived rows (source='ledger',
 * keyed by source_key) and manually ADDED rows (source='manual'). Tenant-scoped,
 * with a unique source-row key so one derived row cannot be overridden twice.
 */
export const taxScheduleEntries = pgTable("tax_schedule_entries", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  kind: text("kind").notNull(), // wht | wht_credit | vat_output | vat_input
  source: text("source").notNull(), // manual | ledger
  sourceKey: text("source_key"),
  period: text("period").notNull(),
  date: text("date").notNull(),
  docNo: text("doc_no").notNull(),
  partyName: text("party_name").notNull(),
  partyTin: text("party_tin").notNull().default(""),
  nature: text("nature").notNull().default(""),
  grossAmount: money("gross_amount").notNull().default(0),
  rate: rate("rate").notNull().default(0),
  taxAmount: money("tax_amount").notNull().default(0),
  levyAmount: money("levy_amount").notNull().default(0),
  reference: text("reference").notNull().default(""),
  status: text("status").notNull().default(""),
  note: text("note"),
  adjustmentReason: text("adjustment_reason"),
  originalTaxAmount: money("original_tax_amount"),
  createdBy: text("created_by").notNull(),
  updatedAt: text("updated_at").notNull(),
}, (t) => [
  unique("tax_schedule_entries_client_id_id_uq").on(t.clientId, t.id),
  // One override per derived source row per entity and schedule kind.
  uniqueIndex("tax_schedule_source_key_idx").on(t.clientId, t.kind, t.sourceKey),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "tax_schedule_entries_client_fk" }).onDelete("restrict"),
  check("tax_schedule_entries_kind_check", sql`${t.kind} in ('wht', 'wht_credit', 'vat_output', 'vat_input')`),
  check("tax_schedule_entries_source_check", sql`${t.source} in ('manual', 'ledger')`),
  check("tax_schedule_entries_amounts_check", sql`${t.grossAmount} >= 0 and ${t.taxAmount} >= 0 and ${t.levyAmount} >= 0`),
  check("tax_schedule_entries_adjustment_reason_check", sql`${t.originalTaxAmount} is null or ${t.adjustmentReason} is not null`),
]);

/**
 * Perpetual inventory subsystem — item master. Quantity and value are kept
 * together so the valuation report always reconciles to the inventory control
 * account (120000). `costMethod` is fixed per item (IAS 2 consistency).
 */
export const stockItems = pgTable("stock_items", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  itemCode: text("item_code").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  uom: text("uom").notNull(),
  quantityOnHand: quantity("quantity_on_hand").notNull().default(0),
  unitCost: unitRate("unit_cost").notNull().default(0),
  totalValue: money("total_value").notNull().default(0),
  reorderLevel: quantity("reorder_level"),
  location: text("location"),
  glAccount: text("gl_account"),
  costMethod: text("cost_method"), // weighted_average | fifo | specific
  netRealisableValue: money("net_realisable_value"),
}, (t) => [
  unique("stock_items_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("stock_items_scope_idx").on(t.clientId, t.itemCode),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "stock_items_client_fk" }).onDelete("restrict"),
  check("stock_items_values_check", sql`${t.quantityOnHand} >= 0 and ${t.unitCost} >= 0 and ${t.totalValue} >= 0`),
  check("stock_items_cost_method_check", sql`${t.costMethod} is null or ${t.costMethod} in ('weighted_average', 'fifo', 'specific')`),
]);

/** Every receipt, issue, freight capitalisation, return, write-down and count adjustment. */
export const stockMovements = pgTable("stock_movements", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  date: text("date").notNull(),
  itemCode: text("item_code").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(),
  quantity: quantity("quantity").notNull().default(0),
  unitCost: unitRate("unit_cost").notNull().default(0),
  totalValue: money("total_value").notNull().default(0),
  uom: text("uom").notNull(),
  reference: text("reference"),
  docNo: text("doc_no"),
  note: text("note"),
  // Traceability: the movement, its cost basis and the ledger entry it produced.
  direction: text("direction"),
  goodsReceiptLineId: text("goods_receipt_line_id"),
  salesInvoiceLineId: text("sales_invoice_line_id"),
  stockCountLineId: text("stock_count_line_id"),
  costLayerId: text("cost_layer_id"),
  journalEntryId: text("journal_entry_id"),
}, (t) => [
  unique("stock_movements_client_id_id_uq").on(t.clientId, t.id),
  index("stock_movements_client_item_date_idx").on(t.clientId, t.itemCode, t.date),
  uniqueIndex("stock_movements_receipt_line_idx").on(t.clientId, t.goodsReceiptLineId),
  uniqueIndex("stock_movements_sales_line_idx").on(t.clientId, t.salesInvoiceLineId),
  foreignKey({ columns: [t.clientId, t.itemCode], foreignColumns: [stockItems.clientId, stockItems.itemCode], name: "stock_movements_item_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.goodsReceiptLineId], foreignColumns: [goodsReceiptLines.clientId, goodsReceiptLines.id], name: "stock_movements_receipt_line_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.salesInvoiceLineId], foreignColumns: [salesInvoiceLines.clientId, salesInvoiceLines.id], name: "stock_movements_sales_line_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.stockCountLineId], foreignColumns: [stockCountLines.clientId, stockCountLines.id], name: "stock_movements_count_line_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.journalEntryId], foreignColumns: [journalEntries.clientId, journalEntries.id], name: "stock_movements_journal_fk" }).onDelete("restrict"),
  check("stock_movements_values_check", sql`${t.quantity} > 0 and ${t.unitCost} >= 0 and ${t.totalValue} >= 0`),
  check("stock_movements_type_check", sql`${t.type} in ('receipt', 'issue', 'freight', 'customer_return', 'supplier_return', 'write_down', 'count_adjustment', 'transfer')`),
  check("stock_movements_direction_check", sql`${t.direction} is null or ${t.direction} in ('in', 'out')`),
]);

/**
 * Cost layers (FIFO / weighted-average history). Stock issued is allocated
 * against these layers, so the cost of any sale remains explainable by the
 * receipts that support it and historical margins are never restated at today's
 * purchase price.
 */
export const stockCostLayers = pgTable("stock_cost_layers", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  itemCode: text("item_code").notNull(),
  receiptMovementId: text("receipt_movement_id").notNull(),
  receivedOn: text("received_on").notNull(),
  quantityReceived: quantity("quantity_received").notNull(),
  quantityRemaining: quantity("quantity_remaining").notNull(),
  unitCost: unitRate("unit_cost").notNull(),
}, (t) => [
  unique("stock_cost_layers_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("stock_cost_layers_receipt_movement_idx").on(t.clientId, t.receiptMovementId),
  index("stock_cost_layers_fifo_idx").on(t.clientId, t.itemCode, t.receivedOn),
  foreignKey({ columns: [t.clientId, t.receiptMovementId], foreignColumns: [stockMovements.clientId, stockMovements.id], name: "stock_cost_layers_movement_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.itemCode], foreignColumns: [stockItems.clientId, stockItems.itemCode], name: "stock_cost_layers_item_fk" }).onDelete("restrict"),
  check("stock_cost_layers_quantities_check", sql`${t.quantityReceived} > 0 and ${t.quantityRemaining} >= 0 and ${t.quantityRemaining} <= ${t.quantityReceived} and ${t.unitCost} >= 0`),
]);

/** Links an issued quantity to the layer (and cost) that supports it. */
export const stockCostAllocations = pgTable("stock_cost_allocations", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  issueMovementId: text("issue_movement_id").notNull(),
  costLayerId: text("cost_layer_id").notNull(),
  quantity: quantity("quantity").notNull(),
  unitCost: unitRate("unit_cost").notNull(),
  allocatedCost: money("allocated_cost").notNull(),
}, (t) => [
  unique("stock_cost_allocations_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("stock_cost_allocations_movement_layer_idx").on(t.clientId, t.issueMovementId, t.costLayerId),
  foreignKey({ columns: [t.clientId, t.issueMovementId], foreignColumns: [stockMovements.clientId, stockMovements.id], name: "stock_cost_allocations_issue_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.costLayerId], foreignColumns: [stockCostLayers.clientId, stockCostLayers.id], name: "stock_cost_allocations_layer_fk" }).onDelete("restrict"),
  check("stock_cost_allocations_values_check", sql`${t.quantity} > 0 and ${t.unitCost} >= 0 and ${t.allocatedCost} >= 0`),
]);

export const stockCounts = pgTable("stock_counts", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  countNo: text("count_no").notNull(),
  countDate: text("count_date").notNull(),
  status: text("status").notNull().default("draft"),
  createdBy: text("created_by").notNull(),
  approvedBy: text("approved_by"),
  approvedAt: text("approved_at"),
  journalEntryId: text("journal_entry_id"),
}, (t) => [
  unique("stock_counts_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("stock_counts_client_no_idx").on(t.clientId, t.countNo),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "stock_counts_client_fk" }).onDelete("restrict"),
  check("stock_counts_status_check", sql`${t.status} in ('draft', 'approved', 'posted', 'cancelled')`),
]);

export const stockCountLines = pgTable("stock_count_lines", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  stockCountId: text("stock_count_id").notNull(),
  lineNo: integer("line_no").notNull(),
  itemCode: text("item_code").notNull(),
  quantityBeforeCount: quantity("quantity_before_count").notNull(),
  quantityCounted: quantity("quantity_counted").notNull(),
  adjustmentReason: text("adjustment_reason"),
}, (t) => [
  unique("stock_count_lines_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("stock_count_lines_no_idx").on(t.clientId, t.stockCountId, t.lineNo),
  foreignKey({ columns: [t.clientId, t.stockCountId], foreignColumns: [stockCounts.clientId, stockCounts.id], name: "stock_count_lines_count_fk" }).onDelete("restrict"),
  foreignKey({ columns: [t.clientId, t.itemCode], foreignColumns: [stockItems.clientId, stockItems.itemCode], name: "stock_count_lines_item_fk" }).onDelete("restrict"),
  check("stock_count_lines_quantities_check", sql`${t.lineNo} > 0 and ${t.quantityBeforeCount} >= 0 and ${t.quantityCounted} >= 0`),
]);

/**
 * Fixed asset register (IAS 16) with the tax base needed for capital allowances
 * and IAS 12 deferred tax.
 */
export const fixedAssets = pgTable("fixed_assets", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  assetTag: text("asset_tag").notNull(),
  name: text("name").notNull(),
  classCode: text("class_code").notNull(),
  cost: money("cost").notNull().default(0),
  accumDep: money("accum_dep").notNull().default(0),
  usefulLife: text("useful_life").notNull(),
  depreciationRate: rate("depreciation_rate"),
  depreciationMethod: text("depreciation_method"),
  capitalAllowanceClass: text("capital_allowance_class"),
  capitalAllowanceRate: rate("capital_allowance_rate"),
  accumCapitalAllowance: money("accum_capital_allowance").notNull().default(0),
  location: text("location").notNull().default(""),
  acquired: text("acquired"),
  disposedDate: text("disposed_date"),
  disposalProceeds: money("disposal_proceeds"),
}, (t) => [
  unique("fixed_assets_client_id_id_uq").on(t.clientId, t.id),
  uniqueIndex("fixed_assets_client_tag_idx").on(t.clientId, t.assetTag),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "fixed_assets_client_fk" }).onDelete("restrict"),
  check("fixed_assets_values_check", sql`${t.cost} >= 0 and ${t.accumDep} >= 0 and ${t.accumCapitalAllowance} >= 0`),
]);

/**
 * Structured audit trail. Entity identity, actor, correlation reference and a
 * timezone-aware event time are first-class columns; `details` stays free-text
 * only for human context and must never carry secrets.
 */
export const auditLog = pgTable("audit_log", {
  id: text("id").primaryKey(),
  timestamp: text("timestamp").notNull(),
  userId: text("user_id").notNull(),
  username: text("username").notNull(),
  action: text("action").notNull(),
  target: text("target").notNull(),
  details: text("details").notNull(),
  clientId: integer("client_id"),
  entityType: text("entity_type"),
  entityId: text("entity_id"),
  correlationId: text("correlation_id"),
  occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("audit_log_client_occurred_idx").on(t.clientId, t.occurredAt),
  index("audit_log_entity_idx").on(t.clientId, t.entityType, t.entityId),
  foreignKey({ columns: [t.clientId], foreignColumns: [clients.id], name: "audit_log_client_fk" }).onDelete("restrict"),
]);
