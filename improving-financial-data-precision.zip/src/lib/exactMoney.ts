/**
 * Exact decimal boundary helpers.
 *
 * Money is stored in PostgreSQL as `numeric(precision, scale)` (exact), never as
 * binary floating point. Arithmetic that must stay exact — document balancing,
 * subledger reconciliation, cached-balance rebuilds — is performed on integer
 * minor units here, not on JavaScript numbers.
 *
 * `fromExact`/`toExact` are the only place where an exact database value crosses
 * into JavaScript and back, so every aggregation the application performs goes
 * through integer minor units.
 */

export const CENTS_SCALE = 2;

/** Reads an exact numeric value from the driver and converts it to minor units. */
export function exactToMinor(value: string | number, scale = CENTS_SCALE): bigint {
  const text = typeof value === "number" ? numberToExactString(value, scale) : String(value).trim();
  const match = /^(-?)(\d+)(?:\.(\d+))?$/.exec(text);
  if (!match) throw new Error(`Invalid exact decimal: ${text}`);
  const fraction = (match[3] ?? "").padEnd(scale, "0").slice(0, scale);
  const minor = BigInt(match[2]) * BigInt(10) ** BigInt(scale) + BigInt(fraction || "0");
  return match[1] === "-" ? -minor : minor;
}

/** Converts minor units back to an exact decimal string for the driver. */
export function minorToExactString(minor: bigint, scale = CENTS_SCALE): string {
  const negative = minor < BigInt(0);
  const magnitude = negative ? -minor : minor;
  const factor = BigInt(10) ** BigInt(scale);
  const whole = magnitude / factor;
  const fraction = scale > 0 ? (magnitude % factor).toString().padStart(scale, "0") : "";
  return `${negative ? "-" : ""}${whole}${fraction ? `.${fraction}` : ""}`;
}

/**
 * Rounds a JavaScript number onto the column scale using integer minor units.
 * Half-up rounding is applied to the scaled value so a stored amount never
 * depends on binary floating-point representation.
 */
export function numberToExactString(value: number, scale = CENTS_SCALE): string {
  if (!Number.isFinite(value)) throw new Error("Amounts must be finite numbers.");
  const factor = BigInt(10) ** BigInt(scale);
  const scaled = value * Number(factor);
  const rounded = scaled >= 0 ? Math.round(scaled) : -Math.round(-scaled);
  return minorToExactString(BigInt(rounded), scale);
}

/** Reads an exact decimal from the driver into a JavaScript number for display. */
export function exactToNumber(value: string | number, scale = CENTS_SCALE): number {
  const minor = exactToMinor(value, scale);
  return Number(minor) / Number(BigInt(10) ** BigInt(scale));
}

/** Sums exact amounts without floating-point drift. */
export function sumExact(values: Array<number | string>, scale = CENTS_SCALE): number {
  const total = values.reduce((sum, value) => sum + exactToMinor(value, scale), BigInt(0));
  return Number(total) / Number(BigInt(10) ** BigInt(scale));
}

/** True when two amounts are identical at the column scale. */
export function exactEquals(left: number | string, right: number | string, scale = CENTS_SCALE): boolean {
  return exactToMinor(left, scale) === exactToMinor(right, scale);
}
