import { useState } from 'react';
import type { ACDOCALine, ClientEntity, UserAccount } from '../types/accounting';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { Save } from 'lucide-react';
import { docSuffix, uniqueId } from '../utils/ids';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  isPeriodClosed: boolean;
  lines: ACDOCALine[];
  onAddJournalLines: (lines: ACDOCALine[]) => boolean;
}

interface StockMovement {
  id: string;
  date: string;
  itemCode: string;
  description: string;
  type: 'Receipt' | 'Issue' | 'Adjustment';
  quantity: number;
  unitCost: number;
  uom: string;
}

const persist = {
  read(clientId: number): StockMovement[] {
    try {
      const raw = localStorage.getItem(`bpz_stock_${clientId}`);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  },
  write(clientId: number, items: StockMovement[]) {
    try { localStorage.setItem(`bpz_stock_${clientId}`, JSON.stringify(items)); } catch { /* ignore */ }
  },
};

export const InventorySection = ({ currentClient, currentUser, isPeriodClosed, lines, onAddJournalLines }: Props) => {
  const [movements, setMovements] = useState<StockMovement[]>(() => persist.read(currentClient.id));
  const [itemCode, setItemCode] = useState('MAT-001');
  const [description, setDescription] = useState('High Tensile Drill Rods');
  const [type, setType] = useState<StockMovement['type']>('Receipt');
  const [qty, setQty] = useState(0);
  const [unitCost, setUnitCost] = useState(0);
  const [uom, setUom] = useState('Units');
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [feedback, setFeedback] = useState<string | null>(null);

  const inventoryMovements = movements.filter(m => m.itemCode === itemCode);
  const onHandQty = inventoryMovements.reduce((n, m) => n + (m.type === 'Issue' ? -m.quantity : m.quantity), 0);
  const totalValue = inventoryMovements.reduce((n, m) => n + (m.type === 'Issue' ? -1 : 1) * m.quantity * m.unitCost, 0);
  const journalBalance = lines.filter(l => l.clientId === currentClient.id && l.accountNo === '120000').reduce((n, l) => n + Math.round((l.debit - l.credit) * 100), 0) / 100;

  const isRestricted = currentUser.status === 'restricted' || currentUser.status === 'suspended';

  const handlePost = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (isPeriodClosed) return setFeedback('Posting blocked. Period is closed.');
    if (isRestricted) return setFeedback('Action blocked. Your account has been restricted.');
    if (qty <= 0 || unitCost < 0 || !Number.isFinite(qty) || !Number.isFinite(unitCost)) return setFeedback('Enter a positive quantity and non-negative unit cost.');
    if (type === 'Issue' && qty > onHandQty) return setFeedback(`Cannot issue ${qty}; only ${onHandQty} on hand.`);

    const period = date.slice(0, 7);
    const docNo = `INV-${period}-${docSuffix()}`;
    const totalAmount = qty * unitCost;
    const isDebit = type === 'Receipt';
    // Post the ledger entry FIRST; the stock movement is persisted only when the
    // accounting entry is accepted, so stock records can never drift from the GL.
    // Adjustments (count variances) write stock down: Dr 690000 / Cr 120000.
    const lines2Post: ACDOCALine[] | null = totalAmount <= 0
      ? null
      : type === 'Adjustment'
        ? [
            { id: `${uniqueId('JL-STK')}-1`, docNo, period, date, module: 'INV', docType: 'STAT', accountNo: '690000', accountName: 'Impairment Loss on Non-Financial Assets (stock variance)', costCenter: 'CC-OPS', debit: totalAmount, credit: 0, currency: currentClient.currency, description: `Stock count adjustment ${itemCode} x ${qty} ${uom}`, createdBy: currentUser.username, clientId: currentClient.id },
            { id: `${uniqueId('JL-STK')}-2`, docNo, period, date, module: 'INV', docType: 'STAT', accountNo: '120000', accountName: `Inventory - ${description}`, costCenter: 'CC-OPS', debit: 0, credit: totalAmount, currency: currentClient.currency, description: `Stock write-down ${itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
          ]
        : isDebit
        ? [
            { id: `${uniqueId('JL-STK')}-1`, docNo, period, date, module: 'INV', docType: 'STAT', accountNo: '120000', accountName: `Inventory - ${description}`, costCenter: 'CC-OPS', debit: totalAmount, credit: 0, currency: currentClient.currency, description: `Stock receipt ${itemCode} x ${qty} ${uom}`, createdBy: currentUser.username, clientId: currentClient.id },
            { id: `${uniqueId('JL-STK')}-2`, docNo, period, date, module: 'FI', docType: 'STAT', accountNo: '200000', accountName: 'Trade Payables (Stock Receipt)', costCenter: 'CC-PRC', debit: 0, credit: totalAmount, currency: currentClient.currency, description: `Inventory liability for ${itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
          ]
        : [
            { id: `${uniqueId('JL-STK')}-1`, docNo, period, date, module: 'INV', docType: 'STAT', accountNo: '500000', accountName: 'Cost of Sales / Direct Site Extraction', costCenter: 'CC-OPS', debit: totalAmount, credit: 0, currency: currentClient.currency, description: `Stock issue ${itemCode} x ${qty} ${uom}`, createdBy: currentUser.username, clientId: currentClient.id },
            { id: `${uniqueId('JL-STK')}-2`, docNo, period, date, module: 'INV', docType: 'STAT', accountNo: '120000', accountName: `Inventory - ${description}`, costCenter: 'CC-OPS', debit: 0, credit: totalAmount, currency: currentClient.currency, description: `Inventory release for ${itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
          ];
    if (lines2Post) {
      const ok = onAddJournalLines(lines2Post);
      if (!ok) return setFeedback('Stock movement NOT recorded: the accounting entry was rejected. Review the period / balance.');
    }
    const newMovements = [...movements, { id: uniqueId('ID'), date, itemCode, description, type, quantity: qty, unitCost, uom }];
    setMovements(newMovements);
    persist.write(currentClient.id, newMovements);
    setQty(0);
    setFeedback(`Recorded ${type.toLowerCase()} for ${itemCode}.`);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`INV · Stock & Inventory · ${currentClient.code}`}
        title="Inventory & Stock Valuation (IAS 2)"
        desc="Stock movements, on-hand quantity and ledger reconciliation for account 120000."
      />
      {feedback && <div className={`text-xs rounded-lg p-3 ${feedback.startsWith('Recorded') ? 'bg-emerald-50 text-emerald-900 border border-emerald-300' : 'bg-rose-50 text-rose-900 border border-rose-300'}`}>{feedback}</div>}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card title="On hand">
          <div className="font-mono text-2xl font-black text-[#082f4f]">{onHandQty} <span className="text-xs text-[#355875] font-sans font-bold">{uom}</span></div>
        </Card>
        <Card title="Carrying value (weighted)">
          <div className="font-mono text-2xl font-black text-emerald-800">₵{formatGHS(totalValue)}</div>
        </Card>
        <Card title="Ledger 120000 (unverified)">
          <div className="font-mono text-2xl font-black text-[#006f98]">₵{formatGHS(journalBalance)}</div>
          <div className="text-[10.5px] text-[#355875] mt-0.5">Difference may indicate unposted stock adjustments.</div>
        </Card>
      </div>

        <Card title="Record a stock movement" sub="Receipts post Dr 120000 / Cr 200000; issues post Dr 500000 / Cr 120000; adjustments post Dr 690000 / Cr 120000">
        <form onSubmit={handlePost} className="grid grid-cols-1 sm:grid-cols-6 gap-3 text-xs">
          <input type="date" value={date} onChange={e => setDate(e.target.value)} className="rounded border border-sky-300 p-2" />
          <input value={itemCode} onChange={e => setItemCode(e.target.value)} placeholder="Item code" className="rounded border border-sky-300 p-2" required />
          <input value={description} onChange={e => setDescription(e.target.value)} placeholder="Description" className="rounded border border-sky-300 p-2 sm:col-span-2" required />
          <select value={type} onChange={e => setType(e.target.value as StockMovement['type'])} className="rounded border border-sky-300 p-2 font-semibold">
            <option value="Receipt">Receipt (purchase)</option>
            <option value="Issue">Issue (consumed / sold)</option>
            <option value="Adjustment">Adjustment (no GL)</option>
          </select>
          <select value={uom} onChange={e => setUom(e.target.value)} className="rounded border border-sky-300 p-2 font-semibold">
            <option>Units</option><option>Tons</option><option>Drums</option><option>Litres</option><option>Kg</option>
          </select>
          <input type="number" min="0" step="0.01" value={qty || ''} onChange={e => setQty(Number(e.target.value))} placeholder="Quantity" className="rounded border border-sky-300 p-2 font-mono" required />
          <input type="number" min="0" step="0.01" value={unitCost || ''} onChange={e => setUnitCost(Number(e.target.value))} placeholder="Unit cost" className="rounded border border-sky-300 p-2 font-mono sm:col-span-2" />
          <button type="submit" disabled={isPeriodClosed || isRestricted} className="rounded bg-[#082f4f] text-white font-bold text-xs py-2 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 sm:col-span-3">
            <Save className="h-3.5 w-3.5" /> Record movement
          </button>
        </form>
      </Card>

      <Card title={`Stock movements for ${itemCode}`} sub={`${movements.length} movements recorded for this workspace`}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Date</th>
                <th className={thCls}>Type</th>
                <th className={thCls + ' text-right'}>Quantity</th>
                <th className={thCls + ' text-right'}>Unit Cost (₵)</th>
                <th className={thCls + ' text-right'}>Value (₵)</th>
              </tr>
            </thead>
            <tbody>
              {movements.length === 0 ? (
                <tr><td colSpan={5} className="px-3 py-6 text-center text-[#355875]">No stock movements recorded for this workspace yet.</td></tr>
              ) : movements.map(m => (
                <tr key={m.id} className={rowCls}>
                  <td className="px-3 py-2 font-mono text-[#355875]">{m.date}</td>
                  <td className="px-3 py-2 font-bold text-[#082f4f]">{m.type}</td>
                  <td className={numCls + (m.type === 'Issue' ? ' text-rose-700' : ' text-emerald-700')}>{m.type === 'Issue' ? '−' : '+'}{m.quantity} {m.uom}</td>
                  <td className={numCls}>{formatGHS(m.unitCost)}</td>
                  <td className={numCls + ' font-bold'}>{formatGHS(m.quantity * m.unitCost)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
