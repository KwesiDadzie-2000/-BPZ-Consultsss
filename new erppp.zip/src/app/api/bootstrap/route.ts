import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import {
  approvalRequests,
  bankAccounts,
  businessPartners,
  chartAccounts,
  closedPeriods,
  clients,
  companyProfiles,
  disclosureNotes,
  employees,
  journalLines,
  payrollRecords,
  prepaymentRecords,
  prepaymentSchedules,
  purchaseOrders,
  salesInvoices,
  stockItems,
  stockMovements,
  fixedAssets,
  taxScheduleEntries,
  users,
} from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope, sanitizeUser } from "@/lib/auth";
import { eq, inArray } from "drizzle-orm";

export const dynamic = "force-dynamic";

/**
 * Returns the full workspace state for the authenticated user, tenant-scoped:
 * the owner receives every entity's books; other users receive only their own
 * entity's data (plus the firm-level chart of accounts and disclosure notes).
 */
export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    console.error("bootstrap: database unavailable", e);
    return authJson(req, { ok: false, error: "database-unavailable" }, { status: 503 });
  }

  let user;
  try {
    user = await getSessionUser(req);
  } catch (e) {
    // An infrastructure fault is NOT an expired session: answering 401 here is
    // what used to throw a signed-in user back to the login portal.
    console.error("bootstrap: session lookup failed", e);
    return authJson(req, { ok: false, error: "session-check-failed" }, { status: 503 });
  }
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });

  const isOwner = user.role === "owner";
  const firmWide = hasFirmWideScope(user);
  const clientId = user.clientId ?? null;

  const visibleClients = firmWide
    ? await db.select().from(clients)
    : clientId === null
      ? []
      : await db.select().from(clients).where(eq(clients.id, clientId));
  const visibleIds = visibleClients.map((c) => c.id);
  // Non-firm users read only their own entity at the database, not every tenant filtered in memory.
  const scopeIds = visibleIds.length ? visibleIds : [-1];
  // Firm-wide users load journals per entity (?entity=<id>) so a large practice
  // does not ship every client's ledger to the browser at sign-in. `entity=all`
  // (or no parameter, for older clients) returns every visible entity.
  const entityParam = new URL(req.url).searchParams.get("entity");
  const journalScope = firmWide && entityParam && entityParam !== "all" && visibleIds.includes(Number(entityParam)) ? [Number(entityParam)] : null;
  const scoped = <T extends { clientId: number | null }>(rows: T[]) =>
    firmWide ? rows : rows.filter((r) => r.clientId !== null && visibleIds.includes(r.clientId));

  const [
    allLines,
    allBanks,
    allPOs,
    allInvoices,
    allEmployees,
    allPartners,
    allPayroll,
    allApprovals,
    allClosed,
    allPrepayments,
    allPrepaymentSchedules,
    allTaxSchedules,
    allStockItems,
    allStockMovements,
    allFixedAssets,
  ] = await Promise.all([
    journalScope ? db.select().from(journalLines).where(inArray(journalLines.clientId, journalScope)) : firmWide ? db.select().from(journalLines) : db.select().from(journalLines).where(inArray(journalLines.clientId, scopeIds)),
    firmWide ? db.select().from(bankAccounts) : db.select().from(bankAccounts).where(inArray(bankAccounts.clientId, scopeIds)),
    firmWide ? db.select().from(purchaseOrders) : db.select().from(purchaseOrders).where(inArray(purchaseOrders.clientId, scopeIds)),
    firmWide ? db.select().from(salesInvoices) : db.select().from(salesInvoices).where(inArray(salesInvoices.clientId, scopeIds)),
    firmWide ? db.select().from(employees) : db.select().from(employees).where(inArray(employees.clientId, scopeIds)),
    firmWide ? db.select().from(businessPartners) : db.select().from(businessPartners).where(inArray(businessPartners.clientId, scopeIds)),
    firmWide ? db.select().from(payrollRecords) : db.select().from(payrollRecords).where(inArray(payrollRecords.clientId, scopeIds)),
    firmWide ? db.select().from(approvalRequests) : db.select().from(approvalRequests).where(inArray(approvalRequests.clientId, scopeIds)),
    firmWide ? db.select().from(closedPeriods) : db.select().from(closedPeriods).where(inArray(closedPeriods.clientId, scopeIds)),
    firmWide ? db.select().from(prepaymentRecords) : db.select().from(prepaymentRecords).where(inArray(prepaymentRecords.clientId, scopeIds)),
    firmWide ? db.select().from(prepaymentSchedules) : db.select().from(prepaymentSchedules).where(inArray(prepaymentSchedules.clientId, scopeIds)),
    firmWide ? db.select().from(taxScheduleEntries) : db.select().from(taxScheduleEntries).where(inArray(taxScheduleEntries.clientId, scopeIds)),
    firmWide ? db.select().from(stockItems) : db.select().from(stockItems).where(inArray(stockItems.clientId, scopeIds)),
    firmWide ? db.select().from(stockMovements) : db.select().from(stockMovements).where(inArray(stockMovements.clientId, scopeIds)),
    firmWide ? db.select().from(fixedAssets) : db.select().from(fixedAssets).where(inArray(fixedAssets.clientId, scopeIds)),
  ]);

  const profiles = await db.select().from(companyProfiles);
  const allCoa = await db.select().from(chartAccounts);
  // Chart of accounts: firm master (clientId null) plus the user's own entity customs.
  const coa = firmWide ? allCoa : allCoa.filter((a) => a.clientId === null || a.clientId === clientId);
  const notes = await db.select().from(disclosureNotes);
  // User accounts are returned to the owner only (sanitized — no password material).
  const allUsers = isOwner ? (await db.select().from(users)).map(sanitizeUser) : [];

  return authJson(req, {
    ok: true,
    state: {
      clients: visibleClients,
      journalLines: scoped(allLines),
      journalScope: journalScope ? journalScope[0] : "all",
      bankAccounts: scoped(allBanks),
      purchaseOrders: scoped(allPOs),
      salesInvoices: scoped(allInvoices),
      employees: scoped(allEmployees),
      businessPartners: scoped(allPartners).map(({ sourceId, id, ...partner }) => ({ ...partner, id: sourceId ?? id })),
      payrollRecords: scoped(allPayroll).map((r) => r.record),
      approvalRequests: scoped(allApprovals),
      prepaymentRecords: scoped(allPrepayments).map((r) => r.record),
      prepaymentSchedules: scoped(allPrepaymentSchedules).map((r) => r.line),
      taxScheduleEntries: scoped(allTaxSchedules).map((t) => ({ ...t, sourceKey: t.sourceKey ?? undefined, note: t.note ?? undefined })),
      stockItems: scoped(allStockItems),
      stockMovements: scoped(allStockMovements),
      fixedAssets: scoped(allFixedAssets),
      companyProfiles: Object.fromEntries(
        profiles
          .filter((p) => firmWide || p.clientId === clientId)
          .map((p) => [p.clientId, p])
      ),
      chartOfAccounts: coa,
      disclosureNotes: notes,
      closedPeriods: scoped(allClosed).map((c) => ({ clientId: c.clientId, period: c.period })),
      users: allUsers,
    },
  });
}
