import { randomUUID } from "node:crypto";
import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { auditLog, deskRecords } from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * Operations desk API — Human Resources, Client Relationship Management and
 * Store/Inventory.
 *
 * Security & integrity controls:
 *  • every request is authenticated, then client-scope checked server-side
 *    (a user bound to one entity can never read or write another entity);
 *  • desk + record kind are allow-listed, so the endpoint cannot be used to
 *    write arbitrary data;
 *  • payloads are size-limited and must be JSON objects;
 *  • every create/update/delete is written to the immutable audit log.
 */

const DESKS: Record<string, string[]> = {
  hr: ["department", "attendance", "request", "task"],
  crm: ["contact", "opportunity", "activity", "ticket"],
  store: ["product", "quotation", "purchase_order", "supplier"],
  // Production postings use /api/production, not arbitrary JSON records.
  // Legacy rows remain readable by the controlled migration warning there.
};

const MAX_PAYLOAD_BYTES = 512 * 1024;

type DeskBody = {
  desk?: unknown;
  kind?: unknown;
  clientId?: unknown;
  id?: unknown;
  record?: unknown;
};

function json(body: unknown, status = 200) {
  return Response.json(body, { status, headers: { "cache-control": "no-store" } });
}

function parseScope(body: DeskBody) {
  const desk = String(body.desk ?? "");
  const kind = String(body.kind ?? "");
  const clientId = Number(body.clientId);
  if (!DESKS[desk]) return { error: "Unknown desk." } as const;
  if (!DESKS[desk].includes(kind)) return { error: "Unknown record type for this desk." } as const;
  if (!Number.isInteger(clientId) || clientId <= 0) return { error: "A valid client entity is required." } as const;
  return { desk, kind, clientId } as const;
}

async function authorise(req: Request, clientId: number) {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  if (!user) return { response: json({ ok: false, error: "Unauthorized" }, 401) } as const;
  if (user.status === "restricted" || user.status === "suspended") {
    return { response: json({ ok: false, error: "This account is restricted." }, 403) } as const;
  }
  const firmWide = hasFirmWideScope(user);
  if (!firmWide && user.clientId !== clientId) {
    return { response: json({ ok: false, error: "You do not have access to that entity." }, 403) } as const;
  }
  return { user } as const;
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const scope = parseScope({
    desk: url.searchParams.get("desk"),
    kind: url.searchParams.get("kind") ?? "",
    clientId: url.searchParams.get("clientId"),
  });
  if ("error" in scope) return json({ ok: false, error: scope.error }, 400);

  try {
    const auth = await authorise(req, scope.clientId);
    if ("response" in auth) return auth.response;
    const rows = await db
      .select()
      .from(deskRecords)
      .where(and(eq(deskRecords.clientId, scope.clientId), eq(deskRecords.desk, scope.desk), eq(deskRecords.kind, scope.kind)))
      .orderBy(asc(deskRecords.createdAt));
    return json({
      ok: true,
      records: rows.map((r) => ({
        ...(r.payload as Record<string, unknown>),
        id: r.id,
        _createdBy: r.createdBy,
        _updatedBy: r.updatedBy,
        _createdAt: r.createdAt,
        _updatedAt: r.updatedAt,
      })),
    });
  } catch (error) {
    console.error("desk GET failed", error);
    return json({ ok: false, error: "The desk data could not be loaded." }, 503);
  }
}

export async function POST(req: Request) {
  let body: DeskBody;
  try {
    const raw = await req.text();
    if (raw.length > MAX_PAYLOAD_BYTES) return json({ ok: false, error: "The record is too large." }, 413);
    body = JSON.parse(raw) as DeskBody;
  } catch {
    return json({ ok: false, error: "Invalid request body." }, 400);
  }

  const scope = parseScope(body);
  if ("error" in scope) return json({ ok: false, error: scope.error }, 400);
  if (!body.record || typeof body.record !== "object" || Array.isArray(body.record)) {
    return json({ ok: false, error: "A record object is required." }, 400);
  }

  const record = body.record as Record<string, unknown>;
  const id = typeof body.id === "string" && body.id.trim() ? body.id.trim() : randomUUID();
  const clean: Record<string, unknown> = { ...record };
  delete clean.id;
  delete clean._createdBy;
  delete clean._updatedBy;
  delete clean._createdAt;
  delete clean._updatedAt;

  try {
    const auth = await authorise(req, scope.clientId);
    if ("response" in auth) return auth.response;
    // Read-only role: auditors may review the desk but never mutate it.
    if (auth.user.role === "auditor") {
      return json({ ok: false, error: "Auditors have read-only access to this desk." }, 403);
    }
    // HR request decisions are a management control, not a data edit.
    if (scope.desk === "hr" && scope.kind === "request") {
      const nextStatus = String((body.record as Record<string, unknown>).status ?? "");
      const isDecision = nextStatus === "approved" || nextStatus === "rejected";
      const canDecide = ["owner", "partner", "manager"].includes(auth.user.role);
      if (isDecision && !canDecide) {
        return json({ ok: false, error: "Only an owner, partner or manager may approve or reject an HR request." }, 403);
      }
    }
    const now = new Date();
    const existing = await db
      .select({ id: deskRecords.id })
      .from(deskRecords)
      .where(and(eq(deskRecords.id, id), eq(deskRecords.clientId, scope.clientId), eq(deskRecords.desk, scope.desk)))
      .limit(1);
    const isUpdate = existing.length > 0;

    if (isUpdate) {
      await db
        .update(deskRecords)
        .set({ payload: clean, kind: scope.kind, updatedBy: auth.user.username, updatedAt: now })
        .where(and(eq(deskRecords.id, id), eq(deskRecords.clientId, scope.clientId)));
    } else {
      await db.insert(deskRecords).values({
        id,
        clientId: scope.clientId,
        desk: scope.desk,
        kind: scope.kind,
        payload: clean,
        createdBy: auth.user.username,
        updatedBy: auth.user.username,
      });
    }

    await db.insert(auditLog).values({
      id: randomUUID(),
      timestamp: now.toISOString(),
      userId: auth.user.username,
      username: auth.user.username,
      action: isUpdate ? `${scope.desk.toUpperCase()}_UPDATED` : `${scope.desk.toUpperCase()}_CREATED`,
      target: `${scope.kind}:${id}`,
      details: `fields: ${Object.keys(clean).sort().join(", ").slice(0, 300)}`,
      // Never copy personal/contact data into the audit trail: record only the field names.
      clientId: scope.clientId,
    });

    return json({ ok: true, id, updated: isUpdate });
  } catch (error) {
    console.error("desk POST failed", error);
    return json({ ok: false, error: "The record could not be saved." }, 503);
  }
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id") ?? "";
  const scope = parseScope({
    desk: url.searchParams.get("desk"),
    kind: url.searchParams.get("kind") ?? "",
    clientId: url.searchParams.get("clientId"),
  });
  if ("error" in scope) return json({ ok: false, error: scope.error }, 400);
  if (!id) return json({ ok: false, error: "A record id is required." }, 400);

  try {
    const auth = await authorise(req, scope.clientId);
    if ("response" in auth) return auth.response;
    if (auth.user.role === "auditor") {
      return json({ ok: false, error: "Auditors have read-only access to this desk." }, 403);
    }
    const deleted = await db
      .delete(deskRecords)
      .where(
        and(
          eq(deskRecords.id, id),
          eq(deskRecords.clientId, scope.clientId),
          eq(deskRecords.desk, scope.desk),
          eq(deskRecords.kind, scope.kind)
        )
      )
      .returning({ id: deskRecords.id });
    if (!deleted.length) return json({ ok: false, error: "Record not found." }, 404);
    await db.insert(auditLog).values({
      id: randomUUID(),
      timestamp: new Date().toISOString(),
      userId: auth.user.username,
      username: auth.user.username,
      action: `${scope.desk.toUpperCase()}_DELETED`,
      target: `${scope.kind}:${id}`,
      details: "Record removed from operations desk",
      clientId: scope.clientId,
    });
    return json({ ok: true });
  } catch (error) {
    console.error("desk DELETE failed", error);
    return json({ ok: false, error: "The record could not be deleted." }, 503);
  }
}
