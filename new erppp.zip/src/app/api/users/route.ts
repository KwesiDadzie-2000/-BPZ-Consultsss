import { randomUUID } from "node:crypto";
import { BODY_LIMITS, RequestBodyError, readJsonBody } from "@/lib/http";
import { and, eq, ne, sql } from "drizzle-orm";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import { auditLog, clients, sessions, users } from "@/db/schema";
import { authJson, requireOwner, sanitizeUser } from "@/lib/auth";
import { hashPassword, newSalt, passwordPolicyError } from "@/lib/password";
import type { UserAccount } from "@/types/accounting";

export const dynamic = "force-dynamic";

/**
 * User administration (owner only).
 *
 * Review fixes:
 *  - Role, status, username, email, maker limit and entity are validated
 *    (previously any string was written straight to the database).
 *  - Usernames/emails are normalised to lower case: login lower-cases the
 *    identifier, so a mixed-case username could never sign in.
 *  - Duplicate e-mail/username returns 409 instead of an unhandled 500.
 *  - The last active owner cannot be demoted/restricted, and an owner cannot
 *    restrict their own account (prevents total administrative lock-out).
 *  - Password resets and restrictions revoke the target's live sessions.
 *  - Every create/update is written to the audit trail (ISO 27001 A.8.15).
 */
const ROLES = new Set<UserAccount["role"]>(["owner", "partner", "manager", "accountant", "auditor"]);
const STATUSES = new Set(["active", "restricted", "suspended"]);
const USERNAME_RE = /^[a-z0-9._-]{3,40}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/** Owner-only: list all user accounts (sanitized — never any password material). */
export async function GET(req: Request) {
  await ensureDatabaseReady();
  const user = await requireOwner(req);
  if (!user) return authJson(req, { ok: false, error: "Forbidden" }, { status: 403 });
  const rows = await db.select().from(users);
  return Response.json({ ok: true, users: rows.map(sanitizeUser) });
}

/** Owner-only: create or update a user account. Plaintext passwords are hashed server-side. */
export async function PUT(req: Request) {
  await ensureDatabaseReady();
  const actor = await requireOwner(req);
  if (!actor) return authJson(req, { ok: false, error: "Forbidden" }, { status: 403 });

  let body: { user?: UserAccount & { password?: string } };
  try {
    body = await readJsonBody(req, BODY_LIMITS.users);
  } catch (error) {
    if (error instanceof RequestBodyError && error.status === 413) return Response.json({ ok: false, error: error.message }, { status: 413 });
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  const u = body?.user;
  if (!u || !u.username) return Response.json({ ok: false, error: "User is required." }, { status: 400 });

  const username = String(u.username).trim().toLowerCase();
  const email = String(u.email ?? "").trim().toLowerCase();
  const name = String(u.name ?? "").trim();
  const role = u.role;
  const status = u.status ?? "active";
  const makerLimit = Number(u.makerLimit ?? 0);
  const clientId = u.clientId === undefined || u.clientId === null ? null : Number(u.clientId);

  if (!USERNAME_RE.test(username)) return Response.json({ ok: false, error: "Username must be 3–40 characters: letters, digits, dot, dash or underscore." }, { status: 400 });
  if (!EMAIL_RE.test(email)) return Response.json({ ok: false, error: "A valid e-mail address is required." }, { status: 400 });
  if (!name) return Response.json({ ok: false, error: "Full name is required." }, { status: 400 });
  if (!ROLES.has(role)) return Response.json({ ok: false, error: "Unknown role." }, { status: 400 });
  if (!STATUSES.has(status)) return Response.json({ ok: false, error: "Unknown account status." }, { status: 400 });
  if (!Number.isFinite(makerLimit) || makerLimit < 0) return Response.json({ ok: false, error: "Maker limit must be zero or a positive amount." }, { status: 400 });
  if (clientId !== null) {
    if (!Number.isInteger(clientId)) return Response.json({ ok: false, error: "Invalid entity." }, { status: 400 });
    const entity = await db.select({ id: clients.id }).from(clients).where(eq(clients.id, clientId)).limit(1);
    if (!entity[0]) return Response.json({ ok: false, error: "The selected entity does not exist." }, { status: 400 });
  }
  if (u.password) {
    const policyError = passwordPolicyError(u.password);
    if (policyError) return Response.json({ ok: false, error: policyError }, { status: 400 });
  }

  const existing = (await db.select().from(users).where(sql`lower(${users.username}) = ${username}`).limit(1))[0];
  if (!existing && !u.password) {
    return Response.json({ ok: false, error: "A password is required when creating a new user." }, { status: 400 });
  }
  const emailOwner = (await db.select({ id: users.id }).from(users).where(sql`lower(${users.email}) = ${email}`).limit(1))[0];
  if (emailOwner && emailOwner.id !== existing?.id) {
    return Response.json({ ok: false, error: "Another account already uses this e-mail address." }, { status: 409 });
  }

  if (existing) {
    const losesOwnerAuthority = existing.role === "owner" && existing.status === "active" && (role !== "owner" || status !== "active");
    if (losesOwnerAuthority) {
      const others = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(users)
        .where(and(eq(users.role, "owner"), eq(users.status, "active"), ne(users.id, existing.id)));
      if (!Number(others[0]?.n ?? 0)) return Response.json({ ok: false, error: "At least one active owner must remain. Appoint another owner first." }, { status: 409 });
    }
    if (existing.username === actor.username && status !== "active") {
      return Response.json({ ok: false, error: "You cannot restrict or suspend your own account." }, { status: 409 });
    }
  }

  const salt = newSalt();
  const passwordHash = u.password ? await hashPassword(u.password, salt) : null;
  const common = {
    name,
    email,
    role,
    makerLimit,
    canCheck: Boolean(u.canCheck),
    clientId,
    status,
    restrictionReason: status === "active" ? null : String(u.restrictionReason ?? "").slice(0, 300) || null,
    permissions: u.permissions ?? null,
  };

  try {
    if (existing) {
      await db
        .update(users)
        .set({ ...common, ...(passwordHash ? { passwordHash, passwordSalt: salt } : {}) })
        .where(eq(users.id, existing.id));
      // Revoke live sessions when the credential changes or access is withdrawn.
      if ((passwordHash && existing.username !== actor.username) || status !== "active") {
        await db.delete(sessions).where(eq(sessions.userId, existing.id));
      }
    } else {
      await db.insert(users).values({ id: username, username, ...common, passwordHash, passwordSalt: passwordHash ? salt : null });
    }
  } catch (error) {
    const message = String((error as { message?: string })?.message ?? "");
    if (/duplicate key|unique/i.test(message)) return Response.json({ ok: false, error: "Username or e-mail already exists." }, { status: 409 });
    console.error("user save failed", error);
    return Response.json({ ok: false, error: "The user could not be saved." }, { status: 500 });
  }

  const changes: string[] = [];
  if (!existing) changes.push(`created as ${role}`);
  else {
    if (existing.role !== role) changes.push(`role ${existing.role}→${role}`);
    if (existing.status !== status) changes.push(`status ${existing.status}→${status}`);
    if (existing.makerLimit !== makerLimit) changes.push(`maker limit ${existing.makerLimit}→${makerLimit}`);
    if (existing.canCheck !== Boolean(u.canCheck)) changes.push(`checker ${existing.canCheck}→${Boolean(u.canCheck)}`);
    if ((existing.clientId ?? null) !== clientId) changes.push(`entity ${existing.clientId ?? "firm"}→${clientId ?? "firm"}`);
  }
  if (passwordHash) changes.push("password reset");
  try {
    await db.insert(auditLog).values({
      id: randomUUID(),
      timestamp: new Date().toISOString(),
      userId: actor.username,
      username: actor.username,
      action: existing ? "USER_UPDATED" : "USER_CREATED",
      target: username,
      details: changes.join(" · ") || "profile updated",
      clientId,
    });
  } catch (error) {
    console.error("user audit write failed", error);
  }

  const rows = await db.select().from(users).where(eq(users.username, username)).limit(1);
  return Response.json({ ok: true, user: rows[0] ? sanitizeUser(rows[0]) : null });
}
