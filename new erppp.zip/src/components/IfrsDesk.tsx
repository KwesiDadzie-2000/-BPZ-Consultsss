"use client";

import { useState } from "react";
import { ArrowUpRight, BookOpenCheck, FileSpreadsheet, Layers, ShieldCheck } from "lucide-react";
import type { ACDOCALine, AccountMaster, ClientEntity, FixedAsset, MonthlyPayrollRecord, PurchaseOrder, SalesInvoice, StockItem, StockMovement, UserAccount } from "../types/accounting";
import { Badge, PageHeader } from "./ui";
import { ComprehensiveStandardsDesk } from "./ComprehensiveStandardsDesk";
import { IfrsSchedulesDesk } from "./IfrsSchedulesDesk";

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  assets: FixedAsset[];
  stockItems: StockItem[];
  stockMovements: StockMovement[];
  invoices: SalesInvoice[];
  orders: PurchaseOrder[];
  payroll: MonthlyPayrollRecord[];
  fiscalYearStart?: string;
  onAddJournalLines: (lines: ACDOCALine[]) => boolean | void;
  onNavigate: (section: string) => void;
}

const TABS = [
  { id: "standards", label: "Standards & application", icon: BookOpenCheck, hint: "IFRS/IAS requirements, applicability and disclosure logic" },
  { id: "schedules", label: "Schedules & working papers", icon: Layers, hint: "Reconciled schedules behind every note, with one-click adjusting journals" },
];

/**
 * IFRS Desk — the two formerly separate IFRS modules now behave as one module.
 *
 * The Standards desk and the Schedules desk were split, which forced users to
 * guess which desk held the requirement and which held the calculation. They
 * now share one page, one entity context and one navigation entry, while each
 * retains its own focused workspace underneath. Links between them (for
 * example IAS 16 → PPE roll-forward) are handled by switching the tab, not by
 * leaving the module.
 */
export function IfrsDesk(props: Props) {
  const [tab, setTab] = useState("standards");
  const { currentClient, onNavigate } = props;

  return (
    <div>
      <PageHeader
        kicker={`${currentClient.code} · IFRS / IAS Financial Reporting`}
        title="IFRS Desk"
        desc="One IFRS workspace: understand and apply every applicable standard, then prepare the supporting schedule that proves the number. Both desks use the same general ledger, period locks, maker-checker approvals and audit trail."
      >
        <Badge tone="fi">IFRS</Badge>
        <Badge tone="slate">Standards + schedules</Badge>
        <button onClick={() => onNavigate("ifrs_statements")} className="inline-flex items-center gap-1 rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">
          <FileSpreadsheet className="h-3.5 w-3.5" /> Financial statements <ArrowUpRight className="h-3 w-3" />
        </button>
        <button onClick={() => onNavigate("disclosures")} className="inline-flex items-center gap-1 rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">
          <ShieldCheck className="h-3.5 w-3.5" /> Notes to accounts
        </button>
      </PageHeader>

      <div className="mb-4 rounded-xl border border-sky-200 bg-white p-1.5 shadow-sm">
        <div role="tablist" aria-label="IFRS desk sections" className="flex flex-col gap-1.5 sm:flex-row">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                role="tab"
                aria-selected={active}
                onClick={() => setTab(t.id)}
                className={`flex flex-1 items-start gap-2.5 rounded-lg px-3 py-2.5 text-left transition ${active ? "bg-[#082f4f] text-white shadow-sm" : "text-[#163653] hover:bg-sky-100"}`}
              >
                <Icon className={`mt-0.5 h-4 w-4 shrink-0 ${active ? "text-[#f5b719]" : "text-[#355875]"}`} />
                <span>
                  <span className="block text-xs font-bold">{t.label}</span>
                  <span className={`block text-[10.5px] ${active ? "text-sky-100" : "text-[#355875]"}`}>{t.hint}</span>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {tab === "standards" && (
        <ComprehensiveStandardsDesk
          key={currentClient.id}
          currentClient={props.currentClient}
          currentUser={props.currentUser}
          lines={props.lines}
          onAddJournalLines={props.onAddJournalLines}
          onNavigateSection={(section) => {
            if (section === "ifrs_schedules" || section === "ifrs_desk") setTab("schedules");
            else props.onNavigate(section);
          }}
        />
      )}

      {tab === "schedules" && (
        <IfrsSchedulesDesk
          key={currentClient.id}
          currentClient={props.currentClient}
          currentUser={props.currentUser}
          lines={props.lines}
          accounts={props.accounts}
          assets={props.assets}
          stockItems={props.stockItems}
          stockMovements={props.stockMovements}
          invoices={props.invoices}
          orders={props.orders}
          payroll={props.payroll}
          fiscalYearStart={props.fiscalYearStart}
          onAddJournalLines={props.onAddJournalLines}
          onNavigate={props.onNavigate}
        />
      )}
    </div>
  );
}
