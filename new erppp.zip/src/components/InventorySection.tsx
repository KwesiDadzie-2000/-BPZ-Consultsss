import { useMemo, useState } from 'react';
import type { ACDOCALine, ClientEntity, StockItem, StockMovement, UserAccount } from '../types/accounting';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { Boxes, Save } from 'lucide-react';
import { ModulePrintButton } from './ModulePrintButton';
import { docSuffix, uniqueId } from '../utils/ids';
import {
  COGS_ACCOUNT,
  INVENTORY_ACCOUNT,
  INVENTORY_ACCOUNT_NAME,
  inventoryAccountName,
  applyIssue,
  applyLandedCost,
  applyReceipt,
  applyWriteDown,
  buildAdjustmentEntries,
  buildMovement,
  buildWriteDownEntries,
  money,
  nrvWriteDown,
  reconcileInventory,
  tradingResult,
  type CostMethod,
} from '../utils/trading';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  isPeriodClosed: boolean;
  lines: ACDOCALine[];
  items: StockItem[];
  movements: StockMovement[];
  onAddJournalLines: (lines: ACDOCALine[]) => boolean;
  onAddItem: (item: StockItem) => void;
  onApplyStock: (item: StockItem, movement: StockMovement) => void;
  onNavigate?: (section: string) => void;
}

type Action = 'Receipt' | 'Issue' | 'Freight' | 'WriteDown' | 'Adjustment' | 'ReturnOut';

const ACTIONS: { id: Action; label: string; help: string }[] = [
  { id: 'Receipt', label: 'Goods received (purchase)', help: 'Dr Inventory · Cr Trade payables / Bank — recognised when control of the goods passes.' },
  { id: 'Freight', label: 'Inward freight (capitalise)', help: 'Dr Inventory · Cr Bank — directly attributable cost of bringing goods to their present location (IAS 2.11).' },
  { id: 'Issue', label: 'Issue to expense / consumption', help: 'Dr Cost of Sales · Cr Inventory. For manufacturing WIP, issue materials through the Production Desk instead.' },
  { id: 'WriteDown', label: 'Write-down to net realisable value', help: 'Dr Impairment expense · Cr Inventory — lower of cost and NRV (IAS 2.9).' },
  { id: 'Adjustment', label: 'Stock-count adjustment', help: 'Surplus: Dr Inventory · Cr Cost of sales. Loss: Dr Impairment expense · Cr Inventory.' },
  { id: 'ReturnOut', label: 'Return goods to supplier', help: 'Dr Trade payables · Cr Inventory — before payment, supported by a credit note.' },
];

export const InventorySection = ({
  currentClient, currentUser, isPeriodClosed, lines, items, movements, onAddJournalLines, onAddItem, onApplyStock, onNavigate,
}: Props) => {
  const [action, setAction] = useState<Action>('Receipt');
  const [itemCode, setItemCode] = useState<string>(items[0]?.itemCode || '');
  const [qty, setQty] = useState(0);
  const [unitCost, setUnitCost] = useState(0);
  const [amount, setAmount] = useState(0);
  const [nrvPerUnit, setNrvPerUnit] = useState(0);
  const [onCredit, setOnCredit] = useState(true);
  const [vendor, setVendor] = useState('');
  const [note, setNote] = useState('');
  const [date, setDate] = useState(() => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); });
  const [feedback, setFeedback] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);

  // New item form
  const [showNewItem, setShowNewItem] = useState(false);
  const [newCode, setNewCode] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newUom, setNewUom] = useState('Units');
  const [newCategory, setNewCategory] = useState('Merchandise');
  const [newMethod, setNewMethod] = useState<CostMethod>('weighted_average');
  const [newReorder, setNewReorder] = useState(0);

  const isRestricted = currentUser.role === 'auditor' || currentUser.status === 'restricted' || currentUser.status === 'suspended';
  const selected = items.find((i) => i.itemCode === itemCode);
  const reconciliation = useMemo(() => reconcileInventory(items, lines, currentClient.id), [items, lines, currentClient.id]);

  const trading = useMemo(() => {
    const clientLines = lines.filter((l) => l.clientId === currentClient.id);
    const revenue = clientLines.filter((l) => l.accountNo.startsWith('4') && Number(l.accountNo) < 420000)
      .reduce((n, l) => n + Math.round(l.credit * 100) - Math.round(l.debit * 100), 0) / 100;
    const cogs = clientLines.filter((l) => l.accountNo === COGS_ACCOUNT)
      .reduce((n, l) => n + Math.round(l.debit * 100) - Math.round(l.credit * 100), 0) / 100;
    return tradingResult(revenue, cogs);
  }, [lines, currentClient.id]);

  const ctx = (docNo: string) => ({
    docNo, date, currency: currentClient.currency, clientId: currentClient.id, createdBy: currentUser.username, costCenter: 'CC-OPS',
  });

  const guard = (): string | null => {
    if (isPeriodClosed) return 'Posting blocked. The accounting period is closed.';
    if (isRestricted) return 'Action blocked. Your account has been restricted.';
    if (!selected) return 'Select a stock item first.';
    return null;
  };

  const addItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRestricted) { setFeedback({ tone: 'err', text: 'This account cannot modify stock master data.' }); return; }
    if (!newCode.trim() || !newDesc.trim()) { setFeedback({ tone: 'err', text: 'Item code and description are required.' }); return; }
    if (items.some((i) => i.itemCode.toLowerCase() === newCode.trim().toLowerCase())) {
      setFeedback({ tone: 'err', text: `Item ${newCode} already exists in this entity's item master.` });
      return;
    }
    const item: StockItem = {
      id: uniqueId('ITEM'), clientId: currentClient.id, itemCode: newCode.trim().toUpperCase(), description: newDesc.trim(),
      category: newCategory, uom: newUom, quantityOnHand: 0, unitCost: 0, totalValue: 0,
      reorderLevel: newReorder || undefined, location: 'Main store',
      glAccount: newCategory.toLowerCase().includes('finished') ? '121000' : INVENTORY_ACCOUNT, costMethod: newMethod,
    };
    onAddItem(item);
    setItemCode(item.itemCode);
    setShowNewItem(false);
    setNewCode(''); setNewDesc('');
    setFeedback({ tone: 'ok', text: `Item ${item.itemCode} added to the item master (${newMethod === 'fifo' ? 'FIFO' : 'weighted average'}).` });
  };

  const post = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const blocked = guard();
    if (blocked || !selected) { setFeedback({ tone: 'err', text: blocked || 'Select an item.' }); return; }
    const period = date.slice(0, 7);
    const control = selected.glAccount || INVENTORY_ACCOUNT;

    if (action === 'Receipt') {
      if (qty <= 0 || unitCost <= 0) { setFeedback({ tone: 'err', text: 'Receipt quantity and unit cost must both be positive.' }); return; }
      const result = applyReceipt(selected, qty, unitCost);
      if (result.error) { setFeedback({ tone: 'err', text: result.error }); return; }
      const docNo = `GRN-${period}-${docSuffix()}`;
      const value = result.cost;
      const entries: ACDOCALine[] = [
        { id: uniqueId('JL-GRN'), docNo, period, date, module: 'MM', docType: 'PO', accountNo: control, accountName: inventoryAccountName(control), costCenter: 'CC-OPS', debit: value, credit: 0, currency: currentClient.currency, description: `Goods received ${selected.itemCode} × ${qty}`, createdBy: currentUser.username, clientId: currentClient.id },
        { id: uniqueId('JL-GRN'), docNo, period, date, module: 'MM', docType: 'PO', accountNo: onCredit ? '200000' : '100000', accountName: onCredit ? `Trade Payables (${vendor || 'Supplier'})` : 'Cash at Bank (Operating)', costCenter: 'CC-OPS', debit: 0, credit: value, currency: currentClient.currency, description: onCredit ? `Supplier liability for ${selected.itemCode}` : `Cash purchase of ${selected.itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
      ];
      if (!onAddJournalLines(entries)) { setFeedback({ tone: 'err', text: 'Receipt rejected — check the period, the chart of accounts and duplicate documents.' }); return; }
      onApplyStock(result.item, buildMovement({ clientId: currentClient.id, date, item: selected, type: 'Receipt', quantity: qty, unitCost, totalValue: value, docNo, reference: vendor, note }));
      setFeedback({ tone: 'ok', text: `Receipt posted: ${qty} ${selected.uom} at ${formatGHS(unitCost)} → new weighted-average cost ${formatGHS(result.item.unitCost)}.` });
      return;
    }

    if (action === 'Freight') {
      const result = applyLandedCost(selected, amount);
      if (result.error) { setFeedback({ tone: 'err', text: result.error }); return; }
      const docNo = `FRT-${period}-${docSuffix()}`;
      const entries: ACDOCALine[] = [
        { id: uniqueId('JL-FRT'), docNo, period, date, module: 'MM', docType: 'PO', accountNo: control, accountName: inventoryAccountName(control), costCenter: 'CC-OPS', debit: money(amount), credit: 0, currency: currentClient.currency, description: `Inward freight capitalised — ${selected.itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
        { id: uniqueId('JL-FRT'), docNo, period, date, module: 'MM', docType: 'PO', accountNo: onCredit ? '200000' : '100000', accountName: onCredit ? `Trade Payables (${vendor || 'Freight forwarder'})` : 'Cash at Bank (Operating)', costCenter: 'CC-OPS', debit: 0, credit: money(amount), currency: currentClient.currency, description: `Inward freight on ${selected.itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
      ];
      if (!onAddJournalLines(entries)) { setFeedback({ tone: 'err', text: 'Freight capitalisation rejected — check the period and the chart of accounts.' }); return; }
      onApplyStock(result.item, buildMovement({ clientId: currentClient.id, date, item: selected, type: 'Freight', quantity: 0, unitCost: 0, totalValue: money(amount), docNo, reference: vendor, note: note || 'Inward freight capitalised' }));
      setFeedback({ tone: 'ok', text: `Freight ${formatGHS(amount)} capitalised — unit cost is now ${formatGHS(result.item.unitCost)}.` });
      return;
    }

    if (action === 'Issue' || action === 'ReturnOut') {
      const result = applyIssue(selected, qty, movements, (selected.costMethod as CostMethod) || 'weighted_average');
      if (result.error) { setFeedback({ tone: 'err', text: result.error }); return; }
      const docNo = `${action === 'Issue' ? 'ISS' : 'RTS'}-${period}-${docSuffix()}`;
      const entries: ACDOCALine[] = action === 'Issue'
        ? [
            { id: uniqueId('JL-ISS'), docNo, period, date, module: 'INV', docType: 'JE', accountNo: COGS_ACCOUNT, accountName: 'Cost of Goods Sold — Merchandise', costCenter: 'CC-OPS', debit: result.cost, credit: 0, currency: currentClient.currency, description: `Stock issued — ${selected.itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
            { id: uniqueId('JL-ISS'), docNo, period, date, module: 'INV', docType: 'JE', accountNo: control, accountName: inventoryAccountName(control), costCenter: 'CC-OPS', debit: 0, credit: result.cost, currency: currentClient.currency, description: `Stock issued — ${selected.itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
          ]
        : [
            { id: uniqueId('JL-RTS'), docNo, period, date, module: 'MM', docType: 'PO', accountNo: '200000', accountName: `Trade Payables (${vendor || 'Supplier'})`, costCenter: 'CC-OPS', debit: result.cost, credit: 0, currency: currentClient.currency, description: `Goods returned to supplier — ${selected.itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
            { id: uniqueId('JL-RTS'), docNo, period, date, module: 'MM', docType: 'PO', accountNo: control, accountName: inventoryAccountName(control), costCenter: 'CC-OPS', debit: 0, credit: result.cost, currency: currentClient.currency, description: `Goods returned to supplier — ${selected.itemCode}`, createdBy: currentUser.username, clientId: currentClient.id },
          ];
      if (!onAddJournalLines(entries)) { setFeedback({ tone: 'err', text: 'Movement rejected — check the period and the chart of accounts.' }); return; }
      onApplyStock(result.item, buildMovement({ clientId: currentClient.id, date, item: selected, type: action === 'Issue' ? 'Issue' : 'ReturnOut', quantity: qty, unitCost: result.unitCost, totalValue: result.cost, docNo, reference: vendor, note }));
      setFeedback({ tone: 'ok', text: `${action === 'Issue' ? 'Issue' : 'Return to supplier'} posted at carrying cost ${formatGHS(result.cost)}.` });
      return;
    }

    if (action === 'WriteDown') {
      const required = nrvPerUnit > 0 ? nrvWriteDown(selected, nrvPerUnit) : money(amount);
      if (required <= 0) { setFeedback({ tone: 'err', text: 'No write-down required — cost is already at or below net realisable value.' }); return; }
      const result = applyWriteDown(selected, required);
      if (result.error) { setFeedback({ tone: 'err', text: result.error }); return; }
      const docNo = `NRV-${period}-${docSuffix()}`;
      const entries = buildWriteDownEntries(ctx(docNo), required, selected.itemCode, note || 'lower of cost and net realisable value');
      if (!onAddJournalLines(entries)) { setFeedback({ tone: 'err', text: 'Write-down rejected — check the period and the chart of accounts.' }); return; }
      onApplyStock(
        { ...result.item, netRealisableValue: nrvPerUnit > 0 ? nrvPerUnit : result.item.unitCost },
        buildMovement({ clientId: currentClient.id, date, item: selected, type: 'WriteDown', quantity: 0, unitCost: 0, totalValue: required, docNo, note: note || 'NRV write-down' }),
      );
      setFeedback({ tone: 'ok', text: `Write-down of ${formatGHS(required)} posted — carrying value is now ${formatGHS(result.item.totalValue)}.` });
      return;
    }

    // Stock-count adjustment: qty is the COUNTED quantity.
    const counted = qty;
    const diffQty = Math.round((counted - selected.quantityOnHand) * 1000) / 1000;
    if (diffQty === 0) { setFeedback({ tone: 'err', text: 'Counted quantity equals the book quantity — no adjustment required.' }); return; }
    const rate = selected.unitCost;
    const value = money(diffQty * rate);
    const docNo = `CNT-${period}-${docSuffix()}`;
    const entries = buildAdjustmentEntries(ctx(docNo), value, selected.itemCode, note || 'physical stock count');
    if (!onAddJournalLines(entries)) { setFeedback({ tone: 'err', text: 'Adjustment rejected — check the period and the chart of accounts.' }); return; }
    const nextQty = counted;
    const nextValue = money(selected.totalValue + value);
    onApplyStock(
      { ...selected, quantityOnHand: nextQty, totalValue: nextValue, unitCost: nextQty > 0 ? money(nextValue / nextQty) : selected.unitCost },
      buildMovement({ clientId: currentClient.id, date, item: selected, type: 'Adjustment', quantity: diffQty, unitCost: rate, totalValue: value, docNo, note: note || 'physical stock count' }),
    );
    setFeedback({ tone: 'ok', text: `Count adjustment posted: ${diffQty > 0 ? 'surplus' : 'loss'} of ${Math.abs(diffQty)} ${selected.uom} (${formatGHS(Math.abs(value))}).` });
  };

  const clientMovements = movements.filter((m) => m.clientId === currentClient.id).slice().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 40);

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`INV · Perpetual inventory · ${currentClient.code}`}
        title="Stock, Costing & Cost of Sales (IAS 2)"
        desc="Receipts, sales issues and adjustments update physical stock. The valuation checks raw materials, finished goods, spares and biological stock against their GL controls; WIP is reconciled separately by work order."
      >
        {onNavigate && <button type="button" onClick={() => onNavigate('production_desk')} className="rounded border border-sky-300 bg-white px-2.5 py-1.5 text-xs font-bold text-[#082f4f]">Issue to production / WIP →</button>}
        <ModulePrintButton title={`Inventory & stock register — ${currentClient.name}`} subtitle={`Valuation and movements through ${new Date().toISOString().slice(0, 10)}`} />
        <button onClick={() => setShowNewItem(true)} disabled={isRestricted} className="flex gap-1.5 items-center rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white disabled:opacity-40"><Boxes className="h-4 w-4" /> New item</button>
      </PageHeader>

      {feedback && (
        <div className={`text-xs rounded-lg p-3 border ${feedback.tone === 'ok' ? 'bg-emerald-50 text-emerald-900 border-emerald-300' : 'bg-rose-50 text-rose-900 border-rose-300'}`}>{feedback.text}</div>
      )}

      <div className="grid gap-4 md:grid-cols-3">
        <Card title="Inventory valuation" sub="Item master total">
          <div className="text-2xl font-black text-[#082f4f]">{formatGHS(reconciliation.valuation)}</div>
          <div className="mt-1 text-[11px] text-[#355875]">Physical stock GL (120000, 121000, 123000): {formatGHS(reconciliation.ledger)}</div>
          <div className={`mt-2 rounded px-2 py-1 text-[11px] font-bold ${reconciliation.reconciled ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'}`}>
            {reconciliation.reconciled ? 'Reconciled to the general ledger' : `Difference ${formatGHS(reconciliation.difference)} — investigate before reporting`}
          </div>
        </Card>
        <Card title="Trading result" sub="Posted revenue against posted cost of sales">
          <div className="space-y-1 font-mono text-xs">
            <div>Revenue: {formatGHS(trading.revenue)}</div>
            <div>Cost of sales: {formatGHS(trading.costOfSales)}</div>
            <div className="border-t pt-1 font-bold">Gross profit: {formatGHS(trading.grossProfit)}</div>
            <div>Gross margin: {trading.grossMarginPct}% · Mark-up on cost: {trading.markupOnCostPct}%</div>
          </div>
        </Card>
        <Card title="Stock health" sub="Items below reorder level or carried above NRV">
          <ul className="space-y-1 text-[11px] text-[#355875]">
            {items.filter((i) => i.reorderLevel && i.quantityOnHand <= i.reorderLevel).map((i) => (
              <li key={`re-${i.id}`} className="text-amber-800">Reorder: {i.itemCode} — {i.quantityOnHand} {i.uom} on hand (level {i.reorderLevel})</li>
            ))}
            {items.filter((i) => i.netRealisableValue != null && i.netRealisableValue < i.unitCost).map((i) => (
              <li key={`nrv-${i.id}`} className="text-rose-800">NRV below cost: {i.itemCode} — write-down required</li>
            ))}
            {!items.some((i) => (i.reorderLevel && i.quantityOnHand <= i.reorderLevel) || (i.netRealisableValue != null && i.netRealisableValue < i.unitCost)) && <li>No exceptions.</li>}
          </ul>
        </Card>
      </div>

      <Card title="Item master" sub="Perpetual quantity, cost formula and carrying value for every stocked item.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-xs">
            <thead><tr className="border-b border-sky-200 bg-sky-50/70">
              <th className={thCls}>Item</th><th className={thCls}>Description</th><th className={thCls}>Category</th>
              <th className={thCls}>Cost formula</th><th className={thCls + ' text-right'}>On hand</th>
              <th className={thCls + ' text-right'}>Unit cost</th><th className={thCls + ' text-right'}>Carrying value</th>
              <th className={thCls + ' text-right'}>NRV/unit</th>
            </tr></thead>
            <tbody>
              {items.map((i) => (
                <tr key={i.id} className={rowCls}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{i.itemCode}</td>
                  <td className="px-3 py-2">{i.description}</td>
                  <td className="px-3 py-2">{i.category}</td>
                  <td className="px-3 py-2">{i.costMethod === 'fifo' ? 'FIFO' : i.costMethod === 'specific' ? 'Specific identification' : 'Weighted average'}</td>
                  <td className={numCls}>{i.quantityOnHand} {i.uom}</td>
                  <td className={numCls}>{formatGHS(i.unitCost)}</td>
                  <td className={numCls + ' font-bold'}>{formatGHS(i.totalValue)}</td>
                  <td className={numCls}>{i.netRealisableValue != null ? formatGHS(i.netRealisableValue) : '—'}</td>
                </tr>
              ))}
              {!items.length && <tr><td colSpan={8} className="px-3 py-6 text-center text-[#355875]">No stock items yet — add one to start the perpetual records.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>

      <Card title="Record a stock movement" sub="Every movement posts its own balanced journal and updates the perpetual records in the same action.">
        <form onSubmit={post} className="grid gap-3 md:grid-cols-3 text-xs">
          <label className="block font-bold text-[#355875] md:col-span-2">Movement
            <select value={action} onChange={(e) => setAction(e.target.value as Action)} className="mt-1 block w-full rounded border border-sky-300 p-2">
              {ACTIONS.map((a) => <option key={a.id} value={a.id}>{a.label}</option>)}
            </select>
          </label>
          <label className="block font-bold text-[#355875]">Date
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
          </label>
          <label className="block font-bold text-[#355875]">Item
            <select value={itemCode} onChange={(e) => setItemCode(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2">
              <option value="">Select item</option>
              {items.map((i) => <option key={i.id} value={i.itemCode}>{i.itemCode} · {i.description}</option>)}
            </select>
          </label>
          {(action === 'Receipt' || action === 'Issue' || action === 'ReturnOut' || action === 'Adjustment') && (
            <label className="block font-bold text-[#355875]">{action === 'Adjustment' ? 'Counted quantity' : 'Quantity'}
              <input type="number" min="0" step="0.001" value={qty || ''} onChange={(e) => setQty(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
            </label>
          )}
          {action === 'Receipt' && (
            <label className="block font-bold text-[#355875]">Unit cost ({currentClient.currency})
              <input type="number" min="0" step="0.01" value={unitCost || ''} onChange={(e) => setUnitCost(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
            </label>
          )}
          {(action === 'Freight' || action === 'WriteDown') && (
            <label className="block font-bold text-[#355875]">Amount ({currentClient.currency})
              <input type="number" min="0" step="0.01" value={amount || ''} onChange={(e) => setAmount(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
            </label>
          )}
          {action === 'WriteDown' && (
            <label className="block font-bold text-[#355875]">Net realisable value per unit (optional)
              <input type="number" min="0" step="0.01" value={nrvPerUnit || ''} onChange={(e) => setNrvPerUnit(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" />
            </label>
          )}
          {(action === 'Receipt' || action === 'Freight' || action === 'ReturnOut') && (
            <>
              <label className="block font-bold text-[#355875]">Supplier / counterparty
                <input value={vendor} onChange={(e) => setVendor(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" />
              </label>
              {action !== 'ReturnOut' && (
                <label className="block font-bold text-[#355875]">Settlement
                  <select value={onCredit ? 'credit' : 'cash'} onChange={(e) => setOnCredit(e.target.value === 'credit')} className="mt-1 block w-full rounded border border-sky-300 p-2">
                    <option value="credit">On credit (Cr Trade payables)</option>
                    <option value="cash">Paid now (Cr Bank)</option>
                  </select>
                </label>
              )}
            </>
          )}
          <label className="block font-bold text-[#355875] md:col-span-2">Note / reason
            <input value={note} onChange={(e) => setNote(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" placeholder="Supporting reference, approval or reason" />
          </label>
          <div className="md:col-span-3 rounded bg-sky-50 border border-sky-200 p-3 text-[11px] text-[#2d4f6d]">
            {ACTIONS.find((a) => a.id === action)?.help}
            {selected && <div className="mt-1 font-mono">On hand: {selected.quantityOnHand} {selected.uom} · unit cost {formatGHS(selected.unitCost)} · value {formatGHS(selected.totalValue)}</div>}
          </div>
          <div className="md:col-span-3 flex justify-end">
            <button type="submit" className="flex items-center gap-1.5 rounded bg-[#082f4f] px-4 py-2 text-xs font-bold text-white"><Save className="h-4 w-4" /> Post movement</button>
          </div>
        </form>
      </Card>

      <Card title="Movement history" sub="Receipts, issues, freight, returns, write-downs and count adjustments with their posted document.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-xs">
            <thead><tr className="border-b border-sky-200 bg-sky-50/70">
              <th className={thCls}>Date</th><th className={thCls}>Document</th><th className={thCls}>Item</th>
              <th className={thCls}>Type</th><th className={thCls + ' text-right'}>Qty</th>
              <th className={thCls + ' text-right'}>Unit cost</th><th className={thCls + ' text-right'}>Value</th><th className={thCls}>Note</th>
            </tr></thead>
            <tbody>
              {clientMovements.map((m) => (
                <tr key={m.id} className={rowCls}>
                  <td className="px-3 py-2 font-mono">{m.date}</td>
                  <td className="px-3 py-2 font-mono text-[#855b00]">{m.docNo || '—'}</td>
                  <td className="px-3 py-2 font-mono">{m.itemCode}</td>
                  <td className="px-3 py-2">{m.type}</td>
                  <td className={numCls}>{m.quantity}</td>
                  <td className={numCls}>{formatGHS(m.unitCost)}</td>
                  <td className={numCls}>{formatGHS(m.totalValue)}</td>
                  <td className="px-3 py-2 text-[11px] text-[#355875]">{m.note || m.reference || '—'}</td>
                </tr>
              ))}
              {!clientMovements.length && <tr><td colSpan={8} className="px-3 py-6 text-center text-[#355875]">No stock movements recorded yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>

      {showNewItem && (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/50 p-4">
          <form onSubmit={addItem} className="my-8 w-full max-w-lg space-y-3 rounded-xl bg-white p-6 text-xs shadow-xl">
            <h3 className="border-b border-sky-100 pb-2 text-base font-bold text-[#082f4f]">New stock item</h3>
            <label className="block font-bold text-[#355875]">Item code<input value={newCode} onChange={(e) => setNewCode(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" /></label>
            <label className="block font-bold text-[#355875]">Description<input value={newDesc} onChange={(e) => setNewDesc(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" /></label>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block font-bold text-[#355875]">Category (sets the stock GL)
                <select value={newCategory} onChange={(e) => setNewCategory(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2">
                  <option value="Merchandise">Merchandise / trading stock → 120000</option>
                  <option value="Raw Materials">Raw materials / inputs → 120000</option>
                  <option value="Finished Goods">Finished goods / production output → 121000</option>
                  <option value="Consumables">Spares & consumables → 120000</option>
                </select>
              </label>
              <label className="block font-bold text-[#355875]">Unit of measure<input value={newUom} onChange={(e) => setNewUom(e.target.value)} className="mt-1 block w-full rounded border border-sky-300 p-2" /></label>
              <label className="block font-bold text-[#355875]">Cost formula
                <select value={newMethod} onChange={(e) => setNewMethod(e.target.value as CostMethod)} className="mt-1 block w-full rounded border border-sky-300 p-2">
                  <option value="weighted_average">Weighted average</option>
                  <option value="fifo">First-in, first-out (FIFO)</option>
                  <option value="specific">Specific identification</option>
                </select>
              </label>
              <label className="block font-bold text-[#355875]">Reorder level<input type="number" min="0" step="0.001" value={newReorder || ''} onChange={(e) => setNewReorder(Number(e.target.value))} className="mt-1 block w-full rounded border border-sky-300 p-2 font-mono" /></label>
            </div>
            <p className="rounded bg-sky-50 border border-sky-200 p-2 text-[10.5px] text-[#2d4f6d]">The cost formula is fixed per item and applied consistently (IAS 2.25); changing it later would rewrite historical profit.</p>
            <div className="flex justify-end gap-2 border-t border-sky-100 pt-3">
              <button type="button" onClick={() => setShowNewItem(false)} className="px-3 py-2">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-2 font-bold text-white">Add item</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
