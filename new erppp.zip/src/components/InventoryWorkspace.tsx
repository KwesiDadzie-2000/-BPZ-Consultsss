"use client";

import { useState } from "react";
import { Boxes, ClipboardList } from "lucide-react";
import type { ACDOCALine, BusinessPartner, ClientEntity, PurchaseOrder, SalesInvoice, StockItem, StockMovement, UserAccount } from "../types/accounting";
import { InventorySection } from "./InventorySection";
import { StoreOperationsDesk } from "./StoreOperationsDesk";

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  isPeriodClosed: boolean;
  lines: ACDOCALine[];
  items: StockItem[];
  movements: StockMovement[];
  partners: BusinessPartner[];
  orders: PurchaseOrder[];
  invoices: SalesInvoice[];
  onAddJournalLines: (lines: ACDOCALine[]) => boolean;
  onAddItem: (item: StockItem) => void;
  onApplyStock: (item: StockItem, movement: StockMovement) => void;
  onNavigate: (section: string) => void;
}

/**
 * Inventory workspace — the original stock ledger (receipts, issues, freight,
 * write-downs, valuation and reconciliation) is preserved exactly as designed
 * and now sits alongside the store-operations desk (products and barcodes,
 * quotations, purchase orders, reorder alerts and suppliers) under one module.
 */
export function InventoryWorkspace(props: Props & { initialTab?: "operations" | "ledger" }) {
  const [tab, setTab] = useState<"operations" | "ledger">(props.initialTab ?? "operations");

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-sky-200 bg-white p-1.5 shadow-sm">
        <div className="flex gap-1.5">
          <button
            onClick={() => setTab("operations")}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-bold transition ${tab === "operations" ? "bg-[#082f4f] text-white" : "text-[#163653] hover:bg-sky-100"}`}
          >
            <Boxes className={`h-4 w-4 ${tab === "operations" ? "text-[#f5b719]" : "text-[#855b00]"}`} /> Store operations
          </button>
          <button
            onClick={() => setTab("ledger")}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-bold transition ${tab === "ledger" ? "bg-[#082f4f] text-white" : "text-[#163653] hover:bg-sky-100"}`}
          >
            <ClipboardList className={`h-4 w-4 ${tab === "ledger" ? "text-[#f5b719]" : "text-[#855b00]"}`} /> Stock ledger &amp; valuation
          </button>
        </div>
        <span className="px-2 text-[10.5px] font-semibold text-[#355875]">One inventory module · two connected workspaces</span>
      </div>

      {tab === "operations" && (
        <StoreOperationsDesk
          currentClient={props.currentClient}
          currentUser={props.currentUser}
          stockItems={props.items}
          movements={props.movements}
          partners={props.partners}
          orders={props.orders}
          invoices={props.invoices}
          onAddItem={props.onAddItem}
          onNavigate={(section) => {
            if (section === "inventory") setTab("ledger");
            else props.onNavigate(section);
          }}
        />
      )}

      {tab === "ledger" && (
        <InventorySection
          key={props.currentClient.id}
          currentClient={props.currentClient}
          currentUser={props.currentUser}
          isPeriodClosed={props.isPeriodClosed}
          lines={props.lines}
          items={props.items}
          movements={props.movements}
          onAddJournalLines={props.onAddJournalLines}
          onAddItem={props.onAddItem}
          onApplyStock={props.onApplyStock}
          onNavigate={props.onNavigate}
        />
      )}
    </div>
  );
}
