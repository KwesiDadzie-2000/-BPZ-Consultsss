"use client";

import { useMemo, useState } from "react";
import { ArrowRight, CalendarClock, CheckCircle2, Compass, GitBranch, Layers, Settings2, ShieldCheck } from "lucide-react";
import type { ClientEntity, UserAccount } from "../types/accounting";
import { GHANA_ECONOMY_SECTORS } from "../data/ghanaSectors";
import { profileForClientSector, type SectorProfile } from "../data/sectorProfiles";
import { Badge, Card, PageHeader, numCls, rowCls, tdCls, thCls } from "./ui";
import { Field, inputCls } from "./DeskKit";

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  /** Owner can re-classify the entity's sector; the workspace switches to that profile. */
  onChangeSector?: (sectorName: string) => void;
  onNavigate?: (section: string) => void;
}

/**
 * Sector Workflow Switcher.
 *
 * When a client workspace is opened, the system derives the sector profile
 * from the entity's sector and switches the workspace to that industry's
 * accounting workflow: the flow, the modules to use, the dimensions to
 * configure, the key GL accounts, the sector compliance calendar and the
 * close controls. The owner can re-classify the sector here, which re-arms
 * the profile everywhere (sidebar, dashboard, this desk).
 */
export function SectorWorkflowDesk({ currentClient, currentUser, onChangeSector, onNavigate }: Props) {
  const [sectorCode, setSectorCode] = useState<string>(() => {
    // match current client sector to a registered code
    const p = profileForClientSector(currentClient.sector);
    return p.sectorCode;
  });
  const profile: SectorProfile = useMemo(() => {
    const byCode = GHANA_ECONOMY_SECTORS.find((s) => s.code === sectorCode);
    return byCode ? profileForClientSector(byCode.name) : profileForClientSector(currentClient.sector);
  }, [sectorCode, currentClient.sector]);

  const isOwner = currentUser.role === "owner";

  return (
    <div>
      <PageHeader
        kicker={`${currentClient.code} · Sector workspace switcher`}
        title="Sector Workflow Profile"
        desc="Opening this workspace automatically switches the system to this entity's industry accounting workflow — modules, dimensions, key accounts, tax calendar and close controls. Re-classify below to switch profiles."
      >
        <Badge tone="fi">{profile.category}</Badge>
        <Badge tone="slate">{profile.manualRef}</Badge>
      </PageHeader>

      <div className="mb-4 grid gap-4 lg:grid-cols-[320px_1fr]">
        <Card title="Switch sector profile" sub={isOwner ? "Owner: re-classify this entity — the whole workspace re-arms to the new profile." : "Only the Firm Owner can re-classify the entity sector."}>
          <div className="space-y-2">
            <Field label="Entity sector">
              <select
                className={inputCls}
                value={sectorCode}
                disabled={!isOwner || !onChangeSector}
                onChange={(e) => {
                  setSectorCode(e.target.value);
                  const def = GHANA_ECONOMY_SECTORS.find((s) => s.code === e.target.value);
                  if (def && onChangeSector) onChangeSector(def.name);
                }}
              >
                {GHANA_ECONOMY_SECTORS.map((s) => (
                  <option key={s.code} value={s.code}>{s.name}</option>
                ))}
              </select>
            </Field>
            <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-2.5 text-[11px] text-[#2d4f6d]">
              <span className="font-bold text-[#082f4f]">Current profile:</span> {profile.sectorName}
              <div className="mt-1">{profile.tagline}</div>
            </div>
            {!isOwner && <p className="text-[10.5px] text-[#355875]">Ask the Firm Owner to change the entity&apos;s sector classification.</p>}
          </div>
        </Card>

        <Card title="Operational flow — event → posting → report" sub={profile.manualRef}>
          <ol className="space-y-1.5">
            {profile.flow.map((step, i) => (
              <li key={i} className="flex items-start gap-2 rounded-lg border border-sky-100 bg-white px-2.5 py-2">
                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#082f4f] font-mono text-[10px] font-bold text-white">{i + 1}</span>
                <span className="text-[11.5px] font-semibold text-[#0a253e]">{step}</span>
              </li>
            ))}
          </ol>
        </Card>
      </div>

      <div className="mb-4 grid gap-4 lg:grid-cols-3">
        <Card title="Modules this workspace emphasises" sub="Deep links into the sector workflow">
          <ul className="space-y-1.5">
            {profile.modules.map((m) => (
              <li key={m.id}>
                <button
                  onClick={() => onNavigate?.(m.id)}
                  className="flex w-full items-center justify-between gap-2 rounded-lg border border-sky-200 bg-white px-2.5 py-2 text-left hover:bg-sky-50"
                >
                  <span>
                    <span className="block text-[11.5px] font-bold text-[#082f4f]">{m.label}</span>
                    <span className="block text-[10.5px] text-[#355875]">{m.reason}</span>
                  </span>
                  <ArrowRight className="h-3.5 w-3.5 shrink-0 text-[#355875]" />
                </button>
              </li>
            ))}
          </ul>
        </Card>

        <Card title="Dimensions to configure" sub="Add these as cost centres / tags in master data">
          <div className="flex flex-wrap gap-1.5">
            {profile.dimensions.map((d) => <Badge key={d} tone="slate">{d}</Badge>)}
          </div>
        </Card>

        <Card title="Key GL accounts for this sector" sub="Confirm these accounts exist and are mapped in the chart of accounts">
          <div className="space-y-1.5">
            {profile.keyAccounts.map((a) => (
              <div key={a.accountNo} className="rounded-lg border border-sky-100 bg-white px-2.5 py-1.5">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[11px] font-bold text-[#855b00]">{a.accountNo}</span>
                  <span className="text-[11px] font-bold text-[#082f4f]">{a.name}</span>
                </div>
                <div className="text-[10.5px] text-[#355875]">{a.why}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="mb-4 grid gap-4 lg:grid-cols-2">
        <Card title="Recognition & accounting notes" sub="Apply before posting sector transactions">
          <ul className="list-disc space-y-1.5 pl-4 text-[11.5px] leading-relaxed text-[#2d4f6d]">
            {profile.accountingNotes.map((n, i) => <li key={i}>{n}</li>)}
          </ul>
        </Card>
        <Card title="Close & control checks" sub="Run at month-end for this sector">
          <ul className="space-y-1.5">
            {profile.closeControls.map((c, i) => (
              <li key={i} className="flex items-start gap-2 text-[11.5px] text-[#0a253e]">
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#087a55]" />
                <span>{c}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <Card
        title="Compliance calendar — this sector"
        sub="Standard Ghana obligations plus sector-specific filings. Verify actual due dates, extensions and portal acknowledgements with a Ghana-qualified accountant."
        action={onNavigate && <button onClick={() => onNavigate("tax_schedule")} className="rounded-lg border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">Open Tax & Statutory Returns →</button>}
      >
        <div className="overflow-x-auto rounded-lg border border-sky-200">
          <table className="w-full min-w-[720px] border-collapse">
            <thead>
              <tr>
                <th className={thCls}>Obligation</th>
                <th className={thCls}>Due</th>
                <th className={thCls}>Authority</th>
                <th className={thCls}></th>
              </tr>
            </thead>
            <tbody>
              {profile.compliance.map((c, i) => (
                <tr key={i} className={rowCls}>
                  <td className={tdCls}><span className="font-bold text-[#082f4f]">{c.obligation}</span></td>
                  <td className={tdCls}><span className="inline-flex items-center gap-1"><CalendarClock className="h-3 w-3 text-[#855b00]" />{c.due}</span></td>
                  <td className={tdCls}><Badge tone="gold">{c.authority}</Badge></td>
                  <td className={tdCls}>{c.section && onNavigate && <button onClick={() => onNavigate(c.section!)} className="text-[10.5px] font-bold text-[#006f98] hover:underline">Open →</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
