import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { X, FileText, ChevronRight, Printer, Paperclip } from 'lucide-react';
import { AttachmentsPanel } from '../AttachmentsPanel';
import { ModulePrintButton } from '../ModulePrintButton';
import { documentTitle, printPaymentDocument, printTradeDocument } from '../../utils/documentPrint';
import type { AccountMaster, StockItem, UserAccount } from '../../types/accounting';
import { Card, StatusBadge, thCls, numCls, rowCls } from '../ui';
import {
  DOC_TYPE_LABEL, ITEM_TYPE_LABEL, fetchRecordAudit, fmtMoney, fmtQty, money, fulfilledQuantity,
  type TradeAuditEvent, type TradeDesk, type TradeDocument, type TradeItemType, type TradeNotice, type TradePayment,
} from '../../lib/tradeClient';

/* ------------------------------------------------------------------ *
 * Style tokens shared by the P2P and O2C desks
 * ------------------------------------------------------------------ */
export const inputCls = 'w-full rounded border border-sky-300 bg-white px-2 py-1.5 text-xs text-[#0a253e] outline-none focus:border-[#082f4f] disabled:bg-slate-100';
export const labelCls = 'block text-[10.5px] font-bold uppercase tracking-wider text-[#355875] mb-0.5';
export const btnPrimary = 'rounded bg-[#082f4f] px-3 py-1.5 text-[11px] font-bold text-white hover:bg-[#0c3f68] disabled:opacity-50 disabled:cursor-not-allowed';
export const btnSecondary = 'rounded border border-sky-300 bg-white px-3 py-1.5 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50 disabled:opacity-50 disabled:cursor-not-allowed';
export const btnAmber = 'rounded border border-amber-400 bg-amber-50 px-2.5 py-1 text-[11px] font-bold text-[#855b00] hover:bg-amber-100 disabled:opacity-50 disabled:cursor-not-allowed';
export const btnGreen = 'rounded bg-emerald-700 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed';

export const POSTING_TYPES = new Set(['goods_receipt', 'supplier_invoice', 'supplier_credit_note', 'supplier_debit_note', 'sales_delivery', 'sales_invoice', 'customer_credit_note', 'customer_debit_note']);

export const symbolFor = (ccy: string) => (ccy === 'USD' ? '$' : ccy === 'GBP' ? '£' : ccy === 'EUR' ? '€' : ccy === 'GHS' ? '₵' : `${ccy} `);


/**
 * The print control that sits under each desk module. It prints the module the
 * operator is looking at (letterhead + that register only), never the whole
 * workspace with its buttons and navigation.
 */
export function ModulePrintFooter({ targetId, title, subtitle }: { targetId: string; title: string; subtitle?: string }) {
  return (
    <div data-print-hide className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-sky-200 bg-white px-3 py-2">
      <p className="text-[10.5px] text-[#355875]">
        Print this module on its own — document header, period and the register above, with the controls removed.
      </p>
      <ModulePrintButton targetId={targetId} title={title} subtitle={subtitle} label="Print this module" />
    </div>
  );
}

export function Field({ label, children, className, hint }: { label: string; children: ReactNode; className?: string; hint?: string }) {
  return (
    <div className={className}>
      <label className={labelCls}>{label}</label>
      {children}
      {hint && <p className="mt-0.5 text-[10px] text-[#355875]">{hint}</p>}
    </div>
  );
}

export function Modal({ title, sub, onClose, children, wide }: { title: string; sub?: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/50 p-3 sm:p-6" role="dialog" aria-modal="true" aria-label={title}>
      <div className={`my-4 w-full ${wide ? 'max-w-5xl' : 'max-w-3xl'} rounded-xl border border-sky-300 bg-white shadow-2xl`}>
        <div className="flex items-start justify-between gap-3 border-b border-sky-100 px-5 py-3">
          <div>
            <h3 className="text-sm font-black text-[#082f4f]">{title}</h3>
            {sub && <p className="text-[11px] text-[#355875]">{sub}</p>}
          </div>
          <button type="button" onClick={onClose} aria-label="Close" className="rounded p-1 text-[#355875] hover:bg-sky-50"><X className="h-4 w-4" /></button>
        </div>
        <div className="px-5 py-4 text-xs">{children}</div>
      </div>
    </div>
  );
}

export function DeskNotice({ notice, onDismiss }: { notice: TradeNotice | null; onDismiss: () => void }) {
  if (!notice) return null;
  const tone = notice.tone === 'error' ? 'border-rose-300 bg-rose-50 text-rose-900' : notice.tone === 'ok' ? 'border-emerald-300 bg-emerald-50 text-emerald-900' : 'border-sky-300 bg-sky-50 text-[#082f4f]';
  return (
    <div role={notice.tone === 'error' ? 'alert' : 'status'} className={`flex items-start justify-between gap-3 rounded-lg border px-3 py-2 text-xs font-bold ${tone}`}>
      <span>{notice.text}</span>
      <button type="button" onClick={onDismiss} className="shrink-0 text-[11px] underline">Dismiss</button>
    </div>
  );
}

/** Visual lifecycle pipeline with live counts per stage. */
export function Pipeline({ steps }: { steps: Array<{ label: string; count: number; hint: string; tone?: 'mm' | 'sd' }> }) {
  return (
    <div className="flex flex-wrap items-stretch gap-1.5">
      {steps.map((s, i) => (
        <div key={s.label} className="flex items-center gap-1.5">
          <div className="min-w-[128px] rounded-lg border border-sky-200 bg-white px-3 py-2">
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#355875]">{s.label}</div>
            <div className="font-mono text-base font-black text-[#082f4f]">{s.count}</div>
            <div className="text-[10px] text-[#2d4f6d]">{s.hint}</div>
          </div>
          {i < steps.length - 1 && <ChevronRight className="h-4 w-4 text-sky-400" />}
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Draft line editor for orders, requisitions and direct invoices
 * ------------------------------------------------------------------ */
export interface DraftLine {
  key: string;
  itemType: TradeItemType;
  itemCode: string;
  description: string;
  uom: string;
  quantity: number;
  unitPrice: number;
  discountAmount: number;
  taxRate: number;
  accountNo: string;
  revenueAccount: string;
  costCenter: string;
}

let lineSeq = 0;
export const newDraftLine = (defaults: Partial<DraftLine> = {}): DraftLine => ({
  key: `L${Date.now().toString(36)}${(lineSeq += 1)}`,
  itemType: 'service', itemCode: '', description: '', uom: 'each', quantity: 1, unitPrice: 0, discountAmount: 0,
  taxRate: 0, accountNo: '', revenueAccount: '', costCenter: 'CC-OPS', ...defaults,
});

export const lineNet = (l: DraftLine) => money(Math.max(0, l.quantity * l.unitPrice - l.discountAmount));
export const lineTax = (l: DraftLine) => money(lineNet(l) * l.taxRate / 100);

export function draftTotals(lines: DraftLine[]) {
  const net = money(lines.reduce((s, l) => s + lineNet(l), 0));
  const tax = money(lines.reduce((s, l) => s + lineTax(l), 0));
  return { net, tax, total: money(net + tax) };
}

export function toApiLines(lines: DraftLine[], mode: 'purchase' | 'sales', stockItems: StockItem[]) {
  return lines.map((l) => {
    const item = l.itemType === 'stock' ? stockItems.find((s) => s.itemCode === l.itemCode) : undefined;
    return {
      itemType: l.itemType,
      itemCode: l.itemType === 'stock' ? l.itemCode : undefined,
      description: l.description || item?.description || `${ITEM_TYPE_LABEL[l.itemType]}`,
      uom: l.uom || item?.uom || 'each',
      quantity: l.quantity,
      unitPrice: l.unitPrice,
      discountAmount: l.discountAmount,
      taxRate: l.taxRate,
      taxCode: l.taxRate > 0 ? 'VAT' : 'none',
      accountNo: mode === 'purchase' && l.itemType !== 'stock' ? (l.accountNo || undefined) : undefined,
      inventoryAccount: item?.glAccount || undefined,
      revenueAccount: mode === 'sales' ? (l.revenueAccount || undefined) : undefined,
      costCenter: l.costCenter || undefined,
    };
  });
}

export function validateDraftLines(lines: DraftLine[], mode: 'purchase' | 'sales', stockItems: StockItem[]): string | null {
  if (!lines.length) return 'Add at least one line.';
  for (const [i, l] of lines.entries()) {
    const n = i + 1;
    if (l.itemType === 'stock' && !l.itemCode) return `Line ${n}: choose the stock item.`;
    if (l.itemType === 'stock' && !stockItems.some((s) => s.itemCode === l.itemCode)) return `Line ${n}: stock item ${l.itemCode} is not registered for this entity.`;
    if (!l.description.trim() && l.itemType !== 'stock') return `Line ${n}: enter a description.`;
    if (!(l.quantity > 0)) return `Line ${n}: quantity must be positive.`;
    if (l.unitPrice < 0) return `Line ${n}: unit price cannot be negative.`;
    if (l.discountAmount < 0 || l.discountAmount > l.quantity * l.unitPrice + 0.009) return `Line ${n}: discount exceeds the line value.`;
    if (l.taxRate < 0 || l.taxRate > 100) return `Line ${n}: tax rate must be between 0 and 100.`;
    if (mode === 'purchase' && l.itemType !== 'stock' && !l.accountNo) return `Line ${n}: select the GL account to charge.`;
    if (mode === 'sales' && !l.revenueAccount) return `Line ${n}: select the revenue account.`;
  }
  return null;
}

interface LineEditorProps {
  lines: DraftLine[];
  onChange: (lines: DraftLine[]) => void;
  mode: 'purchase' | 'sales';
  stockItems: StockItem[];
  accounts: AccountMaster[];
  currency: string;
  /** Restrict the selectable item types (e.g. a direct service invoice). */
  allowedTypes?: TradeItemType[];
  defaultTaxRate: number;
}

export function LineEditor({ lines, onChange, mode, stockItems, accounts, currency, allowedTypes, defaultTaxRate }: LineEditorProps) {
  const types = (allowedTypes || (['stock', 'office', 'service', 'asset'] as TradeItemType[]));
  const chargeAccounts = useMemo(() => accounts.filter((a) => a.active && (a.type === 'Expense' || a.type === 'Asset')), [accounts]);
  const revenueAccounts = useMemo(() => accounts.filter((a) => a.active && a.type === 'Income'), [accounts]);
  const sym = symbolFor(currency);
  const update = (key: string, patch: Partial<DraftLine>) => onChange(lines.map((l) => (l.key === key ? { ...l, ...patch } : l)));
  const remove = (key: string) => onChange(lines.filter((l) => l.key !== key));
  const add = () => onChange([...lines, newDraftLine({ itemType: types[0], taxRate: defaultTaxRate, revenueAccount: revenueAccounts.find((a) => a.accountNo === '400000')?.accountNo || revenueAccounts[0]?.accountNo || '' })]);
  const totals = draftTotals(lines);
  return (
    <div className="space-y-2">
      <div className="overflow-x-auto rounded-lg border border-sky-200">
        <table className="w-full min-w-[980px] text-[11px]">
          <thead>
            <tr className="bg-sky-50/70">
              <th className={thCls}>#</th>
              <th className={thCls}>Type</th>
              <th className={thCls}>Item / description</th>
              <th className={thCls}>{mode === 'purchase' ? 'Charge account' : 'Revenue account'}</th>
              <th className={thCls}>Cost centre</th>
              <th className={thCls + ' text-right'}>Qty</th>
              <th className={thCls}>UoM</th>
              <th className={thCls + ' text-right'}>Unit price</th>
              <th className={thCls + ' text-right'}>Discount</th>
              <th className={thCls + ' text-right'}>Tax %</th>
              <th className={thCls + ' text-right'}>Line total</th>
              <th className={thCls}></th>
            </tr>
          </thead>
          <tbody>
            {lines.map((l, i) => {
              const item = l.itemType === 'stock' ? stockItems.find((s) => s.itemCode === l.itemCode) : undefined;
              return (
                <tr key={l.key} className="border-t border-sky-100 align-top">
                  <td className="px-2 py-1.5 font-mono text-[#355875]">{i + 1}</td>
                  <td className="px-2 py-1.5">
                    <select value={l.itemType} onChange={(e) => update(l.key, { itemType: e.target.value as TradeItemType, itemCode: '', accountNo: '' })} className={inputCls + ' min-w-[120px]'}>
                      {types.map((t) => <option key={t} value={t}>{ITEM_TYPE_LABEL[t]}</option>)}
                    </select>
                  </td>
                  <td className="px-2 py-1.5 min-w-[220px] space-y-1">
                    {l.itemType === 'stock' ? (
                      <select value={l.itemCode} onChange={(e) => {
                        const s = stockItems.find((x) => x.itemCode === e.target.value);
                        update(l.key, { itemCode: e.target.value, description: s?.description || '', uom: s?.uom || 'each', unitPrice: mode === 'purchase' && s && l.unitPrice === 0 ? s.unitCost : l.unitPrice });
                      }} className={inputCls}>
                        <option value="">Select stock item</option>
                        {stockItems.map((s) => <option key={s.id} value={s.itemCode}>{s.itemCode} · {s.description} ({fmtQty(s.quantityOnHand)} {s.uom} on hand)</option>)}
                      </select>
                    ) : (
                      <input value={l.description} onChange={(e) => update(l.key, { description: e.target.value })} placeholder="Description" className={inputCls} />
                    )}
                    {item && <div className="text-[10px] text-[#355875]">Carrying cost {sym}{fmtMoney(item.unitCost)} · control {item.glAccount || '120000'}</div>}
                  </td>
                  <td className="px-2 py-1.5 min-w-[200px]">
                    {mode === 'purchase' ? (
                      l.itemType === 'stock' ? <span className="text-[10px] text-[#355875]">Inventory control {item?.glAccount || '120000'} · GRNI 204000</span> : (
                        <select value={l.accountNo} onChange={(e) => update(l.key, { accountNo: e.target.value })} className={inputCls}>
                          <option value="">Select account</option>
                          {chargeAccounts.map((a) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>)}
                        </select>
                      )
                    ) : (
                      <select value={l.revenueAccount} onChange={(e) => update(l.key, { revenueAccount: e.target.value })} className={inputCls}>
                        <option value="">Select revenue account</option>
                        {revenueAccounts.map((a) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>)}
                      </select>
                    )}
                  </td>
                  <td className="px-2 py-1.5"><input value={l.costCenter} onChange={(e) => update(l.key, { costCenter: e.target.value })} className={inputCls + ' w-24 font-mono'} /></td>
                  <td className="px-2 py-1.5"><input type="number" min="0" step="0.001" value={l.quantity} onChange={(e) => update(l.key, { quantity: Number(e.target.value) })} className={inputCls + ' w-20 text-right font-mono'} /></td>
                  <td className="px-2 py-1.5"><input value={l.uom} onChange={(e) => update(l.key, { uom: e.target.value })} className={inputCls + ' w-16'} /></td>
                  <td className="px-2 py-1.5"><input type="number" min="0" step="0.01" value={l.unitPrice} onChange={(e) => update(l.key, { unitPrice: Number(e.target.value) })} className={inputCls + ' w-24 text-right font-mono'} /></td>
                  <td className="px-2 py-1.5"><input type="number" min="0" step="0.01" value={l.discountAmount} onChange={(e) => update(l.key, { discountAmount: Number(e.target.value) })} className={inputCls + ' w-20 text-right font-mono'} /></td>
                  <td className="px-2 py-1.5"><input type="number" min="0" max="100" step="0.5" value={l.taxRate} onChange={(e) => update(l.key, { taxRate: Number(e.target.value) })} className={inputCls + ' w-16 text-right font-mono'} /></td>
                  <td className={numCls + ' font-bold whitespace-nowrap'}>{sym}{fmtMoney(lineNet(l) + lineTax(l))}</td>
                  <td className="px-2 py-1.5"><button type="button" onClick={() => remove(l.key)} className="text-rose-700 hover:underline">Remove</button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button type="button" onClick={add} className={btnSecondary}>+ Add line</button>
        <div className="flex gap-4 font-mono text-[11px]">
          <span>Net <strong>{sym}{fmtMoney(totals.net)}</strong></span>
          <span>Tax <strong>{sym}{fmtMoney(totals.tax)}</strong></span>
          <span className="text-[#082f4f]">Total <strong>{sym}{fmtMoney(totals.total)}</strong></span>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Lifecycle actions (maker / checker separation enforced by the server)
 * ------------------------------------------------------------------ */
export interface LifecycleHandlers {
  onFulfil?: (doc: TradeDocument) => void;        // receive goods / deliver
  onInvoice?: (doc: TradeDocument) => void;       // bill a receipt / delivery
  onPay?: (doc: TradeDocument) => void;           // settle an open invoice
  onNote?: (doc: TradeDocument) => void;          // credit / debit note
  onConvert?: (doc: TradeDocument) => void;       // requisition → PO
  onAllocate?: (doc: TradeDocument) => void;      // open credit → invoices
}

export function LifecycleActions({ doc, desk, currentUser, handlers, onOpen }: { doc: TradeDocument; desk: TradeDesk; currentUser: UserAccount; handlers: LifecycleHandlers; onOpen: (doc: TradeDocument) => void }) {
  const postable = POSTING_TYPES.has(doc.docType);
  const isChecker = currentUser.role === 'owner' || currentUser.canCheck;
  const ownDocument = doc.createdBy === currentUser.username || doc.submittedBy === currentUser.username;
  const busy = desk.busy;
  const buttons: ReactNode[] = [];
  if (doc.status === 'Draft') {
    buttons.push(<button key="submit" disabled={busy} onClick={() => void desk.submitAndPost(doc, postable)} className={btnPrimary}>{postable ? 'Submit & post' : 'Submit for approval'}</button>);
  }
  if (doc.status === 'Submitted') {
    if (isChecker && !ownDocument) {
      buttons.push(<button key="approve" disabled={busy} onClick={() => { const reason = window.prompt(`Checker approval of ${doc.docNo} — note for the audit trail:`, 'Reviewed and approved') ?? ''; if (reason !== '') void desk.approveAndPost(doc, postable, reason); }} className={btnGreen}>{postable ? 'Approve & post' : 'Approve'}</button>);
    } else {
      buttons.push(<span key="await" className="text-[10.5px] font-semibold text-amber-800">Awaiting independent checker</span>);
    }
  }
  if (doc.status === 'Approved' && postable) {
    buttons.push(<button key="post" disabled={busy} onClick={() => void desk.post(doc)} className={btnPrimary}>Post</button>);
  }
  if (doc.docType === 'purchase_requisition' && doc.status === 'Approved' && handlers.onConvert) {
    buttons.push(<button key="convert" disabled={busy} onClick={() => handlers.onConvert!(doc)} className={btnGreen}>Raise PO</button>);
  }
  if (doc.docType === 'purchase_order' && ['Approved', 'PartiallyReceived'].includes(doc.status) && handlers.onFulfil) {
    buttons.push(<button key="grn" disabled={busy} onClick={() => handlers.onFulfil!(doc)} className={btnGreen}>{doc.status === 'PartiallyReceived' ? 'Receive balance' : 'Receive goods'}</button>);
  }
  if (doc.docType === 'purchase_order' && ['Approved', 'PartiallyReceived', 'Received'].includes(doc.status) && handlers.onInvoice && doc.lines.some((l) => l.itemType === 'service' || doc.status !== 'Approved')) {
    buttons.push(<button key="sin" disabled={busy} onClick={() => handlers.onInvoice!(doc)} className={btnSecondary}>Supplier invoice</button>);
  }
  if (doc.docType === 'goods_receipt' && doc.status === 'Posted' && handlers.onInvoice) {
    buttons.push(<button key="sin2" disabled={busy} onClick={() => handlers.onInvoice!(doc)} className={btnSecondary}>Match invoice</button>);
  }
  if (doc.docType === 'sales_order' && ['Approved', 'PartiallyDelivered'].includes(doc.status) && handlers.onFulfil) {
    buttons.push(<button key="del" disabled={busy} onClick={() => handlers.onFulfil!(doc)} className={btnGreen}>{doc.status === 'PartiallyDelivered' ? 'Deliver balance' : 'Deliver'}</button>);
  }
  if (doc.docType === 'sales_delivery' && doc.status === 'Posted' && handlers.onInvoice) {
    buttons.push(<button key="inv" disabled={busy} onClick={() => handlers.onInvoice!(doc)} className={btnSecondary}>Invoice</button>);
  }
  if ((doc.docType === 'supplier_invoice' || doc.docType === 'sales_invoice') && ['Open', 'PartiallySettled'].includes(doc.status)) {
    if (handlers.onPay) buttons.push(<button key="pay" disabled={busy} onClick={() => handlers.onPay!(doc)} className={btnGreen}>{doc.docType === 'supplier_invoice' ? 'Pay' : 'Receive payment'}</button>);
  }
  if ((doc.docType === 'supplier_invoice' || doc.docType === 'sales_invoice') && doc.postedAt && handlers.onNote) {
    buttons.push(<button key="note" disabled={busy} onClick={() => handlers.onNote!(doc)} className={btnAmber}>{doc.docType === 'supplier_invoice' ? 'Debit / credit note' : 'Credit note'}</button>);
  }
  if (doc.status === 'OpenCredit' && handlers.onAllocate && (doc.openBalance ?? 0) > 0.009) {
    buttons.push(<button key="alloc" disabled={busy} onClick={() => handlers.onAllocate!(doc)} className={btnAmber}>Allocate credit</button>);
  }
  // Every document can be printed the moment it exists — and the sheet that
  // comes out is the document itself (tax invoice, purchase order, GRN),
  // never the application screen.
  buttons.push(
    <button key="print" type="button" onClick={() => printTradeDocument(doc, desk.printEntity, currentUser.name)} title={`Print ${documentTitle(doc.docType)}`}
      className="rounded border border-sky-300 bg-white px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">
      <Printer className="h-3 w-3 inline" /> Print
    </button>,
  );
  buttons.push(<button key="open" onClick={() => onOpen(doc)} className="rounded px-2 py-1 text-[11px] font-bold text-[#006f98] hover:underline">Open</button>);
  return <div className="flex flex-wrap items-center justify-end gap-1">{buttons}</div>;
}

/* ------------------------------------------------------------------ *
 * Document table
 * ------------------------------------------------------------------ */
export function fulfilmentSummary(doc: TradeDocument, documents: TradeDocument[], childType: string): string | null {
  if (!['purchase_order', 'sales_order'].includes(doc.docType)) return null;
  const ordered = doc.lines.reduce((s, l) => s + l.quantity, 0);
  const done = doc.lines.reduce((s, l) => s + fulfilledQuantity(documents, l.id, childType), 0);
  return `${fmtQty(done)} / ${fmtQty(ordered)}`;
}

export function DocumentsTable({ title, sub, docs, documents, desk, currentUser, handlers, onOpen, emptyText, childType, actions }: {
  title: string; sub?: string; docs: TradeDocument[]; documents: TradeDocument[]; desk: TradeDesk; currentUser: UserAccount;
  handlers: LifecycleHandlers; onOpen: (doc: TradeDocument) => void; emptyText: string; childType?: string; actions?: ReactNode;
}) {
  const sorted = [...docs].sort((a, b) => b.date.localeCompare(a.date) || b.docNo.localeCompare(a.docNo));
  return (
    <Card title={title} sub={sub} action={actions}>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1000px] text-xs">
          <thead>
            <tr className="border-b border-sky-200">
              <th className={thCls}>Document</th>
              <th className={thCls}>Date</th>
              <th className={thCls}>Party</th>
              <th className={thCls}>Reference</th>
              <th className={thCls}>Status</th>
              <th className={thCls + ' text-right'}>Net</th>
              <th className={thCls + ' text-right'}>Tax</th>
              <th className={thCls + ' text-right'}>Total</th>
              <th className={thCls + ' text-right'}>{childType ? 'Fulfilled' : 'Open balance'}</th>
              <th className={thCls + ' text-right'}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {sorted.length === 0 && <tr><td colSpan={10} className="px-3 py-6 text-center text-[#355875]">{emptyText}</td></tr>}
            {sorted.map((d) => (
              <tr key={d.id} className={rowCls}>
                <td className="px-3 py-2">
                  <div className="font-mono font-bold text-[#855b00]">{d.docNo}</div>
                  <div className="text-[10px] text-[#355875]">{DOC_TYPE_LABEL[d.docType] || d.docType} · v{d.version}</div>
                </td>
                <td className="px-3 py-2 font-mono text-[#2d4f6d]">{d.date}{d.dueDate ? <div className="text-[10px]">due {d.dueDate}</div> : null}</td>
                <td className="px-3 py-2 font-bold text-[#082f4f]">{d.partyName || <span className="text-[#355875] font-normal">—</span>}</td>
                <td className="px-3 py-2 font-mono text-[10.5px] text-[#2d4f6d]">{d.externalRef || d.sourceRef || '—'}</td>
                <td className="px-3 py-2"><StatusBadge status={d.status} /></td>
                <td className={numCls}>{d.currency} {fmtMoney(d.netAmount)}</td>
                <td className={numCls}>{fmtMoney(d.taxAmount)}</td>
                <td className={numCls + ' font-bold text-[#082f4f]'}>{fmtMoney(d.totalAmount)}</td>
                <td className={numCls}>{childType ? fulfilmentSummary(d, documents, childType) : d.openBalance === null ? '—' : fmtMoney(d.openBalance)}</td>
                <td className="px-3 py-2"><LifecycleActions doc={d} desk={desk} currentUser={currentUser} handlers={handlers} onOpen={onOpen} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

/* ------------------------------------------------------------------ *
 * Payments table (cash movements + open-item allocation state)
 * ------------------------------------------------------------------ */
export function PaymentsTable({ payments, documents, desk, currentUser, onAllocate, types, title, sub }: {
  payments: TradePayment[]; documents: TradeDocument[]; desk: TradeDesk; currentUser: UserAccount;
  onAllocate: (p: TradePayment) => void; types: string[]; title: string; sub: string;
}) {
  const rows = payments.filter((p) => types.includes(p.paymentType) || (p.paymentType === 'reversal' && types.length)).sort((a, b) => b.date.localeCompare(a.date) || b.paymentNo.localeCompare(a.paymentNo));
  const isChecker = currentUser.role === 'owner' || currentUser.canCheck;
  const docNo = (id: string) => documents.find((d) => d.id === id)?.docNo || id.slice(0, 8);
  return (
    <Card title={title} sub={sub}>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[900px] text-xs">
          <thead>
            <tr className="border-b border-sky-200">
              <th className={thCls}>Voucher</th><th className={thCls}>Date</th><th className={thCls}>Type</th><th className={thCls}>Party</th>
              <th className={thCls + ' text-right'}>Gross</th><th className={thCls + ' text-right'}>Withheld</th><th className={thCls + ' text-right'}>Cash</th>
              <th className={thCls}>Applied to</th><th className={thCls + ' text-right'}>Unapplied</th><th className={thCls}>Status</th><th className={thCls + ' text-right'}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={11} className="px-3 py-6 text-center text-[#355875]">No payments recorded yet.</td></tr>}
            {rows.map((p) => (
              <tr key={p.id} className={rowCls}>
                <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{p.paymentNo}{p.reversalOf && <div className="text-[10px] font-normal text-[#355875]">reversal</div>}</td>
                <td className="px-3 py-2 font-mono">{p.date}</td>
                <td className="px-3 py-2">{p.paymentType.replace(/_/g, ' ')}<div className="text-[10px] text-[#355875]">{p.method.replace(/_/g, ' ')}</div></td>
                <td className="px-3 py-2 font-bold text-[#082f4f]">{p.partyName}</td>
                <td className={numCls}>{p.currency} {fmtMoney(p.amount)}</td>
                <td className={numCls}>{fmtMoney(p.withheldAmount)}</td>
                <td className={numCls + ' font-bold'}>{fmtMoney(p.cashAmount)}</td>
                <td className="px-3 py-2 font-mono text-[10.5px]">{p.allocations.length ? p.allocations.map((a) => `${docNo(a.targetDocumentId)} ${fmtMoney(a.amount)}`).join(', ') : '—'}</td>
                <td className={numCls + (p.unallocated > 0.009 ? ' text-amber-800 font-bold' : '')}>{fmtMoney(p.unallocated)}</td>
                <td className="px-3 py-2"><StatusBadge status={p.status} /></td>
                <td className="px-3 py-2">
                  <div className="flex flex-wrap justify-end gap-1">
                    <button type="button" onClick={() => printPaymentDocument(p, desk.printEntity, currentUser.name, {
                      bankName: desk.state?.bankAccounts?.find((b) => b.id === p.bankAccountId)?.name,
                      allocations: p.allocations.map((a) => ({ docNo: docNo(a.targetDocumentId), amount: a.amount })),
                    })} title="Print receipt / payment voucher" className="rounded border border-sky-300 bg-white px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50">
                      <Printer className="h-3 w-3 inline" /> Print
                    </button>
                    {p.status === 'posted' && p.unallocated > 0.009 && p.paymentType !== 'reversal' && <button disabled={desk.busy} onClick={() => onAllocate(p)} className={btnAmber}>Apply to invoices</button>}
                    {p.status === 'posted' && p.paymentType !== 'reversal' && isChecker && (
                      <button disabled={desk.busy} onClick={() => { const reason = window.prompt(`Reverse ${p.paymentNo} — reason (audit trail):`) ?? ''; if (reason.trim()) void desk.run({ action: 'reverse_payment', paymentId: p.id, reason: reason.trim(), date: new Date().toISOString().slice(0, 10) }, (r) => `${p.paymentNo} reversed by ${String(r.reversalNo || '')}.`); }} className="rounded border border-rose-300 bg-rose-50 px-2 py-1 text-[11px] font-bold text-rose-800 hover:bg-rose-100 disabled:opacity-50">Reverse</button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

/* ------------------------------------------------------------------ *
 * Document drawer — lines, traceability chain, audit trail
 * ------------------------------------------------------------------ */
export function DocumentDrawer({ doc, documents, desk, currentUser, handlers, onClose }: { doc: TradeDocument; documents: TradeDocument[]; desk: TradeDesk; currentUser: UserAccount; handlers: LifecycleHandlers; onClose: () => void }) {
  const byId = useMemo(() => new Map(documents.map((d) => [d.id, d])), [documents]);
  const [tab, setTab] = useState<'lines' | 'chain' | 'audit' | 'files'>('lines');
  // The workspace carries only a capped audit window (for speed). The drawer
  // pulls the COMPLETE history of this one document from the server, so nothing
  // is ever hidden just because the entity has a long history.
  const cached = useMemo(
    () => (desk.state?.auditEvents || []).filter((e) => e.recordId === doc.id).sort((a, b) => a.occurredAt.localeCompare(b.occurredAt)),
    [desk.state, doc.id],
  );
  const [fullAudit, setFullAudit] = useState<TradeAuditEvent[] | null>(null);
  useEffect(() => {
    let alive = true;
    setFullAudit(null);
    void fetchRecordAudit(desk.clientId, doc.id).then((events) => { if (alive) setFullAudit(events); });
    return () => { alive = false; };
  }, [desk.clientId, doc.id]);
  const audit = fullAudit && fullAudit.length >= cached.length ? fullAudit : cached;
  const upstream = doc.links.filter((l) => l.toDocumentId === doc.id).map((l) => byId.get(l.fromDocumentId)).filter((d): d is TradeDocument => !!d);
  const downstream = doc.links.filter((l) => l.fromDocumentId === doc.id).map((l) => byId.get(l.toDocumentId)).filter((d): d is TradeDocument => !!d);
  const uniq = (list: TradeDocument[]) => [...new Map(list.map((d) => [d.id, d])).values()];
  const data = doc.data || {};
  const journalNos = audit.map((e) => (e.afterState && typeof e.afterState === 'object' ? (e.afterState as Record<string, unknown>).journalNo : undefined)).filter((j): j is string => typeof j === 'string');
  return (
    <Modal title={`${DOC_TYPE_LABEL[doc.docType] || doc.docType} ${doc.docNo}`} sub={`${doc.partyName || 'No counterparty'} · ${doc.currency} · status ${doc.status} · created by ${doc.createdBy}${doc.approvedBy ? ` · approved by ${doc.approvedBy}` : ''}${doc.postedAt ? ` · posted ${new Date(doc.postedAt).toLocaleString()}` : ''}`} onClose={onClose} wide>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex gap-1">
          {(['lines', 'chain', 'audit'] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`rounded px-3 py-1 text-[11px] font-bold ${tab === t ? 'bg-[#082f4f] text-white' : 'bg-sky-50 text-[#082f4f]'}`}>{t === 'lines' ? 'Lines' : t === 'chain' ? 'Document chain' : `Audit trail (${audit.length})`}</button>
          ))}
        </div>
        <LifecycleActions doc={doc} desk={desk} currentUser={currentUser} handlers={handlers} onOpen={() => undefined} />
      </div>
      {tab === 'lines' && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2 text-[11px] sm:grid-cols-4">
            <div className="rounded border border-sky-200 bg-sky-50/60 p-2"><div className={labelCls}>Net</div><div className="font-mono font-bold">{doc.currency} {fmtMoney(doc.netAmount)}</div></div>
            <div className="rounded border border-sky-200 bg-sky-50/60 p-2"><div className={labelCls}>Tax</div><div className="font-mono font-bold">{fmtMoney(doc.taxAmount)}</div></div>
            <div className="rounded border border-sky-200 bg-sky-50/60 p-2"><div className={labelCls}>Total</div><div className="font-mono font-bold">{fmtMoney(doc.totalAmount)}</div></div>
            <div className="rounded border border-sky-200 bg-sky-50/60 p-2"><div className={labelCls}>{doc.openBalance === null ? 'Rate' : 'Open balance'}</div><div className="font-mono font-bold">{doc.openBalance === null ? `${doc.exchangeRate} → ${doc.functionalCurrency}` : fmtMoney(doc.openBalance)}</div></div>
          </div>
          {(doc.externalRef || doc.sourceRef || data.evidenceRef || data.serviceEvidence || data.notes || data.paymentTerms || journalNos.length > 0) && (
            <div className="rounded border border-sky-200 p-2 text-[11px] text-[#2d4f6d] space-y-0.5">
              {doc.externalRef && <div>Supplier / external reference: <span className="font-mono font-bold">{doc.externalRef}</span></div>}
              {doc.sourceRef && <div>Source document: <span className="font-mono font-bold">{doc.sourceRef}</span></div>}
              {typeof data.evidenceRef === 'string' && data.evidenceRef && <div>Delivery / acceptance evidence: <span className="font-mono font-bold">{data.evidenceRef}</span></div>}
              {typeof data.serviceEvidence === 'string' && data.serviceEvidence && <div>Service completion evidence: <span className="font-mono font-bold">{data.serviceEvidence}</span></div>}
              {typeof data.paymentTerms === 'string' && data.paymentTerms && <div>Payment terms: {data.paymentTerms}</div>}
              {typeof data.notes === 'string' && data.notes && <div>Notes: {data.notes}</div>}
              {journalNos.length > 0 && <div>Journal document(s): <span className="font-mono font-bold">{[...new Set(journalNos)].join(', ')}</span> — open the General Ledger to see the posted lines.</div>}
            </div>
          )}
          <div className="overflow-x-auto rounded border border-sky-200">
            <table className="w-full min-w-[800px] text-[11px]">
              <thead><tr className="bg-sky-50/70"><th className={thCls}>#</th><th className={thCls}>Item</th><th className={thCls}>Type</th><th className={thCls}>Account</th><th className={thCls + ' text-right'}>Qty</th><th className={thCls + ' text-right'}>Unit</th><th className={thCls + ' text-right'}>Disc.</th><th className={thCls + ' text-right'}>Tax</th><th className={thCls + ' text-right'}>Total</th></tr></thead>
              <tbody>
                {doc.lines.map((l) => (
                  <tr key={l.id} className="border-t border-sky-100">
                    <td className="px-2 py-1 font-mono">{l.lineNo}</td>
                    <td className="px-2 py-1">{l.itemCode && <span className="font-mono font-bold text-[#855b00]">{l.itemCode} · </span>}{l.description}{typeof l.data?.carryingUnitCost === 'number' ? <div className="text-[10px] text-[#355875]">carrying cost {fmtMoney(l.data.carryingUnitCost as number)}/unit</div> : null}</td>
                    <td className="px-2 py-1">{l.itemType}</td>
                    <td className="px-2 py-1 font-mono">{l.revenueAccount || l.accountNo || l.inventoryAccount || '—'}{l.costCenter ? <div className="text-[10px]">{l.costCenter}</div> : null}</td>
                    <td className={numCls}>{fmtQty(l.quantity)} {l.uom}</td>
                    <td className={numCls}>{fmtMoney(l.unitPrice)}</td>
                    <td className={numCls}>{fmtMoney(l.discountAmount)}</td>
                    <td className={numCls}>{fmtMoney(l.taxAmount)} <span className="text-[10px]">({l.taxRate}%)</span></td>
                    <td className={numCls + ' font-bold'}>{fmtMoney(l.totalAmount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {tab === 'files' && (
        <AttachmentsPanel
          clientId={desk.clientId}
          docId={doc.id}
          docNo={doc.docNo}
          addedBy={currentUser.name}
          canDelete={doc.status === 'Draft' || currentUser.role === 'owner' || currentUser.canCheck}
        />
      )}
      {tab === 'chain' && (
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <div className={labelCls}>Upstream (this document was created from)</div>
            {uniq(upstream).length === 0 ? <p className="text-[#355875]">None — this is the start of the chain.</p> : uniq(upstream).map((d) => <div key={d.id} className="flex items-center justify-between rounded border border-sky-200 px-2 py-1.5 mb-1"><span><span className="font-mono font-bold text-[#855b00]">{d.docNo}</span> · {DOC_TYPE_LABEL[d.docType] || d.docType}</span><StatusBadge status={d.status} /></div>)}
          </div>
          <div>
            <div className={labelCls}>Downstream (created from this document)</div>
            {uniq(downstream).length === 0 ? <p className="text-[#355875]">Nothing yet.</p> : uniq(downstream).map((d) => <div key={d.id} className="flex items-center justify-between rounded border border-sky-200 px-2 py-1.5 mb-1"><span><span className="font-mono font-bold text-[#855b00]">{d.docNo}</span> · {DOC_TYPE_LABEL[d.docType] || d.docType}</span><StatusBadge status={d.status} /></div>)}
          </div>
        </div>
      )}
      {tab === 'audit' && (
        <div className="space-y-1">
          {audit.length === 0 && <p className="text-[#355875]">No audit events.</p>}
          {audit.map((e) => (
            <div key={e.id} className="flex items-start gap-2 rounded border border-sky-100 px-2 py-1.5">
              <FileText className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#355875]" />
              <div>
                <div className="font-bold text-[#082f4f]">{e.eventType.replace(/_/g, ' ')} <span className="font-normal text-[#355875]">· {e.actor} · {new Date(e.occurredAt).toLocaleString()}</span></div>
                {e.reason && <div className="text-[#2d4f6d]">{e.reason}</div>}
              </div>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}

/**
 * Single money-movement gateway.
 *
 * Cash used to leave the business from three different places (the P2P desk,
 * the O2C desk and the Payment Desk), each with its own controls. Every
 * settlement is now raised at the Payment Desk, so one screen enforces the
 * treasury account, payee verification, withholding tax and the maker limit.
 * The lifecycle desks keep the *context* (which invoice) and hand it over.
 */
export function PaymentDeskRedirect({ side, docNo, partyName, amount, currency, onGo, onClose }: {
  side: 'supplier' | 'customer';
  docNo?: string;
  partyName?: string;
  amount?: number | null;
  currency: string;
  onGo: () => void;
  onClose: () => void;
}) {
  const supplier = side === 'supplier';
  return (
    <Modal
      title={supplier ? 'Settle at the Payment Desk' : 'Receive at the Payment Desk'}
      sub="Every cash movement in this system is raised, controlled and posted at the Payment Desk — one treasury gateway, one audit trail."
      onClose={onClose}
    >
      <div className="space-y-4">
        <div className="rounded border border-sky-200 bg-sky-50/60 px-3 py-2.5 text-[11.5px] font-semibold text-[#0a253e]">
          {docNo ? (
            <>
              <span className="font-black">{docNo}</span>
              {partyName ? <> · {partyName}</> : null}
              {typeof amount === 'number' ? <> · open balance <span className="font-mono font-bold">{currency} {fmtMoney(amount)}</span></> : null}
            </>
          ) : (
            <>All open {supplier ? 'supplier invoices' : 'customer invoices'} for this entity are listed on the Payment Desk.</>
          )}
        </div>
        <ul className="list-disc space-y-1 pl-5 text-[11px] font-semibold text-[#355875]">
          <li>Treasury account, payment method and reference are captured once.</li>
          <li>Income / VAT withholding is computed from the GRA schedule.</li>
          <li>The maker limit and payee verification are enforced before anything posts.</li>
          <li>A payment voucher is produced for the file.</li>
        </ul>
        <div className="flex justify-end gap-2 border-t border-sky-100 pt-3">
          <button type="button" onClick={onClose} className={btnSecondary}>Cancel</button>
          <button type="button" onClick={onGo} className={btnPrimary}>
            Open the Payment Desk
          </button>
        </div>
      </div>
    </Modal>
  );
}
