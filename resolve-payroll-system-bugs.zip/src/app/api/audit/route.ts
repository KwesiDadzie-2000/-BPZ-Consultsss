import { desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { auditLog, clients } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

const LIMIT = 300;

/**
 * Read-only audit trail. Owners review every entity's control history;
 * other users see only their own entity's events. Newest first.
 */
export async function GET(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return Response.json({ ok: false, error: "Unauthorized" }, { status: 401 });

  const isOwner = user.role === "owner";
  let rows;
  if (isOwner) {
    rows = await db.select().from(auditLog).orderBy(desc(auditLog.timestamp)).limit(LIMIT);
  } else {
    if (user.clientId === null || user.clientId === undefined) {
      rows = await db.select().from(auditLog).where(eq(auditLog.clientId, -1)).limit(0);
    } else {
      rows = await db
        .select()
        .from(auditLog)
        .where(inArray(auditLog.clientId, [user.clientId]))
        .orderBy(desc(auditLog.timestamp))
        .limit(LIMIT);
    }
  }
  return Response.json({
    ok: true,
    events: rows.map((r) => ({
      timestamp: r.timestamp,
      username: r.username,
      action: r.action,
      target: r.target,
      details: r.details,
      clientId: r.clientId,
    })),
  });
}
