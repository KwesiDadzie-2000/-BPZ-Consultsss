import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { createSession, sanitizeUser } from "@/lib/auth";
import { hashPassword, needsRehash, newSalt, verifyPassword } from "@/lib/password";

export const dynamic = "force-dynamic";

// Server-side failed-attempt tracking (per server instance).
const failures = new Map<string, { count: number; until: number }>();
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MS = 5 * 60 * 1000;

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const identifier = String(body?.usernameOrEmail || "").trim().toLowerCase();
    const password = String(body?.password || "");
    if (!identifier || !password) {
      return Response.json({ ok: false, error: "Username and password are required." }, { status: 400 });
    }

    const lock = failures.get(identifier);
    if (lock && lock.until > Date.now()) {
      return Response.json({ ok: false, error: "Too many failed attempts. Wait 5 minutes before trying again." }, { status: 429 });
    }

    const found = await db
      .select()
      .from(users)
      .where(or(eq(users.username, identifier), eq(users.email, identifier)))
      .limit(1);
    const user = found[0];

    if (!user || !user.passwordHash || !user.passwordSalt || !(await verifyPassword(password, user.passwordSalt, user.passwordHash))) {
      const next = (lock?.count ?? 0) + 1;
      failures.set(identifier, { count: next, until: next >= MAX_FAILED_ATTEMPTS ? Date.now() + LOCKOUT_MS : 0 });
      return Response.json({ ok: false, error: "Invalid username, email, or password." }, { status: 401 });
    }

    if (user.status === "restricted" || user.status === "suspended") {
      return Response.json(
        { ok: false, error: `Account restricted by administrator.${user.restrictionReason ? ` Reason: "${user.restrictionReason}"` : ""}` },
        { status: 403 }
      );
    }

    failures.delete(identifier);

    // Transparent credential upgrade: any account still carrying a legacy
    // SHA-256 hash is re-hashed with scrypt on this successful login, so the
    // estate migrates to the strong KDF without locking anyone out.
    if (needsRehash(user.passwordHash)) {
      const salt = newSalt();
      await db
        .update(users)
        .set({ passwordSalt: salt, passwordHash: await hashPassword(password, salt) })
        .where(eq(users.id, user.id));
    }

    const token = await createSession(user.id);
    return Response.json({ ok: true, user: sanitizeUser(user), token });
  } catch (e) {
    console.error("login error", e);
    return Response.json({ ok: false, error: "Login failed." }, { status: 500 });
  }
}
