import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return Response.json({ ok: false, user: null }, { status: 401 });
  return Response.json({ ok: true, user });
}
