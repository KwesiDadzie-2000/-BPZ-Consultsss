import { db } from "@/db";
import {
  approvalRequests,
  bankAccounts,
  businessPartners,
  chartAccounts,
  closedPeriods,
  clients,
  companyProfiles,
  disclosureNotes,
  employees,
  journalLines,
  payrollRecords,
  prepaymentRecords,
  prepaymentSchedules,
  purchaseOrders,
  salesInvoices,
  users,
} from "@/db/schema";
import { getSessionUser, sanitizeUser } from "@/lib/auth";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/**
 * Returns the full workspace state for the authenticated user, tenant-scoped:
 * the owner receives every entity's books; other users receive only their own
 * entity's data (plus the firm-level chart of accounts and disclosure notes).
 */
export async function GET(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return Response.json({ ok: false, error: "Unauthorized" }, { status: 401 });

  const isOwner = user.role === "owner";
  const clientId = user.clientId ?? null;

  const visibleClients = isOwner
    ? await db.select().from(clients)
    : clientId === null
      ? []
      : await db.select().from(clients).where(eq(clients.id, clientId));
  const visibleIds = visibleClients.map((c) => c.id);
  const scoped = <T extends { clientId: number | null }>(rows: T[]) =>
    isOwner ? rows : rows.filter((r) => r.clientId !== null && visibleIds.includes(r.clientId));

  const [
    allLines,
    allBanks,
    allPOs,
    allInvoices,
    allEmployees,
    allPartners,
    allPayroll,
    allApprovals,
    allClosed,
    allPrepayments,
    allPrepaymentSchedules,
  ] = await Promise.all([
    db.select().from(journalLines),
    db.select().from(bankAccounts),
    db.select().from(purchaseOrders),
    db.select().from(salesInvoices),
    db.select().from(employees),
    db.select().from(businessPartners),
    db.select().from(payrollRecords),
    db.select().from(approvalRequests),
    db.select().from(closedPeriods),
    db.select().from(prepaymentRecords),
    db.select().from(prepaymentSchedules),
  ]);

  const profiles = await db.select().from(companyProfiles);
  const allCoa = await db.select().from(chartAccounts);
  // Chart of accounts: firm master (clientId null) plus the user's own entity customs.
  const coa = isOwner ? allCoa : allCoa.filter((a) => a.clientId === null || a.clientId === clientId);
  const notes = await db.select().from(disclosureNotes);
  // User accounts are returned to the owner only (sanitized — no password material).
  const allUsers = isOwner ? (await db.select().from(users)).map(sanitizeUser) : [];

  return Response.json({
    ok: true,
    state: {
      clients: visibleClients,
      journalLines: scoped(allLines),
      bankAccounts: scoped(allBanks),
      purchaseOrders: scoped(allPOs),
      salesInvoices: scoped(allInvoices),
      employees: scoped(allEmployees),
      businessPartners: scoped(allPartners),
      payrollRecords: scoped(allPayroll).map((r) => r.record),
      approvalRequests: scoped(allApprovals),
      prepaymentRecords: scoped(allPrepayments).map((r) => r.record),
      prepaymentSchedules: scoped(allPrepaymentSchedules).map((r) => r.line),
      companyProfiles: Object.fromEntries(
        profiles
          .filter((p) => isOwner || p.clientId === clientId)
          .map((p) => [p.clientId, p])
      ),
      chartOfAccounts: coa,
      disclosureNotes: notes,
      closedPeriods: scoped(allClosed).map((c) => ({ clientId: c.clientId, period: c.period })),
      users: allUsers,
    },
  });
}
