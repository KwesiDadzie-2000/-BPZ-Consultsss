import React, { useState } from 'react';
import { ClientEntity, BankAccount, ACDOCALine, AccountMaster, UserAccount } from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import { CheckCircle, Plus, Upload, Calculator } from 'lucide-react';
import { matchStatementLines, parseStatementCsv, buildFxRevaluation, StatementLine } from '../utils/reports';

interface BankingSectionProps {
  currentClient: ClientEntity;
  currentUser?: UserAccount;
  bankAccounts: BankAccount[];
  lines: ACDOCALine[];
  accounts?: AccountMaster[];
  onAddBankAccount?: (acc: BankAccount) => void;
  onAddJournalLines?: (lines: ACDOCALine[]) => boolean;
}

export const BankingSection: React.FC<BankingSectionProps> = ({
  currentClient,
  currentUser,
  bankAccounts,
  lines,
  accounts = [],
  onAddBankAccount,
  onAddJournalLines,
}) => {
  const [selectedAccId, setSelectedAccId] = useState<number>(bankAccounts[0]?.id || 1);
  const [showAddModal, setShowAddModal] = useState(false);
  const [bName, setBName] = useState('Operating Main Account');
  const [bBank, setBBank] = useState('GCB Bank Ltd');
  const [bAccNo, setBAccNo] = useState('10293847561');
  const [bCcy, setBCcy] = useState('GHS');
  const [bOpenBal, setBOpenBal] = useState(150000);
  const [bKind, setBKind] = useState<'bank' | 'cash'>('bank');
  const [bGl, setBGl] = useState('100000');

  // Bank statement import & reconciliation state
  const [stmtLines, setStmtLines] = useState<StatementLine[]>([]);
  const [stmtMsg, setStmtMsg] = useState<string | null>(null);
  // IAS 21 FX revaluation state
  const [fxCcy, setFxCcy] = useState('USD');
  const [fxBookRate, setFxBookRate] = useState(12);
  const [fxClosingRate, setFxClosingRate] = useState(12.5);
  const [fxDate, setFxDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [fxMsg, setFxMsg] = useState<string | null>(null);

  const activeAccount = bankAccounts.find((a) => a.id === selectedAccId) || bankAccounts[0];

  // Treasury GL accounts (bank and cash-on-hand accounts are kept separate).
  const treasuryAccounts = accounts.filter((a) => a.accountNo.startsWith('10'));
  const clientLines = lines.filter((l) => l.clientId === currentClient.id);

  // Statement matching against the selected treasury record's GL account.
  const matches = activeAccount?.glAccount ? matchStatementLines(stmtLines, clientLines, activeAccount.glAccount) : [];
  const matchedCount = matches.filter((m) => m.matched).length;
  const stmtDebits = stmtLines.reduce((n, s) => n + s.debit, 0);
  const stmtCredits = stmtLines.reduce((n, s) => n + s.credit, 0);
  const matchStatusFor = (docNo: string) => matches.find((m) => m.matchedDocNo === docNo);

  // IAS 21 unrealised FX revaluation preview on FCY monetary items in the journal.
  const fxRows = buildFxRevaluation(clientLines, accounts, fxCcy, fxBookRate, fxClosingRate);
  const fxGain = fxRows.reduce((n, r) => n + Math.max(0, r.gainLoss), 0);
  const fxLoss = fxRows.reduce((n, r) => n + Math.max(0, -r.gainLoss), 0);

  const handleImportStatement = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const parsed = parseStatementCsv(String(ev.target?.result || ''));
      setStmtLines(parsed);
      setStmtMsg(parsed.length
        ? `Imported ${parsed.length} statement lines for ${activeAccount?.name || 'this account'}. Auto-match ran against the posted ledger.`
        : 'No valid statement lines found. Expected CSV columns: Date,Description,Debit,Credit.');
      setTimeout(() => setStmtMsg(null), 6000);
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handlePostFxRevaluation = () => {
    if (!onAddJournalLines || !fxRows.length) return;
    const period = fxDate.slice(0, 7);
    const docNo = `FXREV-${fxCcy}-${period}`;
    const entries: ACDOCALine[] = [];
    fxRows.forEach((r, i) => {
      if (r.gainLoss > 0.009) {
        entries.push(
          { id: `JL-FX-${Date.now()}-${i}-1`, docNo, period, date: fxDate, module: 'FI', docType: 'JE', accountNo: r.accountNo, accountName: `${r.accountName} (FX revaluation)`, costCenter: 'CC-ADM', debit: Math.round(r.gainLoss * 100) / 100, credit: 0, currency: currentClient.currency, description: `IAS 21 unrealised FX gain at ${fxClosingRate} (book ${fxBookRate})`, createdBy: currentUser?.username || 'fx_revaluation', clientId: currentClient.id },
          { id: `JL-FX-${Date.now()}-${i}-2`, docNo, period, date: fxDate, module: 'FI', docType: 'JE', accountNo: '491000', accountName: 'Foreign Exchange Gain (IAS 21)', costCenter: 'CC-ADM', debit: 0, credit: Math.round(r.gainLoss * 100) / 100, currency: currentClient.currency, description: `Unrealised FX gain on ${r.accountNo} (${fxCcy})`, createdBy: currentUser?.username || 'fx_revaluation', clientId: currentClient.id },
        );
      } else if (r.gainLoss < -0.009) {
        entries.push(
          { id: `JL-FX-${Date.now()}-${i}-1`, docNo, period, date: fxDate, module: 'FI', docType: 'JE', accountNo: '580000', accountName: 'Foreign Exchange Loss', costCenter: 'CC-ADM', debit: Math.round(-r.gainLoss * 100) / 100, credit: 0, currency: currentClient.currency, description: `IAS 21 unrealised FX loss at ${fxClosingRate} (book ${fxBookRate})`, createdBy: currentUser?.username || 'fx_revaluation', clientId: currentClient.id },
          { id: `JL-FX-${Date.now()}-${i}-2`, docNo, period, date: fxDate, module: 'FI', docType: 'JE', accountNo: r.accountNo, accountName: `${r.accountName} (FX revaluation)`, costCenter: 'CC-ADM', debit: 0, credit: Math.round(-r.gainLoss * 100) / 100, currency: currentClient.currency, description: `Unrealised FX loss on ${r.accountNo} (${fxCcy})`, createdBy: currentUser?.username || 'fx_revaluation', clientId: currentClient.id },
        );
      }
    });
    if (!entries.length) return;
    const ok = onAddJournalLines(entries);
    setFxMsg(ok
      ? `FX revaluation ${docNo} posted: gains ${formatGHS(fxGain)}, losses ${formatGHS(fxLoss)}.`
      : `FX revaluation rejected. The period may be closed or document ${docNo} already exists.`);
    setTimeout(() => setFxMsg(null), 6000);
  };

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (onAddBankAccount) {
      const newAcc: BankAccount = {
        id: Date.now(),
        code: `${bKind === 'cash' ? 'CSH' : 'BNK'}-0${bankAccounts.length + 1}`,
        name: bName,
        bankName: bBank,
        accountNo: bAccNo,
        currency: bCcy,
        balance: bOpenBal,
        kind: bKind,
        glAccount: bGl || (bKind === 'cash' ? '102000' : '100000'),
      };
      onAddBankAccount(newAcc);
      setSelectedAccId(newAcc.id);
      setShowAddModal(false);
    }
  };

  // Statement lines are reconciled against the GL account mapped to the selected
  // treasury record — never the combined cash & bank pool.
  const bankLines = activeAccount
    ? lines.filter((l) => l.clientId === currentClient.id && (activeAccount.glAccount ? l.accountNo === activeAccount.glAccount : l.accountNo.startsWith('10')))
    : [];

  // GL tie-out: the treasury record's balance vs the cash GL balance in the journal.
  const glCash = activeAccount?.glAccount
    ? lines.filter((l) => l.clientId === currentClient.id && l.accountNo === activeAccount.glAccount)
        .reduce((n, l) => n + Math.round((l.debit - l.credit) * 100), 0) / 100
    : 0;
  const tieOut = activeAccount ? Math.round((activeAccount.balance - glCash) * 100) / 100 : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`BANK · Treasury & Bank Accounts · ${currentClient.code}`}
        title="Banking & Statement Reconciliation"
        desc="Multi-currency accounts, statement matching and balances."
      >
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
        >
          <Plus className="h-4 w-4" />
          <span>Add Bank Account</span>
        </button>
      </PageHeader>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Total Treasury Accounts" value={bankAccounts.length} sub="Operating & foreign exchange" />
        <Stat label="Active Account" value={activeAccount ? activeAccount.code : "—"} sub={activeAccount ? activeAccount.bankName : ""} />
        <Stat label="Recorded Bank Balance" value={activeAccount ? `${activeAccount.currency} ${formatGHS(activeAccount.balance)}` : "—"} tone="text-emerald-700" sub="Browser record; not bank-verified" />
        <Stat
          label="GL tie-out difference"
          value={activeAccount ? `${activeAccount.currency} ${formatGHS(Math.abs(tieOut))}` : "—"}
          tone={Math.abs(tieOut) < 0.01 ? "text-emerald-700" : "text-rose-700"}
          sub={activeAccount ? (Math.abs(tieOut) < 0.01 ? "Treasury record matches the general ledger" : "Treasury record and GL differ — post opening balances or clear unreconciled items") : ""}
        />
      </div>

      {/* Account Selector Strip */}
      <div className="flex flex-wrap gap-2">
        {bankAccounts.map((acc) => (
          <button
            key={acc.id}
            onClick={() => setSelectedAccId(acc.id)}
            className={`rounded-xl border p-3 text-left transition shadow-xs ${
              selectedAccId === acc.id
                ? 'border-[#082f4f] bg-sky-50 ring-1 ring-[#082f4f]'
                : 'border-sky-200 bg-white hover:bg-sky-50/50'
            }`}
          >
            <div className="flex items-center justify-between text-xs font-mono text-[#355875]">
              <span>{acc.code}</span>
              <span className="flex items-center gap-1.5">
                <span className={`rounded px-1.5 py-0.2 text-[9px] font-black uppercase ${acc.kind === 'cash' ? 'bg-amber-100 text-[#855b00]' : 'bg-sky-100 text-[#006f98]'}`}>{acc.kind === 'cash' ? 'Cash' : 'Bank'}</span>
                <span className="font-bold text-[#082f4f]">{acc.currency}</span>
              </span>
            </div>
            <div className="text-xs font-bold text-[#082f4f] mt-1">{acc.name}</div>
            <div className="text-[11px] text-[#2d4f6d]">{acc.bankName} · {acc.accountNo}</div>
            <div className="text-[10.5px] text-[#355875] font-mono mt-0.5">GL {acc.glAccount || (acc.kind === 'cash' ? '102000' : '100000')}</div>
            <div className="font-mono text-xs font-bold text-emerald-700 mt-1">
              {acc.currency} {formatGHS(acc.balance)}
            </div>
          </button>
        ))}
      </div>

      {/* Statement import, auto-reconciliation & IAS 21 FX revaluation */}
      <div className="grid gap-4 xl:grid-cols-2">
        <Card
          title="Statement import & reconciliation"
          sub="Import a bank statement CSV (Date,Description,Debit,Credit) and auto-match to the posted ledger"
          action={
            <label className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-1.5 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition cursor-pointer shadow-xs">
              <Upload className="h-3.5 w-3.5 text-[#006f98]" />
              <span>Import statement CSV</span>
              <input type="file" accept=".csv" onChange={handleImportStatement} className="hidden" />
            </label>
          }
        >
          <div className="space-y-3 text-xs">
            {stmtMsg && <div className="rounded-lg border border-sky-300 bg-sky-50 p-2.5 font-bold text-[#082f4f]">{stmtMsg}</div>}
            {stmtLines.length > 0 ? (
              <>
                <div className="flex flex-wrap gap-4 font-mono">
                  <span className="text-[#355875]">Statement lines: <strong className="text-[#082f4f]">{stmtLines.length}</strong></span>
                  <span className="text-[#355875]">Matched: <strong className="text-emerald-700">{matchedCount}</strong></span>
                  <span className="text-[#355875]">Unmatched: <strong className="text-rose-700">{stmtLines.length - matchedCount}</strong></span>
                  <span className="text-[#355875]">Statement debits: <strong className="text-[#082f4f]">{formatGHS(stmtDebits)}</strong></span>
                  <span className="text-[#355875]">Statement credits: <strong className="text-[#082f4f]">{formatGHS(stmtCredits)}</strong></span>
                </div>
                <div className="overflow-x-auto rounded-lg border border-sky-200">
                  <table className="w-full text-xs">
                    <thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Value date</th><th className={thCls}>Narration</th><th className={thCls + ' text-right'}>Debit</th><th className={thCls + ' text-right'}>Credit</th><th className={thCls}>Match status</th></tr></thead>
                    <tbody>
                      {matches.map((m, i) => (
                        <tr key={i} className={rowCls}>
                          <td className="px-3 py-2 font-mono text-[#2d4f6d]">{m.line.date}</td>
                          <td className="px-3 py-2 text-[#0a253e]">{m.line.description}</td>
                          <td className={numCls}>{m.line.debit > 0 ? formatGHS(m.line.debit) : '—'}</td>
                          <td className={numCls}>{m.line.credit > 0 ? formatGHS(m.line.credit) : '—'}</td>
                          <td className="px-3 py-2">
                            {m.matched
                              ? <span className="inline-flex items-center gap-1 rounded bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[10.5px] font-bold"><CheckCircle className="h-3 w-3" /><span>Matched · {m.matchedDocNo}</span></span>
                              : <span className="rounded bg-amber-100 text-[#855b00] px-2 py-0.5 text-[10.5px] font-bold">Unmatched</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            ) : (
              <p className="text-[#2d4f6d] leading-relaxed">No statement imported yet. Export a CSV from the bank (Date,Description,Debit,Credit) and import it here; the desk auto-matches each line to posted journal entries on this account within a 3-day value-date window.</p>
            )}
          </div>
        </Card>

        <Card title="FX revaluation (IAS 21)" sub="Unrealised gain/loss on foreign-currency monetary items in the journal">
          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <label className="font-bold text-[#355875]">Currency
                <select value={fxCcy} onChange={(e) => setFxCcy(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2 font-bold text-[#082f4f]">
                  <option value="USD">USD</option><option value="GBP">GBP</option><option value="EUR">EUR</option>
                </select>
              </label>
              <label className="font-bold text-[#355875]">Book rate
                <input type="number" step="0.0001" value={fxBookRate} onChange={(e) => setFxBookRate(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" />
              </label>
              <label className="font-bold text-[#355875]">Closing rate
                <input type="number" step="0.0001" value={fxClosingRate} onChange={(e) => setFxClosingRate(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" />
              </label>
              <label className="font-bold text-[#355875]">Revaluation date
                <input type="date" value={fxDate} onChange={(e) => setFxDate(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" />
              </label>
            </div>
            {fxMsg && <div className="rounded-lg border border-sky-300 bg-sky-50 p-2.5 font-bold text-[#082f4f]">{fxMsg}</div>}
            {fxRows.length > 0 ? (
              <>
                <div className="overflow-x-auto rounded-lg border border-sky-200">
                  <table className="w-full text-xs">
                    <thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Account</th><th className={thCls + ' text-right'}>{fxCcy} balance</th><th className={thCls + ' text-right'}>Revalued (GHS)</th><th className={thCls + ' text-right'}>Gain / (loss)</th></tr></thead>
                    <tbody>
                      {fxRows.map((r) => (
                        <tr key={r.accountNo} className={rowCls}>
                          <td className="px-3 py-2"><span className="font-mono font-bold text-[#082f4f]">{r.accountNo}</span> <span className="text-[#355875]">{r.accountName}</span></td>
                          <td className={numCls}>{formatGHS(r.fcyBalance)}</td>
                          <td className={numCls}>{formatGHS(r.revaluedGhs)}</td>
                          <td className={numCls + (r.gainLoss >= 0 ? ' text-emerald-700' : ' text-rose-700')}>{formatGHS(r.gainLoss)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <span className="text-[#2d4f6d]">Net unrealised: <strong className={fxGain - fxLoss >= 0 ? 'text-emerald-700' : 'text-rose-700'}>{formatGHS(fxGain - fxLoss)}</strong> (gains {formatGHS(fxGain)} · losses {formatGHS(fxLoss)})</span>
                  <button onClick={handlePostFxRevaluation} disabled={!onAddJournalLines} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs disabled:opacity-40">
                    <Calculator className="h-3.5 w-3.5" />
                    <span>Post revaluation JE</span>
                  </button>
                </div>
              </>
            ) : (
              <p className="text-[#2d4f6d] leading-relaxed">No {fxCcy}-denominated journal balances found for this entity. Post foreign-currency transactions (e.g. a {fxCcy} purchase order or receipt) and the revaluation preview appears here.</p>
            )}
          </div>
        </Card>
      </div>

      <Card
        title={`Statement Lines & Postings for ${activeAccount ? activeAccount.name : ""}`}
        sub="Universal Journal transactions affecting this bank account"
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Doc No</th>
                <th className={thCls}>Date</th>
                <th className={thCls}>Description</th>
                <th className={thCls + " text-right"}>Cash In / Debit (₵)</th>
                <th className={thCls + " text-right"}>Cash Out / Credit (₵)</th>
                <th className={thCls}>Audit Status</th>
              </tr>
            </thead>
            <tbody>
              {bankLines.map((l) => (
                <tr key={l.id} className={rowCls}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{l.docNo}</td>
                  <td className="px-3 py-2 font-mono text-[#2d4f6d]">{l.date}</td>
                  <td className="px-3 py-2 text-[#0a253e]">{l.description}</td>
                  <td className={numCls + " text-emerald-700 font-bold"}>
                    {l.debit > 0 ? formatGHS(l.debit) : '—'}
                  </td>
                  <td className={numCls + " text-rose-700 font-bold"}>
                    {l.credit > 0 ? formatGHS(l.credit) : '—'}
                  </td>
                  <td className="px-3 py-2">
                    {(() => {
                      const match = matchStatusFor(l.docNo);
                      if (stmtLines.length > 0) {
                        return match
                          ? <span className="inline-flex items-center gap-1 rounded bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[10.5px] font-bold"><CheckCircle className="h-3 w-3" /><span>Matched to statement</span></span>
                          : <span className="rounded bg-amber-100 text-[#855b00] px-2 py-0.5 text-[10.5px] font-bold">Not on statement</span>;
                      }
                      return <span className="inline-flex items-center gap-1 rounded bg-sky-100 text-[#006f98] px-2 py-0.5 text-[10.5px] font-bold"><CheckCircle className="h-3 w-3" /><span>Ledger posted</span></span>;
                    })()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Add Bank Account Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleCreateAccount} className="w-full max-w-md rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Add Real Bank Account</h3>
            <div className="space-y-3">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Account Label / Purpose</label>
                <input
                  type="text"
                  value={bName}
                  onChange={(e) => setBName(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-semibold text-[#082f4f]"
                  required
                />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Bank Name / Wallet Provider</label>
                <input
                  type="text"
                  value={bBank}
                  onChange={(e) => setBBank(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-semibold text-[#082f4f]"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Record Type</label>
                  <select
                    value={bKind}
                    onChange={(e) => setBKind(e.target.value as 'bank' | 'cash')}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-bold text-[#082f4f]"
                  >
                    <option value="bank">Bank account</option>
                    <option value="cash">Cash on hand / float</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">GL Account</label>
                  <select
                    value={bGl}
                    onChange={(e) => setBGl(e.target.value)}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-mono text-[#082f4f]"
                  >
                    {treasuryAccounts.map((a) => (
                      <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>
                    ))}
                    {treasuryAccounts.length === 0 && (
                      <>
                        <option value="100000">100000 · Cash at Bank — Operating</option>
                        <option value="102000">102000 · Petty Cash Safe Float</option>
                        <option value="103000">103000 · Cash on Hand — Office Till</option>
                        <option value="104000">104000 · Mobile Money Clearing</option>
                      </>
                    )}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Account Number</label>
                  <input
                    type="text"
                    value={bAccNo}
                    onChange={(e) => setBAccNo(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Currency</label>
                  <select
                    value={bCcy}
                    onChange={(e) => setBCcy(e.target.value)}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-bold text-[#082f4f]"
                  >
                    <option value="GHS">GHS (Ghana Cedi)</option>
                    <option value="USD">USD (US Dollar)</option>
                    <option value="GBP">GBP (British Pound)</option>
                    <option value="EUR">EUR (Euro)</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Opening Balance</label>
                <input
                  type="number"
                  step="0.01"
                  value={bOpenBal}
                  onChange={(e) => setBOpenBal(Number(e.target.value))}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono text-[#082f4f]"
                  required
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setShowAddModal(false)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 font-bold text-white">Save Bank Account</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
