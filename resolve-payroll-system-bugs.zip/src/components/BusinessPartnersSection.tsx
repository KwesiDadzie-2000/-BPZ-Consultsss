import React, { useState } from 'react';
import { ClientEntity, BusinessPartner, SalesInvoice, PurchaseOrder } from '../types/accounting';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { Plus, Search, FileSpreadsheet } from 'lucide-react';

interface BusinessPartnersSectionProps {
  currentClient: ClientEntity;
  partners: BusinessPartner[];
  salesInvoices: SalesInvoice[];
  purchaseOrders: PurchaseOrder[];
  onAddPartner: (p: BusinessPartner) => void;
}

export const BusinessPartnersSection: React.FC<BusinessPartnersSectionProps> = ({
  currentClient,
  partners,
  salesInvoices,
  purchaseOrders,
  onAddPartner,
}) => {
  const [filterType, setFilterType] = useState<'ALL' | 'Vendor' | 'Customer'>('ALL');
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);

  // Form states
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [type, setType] = useState<'Vendor' | 'Customer'>('Vendor');
  const [tin, setTin] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [vatWithholdingAgent, setVatWithholdingAgent] = useState(false);
  const [vatWithholdingRate, setVatWithholdingRate] = useState(7);
  const [cstApplicable, setCstApplicable] = useState(false);
  const [tourismLevyApplicable, setTourismLevyApplicable] = useState(false);
  const [isVatRegistered, setIsVatRegistered] = useState(true);

  // Calculate live receivables / payables balances per partner
  const balances: Record<string, number> = {};
  salesInvoices.forEach((i) => {
    if (i.status === 'Open' || i.status === 'Partial') {
      const due = i.totalReceivable - i.paidAmount;
      balances[i.customerName] = (balances[i.customerName] || 0) + due;
    }
  });
  purchaseOrders.forEach((p) => {
    if (p.status === 'Invoiced') {
      balances[p.vendorName] = (balances[p.vendorName] || 0) + Math.max(0, p.totalAmount - (p.paidAmount || 0));
    }
  });

  const filtered = partners.filter((p) => {
    const matchType = filterType === 'ALL' || p.type === filterType;
    const matchSearch =
      p.code.toLowerCase().includes(search.toLowerCase()) ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.tin.toLowerCase().includes(search.toLowerCase());
    return matchType && matchSearch;
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;
    const newP: BusinessPartner = {
      id: String(Date.now()),
      code: code || `${type === 'Vendor' ? 'V' : 'C'}00${partners.length + 1}`,
      name: name.trim(),
      type,
      tin: tin.trim(),
      email: email.trim(),
      phone: phone.trim(),
      address: address.trim(),
      currency: currentClient.currency,
      isVatWithholdingAgent: vatWithholdingAgent,
      vatWithholdingRate: vatWithholdingAgent ? vatWithholdingRate : undefined,
      isCstApplicable: cstApplicable,
      isTourismLevyApplicable: tourismLevyApplicable,
      isVatRegistered,
    };
    onAddPartner(newP);
    setShowModal(false);
    setCode('');
    setName('');
    setTin('');
    setEmail('');
    setPhone('');
    setAddress('');
    setVatWithholdingAgent(false);
    setVatWithholdingRate(7);
    setCstApplicable(false);
    setTourismLevyApplicable(false);
  };

  const handleExportCsv = () => {
    let csv = `BPCode,PartnerName,Type,TIN,Email,Phone,Address,Currency,CurrentBalance\n`;
    partners.forEach((p) => {
      const bal = balances[p.name] || 0;
      csv += `"${p.code}","${p.name}","${p.type}","${p.tin}","${p.email}","${p.phone}","${p.address}","${p.currency}",${bal}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${currentClient.code}_Business_Partners.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`BP · Suppliers & Customers Master · ${currentClient.code}`}
        title="Business Partners Master Directory"
        desc="Centralized customer accounts receivable and vendor accounts payable directory with tax TINs, payment terms, and open ledger balances."
      >
        <div className="flex gap-2">
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-700" />
            <span>Export Partners (CSV)</span>
          </button>
          <button
            onClick={() => {
              setCode(`${type === 'Vendor' ? 'V' : 'C'}00${partners.length + 1}`);
              setShowModal(true);
            }}
            className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
          >
            <Plus className="h-4 w-4" />
            <span>Add Business Partner</span>
          </button>
        </div>
      </PageHeader>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-white p-3 rounded-xl border border-sky-200 shadow-xs">
        <div className="flex items-center gap-1">
          {(['ALL', 'Vendor', 'Customer'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1.5 rounded-lg font-bold transition ${
                filterType === t
                  ? 'bg-[#082f4f] text-white shadow-xs'
                  : 'bg-sky-50 text-[#355875] hover:bg-sky-100'
              }`}
            >
              {t === 'ALL' ? 'All Partners' : t === 'Vendor' ? 'Vendors / Suppliers' : 'Customers / Clients'}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-sky-400" />
          <input
            type="text"
            placeholder="Search partner, TIN, code..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-56 sm:w-64 rounded-lg border border-sky-300 bg-white pl-8 pr-3 py-1.5 text-xs text-[#082f4f] outline-none focus:border-[#082f4f]"
          />
        </div>
      </div>

      {/* Partners Table */}
      <Card title={`Registered Business Partners (${filtered.length})`} sub="Integrated across Procurement, Sales, and Payment Desks">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Partner Code</th>
                <th className={thCls}>Company / Trading Name</th>
                <th className={thCls}>Category</th>
                <th className={thCls}>Tax TIN</th>
                <th className={thCls}>Contact &amp; Location</th>
                <th className={thCls + " text-right"}>Open Balance (₵)</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => {
                const bal = balances[p.name] || 0;
                return (
                  <tr key={p.id} className={rowCls}>
                    <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{p.code}</td>
                    <td className="px-3 py-2 font-bold text-[#082f4f]">{p.name}</td>
                    <td className="px-3 py-2">
                      <span className={`rounded px-2 py-0.5 text-[10.5px] font-bold ${
                        p.type === 'Vendor'
                          ? 'bg-sky-100 text-[#006f98] border border-sky-300'
                          : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      }`}>
                        {p.type === 'Vendor' ? 'Supplier (AP)' : 'Customer (AR)'}
                      </span>
                    </td>
                    <td className="px-3 py-2 font-mono text-[11px] text-[#355875]">{p.tin || '—'}</td>
                    <td className="px-3 py-2 text-[#355875] text-[11px]">
                      <div>{p.phone || p.email || '—'}</div>
                      <div className="text-[10px] text-slate-400">{p.address}</div>
                    </td>
                    <td className={numCls + ` font-mono font-bold ${
                      p.type === 'Vendor' && bal > 0 ? 'text-rose-700' :
                      p.type === 'Customer' && bal > 0 ? 'text-emerald-700' : 'text-[#355875]'
                    }`}>
                      {bal > 0 ? formatGHS(bal) : '0.00'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* New Partner Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleCreate} className="w-full max-w-lg rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Add New Business Partner</h3>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Partner Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full rounded border border-sky-300 px-2 py-2 outline-none font-bold text-[#082f4f]"
                  >
                    <option value="Vendor">Vendor / Supplier (AP)</option>
                    <option value="Customer">Customer / Client (AR)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Partner Code</label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono font-bold text-[#082f4f]"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Legal Company / Business Name</label>
                <input
                  type="text"
                  placeholder="e.g. Takoradi Power Solutions Ltd"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Tax TIN Number</label>
                  <input
                    type="text"
                    placeholder="e.g. C001928381"
                    value={tin}
                    onChange={(e) => setTin(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono text-[#082f4f]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Contact Phone</label>
                  <input
                    type="text"
                    placeholder="+233 30 200 0000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none text-[#082f4f]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Billing Email</label>
                <input
                  type="email"
                  placeholder="accounts@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-2 outline-none text-[#082f4f]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Physical Address</label>
                <input
                  type="text"
                  placeholder="Street address, city, region"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-2 outline-none text-[#082f4f]"
                />
              </div>

              <div className="rounded-lg border border-sky-200 bg-sky-50 p-3 space-y-2">
                <span className="block font-bold text-[#082f4f] text-[11px] uppercase tracking-wider">Tax attributes</span>
                <label className="flex items-center gap-2 text-[#2d4f6d] font-semibold"><input type="checkbox" checked={isVatRegistered} onChange={(e) => setIsVatRegistered(e.target.checked)} /> VAT-registered (bills carry VAT)</label>
                <label className="flex items-center gap-2 text-[#2d4f6d] font-semibold"><input type="checkbox" checked={vatWithholdingAgent} onChange={(e) => setVatWithholdingAgent(e.target.checked)} /> Appointed VAT withholding agent</label>
                {vatWithholdingAgent && <label className="block text-[#2d4f6d] font-semibold">VAT WHT rate %<input type="number" min="0" max="100" step="0.01" value={vatWithholdingRate} onChange={(e) => setVatWithholdingRate(Number(e.target.value))} className="ml-2 w-20 rounded border border-sky-300 px-2 py-1 font-mono" /></label>}
                <label className="flex items-center gap-2 text-[#2d4f6d] font-semibold"><input type="checkbox" checked={cstApplicable} onChange={(e) => setCstApplicable(e.target.checked)} /> CST applicable (Class 1 communications provider only)</label>
                <label className="flex items-center gap-2 text-[#2d4f6d] font-semibold"><input type="checkbox" checked={tourismLevyApplicable} onChange={(e) => setTourismLevyApplicable(e.target.checked)} /> Tourism levy applicable</label>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setShowModal(false)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 font-bold text-white">Save Partner</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
