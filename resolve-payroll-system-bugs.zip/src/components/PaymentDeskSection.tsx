import { useMemo, useState } from 'react';
import type { ACDOCALine, BankAccount, ClientEntity, PurchaseOrder, SalesInvoice, UserAccount } from '../types/accounting';
import { Card, PageHeader, StatusBadge, formatGHS, numCls, rowCls, thCls } from './ui';
import { Printer, X, Landmark, ReceiptText, BanknoteArrowDown } from 'lucide-react';
import { taxConfigStore } from '../utils/taxConfig';
import { ageIntoBuckets } from '../utils/reports';
import { deriveExpenseBills, type ExpenseBill, type StatutoryPayableRow, type PaymentResult } from '../utils/payables';
import { StatutoryPayablesCard } from './StatutoryPayables';
import type { PaymentMethod } from '../utils/treasury';

type Method = PaymentMethod;
type WhtCode =
  | 'none'
  | 'goods_resident' | 'services_resident' | 'works_resident' | 'professional_resident'
  | 'petroleum_subcontractor_resident' | 'precious_minerals_unprocessed' | 'realisation_assets_resident'
  | 'dividend_resident' | 'interest_resident' | 'rent_residential' | 'rent_commercial'
  | 'royalty_natural_resource' | 'director_manager_fees' | 'agent_commission' | 'examiner_teacher_endorsement'
  | 'non_resident' | 'nonres_mgmt_technical' | 'nonres_royalty_rent' | 'nonres_telecom_transport'
  | 'nonres_petroleum_subcontractor' | 'nonres_insurance_premium' | 'nonres_branch_repatriation'
  | 'nonres_interest' | 'nonres_dividend' | 'nonres_realisation';

// Full GRA withholding tax schedule (Income Tax Act 2015 (Act 896), First Schedule,
// as amended — resident and non-resident categories), effective-dated via tax settings.
const whtOptions = () => {
  const rate = (code: string, fallback: number) => taxConfigStore.rate(code) || fallback;
  return [
    { code: 'none' as WhtCode, label: 'No income withholding', rate: 0, note: 'Use only where an exemption or non-withholding treatment has been confirmed.' },
    { code: 'goods_resident' as WhtCode, label: 'Resident supply of goods', rate: rate('WHT_GOODS', 3), note: 'Income WHT on consideration exclusive of VAT and levies.' },
    { code: 'works_resident' as WhtCode, label: 'Resident supply of works', rate: rate('WHT_WORKS', 5), note: 'Construction, installation or works contracts.' },
    { code: 'services_resident' as WhtCode, label: 'Resident supply of services', rate: rate('WHT_SERVICES', 7.5), note: 'Income WHT on consideration exclusive of VAT and levies.' },
    { code: 'professional_resident' as WhtCode, label: 'Resident professional / technical fee (services)', rate: rate('WHT_PROFESSIONAL', 7.5), note: 'Resident professional services are taxed as services (7.5%); confirm supplier classification before payment.' },
    { code: 'petroleum_subcontractor_resident' as WhtCode, label: 'Petroleum subcontractors (resident)', rate: rate('WHT_PETROLEUM_SUB', 7.5), note: 'Separate GRA category for petroleum subcontractor payments.' },
    { code: 'precious_minerals_unprocessed' as WhtCode, label: 'Unprocessed precious minerals', rate: rate('WHT_PRECIOUS_MINERALS', 3), note: 'Minerals Commission practice note rate.' },
    { code: 'realisation_assets_resident' as WhtCode, label: 'Realisation of assets & liabilities (resident)', rate: rate('WHT_REALISATION', 3), note: 'Consideration for the realisation of assets and liabilities.' },
    { code: 'dividend_resident' as WhtCode, label: 'Dividends (resident)', rate: rate('WHT_DIVIDEND', 8), note: 'Final withholding tax.' },
    { code: 'interest_resident' as WhtCode, label: 'Interest (excl. individuals & resident FIs)', rate: rate('WHT_INTEREST', 8), note: 'On-account WHT for corporate recipients.' },
    { code: 'rent_residential' as WhtCode, label: 'Rent — residential property', rate: rate('WHT_RENT_RESIDENTIAL', 8), note: 'Final withholding tax on residential rent.' },
    { code: 'rent_commercial' as WhtCode, label: 'Rent — non-residential (commercial)', rate: rate('WHT_RENT_COMMERCIAL', 15), note: 'Final withholding tax on commercial rent.' },
    { code: 'royalty_natural_resource' as WhtCode, label: 'Royalties & natural resource payments', rate: rate('WHT_ROYALTY', 15), note: 'Includes mineral royalties paid to residents.' },
    { code: 'director_manager_fees' as WhtCode, label: 'Directors / managers / board fees (individuals)', rate: rate('WHT_DIRECTOR_FEES', 20), note: 'Fees or allowances to resident individuals in these roles.' },
    { code: 'agent_commission' as WhtCode, label: 'Insurance / sales / lotto agent commissions', rate: rate('WHT_AGENT_COMMISSION', 10), note: 'Specific agent category instead of general services.' },
    { code: 'examiner_teacher_endorsement' as WhtCode, label: 'Examiners / teachers / endorsement fees (final)', rate: rate('WHT_EXAMINER_TEACHER', 10), note: 'Final withholding tax.' },
    { code: 'non_resident' as WhtCode, label: 'Non-resident goods, works or services', rate: rate('WHT_NON_RESIDENT', 20), note: 'Subject to applicable treaty relief and contract facts.' },
    { code: 'nonres_mgmt_technical' as WhtCode, label: 'Non-resident management / consulting / technical fees', rate: rate('WHT_NONRES_MGMT_TECH', 20), note: 'Final tax; treaty relief may apply.' },
    { code: 'nonres_royalty_rent' as WhtCode, label: 'Non-resident royalties, natural resources & rents', rate: rate('WHT_NONRES_ROYALTY_RENT', 15), note: 'Final tax; treaty relief may apply.' },
    { code: 'nonres_telecom_transport' as WhtCode, label: 'Non-resident telecom / shipping / air transport', rate: rate('WHT_NONRES_TELECOM_TRANSPORT', 15), note: 'Final tax.' },
    { code: 'nonres_petroleum_subcontractor' as WhtCode, label: 'Non-resident petroleum subcontractors', rate: rate('WHT_NONRES_PETROLEUM_SUB', 15), note: 'Final tax.' },
    { code: 'nonres_insurance_premium' as WhtCode, label: 'Non-resident general insurance premiums', rate: rate('WHT_NONRES_INSURANCE', 5), note: 'Final tax.' },
    { code: 'nonres_branch_repatriation' as WhtCode, label: 'Repatriated branch after-tax profits', rate: rate('WHT_NONRES_BRANCH', 8), note: 'Final tax.' },
    { code: 'nonres_interest' as WhtCode, label: 'Non-resident interest income', rate: rate('WHT_NONRES_INTEREST', 8), note: 'Final tax; treaty relief may apply.' },
    { code: 'nonres_dividend' as WhtCode, label: 'Non-resident dividends', rate: rate('WHT_NONRES_DIVIDEND', 8), note: 'Final tax; treaty relief may apply.' },
    { code: 'nonres_realisation' as WhtCode, label: 'Non-resident realisation of assets & liabilities', rate: rate('WHT_NONRES_REALISATION', 10), note: 'Final tax.' },
  ];
};

type Target =
  | { type: 'supplier'; po: PurchaseOrder }
  | { type: 'customer'; invoice: SalesInvoice }
  | { type: 'expense'; bill: ExpenseBill }
  | { type: 'statutory'; row: StatutoryPayableRow };

interface PaymentDeskSectionProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  purchaseOrders: PurchaseOrder[];
  salesInvoices: SalesInvoice[];
  bankAccounts: BankAccount[];
  lines: ACDOCALine[];
  isPeriodClosed?: boolean;
  onSettleSupplierInvoice: (input: {
    po: PurchaseOrder; grossAmount: number; whtRate: number; vatWithheld: number; bankId: number; method: Method; reference: string;
  }) => PaymentResult;
  onReceiveCustomerPayment: (input: {
    invoice: SalesInvoice; amount: number; bankId: number; method: Method; reference: string;
  }) => PaymentResult;
  onDisburseSalaries?: (period: string, amount: number, bankId: number, method: Method) => PaymentResult;
  onSettleExpenseBill: (input: {
    bill: ExpenseBill; grossAmount: number; whtRate: number; bankId: number; method: Method; reference: string;
  }) => PaymentResult;
  onRemitStatutory: (input: {
    row: StatutoryPayableRow; amount: number; bankId: number; method: Method; reference: string;
  }) => PaymentResult;
  onApprovalSubmitted?: () => void;
}

export const PaymentDeskSection = ({
  currentClient,
  currentUser,
  purchaseOrders,
  salesInvoices,
  bankAccounts,
  lines,
  isPeriodClosed = false,
  onSettleSupplierInvoice,
  onReceiveCustomerPayment,
  onDisburseSalaries,
  onSettleExpenseBill,
  onRemitStatutory,
  onApprovalSubmitted,
}: PaymentDeskSectionProps) => {
  const [bankId, setBankId] = useState<number>(bankAccounts[0]?.id ?? 0);
  const [method, setMethod] = useState<Method>('bank_transfer');
  const [target, setTarget] = useState<Target | null>(null);
  const [amount, setAmount] = useState(0);
  const [whtCode, setWhtCode] = useState<WhtCode>('none');
  const [vatWithholdingAgent, setVatWithholdingAgent] = useState(false);
  const [reference, setReference] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [voucher, setVoucher] = useState<{ payee: string; docRef: string; gross: number; incomeWht: number; vatWht: number; cash: number; bank: BankAccount; method: Method; reference: string; payableAccount: string } | null>(null);

  const restricted = currentUser.status === 'restricted' || currentUser.status === 'suspended' || currentUser.permissions?.canApprovePayments === false;
  const activeBank = bankAccounts.find((b) => b.id === bankId);
  const openBills = purchaseOrders.filter((p) => p.status === 'Invoiced');
  const openInvoices = salesInvoices.filter((i) => i.status === 'Open' || i.status === 'Partial');
  const paidBills = purchaseOrders.filter((p) => p.status === 'Paid');
  const salariesPayable = lines.filter((l) => l.clientId === currentClient.id && l.accountNo === '205000').reduce((sum, l) => sum + l.credit - l.debit, 0);
  const expenseBills = useMemo(() => deriveExpenseBills(lines, currentClient.id), [lines, currentClient.id]);
  const openExpenseBills = expenseBills.filter((b) => b.status === 'Awaiting payment' || b.status === 'Partially paid');
  const settledExpenseBills = expenseBills.filter((b) => b.status === 'Paid');
  const expenseOutstandingTotal = openExpenseBills.reduce((s, b) => s + b.outstanding, 0);

  const openSupplier = (po: PurchaseOrder) => {
    setTarget({ type: 'supplier', po });
    setAmount(Math.max(0, po.totalAmount - (po.paidAmount || 0)));
    setWhtCode(po.itemType === 'material' ? 'goods_resident' : 'services_resident');
    setVatWithholdingAgent(false);
    setReference(`PAY-${po.poNo.replace('PO-', '')}`);
    setFeedback(null);
  };

  const openCustomer = (invoice: SalesInvoice) => {
    setTarget({ type: 'customer', invoice });
    setAmount(Math.max(0, invoice.totalReceivable - invoice.paidAmount));
    setReference(`REC-${invoice.invNo.replace('INV-', '')}`);
    setFeedback(null);
  };

  const openExpense = (bill: ExpenseBill) => {
    setTarget({ type: 'expense', bill });
    setAmount(bill.outstanding);
    setWhtCode('none');
    setVatWithholdingAgent(false);
    setReference(`PAY-${bill.billNo.replace('EXPB-', '')}`);
    setFeedback(null);
  };

  const openStatutory = (row: StatutoryPayableRow) => {
    setTarget({ type: 'statutory', row });
    setAmount(Math.max(0, row.balance));
    setReference(`STAT-${row.accountNo}-${new Date().toISOString().slice(0, 7)}`);
    setFeedback(null);
  };

  const outstanding = target?.type === 'supplier'
    ? Math.max(0, target.po.totalAmount - (target.po.paidAmount || 0))
    : target?.type === 'customer'
      ? Math.max(0, target.invoice.totalReceivable - target.invoice.paidAmount)
      : target?.type === 'expense'
        ? target.bill.outstanding
        : target?.type === 'statutory'
          ? Math.max(0, target.row.balance)
          : 0;
  const currentWhtOptions = whtOptions();
  const selectedWht = currentWhtOptions.find((w) => w.code === whtCode) || currentWhtOptions[0];

  // WHT is always computed on the consideration exclusive of VAT and levies.
  const supplierTaxBase = target?.type === 'supplier' && target.po.totalAmount > 0
    ? amount * (((target.po.netAmount ?? target.po.qty * target.po.unitPrice) / target.po.totalAmount))
    : target?.type === 'expense' && target.bill.gross > 0
      ? amount * ((target.bill.gross - target.bill.vat) / target.bill.gross)
      : 0;
  const incomeWht = target?.type === 'supplier' || target?.type === 'expense' ? Math.round(supplierTaxBase * selectedWht.rate) / 100 : 0;
  // GRA VAT withholding: appointed agents withhold 7% of the standard-rated taxable value at payment.
  const vatWht = target?.type === 'supplier' && vatWithholdingAgent ? Math.round(supplierTaxBase * taxConfigStore.rate('VAT_WHT')) / 100 : 0;
  const isOutflow = target?.type !== 'customer';
  const netDisbursement = Math.max(0, amount - incomeWht - vatWht);

  // Sector levy profile: telecom/communications entities bill CST (5%, cascades into the
  // VAT base per VAT Act 2025 s.15.3); hospitality entities bill the 1% Tourism Levy.
  const sectorText = currentClient.sector.toLowerCase();
  const cstSector = sectorText.includes('telecom') || sectorText.includes('communication') || sectorText.includes('software') || sectorText.includes('information technology') || sectorText.includes('tower') || sectorText.includes('isp');
  const tourismSector = sectorText.includes('hotel') || sectorText.includes('tourism') || sectorText.includes('resort') || sectorText.includes('restaurant') || sectorText.includes('hospitality') || sectorText.includes('event');
  const cstRate = taxConfigStore.rate('CST');
  const tourismRate = taxConfigStore.rate('TOURISM_LEVY');

  // AR / AP aging over open items (30-day credit terms assumed).
  const asOf = new Date().toISOString().slice(0, 10);
  const apAging = ageIntoBuckets(asOf, [
    ...purchaseOrders.filter((p) => p.status !== 'Paid').map((p) => ({ date: p.date, amount: Math.max(0, p.totalAmount - (p.paidAmount || 0)) })),
    ...openExpenseBills.map((b) => ({ date: b.date, amount: b.outstanding })),
  ]);
  const arAging = ageIntoBuckets(asOf, salesInvoices
    .filter((i) => i.status === 'Open' || i.status === 'Partial')
    .map((i) => ({ date: i.date, amount: Math.max(0, i.totalReceivable - i.paidAmount) })));

  const handleResult = (result: PaymentResult, successMsg: string, queuedMsg: string) => {
    if (result === 'queued') {
      if (onApprovalSubmitted) onApprovalSubmitted();
      setFeedback(queuedMsg);
      setTarget(null);
      return;
    }
    if (result === 'failed') {
      setFeedback('The entry was rejected. Check the period lock, duplicate document number, outstanding balance or treasury funds.');
      return;
    }
    setFeedback(successMsg);
    setTarget(null);
  };

  const submit = () => {
    if (!target) return;
    if (restricted) return setFeedback('Payment is blocked: this user has no payment authority.');
    if (isPeriodClosed) return setFeedback('Payment is blocked: the accounting period is closed.');
    if (!activeBank) return setFeedback('Select a bank or cash account before recording payment.');
    if (!Number.isFinite(amount) || amount <= 0 || amount > outstanding + 0.009) return setFeedback(`Enter an amount between 0.01 and ${formatGHS(outstanding)}.`);
    if (isOutflow && method === 'bank_transfer' && activeBank.balance + 0.009 < netDisbursement) return setFeedback(`Insufficient recorded bank balance for a net disbursement of ${formatGHS(netDisbursement)}.`);

    if (target.type === 'supplier') {
      const result = onSettleSupplierInvoice({ po: target.po, grossAmount: amount, whtRate: selectedWht.rate, vatWithheld: vatWht, bankId, method, reference });
      if (result === 'posted') setVoucher({ payee: target.po.vendorName, docRef: target.po.poNo, gross: amount, incomeWht, vatWht, cash: netDisbursement, bank: activeBank, method, reference: reference || `PAY-${target.po.poNo}`, payableAccount: '200000 Trade payables' });
      handleResult(result, `Supplier payment posted successfully — ${target.po.vendorName} settled ${formatGHS(amount)}.`, `Payment queued for approval: it exceeds your maker limit of ${formatGHS(currentUser.makerLimit)}. The payment is effected when an independent checker approves it.`);
      return;
    }
    if (target.type === 'customer') {
      const result = onReceiveCustomerPayment({ invoice: target.invoice, amount, bankId, method, reference });
      handleResult(result, 'Customer receipt posted successfully.', `Receipt queued for approval: it exceeds your maker limit of ${formatGHS(currentUser.makerLimit)}.`);
      return;
    }
    if (target.type === 'expense') {
      const result = onSettleExpenseBill({ bill: target.bill, grossAmount: amount, whtRate: selectedWht.rate, bankId, method, reference });
      if (result === 'posted') setVoucher({ payee: target.bill.payee, docRef: target.bill.billNo, gross: amount, incomeWht, vatWht: 0, cash: netDisbursement, bank: activeBank, method, reference: reference || `PAY-${target.bill.billNo}`, payableAccount: '202000 Accrued expenses & other payables' });
      handleResult(result, `Expense bill ${target.bill.billNo} paid — payable cleared ${formatGHS(amount)} to ${target.bill.payee}.`, `Payment queued for approval: it exceeds your maker limit of ${formatGHS(currentUser.makerLimit)}. The bill stays payable until an independent checker approves.`);
      return;
    }
    const result = onRemitStatutory({ row: target.row, amount, bankId, method, reference });
    if (result === 'posted') setVoucher({ payee: target.row.authority, docRef: `${target.row.label} (GL ${target.row.accountNo})`, gross: amount, incomeWht: 0, vatWht: 0, cash: amount, bank: activeBank, method, reference: reference || `STAT-${target.row.accountNo}`, payableAccount: `${target.row.accountNo} ${target.row.label}` });
    handleResult(result, `Statutory remittance posted: ${target.row.label} — ${formatGHS(amount)} to ${target.row.authority}.`, `Remittance queued for approval: it exceeds your maker limit of ${formatGHS(currentUser.makerLimit)}. It is effected on independent approval.`);
  };

  const paySalary = () => {
    if (!onDisburseSalaries || salariesPayable <= 0 || restricted || isPeriodClosed || !activeBank) return;
    const result = onDisburseSalaries(new Date().toISOString().slice(0, 7), salariesPayable, bankId, method);
    handleResult(result, `Net payroll of ${formatGHS(salariesPayable)} released to staff.`, `Payroll release queued for approval: it exceeds your maker limit of ${formatGHS(currentUser.makerLimit)}.`);
  };

  const targetTitle = target?.type === 'supplier' ? 'Supplier settlement'
    : target?.type === 'customer' ? 'Customer receipt'
      : target?.type === 'expense' ? `Expense bill payment — ${target.bill.payee}`
        : target?.type === 'statutory' ? `Statutory remittance — ${target.row.label}`
          : '';

  return <div className="space-y-6">
    <PageHeader kicker={`PMT · Treasury & Settlements · ${currentClient.code}`} title="Payment Desk" desc="The single point where money moves: supplier settlements, expense-bill payments, statutory remittances (PAYE, SSNIT Tier 1 & 2, WHT, VAT), customer receipts and payroll release." />
    {feedback && <div className={`rounded-lg border p-3 text-xs font-bold ${feedback.includes('blocked') || feedback.includes('Enter') || feedback.includes('Insufficient') || feedback.includes('rejected') ? 'border-rose-300 bg-rose-50 text-rose-900' : feedback.includes('queued') ? 'border-amber-300 bg-amber-50 text-amber-900' : 'border-emerald-300 bg-emerald-50 text-emerald-900'}`}>{feedback}</div>}
    {isPeriodClosed && <div className="rounded-lg border border-rose-300 bg-rose-50 p-3 text-xs font-bold text-rose-900">The current accounting period is closed — all payments are frozen until it is reopened at Month-End Close.</div>}

    {(cstSector || tourismSector) && (
      <div className="rounded-xl border border-sky-200 bg-sky-50 p-4 text-xs text-[#2d4f6d] flex flex-wrap gap-x-6 gap-y-1">
        <strong className="text-[#082f4f]">Sector levy profile — {currentClient.sector}:</strong>
        {cstSector && <span>Communication Service Tax (CST) {cstRate}% applies to electronic communications billings by GRA-notified Class 1 providers; CST is added to the taxable value before VAT/NHIL/GETFund (VAT Act 2025 s.15.3).</span>}
        {tourismSector && <span>Tourism Development Levy {tourismRate}% applies to hospitality accommodation billings (Tourism Act 817).</span>}
        <span>Levies are optional when creating a billing; income WHT and VAT withholding at this desk are always computed on the consideration exclusive of VAT and levies.</span>
      </div>
    )}

    <div className="rounded-xl border border-sky-200 bg-white p-4 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
      <label className="font-bold text-[#355875]">Disbursement account
        <select value={bankId} onChange={(e) => setBankId(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 bg-white px-2.5 py-2 font-bold text-[#082f4f] outline-none">
          {bankAccounts.map((b) => <option key={b.id} value={b.id}>{b.name} · {b.currency} {formatGHS(b.balance)}</option>)}
        </select>
      </label>
      <label className="font-bold text-[#355875]">Payment method
        <select value={method} onChange={(e) => setMethod(e.target.value as Method)} className="mt-1 w-full rounded border border-sky-300 bg-white px-2.5 py-2 font-bold text-[#082f4f] outline-none">
          <option value="bank_transfer">Bank transfer</option><option value="cash">Cash</option><option value="mobile_money">Mobile money</option><option value="cheque">Cheque</option>
        </select>
      </label>
      <div className="rounded bg-sky-50 border border-sky-200 px-3 py-2"><span className="block text-[10px] uppercase tracking-wider font-bold text-[#355875]">Operator</span><strong className="text-[#082f4f]">{currentUser.name}</strong>{currentUser.makerLimit > 0 && <span className="block text-[10px] text-[#355875]">Maker limit: {formatGHS(currentUser.makerLimit)} — larger payments queue for approval</span>}</div>
    </div>

    {salariesPayable > 0 && <div className="rounded-xl border border-amber-300 bg-amber-50 p-4 flex flex-wrap justify-between items-center gap-3 text-xs"><div className="flex items-start gap-2"><BanknoteArrowDown className="h-5 w-5 text-[#855b00] shrink-0" /><div><strong className="block text-[#855b00]">Net payroll payable: {formatGHS(salariesPayable)}</strong><span className="text-[#2d4f6d]">Account 205000 will be debited on release. PAYE and SSNIT Tier 1/Tier 2 are remitted separately below.</span></div></div><button onClick={paySalary} disabled={restricted || isPeriodClosed} className="rounded bg-emerald-700 text-white px-4 py-2 font-bold transition hover:bg-emerald-800 disabled:opacity-40">Release payroll</button></div>}

    <StatutoryPayablesCard
      lines={lines}
      clientId={currentClient.id}
      currency={currentClient.currency}
      onAction={openStatutory}
      actionLabel="Remit"
      disabled={restricted || isPeriodClosed}
      excludeSalaries
    />

    <Card
      title="Expense bills awaiting payment"
      sub={`Recorded at the Expenses & Statutory desk · ${openExpenseBills.length} open · ${currentClient.currency} ${formatGHS(expenseOutstandingTotal)} outstanding`}
    >
      <div className="overflow-x-auto"><table className="w-full min-w-[820px] text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Bill</th><th className={thCls}>Payee</th><th className={thCls}>Expense GL</th><th className={thCls}>Recorded</th><th className={thCls + ' text-right'}>Gross</th><th className={thCls + ' text-right'}>Paid</th><th className={thCls + ' text-right'}>Outstanding</th><th className={thCls + ' text-center'}>Action</th></tr></thead><tbody>
        {openExpenseBills.length ? openExpenseBills.map((b) => (
          <tr key={b.billNo} className={rowCls}>
            <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{b.billNo}</td>
            <td className="px-3 py-2 font-bold text-[#082f4f]">{b.payee}<span className="block text-[10px] font-normal text-[#355875]">{b.description}</span></td>
            <td className="px-3 py-2 font-mono">{b.expenseAccountNo}</td>
            <td className="px-3 py-2 font-mono">{b.date}</td>
            <td className={numCls}>{formatGHS(b.gross)}</td>
            <td className={numCls}>{formatGHS(b.paid)}</td>
            <td className={numCls + ' font-bold text-rose-700'}>{formatGHS(b.outstanding)}</td>
            <td className="px-3 py-2 text-center"><button onClick={() => openExpense(b)} disabled={restricted || isPeriodClosed} className="inline-flex items-center gap-1 rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white transition hover:bg-[#0c3f68] disabled:opacity-30"><ReceiptText className="h-3 w-3" /> Pay</button></td>
          </tr>
        )) : <tr><td colSpan={8} className="p-6 text-center text-[#355875]">No expense bills awaiting payment. Bills recorded at the Expenses & Statutory desk appear here automatically.</td></tr>}
      </tbody></table></div>
      {settledExpenseBills.length > 0 && <details className="mt-3 text-xs"><summary className="cursor-pointer font-bold text-[#355875] hover:text-[#082f4f]">Settled expense bills ({settledExpenseBills.length})</summary>
        <div className="mt-2 overflow-x-auto"><table className="w-full text-xs"><thead><tr className="border-b border-sky-200"><th className={thCls}>Bill</th><th className={thCls}>Payee</th><th className={thCls + ' text-right'}>Gross</th><th className={thCls}>Status</th></tr></thead><tbody>
          {settledExpenseBills.map((b) => <tr key={b.billNo} className={rowCls}><td className="px-3 py-2 font-mono">{b.billNo}</td><td className="px-3 py-2">{b.payee}</td><td className={numCls}>{formatGHS(b.gross)}</td><td className="px-3 py-2"><StatusBadge status={b.status} /></td></tr>)}
        </tbody></table></div>
      </details>}
    </Card>

    <div className="grid gap-6 xl:grid-cols-2">
      <Card title="Supplier invoices awaiting payment" sub="Partial and full settlement supported">
        <div className="overflow-x-auto"><table className="w-full min-w-[680px] text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Bill</th><th className={thCls}>Vendor</th><th className={thCls}>Type</th><th className={thCls}>CCY</th><th className={thCls + ' text-right'}>Gross</th><th className={thCls + ' text-right'}>Paid</th><th className={thCls + ' text-right'}>Outstanding</th><th className={thCls + ' text-center'}>Action</th></tr></thead><tbody>{openBills.length ? openBills.map(po => { const paid = po.paidAmount || 0; const due = po.totalAmount - paid; const ccy = po.currency || currentClient.currency; return <tr key={po.id} className={rowCls}><td className="px-3 py-2 font-mono font-bold text-[#855b00]">{po.poNo}</td><td className="px-3 py-2 font-bold text-[#082f4f]">{po.vendorName}</td><td className="px-3 py-2">{po.itemType}</td><td className="px-3 py-2 font-mono font-bold text-[#006f98]">{ccy}</td><td className={numCls}>{formatGHS(po.totalAmount)}</td><td className={numCls}>{formatGHS(paid)}</td><td className={numCls + ' font-bold text-rose-700'}>{formatGHS(due)}</td><td className="px-3 py-2 text-center"><button onClick={() => openSupplier(po)} className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white transition hover:bg-[#0c3f68]">Pay</button></td></tr>; }) : <tr><td colSpan={8} className="p-6 text-center text-[#355875]">No supplier invoices awaiting payment.</td></tr>}</tbody></table></div>
      </Card>
      <Card title="Customer invoices awaiting receipt" sub="Partial and full customer receipt supported">
        <div className="overflow-x-auto"><table className="w-full min-w-[680px] text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Invoice</th><th className={thCls}>Customer</th><th className={thCls + ' text-right'}>Gross</th><th className={thCls + ' text-right'}>Paid</th><th className={thCls + ' text-right'}>Outstanding</th><th className={thCls + ' text-center'}>Action</th></tr></thead><tbody>{openInvoices.length ? openInvoices.map(inv => { const due = inv.totalReceivable - inv.paidAmount; return <tr key={inv.id} className={rowCls}><td className="px-3 py-2 font-mono font-bold text-[#855b00]">{inv.invNo}</td><td className="px-3 py-2 font-bold text-[#082f4f]">{inv.customerName}</td><td className={numCls}>{formatGHS(inv.totalReceivable)}</td><td className={numCls}>{formatGHS(inv.paidAmount)}</td><td className={numCls + ' font-bold text-emerald-800'}>{formatGHS(due)}</td><td className="px-3 py-2 text-center"><button onClick={() => openCustomer(inv)} className="rounded bg-emerald-700 px-2.5 py-1 text-[11px] font-bold text-white transition hover:bg-emerald-800">Receive</button></td></tr>; }) : <tr><td colSpan={6} className="p-6 text-center text-[#355875]">No customer invoices awaiting receipt.</td></tr>}</tbody></table></div>
      </Card>
    </div>

    <div className="grid gap-6 xl:grid-cols-2">
      <Card title="Payables aging (AP)" sub={`Open supplier & expense balances as at ${asOf} · 30-day terms`}>
        <table className="w-full text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Bucket</th><th className={thCls + ' text-right'}>Amount</th></tr></thead><tbody>
          <tr className={rowCls}><td className="p-2">Current (0-30 days)</td><td className={numCls}>{formatGHS(apAging.current)}</td></tr>
          <tr className={rowCls}><td className="p-2">31-60 days</td><td className={numCls}>{formatGHS(apAging.days31to60)}</td></tr>
          <tr className={rowCls}><td className="p-2">61-90 days</td><td className={numCls}>{formatGHS(apAging.days61to90)}</td></tr>
          <tr className={rowCls}><td className="p-2">Over 90 days</td><td className={numCls + ' text-rose-700 font-bold'}>{formatGHS(apAging.over90)}</td></tr>
          <tr className="bg-sky-100 font-bold"><td className="p-2">Total outstanding</td><td className={numCls}>{formatGHS(apAging.total)}</td></tr>
        </tbody></table>
        <p className="mt-2 text-[11px] text-[#2d4f6d]">{apAging.overdueCount} payable(s) beyond terms. Statutory dues (PAYE 15th, SSNIT/Tier 2 14th) attract penalties — escalate before releasing further payments.</p>
      </Card>
      <Card title="Receivables aging (AR)" sub={`Open customer balances as at ${asOf} · 30-day terms`}>
        <table className="w-full text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Bucket</th><th className={thCls + ' text-right'}>Amount</th></tr></thead><tbody>
          <tr className={rowCls}><td className="p-2">Current (0-30 days)</td><td className={numCls}>{formatGHS(arAging.current)}</td></tr>
          <tr className={rowCls}><td className="p-2">31-60 days</td><td className={numCls}>{formatGHS(arAging.days31to60)}</td></tr>
          <tr className={rowCls}><td className="p-2">61-90 days</td><td className={numCls}>{formatGHS(arAging.days61to90)}</td></tr>
          <tr className={rowCls}><td className="p-2">Over 90 days</td><td className={numCls + ' text-rose-700 font-bold'}>{formatGHS(arAging.over90)}</td></tr>
          <tr className="bg-sky-100 font-bold"><td className="p-2">Total outstanding</td><td className={numCls}>{formatGHS(arAging.total)}</td></tr>
        </tbody></table>
        <p className="mt-2 text-[11px] text-[#2d4f6d]">{arAging.overdueCount} customer invoice(s) beyond terms. Chase before the ECL allowance is reassessed.</p>
      </Card>
    </div>

    {paidBills.length > 0 && <Card title="Settled supplier payments" sub="Payment vouchers are generated from the selected settlement"><div className="overflow-x-auto"><table className="w-full text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Reference</th><th className={thCls}>Supplier</th><th className={thCls + ' text-right'}>Invoice value</th><th className={thCls}>Status</th></tr></thead><tbody>{paidBills.map(po => <tr key={po.id} className={rowCls}><td className="px-3 py-2 font-mono">{po.poNo}</td><td className="px-3 py-2">{po.vendorName}</td><td className={numCls}>{formatGHS(po.totalAmount)}</td><td className="px-3 py-2"><StatusBadge status={po.status} /></td></tr>)}</tbody></table></div></Card>}

    {target && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-xl bg-white p-6 shadow-xl space-y-4 text-xs">
        <div className="flex justify-between border-b border-sky-100 pb-2">
          <h3 className="font-bold text-[#082f4f] flex items-center gap-1.5">{target.type === 'statutory' && <Landmark className="h-4 w-4 text-[#855b00]" />}{targetTitle}</h3>
          <button onClick={() => setTarget(null)}><X className="h-4 w-4" /></button>
        </div>
        <div className="text-[#2d4f6d]">Outstanding amount: <strong>{formatGHS(outstanding)}</strong> <span className="font-mono font-bold text-[#006f98]">{target.type === 'supplier' ? (target.po.currency || currentClient.currency) : currentClient.currency}</span></div>

        {target.type === 'expense' && <div className="rounded bg-sky-50 border border-sky-200 p-3 text-[#2d4f6d]">Bill <strong className="font-mono">{target.bill.billNo}</strong> recorded {target.bill.date} · expense GL {target.bill.expenseAccountNo} {target.bill.expenseAccountName}. Payment debits 202000 Accrued Expenses & Other Payables and credits the selected treasury account.</div>}
        {target.type === 'statutory' && <div className="rounded bg-amber-50 border border-amber-200 p-3 text-[#2d4f6d]"><strong className="text-[#855b00]">{target.row.label}</strong> · GL {target.row.accountNo}<br />Remit to: <strong>{target.row.authority}</strong><br />Statutory deadline: <strong>{target.row.due}</strong><br /><span className="text-[10px]">{target.row.source}. Partial remittances are supported; the balance stays payable.</span></div>}
        {target.type === 'customer' && (target.invoice.cstAmount || target.invoice.tourismLevyAmount) ? <div className="rounded bg-sky-50 border border-sky-200 p-3 text-[#2d4f6d]">Gross receipt includes sector levies: {target.invoice.cstAmount ? `CST ${formatGHS(target.invoice.cstAmount)}` : ''}{target.invoice.cstAmount && target.invoice.tourismLevyAmount ? ' · ' : ''}{target.invoice.tourismLevyAmount ? `Tourism levy ${formatGHS(target.invoice.tourismLevyAmount)}` : ''} — settled within the customer receipt; liabilities sit in accounts 223000 / 224000.</div> : null}
        {target.type === 'customer' && (target.invoice.vatWithheldByCustomer || 0) > 0 ? <div className="rounded bg-amber-50 border border-amber-200 p-3 text-[#2d4f6d]"><strong>VAT withholding at source:</strong> {target.invoice.customerName} is an appointed withholding agent — {formatGHS(target.invoice.vatWithheldByCustomer || 0)} (7% of taxable value) is withheld and settles the receivable via WHT receivable (115000). Enter the cash actually received; the desk prorates the withholding across partial receipts.</div> : null}

        <label className="block font-bold text-[#355875]">Amount to record<input type="number" min="0.01" max={outstanding} step="0.01" value={amount} onChange={e => setAmount(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" /></label>
        <label className="block font-bold text-[#355875]">Payment reference<input value={reference} onChange={e => setReference(e.target.value)} placeholder="Document reference" className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" /></label>

        {(target.type === 'supplier' || target.type === 'expense') && <>
          <label className="block font-bold text-[#355875]">Income WHT treatment<select value={whtCode} onChange={e => setWhtCode(e.target.value as WhtCode)} className="mt-1 w-full rounded border border-sky-300 p-2">{currentWhtOptions.map(w => <option key={w.code} value={w.code}>{w.label} · {w.rate}%</option>)}</select></label>
          {target.type === 'supplier' && <label className="flex items-start gap-2 text-[#355875]"><input type="checkbox" checked={vatWithholdingAgent} onChange={e => setVatWithholdingAgent(e.target.checked)} className="mt-1" /><span><strong>Paying company is an appointed VAT withholding agent</strong><br />Withhold 7% of taxable value and issue VAT withholding credit certificate.</span></label>}
          <div className="rounded bg-sky-50 border border-sky-200 p-3 space-y-1">
            <div>Consideration excl. VAT: <strong>{formatGHS(supplierTaxBase)}</strong></div>
            <div>Income WHT ({selectedWht.rate}%): <strong className="text-rose-700">({formatGHS(incomeWht)})</strong></div>
            {target.type === 'supplier' && <div>VAT withholding (7%): <strong className="text-rose-700">({formatGHS(vatWht)})</strong></div>}
            <div className="border-t pt-1 font-bold">Net cash / transfer: {formatGHS(netDisbursement)}</div>
            <p className="text-[10px] text-[#355875]">{selectedWht.note} Withheld amounts become statutory payables (209000 / 221000) remitted from this desk.</p>
          </div>
        </>}
        {target.type === 'statutory' && <div className="rounded bg-sky-50 border border-sky-200 p-3 space-y-1"><div>Remittance amount: <strong>{formatGHS(amount)}</strong></div><div className="border-t pt-1 font-bold">Cash / transfer from treasury: {formatGHS(amount)}</div><p className="text-[10px] text-[#355875]">Dr {target.row.accountNo} {target.row.label} · Cr bank/cash. Retain the authority receipt against the payment reference.</p></div>}

        <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
          <button onClick={() => setTarget(null)} className="rounded px-3 py-2 font-bold text-[#355875] hover:bg-sky-50">Cancel</button>
          <button onClick={submit} disabled={restricted || isPeriodClosed} className="rounded bg-emerald-700 px-4 py-2 font-bold text-white transition hover:bg-emerald-800 disabled:opacity-40">{target.type === 'customer' ? 'Record receipt' : target.type === 'statutory' ? 'Remit statutory payable' : 'Effect payment'}</button>
        </div>
      </div>
    </div>}

    {voucher && <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4">
      <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-xl bg-white p-7 shadow-xl text-[#082f4f] space-y-4">
        <div className="flex justify-between border-b border-sky-200 pb-3">
          <div><h2 className="text-lg font-black">{currentClient.name}</h2><div className="text-xs">PAYMENT VOUCHER · {voucher.reference}</div></div>
          <div className="text-right text-xs">Date: {new Date().toISOString().slice(0, 10)}<br />Method: {voucher.method.replace('_', ' ')}</div>
        </div>
        <div className="rounded bg-sky-50 border border-sky-200 p-3 text-sm"><strong>Payee:</strong> {voucher.payee}<br /><strong>Document:</strong> {voucher.docRef}<br /><strong>Disbursed from:</strong> {voucher.bank.name} · {voucher.bank.bankName}</div>
        <table className="w-full text-xs"><thead><tr className="border-b border-sky-200"><th className="p-2 text-left">Journal line</th><th className="p-2 text-right">Debit</th><th className="p-2 text-right">Credit</th></tr></thead><tbody>
          <tr><td className="p-2">{voucher.payableAccount}</td><td className="p-2 text-right">{formatGHS(voucher.gross)}</td><td className="p-2 text-right">-</td></tr>
          {voucher.incomeWht > 0 && <tr><td className="p-2">209000 Income WHT payable</td><td className="p-2 text-right">-</td><td className="p-2 text-right">{formatGHS(voucher.incomeWht)}</td></tr>}
          {voucher.vatWht > 0 && <tr><td className="p-2">221000 VAT withholding payable</td><td className="p-2 text-right">-</td><td className="p-2 text-right">{formatGHS(voucher.vatWht)}</td></tr>}
          <tr><td className="p-2">Bank/cash payment</td><td className="p-2 text-right">-</td><td className="p-2 text-right">{formatGHS(voucher.cash)}</td></tr>
          <tr className="border-t font-bold"><td className="p-2">Totals</td><td className="p-2 text-right">{formatGHS(voucher.gross)}</td><td className="p-2 text-right">{formatGHS(voucher.gross)}</td></tr>
        </tbody></table>
        <div className="grid grid-cols-3 gap-5 pt-8 text-center text-[11px]">
          <div className="border-t border-slate-400 pt-1">Prepared by<br /><strong>{currentUser.name}</strong></div>
          <div className="border-t border-slate-400 pt-1">Checked / approved by</div>
          <div className="border-t border-slate-400 pt-1">Received by (signature)</div>
        </div>
        <div className="flex justify-end gap-2 print:hidden">
          <button onClick={() => window.print()} className="flex items-center gap-1.5 rounded bg-[#082f4f] px-4 py-2 text-xs font-bold text-white transition hover:bg-[#0c3f68]"><Printer className="h-3.5 w-3.5" /> Print voucher</button>
          <button onClick={() => setVoucher(null)} className="rounded border border-sky-300 px-4 py-2 text-xs font-bold text-[#355875] hover:bg-sky-50">Close</button>
        </div>
      </div>
    </div>}
  </div>;
};
