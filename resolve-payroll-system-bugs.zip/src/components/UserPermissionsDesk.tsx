import React, { useState } from 'react';
import { UserAccount, UserPermissions } from '../types/accounting';
import { persistentStorage } from '../utils/persistentStorage';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import {
  ShieldAlert,
  Lock,
  Unlock,
  Edit,
  Check,
} from 'lucide-react';

interface UserPermissionsDeskProps {
  currentUser?: UserAccount;
  onRefreshUsers?: () => void;
}

export const UserPermissionsDesk: React.FC<UserPermissionsDeskProps> = ({
  onRefreshUsers,
}) => {
  const [users, setUsers] = useState<UserAccount[]>(() => persistentStorage.getUserAccounts());
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [restrictTargetUser, setRestrictTargetUser] = useState<UserAccount | null>(null);
  const [restrictionReason, setRestrictionReason] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const handleToggleUserStatus = (targetUser: UserAccount) => {
    if (targetUser.username === 'owner') {
      alert('The primary Firm Owner account cannot be restricted.');
      return;
    }

    if (targetUser.status === 'restricted' || targetUser.status === 'suspended') {
      // Unrestrict user
      persistentStorage.updateUserStatus(targetUser.username, 'active', '');
      const updated = persistentStorage.getUserAccounts();
      setUsers(updated);
      setToastMsg(`User ${targetUser.name} (${targetUser.username}) has been unrestricted and restored to active status.`);
      setTimeout(() => setToastMsg(null), 4000);
      if (onRefreshUsers) onRefreshUsers();
    } else {
      // Open modal to specify restriction reason
      setRestrictTargetUser(targetUser);
      setRestrictionReason('Posting privileges suspended by Firm Owner pending review.');
    }
  };

  const handleConfirmRestriction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!restrictTargetUser) return;

    persistentStorage.updateUserStatus(restrictTargetUser.username, 'restricted', restrictionReason);
    const updated = persistentStorage.getUserAccounts();
    setUsers(updated);
    setToastMsg(`User ${restrictTargetUser.name} is now RESTRICTED. Their posting and approval actions are blocked.`);
    setTimeout(() => setToastMsg(null), 4000);
    setRestrictTargetUser(null);
    if (onRefreshUsers) onRefreshUsers();
  };

  const handleSaveUserPermissions = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    persistentStorage.upsertUserAccount(editingUser);
    const updated = persistentStorage.getUserAccounts();
    setUsers(updated);
    setToastMsg(`Permissions and Maker Limit for ${editingUser.name} updated successfully.`);
    setTimeout(() => setToastMsg(null), 4000);
    setEditingUser(null);
    if (onRefreshUsers) onRefreshUsers();
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker="GOVERNANCE & ACCESS CONTROL · OWNER CONSOLE"
        title="User Permissions & Restriction Control Desk"
        desc="Administer staff, accountants, and client controllers across all workspaces. Enforce Maker-Checker limits, block or restrict posting authority, and customize module access permissions."
      />

      {toastMsg && (
        <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-xs font-bold text-emerald-900 flex items-center gap-2 shadow-xs">
          <Check className="h-5 w-5 text-emerald-700 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* User Directory & Control Matrix */}
      <Card
        title={`Registered Users & Governance Matrix (${users.length} Accounts)`}
        sub="Control maker limits, active vs restricted status, and feature posting rights"
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[850px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Username</th>
                <th className={thCls}>Full Name / Contact</th>
                <th className={thCls}>Role &amp; Authority</th>
                <th className={thCls + ' text-right'}>Maker Limit (₵)</th>
                <th className={thCls}>Permissions</th>
                <th className={thCls}>Status</th>
                <th className={thCls + ' text-center'}>Owner Controls</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => {
                const isRestricted = u.status === 'restricted' || u.status === 'suspended';
                const isOwnerAccount = u.role === 'owner';
                const perms = u.permissions || {
                  canPostJournals: true,
                  canApprovePayments: u.canCheck,
                  canRunPayroll: true,
                  canClosePeriod: u.role === 'owner',
                  canModifyCOA: u.canCheck,
                };

                return (
                  <tr key={u.username} className={`${rowCls} ${isRestricted ? 'bg-rose-50/60' : ''}`}>
                    <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{u.username}</td>
                    <td className="px-3 py-2">
                      <div className="font-bold text-[#082f4f]">{u.name}</div>
                      <div className="text-[11px] text-[#355875] font-mono">{u.email}</div>
                    </td>
                    <td className="px-3 py-2">
                      <span
                        className={`rounded px-2 py-0.5 text-[10.5px] font-bold uppercase ${
                          u.role === 'owner'
                            ? 'bg-amber-100 text-[#855b00] border border-amber-300'
                            : u.role === 'partner' || u.role === 'manager'
                            ? 'bg-sky-100 text-[#006f98] border border-sky-300'
                            : 'bg-slate-100 text-[#355875] border border-slate-300'
                        }`}
                      >
                        {u.role}
                      </span>
                      <div className="text-[10.5px] text-[#2d4f6d] mt-0.5">
                        {u.canCheck ? '✓ Checker Authority' : 'Maker Only'}
                      </div>
                    </td>
                    <td className={numCls + ' font-mono font-bold text-[#082f4f]'}>
                      {u.makerLimit === 0 ? '₵0 (Read-Only)' : `₵${formatGHS(u.makerLimit)}`}
                    </td>
                    <td className="px-3 py-2 text-[10.5px]">
                      <div className="flex flex-wrap gap-1">
                        <span className={`px-1.5 py-0.2 rounded font-bold ${perms.canPostJournals ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-400'}`}>
                          Journals
                        </span>
                        <span className={`px-1.5 py-0.2 rounded font-bold ${perms.canApprovePayments ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-400'}`}>
                          Payments
                        </span>
                        <span className={`px-1.5 py-0.2 rounded font-bold ${perms.canRunPayroll ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-400'}`}>
                          Payroll
                        </span>
                      </div>
                    </td>
                    <td className="px-3 py-2">
                      {isRestricted ? (
                        <div>
                          <span className="rounded bg-rose-100 text-rose-800 px-2 py-0.5 text-[10.5px] font-bold border border-rose-300 flex items-center gap-1 w-fit">
                            <Lock className="h-3 w-3" />
                            <span>Restricted</span>
                          </span>
                          {u.restrictionReason && (
                            <div className="text-[10px] text-rose-700 mt-0.5 max-w-[160px] truncate" title={u.restrictionReason}>
                              {u.restrictionReason}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="rounded bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[10.5px] font-bold border border-emerald-300 flex items-center gap-1 w-fit">
                          <Check className="h-3 w-3" />
                          <span>Active</span>
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-center">
                      {!isOwnerAccount ? (
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setEditingUser({ ...u, permissions: perms })}
                            className="rounded border border-sky-300 bg-sky-50 px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-100 transition"
                            title="Edit Permissions & Limits"
                          >
                            <Edit className="h-3 w-3 inline mr-1" />
                            <span>Edit</span>
                          </button>

                          <button
                            onClick={() => handleToggleUserStatus(u)}
                            className={`rounded px-2 py-1 text-[11px] font-bold transition flex items-center gap-1 ${
                              isRestricted
                                ? 'bg-emerald-700 text-white hover:bg-emerald-800'
                                : 'bg-[#b42318] text-white hover:bg-rose-800'
                            }`}
                            title={isRestricted ? 'Unrestrict user access' : 'Restrict user authority'}
                          >
                            {isRestricted ? <Unlock className="h-3 w-3" /> : <Lock className="h-3 w-3" />}
                            <span>{isRestricted ? 'Unrestrict' : 'Restrict'}</span>
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-400 font-semibold italic">Owner Protected</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Modal: Restrict User Confirmation */}
      {restrictTargetUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <form
            onSubmit={handleConfirmRestriction}
            className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl space-y-4 text-xs text-[#0a253e]"
          >
            <div className="flex items-center gap-2 text-rose-800 font-bold border-b border-sky-100 pb-2">
              <ShieldAlert className="h-5 w-5 text-rose-700" />
              <h3 className="text-sm font-black">Restrict User Posting Authority</h3>
            </div>

            <p className="text-[#2d4f6d] leading-relaxed">
              You are about to restrict <strong>{restrictTargetUser.name}</strong> ({restrictTargetUser.username}). When restricted, all attempts to post journals, disburse payments, or run payroll will be immediately blocked.
            </p>

            <div>
              <label className="block font-bold text-[#0a253e] mb-1">Reason for Restriction / Suspension</label>
              <textarea
                rows={3}
                value={restrictionReason}
                onChange={(e) => setRestrictionReason(e.target.value)}
                placeholder="State reason for governance audit trail..."
                className="w-full rounded border border-sky-300 p-2.5 outline-none font-semibold text-[#082f4f]"
                required
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button
                type="button"
                onClick={() => setRestrictTargetUser(null)}
                className="rounded px-3.5 py-1.5 font-semibold text-[#2d4f6d] hover:bg-sky-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-lg bg-[#b42318] px-4 py-1.5 font-bold text-white hover:bg-rose-800"
              >
                Confirm &amp; Restrict User
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Edit User Permissions & Limits */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto">
          <form
            onSubmit={handleSaveUserPermissions}
            className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl space-y-4 text-xs text-[#0a253e]"
          >
            <div className="flex items-center justify-between border-b border-sky-200 pb-3">
              <div>
                <h3 className="text-base font-black text-[#082f4f]">
                  Edit Permissions — {editingUser.name}
                </h3>
                <span className="text-[11px] text-[#2d4f6d] font-mono">@{editingUser.username}</span>
              </div>
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="text-slate-400 hover:text-black text-xl font-bold p-1"
              >
                &times;
              </button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">User Role</label>
                  <select
                    value={editingUser.role}
                    onChange={(e) => setEditingUser({ ...editingUser, role: e.target.value as any })}
                    className="w-full rounded border border-sky-300 px-2.5 py-1.5 outline-none font-bold text-[#082f4f]"
                  >
                    <option value="accountant">Accountant / Staff Maker</option>
                    <option value="manager">Manager / Review Senior</option>
                    <option value="partner">Partner / Audit Director</option>
                    <option value="auditor">Independent Auditor (Read-Only)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Maker Limit Threshold (₵)</label>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={editingUser.makerLimit}
                    onChange={(e) => setEditingUser({ ...editingUser, makerLimit: Number(e.target.value) })}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono font-bold text-[#082f4f]"
                    required
                  />
                  <span className="text-[10px] text-slate-500 block mt-0.5">Postings above this require Checker approval</span>
                </div>
              </div>

              {/* Module-Level Permissions Checkboxes */}
              <div className="rounded-xl border border-sky-200 bg-sky-50/70 p-3.5 space-y-2">
                <span className="block font-bold text-[#082f4f] text-[11px] uppercase tracking-wider">
                  Granted Module Posting Authorities:
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer font-semibold text-[#0a253e]">
                    <input
                      type="checkbox"
                      checked={editingUser.permissions?.canPostJournals ?? true}
                      onChange={(e) =>
                        setEditingUser({
                          ...editingUser,
                          permissions: {
                            ...(editingUser.permissions as UserPermissions),
                            canPostJournals: e.target.checked,
                          },
                        })
                      }
                      className="rounded border-sky-300"
                    />
                    <span>Post Manual Journals (FI)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer font-semibold text-[#0a253e]">
                    <input
                      type="checkbox"
                      checked={editingUser.permissions?.canApprovePayments ?? false}
                      onChange={(e) =>
                        setEditingUser({
                          ...editingUser,
                          permissions: {
                            ...(editingUser.permissions as UserPermissions),
                            canApprovePayments: e.target.checked,
                          },
                        })
                      }
                      className="rounded border-sky-300"
                    />
                    <span>Disburse Bank Payments (PMT)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer font-semibold text-[#0a253e]">
                    <input
                      type="checkbox"
                      checked={editingUser.permissions?.canRunPayroll ?? true}
                      onChange={(e) =>
                        setEditingUser({
                          ...editingUser,
                          permissions: {
                            ...(editingUser.permissions as UserPermissions),
                            canRunPayroll: e.target.checked,
                          },
                        })
                      }
                      className="rounded border-sky-300"
                    />
                    <span>Prepare &amp; Post Payroll (HR)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer font-semibold text-[#0a253e]">
                    <input
                      type="checkbox"
                      checked={editingUser.permissions?.canClosePeriod ?? false}
                      onChange={(e) =>
                        setEditingUser({
                          ...editingUser,
                          permissions: {
                            ...(editingUser.permissions as UserPermissions),
                            canClosePeriod: e.target.checked,
                          },
                        })
                      }
                      className="rounded border-sky-300"
                    />
                    <span>Freeze Month-End Periods (MCC)</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-sky-100">
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="rounded px-4 py-2 font-semibold text-[#2d4f6d] hover:bg-sky-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-lg bg-[#082f4f] px-5 py-2 font-bold text-white hover:bg-[#0c3f68]"
              >
                Save Permissions
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
