import "dotenv/config";
import { db } from "@/db";
import {
  users,
  clients,
  journalLines,
  bankAccounts,
  purchaseOrders,
  salesInvoices,
  employees,
  companyProfiles,
  chartAccounts,
  businessPartners,
  approvalRequests,
  disclosureNotes,
  prepaymentRecords,
  prepaymentSchedules,
  closedPeriods,
  auditLog,
} from "@/db/schema";
import {
  INITIAL_USERS,
  INITIAL_CLIENTS,
  INITIAL_ACDOCA_LINES,
  INITIAL_BANK_ACCOUNTS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_SALES_INVOICES,
  INITIAL_EMPLOYEES,
  INITIAL_CHART_OF_ACCOUNTS,
  INITIAL_BUSINESS_PARTNERS,
  INITIAL_APPROVAL_REQUESTS,
  INITIAL_DISCLOSURES,
  INITIAL_PREPAYMENTS,
  INITIAL_PREPAYMENT_SCHEDULES,
} from "@/data/accountingSeed";
import { DEFAULT_PROFILES } from "@/utils/persistentStorage";
import { hashPassword, newSalt } from "@/lib/password";

/**
 * Idempotent demo seed: wipes and reloads the demonstration dataset.
 * Passwords are stored hashed (SHA-256 + per-user salt) — never in plaintext.
 */
async function main() {
  // Wipe in dependency-safe order.
  await db.delete(journalLines);
  await db.delete(bankAccounts);
  await db.delete(purchaseOrders);
  await db.delete(salesInvoices);
  await db.delete(employees);
  await db.delete(businessPartners);
  await db.delete(approvalRequests);
  await db.delete(prepaymentRecords);
  await db.delete(prepaymentSchedules);
  await db.delete(closedPeriods);
  await db.delete(auditLog);
  await db.delete(companyProfiles);
  await db.delete(chartAccounts);
  await db.delete(disclosureNotes);
  await db.delete(clients);
  await db.delete(users);

  for (const u of INITIAL_USERS) {
    const salt = newSalt();
    const passwordHash = u.password ? await hashPassword(u.password, salt) : null;
    await db.insert(users).values({
      id: u.username,
      username: u.username,
      email: u.email,
      name: u.name,
      role: u.role,
      makerLimit: u.makerLimit,
      canCheck: u.canCheck,
      clientId: u.clientId ?? null,
      passwordHash,
      passwordSalt: passwordHash ? salt : null,
      status: u.status ?? "active",
      restrictionReason: u.restrictionReason ?? null,
      permissions: u.permissions ?? null,
    });
  }

  await db.insert(clients).values(
    INITIAL_CLIENTS.map((c) => ({
      id: c.id,
      code: c.code,
      name: c.name,
      sector: c.sector,
      currency: c.currency,
      jurisdiction: c.jurisdiction,
      regNumber: c.regNumber,
      isParent: c.isParent ?? false,
      assignedServices: c.assignedServices ?? null,
      adminUsername: c.adminUsername ?? null,
      adminEmail: c.adminEmail ?? null,
      loginUrl: c.loginUrl ?? null,
    }))
  );

  await db.insert(journalLines).values(
    INITIAL_ACDOCA_LINES.map((l) => ({
      id: l.id,
      docNo: l.docNo,
      period: l.period,
      date: l.date,
      module: l.module,
      docType: l.docType,
      accountNo: l.accountNo,
      accountName: l.accountName,
      costCenter: l.costCenter ?? null,
      debit: l.debit,
      credit: l.credit,
      currency: l.currency,
      description: l.description,
      createdBy: l.createdBy,
      checkedBy: l.checkedBy ?? null,
      isReversed: l.isReversed ?? false,
      reference: l.reference ?? null,
      clientId: l.clientId,
    }))
  );

  // Legacy demonstration rows without an explicit tag belong to the demo client
  // (CLI-001, id 2) — the same default the workspace applies to untagged rows.
  const LEGACY_CLIENT_ID = 2;
  await db.insert(bankAccounts).values(
    INITIAL_BANK_ACCOUNTS.map((b) => ({
      id: b.id,
      clientId: b.clientId ?? LEGACY_CLIENT_ID,
      code: b.code,
      name: b.name,
      bankName: b.bankName,
      accountNo: b.accountNo,
      currency: b.currency,
      balance: b.balance,
      kind: b.kind ?? null,
      glAccount: b.glAccount ?? null,
    }))
  );

  await db.insert(purchaseOrders).values(
    INITIAL_PURCHASE_ORDERS.map((p) => ({
      id: p.id,
      clientId: p.clientId ?? LEGACY_CLIENT_ID,
      poNo: p.poNo,
      vendorName: p.vendorName,
      itemType: p.itemType,
      itemDescription: p.itemDescription,
      qty: p.qty,
      unitPrice: p.unitPrice,
      vatRecoverable: p.vatRecoverable,
      totalAmount: p.totalAmount,
      paidAmount: p.paidAmount ?? 0,
      status: p.status,
      date: p.date,
      currency: p.currency ?? null,
      vatTreatment: p.vatTreatment ?? null,
      netAmount: p.netAmount ?? null,
      quotationRef: p.quotationRef ?? null,
      glAccount: p.glAccount,
      glAccountName: p.glAccountName,
      costCenter: p.costCenter,
      costCenterName: p.costCenterName,
    }))
  );

  await db.insert(salesInvoices).values(
    INITIAL_SALES_INVOICES.map((i) => ({
      id: i.id,
      clientId: i.clientId ?? LEGACY_CLIENT_ID,
      invNo: i.invNo,
      customerName: i.customerName,
      revenueStream: i.revenueStream,
      netRevenue: i.netRevenue,
      vatOutput: i.vatOutput,
      cstAmount: i.cstAmount ?? null,
      tourismLevyAmount: i.tourismLevyAmount ?? null,
      vatWithheldByCustomer: i.vatWithheldByCustomer ?? null,
      totalReceivable: i.totalReceivable,
      paidAmount: i.paidAmount,
      status: i.status,
      date: i.date,
    }))
  );

  await db.insert(employees).values(
    INITIAL_EMPLOYEES.map((e) => ({
      id: e.id,
      clientId: e.clientId ?? LEGACY_CLIENT_ID,
      bpNo: e.bpNo,
      name: e.name,
      role: e.role,
      department: e.department,
      jurisdiction: e.jurisdiction,
      basicSalary: e.basicSalary,
      allowances: e.allowances,
      ssnitNumber: e.ssnitNumber,
      tin: e.tin,
      status: e.status,
      isResident: e.isResident ?? true,
      exemptTier1: e.exemptTier1 ?? false,
      exemptTier2: e.exemptTier2 ?? false,
      ssnitExempt: e.ssnitExempt ?? false,
      ssnitExemptionReason: e.ssnitExemptionReason ?? null,
      taxRelief: e.taxRelief ?? 0,
      reliefType: e.reliefType ?? null,
      deductions: e.deductions ?? null,
    }))
  );

  await db.insert(companyProfiles).values(
    Object.values(DEFAULT_PROFILES).map((p) => ({
      clientId: p.clientId,
      legalName: p.legalName,
      tradingName: p.tradingName,
      tin: p.tin,
      vatRegNo: p.vatRegNo,
      address: p.address,
      phone: p.phone,
      email: p.email,
      website: p.website,
      fiscalYearStart: p.fiscalYearStart,
      bankPaymentDetails: p.bankPaymentDetails,
    }))
  );

  await db.insert(chartAccounts).values(
    INITIAL_CHART_OF_ACCOUNTS.map((a) => ({
      accountNo: a.accountNo,
      name: a.name,
      type: a.type,
      category: a.category,
      active: a.active,
      isCustom: a.isCustom ?? false,
      clientId: null,
    }))
  );

  await db.insert(businessPartners).values(
    INITIAL_BUSINESS_PARTNERS.map((p) => ({
      id: p.id,
      clientId: p.clientId ?? LEGACY_CLIENT_ID,
      code: p.code,
      name: p.name,
      type: p.type,
      tin: p.tin,
      email: p.email,
      phone: p.phone,
      address: p.address,
      currency: p.currency,
      isVatWithholdingAgent: p.isVatWithholdingAgent,
      vatWithholdingRate: p.vatWithholdingRate ?? null,
      isCstApplicable: p.isCstApplicable,
      isTourismLevyApplicable: p.isTourismLevyApplicable,
      isVatRegistered: p.isVatRegistered ?? null,
    }))
  );

  await db.insert(approvalRequests).values(
    INITIAL_APPROVAL_REQUESTS.map((r) => ({
      id: r.id,
      clientId: r.clientId,
      clientCode: r.clientCode,
      clientName: r.clientName,
      docNo: r.docNo,
      docType: r.docType,
      amount: r.amount,
      requestedBy: r.requestedBy,
      requestedAt: r.requestedAt,
      description: r.description,
      reasonForApproval: r.reasonForApproval,
      status: r.status,
      reviewedBy: r.reviewedBy ?? null,
      reviewedAt: r.reviewedAt ?? null,
      rejectionReason: r.rejectionReason ?? null,
      payload: r.payload ?? null,
    }))
  );

  await db.insert(disclosureNotes).values(
    INITIAL_DISCLOSURES.map((n) => ({
      key: n.key,
      noteNumber: n.noteNumber,
      title: n.title,
      standardRef: n.standardRef,
      applicable: n.applicable,
      notApplicableReason: n.notApplicableReason ?? null,
      body: n.body,
      tables: n.tables ?? null,
      editableOverride: (n as { editableOverride?: boolean }).editableOverride ?? null,
    }))
  );

  await db.insert(prepaymentRecords).values(
    INITIAL_PREPAYMENTS.map((p) => ({ id: p.id, clientId: p.clientId, record: p }))
  );
  await db.insert(prepaymentSchedules).values(
    INITIAL_PREPAYMENT_SCHEDULES.map((s) => ({ id: s.id, prepaymentId: s.prepaymentId, clientId: s.clientId, line: s }))
  );

  console.log("Seed complete: users (hashed passwords), clients, journal, treasury, orders, invoices, employees, profiles, COA, partners, approvals, disclosures, prepayments.");
}

main().then(() => process.exit(0)).catch((e) => {
  console.error(e);
  process.exit(1);
});
