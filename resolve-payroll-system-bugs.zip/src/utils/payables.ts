import type { ACDOCALine } from '../types/accounting';

export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

/** Result of any Payment Desk operation. `queued` = sent to the maker-checker approval queue. */
export type PaymentResult = 'posted' | 'queued' | 'failed';

/* ============================================================================
 * EXPENSE BILLS — the Expenses & Statutory desk RECORDS obligations only.
 * Every recorded bill debits the expense (plus recoverable input VAT) and credits
 * 202000 Accrued Expenses & Other Payables. Cash never leaves at this desk:
 * settlement happens exclusively at the Payment Desk, which debits 202000 and
 * credits the treasury account. Open bills are derived from the ledger itself,
 * so the payable register can never drift from the books.
 * ========================================================================== */
export const EXPENSE_BILL_PREFIX = 'EXPB-';
export const EXPENSE_PAYABLE_ACCOUNT = '202000';

export interface ExpenseBill {
  billNo: string;
  date: string;
  period: string;
  payee: string;
  expenseAccountNo: string;
  expenseAccountName: string;
  costCenter: string;
  currency: string;
  gross: number;
  vat: number;
  paid: number;
  outstanding: number;
  status: 'Awaiting payment' | 'Partially paid' | 'Paid' | 'Reversed';
  createdBy: string;
  description: string;
}

const payeeFromAccountName = (accountName: string): string => {
  const m = accountName.match(/\(([^)]+)\)\s*$/);
  return m ? m[1] : accountName;
};

/** Derive the expense-bill payable register for one entity from posted journal lines. */
export function deriveExpenseBills(lines: ACDOCALine[], clientId: number): ExpenseBill[] {
  const scoped = lines.filter((l) => l.clientId === clientId);
  const accruals = new Map<string, ACDOCALine[]>();
  for (const l of scoped) {
    if (!l.docNo.startsWith(EXPENSE_BILL_PREFIX)) continue;
    const list = accruals.get(l.docNo) || [];
    list.push(l);
    accruals.set(l.docNo, list);
  }
  const bills: ExpenseBill[] = [];
  for (const [billNo, docLines] of accruals) {
    const payableLine = docLines.find((l) => l.accountNo === EXPENSE_PAYABLE_ACCOUNT && l.credit > 0);
    if (!payableLine) continue;
    const expenseLine = docLines.find((l) => l.debit > 0 && l.accountNo !== '125000' && l.accountNo !== EXPENSE_PAYABLE_ACCOUNT);
    const vat = round2(docLines.filter((l) => l.accountNo === '125000').reduce((s, l) => s + l.debit - l.credit, 0));
    const gross = round2(docLines.filter((l) => l.accountNo === EXPENSE_PAYABLE_ACCOUNT).reduce((s, l) => s + l.credit - l.debit, 0));
    // Settlements (and their reversals) carry reference = billNo on the 202000 line.
    const paid = round2(scoped
      .filter((l) => l.accountNo === EXPENSE_PAYABLE_ACCOUNT && l.reference === billNo && l.docNo !== billNo)
      .reduce((s, l) => s + l.debit - l.credit, 0));
    const reversed = docLines.every((l) => l.isReversed);
    const outstanding = reversed ? 0 : Math.max(0, round2(gross - paid));
    const status: ExpenseBill['status'] = reversed
      ? 'Reversed'
      : outstanding <= 0.009
        ? 'Paid'
        : paid > 0.009
          ? 'Partially paid'
          : 'Awaiting payment';
    bills.push({
      billNo,
      date: payableLine.date,
      period: payableLine.period,
      payee: payeeFromAccountName(payableLine.accountName),
      expenseAccountNo: expenseLine?.accountNo || '',
      expenseAccountName: expenseLine?.accountName || '',
      costCenter: payableLine.costCenter || 'CC-ADM',
      currency: payableLine.currency,
      gross,
      vat,
      paid,
      outstanding,
      status,
      createdBy: payableLine.createdBy,
      description: expenseLine?.description || payableLine.description,
    });
  }
  return bills.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : a.billNo < b.billNo ? 1 : -1));
}

/* ============================================================================
 * STATUTORY PAYABLES — obligations that appear the instant the source document
 * is posted (payroll → PAYE + SSNIT Tier 1 13.5% + Tier 2 5%; supplier settlement
 * → income WHT / VAT withholding; sales → VAT / CST / tourism levy; CIT provision).
 * Balances are read live from the ledger, and remittance is executed only at the
 * Payment Desk (Dr liability / Cr bank-cash).
 * ========================================================================== */
export interface StatutoryPayableDef {
  accountNo: string;
  label: string;
  authority: string;
  due: string;
  source: string;
  payroll?: boolean;
}

export const STATUTORY_PAYABLES: StatutoryPayableDef[] = [
  { accountNo: '207000', label: 'PAYE income tax withheld', authority: 'Ghana Revenue Authority (GRA)', due: '15th of the following month', source: 'Posted payroll (Act 896 / Act 1178 graduated bands)', payroll: true },
  { accountNo: '206000', label: 'SSNIT Tier 1 — 13.5% of basic', authority: 'SSNIT (incl. 2.5% forwarded to NHIA)', due: '14th of the following month', source: 'Posted payroll — Tier 1 allocation of the 18.5% contribution', payroll: true },
  { accountNo: '206100', label: 'Tier 2 occupational pension — 5% of basic', authority: 'Approved Tier 2 trustee / custodian', due: '14th of the following month', source: 'Posted payroll — mandatory Tier 2 allocation of the 18.5%', payroll: true },
  { accountNo: '208000', label: 'Staff deductions & welfare recoveries', authority: 'Loan providers / welfare funds', due: 'Per deduction agreement', source: 'Posted payroll — custom deductions', payroll: true },
  { accountNo: '209000', label: 'Income WHT deducted from suppliers', authority: 'Ghana Revenue Authority (GRA)', due: '15th of the following month', source: 'Supplier & expense settlements at the Payment Desk' },
  { accountNo: '221000', label: 'VAT withheld from suppliers (7%)', authority: 'Ghana Revenue Authority (GRA)', due: 'With the monthly VAT return', source: 'Payment Desk — appointed VAT withholding agent settlements' },
  { accountNo: '220000', label: 'VAT / NHIL / GETFund output liability', authority: 'Ghana Revenue Authority (GRA)', due: 'Last working day of the following month', source: 'Posted sales invoices (net of recoverable input VAT 125000)' },
  { accountNo: '223000', label: 'Communication Service Tax (CST)', authority: 'Ghana Revenue Authority (GRA)', due: 'With the monthly VAT return', source: 'Posted telecom / communications billings' },
  { accountNo: '224000', label: 'Tourism Development Levy (1%)', authority: 'Ghana Tourism Authority / GRA', due: 'With the monthly VAT return', source: 'Posted hospitality billings' },
  { accountNo: '212000', label: 'Corporate income tax (CIT)', authority: 'Ghana Revenue Authority (GRA)', due: 'Quarterly instalments; balance at year end', source: 'CIT provision from the tax working paper' },
  { accountNo: '205000', label: 'Net salaries payable to staff', authority: 'Employees (bank / mobile money)', due: 'Payday per employment contract', source: 'Posted payroll — released via the payroll release action', payroll: true },
];

/** Credit-side ledger balance of an account for one entity (positive = payable). */
export function liabilityBalance(lines: ACDOCALine[], clientId: number, accountNo: string): number {
  return round2(lines
    .filter((l) => l.clientId === clientId && l.accountNo === accountNo)
    .reduce((s, l) => s + l.credit - l.debit, 0));
}

export interface StatutoryPayableRow extends StatutoryPayableDef {
  balance: number;
}

/** Live statutory payable register for one entity, in desk display order. */
export function statutoryPayableRows(lines: ACDOCALine[], clientId: number): StatutoryPayableRow[] {
  return STATUTORY_PAYABLES.map((def) => ({ ...def, balance: liabilityBalance(lines, clientId, def.accountNo) }));
}
