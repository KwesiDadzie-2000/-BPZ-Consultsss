import {
  ClientEntity,
  ACDOCALine,
  BankAccount,
  EmployeeProfile,
  PurchaseOrder,
  SalesInvoice,
  DisclosureNote,
  AccountMaster,
  BusinessPartner,
  MonthlyPayrollRecord,
  UserAccount,
  ApprovalRequest,
  PrepaymentRecord,
  PrepaymentScheduleLine,
} from '../types/accounting';
import { normalizePayrollRecord } from './payrollCalculator';
import {
  INITIAL_CLIENTS,
  INITIAL_USERS,
  INITIAL_ACDOCA_LINES,
  INITIAL_BANK_ACCOUNTS,
  INITIAL_EMPLOYEES,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_SALES_INVOICES,
  INITIAL_DISCLOSURES,
  INITIAL_CHART_OF_ACCOUNTS,
  INITIAL_BUSINESS_PARTNERS,
  INITIAL_APPROVAL_REQUESTS,
  INITIAL_PREPAYMENTS,
  INITIAL_PREPAYMENT_SCHEDULES,
} from '../data/accountingSeed';

export interface CompanyProfile {
  clientId: number;
  legalName: string;
  tradingName: string;
  tin: string;
  vatRegNo: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  fiscalYearStart: string; // e.g. "January"
  bankPaymentDetails: string;
}

const STORAGE_KEYS = {
  CLIENTS: 'bpz_clients_v1',
  CURRENT_CLIENT_ID: 'bpz_current_client_id_v1',
  JOURNAL_LINES: 'bpz_journal_lines_v1',
  BANK_ACCOUNTS: 'bpz_bank_accounts_v1',
  PURCHASE_ORDERS: 'bpz_purchase_orders_v1',
  SALES_INVOICES: 'bpz_sales_invoices_v1',
  EMPLOYEES: 'bpz_employees_v1',
  DISCLOSURE_NOTES: 'bpz_disclosure_notes_v1',
  PERIOD_CLOSED: 'bpz_period_closed_v1',
  CLOSED_PERIODS: 'bpz_closed_periods_v1',
  PROFILES: 'bpz_company_profiles_v1',
  CHART_OF_ACCOUNTS: 'bpz_chart_of_accounts_v1',
  BUSINESS_PARTNERS: 'bpz_business_partners_v1',
  PAYROLL_RECORDS: 'bpz_payroll_records_v1',
  USERS: 'bpz_user_accounts_v1',
  APPROVALS: 'bpz_approval_requests_v1',
  PREPAYMENTS: 'bpz_prepayments_v1',
  PREPAYMENT_SCHEDULES: 'bpz_prepayment_schedules_v1',
};

export const DEFAULT_PROFILES: Record<number, CompanyProfile> = {
  1: {
    clientId: 1,
    legalName: 'BPZ Consult Ltd',
    tradingName: 'BPZ Consult — Financial Experts',
    tin: 'C0001928374',
    vatRegNo: 'VAT-GH-109283',
    address: 'Suite 401, Financial Tower, Airport City, Accra, Ghana',
    phone: '+233 30 200 1122',
    email: 'info@bpzconsult.com',
    website: 'www.bpzconsult.com',
    fiscalYearStart: 'January',
    bankPaymentDetails: 'Ecobank Ghana Ltd · Account: 144100298102 · Branch: Airport City',
  },
  2: {
    clientId: 2,
    legalName: 'Gold Coast Mines Ltd',
    tradingName: 'Gold Coast Mining & Smelting',
    tin: 'C0094812201',
    vatRegNo: 'VAT-GH-948122',
    address: 'Plot 14, Western Concession Road, Tarkwa, Western Region, Ghana',
    phone: '+233 31 209 8844',
    email: 'accounts@goldcoastmines.com',
    website: 'www.goldcoastmines.com',
    fiscalYearStart: 'January',
    bankPaymentDetails: 'Ecobank Ghana Ltd (Operating GHS) · A/C 144100298102 · StanChart USD 870192837101',
  },
};

export const persistentStorage = {
  getClients(): ClientEntity[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CLIENTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Storage read failed', e);
    }
    return INITIAL_CLIENTS;
  },

  saveClients(clients: ClientEntity[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.CLIENTS, JSON.stringify(clients));
    } catch (e) {
      console.warn('Storage write failed', e);
    }
  },

  getCurrentClientId(): number {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CURRENT_CLIENT_ID);
      if (saved) return Number(saved);
    } catch (e) {}
    return INITIAL_CLIENTS[1].id; // Default Gold Coast Mines
  },

  saveCurrentClientId(id: number) {
    try {
      localStorage.setItem(STORAGE_KEYS.CURRENT_CLIENT_ID, String(id));
    } catch (e) {}
  },

  getJournalLines(): ACDOCALine[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.JOURNAL_LINES);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_ACDOCA_LINES;
  },

  saveJournalLines(lines: ACDOCALine[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.JOURNAL_LINES, JSON.stringify(lines));
    } catch (e) {}
  },

  getBankAccounts(): BankAccount[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.BANK_ACCOUNTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_BANK_ACCOUNTS;
  },

  saveBankAccounts(accounts: BankAccount[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.BANK_ACCOUNTS, JSON.stringify(accounts));
    } catch (e) {}
  },

  getPurchaseOrders(): PurchaseOrder[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PURCHASE_ORDERS);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_PURCHASE_ORDERS;
  },

  savePurchaseOrders(pos: PurchaseOrder[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.PURCHASE_ORDERS, JSON.stringify(pos));
    } catch (e) {}
  },

  getSalesInvoices(): SalesInvoice[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SALES_INVOICES);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_SALES_INVOICES;
  },

  saveSalesInvoices(invoices: SalesInvoice[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.SALES_INVOICES, JSON.stringify(invoices));
    } catch (e) {}
  },

  getEmployees(): EmployeeProfile[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.EMPLOYEES);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_EMPLOYEES;
  },

  saveEmployees(emps: EmployeeProfile[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.EMPLOYEES, JSON.stringify(emps));
    } catch (e) {}
  },

  getDisclosureNotes(): DisclosureNote[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DISCLOSURE_NOTES);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_DISCLOSURES;
  },

  saveDisclosureNotes(notes: DisclosureNote[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.DISCLOSURE_NOTES, JSON.stringify(notes));
    } catch (e) {}
  },

  /** Closed fiscal periods per entity (e.g. { 2: ["2026-03"] }) — each entity's books freeze independently. */
  getClosedPeriods(): Record<number, string[]> {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CLOSED_PERIODS);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    // Migrate the legacy single global flag.
    try {
      const legacy = localStorage.getItem(STORAGE_KEYS.PERIOD_CLOSED);
      if (legacy && JSON.parse(legacy)) {
        const period = new Date().toISOString().slice(0, 7);
        const map: Record<number, string[]> = {};
        for (const c of INITIAL_CLIENTS) map[c.id] = [period];
        return map;
      }
    } catch (e) {}
    return {};
  },

  saveClosedPeriods(periods: Record<number, string[]>) {
    try {
      localStorage.setItem(STORAGE_KEYS.CLOSED_PERIODS, JSON.stringify(periods));
    } catch (e) {}
  },

  getCompanyProfiles(): Record<number, CompanyProfile> {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROFILES);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return DEFAULT_PROFILES;
  },

  saveCompanyProfiles(profiles: Record<number, CompanyProfile>) {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
    } catch (e) {}
  },

  /**
   * Owner action: set the fiscal year start month for every entity (all clients).
   * Creates a default profile for any entity that does not have one yet.
   */
  setFiscalYearStartForAll(month: string, clientIds: number[]) {
    const profiles = this.getCompanyProfiles();
    const updated = { ...profiles };
    for (const id of clientIds) {
      const existing = updated[id] || {
        clientId: id,
        legalName: '',
        tradingName: '',
        tin: '',
        vatRegNo: '',
        address: '',
        phone: '',
        email: '',
        website: '',
        fiscalYearStart: 'January',
        bankPaymentDetails: '',
      };
      updated[id] = { ...existing, fiscalYearStart: month };
    }
    this.saveCompanyProfiles(updated);
    return updated;
  },

  getChartOfAccounts(): AccountMaster[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CHART_OF_ACCOUNTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_CHART_OF_ACCOUNTS;
  },

  saveChartOfAccounts(accounts: AccountMaster[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.CHART_OF_ACCOUNTS, JSON.stringify(accounts));
    } catch (e) {}
  },

  getBusinessPartners(): BusinessPartner[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.BUSINESS_PARTNERS);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_BUSINESS_PARTNERS;
  },

  saveBusinessPartners(partners: BusinessPartner[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.BUSINESS_PARTNERS, JSON.stringify(partners));
    } catch (e) {}
  },

  getPayrollRecords(): MonthlyPayrollRecord[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PAYROLL_RECORDS);
      if (saved) {
        // Migrate records saved under the pre-2026 SSNIT model to the statutory
        // 18.5% (5.5% employee + 13% employer; Tier 2 5% allocated) model.
        return (JSON.parse(saved) as MonthlyPayrollRecord[]).map(normalizePayrollRecord);
      }
    } catch (e) {}
    return [];
  },

  savePayrollRecords(records: MonthlyPayrollRecord[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.PAYROLL_RECORDS, JSON.stringify(records));
    } catch (e) {}
  },

  getPrepayments(): PrepaymentRecord[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PREPAYMENTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_PREPAYMENTS;
  },

  savePrepayments(records: PrepaymentRecord[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.PREPAYMENTS, JSON.stringify(records));
    } catch (e) {}
  },

  getPrepaymentSchedules(): PrepaymentScheduleLine[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PREPAYMENT_SCHEDULES);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_PREPAYMENT_SCHEDULES;
  },

  savePrepaymentSchedules(schedules: PrepaymentScheduleLine[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.PREPAYMENT_SCHEDULES, JSON.stringify(schedules));
    } catch (e) {}
  },

  getUserAccounts(): UserAccount[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USERS);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_USERS;
  },

  saveUserAccounts(users: UserAccount[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    } catch (e) {}
  },

  upsertUserAccount(user: UserAccount) {
    const list = this.getUserAccounts();
    const idx = list.findIndex((u) => u.username.toLowerCase() === user.username.toLowerCase());
    if (idx >= 0) {
      list[idx] = { ...list[idx], ...user };
    } else {
      list.push(user);
    }
    this.saveUserAccounts(list);
    // Server is authoritative for credentials: hash and persist owner-side.
    import('./session').then(({ apiFetch }) => {
      apiFetch('/api/users', { method: 'PUT', body: JSON.stringify({ user }) }).catch(() => {});
    });
  },

  updateUserStatus(username: string, status: 'active' | 'restricted' | 'suspended', reason?: string) {
    const list = this.getUserAccounts();
    const updated = list.map((u) =>
      u.username.toLowerCase() === username.toLowerCase()
        ? { ...u, status, restrictionReason: reason || u.restrictionReason }
        : u
    );
    this.saveUserAccounts(updated);
    const target = updated.find((u) => u.username.toLowerCase() === username.toLowerCase());
    if (target) {
      import('./session').then(({ apiFetch }) => {
        apiFetch('/api/users', { method: 'PUT', body: JSON.stringify({ user: target }) }).catch(() => {});
      });
    }
  },

  getApprovalRequests(): ApprovalRequest[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.APPROVALS);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_APPROVAL_REQUESTS;
  },

  saveApprovalRequests(reqs: ApprovalRequest[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.APPROVALS, JSON.stringify(reqs));
    } catch (e) {}
  },

  addApprovalRequest(req: ApprovalRequest) {
    const list = this.getApprovalRequests();
    list.unshift(req);
    this.saveApprovalRequests(list);
  },

  resolveApprovalRequest(id: string, decision: 'approved' | 'rejected', reviewerName: string, reason?: string): ApprovalRequest | null {
    const list = this.getApprovalRequests();
    const target = list.find((r) => r.id === id);
    if (!target) return null;
    target.status = decision;
    target.reviewedBy = reviewerName;
    target.reviewedAt = new Date().toISOString().replace('T', ' ').slice(0, 16) + ' GMT';
    if (reason) target.rejectionReason = reason;
    this.saveApprovalRequests(list);
    return target;
  },

  // Export full books backup (.json)
  exportFullBackup(): string {
    const data = {
      version: '2026.4',
      exportDate: new Date().toISOString(),
      clients: this.getClients(),
      currentClientId: this.getCurrentClientId(),
      chartOfAccounts: this.getChartOfAccounts(),
      businessPartners: this.getBusinessPartners(),
      journalLines: this.getJournalLines(),
      bankAccounts: this.getBankAccounts(),
      purchaseOrders: this.getPurchaseOrders(),
      salesInvoices: this.getSalesInvoices(),
      employees: this.getEmployees(),
      payrollRecords: this.getPayrollRecords(),
      disclosureNotes: this.getDisclosureNotes(),
      closedPeriods: this.getClosedPeriods(),
      profiles: this.getCompanyProfiles(),
    };
    return JSON.stringify(data, null, 2);
  },

  // Restore books from backup (.json)
  restoreFullBackup(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      // Refuse partial or malformed restores before changing any browser data.
      if (data.version !== '2026.4' || !Array.isArray(data.clients) || !data.clients.length ||
          !Array.isArray(data.journalLines) || !Array.isArray(data.bankAccounts) ||
          !Array.isArray(data.purchaseOrders) || !Array.isArray(data.salesInvoices) ||
          !Array.isArray(data.employees) || !Array.isArray(data.payrollRecords) ||
          !Array.isArray(data.disclosureNotes) || !Array.isArray(data.chartOfAccounts) ||
          !Array.isArray(data.businessPartners) || !data.profiles ||
          (typeof data.periodClosed !== 'boolean' && typeof data.closedPeriods !== 'object')) return false;
      const clientIds = new Set(data.clients.map((c: ClientEntity) => c.id));
      if (data.journalLines.some((l: ACDOCALine) => !clientIds.has(l.clientId) ||
          !Number.isFinite(l.debit) || !Number.isFinite(l.credit) || l.debit < 0 || l.credit < 0)) return false;
      const documents = new Map<string, number>();
      for (const l of data.journalLines as ACDOCALine[]) {
        const key = `${l.clientId}:${l.docNo}`;
        documents.set(key, (documents.get(key) || 0) + Math.round(l.debit * 100) - Math.round(l.credit * 100));
      }
      if ([...documents.values()].some(amount => amount !== 0)) return false;
      if (data.clients && Array.isArray(data.clients)) {
        this.saveClients(data.clients);
      }
      if (data.chartOfAccounts && Array.isArray(data.chartOfAccounts)) {
        this.saveChartOfAccounts(data.chartOfAccounts);
      }
      if (data.businessPartners && Array.isArray(data.businessPartners)) {
        this.saveBusinessPartners(data.businessPartners);
      }
      if (data.journalLines && Array.isArray(data.journalLines)) {
        this.saveJournalLines(data.journalLines);
      }
      if (data.bankAccounts && Array.isArray(data.bankAccounts)) {
        this.saveBankAccounts(data.bankAccounts);
      }
      if (data.purchaseOrders && Array.isArray(data.purchaseOrders)) {
        this.savePurchaseOrders(data.purchaseOrders);
      }
      if (data.salesInvoices && Array.isArray(data.salesInvoices)) {
        this.saveSalesInvoices(data.salesInvoices);
      }
      if (data.employees && Array.isArray(data.employees)) {
        this.saveEmployees(data.employees);
      }
      if (data.payrollRecords && Array.isArray(data.payrollRecords)) {
        this.savePayrollRecords(data.payrollRecords);
      }
      if (data.disclosureNotes && Array.isArray(data.disclosureNotes)) {
        this.saveDisclosureNotes(data.disclosureNotes);
      }
      if (data.profiles) {
        this.saveCompanyProfiles(data.profiles);
      }
      if (data.closedPeriods && typeof data.closedPeriods === 'object') {
        this.saveClosedPeriods(data.closedPeriods);
      }
      return true;
    } catch (e) {
      console.error('Failed to restore backup', e);
      return false;
    }
  },

  // Reset to clean fresh books (wipe sample demo transactions for a real entity)
  initFreshBooks(clientId: number) {
    const lines = this.getJournalLines().filter((l) => l.clientId !== clientId);
    this.saveJournalLines(lines);
    this.savePrepayments(this.getPrepayments().filter((r) => r.clientId !== clientId));
    this.savePrepaymentSchedules(this.getPrepaymentSchedules().filter((s) => s.clientId !== clientId));
  },
};
