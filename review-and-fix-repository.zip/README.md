# BPZ Consult Review Workspace

The latest source archive was imported and bug-fixed without redesigning the BPZ template. Start with `docs/SYSTEM_REVIEW.md` for the critique, remediation scope, evidence, and unresolved production risks.

## Run The Review

```sh
npm install
npm run dev
```

The Vite entry opens a clearly labelled, local-only sample workspace. Do not enter real customer or employee information. The original Next server routes remain in `src/app/api/` and are not emulated as live infrastructure.

## Verification

```sh
npx tsc --noEmit
npx tsx src/tests/sectorTransactions.test.ts
npx tsx --test src/tests/reviewRegressions.test.ts
npx playwright test tests/workspace.spec.ts --workers=1
npm run build
```

Browser tests require the dev server on port 5173 and Chromium installed through `npx playwright install chromium`. On a minimal Linux machine, run `npx playwright install-deps chromium` as well.

For the API regression suite, supply `BPZ_TEST_DATABASE_URL` pointing to a **disposable local database named `bpz_review_test`**. The suite recreates that database's public schema and refuses any other database name or non-local host. Never use production credentials for this test.

## Original Project

`upstream-original/` contains the untouched repository archive and extracted source. No changes were pushed to GitHub. The original Next application does not enable the Vite review transport. Its production deployment needs PostgreSQL and an operator-provisioned user; configure `BPZ_SEED_PASSWORD_OWNER` before seeding a fresh database or use the existing administrative password-reset procedure. Without an explicit seed password, a random password is generated instead of a public default.

Posted journals are intentionally immutable after the review. Correct mistakes with **Reverse**, followed by a new journal, not Edit/Delete or a full-state overwrite.

`artifacts/` contains verification evidence and the generated patch/source package when available.