# BPZ Consult: Focused System Review

## Scope And Preservation

Reviewed the most recent upload in `KwesiDadzie-2000/-BPZ-Consultsss`:

- Commit: `22c026b249ca69840f0f69dd472e87fcc7c56e8f`.
- Uploaded: 29 October 2026, 20:34:49 UTC.
- Archive: `comprehensive-system-audit-and-improvement.zip`.
- Untouched reference: `upstream-original/source/` and the original ZIP alongside it.

The GitHub repository was not pushed to or changed. The working implementation is in `src/`. The original BPZ header, sidebar, colour palette, module templates, tables, and dashboard composition are retained. Changes to visible controls are limited to accurate status text, correct field values, error messages, and accessibility.

## Critique

The system has useful foundations: double-entry journals, entity scoping, period controls, an approval queue, scrypt password hashing, a server-side trade engine, and a sizeable collection of accounting modules. However, a large feature list and references to IFRS or SOC 2 are not evidence of compliance.

The main weakness was inconsistent authority. The individual journal endpoint had controls that the full-state synchronization endpoint could bypass. A supposedly posted document could be replaced or deleted by a browser snapshot. Similarly, naming a real checker was treated as approval without requiring that checker to submit the transaction. These are accounting-integrity defects, not cosmetic issues.

The existing audit report's broad descriptions such as "sound" and "certified" should not be treated as an independent assurance opinion. This review makes only the specific, testable claims below.

## Findings And Fixes

| ID | Severity | Observed Defect | Targeted Remediation |
| --- | --- | --- | --- |
| R01 | Critical | `api/state` replaced posted journal content, deleted omitted records, and regenerated headers. `api/journal` also allowed PATCH/DELETE of posted documents. | Journal sync is append-only. Conflicting content returns 409. Missing rows survive. Checks are repeated under the shared transaction lock. Posted PATCH/DELETE is refused; use a reversal and a correcting entry. |
| R02 | Critical | A maker could supply a real authorised user's name as `checkedBy` without that user taking part. | An independent checker stamp must belong to the authenticated submitter. Maker/checker entity scope, active status, posting permission, and consistent stamps are checked. |
| R03 | High | A zero maker limit was labelled read-only in the UI but treated as unlimited by validation. | Zero or invalid maker limits refuse posting instead of granting unlimited authority. |
| R04 | High | The approval dialog changed status before posting, dropped `payload.settlement`, and did not reliably trigger a sync for review-only decisions. | Await the posting result, preserve the entire payload, apply settlement metadata after success, use the authenticated reviewer username, sync decision revisions, prevent duplicate clicks, and leave rejected postings pending. |
| R05 | High | Shared frontend seed data contained usable default plaintext passwords. Cached identity could open a workspace during an authentication outage. | Remove seed passwords from browser-imported data and browser user writes. New server seeds use operator-provided environment values or cryptographically random unusable defaults. Do not authorise a production workspace from a cached identity. |
| R06 | High | Journal period could differ from posting date; unsafe amounts and inconsistent checker stamps were accepted. | Validate date/period agreement, safe minor-unit amounts, two-decimal precision, unique identifiers, and consistent document identities. Mirror checks before local posting. |
| R07 | Medium | Manual-journal default labels did not match actual chart entries. Selected period could silently use today's date. Same-account entries and sub-unit amounts were mishandled. | Bind initial selections to actual active accounts, select an explicit posting date, derive its period, reject same-account entries, and accept valid amounts from 0.01. |
| R08 | Medium | "Recent" activity used the first stored rows; dashboard values always displayed GHS and could combine currencies. | Sort a copy newest first, use entity currency, exclude untranslated foreign-currency lines with a visible explanation, and evaluate balance separately per currency. Add an empty-state row and correct loss colouring. This is not an FX translation engine. |
| R09 | High | Full-book backups omitted inventory, movements, fixed assets, approvals, prepayments, and tax schedule edits. Restore could silently stop part-way on storage failure. | Version 2026.5 includes these registers; 2026.4 remains readable. Validate before writing and attempt rollback on a failed multi-key write. Storage remains browser storage, not a transactional database. |
| R10 | Medium | Spreadsheet exports quoted text but did not neutralise formula-like values. | The shared CSV exporter neutralises formula-prefixed strings while preserving actual negative numeric values. |
| R11 | Medium | Journal/review dialogs lacked reliable keyboard focus handling; hidden mobile navigation remained focusable; some fields had no associated labels. | Add dialog semantics, focus containment/restoration, Escape dismissal, explicit labels, mobile inert state, a skip link, visible focus, status announcements, and reduced-motion support. |
| R12 | Medium | Permission-denial responses retried as if the session were lost; login lockout could reuse an expired browser counter; storage errors were swallowed. | Do not retry an ordinary 403 as authentication failure. Recheck lockout time on submit and reset expired counters. Surface storage failures and retain malformed saved data for recovery. |
| R13 | Medium | Period-lock authority was only partially enforced on full-state synchronization. | A non-owner without `canClosePeriod` cannot change period locks through sync. Approval status transitions also require an independent reviewer identity. |

The development harness had vulnerable dependencies independent of the upstream Next template. Vite was updated to 7.3.7 through npm, and the dependency audit was clean at verification time.

## Preview Versus Production

`src/main.tsx` explicitly enables an isolated local review transport. It shows the original dashboard and original sample records without requesting or fabricating a production login. The header identifies this as **Local review / sample data**. Ledger, registers, quick invoicing, reports, approvals, and backups use isolated browser storage. Production storage and session keys are not cleared when leaving review.

The original Next entry (`src/app/page.tsx`) does not enable this transport. It continues to use the authenticated PostgreSQL API. The local preview is not a production authentication implementation.

Advanced server-authoritative trade mutations, user provisioning, live integrations, and SSO cannot be executed against a production service from this static preview. They do not return fabricated success. The original implementation is retained for a configured deployment. Use the original quick-entry tabs for browser review.

## Verification

Verification commands and evidence are retained in `artifacts/` and the test sources:

- `npx tsx src/tests/sectorTransactions.test.ts`: 47 existing accounting tests.
- `npx tsx --test src/tests/reviewRegressions.test.ts`: 43 targeted regressions covering validation, approval identity, immutability, currency isolation, CSV safety, and backup recovery.
- `BPZ_TEST_DATABASE_URL=... npx tsx src/tests/apiRegression.test.ts`: 22 route-level integration cases against a disposable local PostgreSQL database. Includes authentication, forgery rejection, immutability, stale sync, concurrent writes, review decisions, permissions, and logout. No production database was accessed.
- `npx playwright test tests/workspace.spec.ts --workers=1`: 11 browser checks for posting, persistence, reversal, approval settlement metadata, rejected approvals, entity isolation, keyboard access, and preview isolation.
- All 35 original sidebar destinations were smoke-tested without uncaught page errors.
- The dashboard passed the automated axe WCAG A/AA checks used by the browser suite. This is not a whole-product WCAG conformance claim.
- `npx tsc --noEmit` and `npm run build` are required verification gates.
- A separate compatibility build of the patched original Next application passed using installed Next 16.4.3. The archive's pinned Next 16.2.6 dependency tree was not substituted into that test; validate the exact production dependency lockfile before rollout.
- Archive comparison: all 126 original files match their ZIP contents byte for byte. See `artifacts/provenance.json` for the SHA-256 fingerprint.

## Remaining Production Risks

These are **not** claimed to be fixed or certified:

1. Most operational master data still uses full-state replacement. Move it to versioned, command-based APIs to prevent stale writes and make settlement side effects atomic with journals. The repaired journal ledger itself is append-only.
2. Whole-product IFRS correctness, current tax law, jurisdiction-specific payroll, currency conversion, consolidation, and statutory filings require qualified domain review. The new dashboard currency guard does not repair every downstream report's FX handling.
3. The sample bank register and sample ledger do not reconcile: the dashboard correctly derives its cash amount from the posted journal rather than inventing an opening balance. Load verified opening balances and reconcile before real use.
4. Rotate any existing accounts that used the public seed passwords. Removing defaults does not rotate passwords already stored in a deployed database or remove earlier public archives.
5. MFA, distributed rate limiting, complete CSRF/origin policy, cookie/token exposure review, encrypted data handling, and a penetration test remain deployment requirements. Production session tokens are still readable by JavaScript in the inherited fallback mechanism.
6. Browser backups do not replace encrypted database backups, point-in-time recovery, restore drills, retention controls, or an attachment backup. IndexedDB attachments are outside the JSON books backup.
7. An automated accessibility check of selected workflows does not cover every original modal, financial report, contrast combination, or assistive technology.
8. API regression tests used a local PostgreSQL fixture. No production credentials, infrastructure configuration, external integrations, load test, or production deployment were verified.

## Standards References

- OWASP Transaction Authorization Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Transaction_Authorization_Cheat_Sheet.html
- W3C WAI-ARIA modal dialog pattern: https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/
- WCAG 2.2: https://www.w3.org/TR/WCAG22/
- Next route handlers use standard Request/Response APIs: https://nextjs.org/docs/app/api-reference/file-conventions/route

These references guided specific controls. This document is an engineering review, not an IFRS, SOC 2, ISO, security, or regulatory certification.