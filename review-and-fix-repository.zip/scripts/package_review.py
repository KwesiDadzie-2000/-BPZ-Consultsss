"""Package the patched original project without changing the reference archive."""

from pathlib import Path
import difflib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL = ROOT / "upstream-original/source"
ARTIFACTS = ROOT / "artifacts"
DOWNLOADS = ROOT / "public/downloads"
ARTIFACTS.mkdir(exist_ok=True)
DOWNLOADS.mkdir(parents=True, exist_ok=True)

files = {path.relative_to(ORIGINAL).as_posix(): path.read_bytes()
         for path in ORIGINAL.rglob("*") if path.is_file()}
reference = dict(files)
preview_entry_only = {"src/main.tsx", "src/index.css", "src/preview/enable.ts"}
for path in (ROOT / "src").rglob("*"):
    name = path.relative_to(ROOT).as_posix()
    if path.is_file() and name not in preview_entry_only:
        files[name] = path.read_bytes()
files["docs/SYSTEM_REVIEW.md"] = (ROOT / "docs/SYSTEM_REVIEW.md").read_bytes()
files["REVIEW_NOTES.md"] = b"""# BPZ Consult Reviewed Source

This package preserves the original Next project and BPZ visual template.
See docs/SYSTEM_REVIEW.md for findings, verification, and unresolved risks.
The previous AUDIT_REPORT.md is retained as historical source material, not
as a new certification or endorsement.

Run npm install, configure DATABASE_URL, and use the original npm run dev
or npm run build commands. On a NEW database set BPZ_SEED_PASSWORD_OWNER
to an independently generated strong password before first provisioning.
Previously deployed default-password accounts must be rotated separately.

This Next entry requires server authentication. It does NOT enable the
Vite local-review mode. The local review entry and browser tests belong to
the separate review workspace, not to this production-source package.

Never run src/tests/apiRegression.test.ts against production. It recreates
the schema of a disposable LOCAL database named bpz_review_test, supplied
through BPZ_TEST_DATABASE_URL.

Posted journals are immutable: use Reverse and post a correcting journal.
No source changes have been pushed to the original GitHub repository.
"""

patch = []
changed = []
for name, content in sorted(files.items()):
    before = reference.get(name)
    if before == content:
        continue
    changed.append({"path": name, "status": "modified" if before is not None else "added"})
    patch.append(f"diff --git a/{name} b/{name}\n")
    if before is None:
        patch.append("new file mode 100644\n")
    for line in difflib.unified_diff(
        (before or b"").decode().splitlines(keepends=True),
        content.decode().splitlines(keepends=True),
        fromfile=f"a/{name}" if before is not None else "/dev/null",
        tofile=f"b/{name}",
    ):
        patch.append(line if line.endswith("\n") else line + "\n\\ No newline at end of file\n")

archive = ARTIFACTS / "bpz-reviewed-source.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as target:
    for name, content in sorted(files.items()):
        target.writestr(name, content)
(ARTIFACTS / "bpz-review-fixes.patch").write_text("".join(patch))
(ARTIFACTS / "change-manifest.json").write_text(json.dumps(changed, indent=2) + "\n")
for name in ["bpz-reviewed-source.zip", "bpz-review-fixes.patch"]:
    (DOWNLOADS / name).write_bytes((ARTIFACTS / name).read_bytes())
(DOWNLOADS / "SYSTEM_REVIEW.md").write_bytes((ROOT / "docs/SYSTEM_REVIEW.md").read_bytes())
print(f"Packaged {len(files)} files; {len(changed)} changed or added files.")
print(f"Source package: {archive.relative_to(ROOT)} ({archive.stat().st_size:,} bytes)")