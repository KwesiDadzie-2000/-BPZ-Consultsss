import './config';

window.__BPZ_LOCAL_REVIEW__ = true;