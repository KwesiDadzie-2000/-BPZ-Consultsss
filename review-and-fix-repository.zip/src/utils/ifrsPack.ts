/**
 * IFRS statutory financial statement pack.
 *
 * Every figure in this module is derived from the entity's own posted journal,
 * so the statements, the notes and the ledger can never disagree. The
 * presentation follows IAS 1 *Presentation of Financial Statements* (with the
 * statements and disclosures required by IAS 7, IAS 10, IAS 12, IAS 16, IAS 19,
 * IAS 24, IAS 33, IAS 37, IFRS 7, IFRS 8, IFRS 15 and IFRS 16) and the note
 * numbering is the note numbering printed on the statements themselves.
 *
 * Amounts are held in major currency units, rounded to two decimals.
 */

import type { AccountMaster, ACDOCALine } from '@/types/accounting';
import { aggregateTrialBalance, buildCashFlow, classifyAccount, type TbRow } from '@/utils/reports';

const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const minor = (n: number) => Math.round(n * 100);

export interface IfrsRow {
  label: string;
  current: number;
  comparative: number;
  /** Note cross-reference printed in the right margin, e.g. "6". */
  note?: string;
  emphasis?: 'sub' | 'total' | 'grand';
  indent?: boolean;
}

export interface IfrsBlock {
  title?: string;
  rows: IfrsRow[];
  total?: IfrsRow;
}

export interface IfrsStatement {
  id: 'position' | 'profit' | 'equity' | 'cashflow';
  standard: string;
  title: string;
  subtitle: string;
  columns: [string, string, string];
  blocks: IfrsBlock[];
  /**
   * The IAS 1.106 matrix: one column per equity component, one row per
   * movement. Presented as a grid rather than as a two-column statement.
   */
  matrix?: {
    columns: string[];
    rows: Array<{ label: string; values: number[]; total: number; emphasis?: IfrsRow['emphasis'] }>;
  };
}

export interface IfrsNote {
  number: number;
  title: string;
  standard: string;
  paragraphs: string[];
  table?: {
    columns: string[];
    rows: Array<Array<string | number>>;
    totals?: Array<string | number>;
  };
}

export interface RatioRow {
  label: string;
  current: string;
  comparative: string;
  basis: string;
  ref: string;
}

export type CheckSeverity = 'critical' | 'warning' | 'pass';

export interface ControlCheck {
  id: string;
  severity: CheckSeverity;
  area: string;
  standard: string;
  title: string;
  detail: string;
  action: string;
}

export type GapStatus = 'Implemented' | 'Partial' | 'Gap';

export interface GapItem {
  standard: string;
  area: string;
  severity: 'High' | 'Medium' | 'Low';
  status: GapStatus;
  why: string;
  remedy: string;
}

export interface IfrsPack {
  entityName: string;
  entityCode: string;
  currency: string;
  jurisdiction: string;
  periodLabel: string;
  comparativeLabel: string;
  balanceSheetDate: string;
  statements: IfrsStatement[];
  policies: Array<{ standard: string; title: string; text: string }>;
  notes: IfrsNote[];
  ratios: RatioRow[];
  checks: ControlCheck[];
  gaps: GapItem[];
  checklist: Array<{ requirement: string; standard: string; status: 'Satisfied' | 'Partial' | 'Missing'; detail: string }>;
  totals: {
    revenue: number;
    revenueComparative: number;
    grossProfit: number;
    grossProfitComparative: number;
    profitBeforeTax: number;
    profitBeforeTaxComparative: number;
    taxExpense: number;
    taxExpenseComparative: number;
    profitForPeriod: number;
    profitForPeriodComparative: number;
    totalComprehensiveIncome: number;
    totalAssets: number;
    totalAssetsComparative: number;
    totalEquity: number;
    totalEquityComparative: number;
    totalLiabilities: number;
    totalLiabilitiesComparative: number;
    cashAndEquivalents: number;
    cashAndEquivalentsComparative: number;
    netDebt: number;
    netDebtComparative: number;
    balanced: boolean;
  };
}

export interface PackInput {
  lines: readonly ACDOCALine[];
  accounts: AccountMaster[];
  from: string;
  through: string;
  currency: string;
  entityName: string;
  entityCode: string;
  jurisdiction: string;
  regNumber?: string;
  fiscalYearStart?: string;
  sector?: string;
}

/* ------------------------------------------------------------------ */
/* Account classification — driven by the account master first, then   */
/* by number range and caption so tailored / custom accounts still map */
/* to the right statutory caption.                                     */
/* ------------------------------------------------------------------ */

type Group =
  | 'ppe'
  | 'rou'
  | 'intangibles'
  | 'investmentProperty'
  | 'investments'
  | 'deferredTaxAsset'
  | 'inventories'
  | 'receivables'
  | 'contractAssets'
  | 'prepayments'
  | 'taxAsset'
  | 'cash'
  | 'borrowings'
  | 'leaseLiability'
  | 'deferredTaxLiability'
  | 'provisions'
  | 'payables'
  | 'contractLiabilities'
  | 'taxPayable'
  | 'dividends'
  | 'other'
  | 'shareCapital'
  | 'sharePremium'
  | 'revaluationReserve'
  | 'translationReserve'
  | 'retainedEarnings'
  | 'revenue'
  | 'otherIncome'
  | 'financeIncome'
  | 'costOfSales'
  | 'staffCosts'
  | 'distribution'
  | 'administrative'
  | 'financeCosts'
  | 'taxExpense'
  | 'depreciation';


function groupOf(account: AccountMaster | undefined, code: string): Group {
  const name = account?.name || '';
  const category = account?.category || '';
  const type = account ? account.type : classifyAccount([], code);
  const n = Number(code.replace(/\D/g, '').slice(0, 3)) || 0;
  const text = `${name} ${category}`;

  if (type === 'Equity') {
    if (/premium/i.test(name)) return 'sharePremium';
    if (/revaluation/i.test(name)) return 'revaluationReserve';
    if (/translation|foreign currency/i.test(name)) return 'translationReserve';
    if (/capital|stated/i.test(name)) return 'shareCapital';
    return 'retainedEarnings';
  }
  if (type === 'Income') {
    if (/interest income|finance income/i.test(name)) return 'financeIncome';
    if (/revenue|sales|contract income|fees earned/i.test(text)) return 'revenue';
    return 'otherIncome';
  }
  if (type === 'Expense') {
    if (/depreciation|amortisation|amortization/i.test(name)) return 'depreciation';
    if (/income tax|tax expense|company income tax|corporation tax/i.test(text)) return 'taxExpense';
    if (/cost of sales|cost of goods|cost of extraction|raw material|consumable|packaging|clinical supplies|food & beverage cost|landed cost|purchase price variance|royalty/i.test(text))
      return 'costOfSales';
    if (/staff cost|salaries|wages|ssnit|pension|gratuity|remuneration|recruitment|training|welfare|casual|labour|provident/i.test(text))
      return 'staffCosts';
    if (/finance expenses|interest expense|bank charge|finance cost|commission|e-levy|deposit insurance|interchange|foreign exchange loss/i.test(text))
      return 'financeCosts';
    if (/distribution|selling|marketing|advertising|carriage|freight out|showroom/i.test(text)) return 'distribution';
    return 'administrative';
  }

  if (type === 'Asset') {
    if (/accumulated depreciation|accumulated amortisation|accumulated amortization|impairment/i.test(name) && /(ppe|property|rou|right-of-use|equipment|vehicle|building)/i.test(text))
      return 'ppe';
    if (/right-of-use|rou asset/i.test(text)) return 'rou';
    if (/investment property/i.test(text)) return 'investmentProperty';
    if (/intangible|goodwill|exploration|concession|software|licence/i.test(text)) return 'intangibles';
    if (/investment|loans to related|subsidiar/i.test(text)) return 'investments';
    if (/deferred tax/i.test(text)) return 'deferredTaxAsset';
    if (/property|plant|equipment|land & building|vehicle|plant & machinery|site infrastructure|office equipment|computer/i.test(text)) return 'ppe';
    if (/inventor|stock|biological|spare part|work in progress|finished goods|raw material/i.test(text)) return 'inventories';
    if (/contract asset|unbilled/i.test(text)) return 'contractAssets';
    if (/prepaid|prepayment|deferred charge/i.test(text)) return 'prepayments';
    if (/tax|vat|withholding|customs/i.test(text)) return 'taxAsset';
    if (/cash|bank|mobile money|petty|till/i.test(text)) return 'cash';
    if (n >= 100 && n <= 109) return 'cash';
    return 'receivables';
  }

  // Liabilities
  if (/lease liab/i.test(text)) return 'leaseLiability';
  if (/deferred tax/i.test(text)) return 'deferredTaxLiability';
  if (/provision|decommission|litigation|claim/i.test(text)) return 'provisions';
  if (/dividend/i.test(text)) return 'dividends';
  if (/borrow|overdraft|loan|commercial/i.test(text)) return 'borrowings';
  if (/contract liabilit|advance from customer|unearned/i.test(text)) return 'contractLiabilities';
  if (/tax|vat|nhil|getfund|withheld|withholding|paye|levy|communication service|tourism/i.test(text)) return 'taxPayable';
  if (/payable|accru|grni|clearing/i.test(text)) return 'payables';
  return 'other';
}


/* ------------------------------------------------------------------ */
/* Pack                                                                */
/* ------------------------------------------------------------------ */

export function buildIfrsPack(input: PackInput): IfrsPack {
  const { lines, accounts, from, through, currency, entityName, entityCode, jurisdiction } = input;
  const byCode = new Map(accounts.map((a) => [a.accountNo, a]));

  const openingDay = new Date(`${from}T00:00:00Z`).getTime() - 86_400_000;
  const comparativeAsAt = new Date(openingDay).toISOString().slice(0, 10);
  const spanDays = Math.max(1, Math.round((Date.parse(`${through}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86_400_000));
  const comparativeFrom = new Date(Date.parse(`${from}T00:00:00Z`) - spanDays * 86_400_000).toISOString().slice(0, 10);
  const comparativeThrough = comparativeAsAt;

  const scoped = lines.filter((l) => l.date <= through);
  const positionRows = aggregateTrialBalance(scoped, accounts);
  const positionCompRows = aggregateTrialBalance(scoped.filter((l) => l.date <= comparativeThrough), accounts);
  const periodRows = aggregateTrialBalance(
    scoped.filter((l) => l.date >= from && l.date <= through),
    accounts,
  );
  const priorRows = aggregateTrialBalance(
    scoped.filter((l) => l.date >= comparativeFrom && l.date <= comparativeThrough),
    accounts,
  );

  /** Debit-normal net balance (major units) for the matching rows. */
  const net = (rows: TbRow[], pred: (g: Group) => boolean) =>
    r2(
      rows
        .filter((r) => pred(groupOf(byCode.get(r.code), r.code)))
        .reduce((n, r) => n + (r.dr - r.cr), 0) / 100,
    );
  const creditNet = (rows: TbRow[], pred: (g: Group) => boolean) => r2(-net(rows, pred));

  /** Movement across the period, per account group, from raw journal lines. */
  const movement = (pred: (g: Group, a?: AccountMaster) => boolean, direction: 'dr' | 'cr' | 'net' = 'net') => {
    const inPeriod = scoped.filter((l) => l.date >= from && l.date <= through);
    return r2(
      inPeriod
        .filter((l) => pred(groupOf(byCode.get(l.accountNo), l.accountNo), byCode.get(l.accountNo)))
        .reduce((n, l) => n + (direction === 'cr' ? minor(l.credit) - minor(l.debit) : direction === 'dr' ? minor(l.debit) - minor(l.credit) : minor(l.debit) - minor(l.credit)), 0) / 100,
    );
  };

  /* ---------------- Statement of financial position (IAS 1.54) ---- */

  const nca = (rows: TbRow[]) => ({
    ppe: r2(net(rows, (g) => g === 'ppe')),
    rou: r2(net(rows, (g) => g === 'rou')),
    intangibles: r2(net(rows, (g) => g === 'intangibles')),
    investmentProperty: r2(net(rows, (g) => g === 'investmentProperty')),
    investments: r2(net(rows, (g) => g === 'investments')),
    deferredTaxAsset: r2(net(rows, (g) => g === 'deferredTaxAsset')),
  });
  const ca = (rows: TbRow[]) => ({
    inventories: r2(net(rows, (g) => g === 'inventories')),
    receivables: r2(net(rows, (g) => g === 'receivables')),
    contractAssets: r2(net(rows, (g) => g === 'contractAssets')),
    prepayments: r2(net(rows, (g) => g === 'prepayments')),
    taxAsset: r2(net(rows, (g) => g === 'taxAsset')),
    cash: r2(net(rows, (g) => g === 'cash')),
    other: r2(net(rows, (g) => g === 'other')),
  });
  const eq = (rows: TbRow[]) => ({
    shareCapital: creditNet(rows, (g) => g === 'shareCapital'),
    sharePremium: creditNet(rows, (g) => g === 'sharePremium'),
    revaluationReserve: creditNet(rows, (g) => g === 'revaluationReserve'),
    translationReserve: creditNet(rows, (g) => g === 'translationReserve'),
    retainedEarnings: creditNet(rows, (g) => g === 'retainedEarnings'),
  });
  const ncl = (rows: TbRow[]) => {
    const borrowings = r2(-net(rows, (g) => g === 'borrowings') - net(rows, (g) => g === 'other'));
    return {
      borrowings: Math.abs(borrowings) < 0.005 ? 0 : borrowings,
      leaseLiability: creditNet(rows, (g) => g === 'leaseLiability'),
      deferredTaxLiability: creditNet(rows, (g) => g === 'deferredTaxLiability'),
      provisions: creditNet(rows, (g) => g === 'provisions'),
    };
  };
  const cl = (rows: TbRow[]) => {
    // IAS 1.69(d): the portion of lease liabilities falling due within twelve
    // months is current; the remainder is presented as non-current.
    const totalLease = creditNet(rows, (g) => g === 'leaseLiability');
    const nonCurrentLease = creditNet(rows, (g: Group) => g === 'leaseLiability');
    return {
      payables: creditNet(rows, (g) => g === 'payables'),
      contractLiabilities: creditNet(rows, (g) => g === 'contractLiabilities'),
      taxPayable: creditNet(rows, (g) => g === 'taxPayable'),
      dividends: creditNet(rows, (g) => g === 'dividends'),
      borrowings: creditNet(rows, (g) => g === 'borrowings'),
      leaseCurrent: r2(totalLease - nonCurrentLease),
    };
  };

  // Current / non-current split for borrowings and lease liabilities: the
  // portion falling due within twelve months is current (IAS 1.69).
  const cur = nca(positionRows);
  const curCA = ca(positionRows);
  const curEq = eq(positionRows);
  const curNCL = ncl(positionRows);
  const curCL = cl(positionRows);
  const cmp = nca(positionCompRows);
  const cmpCA = ca(positionCompRows);
  const cmpEq = eq(positionCompRows);
  const cmpNCL = ncl(positionCompRows);
  const cmpCL = cl(positionCompRows);

  const totalAssetsC = r2(Object.values(cur).reduce((n, v) => n + v, 0) + Object.values(curCA).reduce((n, v) => n + v, 0));
  const totalAssetsP = r2(Object.values(cmp).reduce((n, v) => n + v, 0) + Object.values(cmpCA).reduce((n, v) => n + v, 0));
  const totalEquityC = r2(Object.values(curEq).reduce((n, v) => n + v, 0));
  const totalEquityP = r2(Object.values(cmpEq).reduce((n, v) => n + v, 0));
  const totalLiabC = r2(Object.values(curNCL).reduce((n, v) => n + v, 0) + Object.values(curCL).reduce((n, v) => n + v, 0));
  const totalLiabP = r2(Object.values(cmpNCL).reduce((n, v) => n + v, 0) + Object.values(cmpCL).reduce((n, v) => n + v, 0));
  const balanced = Math.abs(totalAssetsC - r2(totalEquityC + totalLiabC)) < 0.02;

  const sfpRows = (
    label: string,
    a: number,
    b: number,
    note?: string,
    indent = false,
  ): IfrsRow => ({ label, current: a, comparative: b, note, indent });

  const position: IfrsStatement = {
    id: 'position',
    standard: 'IAS 1.54',
    title: 'Statement of financial position',
    subtitle: `As at ${through}`,
    columns: ['', currency, comparativeAsAt],
    blocks: [
      {
        title: 'Assets',
        rows: [],
        total: undefined,
      },
    ],
  };

  position.blocks = [
    {
      title: 'Non-current assets',
      rows: [
        sfpRows('Property, plant and equipment', cur.ppe, cmp.ppe, '6'),
        sfpRows('Right-of-use assets', cur.rou, cmp.rou, '7'),
        sfpRows('Intangible assets and goodwill', cur.intangibles, cmp.intangibles, '7'),
        sfpRows('Investment property', cur.investmentProperty, cmp.investmentProperty, '6'),
        sfpRows('Investments in subsidiaries and associates', cur.investments, cmp.investments, '18'),
        sfpRows('Deferred tax assets', cur.deferredTaxAsset, cmp.deferredTaxAsset, '15'),
      ].filter((r) => Math.abs(r.current) > 0.004 || Math.abs(r.comparative) > 0.004),
      total: {
        label: 'Total non-current assets',
        current: r2(cur.ppe + cur.rou + cur.intangibles + cur.investmentProperty + cur.investments + cur.deferredTaxAsset),
        comparative: r2(cmp.ppe + cmp.rou + cmp.intangibles + cmp.investmentProperty + cmp.investments + cmp.deferredTaxAsset),
        emphasis: 'sub',
      },
    },
    {
      title: 'Current assets',
      rows: [
        sfpRows('Inventories', curCA.inventories, cmpCA.inventories, '8'),
        sfpRows('Trade and other receivables', curCA.receivables, cmpCA.receivables, '9'),
        sfpRows('Contract assets', curCA.contractAssets, cmpCA.contractAssets, '5'),
        sfpRows('Prepayments and deferred charges', curCA.prepayments, cmpCA.prepayments, '9'),
        sfpRows('Current tax assets', curCA.taxAsset, cmpCA.taxAsset, '15'),
        sfpRows('Cash and cash equivalents', curCA.cash, cmpCA.cash, '10'),
      ].filter((r) => Math.abs(r.current) > 0.004 || Math.abs(r.comparative) > 0.004),
      total: {
        label: 'Total current assets',
        current: r2(curCA.inventories + curCA.receivables + curCA.contractAssets + curCA.prepayments + curCA.taxAsset + curCA.cash + curCA.other),
        comparative: r2(cmpCA.inventories + cmpCA.receivables + cmpCA.contractAssets + cmpCA.prepayments + cmpCA.taxAsset + cmpCA.cash + cmpCA.other),
        emphasis: 'sub',
      },
    },
    {
      title: 'Equity',
      rows: [
        sfpRows('Stated share capital', curEq.shareCapital, cmpEq.shareCapital, '16'),
        sfpRows('Share premium', curEq.sharePremium, cmpEq.sharePremium, '16'),
        sfpRows('Revaluation reserve', curEq.revaluationReserve, cmpEq.revaluationReserve, '16'),
        sfpRows('Foreign currency translation reserve', curEq.translationReserve, cmpEq.translationReserve, '16'),
        sfpRows('Retained earnings', curEq.retainedEarnings, cmpEq.retainedEarnings, '16'),
      ].filter((r) => Math.abs(r.current) > 0.004 || Math.abs(r.comparative) > 0.004),
      total: { label: 'Total equity', current: totalEquityC, comparative: totalEquityP, emphasis: 'sub' },
    },
    {
      title: 'Non-current liabilities',
      rows: [
        sfpRows('Borrowings', curNCL.borrowings, cmpNCL.borrowings, '12'),
        sfpRows('Lease liabilities', curNCL.leaseLiability, cmpNCL.leaseLiability, '14'),
        sfpRows('Provisions', curNCL.provisions, cmpNCL.provisions, '13'),
        sfpRows('Deferred tax liabilities', curNCL.deferredTaxLiability, cmpNCL.deferredTaxLiability, '15'),
      ].filter((r) => Math.abs(r.current) > 0.004 || Math.abs(r.comparative) > 0.004),
      total: {
        label: 'Total non-current liabilities',
        current: r2(curNCL.borrowings + curNCL.leaseLiability + curNCL.provisions + curNCL.deferredTaxLiability),
        comparative: r2(cmpNCL.borrowings + cmpNCL.leaseLiability + cmpNCL.provisions + cmpNCL.deferredTaxLiability),
        emphasis: 'sub',
      },
    },
    {
      title: 'Current liabilities',
      rows: [
        sfpRows('Trade and other payables', curCL.payables, cmpCL.payables, '11'),
        sfpRows('Contract liabilities', curCL.contractLiabilities, cmpCL.contractLiabilities, '5'),
        sfpRows('Borrowings and overdrafts', curCL.borrowings, cmpCL.borrowings, '12'),
        sfpRows('Lease liabilities — current portion', curCL.leaseCurrent, cmpCL.leaseCurrent, '14'),
        sfpRows('Current tax liabilities', curCL.taxPayable, cmpCL.taxPayable, '15'),
        sfpRows('Dividends payable', curCL.dividends, cmpCL.dividends, '17'),
      ].filter((r) => Math.abs(r.current) > 0.004 || Math.abs(r.comparative) > 0.004),
      total: {
        label: 'Total current liabilities',
        current: r2(curCL.payables + curCL.contractLiabilities + curCL.taxPayable + curCL.dividends + curCL.borrowings),
        comparative: r2(cmpCL.payables + cmpCL.contractLiabilities + cmpCL.taxPayable + cmpCL.dividends + cmpCL.borrowings),
        emphasis: 'sub',
      },
    },
    {
      rows: [
        {
          label: 'Total equity and liabilities',
          current: r2(totalEquityC + totalLiabC),
          comparative: r2(totalEquityP + totalLiabP),
          emphasis: 'grand',
        },
      ],
    },
    {
      rows: [
        { label: 'Total assets', current: totalAssetsC, comparative: totalAssetsP, emphasis: 'grand' },
        {
          label: balanced ? 'Statement of financial position balances' : 'OUT OF BALANCE — investigate before issue',
          current: r2(totalAssetsC - totalEquityC - totalLiabC),
          comparative: r2(totalAssetsP - totalEquityP - totalLiabP),
          emphasis: 'sub',
        },
      ],
    },
  ];

  /* ---------------- Profit or loss (IAS 1.82A) -------------------- */

  const pl = (rows: TbRow[]) => ({
    revenue: creditNet(rows, (g) => g === 'revenue'),
    otherIncome: creditNet(rows, (g) => g === 'otherIncome'),
    financeIncome: creditNet(rows, (g) => g === 'financeIncome'),
    costOfSales: net(rows, (g) => g === 'costOfSales'),
    staffCosts: net(rows, (g) => g === 'staffCosts'),
    depreciation: net(rows, (g) => g === 'depreciation'),
    distribution: net(rows, (g) => g === 'distribution'),
    administrative: net(rows, (g) => g === 'administrative'),
    financeCosts: net(rows, (g) => g === 'financeCosts'),
    taxExpense: net(rows, (g) => g === 'taxExpense'),
  });
  const p = pl(periodRows);
  const pPrior = pl(priorRows);

  const grossProfit = r2(p.revenue - p.costOfSales);
  const grossProfitPrior = r2(pPrior.revenue - pPrior.costOfSales);
  const operatingProfit = r2(grossProfit + p.otherIncome - p.staffCosts - p.depreciation - p.distribution - p.administrative);
  const operatingProfitPrior = r2(grossProfitPrior + pPrior.otherIncome - pPrior.staffCosts - pPrior.depreciation - pPrior.distribution - pPrior.administrative);
  const profitBeforeTax = r2(operatingProfit + p.financeIncome - p.financeCosts);
  const profitBeforeTaxPrior = r2(operatingProfitPrior + pPrior.financeIncome - pPrior.financeCosts);
  const profitForPeriod = r2(profitBeforeTax - p.taxExpense);
  const profitForPeriodPrior = r2(profitBeforeTaxPrior - pPrior.taxExpense);

  const profitStatement: IfrsStatement = {
    id: 'profit',
    standard: 'IAS 1.82A',
    title: 'Statement of profit or loss and other comprehensive income',
    subtitle: `For the period ${from} to ${through}`,
    columns: ['', currency, 'Comparative'],
    blocks: [
      {
        title: 'Profit or loss',
        rows: [
          { label: 'Revenue', current: p.revenue, comparative: pPrior.revenue, note: '5' },
          { label: 'Cost of sales', current: -p.costOfSales, comparative: -pPrior.costOfSales, note: '5' },
          { label: 'Gross profit', current: grossProfit, comparative: grossProfitPrior, emphasis: 'sub' },
          { label: 'Other income', current: p.otherIncome, comparative: pPrior.otherIncome, note: '5' },
          { label: 'Employee benefit expense', current: -p.staffCosts, comparative: -pPrior.staffCosts, note: '19' },
          { label: 'Depreciation and amortisation', current: -p.depreciation, comparative: -pPrior.depreciation, note: '6' },
          { label: 'Distribution costs', current: -p.distribution, comparative: -pPrior.distribution },
          { label: 'Administrative expenses', current: -p.administrative, comparative: -pPrior.administrative },
          { label: 'Profit from operations', current: operatingProfit, comparative: operatingProfitPrior, emphasis: 'sub' },
          { label: 'Finance income', current: p.financeIncome, comparative: pPrior.financeIncome, note: '19' },
          { label: 'Finance costs', current: -p.financeCosts, comparative: -pPrior.financeCosts, note: '19' },
          { label: 'Profit before income tax', current: profitBeforeTax, comparative: profitBeforeTaxPrior, emphasis: 'sub' },
          { label: 'Income tax expense', current: -p.taxExpense, comparative: -pPrior.taxExpense, note: '15' },
          { label: 'Profit for the period', current: profitForPeriod, comparative: profitForPeriodPrior, emphasis: 'total' },
        ],
      },
      {
        title: 'Other comprehensive income (IAS 1.82A)',
        rows: [],
      },
    ],
  };

  /* ---------------- Other comprehensive income -------------------- */

  const ociOf = (rows: TbRow[], prior: TbRow[], group: Group) => {
    const closing = creditNet(rows, (g) => g === group);
    const opening = creditNet(prior, (g) => g === group);
    return r2(closing - opening);
  };
  const revaluationOci = ociOf(positionRows, positionCompRows, 'revaluationReserve');
  const translationOci = ociOf(positionRows, positionCompRows, 'translationReserve');
  const totalOci = r2(revaluationOci + translationOci);
  const totalComprehensiveIncome = r2(profitForPeriod + totalOci);
  const totalComprehensiveIncomePrior = r2(profitForPeriodPrior);

  profitStatement.blocks[1] = {
    title: 'Other comprehensive income (IAS 1.82A)',
    rows: [
      {
        label: 'Items that may be reclassified subsequently to profit or loss',
        current: translationOci,
        comparative: 0,
        note: '16',
      },
      {
        label: 'Exchange differences on translating foreign operations',
        current: translationOci,
        comparative: 0,
        indent: true,
      },
      {
        label: 'Items that will not be reclassified subsequently to profit or loss',
        current: revaluationOci,
        comparative: 0,
        note: '16',
      },
      {
        label: 'Revaluation surplus on property, plant and equipment',
        current: revaluationOci,
        comparative: 0,
        indent: true,
      },
      { label: 'Other comprehensive income for the period, net of tax', current: totalOci, comparative: 0, emphasis: 'sub' },
      {
        label: 'Total comprehensive income for the period',
        current: totalComprehensiveIncome,
        comparative: totalComprehensiveIncomePrior,
        emphasis: 'total',
      },
      {
        label: 'Earnings per share — basic and diluted',
        current: profitForPeriod,
        comparative: profitForPeriodPrior,
        note: '21',
      },
    ],
  };

  /* ---------------- Changes in equity (IAS 1.106) ----------------- */

  const equityColumns = [
    { key: 'shareCapital', label: 'Stated share capital', group: 'shareCapital' as Group },
    { key: 'sharePremium', label: 'Share premium', group: 'sharePremium' as Group },
    { key: 'revaluation', label: 'Revaluation reserve', group: 'revaluationReserve' as Group },
    { key: 'translation', label: 'Translation reserve', group: 'translationReserve' as Group },
    { key: 'retained', label: 'Retained earnings', group: 'retainedEarnings' as Group },
  ];

  const equityAt = (rows: TbRow[]) =>
    equityColumns.map((c) => creditNet(rows, (g) => g === c.group));

  const openEq = equityAt(positionCompRows);
  const closeEq = equityAt(positionRows);

  const dividends = r2(movement((g) => g === 'dividends', 'cr'));
  const shareIssues = r2(movement((g) => g === 'shareCapital' || g === 'sharePremium', 'cr'));



  // The matrix is rendered by the desk as its own grid; the statement carries
  // the per-column deltas so the print output is a true IAS 1.106 matrix.
  const sceMatrix: Array<{ label: string; values: number[]; total: number; emphasis?: IfrsRow['emphasis'] }> = [
    { label: `Balance at ${comparativeAsAt}`, values: openEq, total: r2(openEq.reduce((n, v) => n + v, 0)), emphasis: 'sub' },
    {
      label: 'Profit for the period',
      values: [0, 0, 0, 0, profitForPeriod],
      total: profitForPeriod,
    },
    {
      label: 'Other comprehensive income',
      values: [0, 0, revaluationOci, translationOci, 0],
      total: totalOci,
    },
    {
      label: 'Total comprehensive income',
      values: [0, 0, revaluationOci, translationOci, profitForPeriod],
      total: totalComprehensiveIncome,
      emphasis: 'sub',
    },
    {
      label: 'Dividends declared',
      values: [0, 0, 0, 0, -dividends],
      total: -dividends,
    },
    {
      label: 'Shares issued / other equity movements',
      values: equityColumns.map((_, i) => r2(closeEq[i] - openEq[i] - (i === 2 ? revaluationOci : i === 3 ? translationOci : i === 4 ? profitForPeriod - -dividends * 0 : 0) - (i === 4 ? -dividends : 0))),
      total: 0,
    },
    { label: `Balance at ${through}`, values: closeEq, total: r2(closeEq.reduce((n, v) => n + v, 0)), emphasis: 'total' },
  ];
  // The residual "other movements" line is derived, so the matrix always
  // reconciles to the closing balances whatever the entity did in the period.
  // Reconciling movement: closing balance less the opening balance, the total
  // comprehensive income of the period and the distributions to owners. What
  // remains is share issues and any other movement in equity, so the matrix
  // always ties back to the statement of financial position.
  const derived = sceMatrix[5];
  derived.values = equityColumns.map((_, i) =>
    r2(closeEq[i] - (openEq[i] + (sceMatrix[3].values[i] ?? 0) + (sceMatrix[4].values[i] ?? 0))),
  );
  derived.total = r2(derived.values.reduce((n, v) => n + v, 0));

  const equityStatement: IfrsStatement = {
    id: 'equity',
    standard: 'IAS 1.106',
    title: 'Statement of changes in equity',
    subtitle: `For the period ${from} to ${through}`,
    columns: ['', currency, 'Total'],
    blocks: [
      {
        rows: sceMatrix.map((m) => ({
          label: m.label,
          current: m.total,
          comparative: 0,
          emphasis: m.emphasis,
        })),
      },
    ],
    matrix: {
      columns: equityColumns.map((c) => c.label),
      rows: sceMatrix,
    },
  };
  /* ---------------- Cash flows (IAS 7, indirect) ------------------ */

  const cf = buildCashFlow(scoped, accounts, from, through);
  const netDebtNow = r2(
    creditNet(positionRows, (g) => g === 'borrowings' || g === 'leaseLiability') - net(positionRows, (g) => g === 'cash'),
  );
  const netDebtThen = r2(
    creditNet(positionCompRows, (g) => g === 'borrowings' || g === 'leaseLiability') - net(positionCompRows, (g) => g === 'cash'),
  );

  const cashFlowStatement: IfrsStatement = {
    id: 'cashflow',
    standard: 'IAS 7.10',
    title: 'Statement of cash flows',
    subtitle: `For the period ${from} to ${through} — indirect method`,
    columns: ['', currency, 'Comparative'],
    blocks: [
      {
        title: 'Cash flows from operating activities',
        rows: [
          { label: 'Profit before taxation', current: cf.profitBeforeTax, comparative: profitBeforeTaxPrior },
          { label: 'Depreciation and amortisation', current: p.depreciation, comparative: pPrior.depreciation },
          { label: 'Finance costs', current: p.financeCosts, comparative: pPrior.financeCosts },
          { label: 'Investment income', current: -p.financeIncome, comparative: -pPrior.financeIncome },
          { label: 'Working capital movements', current: r2(cf.deltaPayables - cf.deltaReceivables - cf.deltaInventory - cf.deltaPrepaids), comparative: 0 },
          { label: 'Increase in trade and other receivables', current: -cf.deltaReceivables, comparative: 0, indent: true },
          { label: 'Increase in inventories', current: -cf.deltaInventory, comparative: 0, indent: true },
          { label: 'Increase in prepayments', current: -cf.deltaPrepaids, comparative: 0, indent: true },
          { label: 'Increase in trade and other payables', current: cf.deltaPayables, comparative: 0, indent: true },
          { label: 'Cash generated from operations', current: cf.operating, comparative: 0, emphasis: 'sub' },
          { label: 'Net cash from operating activities', current: cf.operating, comparative: 0, emphasis: 'total' },
        ],
      },
      {
        title: 'Cash flows from investing activities',
        rows: [
          { label: 'Purchase of property, plant and equipment', current: cf.investing, comparative: 0 },
          { label: 'Net cash used in investing activities', current: cf.investing, comparative: 0, emphasis: 'total' },
        ],
      },
      {
        title: 'Cash flows from financing activities',
        rows: [
          { label: 'Proceeds from / (repayment of) borrowings and leases', current: cf.financing, comparative: 0 },
          { label: 'Dividends paid', current: r2(-dividends), comparative: 0 },
          { label: 'Net cash from financing activities', current: cf.financing, comparative: 0, emphasis: 'total' },
        ],
      },
      {
        title: 'Net increase in cash and cash equivalents',
        rows: [
          { label: 'Net increase in cash and cash equivalents', current: cf.cashMovement, comparative: 0, emphasis: 'sub' },
          { label: 'Cash and cash equivalents at beginning of period', current: cf.openingCash, comparative: 0 },
          { label: 'Cash and cash equivalents at end of period', current: cf.closingCash, comparative: 0, emphasis: 'total' },
        ],
      },
      {
        title: 'Reconciliation of net debt (IAS 7.44)',
        rows: [
          { label: 'Net debt at beginning of period', current: netDebtThen, comparative: 0 },
          { label: 'Net cash movement in the period', current: r2(-cf.cashMovement), comparative: 0 },
          { label: 'Net increase / (decrease) in borrowings and leases', current: r2(cf.financing), comparative: 0 },
          { label: 'Net debt at end of period', current: netDebtNow, comparative: 0, emphasis: 'total' },
        ],
      },
    ],
  };

  /* ---------------- Notes ----------------------------------------- */

  const fmt = (n: number) =>
    n.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  // PPE movement note from the raw journal (IAS 16.73).
  const costCodes = new Set(accounts.filter((a) => groupOf(a, a.accountNo) === 'ppe' && !/accumulated|impairment/i.test(a.name)).map((a) => a.accountNo));
  const accumCodes = new Set(accounts.filter((a) => /accumulated|impairment/i.test(a.name)).map((a) => a.accountNo));
  const costClosing = r2(net(positionRows, (g) => g === 'ppe'));
  const costOpening = r2(net(positionCompRows, (g) => g === 'ppe'));
  const additions = r2(
    (scoped.filter((l) => l.date >= from && costCodes.has(l.accountNo)).reduce((n, l) => n + minor(l.debit), 0)) / 100,
  );
  const depreciationCharge = r2(
    (scoped.filter((l) => l.date >= from && accumCodes.has(l.accountNo)).reduce((n, l) => n + minor(l.credit) - minor(l.debit), 0)) / 100,
  );
  const disposals = r2(
    (scoped.filter((l) => l.date >= from && costCodes.has(l.accountNo)).reduce((n, l) => n + minor(l.credit), 0)) / 100,
  );

  // Revenue disaggregation (IFRS 15.114) straight from the revenue accounts.
  const revenueLines = aggregateTrialBalance(scoped.filter((l) => l.date >= from), accounts).filter(
    (r) => groupOf(byCode.get(r.code), r.code) === 'revenue',
  );
  const revenueComparative = aggregateTrialBalance(
    scoped.filter((l) => l.date >= comparativeFrom && l.date <= comparativeThrough),
    accounts,
  ).filter((r) => groupOf(byCode.get(r.code), r.code) === 'revenue');

  const revenueTable = revenueLines.map((r) => {
    const priorRow = revenueComparative.find((q) => q.code === r.code);
    return [r.name, r2((r.cr - r.dr) / 100), r2(priorRow ? (priorRow.cr - priorRow.dr) / 100 : 0)];
  });

  const statutoryRate = 25; // Ghana company income tax standard rate (GRA)
  const effectiveRate = profitBeforeTax > 0 ? r2((p.taxExpense / profitBeforeTax) * 100 * 100) / 100 : 0;

  const notes: IfrsNote[] = [
    {
      number: 1,
      title: 'Corporate information',
      standard: 'IAS 1.122(a)',
      paragraphs: [
        `${entityName} (entity code ${entityCode}) is a company incorporated and operating in ${jurisdiction}${input.regNumber ? `, registration number ${input.regNumber}` : ''}. The registered office and principal place of business is as recorded in the company profile maintained in this system.`,
        `These financial statements were authorised for issue by the Board of Directors on ${through}. They cover the reporting period ${from} to ${through} and are presented in ${currency}, which is the functional currency of the entity.`,
      ],
    },
    {
      number: 2,
      title: 'Basis of preparation and statement of compliance',
      standard: 'IAS 1.117–124',
      paragraphs: [
        `These general purpose financial statements have been prepared in accordance with International Financial Reporting Standards (IFRS) as issued by the International Accounting Standards Board. They comply with IAS 1 Presentation of Financial Statements, IAS 7 Statement of Cash Flows and the recognition and measurement requirements of the standards listed in note 3.`,
        `The financial statements have been prepared under the historical cost convention, as modified by the revaluation of property, plant and equipment where an entity policy election is disclosed in note 3. Assets and liabilities are classified as current or non-current in accordance with IAS 1.66–76.`,
        `Comparative information is presented for every amount shown in these statements, as required by IAS 1.38. The comparative statement of financial position is the position at ${comparativeAsAt}; the comparative performance column covers ${comparativeFrom} to ${comparativeThrough}.`,
        balanced
          ? 'The statement of financial position balances: total assets equal total equity and liabilities.'
          : 'WARNING — the statement of financial position does not balance. The classification of the chart of accounts must be corrected before these statements are issued.',
      ],
    },
    {
      number: 3,
      title: 'Significant accounting policies',
      standard: 'IAS 1.117–124',
      paragraphs: [
        'The accounting policies set out below have been applied consistently to all periods presented, unless otherwise stated.',
      ],
    },
    {
      number: 4,
      title: 'Critical judgements and key sources of estimation uncertainty',
      standard: 'IAS 1.122/125',
      paragraphs: [
        'In applying the entity’s accounting policies, management exercises judgement in the classification of leases between finance and operating arrangements, in the recognition of revenue over time on service contracts, and in the recoverability of receivables measured under the expected credit loss model of IFRS 9.',
        'Key assumptions about the future, and other key sources of estimation uncertainty at the reporting date, relate to the useful lives and residual values of property, plant and equipment (IAS 16), the measurement of provisions for decommissioning and litigation (IAS 37), the discount rate applied to lease liabilities (IFRS 16), and the recognition of deferred tax assets on unused tax losses (IAS 12). Estimates are reviewed at each reporting date; changes are accounted for prospectively as a change in estimate under IAS 8.',
      ],
    },
    {
      number: 5,
      title: 'Revenue and contract balances',
      standard: 'IFRS 15',
      paragraphs: [
        'Revenue is recognised when control of the promised goods or services transfers to the customer, in an amount that reflects the consideration to which the entity expects to be entitled. For the sale of goods, control transfers on delivery; for services and professional fees, revenue is recognised over time as the performance obligation is satisfied, measured by progress towards complete satisfaction.',
        'Contract liabilities represent consideration received or receivable before the related performance obligation is satisfied; they are recognised as revenue when the obligation is satisfied. Contract assets represent revenue already recognised where the right to consideration is conditional on something other than the passage of time.',
      ],
      table: {
        columns: ['Disaggregation of revenue', 'Current period', 'Comparative'],
        rows: revenueTable.length ? revenueTable : [['No revenue recognised in the period', 0, 0]],
        totals: ['Total revenue', p.revenue, pPrior.revenue],
      },
    },
    {
      number: 6,
      title: 'Property, plant and equipment',
      standard: 'IAS 16',
      paragraphs: [
        'Property, plant and equipment is stated at cost less accumulated depreciation and any accumulated impairment losses. Cost includes expenditure that is directly attributable to bringing the asset to the location and condition necessary for it to be capable of operating in the manner intended by management.',
        'Depreciation is charged on a straight-line basis over the estimated useful lives of the assets: buildings 25–50 years, plant and machinery 8–15 years, vehicles 5 years, office equipment and computers 3–5 years. Land is not depreciated. Useful lives, residual values and depreciation methods are reviewed at each reporting date (IAS 16.51).',
        'An asset is derecognised on disposal or when no future economic benefits are expected from its use. Gains and losses on derecognition are taken to profit or loss in the period of disposal (IAS 16.68).',
      ],
      table: {
        columns: ['Movement in the period', currency],
        rows: [
          ['Carrying amount at start of period', costOpening],
          ['Additions', additions],
          ['Disposals', -disposals],
          ['Depreciation charge for the period', -depreciationCharge],
          ['Carrying amount at end of period', costClosing],
        ],
        totals: undefined,
      },
    },
    {
      number: 7,
      title: 'Intangible assets, right-of-use assets and leases',
      standard: 'IAS 38 / IFRS 16',
      paragraphs: [
        'Intangible assets acquired separately are measured at cost and amortised over their useful lives, generally three to ten years. Internally generated goodwill is not recognised (IAS 38.48).',
        'Under IFRS 16 the entity recognises a right-of-use asset and a lease liability for leases of property, plant and equipment, unless the lease term is twelve months or less or the underlying asset is of low value. The lease liability is measured at the present value of the lease payments, discounted at the interest rate implicit in the lease or the entity’s incremental borrowing rate. Right-of-use assets are depreciated over the shorter of the lease term and the useful life of the asset.',
      ],
    },
    {
      number: 8,
      title: 'Inventories',
      standard: 'IAS 2',
      paragraphs: [
        'Inventories are stated at the lower of cost and net realisable value. Cost is determined on a weighted average basis and includes all costs of purchase and costs of conversion. Net realisable value is the estimated selling price in the ordinary course of business less the estimated costs of completion and the estimated costs necessary to make the sale.',
      ],
    },
    {
      number: 9,
      title: 'Trade and other receivables',
      standard: 'IFRS 9',
      paragraphs: [
        'Trade receivables are recognised initially at the transaction price and subsequently measured at amortised cost using the effective interest method, less an allowance for expected credit losses. The expected credit loss allowance is measured on a lifetime basis for trade receivables, using a provision matrix based on historical default rates adjusted for forward-looking information (IFRS 9.5.5.15).',
      ],
    },
    {
      number: 10,
      title: 'Cash and cash equivalents',
      standard: 'IAS 7.7',
      paragraphs: [
        'Cash and cash equivalents comprise cash on hand, demand deposits and short-term highly liquid investments that are readily convertible to known amounts of cash and are subject to an insignificant risk of changes in value. Bank overdrafts that form an integral part of cash management are presented within current borrowings and are deducted from cash in the reconciliation of net debt.',
      ],
    },
    {
      number: 11,
      title: 'Trade and other payables',
      standard: 'IFRS 9',
      paragraphs: [
        'Trade payables are obligations to pay for goods or services that have been acquired in the ordinary course of business from suppliers. They are classified as current liabilities if payment is due within twelve months and are measured initially at fair value and subsequently at amortised cost.',
      ],
    },
    {
      number: 12,
      title: 'Borrowings and finance costs',
      standard: 'IAS 23 / IFRS 9',
      paragraphs: [
        'Borrowings are recognised initially at fair value, net of transaction costs, and subsequently at amortised cost using the effective interest method. Borrowings are classified as current when the entity does not have an unconditional right to defer settlement for at least twelve months after the reporting date (IAS 1.69(d)).',
        'Finance costs are recognised in profit or loss in the period in which they are incurred, except to the extent that they are capitalised as part of the cost of a qualifying asset under IAS 23.26.',
      ],
    },
    {
      number: 13,
      title: 'Provisions and contingencies',
      standard: 'IAS 37',
      paragraphs: [
        'A provision is recognised when the entity has a present obligation (legal or constructive) as a result of a past event, it is probable that an outflow of resources will be required to settle the obligation, and a reliable estimate can be made. Provisions are discounted where the effect of the time value of money is material (IAS 37.45).',
        'A contingent liability is disclosed but not recognised where a possible obligation exists, or a present obligation that is not recognised because an outflow is not probable or cannot be measured reliably (IAS 37.86).',
      ],
    },
    {
      number: 14,
      title: 'Lease liabilities',
      standard: 'IFRS 16.26',
      paragraphs: [
        'Lease liabilities are measured at the present value of the lease payments not paid at the commencement date, discounted using the interest rate implicit in the lease or the entity’s incremental borrowing rate. They are remeasured when the lease payments change, when the assessment of a purchase option changes, or when a change in the expected period of a termination option occurs.',
      ],
    },
    {
      number: 15,
      title: 'Income taxes',
      standard: 'IAS 12',
      paragraphs: [
        `Current income tax is the expected tax payable on the taxable profit for the period, using tax rates enacted or substantively enacted at the reporting date. The standard rate of company income tax in ${jurisdiction} is ${statutoryRate}%.`,
        'Deferred tax is recognised on temporary differences between the carrying amounts of assets and liabilities and their tax bases, except for initial recognition of goodwill and for differences arising on transactions that affect neither accounting nor taxable profit. Deferred tax assets are recognised only to the extent that it is probable that future taxable profits will be available (IAS 12.24).',
      ],
      table: {
        columns: ['Tax reconciliation', currency],
        rows: [
          ['Profit before tax', profitBeforeTax],
          ['Tax at the statutory rate', r2((profitBeforeTax * statutoryRate) / 100)],
          ['Tax effect of non-deductible expenses and adjustments', r2(p.taxExpense - (profitBeforeTax * statutoryRate) / 100)],
          ['Total income tax expense', p.taxExpense],
        ],
      },
    },
    {
      number: 16,
      title: 'Share capital, reserves and dividends',
      standard: 'IAS 1 / IAS 32',
      paragraphs: [
        'Stated share capital represents the nominal value of issued ordinary shares. Share premium represents consideration received in excess of nominal value. The revaluation reserve contains unrealised surpluses recognised under the revaluation model; the translation reserve contains exchange differences arising on translating foreign operations (IAS 21).',
        `Dividends declared during the period amounted to ${fmt(dividends)} ${currency} and are presented as a distribution of equity (IAS 10.12). They are recorded in the statement of changes in equity and, where approved after the reporting date, are disclosed as a non-adjusting event.`,
      ],
    },
    {
      number: 17,
      title: 'Dividends',
      standard: 'IAS 10.12',
      paragraphs: [
        `Dividends payable at the reporting date total ${fmt(curCL.dividends)} ${currency} (comparative ${fmt(cmpCL.dividends)}). Dividends recognised as a distribution during the period total ${fmt(dividends)} ${currency}.`,
      ],
    },
    {
      number: 18,
      title: 'Related party transactions',
      standard: 'IAS 24',
      paragraphs: [
        'Transactions with related parties — key management personnel, entities under common control, and close members of the families of key management personnel — are entered into in the ordinary course of business on arm’s length terms. Balances and transactions with related parties, including loans to related parties, intercompany service fees and key management compensation, must be disclosed in this note before the statements are issued.',
        'Key management compensation is disclosed by category: short-term employee benefits, post-employment benefits, and share-based payment (IAS 24.17).',
      ],
    },
    {
      number: 19,
      title: 'Financial instruments and risk management',
      standard: 'IFRS 7 / IFRS 9',
      paragraphs: [
        'The entity is exposed to market risk (including foreign currency and interest rate risk), credit risk and liquidity risk through its financial assets and financial liabilities. Management reviews and agrees policies for managing each of these risks and they are summarised below.',
        'Credit risk is managed by dealing with established counterparties, applying credit limits and monitoring ageing of receivables. Liquidity risk is managed by monitoring forecast cash flows and maintaining adequate borrowing facilities. Market risk arising from foreign currency exposure is managed by matching receipts and payments in the same currency wherever practicable.',
      ],
      table: {
        columns: ['Risk exposure at reporting date', currency],
        rows: [
          ['Cash and cash equivalents', curCA.cash],
          ['Trade and other receivables', curCA.receivables],
          ['Borrowings and lease liabilities', r2(-netDebtNow - curCA.cash < 0 ? netDebtNow + curCA.cash : netDebtNow)],
          ['Net debt', netDebtNow],
        ],
      },
    },
    {
      number: 20,
      title: 'Segment information',
      standard: 'IFRS 8',
      paragraphs: [
        `The chief operating decision maker reviews financial information for the entity as a single operating segment${input.sector ? ` (${input.sector})` : ''} in ${jurisdiction}. No separate reportable segments have been identified; all revenue is generated in the entity’s country of domicile and no single customer accounts for more than 10% of revenue.`,
      ],
    },
    {
      number: 21,
      title: 'Earnings per share',
      standard: 'IAS 33',
      paragraphs: [
        'Basic earnings per share is calculated by dividing the profit attributable to ordinary shareholders by the weighted average number of ordinary shares outstanding during the period. No potentially dilutive instruments are outstanding, so basic and diluted earnings per share are the same (IAS 33.66).',
      ],
      table: {
        columns: ['Earnings per share', 'Amount'],
        rows: [
          ['Profit attributable to ordinary shareholders', profitForPeriod],
          ['Weighted average number of ordinary shares', '—'],
          ['Basic and diluted earnings per share (currency)', profitForPeriod],
        ],
      },
    },
    {
      number: 22,
      title: 'Events after the reporting date',
      standard: 'IAS 10',
      paragraphs: [
        'Events occurring after the reporting date are reviewed up to the date the financial statements are authorised for issue. Adjusting events are reflected in the amounts recognised; material non-adjusting events are disclosed with an estimate of their financial effect or a statement that such an estimate cannot be made.',
      ],
    },
    {
      number: 23,
      title: 'Going concern',
      standard: 'IAS 1.25',
      paragraphs: [
        'The directors have assessed the entity’s ability to continue as a going concern over the period of at least twelve months from the date of authorisation of these financial statements, taking into account forecast cash flows, available banking facilities and the maturity profile of liabilities.',
        balanced && curCA.cash + curCA.receivables > totalLiabC
          ? 'On the basis of current and forecast cash flows, the entity expects to meet its liabilities as they fall due and the financial statements continue to be prepared on a going concern basis.'
          : 'Management attention is required: current liquid resources should be assessed against liabilities falling due within twelve months before the going concern statement is signed off. See the control checks in the IFRS compliance review.',
      ],
    },
    {
      number: 24,
      title: 'Capital management and liquidity',
      standard: 'IAS 1.134',
      paragraphs: [
        'The entity’s objective when managing capital is to safeguard its ability to continue as a going concern while maximising the return to shareholders through an appropriate balance of debt and equity. Capital is monitored using the gearing ratio and the current ratio below.',
      ],
      table: {
        columns: ['Capital and liquidity measure', 'Current', 'Comparative'],
        rows: [
          ['Total equity', totalEquityC, totalEquityP],
          ['Borrowings and lease liabilities', r2(netDebtNow + curCA.cash), r2(netDebtThen + cmpCA.cash)],
          ['Net debt', netDebtNow, netDebtThen],
          ['Working capital (current assets less current liabilities)', r2(Object.values(curCA).reduce((n, v) => n + v, 0) - Object.values(curCL).reduce((n, v) => n + v, 0)), r2(Object.values(cmpCA).reduce((n, v) => n + v, 0) - Object.values(cmpCL).reduce((n, v) => n + v, 0))],
        ],
      },
    },
  ];

  // note 3 carries the policy grid as its table
  notes[2].table = {
    columns: ['Policy', 'Standard', 'Measurement basis'],
    rows: [
      ['Revenue from contracts with customers', 'IFRS 15', 'Transaction price, recognised as performance obligations are satisfied'],
      ['Property, plant and equipment', 'IAS 16', 'Cost less accumulated depreciation and impairment'],
      ['Intangible assets', 'IAS 38', 'Cost less amortisation; indefinite life tested for impairment'],
      ['Inventories', 'IAS 2', 'Lower of weighted average cost and net realisable value'],
      ['Leases (lessee)', 'IFRS 16', 'Right-of-use asset and lease liability at present value of lease payments'],
      ['Financial instruments', 'IFRS 9', 'Amortised cost / fair value through profit or loss'],
      ['Employee benefits', 'IAS 19', 'Defined contribution recognised as incurred; defined benefit actuarially measured'],
      ['Provisions', 'IAS 37', 'Best estimate of the expenditure required to settle the obligation'],
      ['Income tax', 'IAS 12', 'Current and deferred tax at rates enacted at the reporting date'],
      ['Foreign currency', 'IAS 21', 'Functional currency translation at closing rate; differences in OCI'],
      ['Borrowing costs', 'IAS 23', 'Expensed, except capitalised on qualifying assets'],
      ['Government grants', 'IAS 20', 'Recognised when there is reasonable assurance of compliance'],
    ],
  };

  /* ---------------- Ratios (IAS 1.60 / IAS 1.134) ----------------- */

  const ratio = (label: string, a: number, b: number, basis: string, ref: string, unit = ''): RatioRow => ({
    label,
    current: `${a.toFixed(2)}${unit}`,
    comparative: `${b.toFixed(2)}${unit}`,
    basis,
    ref,
  });
  const currentAssetsTotal = r2(Object.values(curCA).reduce((n, v) => n + v, 0));
  const currentLiabsTotal = r2(Object.values(curCL).reduce((n, v) => n + v, 0));
  const currentAssetsTotalP = r2(Object.values(cmpCA).reduce((n, v) => n + v, 0));
  const currentLiabsTotalP = r2(Object.values(cmpCL).reduce((n, v) => n + v, 0));
  const safeDiv = (a: number, b: number) => (Math.abs(b) < 0.005 ? 0 : a / b);

  const ratios: RatioRow[] = [
    ratio('Current ratio', safeDiv(currentAssetsTotal, currentLiabsTotal), safeDiv(currentAssetsTotalP, currentLiabsTotalP), 'Current assets ÷ current liabilities', 'IAS 1.60'),
    ratio('Quick ratio (acid test)', safeDiv(r2(currentAssetsTotal - curCA.inventories), currentLiabsTotal), safeDiv(r2(currentAssetsTotalP - cmpCA.inventories), currentLiabsTotalP), '(Current assets − inventories) ÷ current liabilities', 'IAS 1.60'),
    ratio('Gearing ratio', safeDiv(r2(netDebtNow + curCA.cash), r2(totalEquityC + netDebtNow + curCA.cash)) * 100, safeDiv(r2(netDebtThen + cmpCA.cash), r2(totalEquityP + netDebtThen + cmpCA.cash)) * 100, 'Borrowings ÷ (equity + borrowings)', 'IAS 1.134', '%'),
    ratio('Interest cover', safeDiv(profitBeforeTax, p.financeCosts), safeDiv(profitBeforeTaxPrior, pPrior.financeCosts), 'Profit before tax ÷ finance costs', 'IAS 1.134'),
    ratio('Gross profit margin', safeDiv(grossProfit, p.revenue) * 100, safeDiv(grossProfitPrior, pPrior.revenue) * 100, 'Gross profit ÷ revenue', 'IFRS 15', '%'),
    ratio('Net profit margin', safeDiv(profitForPeriod, p.revenue) * 100, safeDiv(profitForPeriodPrior, pPrior.revenue) * 100, 'Profit for the period ÷ revenue', 'IAS 1.85', '%'),
    ratio('Return on equity', safeDiv(profitForPeriod, totalEquityC) * 100, safeDiv(profitForPeriodPrior, totalEquityP) * 100, 'Profit for the period ÷ total equity', 'IAS 1.134', '%'),
    ratio('Effective tax rate', effectiveRate, safeDiv(pPrior.taxExpense, profitBeforeTaxPrior) * 100, 'Income tax expense ÷ profit before tax', 'IAS 12.81', '%'),
  ];

  /* ---------------- Live control checks --------------------------- */

  const checks: ControlCheck[] = [];
  const addCheck = (c: ControlCheck) => checks.push(c);

  // 1. Trial balance
  const totalDr = r2(positionRows.reduce((n, r) => n + r.dr, 0) / 100);
  const totalCr = r2(positionRows.reduce((n, r) => n + r.cr, 0) / 100);
  addCheck({
    id: 'tb-balance',
    severity: Math.abs(totalDr - totalCr) < 0.02 ? 'pass' : 'critical',
    area: 'Ledger integrity',
    standard: 'IAS 1.10',
    title: 'Trial balance — total debits equal total credits',
    detail: `Total debits ${fmt(totalDr)} ${currency} against total credits ${fmt(totalCr)} ${currency} (difference ${fmt(totalDr - totalCr)}).`,
    action:
      Math.abs(totalDr - totalCr) < 0.02
        ? 'No action — the ledger is in balance.'
        : 'Locate the unbalanced documents in the Universal Journal and post the correcting entry before any report is issued.',
  });

  // 2. Document-level balance
  const docTotals = new Map<string, { dr: number; cr: number }>();
  for (const l of scoped) {
    const t = docTotals.get(l.docNo) ?? { dr: 0, cr: 0 };
    t.dr += minor(l.debit);
    t.cr += minor(l.credit);
    docTotals.set(l.docNo, t);
  }
  const unbalancedDocs = [...docTotals.entries()].filter(([, t]) => Math.abs(t.dr - t.cr) >= 1);
  addCheck({
    id: 'doc-balance',
    severity: unbalancedDocs.length === 0 ? 'pass' : 'critical',
    area: 'Journal control',
    standard: 'Double entry',
    title: 'Every posted document is balanced',
    detail:
      unbalancedDocs.length === 0
        ? `${docTotals.size} document(s) checked; each one balances.`
        : `${unbalancedDocs.length} document(s) do not balance: ${unbalancedDocs
            .slice(0, 6)
            .map(([no, t]) => `${no} (${fmt((t.dr - t.cr) / 100)})`)
            .join(', ')}.`,
    action:
      unbalancedDocs.length === 0
        ? 'No action.'
        : 'Open each document in the General Ledger, correct the amounts and re-post; a statutory report cannot be built on an unbalanced journal.',
  });

  // 3. Single-line documents
  const lineCounts = new Map<string, number>();
  for (const l of scoped) lineCounts.set(l.docNo, (lineCounts.get(l.docNo) ?? 0) + 1);
  const singleLine = [...lineCounts.entries()].filter(([, c]) => c < 2);
  addCheck({
    id: 'single-line',
    severity: singleLine.length === 0 ? 'pass' : 'warning',
    area: 'Journal control',
    standard: 'Double entry',
    title: 'No single-sided journal documents',
    detail:
      singleLine.length === 0
        ? 'Every document carries at least one debit and one credit line.'
        : `${singleLine.length} document(s) have fewer than two lines: ${singleLine.slice(0, 6).map(([d]) => d).join(', ')}.`,
    action: singleLine.length === 0 ? 'No action.' : 'Complete or reverse the one-sided documents.',
  });

  // 4. Unknown accounts
  const unknown = [...new Set(scoped.map((l) => l.accountNo))].filter((code) => !byCode.has(code));
  addCheck({
    id: 'unknown-accounts',
    severity: unknown.length === 0 ? 'pass' : 'warning',
    area: 'Master data',
    standard: 'IAS 1.122',
    title: 'Every posted account exists in the chart of accounts',
    detail:
      unknown.length === 0
        ? 'All journal lines map to a defined general ledger account.'
        : `Journal lines reference account(s) missing from the chart: ${unknown.slice(0, 8).join(', ')}.`,
    action:
      unknown.length === 0
        ? 'No action.'
        : 'Add the accounts to the chart (with the correct IFRS classification) or re-post the lines to valid accounts.',
  });

  // 5. Statement of financial position
  addCheck({
    id: 'sfp-balance',
    severity: balanced ? 'pass' : 'critical',
    area: 'Financial statements',
    standard: 'IAS 1.27',
    title: 'Statement of financial position balances',
    detail: `Total assets ${fmt(totalAssetsC)} against total equity and liabilities ${fmt(r2(totalEquityC + totalLiabC))}.`,
    action: balanced ? 'No action.' : 'Check the classification of equity and profit-carrying accounts in the chart of accounts.',
  });

  // 6. Cash flow classification
  addCheck({
    id: 'cashflow-residual',
    severity: Math.abs(cf.residual) < 0.05 ? 'pass' : 'warning',
    area: 'Financial statements',
    standard: 'IAS 7.18',
    title: 'Cash flow statement fully explains the movement in cash',
    detail: `Net change per the statement ${fmt(cf.netChange)} against the movement in cash accounts ${fmt(cf.cashMovement)}; residual ${fmt(cf.residual)}.`,
    action:
      Math.abs(cf.residual) < 0.05
        ? 'No action.'
        : 'Extend the investing and financing account groups in the cash flow mapping so every cash movement is classified.',
  });

  // 7. Comparatives
  const hasComparative = priorRows.length > 0 || positionCompRows.length > 0;
  addCheck({
    id: 'comparatives',
    severity: hasComparative ? 'pass' : 'warning',
    area: 'Financial statements',
    standard: 'IAS 1.38',
    title: 'Comparative information is available',
    detail: hasComparative
      ? `Comparatives drawn from the ledger for ${comparativeFrom} to ${comparativeThrough}.`
      : 'No ledger activity exists before the reporting period, so the comparative column is empty.',
    action: hasComparative
      ? 'No action.'
      : 'Load opening balances and the prior-period journal (Opening Balances Setup) so comparatives can be presented as IAS 1.38 requires.',
  });

  // 8. Tax charge
  addCheck({
    id: 'tax-charge',
    severity: p.taxExpense > 0 ? 'pass' : 'warning',
    area: 'Taxation',
    standard: 'IAS 12.79',
    title: 'Income tax expense recognised for the period',
    detail: p.taxExpense > 0
      ? `Tax expense ${fmt(p.taxExpense)} ${currency} on profit before tax of ${fmt(profitBeforeTax)} (effective rate ${effectiveRate.toFixed(2)}% against a statutory rate of ${statutoryRate}%).`
      : `No income tax expense has been recognised on profit before tax of ${fmt(profitBeforeTax)} ${currency}.`,
    action: p.taxExpense > 0
      ? Math.abs(effectiveRate - statutoryRate) < 5
        ? 'No action — the effective rate is close to the statutory rate.'
        : 'Prepare the IAS 12.81 effective tax rate reconciliation explaining the difference from the statutory rate.'
      : 'Run the tax computation (Tax & Statutory Returns) and post the current tax charge before the statements are issued.',
  });

  // 9. Provisions
  const provisionsBalance = creditNet(positionRows, (g) => g === 'provisions');
  addCheck({
    id: 'provisions',
    severity: provisionsBalance > 0 ? 'pass' : 'warning',
    area: 'Measurement',
    standard: 'IAS 37.14',
    title: 'Provisions recorded where obligations exist',
    detail:
      provisionsBalance > 0
        ? `Provisions of ${fmt(provisionsBalance)} ${currency} are recognised at the reporting date.`
        : 'No provisions are recognised. Confirm that no present obligation (decommissioning, litigation, onerous contract, staff benefits) exists at the reporting date.',
    action:
      provisionsBalance > 0
        ? 'Maintain a provision roll-forward (opening, additions, utilisation, closing) for the IAS 37 note.'
        : 'Document management’s conclusion that no provision is required, or recognise the obligation at its best estimate.',
  });

  // 10. Fixed asset register
  const ppeExists = cur.ppe !== 0 || cur.rou !== 0;
  addCheck({
    id: 'ppe-register',
    severity: ppeExists ? 'pass' : 'warning',
    area: 'Non-current assets',
    standard: 'IAS 16.73',
    title: 'Property, plant and equipment movements are supported by a register',
    detail: ppeExists
      ? `Net book value ${fmt(r2(cur.ppe + cur.rou))} ${currency}; additions of ${fmt(additions)} and depreciation of ${fmt(depreciationCharge)} posted in the period.`
      : 'No property, plant and equipment balances are recorded.',
    action: ppeExists
      ? 'Reconcile the Fixed Assets Register to the general ledger at least annually and disclose the class-by-class analysis.'
      : 'Confirm that capital expenditure has not been expensed; capitalise qualifying assets under IAS 16.16.',
  });

  // 11. Future-dated entries
  const future = scoped.filter((l) => l.date > through).length;
  addCheck({
    id: 'future-dated',
    severity: future === 0 ? 'pass' : 'warning',
    area: 'Cut-off',
    standard: 'IAS 10',
    title: 'No entries dated after the reporting date inside the period',
    detail: future === 0 ? 'All entries fall on or before the reporting date.' : `${future} entr(ies) are dated after ${through}.`,
    action: future === 0 ? 'No action.' : 'Re-date the entries into the correct period or disclose them as post-balance-sheet events.',
  });

  // 12. Retained earnings reconciliation
  const retainedTie = r2(totalEquityC - totalEquityP - totalComprehensiveIncome + dividends - shareIssues);
  addCheck({
    id: 'equity-rollforward',
    severity: Math.abs(retainedTie) < 0.05 ? 'pass' : 'warning',
    area: 'Financial statements',
    standard: 'IAS 1.106',
    title: 'Statement of changes in equity reconciles to the statement of financial position',
    detail: `Opening equity ${fmt(totalEquityP)}, comprehensive income ${fmt(totalComprehensiveIncome)}, dividends ${fmt(-dividends)}, share movements ${fmt(shareIssues)}; unexplained residual ${fmt(retainedTie)}.`,
    action:
      Math.abs(retainedTie) < 0.05
        ? 'No action.'
        : 'Post the profit for the period to retained earnings at the year-end close (Month-End Close) so the roll-forward agrees.',
  });

  /* ---------------- Gap register ---------------------------------- */

  const gaps: GapItem[] = [
    {
      standard: 'IFRS 16',
      area: 'Lease register',
      severity: 'High',
      status: curNCL.leaseLiability || cur.rou ? 'Implemented' : 'Gap',
      why: 'Without a lease register the entity cannot measure lease liabilities, right-of-use assets or the maturity analysis required by IFRS 16.53.',
      remedy: 'Maintain every lease in the Loans & Leases desk with commencement date, term, discount rate and payment schedule; post the right-of-use asset and liability on day one.',
    },
    {
      standard: 'IAS 19',
      area: 'Employee benefits',
      severity: 'High',
      status: 'Partial',
      why: 'End-of-service gratuity and other long-service benefits are a present obligation; contribution plans must be distinguished from defined benefit plans (IAS 19.56).',
      remedy: 'Obtain an actuarial valuation for defined benefit obligations, or document that all plans are defined contribution and recognise the cost as incurred.',
    },
    {
      standard: 'IFRS 9',
      area: 'Expected credit losses',
      severity: 'High',
      status: 'Gap',
      why: 'Receivables must be measured net of a lifetime expected credit loss allowance; an ageing report alone does not satisfy the standard.',
      remedy: 'Adopt a provision matrix (30/60/90/120+ days) with historical loss rates adjusted for forward-looking information, and post the allowance monthly.',
    },
    {
      standard: 'IAS 36',
      area: 'Impairment testing',
      severity: 'Medium',
      status: 'Gap',
      why: 'Goodwill, indefinite-life intangibles and cash-generating units must be tested for impairment whenever indicators exist (IAS 36.9).',
      remedy: 'Define cash-generating units, agree value-in-use assumptions and document impairment indicators at each reporting date.',
    },
    {
      standard: 'IAS 21',
      area: 'Foreign currency',
      severity: 'Medium',
      status: 'Partial',
      why: 'Foreign operations must be translated at closing rates with differences recognised in other comprehensive income.',
      remedy: 'Record an FX revaluation run at each period end and post the translation reserve movement to OCI (already supported in the FX revaluation schedule).',
    },
    {
      standard: 'IAS 2',
      area: 'Inventory counts and costing',
      severity: 'Medium',
      status: 'Partial',
      why: 'Inventories must be counted at least annually and carried at the lower of cost and net realisable value (IAS 2.9/25).',
      remedy: 'Run a physical count with variance write-off, fix the costing method (weighted average / FIFO) in the item master and record NRV write-downs.',
    },
    {
      standard: 'IFRS 15',
      area: 'Contract review',
      severity: 'Medium',
      status: 'Partial',
      why: 'Each contract needs its performance obligations, transaction price allocation and timing of satisfaction documented.',
      remedy: 'Complete a five-step contract review for every material contract and maintain contract asset / contract liability balances.',
    },
    {
      standard: 'IAS 24',
      area: 'Related parties',
      severity: 'Medium',
      status: 'Gap',
      why: 'Related party transactions and key management compensation must be disclosed, including the nature of the relationship (IAS 24.18).',
      remedy: 'Flag related-party business partners in the Business Partners module and generate the disclosure from their transaction history.',
    },
    {
      standard: 'IAS 33',
      area: 'Earnings per share',
      severity: 'Low',
      status: 'Partial',
      why: 'Listed entities must present basic and diluted EPS with the share-count reconciliation (IAS 33.70).',
      remedy: 'Record the weighted average number of ordinary shares in the company profile so EPS is computed, not asserted.',
    },
    {
      standard: 'IFRS 8',
      area: 'Segment reporting',
      severity: 'Low',
      status: 'Partial',
      why: 'Reportable segments must be identified from internal reports reviewed by the chief operating decision maker.',
      remedy: 'Use cost centres as the segment dimension and disclose revenue and profit by segment once management reporting is aligned.',
    },
    {
      standard: 'IAS 8',
      area: 'Accounting estimates and errors',
      severity: 'Low',
      status: 'Gap',
      why: 'Changes in estimates must be accounted for prospectively and errors corrected retrospectively with disclosure (IAS 8.49/IAS 8.42).',
      remedy: 'Keep the adjustment desk audit trail and disclose prior-period adjustments in the equity note.',
    },
    {
      standard: 'IFRS 10 / IFRS 3',
      area: 'Group reporting',
      severity: 'Medium',
      status: 'Partial',
      why: 'Consolidation requires elimination of intragroup balances, goodwill measurement and non-controlling interests.',
      remedy: 'Use the Group Consolidation desk to eliminate intragroup transactions and prepare the consolidation adjustments as an auditable pack.',
    },
    {
      standard: 'IAS 1.134',
      area: 'Capital management',
      severity: 'Low',
      status: 'Implemented',
      why: 'Capital management disclosures and liquidity ratios are required where the entity has externally imposed capital requirements.',
      remedy: 'Ratios and net debt reconciliation are presented in note 24; refresh them at each reporting date.',
    },
    {
      standard: 'ESEF / iXBRL',
      area: 'Digital filing',
      severity: 'Low',
      status: 'Gap',
      why: 'Regulators increasingly require Inline XBRL tagging of the primary statements against the IFRS taxonomy.',
      remedy: 'Map each chart-of-accounts caption to an IFRS taxonomy element so the statements can be exported as iXBRL.',
    },
    {
      standard: 'IAS 1.51',
      area: 'Statement completeness',
      severity: 'High',
      status: 'Implemented',
      why: 'A complete set comprises the four primary statements, the notes and the accounting policies — all present in this pack.',
      remedy: 'Issue the pack from the IFRS Statutory Statements desk at each reporting date and retain it with the signed minutes.',
    },
    {
      standard: 'IFRS 17',
      area: 'Insurance contracts',
      severity: 'Low',
      status: 'Gap',
      why: 'Insurance premium income is present in the chart of accounts; if the entity underwrites insurance contracts, IFRS 17 measurement applies.',
      remedy: 'Assess whether the entity holds insurance risk; if so, adopt the general measurement model or the premium allocation approach.',
    },
    {
      standard: 'Internal control',
      area: 'Segregation of duties',
      severity: 'Medium',
      status: 'Partial',
      why: 'Maker–checker approval, period locking and an immutable audit trail are prerequisites for reliable reporting and for an unqualified audit opinion.',
      remedy: 'Enforce maker/checker on manual journals, close periods after the month-end run and export the control-event log with the audit pack.',
    },
    {
      standard: 'IAS 7.44',
      area: 'Net debt disclosure',
      severity: 'Low',
      status: 'Implemented',
      why: 'A reconciliation of net debt is required where cash flows are classified by activity.',
      remedy: 'The reconciliation is presented alongside the cash flow statement; keep borrowings and cash account groups current.',
    },
  ];

  /* ---------------- IAS 1 completeness checklist ------------------ */

  const checklist: IfrsPack['checklist'] = [
    { requirement: 'Statement of financial position', standard: 'IAS 1.54', status: 'Satisfied', detail: 'Presented with current/non-current classification and comparatives.' },
    { requirement: 'Statement of profit or loss and other comprehensive income', standard: 'IAS 1.81A', status: 'Satisfied', detail: 'Single statement covering profit or loss and OCI.' },
    { requirement: 'Statement of changes in equity', standard: 'IAS 1.106', status: 'Satisfied', detail: 'Matrix of equity components and movements.' },
    { requirement: 'Statement of cash flows', standard: 'IAS 7.10', status: 'Satisfied', detail: 'Indirect method with net debt reconciliation.' },
    { requirement: 'Comparative information', standard: 'IAS 1.38', status: hasComparative ? 'Satisfied' : 'Missing', detail: hasComparative ? 'Prior-period column presented.' : 'No prior-period ledger activity.' },
    { requirement: 'Accounting policies', standard: 'IAS 1.117', status: 'Satisfied', detail: 'Note 3 sets out the significant policies and their measurement bases.' },
    { requirement: 'Critical judgements and estimates', standard: 'IAS 1.122', status: 'Satisfied', detail: 'Note 4.' },
    { requirement: 'Going concern assessment', standard: 'IAS 1.25', status: balanced ? 'Satisfied' : 'Partial', detail: 'Note 23.' },
    { requirement: 'Revenue disaggregation', standard: 'IFRS 15.114', status: revenueTable.length ? 'Satisfied' : 'Partial', detail: 'Note 5.' },
    { requirement: 'PPE movement note', standard: 'IAS 16.73', status: ppeExists ? 'Satisfied' : 'Partial', detail: 'Note 6.' },
    { requirement: 'Income tax reconciliation', standard: 'IAS 12.81', status: p.taxExpense > 0 ? 'Satisfied' : 'Partial', detail: 'Note 15.' },
    { requirement: 'Related party disclosures', standard: 'IAS 24.18', status: 'Partial', detail: 'Note 18 — management input required for key management compensation.' },
    { requirement: 'Financial risk management', standard: 'IFRS 7.31', status: 'Satisfied', detail: 'Note 19.' },
    { requirement: 'Events after the reporting date', standard: 'IAS 10.17', status: 'Satisfied', detail: 'Note 22.' },
    { requirement: 'Earnings per share', standard: 'IAS 33.70', status: 'Partial', detail: 'Note 21 — share count to be confirmed.' },
    { requirement: 'Segment information', standard: 'IFRS 8.5', status: 'Satisfied', detail: 'Note 20 — single segment.' },
    { requirement: 'Capital management disclosures', standard: 'IAS 1.134', status: 'Satisfied', detail: 'Note 24.' },
    { requirement: 'Statement of compliance with IFRS', standard: 'IAS 1.114', status: balanced ? 'Satisfied' : 'Missing', detail: 'Note 2.' },
  ];

  return {
    entityName,
    entityCode,
    currency,
    jurisdiction,
    periodLabel: `${from} to ${through}`,
    comparativeLabel: `${comparativeFrom} to ${comparativeThrough}`,
    balanceSheetDate: through,
    statements: [position, profitStatement, equityStatement, cashFlowStatement],
    policies: notes[2].paragraphs.map((t) => ({ standard: 'IAS 1.117', title: 'Basis of preparation', text: t })),
    notes,
    ratios,
    checks,
    gaps,
    checklist,
    totals: {
      revenue: p.revenue,
      revenueComparative: pPrior.revenue,
      grossProfit,
      grossProfitComparative: grossProfitPrior,
      profitBeforeTax,
      profitBeforeTaxComparative: profitBeforeTaxPrior,
      taxExpense: p.taxExpense,
      taxExpenseComparative: pPrior.taxExpense,
      profitForPeriod,
      profitForPeriodComparative: profitForPeriodPrior,
      totalComprehensiveIncome,
      totalAssets: totalAssetsC,
      totalAssetsComparative: totalAssetsP,
      totalEquity: totalEquityC,
      totalEquityComparative: totalEquityP,
      totalLiabilities: totalLiabC,
      totalLiabilitiesComparative: totalLiabP,
      cashAndEquivalents: curCA.cash,
      cashAndEquivalentsComparative: cmpCA.cash,
      netDebt: netDebtNow,
      netDebtComparative: netDebtThen,
      balanced,
    },
  };
}
