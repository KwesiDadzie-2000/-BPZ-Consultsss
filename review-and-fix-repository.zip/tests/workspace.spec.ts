import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test.beforeEach(async ({ page }) => {
  await page.goto('http://localhost:5173');
  await expect(page.getByRole('heading', { name: 'Gold Coast Mines Ltd', exact: true })).toBeVisible();
});

test('preserves original workspace and isolates entity balances', async ({ page }) => {
  await expect(page.getByText('Local review · sample data')).toBeVisible();
  await page.getByLabel('Active accounting workspace').selectOption('3');
  await expect(page.getByRole('heading', { name: 'Volta River Agro Ltd', exact: true })).toBeVisible();
  await expect(page.getByText('No journal entries yet.', { exact: false })).toBeVisible();
  await page.getByLabel('Active accounting workspace').selectOption('2');
  await expect(page.getByText('25 active journal lines')).toBeVisible();
});

test('manual journal has labelled controls, correct account, and focus restoration', async ({ page }) => {
  await page.getByRole('button', { name: 'Post Journal Entry', exact: true }).click();
  await page.getByRole('button', { name: /Post Manual Journal|New Journal|Post Entry|Create.*Journal/ }).first().click();
  const dialog = page.getByRole('dialog', { name: 'Post Manual Journal Entry' });
  await expect(dialog).toBeVisible();
  await expect(page.getByLabel('Debit Account (Dr)')).toHaveValue(/600000.*Depreciation/);
  await page.keyboard.press('Escape');
  await expect(dialog).not.toBeVisible();
});

test('approval queue supports keyboard dismissal', async ({ page }) => {
  const trigger = page.getByRole('button', { name: '2 Approvals', exact: true });
  await trigger.click();
  await expect(page.getByRole('dialog', { name: 'Review queue' })).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(trigger).toBeFocused();
});

test('dashboard passes automated WCAG A/AA checks', async ({ page }) => {
  const result = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa']).analyze();
  expect(result.violations).toEqual([]);
});

test('local preview can be exited and reopened without production credentials', async ({ page }) => {
  await page.getByRole('button', { name: /Exit review/ }).click();
  await expect(page.getByRole('button', { name: 'Open review workspace' })).toBeVisible();
  await expect(page.locator('input[type=password]')).toHaveCount(0);
  await page.getByRole('button', { name: 'Open review workspace' }).click();
  await expect(page.getByRole('heading', { name: 'Gold Coast Mines Ltd', exact: true })).toBeVisible();
});

test('mobile navigation closes with Escape and does not overflow', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole('button', { name: 'Open navigation menu' }).click();
  await expect(page.getByRole('dialog', { name: 'Main navigation' })).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog', { name: 'Main navigation' })).toHaveCount(0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});

test('a journal posts, persists on refresh, and reverses without changing its original', async ({ page }) => {
  await page.getByRole('button', { name: 'Post Journal Entry', exact: true }).click();
  await page.getByRole('button', { name: 'Post Manual Journal', exact: true }).click();
  await page.getByLabel('Amount (GHS)').fill('123.45');
  await page.getByLabel('Narration / Justification').fill('Browser regression journal');
  await page.getByRole('button', { name: 'Post Entry', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.getByText(/27 lines/)).toBeVisible();
  await page.reload();
  await expect(page.getByText('27 active journal lines')).toBeVisible();
  await page.locator('aside nav button').filter({ hasText: 'Universal Journal' }).click();
  const row = page.getByRole('row').filter({ hasText: 'Browser regression journal' }).first();
  const docNo = (await row.locator('td').first().textContent())!.trim();
  const before = await page.evaluate((doc) => JSON.parse(localStorage.getItem('bpz_review:bpz_journal_lines_v1')!).filter((line: { docNo: string }) => line.docNo === doc), docNo);
  await row.getByRole('button', { name: 'Reverse', exact: true }).click();
  await expect(row.getByRole('button', { name: 'Reverse', exact: true })).toBeDisabled();
  const after = await page.evaluate((doc) => JSON.parse(localStorage.getItem('bpz_review:bpz_journal_lines_v1')!).filter((line: { docNo: string }) => line.docNo === doc), docNo);
  expect(after).toEqual(before);
  expect(await page.evaluate(() => localStorage.getItem('bpz_journal_lines_v1'))).toBeNull();
});

test('same-account journal is refused without closing the form', async ({ page }) => {
  await page.getByRole('button', { name: 'Post Journal Entry', exact: true }).click();
  await page.getByRole('button', { name: 'Post Manual Journal', exact: true }).click();
  const debit = await page.getByLabel('Debit Account (Dr)').inputValue();
  await page.getByLabel('Credit Account (Cr)').selectOption(debit);
  await page.getByLabel('Narration / Justification').fill('Invalid same-account entry');
  await page.getByRole('button', { name: 'Post Entry', exact: true }).click();
  await expect(page.getByRole('alert')).toHaveText('Choose different debit and credit accounts.');
  await expect(page.getByRole('dialog')).toBeVisible();
});

for (const closed of [false, true]) {
  test(`payment approval ${closed ? 'stays pending after rejection' : 'retains settlement metadata'}`, async ({ page }) => {
    await page.addInitScript((periodClosed) => {
      const date = new Date().toISOString().slice(0, 10);
      const period = date.slice(0, 7);
      const base = { docNo: 'REVIEW-PAYMENT', period, date, module: 'FI', docType: 'PAY', currency: 'GHS', description: 'Settlement regression', createdBy: 'demo', clientId: 2 };
      const request = {
        id: 'REVIEW-PAYMENT-APPROVAL', clientId: 2, clientCode: 'CLI-001', clientName: 'Gold Coast Mines Ltd',
        docNo: base.docNo, docType: 'PAY', amount: 100, requestedBy: 'demo', requestedAt: date,
        description: base.description, reasonForApproval: 'Independent payment review', status: 'pending',
        payload: {
          lines: [
            { ...base, id: 'review-payment-dr', accountNo: '205000', accountName: 'Salaries payable', debit: 100, credit: 0 },
            { ...base, id: 'review-payment-cr', accountNo: '100000', accountName: 'Bank', debit: 0, credit: 100 },
          ],
          settlement: { kind: 'salary', clientId: 2, settleAmount: 100, cashDelta: -100, bankId: 1 },
        },
      };
      localStorage.setItem('bpz_review:bpz_approval_requests_v1', JSON.stringify([request]));
      localStorage.setItem('bpz_review:bpz_closed_periods_v1', JSON.stringify(periodClosed ? { 2: [period] } : {}));
    }, closed);
    await page.reload();
    await page.getByRole('button', { name: '1 Approvals', exact: true }).click();
    const dialog = page.getByRole('dialog', { name: 'Review queue' });
    await dialog.getByRole('button', { name: 'Approve & post journal', exact: true }).click();
    if (closed) await expect(dialog.getByRole('alert')).toContainText('remains pending');
    else await expect(dialog.getByRole('status')).toContainText('Approved and posted');
    const saved = await page.evaluate(() => ({
      approval: JSON.parse(localStorage.getItem('bpz_review:bpz_approval_requests_v1')!)[0],
      bank: JSON.parse(localStorage.getItem('bpz_review:bpz_bank_accounts_v1')!).find((row: { id: number }) => row.id === 1),
    }));
    expect(saved.approval.status).toBe(closed ? 'pending' : 'approved');
    expect(saved.bank.balance).toBe(closed ? 640000 : 639900);
    expect(saved.approval.payload.settlement.bankId).toBe(1);
  });
}

test('exiting review never clears original production session keys', async ({ page }) => {
  await page.evaluate(() => {
    localStorage.setItem('bpz_session_token_v1', 'production-placeholder-for-isolation-test');
    localStorage.setItem('bpz_session_user_v1', '{"username":"untouched"}');
  });
  await page.getByRole('button', { name: /Exit review/ }).click();
  expect(await page.evaluate(() => localStorage.getItem('bpz_session_token_v1'))).toBe('production-placeholder-for-isolation-test');
  expect(await page.evaluate(() => localStorage.getItem('bpz_session_user_v1'))).toBe('{"username":"untouched"}');
});