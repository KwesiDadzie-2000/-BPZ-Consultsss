/**
 * Browser-side client for the server-authoritative trade engine (/api/trade).
 *
 * The P2P (procure-to-pay) and O2C (order-to-cash) lifecycles are posted by the
 * server in one database transaction (document, stock, journal, audit, outbox).
 * This module wraps the API, types its workspace snapshot and exposes a hook that
 * (a) loads the snapshot for the active entity, (b) runs commands with an
 * idempotency key, and (c) asks the workspace to re-pull its server copy after
 * every successful mutation — so the legacy desks (ledger, inventory, banking)
 * see the posting immediately and never overwrite it with a stale sync.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { apiFetchVerified } from '@/utils/session';
import { uniqueId } from '@/utils/ids';

export type TradeDocType =
  | 'purchase_requisition' | 'purchase_order' | 'goods_receipt' | 'supplier_invoice'
  | 'supplier_credit_note' | 'supplier_debit_note'
  | 'sales_order' | 'sales_delivery' | 'sales_invoice' | 'customer_credit_note' | 'customer_debit_note';

export type TradeItemType = 'stock' | 'office' | 'service' | 'asset';

export interface TradeLine {
  id: string;
  clientId: number;
  documentId: string;
  lineNo: number;
  itemCode: string | null;
  description: string;
  itemType: TradeItemType | string;
  uom: string;
  quantity: number;
  unitPrice: number;
  discountAmount: number;
  taxCode: string;
  taxRate: number;
  taxAmount: number;
  netAmount: number;
  totalAmount: number;
  accountNo: string | null;
  inventoryAccount: string | null;
  revenueAccount: string | null;
  costCenter: string | null;
  sourceLineId: string | null;
  data: Record<string, unknown>;
}

export interface TradeLink {
  id: string;
  fromDocumentId: string;
  fromLineId: string | null;
  toDocumentId: string;
  toLineId: string | null;
  linkType: string;
  quantity: number;
  amount: number;
}

export interface TradeDocument {
  id: string;
  clientId: number;
  docType: TradeDocType | string;
  docNo: string;
  status: string;
  date: string;
  dueDate: string | null;
  partyId: string | null;
  partyName: string;
  currency: string;
  functionalCurrency: string;
  exchangeRate: number;
  netAmount: number;
  taxAmount: number;
  totalAmount: number;
  version: number;
  createdBy: string;
  submittedBy: string | null;
  approvedBy: string | null;
  approvedAt: string | null;
  postedAt: string | null;
  externalRef: string | null;
  sourceRef: string | null;
  reason: string | null;
  data: Record<string, unknown>;
  lines: TradeLine[];
  links: TradeLink[];
  openBalance: number | null;
}

export interface TradeAllocation {
  id: string;
  sourceType: string;
  sourceId: string;
  targetDocumentId: string;
  amount: number;
  currency: string;
  allocationDate: string;
  createdBy: string;
  reversedAt: string | null;
}

export interface TradePayment {
  id: string;
  paymentNo: string;
  paymentType: 'customer_receipt' | 'customer_advance' | 'supplier_payment' | 'reversal' | string;
  partyId: string | null;
  partyName: string;
  date: string;
  currency: string;
  functionalCurrency: string;
  exchangeRate: number;
  amount: number;
  functionalAmount: number;
  cashAmount: number;
  withheldAmount: number;
  method: string;
  bankAccountId: number | null;
  reference: string | null;
  status: string;
  reversalOf: string | null;
  createdBy: string;
  allocations: TradeAllocation[];
  unallocated: number;
}

export interface TradeAuditEvent {
  id: string;
  actor: string;
  eventType: string;
  recordType: string;
  recordId: string;
  occurredAt: string;
  reason: string | null;
  beforeState?: Record<string, unknown> | null;
  afterState?: Record<string, unknown> | null;
}

export interface TradeWorkspace {
  client: { id: number; code: string; name: string; currency: string };
  documents: TradeDocument[];
  payments: TradePayment[];
  allocations: TradeAllocation[];
  stockItems: Array<{ id: string; itemCode: string; description: string; uom: string; quantityOnHand: number; unitCost: number; totalValue: number; glAccount: string | null; costMethod: string | null }>;
  bankAccounts: Array<{ id: number; name: string; currency: string; balance: number; kind: string | null; glAccount: string | null }>;
  cashbook: Array<{ bankAccountId: number; name: string; currency: string; recordedBalance: number; bookMovementBalance: number; movementCount: number }>;
  inventoryLots: Array<{ id: string; itemCode: string; receiptDate: string; originalQuantity: number; remainingQuantity: number; functionalUnitCost: number }>;
  auditEvents: TradeAuditEvent[];
}

export type TradeCommand = Record<string, unknown> & { action: string };

export interface TradeResult {
  ok: boolean;
  result?: Record<string, unknown>;
  error?: string;
  sessionLost?: boolean;
  status?: number;
}

export const DOC_TYPE_LABEL: Record<string, string> = {
  purchase_requisition: 'Purchase requisition',
  purchase_order: 'Purchase order',
  goods_receipt: 'Goods receipt (GRN)',
  supplier_invoice: 'Supplier invoice',
  supplier_credit_note: 'Supplier credit note',
  supplier_debit_note: 'Supplier debit note',
  sales_order: 'Sales order',
  sales_delivery: 'Delivery note',
  sales_invoice: 'Sales invoice',
  customer_credit_note: 'Customer credit note',
  customer_debit_note: 'Customer debit note',
};

export const ITEM_TYPE_LABEL: Record<TradeItemType, string> = {
  stock: 'Stock (perpetual inventory)',
  office: 'Office consumption / expense',
  service: 'Service',
  asset: 'Capital asset',
};

/** Posted-state helpers shared by the desks. */
export const isPosted = (doc: TradeDocument) => !!doc.postedAt;
export const isOpenInvoice = (doc: TradeDocument) => ['Open', 'PartiallySettled'].includes(doc.status);
export const isAuthorisationOpen = (doc: TradeDocument) =>
  ['Approved', 'PartiallyReceived', 'PartiallyDelivered'].includes(doc.status);

export async function fetchTradeWorkspace(clientId: number): Promise<{ ok: true; state: TradeWorkspace } | { ok: false; error: string; sessionLost?: boolean }> {
  const { response, sessionLost } = await apiFetchVerified(`/api/trade?clientId=${clientId}`);
  if (sessionLost) return { ok: false, error: 'Your session has ended — sign in again to continue.', sessionLost: true };
  if (!response) return { ok: false, error: 'The server could not be reached. The P2P / O2C desk needs a live connection because every posting is committed on the server.' };
  const body = await response.json().catch(() => null);
  if (!response.ok || !body?.ok) return { ok: false, error: body?.error || `HTTP ${response.status}` };
  return { ok: true, state: body as TradeWorkspace };
}

export async function runTradeCommand(clientId: number, command: TradeCommand, idempotencyKey?: string): Promise<TradeResult> {
  const payload = { ...command, clientId, idempotencyKey: idempotencyKey || uniqueId('cmd') };
  const { response, sessionLost } = await apiFetchVerified('/api/trade', { method: 'POST', body: JSON.stringify(payload) });
  if (sessionLost) return { ok: false, error: 'Your session has ended — sign in again. Nothing was posted.', sessionLost: true };
  if (!response) return { ok: false, error: 'The server could not be reached — nothing was posted. Retry when the connection returns.' };
  const body = await response.json().catch(() => null);
  if (!response.ok || !body?.ok) return { ok: false, error: body?.error || `HTTP ${response.status}`, status: response.status };
  return { ok: true, result: body as Record<string, unknown> };
}

export interface TradeNotice {
  tone: 'ok' | 'error' | 'info';
  text: string;
}

export interface UseTradeDeskOptions {
  clientId: number;
  /** Called after every successful server mutation so the workspace re-pulls its server copy. */
  onServerMutation?: () => Promise<void> | void;
  onSessionLost?: () => void;
}

export function useTradeDesk({ clientId, onServerMutation, onSessionLost }: UseTradeDeskOptions) {
  const [state, setState] = useState<TradeWorkspace | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [notice, setNotice] = useState<TradeNotice | null>(null);
  const alive = useRef(true);
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);

  const refresh = useCallback(async () => {
    const result = await fetchTradeWorkspace(clientId);
    if (!alive.current) return;
    if (result.ok) { setState(result.state); setLoadError(null); }
    else { setLoadError(result.error); if (result.sessionLost) onSessionLost?.(); }
    setLoading(false);
  }, [clientId, onSessionLost]);

  useEffect(() => { setLoading(true); setState(null); void refresh(); }, [refresh]);

  /**
   * Runs one command. The idempotency key is fixed per call so a retry of the same
   * click can never post twice. After success the trade snapshot AND the main
   * workspace are refreshed before the UI is re-enabled.
   */
  const run = useCallback(async (command: TradeCommand, successText?: string | ((r: Record<string, unknown>) => string)): Promise<TradeResult> => {
    setBusy(true);
    setNotice(null);
    const key = uniqueId('cmd');
    const result = await runTradeCommand(clientId, command, key);
    if (!alive.current) return result;
    if (result.ok) {
      await refresh();
      try { await onServerMutation?.(); } catch { /* the trade snapshot is already fresh */ }
      if (alive.current) setNotice({ tone: 'ok', text: typeof successText === 'function' ? successText(result.result || {}) : successText || 'Done — committed on the server.' });
    } else {
      if (result.sessionLost) onSessionLost?.();
      setNotice({ tone: 'error', text: result.error || 'The command was rejected.' });
      // A 409 means our snapshot is stale (version/status changed) — reload it.
      if (result.status === 409) await refresh();
    }
    if (alive.current) setBusy(false);
    return result;
  }, [clientId, refresh, onServerMutation, onSessionLost]);

  /** Submit a draft and, when it is self-authorised within the maker limit, post it in the same action. */
  const submitAndPost = useCallback(async (doc: TradeDocument, postable: boolean) => {
    const submitted = await run({ action: 'submit_document', documentId: doc.id, expectedVersion: doc.version },
      (r) => r.status === 'Submitted'
        ? `${doc.docNo} submitted — it is above your maker limit and now awaits an independent checker.`
        : `${doc.docNo} approved.`);
    if (!submitted.ok || !postable) return submitted;
    const r = submitted.result || {};
    if (r.status !== 'Approved') return submitted;
    return run({ action: 'post_document', documentId: doc.id, expectedVersion: Number(r.version) },
      (p) => `${doc.docNo} posted · journal ${String(p.journalNo || '')}`);
  }, [run]);

  const approveAndPost = useCallback(async (doc: TradeDocument, postable: boolean, reason: string) => {
    const approved = await run({ action: 'approve_document', documentId: doc.id, expectedVersion: doc.version, reason }, `${doc.docNo} approved as independent checker.`);
    if (!approved.ok || !postable) return approved;
    return run({ action: 'post_document', documentId: doc.id, expectedVersion: Number(approved.result?.version) },
      (p) => `${doc.docNo} posted · journal ${String(p.journalNo || '')}`);
  }, [run]);

  const post = useCallback(async (doc: TradeDocument) =>
    run({ action: 'post_document', documentId: doc.id, expectedVersion: doc.version }, (p) => `${doc.docNo} posted · journal ${String(p.journalNo || '')}`), [run]);

  return { state, loading, busy, loadError, notice, setNotice, refresh, run, submitAndPost, approveAndPost, post };
}

export type TradeDesk = ReturnType<typeof useTradeDesk>;

/** Quantity already consumed from a source line by posted child documents of a given type. */
export function fulfilledQuantity(documents: TradeDocument[], sourceLineId: string, childType: string): number {
  let total = 0;
  for (const doc of documents) {
    if (doc.docType !== childType || !doc.postedAt) continue;
    for (const line of doc.lines) if (line.sourceLineId === sourceLineId) total += line.quantity;
  }
  return Math.round(total * 1000) / 1000;
}

/** Quantity on a source line already consumed by child documents that are NOT yet posted (drafts awaiting approval). */
export function pendingQuantity(documents: TradeDocument[], sourceLineId: string, childType: string): number {
  let total = 0;
  for (const doc of documents) {
    if (doc.docType !== childType || doc.postedAt) continue;
    for (const line of doc.lines) if (line.sourceLineId === sourceLineId) total += line.quantity;
  }
  return Math.round(total * 1000) / 1000;
}

export const money = (n: number) => Math.round((Number.isFinite(n) ? n : 0) * 100) / 100;
export const fmtMoney = (n: number) => money(n).toLocaleString('en-GH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
export const fmtQty = (n: number) => (Math.round(n * 1000) / 1000).toLocaleString('en-GH', { maximumFractionDigits: 3 });
