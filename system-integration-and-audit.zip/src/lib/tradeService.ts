import { createHash, randomUUID } from "node:crypto";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  auditLog,
  bankAccounts,
  chartAccounts,
  clients,
  closedPeriods,
  journalHeaders,
  journalLines,
  postingEvents,
  stockItems,
  stockMovements,
  tradeAllocations,
  tradeAuditEvents,
  tradeBankMatches,
  tradeBankStatements,
  tradeCashMovements,
  tradeCounters,
  tradeDocumentLines,
  tradeDocumentLinks,
  tradeDocuments,
  tradeInbox,
  tradeInventoryLots,
  tradeInventoryReservations,
  tradeOutbox,
  tradePayments,
  tradePostingEvents,
} from "@/db/schema";
import { buildJournalHeader, buildPostingEvent } from "@/lib/journalPosting";
import { validateJournalLines } from "@/lib/journalValidation";
import { hasFirmWideScope } from "@/utils/access";
import type { ACDOCALine, UserAccount } from "@/types/accounting";

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
type JsonRecord = Record<string, unknown>;
type Side = "debit" | "credit";

const LOCK_NAMESPACE = 4_027_441;
const EPSILON = 0.009;
const PREFIX: Record<string, string> = {
  purchase_requisition: "PR",
  purchase_order: "PO",
  goods_receipt: "GRN",
  supplier_invoice: "SIN",
  supplier_credit_note: "SCN",
  supplier_debit_note: "SDN",
  sales_order: "SO",
  sales_delivery: "DEL",
  sales_invoice: "INV",
  customer_credit_note: "CCN",
  customer_debit_note: "CDN",
};
const DOCUMENT_TYPES = new Set(Object.keys(PREFIX));
const STOCK_TYPES = new Set(["stock", "office", "service", "asset"]);
const DEFAULT_ACCOUNTS: Record<string, string> = {
  "100000": "Cash at Bank — Operating Account",
  "110000": "Trade & Other Receivables",
  "118100": "Unbilled Contract Assets — Revenue Recognised",
  "120000": "Inventories — Raw Materials & Spares",
  "125000": "VAT Input Tax Recoverable",
  "200000": "Trade Payables & Supplier Balances",
  "204000": "Goods Received Not Invoiced (GRNI) Clearing",
  "209000": "Withholding Tax Payable",
  "220000": "VAT Output Liability",
  "225000": "Customer Contract Liabilities / Advances",
  "400000": "Revenue from Customer Contracts",
  "402000": "Revenue — Trading & Merchandise Sales",
  "504000": "Cost of Goods Sold — Merchandise",
  "520000": "Purchase Price & Landed Cost Variances",
  "580000": "Foreign Exchange Loss",
  "491000": "Foreign Exchange Gain",
  "628000": "Office Consumables & Cleaning Services",
  "621000": "Contracted Services & Subcontractor Costs",
  "658000": "Freight, Haulage & Shipping Charges",
  "116000": "Prepayments & Deferred Charges",
};

export class TradeServiceError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.name = "TradeServiceError";
    this.status = status;
  }
}

const roundMoney = (n: number) => Math.round((Number.isFinite(n) ? n : 0) * 100) / 100;
const roundQty = (n: number) => Math.round((Number.isFinite(n) ? n : 0) * 1000) / 1000;
const moneyCents = (n: number) => Math.round(roundMoney(n) * 100);
const isoToday = () => new Date().toISOString().slice(0, 10);
const isRecord = (v: unknown): v is JsonRecord => !!v && typeof v === "object" && !Array.isArray(v);
const finite = (value: unknown, fallback = 0) => {
  const number = typeof value === "number" ? value : Number(value);
  return Number.isFinite(number) ? number : fallback;
};
const str = (value: unknown, fallback = "") => typeof value === "string" ? value.trim() : fallback;
const cleanRecord = (value: unknown): JsonRecord => isRecord(value) ? value : {};
const safeDate = (value: unknown, fallback = isoToday()) => {
  const date = str(value, fallback);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(`${date}T00:00:00Z`))) {
    throw new TradeServiceError("Use a valid accounting date in YYYY-MM-DD format.");
  }
  return date;
};
const canonical = (value: unknown): unknown => {
  if (Array.isArray(value)) return value.map(canonical);
  if (!isRecord(value)) return value;
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonical(value[key])]));
};
const hashRequest = (value: unknown) => createHash("sha256").update(JSON.stringify(canonical(value))).digest("hex");
const sourceTypeFor = (type: string) => type === "supplier_invoice" || type === "supplier_credit_note" || type === "supplier_debit_note" ? "supplier" : "customer";
const sourceInvoiceTypeFor = (type: string) => type === "supplier_credit_note" || type === "supplier_debit_note" ? "supplier_invoice" : "sales_invoice";
const allowedItemType = (type: unknown): string => {
  const value = str(type, "service");
  if (!STOCK_TYPES.has(value)) throw new TradeServiceError("Select stock, office consumption, service or asset for every line.");
  return value;
};

async function assertClient(tx: Tx, clientId: number, user: UserAccount) {
  if (!Number.isInteger(clientId) || clientId <= 0) throw new TradeServiceError("A valid client workspace is required.");
  if (!hasFirmWideScope(user) && user.clientId !== clientId) throw new TradeServiceError("This transaction belongs to another client workspace.", 403);
  const rows = await tx.select().from(clients).where(eq(clients.id, clientId)).limit(1);
  if (!rows[0]) throw new TradeServiceError("The selected client workspace does not exist.", 404);
  return rows[0];
}

async function nextNumber(tx: Tx, clientId: number, prefix: string, date: string): Promise<string> {
  const scopedPrefix = `${prefix}-${date.slice(0, 4)}`;
  const result = await tx.insert(tradeCounters).values({ clientId, prefix: scopedPrefix, lastNumber: 1 })
    .onConflictDoUpdate({
      target: [tradeCounters.clientId, tradeCounters.prefix],
      set: { lastNumber: sql`${tradeCounters.lastNumber} + 1` },
    })
    .returning({ lastNumber: tradeCounters.lastNumber });
  return `${scopedPrefix}-${String(result[0]?.lastNumber ?? 1).padStart(5, "0")}`;
}

async function getDocument(tx: Tx, clientId: number, id: string) {
  const rows = await tx.select().from(tradeDocuments).where(and(eq(tradeDocuments.clientId, clientId), eq(tradeDocuments.id, id))).limit(1);
  if (!rows[0]) throw new TradeServiceError("The referenced document was not found in this workspace.", 404);
  return rows[0];
}

async function getDocumentLines(tx: Tx, clientId: number, documentId: string) {
  return tx.select().from(tradeDocumentLines)
    .where(and(eq(tradeDocumentLines.clientId, clientId), eq(tradeDocumentLines.documentId, documentId)))
    .orderBy(tradeDocumentLines.lineNo);
}

async function getSourceLine(tx: Tx, clientId: number, id: string) {
  const rows = await tx.select().from(tradeDocumentLines)
    .where(and(eq(tradeDocumentLines.clientId, clientId), eq(tradeDocumentLines.id, id))).limit(1);
  if (!rows[0]) throw new TradeServiceError("The source document line was not found in this workspace.", 404);
  const document = await getDocument(tx, clientId, rows[0].documentId);
  return { line: rows[0], document };
}

interface NormalizedLine {
  id: string;
  clientId: number;
  documentId: string;
  lineNo: number;
  itemCode: string | null;
  description: string;
  itemType: string;
  uom: string;
  quantity: number;
  unitPrice: number;
  discountAmount: number;
  taxCode: string;
  taxRate: number;
  taxAmount: number;
  netAmount: number;
  totalAmount: number;
  accountNo: string | null;
  inventoryAccount: string | null;
  revenueAccount: string | null;
  costCenter: string | null;
  sourceLineId: string | null;
  data: JsonRecord;
}

function calculateLine(input: JsonRecord, clientId: number, documentId: string, lineNo: number, overrides: Partial<NormalizedLine> = {}): NormalizedLine {
  const quantity = roundQty(finite(overrides.quantity ?? input.quantity, 1));
  const unitPrice = roundMoney(finite(overrides.unitPrice ?? input.unitPrice, 0));
  const discountAmount = roundMoney(finite(overrides.discountAmount ?? input.discountAmount, 0));
  const taxRate = finite(overrides.taxRate ?? input.taxRate, 0);
  if (quantity < 0 || (quantity === 0 && !overrides.data?.priceOnly) || unitPrice < 0) throw new TradeServiceError(`Line ${lineNo}: quantity and unit price must be positive.`);
  if (discountAmount < 0 || discountAmount > roundMoney(quantity * unitPrice) + EPSILON) throw new TradeServiceError(`Line ${lineNo}: discount exceeds the line value.`);
  if (taxRate < 0 || taxRate > 100) throw new TradeServiceError(`Line ${lineNo}: tax rate must be between 0% and 100%.`);
  const netAmount = roundMoney(Math.max(0, quantity * unitPrice - discountAmount));
  const taxAmount = roundMoney(netAmount * taxRate / 100);
  return {
    id: overrides.id || randomUUID(),
    clientId,
    documentId,
    lineNo,
    itemCode: overrides.itemCode ?? (str(input.itemCode) || null),
    description: overrides.description ?? str(input.description, `Line ${lineNo}`),
    itemType: overrides.itemType ?? allowedItemType(input.itemType),
    uom: overrides.uom ?? str(input.uom, "each"),
    quantity,
    unitPrice,
    discountAmount,
    taxCode: overrides.taxCode ?? str(input.taxCode, taxRate > 0 ? "VAT" : "none"),
    taxRate,
    taxAmount,
    netAmount,
    totalAmount: roundMoney(netAmount + taxAmount),
    accountNo: overrides.accountNo ?? (str(input.accountNo) || null),
    inventoryAccount: overrides.inventoryAccount ?? (str(input.inventoryAccount) || null),
    revenueAccount: overrides.revenueAccount ?? (str(input.revenueAccount) || null),
    costCenter: overrides.costCenter ?? (str(input.costCenter) || null),
    sourceLineId: overrides.sourceLineId ?? (str(input.sourceLineId) || null),
    data: { ...cleanRecord(input.data), ...cleanRecord(overrides.data) },
  };
}

async function normaliseDraftLines(
  tx: Tx,
  clientId: number,
  documentId: string,
  docType: string,
  body: JsonRecord,
): Promise<NormalizedLine[]> {
  const rawLines = Array.isArray(body.lines) ? body.lines.filter(isRecord) : [];
  if (!rawLines.length || rawLines.length > 100) throw new TradeServiceError("Add between 1 and 100 document lines.");
  const normalized: NormalizedLine[] = [];
  for (const [index, raw] of rawLines.entries()) {
    const lineNo = index + 1;
    const sourceLineId = str(raw.sourceLineId);
    if (docType === "goods_receipt" || docType === "sales_delivery") {
      if (!sourceLineId) throw new TradeServiceError(`Line ${lineNo}: choose its authorised order line.`);
      const { line: source, document: parent } = await getSourceLine(tx, clientId, sourceLineId);
      const expectedParent = docType === "goods_receipt" ? "purchase_order" : "sales_order";
      const allowedStatuses = docType === "goods_receipt" ? ["Approved", "PartiallyReceived"] : ["Approved", "PartiallyDelivered"];
      const requestedCurrency = str(body.currency, parent.currency).toUpperCase();
      if (requestedCurrency !== parent.currency.toUpperCase()) throw new TradeServiceError(`Line ${lineNo}: fulfilment currency must remain ${parent.currency}.`);
      if (parent.docType !== expectedParent || !allowedStatuses.includes(parent.status)) {
        throw new TradeServiceError(`Line ${lineNo}: the source ${expectedParent.replaceAll("_", " ")} must be approved and still open for fulfilment.`);
      }
      const quantity = roundQty(finite(raw.quantity, 0));
      const proportion = source.quantity > 0 ? quantity / source.quantity : 0;
      const discountAmount = roundMoney(source.discountAmount * proportion);
      normalized.push(calculateLine(raw, clientId, documentId, lineNo, {
        sourceLineId,
        itemCode: source.itemCode,
        itemType: source.itemType,
        description: source.description,
        uom: source.uom,
        quantity,
        unitPrice: source.unitPrice,
        discountAmount,
        taxRate: docType === "sales_delivery" ? source.taxRate : 0,
        taxCode: source.taxCode,
        accountNo: source.accountNo,
        inventoryAccount: source.inventoryAccount,
        revenueAccount: source.revenueAccount,
        data: { parentDocumentId: parent.id, parentDocNo: parent.docNo, sourcePrice: source.unitPrice },
      }));
      continue;
    }
    if (docType === "sales_invoice") {
      if (sourceLineId) {
        const { line: source, document: delivery } = await getSourceLine(tx, clientId, sourceLineId);
        if (delivery.docType !== "sales_delivery" || delivery.status !== "Posted") throw new TradeServiceError(`Line ${lineNo}: invoice lines must reference a posted delivery.`);
        const quantity = roundQty(finite(raw.quantity, source.quantity));
        const proportion = source.quantity > 0 ? quantity / source.quantity : 0;
        normalized.push(calculateLine(raw, clientId, documentId, lineNo, {
          sourceLineId,
          itemCode: source.itemCode,
          itemType: source.itemType,
          description: source.description,
          uom: source.uom,
          quantity,
          unitPrice: source.unitPrice,
          discountAmount: roundMoney(source.discountAmount * proportion),
          taxRate: finite(cleanRecord(source.data).taxRate, source.taxRate),
          taxCode: source.taxCode,
          accountNo: source.accountNo,
          inventoryAccount: source.inventoryAccount,
          revenueAccount: source.revenueAccount,
          data: { deliveryDocumentId: delivery.id, deliveryDocNo: delivery.docNo, contractAsset: true },
        }));
      } else {
        if (allowedItemType(raw.itemType) !== "service" || !str(raw.data && cleanRecord(raw.data).serviceEvidence)) {
          throw new TradeServiceError(`Line ${lineNo}: direct service invoices require service-completion evidence; goods must be invoiced from a posted delivery.`);
        }
        normalized.push(calculateLine(raw, clientId, documentId, lineNo));
      }
      continue;
    }
    if (docType === "supplier_invoice") {
      if (!sourceLineId) throw new TradeServiceError(`Line ${lineNo}: match each supplier invoice line to a receipt or approved order line.`);
      const { line: source, document: sourceDocument } = await getSourceLine(tx, clientId, sourceLineId);
      if (!((sourceDocument.docType === "goods_receipt" && sourceDocument.status === "Posted") || (sourceDocument.docType === "purchase_order" && sourceDocument.status === "Approved" && source.itemType === "service"))) {
        throw new TradeServiceError(`Line ${lineNo}: supplier invoice matching requires a posted receipt or an approved service order.`);
      }
      normalized.push(calculateLine(raw, clientId, documentId, lineNo, {
        sourceLineId,
        itemCode: source.itemCode,
        itemType: source.itemType,
        description: source.description,
        uom: source.uom,
        unitPrice: finite(raw.unitPrice, source.unitPrice),
        taxRate: finite(raw.taxRate, 0),
        accountNo: source.accountNo,
        inventoryAccount: source.inventoryAccount,
        data: { sourceDocumentId: sourceDocument.id, sourceDocNo: sourceDocument.docNo },
      }));
      continue;
    }
    if (["customer_credit_note", "supplier_credit_note", "supplier_debit_note"].includes(docType)) {
      if (!sourceLineId) throw new TradeServiceError(`Line ${lineNo}: credit/debit note lines must reference an original invoice line.`);
      const { line: source, document: invoice } = await getSourceLine(tx, clientId, sourceLineId);
      const expectedType = sourceInvoiceTypeFor(docType);
      if (invoice.docType !== expectedType || invoice.postedAt === null) throw new TradeServiceError(`Line ${lineNo}: note must reference a posted ${expectedType.replaceAll("_", " ")}.`);
      const noteData = cleanRecord(raw.data);
      const priceOnly = noteData.priceOnly === true;
      const quantity = priceOnly ? 0 : roundQty(finite(raw.quantity, source.quantity));
      const price = priceOnly ? roundMoney(finite(raw.creditAmount, 0)) : source.unitPrice;
      const sourceDiscountRate = source.quantity > 0 ? source.discountAmount / source.quantity : 0;
      normalized.push(calculateLine(raw, clientId, documentId, lineNo, {
        sourceLineId,
        itemCode: source.itemCode,
        itemType: source.itemType,
        description: source.description,
        uom: source.uom,
        quantity: priceOnly ? 1 : quantity,
        unitPrice: price,
        discountAmount: priceOnly ? 0 : roundMoney(sourceDiscountRate * quantity),
        taxRate: source.taxRate,
        taxCode: source.taxCode,
        accountNo: source.accountNo,
        inventoryAccount: source.inventoryAccount,
        revenueAccount: source.revenueAccount,
        data: { ...noteData, priceOnly, restock: noteData.restock === true, returnCondition: str(noteData.returnCondition, "saleable"), sourceInvoiceId: invoice.id },
      }));
      continue;
    }
    normalized.push(calculateLine(raw, clientId, documentId, lineNo));
  }
  return normalized;
}

async function insertLines(tx: Tx, lines: NormalizedLine[]) {
  if (lines.length) await tx.insert(tradeDocumentLines).values(lines);
}

async function addDocumentLink(tx: Tx, clientId: number, fromDocumentId: string, toDocumentId: string, type: string, user: UserAccount, fromLineId?: string | null, toLineId?: string | null, quantity = 0, amount = 0) {
  await tx.insert(tradeDocumentLinks).values({
    id: randomUUID(), clientId, fromDocumentId, fromLineId: fromLineId || null, toDocumentId, toLineId: toLineId || null,
    linkType: type, quantity: roundQty(quantity), amount: roundMoney(amount), createdBy: user.username,
  }).onConflictDoNothing();
}

async function recordAudit(tx: Tx, clientId: number, user: UserAccount, eventType: string, recordType: string, recordId: string, beforeState: unknown, afterState: unknown, reason: string, correlationId: string) {
  const occurredAt = new Date();
  await tx.insert(tradeAuditEvents).values({
    id: randomUUID(), clientId, actor: user.username, eventType, recordType, recordId, occurredAt,
    beforeState: beforeState ?? null, afterState: afterState ?? null, reason: reason || null, correlationId, outcome: "committed",
  });
  await tx.insert(auditLog).values({
    id: randomUUID(), timestamp: occurredAt.toISOString(), userId: user.username, username: user.username,
    action: eventType, target: `${recordType}:${recordId}`, details: reason || eventType, clientId,
  });
}

async function enqueueOutbox(tx: Tx, clientId: number, eventKey: string, aggregateType: string, aggregateId: string, payload: JsonRecord) {
  await tx.insert(tradeOutbox).values({ id: randomUUID(), clientId, eventKey, aggregateType, aggregateId, payload }).onConflictDoNothing();
}

async function resolveAccounts(tx: Tx, clientId: number) {
  const rows = await tx.select().from(chartAccounts);
  const found = new Map<string, { name: string; active: boolean }>();
  for (const row of rows) if (row.clientId === null) found.set(row.accountNo, { name: row.name, active: row.active });
  for (const row of rows) if (row.clientId === clientId) found.set(row.accountNo, { name: row.name, active: row.active });
  return found;
}

interface JournalSpec {
  accountNo: string;
  amount: number; // functional-currency amount
  side: Side;
  description: string;
  costCenter?: string | null;
}

async function postJournal(tx: Tx, input: {
  clientId: number; date: string; currency: string; actor: string; maker: string; checker?: string | null;
  sourceDocNo: string; sourceType: string; sourceId: string; eventType: string; lines: JournalSpec[];
}) {
  const date = safeDate(input.date);
  const period = date.slice(0, 7);
  const frozen = await tx.select({ id: closedPeriods.id }).from(closedPeriods)
    .where(and(eq(closedPeriods.clientId, input.clientId), eq(closedPeriods.period, period))).limit(1);
  if (frozen.length) throw new TradeServiceError(`Accounting period ${period} is closed. Post into an open period or request an authorised adjustment.`, 409);
  const lines = input.lines.filter((line) => Math.abs(roundMoney(line.amount)) >= 0.01).map((line) => ({ ...line, amount: roundMoney(line.amount) }));
  const debit = lines.filter((line) => line.side === "debit").reduce((sum, line) => sum + moneyCents(line.amount), 0);
  const credit = lines.filter((line) => line.side === "credit").reduce((sum, line) => sum + moneyCents(line.amount), 0);
  if (!lines.length || debit !== credit) throw new TradeServiceError(`Posting preview does not balance in ${input.currency}; no records were committed.`, 409);
  const accounts = await resolveAccounts(tx, input.clientId);
  const coaNos = new Set([...accounts.entries()].filter(([, account]) => account.active).map(([number]) => number));
  const journalNo = await nextNumber(tx, input.clientId, "JE", date);
  const journal: ACDOCALine[] = lines.map((line) => {
    const account = accounts.get(line.accountNo);
    const name = account?.name || DEFAULT_ACCOUNTS[line.accountNo];
    if (!name || !coaNos.has(line.accountNo)) throw new TradeServiceError(`Account ${line.accountNo} is missing or inactive in this entity's chart of accounts.`, 409);
    return {
      id: randomUUID(), docNo: journalNo, period, date,
      module: input.sourceType === "payment" || input.sourceType === "payment_reversal" ? "FI"
        : input.sourceType.startsWith("sales") || input.sourceType.startsWith("customer") ? "SD" : "MM",
      docType: "JE", accountNo: line.accountNo, accountName: name, costCenter: line.costCenter || "CC-OPS",
      debit: line.side === "debit" ? line.amount : 0, credit: line.side === "credit" ? line.amount : 0,
      currency: input.currency, description: line.description, createdBy: input.maker,
      checkedBy: input.checker && input.checker !== input.maker ? input.checker : undefined,
      clientId: input.clientId, reference: input.sourceDocNo,
    };
  });
  const validationError = validateJournalLines(journal, { allowedClientIds: [input.clientId], closedPeriodKeys: new Set(), coaAccountNos: coaNos });
  if (validationError) throw new TradeServiceError(validationError, 409);
  const totalDebit = journal.reduce((sum, line) => sum + moneyCents(line.debit), 0);
  const totalCredit = journal.reduce((sum, line) => sum + moneyCents(line.credit), 0);
  if (totalDebit !== totalCredit) throw new TradeServiceError("Journal is not balanced in functional currency.", 409);
  await tx.insert(journalLines).values(journal.map((line) => ({
    id: line.id, docNo: line.docNo, period: line.period, date: line.date, module: line.module, docType: line.docType,
    accountNo: line.accountNo, accountName: line.accountName, costCenter: line.costCenter || null, debit: line.debit,
    credit: line.credit, currency: line.currency, description: line.description, createdBy: line.createdBy,
    checkedBy: line.checkedBy || null, isReversed: false, reference: line.reference || null, clientId: line.clientId,
  })));
  const header = buildJournalHeader(journal);
  await tx.insert(journalHeaders).values(header);
  const postingEvent = buildPostingEvent(journal, input.actor, `${input.eventType}:${input.sourceId}`);
  await tx.insert(postingEvents).values(postingEvent);
  await enqueueOutbox(tx, input.clientId, `${journalNo}:journal.posted`, "journal", journalNo, {
    sourceType: input.sourceType, sourceId: input.sourceId, documentNo: input.sourceDocNo, journalNo,
    functionalCurrency: input.currency, debit: totalDebit / 100, credit: totalCredit / 100,
  });
  return { journalNo, lines: journal, amount: totalDebit / 100 };
}

async function getLockedStock(tx: Tx, clientId: number, itemCode: string) {
  const result = await tx.execute(sql`select * from stock_items where client_id = ${clientId} and item_code = ${itemCode} for update`);
  const row = result.rows[0] as Record<string, unknown> | undefined;
  if (!row) throw new TradeServiceError(`Stock item ${itemCode} is not registered in this client workspace.`, 409);
  return {
    id: String(row.id), clientId, itemCode: String(row.item_code), description: String(row.description),
    uom: String(row.uom), quantity: roundQty(finite(row.quantity_on_hand)), value: roundMoney(finite(row.total_value)),
    unitCost: roundMoney(finite(row.unit_cost)), glAccount: str(row.gl_account, "120000"),
    method: str(row.cost_method, "weighted_average"), location: str(row.location, "Main store"),
  };
}

async function setStock(tx: Tx, item: Awaited<ReturnType<typeof getLockedStock>>, quantity: number, value: number) {
  const q = roundQty(quantity);
  const v = roundMoney(value);
  if (q < -EPSILON || v < -EPSILON) throw new TradeServiceError(`Stock update for ${item.itemCode} would create a negative quantity or value.`, 409);
  await tx.update(stockItems).set({
    quantityOnHand: Math.max(0, q), totalValue: Math.max(0, v), unitCost: q > EPSILON ? roundMoney(v / q) : item.unitCost,
  }).where(and(eq(stockItems.clientId, item.clientId), eq(stockItems.itemCode, item.itemCode)));
}

async function recordStockMovement(tx: Tx, input: {
  item: Awaited<ReturnType<typeof getLockedStock>>; date: string; type: string; quantity: number; unitCost: number;
  totalValue: number; documentNo: string; reference: string; note: string;
}) {
  await tx.insert(stockMovements).values({
    id: randomUUID(), clientId: input.item.clientId, date: input.date, itemCode: input.item.itemCode,
    description: input.item.description, type: input.type, quantity: roundQty(input.quantity), unitCost: roundMoney(input.unitCost),
    totalValue: roundMoney(input.totalValue), uom: input.item.uom, docNo: input.documentNo, reference: input.reference, note: input.note,
  });
}

async function receiveStock(tx: Tx, item: Awaited<ReturnType<typeof getLockedStock>>, input: {
  documentId: string; lineId: string; date: string; quantity: number; totalValue: number; currency: string; docNo: string;
}) {
  const q = roundQty(input.quantity);
  const value = roundMoney(input.totalValue);
  const updatedQ = roundQty(item.quantity + q);
  const updatedValue = roundMoney(item.value + value);
  await setStock(tx, item, updatedQ, updatedValue);
  const unitCost = q > 0 ? roundMoney(value / q) : 0;
  await tx.insert(tradeInventoryLots).values({
    id: randomUUID(), clientId: item.clientId, itemCode: item.itemCode, sourceDocumentId: input.documentId,
    sourceLineId: input.lineId, receiptDate: input.date, originalQuantity: q, remainingQuantity: q,
    functionalUnitCost: unitCost, currency: input.currency,
  });
  await recordStockMovement(tx, { item, date: input.date, type: "Receipt", quantity: q, unitCost, totalValue: value, documentNo: input.docNo, reference: input.docNo, note: "Posted goods receipt" });
  return unitCost;
}

async function issueStock(tx: Tx, item: Awaited<ReturnType<typeof getLockedStock>>, input: {
  line: typeof tradeDocumentLines.$inferSelect; date: string; docNo: string;
}): Promise<number> {
  const quantity = roundQty(input.line.quantity);
  if (quantity <= 0) throw new TradeServiceError("Stock issue quantity must be positive.");
  if (quantity > item.quantity + EPSILON) throw new TradeServiceError(`Only ${item.quantity} ${item.uom} of ${item.itemCode} are available. Negative stock is blocked.`, 409);
  let cost = 0;
  const lots = await tx.select().from(tradeInventoryLots)
    .where(and(eq(tradeInventoryLots.clientId, item.clientId), eq(tradeInventoryLots.itemCode, item.itemCode)));
  const usableLots = lots.filter((lot) => lot.remainingQuantity > EPSILON).sort((a, b) => a.receiptDate.localeCompare(b.receiptDate) || a.id.localeCompare(b.id));
  const selections = Array.isArray(input.line.data && (input.line.data as JsonRecord).lotSelections)
    ? (input.line.data as JsonRecord).lotSelections as JsonRecord[] : [];
  if (item.method === "specific") {
    if (!selections.length) throw new TradeServiceError(`Item ${item.itemCode} uses specific identification. Select the exact receipt lot(s) before dispatch.`);
    const selectedQty = roundQty(selections.reduce((sum, s) => sum + finite(s.quantity), 0));
    if (Math.abs(selectedQty - quantity) > EPSILON) throw new TradeServiceError("Specific-lot quantities must equal the dispatch quantity.");
    for (const selection of selections) {
      const lot = usableLots.find((row) => row.id === str(selection.lotId));
      const take = roundQty(finite(selection.quantity));
      if (!lot || take <= 0 || take > lot.remainingQuantity + EPSILON) throw new TradeServiceError("A selected specific-identification lot is unavailable.", 409);
      cost += take * lot.functionalUnitCost;
      await tx.update(tradeInventoryLots).set({ remainingQuantity: roundQty(lot.remainingQuantity - take) }).where(eq(tradeInventoryLots.id, lot.id));
    }
  } else if (item.method === "fifo") {
    let remaining = quantity;
    for (const lot of usableLots) {
      if (remaining <= EPSILON) break;
      const take = Math.min(remaining, lot.remainingQuantity);
      cost += take * lot.functionalUnitCost;
      remaining = roundQty(remaining - take);
      await tx.update(tradeInventoryLots).set({ remainingQuantity: roundQty(lot.remainingQuantity - take) }).where(eq(tradeInventoryLots.id, lot.id));
    }
    if (remaining > EPSILON) {
      const lotQuantity = lots.reduce((sum, lot) => sum + lot.remainingQuantity, 0);
      const openingQuantity = Math.max(0, item.quantity - lotQuantity);
      const openingValue = Math.max(0, item.value - lots.reduce((sum, lot) => sum + lot.remainingQuantity * lot.functionalUnitCost, 0));
      if (remaining > openingQuantity + EPSILON) throw new TradeServiceError(`FIFO layers for ${item.itemCode} do not reconcile to the stock ledger; correct the opening valuation before dispatch.`, 409);
      cost += remaining * (openingQuantity > 0 ? openingValue / openingQuantity : item.unitCost);
    }
  } else {
    cost = quantity * (item.quantity > 0 ? item.value / item.quantity : item.unitCost);
    let remaining = quantity;
    for (const lot of usableLots) {
      if (remaining <= EPSILON) break;
      const take = Math.min(remaining, lot.remainingQuantity);
      remaining = roundQty(remaining - take);
      await tx.update(tradeInventoryLots).set({ remainingQuantity: roundQty(lot.remainingQuantity - take) }).where(eq(tradeInventoryLots.id, lot.id));
    }
  }
  cost = Math.min(roundMoney(cost), item.value);
  await setStock(tx, item, item.quantity - quantity, item.value - cost);
  await recordStockMovement(tx, { item, date: input.date, type: "Issue", quantity: -quantity, unitCost: roundMoney(cost / quantity), totalValue: -cost, documentNo: input.docNo, reference: input.docNo, note: "Cost-of-sales dispatch at carrying value" });
  return cost;
}

async function updateDocument(tx: Tx, clientId: number, id: string, values: Partial<typeof tradeDocuments.$inferInsert>) {
  await tx.update(tradeDocuments).set({ ...values, updatedAt: new Date() }).where(and(eq(tradeDocuments.clientId, clientId), eq(tradeDocuments.id, id)));
}

async function postedChildren(tx: Tx, clientId: number, type: string) {
  const candidates = await tx.select().from(tradeDocuments).where(and(eq(tradeDocuments.clientId, clientId), eq(tradeDocuments.docType, type)));
  const documents = candidates.filter((document) => document.postedAt !== null);
  if (!documents.length) return [];
  const lines = await tx.select().from(tradeDocumentLines).where(and(eq(tradeDocumentLines.clientId, clientId), inArray(tradeDocumentLines.documentId, documents.map((d) => d.id))));
  return lines.map((line) => ({ line, document: documents.find((d) => d.id === line.documentId)! }));
}

async function activeAllocations(tx: Tx, clientId: number) {
  return tx.select().from(tradeAllocations).where(and(eq(tradeAllocations.clientId, clientId), sql`${tradeAllocations.reversedAt} is null`));
}

async function targetOutstanding(tx: Tx, clientId: number, document: typeof tradeDocuments.$inferSelect) {
  const rows = await activeAllocations(tx, clientId);
  return roundMoney(Math.max(0, document.totalAmount - rows.filter((row) => row.targetDocumentId === document.id).reduce((sum, row) => sum + row.amount, 0)));
}

async function sourceUnallocated(tx: Tx, clientId: number, sourceType: string, sourceId: string, amount: number) {
  const rows = await activeAllocations(tx, clientId);
  return roundMoney(Math.max(0, amount - rows.filter((row) => row.sourceType === sourceType && row.sourceId === sourceId).reduce((sum, row) => sum + row.amount, 0)));
}

async function refreshDocumentSettlementStatus(tx: Tx, clientId: number, documentId: string) {
  const doc = await getDocument(tx, clientId, documentId);
  if (doc.docType !== "sales_invoice" && doc.docType !== "supplier_invoice") return;
  const open = await targetOutstanding(tx, clientId, doc);
  const allocated = roundMoney(doc.totalAmount - open);
  const status = open <= EPSILON ? "Paid" : allocated > EPSILON ? "PartiallySettled" : "Open";
  await updateDocument(tx, clientId, doc.id, { status, version: doc.version + 1 });
}

function journalEntry(accountNo: string, amount: number, side: Side, description: string, costCenter?: string | null): JournalSpec {
  return { accountNo, amount: roundMoney(amount), side, description, costCenter };
}

async function reserveSalesOrder(tx: Tx, doc: typeof tradeDocuments.$inferSelect, user: UserAccount) {
  const lines = await getDocumentLines(tx, doc.clientId, doc.id);
  const grouped = new Map<string, typeof lines>();
  for (const line of lines.filter((row) => row.itemType === "stock" && row.itemCode)) {
    const group = grouped.get(line.itemCode!) || [];
    group.push(line);
    grouped.set(line.itemCode!, group);
  }
  for (const [itemCode, orderLines] of grouped) {
    const item = await getLockedStock(tx, doc.clientId, itemCode);
    const active = await tx.select().from(tradeInventoryReservations)
      .where(and(eq(tradeInventoryReservations.clientId, doc.clientId), eq(tradeInventoryReservations.itemCode, itemCode), eq(tradeInventoryReservations.status, "active")));
    const alreadyReservedForThisOrder = active.filter((row) => row.documentId === doc.id).reduce((sum, row) => sum + row.quantity, 0);
    const available = item.quantity - active.reduce((sum, row) => sum + row.quantity, 0) + alreadyReservedForThisOrder;
    const needed = orderLines.reduce((sum, line) => sum + line.quantity, 0);
    if (needed > available + EPSILON) throw new TradeServiceError(`Cannot approve order ${doc.docNo}: only ${roundQty(available)} ${item.uom} of ${itemCode} are available after existing reservations.`, 409);
    for (const line of orderLines) {
      const existing = active.find((row) => row.lineId === line.id);
      if (!existing) await tx.insert(tradeInventoryReservations).values({
        id: randomUUID(), clientId: doc.clientId, documentId: doc.id, lineId: line.id, itemCode,
        quantity: line.quantity, status: "active",
      });
    }
  }
}

async function authorizeSubmission(tx: Tx, doc: typeof tradeDocuments.$inferSelect, user: UserAccount, expectedVersion: number) {
  if (doc.version !== expectedVersion) throw new TradeServiceError("This document changed after you opened it. Refresh and review the latest version before continuing.", 409);
  if (doc.status !== "Draft") throw new TradeServiceError(`Only a draft document can be submitted (current status: ${doc.status}).`, 409);
  const functionalAmount = roundMoney(doc.totalAmount * doc.exchangeRate);
  const canSelfApproveWithinLimit = user.role === "owner" || (user.makerLimit > 0 && functionalAmount <= user.makerLimit + EPSILON);
  const nextStatus = canSelfApproveWithinLimit ? "Approved" : "Submitted";
  if (nextStatus === "Approved" && doc.docType === "sales_order") await reserveSalesOrder(tx, doc, user);
  const now = new Date();
  await updateDocument(tx, doc.clientId, doc.id, {
    status: nextStatus, submittedBy: user.username, approvedBy: canSelfApproveWithinLimit ? user.username : null,
    approvedAt: canSelfApproveWithinLimit ? now : null, version: doc.version + 1,
  });
  await recordAudit(tx, doc.clientId, user, "DOCUMENT_SUBMITTED", doc.docType, doc.id, { status: doc.status, version: doc.version }, { status: nextStatus, version: doc.version + 1 }, "Submitted; self-authorised only within the configured maker limit.", randomUUID());
  return { documentId: doc.id, docNo: doc.docNo, status: nextStatus, version: doc.version + 1, approvalRequired: nextStatus === "Submitted" };
}

async function approveDocument(tx: Tx, doc: typeof tradeDocuments.$inferSelect, user: UserAccount, expectedVersion: number, reason: string) {
  if (doc.version !== expectedVersion) throw new TradeServiceError("Approval is bound to an older document version. Refresh and revalidate before approving.", 409);
  if (doc.status !== "Submitted") throw new TradeServiceError("Only a submitted document can be approved.", 409);
  if (!(user.role === "owner" || user.canCheck)) throw new TradeServiceError("Your role does not have checker authority.", 403);
  if (doc.createdBy === user.username || doc.submittedBy === user.username) throw new TradeServiceError("A maker cannot approve their own submitted document.", 403);
  if (doc.docType === "sales_order") await reserveSalesOrder(tx, doc, user);
  const now = new Date();
  await updateDocument(tx, doc.clientId, doc.id, { status: "Approved", approvedBy: user.username, approvedAt: now, version: doc.version + 1, reason: reason || doc.reason });
  await recordAudit(tx, doc.clientId, user, "DOCUMENT_APPROVED", doc.docType, doc.id, { status: doc.status, version: doc.version }, { status: "Approved", approvedBy: user.username, version: doc.version + 1 }, reason || "Independent checker approval.", randomUUID());
  return { documentId: doc.id, docNo: doc.docNo, status: "Approved", version: doc.version + 1 };
}

async function createDocument(tx: Tx, clientId: number, clientCurrency: string, user: UserAccount, body: JsonRecord) {
  const docType = str(body.docType);
  if (!DOCUMENT_TYPES.has(docType)) throw new TradeServiceError("Choose a supported purchasing or sales document type.");
  const date = safeDate(body.date);
  const currency = str(body.currency, clientCurrency).toUpperCase();
  const exchangeRate = finite(body.exchangeRate, currency === clientCurrency ? 1 : 0);
  if (currency !== clientCurrency && exchangeRate <= 0) throw new TradeServiceError(`Enter the functional-currency exchange rate for ${currency} → ${clientCurrency}.`);
  if (exchangeRate <= 0) throw new TradeServiceError("Exchange rate must be greater than zero.");
  const partyName = str(body.partyName);
  if (["purchase_order", "supplier_invoice", "supplier_credit_note", "supplier_debit_note"].includes(docType) && !partyName) throw new TradeServiceError("Supplier name is required.");
  if (["sales_order", "sales_invoice", "customer_credit_note", "customer_debit_note"].includes(docType) && !partyName) throw new TradeServiceError("Customer name is required.");
  const externalRef = str(body.externalRef);
  if (docType === "supplier_invoice" && !externalRef) throw new TradeServiceError("Supplier invoice number/reference is required for duplicate detection.");
  if (docType === "supplier_invoice" && externalRef) {
    const duplicates = await tx.select({ id: tradeDocuments.id, docNo: tradeDocuments.docNo }).from(tradeDocuments)
      .where(and(eq(tradeDocuments.clientId, clientId), eq(tradeDocuments.docType, docType), sql`lower(${tradeDocuments.partyName}) = ${partyName.toLowerCase()}`, sql`lower(coalesce(${tradeDocuments.externalRef}, '')) = ${externalRef.toLowerCase()}`)).limit(1);
    if (duplicates.length) throw new TradeServiceError(`Duplicate supplier invoice ${externalRef} already exists as ${duplicates[0].docNo}.`, 409);
  }
  const docId = randomUUID();
  const lines = await normaliseDraftLines(tx, clientId, docId, docType, body);
  const netAmount = roundMoney(lines.reduce((sum, line) => sum + line.netAmount, 0));
  const taxAmount = roundMoney(lines.reduce((sum, line) => sum + line.taxAmount, 0));
  const totalAmount = roundMoney(netAmount + taxAmount);
  const docNo = await nextNumber(tx, clientId, PREFIX[docType], date);
  const sourceDocumentIds = new Set<string>();
  const explicitSource = str(body.sourceDocumentId);
  if (explicitSource) sourceDocumentIds.add(explicitSource);
  if (Array.isArray(body.sourceDocumentIds)) for (const id of body.sourceDocumentIds) if (typeof id === "string" && id.trim()) sourceDocumentIds.add(id.trim());
  for (const line of lines) {
    const parentId = str(line.data.parentDocumentId) || str(line.data.sourceDocumentId) || str(line.data.deliveryDocumentId);
    if (parentId) sourceDocumentIds.add(parentId);
    if (line.sourceLineId) {
      const source = await getSourceLine(tx, clientId, line.sourceLineId);
      sourceDocumentIds.add(source.document.id);
    }
  }
  const rawData = cleanRecord(body.data);
  const safeData: JsonRecord = {
    notes: str(rawData.notes),
    paymentTerms: str(rawData.paymentTerms),
    priceTolerancePct: Math.min(100, Math.max(0, finite(rawData.priceTolerancePct, 5))),
    quantityTolerancePct: Math.min(100, Math.max(0, finite(rawData.quantityTolerancePct, 0))),
    landedCost: roundMoney(Math.max(0, finite(rawData.landedCost, 0))),
    landedCostMethod: str(rawData.landedCostMethod, "value"),
    evidenceRef: str(rawData.evidenceRef),
    warehouse: str(rawData.warehouse, "Main store"),
    serviceEvidence: str(rawData.serviceEvidence),
    dueDate: body.dueDate ? safeDate(body.dueDate) : "",
    requisitionId: str(rawData.requisitionId),
    sourceDocumentId: explicitSource,
  };
  const doc = {
    id: docId, clientId, docType, docNo, status: "Draft", date,
    dueDate: body.dueDate ? safeDate(body.dueDate) : null,
    partyId: str(body.partyId) || null, partyName, currency, functionalCurrency: clientCurrency,
    exchangeRate, netAmount, taxAmount, totalAmount, version: 1, createdBy: user.username,
    externalRef: externalRef || null, sourceRef: str(body.sourceRef) || null, reason: str(body.reason) || null,
    data: safeData,
  };
  await tx.insert(tradeDocuments).values(doc);
  await insertLines(tx, lines);
  for (const sourceId of sourceDocumentIds) {
    const source = await getDocument(tx, clientId, sourceId);
    await addDocumentLink(tx, clientId, source.id, docId, `${source.docType}_to_${docType}`, user, null, null, 0, totalAmount);
  }
  for (const line of lines) {
    if (!line.sourceLineId) continue;
    const source = await getSourceLine(tx, clientId, line.sourceLineId);
    await addDocumentLink(tx, clientId, source.document.id, docId, `${source.document.docType}_line_to_${docType}`, user, source.line.id, line.id, line.quantity, line.totalAmount);
  }
  await recordAudit(tx, clientId, user, "DOCUMENT_DRAFT_CREATED", docType, docId, null, { docNo, status: "Draft", lines: lines.length, totalAmount }, "Draft created; no journal or stock posting occurs on order entry.", randomUUID());
  return { documentId: docId, docNo, docType, status: "Draft", version: 1, totalAmount, currency };
}

function addBalancedPair(lines: JournalSpec[], debitAccount: string, creditAccount: string, amount: number, description: string, costCenter?: string | null) {
  const value = roundMoney(amount);
  if (value <= 0) return;
  lines.push(journalEntry(debitAccount, value, "debit", description, costCenter));
  lines.push(journalEntry(creditAccount, value, "credit", description, costCenter));
}

async function postGoodsReceipt(tx: Tx, doc: typeof tradeDocuments.$inferSelect, user: UserAccount) {
  const lines = await getDocumentLines(tx, doc.clientId, doc.id);
  const parentId = str(cleanRecord(doc.data).sourceDocumentId) || str(cleanRecord(doc.data).requisitionId);
  let order = parentId ? await getDocument(tx, doc.clientId, parentId) : null;
  if (!order && lines[0]?.sourceLineId) order = (await getSourceLine(tx, doc.clientId, lines[0].sourceLineId)).document;
  if (!order || order.docType !== "purchase_order" || order.status !== "Approved" && order.status !== "PartiallyReceived") throw new TradeServiceError("Goods can only be received against an approved purchase order.", 409);
  const orderLines = await getDocumentLines(tx, doc.clientId, order.id);
  const received = await postedChildren(tx, doc.clientId, "goods_receipt");
  const priorBySource = new Map<string, number>();
  for (const row of received) if (row.line.sourceLineId) priorBySource.set(row.line.sourceLineId, (priorBySource.get(row.line.sourceLineId) || 0) + row.line.quantity);
  const landedCost = roundMoney(finite(cleanRecord(doc.data).landedCost));
  const stockLines = lines.filter((line) => line.itemType === "stock");
  if (landedCost > 0 && !stockLines.length) throw new TradeServiceError("Landed cost can only be capitalised when the receipt contains stocked trading goods.");
  const allocationBasis = str(cleanRecord(doc.data).landedCostMethod, "value");
  const basisTotal = stockLines.reduce((sum, line) => sum + (allocationBasis === "quantity" ? line.quantity : line.netAmount), 0);
  if (landedCost > 0 && basisTotal <= 0) throw new TradeServiceError("Choose a valid quantity or value basis to allocate landed cost.");
  const postingLines: JournalSpec[] = [];
  let postedDocValue = 0;
  for (const line of lines) {
    const poLine = orderLines.find((candidate) => candidate.id === line.sourceLineId);
    if (!poLine) throw new TradeServiceError(`Receipt line ${line.lineNo} is not linked to a line on ${order.docNo}.`);
    if (roundQty((priorBySource.get(poLine.id) || 0) + line.quantity) > poLine.quantity * (1 + finite(cleanRecord(order.data).quantityTolerancePct) / 100) + EPSILON) {
      throw new TradeServiceError(`Receipt quantity for ${poLine.description} exceeds the authorised order quantity.`, 409);
    }
    const baseValue = roundMoney(line.netAmount);
    const freightAllocation = line.itemType === "stock" && landedCost > 0
      ? roundMoney(landedCost * (allocationBasis === "quantity" ? line.quantity : line.netAmount) / basisTotal) : 0;
    const transactionValue = roundMoney(baseValue + freightAllocation);
    const functionalValue = roundMoney(transactionValue * order.exchangeRate);
    postedDocValue += transactionValue;
    const accountNo = line.itemType === "stock" ? (line.inventoryAccount || "120000")
      : line.itemType === "asset" ? (line.accountNo || "130000")
        : line.accountNo || (line.itemType === "office" ? "628000" : "621000");
    postingLines.push(journalEntry(accountNo, functionalValue, "debit", `${line.description} received on ${doc.docNo}`, line.costCenter));
    postingLines.push(journalEntry("204000", functionalValue, "credit", `Goods received not invoiced · ${order.docNo}`, line.costCenter));
    if (line.itemType === "stock") {
      const item = await getLockedStock(tx, doc.clientId, str(line.itemCode));
      const unitCost = await receiveStock(tx, item, {
        documentId: doc.id, lineId: line.id, date: doc.date, quantity: line.quantity,
        totalValue: functionalValue, currency: doc.currency, docNo: doc.docNo,
      });
      await tx.update(tradeDocumentLines).set({
        unitPrice: line.quantity > 0 ? roundMoney(transactionValue / line.quantity) : line.unitPrice,
        netAmount: transactionValue, totalAmount: transactionValue,
        data: { ...cleanRecord(line.data), receiptFunctionalCost: functionalValue, carryingUnitCost: unitCost, landedCost: freightAllocation },
      }).where(eq(tradeDocumentLines.id, line.id));
    }
  }
  await updateDocument(tx, doc.clientId, doc.id, { status: "Posted", postedAt: new Date(), totalAmount: postedDocValue, netAmount: postedDocValue, version: doc.version + 1 });
  const newReceived = new Map(priorBySource);
  for (const line of lines) if (line.sourceLineId) newReceived.set(line.sourceLineId, (newReceived.get(line.sourceLineId) || 0) + line.quantity);
  const fullyReceived = orderLines.every((line) => (newReceived.get(line.id) || 0) + EPSILON >= line.quantity);
  await updateDocument(tx, doc.clientId, order.id, { status: fullyReceived ? "Received" : "PartiallyReceived", version: order.version + 1 });
  const journal = await postJournal(tx, {
    clientId: doc.clientId, date: doc.date, currency: doc.functionalCurrency, actor: user.username, maker: doc.createdBy,
    checker: doc.approvedBy, sourceDocNo: doc.docNo, sourceType: doc.docType, sourceId: doc.id, eventType: "goods_receipt_posted", lines: postingLines,
  });
  await recordAudit(tx, doc.clientId, user, "GOODS_RECEIPT_POSTED", doc.docType, doc.id, { status: doc.status }, { status: "Posted", journalNo: journal.journalNo, linkedPurchaseOrder: order.docNo, stockAndExpenseValue: postedDocValue }, "Receipt, stock valuation, GRNI and journal posted atomically.", randomUUID());
  await enqueueOutbox(tx, doc.clientId, `${doc.id}:goods-receipt-posted`, doc.docType, doc.id, { docNo: doc.docNo, journalNo: journal.journalNo, purchaseOrder: order.docNo });
  return { documentId: doc.id, docNo: doc.docNo, status: "Posted", journalNo: journal.journalNo, amount: postedDocValue };
}

async function postSupplierInvoice(tx: Tx, doc: typeof tradeDocuments.$inferSelect, user: UserAccount) {
  const lines = await getDocumentLines(tx, doc.clientId, doc.id);
  const previouslyBilled = await postedChildren(tx, doc.clientId, "supplier_invoice");
  const billedBySource = new Map<string, number>();
  for (const row of previouslyBilled) if (row.line.sourceLineId) billedBySource.set(row.line.sourceLineId, (billedBySource.get(row.line.sourceLineId) || 0) + row.line.quantity);
  const postings: JournalSpec[] = [];
  let taxFunctional = 0;
  let invoiceNetFunctional = 0;
  for (const line of lines) {
    const source = await getSourceLine(tx, doc.clientId, str(line.sourceLineId));
    if (source.document.docType === "goods_receipt") {
      if (roundQty((billedBySource.get(source.line.id) || 0) + line.quantity) > source.line.quantity + EPSILON) throw new TradeServiceError(`Supplier invoice ${doc.externalRef || doc.docNo} bills more than the unbilled receipt quantity for ${source.line.description}.`, 409);
      const poLine = source.line.sourceLineId ? await getSourceLine(tx, doc.clientId, source.line.sourceLineId) : null;
      const tolerance = poLine ? finite(cleanRecord(poLine.document.data).priceTolerancePct, 5) : 5;
      const receiptUnit = source.line.quantity > 0 ? source.line.netAmount / source.line.quantity : source.line.unitPrice;
      const variancePct = receiptUnit > 0 ? Math.abs(line.unitPrice - receiptUnit) / receiptUnit * 100 : 0;
      if (variancePct > tolerance + EPSILON) throw new TradeServiceError(`Price variance ${variancePct.toFixed(2)}% exceeds the approved ${tolerance}% tolerance for ${line.description}.`, 409);
      const grniFunctional = roundMoney((receiptUnit * line.quantity) * source.document.exchangeRate);
      postings.push(journalEntry("204000", grniFunctional, "debit", `Clear GRNI for ${source.document.docNo}`, line.costCenter));
      const invoiceLineFunctional = roundMoney(line.netAmount * doc.exchangeRate);
      const variance = roundMoney(invoiceLineFunctional - grniFunctional);
      if (Math.abs(variance) >= 0.01) {
        if (line.itemType === "stock" && source.line.itemCode) {
          const item = await getLockedStock(tx, doc.clientId, source.line.itemCode);
          const lotRows = await tx.select().from(tradeInventoryLots).where(and(eq(tradeInventoryLots.clientId, doc.clientId), eq(tradeInventoryLots.sourceLineId, source.line.id))).limit(1);
          const lot = lotRows[0];
          const receivedQty = source.line.quantity;
          const remainingQty = lot?.remainingQuantity ?? 0;
          const stockShare = receivedQty > 0 ? roundMoney(variance * remainingQty / receivedQty) : 0;
          const soldShare = roundMoney(variance - stockShare);
          if (stockShare !== 0) {
            if (item.value + stockShare < -EPSILON) throw new TradeServiceError("Late supplier cost adjustment would make inventory valuation negative.", 409);
            await setStock(tx, item, item.quantity, item.value + stockShare);
            postings.push(journalEntry(item.glAccount || "120000", stockShare, stockShare >= 0 ? "debit" : "credit", `Late supplier cost allocated to remaining stock · ${doc.externalRef || doc.docNo}`, line.costCenter));
          }
          if (soldShare !== 0) postings.push(journalEntry("504000", Math.abs(soldShare), soldShare >= 0 ? "debit" : "credit", `Late supplier cost allocated to goods sold · ${doc.externalRef || doc.docNo}`, line.costCenter));
          if (lot) await tx.update(tradeInventoryLots).set({ functionalUnitCost: roundMoney(lot.functionalUnitCost + (receivedQty > 0 ? variance / receivedQty : 0)) }).where(eq(tradeInventoryLots.id, lot.id));
          await recordStockMovement(tx, { item, date: doc.date, type: "Freight", quantity: 0, unitCost: 0, totalValue: stockShare, documentNo: doc.docNo, reference: source.document.docNo, note: "Controlled late supplier-cost allocation to remaining inventory" });
        } else {
          postings.push(journalEntry("520000", Math.abs(variance), variance >= 0 ? "debit" : "credit", `Approved supplier price variance · ${doc.externalRef || doc.docNo}`, line.costCenter));
        }
      }
    } else {
      const expectedParent = source.document.docType === "purchase_order" && source.line.itemType === "service";
      if (!expectedParent) throw new TradeServiceError("Supplier invoice line must match a posted goods receipt or an approved service purchase order.", 409);
      const poLineAmount = roundMoney(source.line.unitPrice * line.quantity);
      const tolerance = finite(cleanRecord(source.document.data).priceTolerancePct, 5);
      const variancePct = poLineAmount > 0 ? Math.abs(line.netAmount - poLineAmount) / poLineAmount * 100 : 0;
      if (variancePct > tolerance + EPSILON) throw new TradeServiceError(`Service invoice price exceeds the approved ${tolerance}% purchase-order tolerance.`, 409);
      postings.push(journalEntry(line.accountNo || source.line.accountNo || "621000", roundMoney(line.netAmount * doc.exchangeRate), "debit", `Supplier service invoice ${doc.externalRef || doc.docNo}`, line.costCenter || source.line.costCenter));
    }
    invoiceNetFunctional += roundMoney(line.netAmount * doc.exchangeRate);
    taxFunctional += roundMoney(line.taxAmount * doc.exchangeRate);
    if (line.taxAmount > 0) postings.push(journalEntry("125000", roundMoney(line.taxAmount * doc.exchangeRate), "debit", `Recoverable input tax · ${doc.externalRef || doc.docNo}`, line.costCenter));
  }
  postings.push(journalEntry("200000", roundMoney(doc.totalAmount * doc.exchangeRate), "credit", `Trade payable · ${doc.partyName} · ${doc.externalRef || doc.docNo}`));
  // The source-line GRNI and invoice price variance already form the net debit; input VAT and the AP credit complete the entry.
  const journal = await postJournal(tx, {
    clientId: doc.clientId, date: doc.date, currency: doc.functionalCurrency, actor: user.username, maker: doc.createdBy,
    checker: doc.approvedBy, sourceDocNo: doc.docNo, sourceType: doc.docType, sourceId: doc.id, eventType: "supplier_invoice_posted", lines: postings,
  });
  await updateDocument(tx, doc.clientId, doc.id, { status: "Open", postedAt: new Date(), version: doc.version + 1, netAmount: roundMoney(invoiceNetFunctional / doc.exchangeRate), taxAmount: roundMoney(taxFunctional / doc.exchangeRate) });
  for (const line of lines) {
    if (line.sourceLineId) {
      const source = await getSourceLine(tx, doc.clientId, line.sourceLineId);
      await addDocumentLink(tx, doc.clientId, source.document.id, doc.id, "supplier_invoice_match", user, source.line.id, line.id, line.quantity, line.netAmount);
    }
  }
  await recordAudit(tx, doc.clientId, user, "SUPPLIER_INVOICE_POSTED", doc.docType, doc.id, { status: doc.status }, { status: "Open", journalNo: journal.journalNo, supplierReference: doc.externalRef }, "Invoice matched to receipts; AP, recoverable tax and GRNI/variance posted atomically.", randomUUID());
  await enqueueOutbox(tx, doc.clientId, `${doc.id}:supplier-invoice-posted`, doc.docType, doc.id, { docNo: doc.docNo, supplierReference: doc.externalRef, journalNo: journal.journalNo });
  return { documentId: doc.id, docNo: doc.docNo, status: "Open", journalNo: journal.journalNo, amount: doc.totalAmount };
}

async function postSalesDelivery(tx: Tx, doc: typeof tradeDocuments.$inferSelect, user: UserAccount) {
  const lines = await getDocumentLines(tx, doc.clientId, doc.id);
  const parentIds = new Set(lines.map((line) => str(line.data && (line.data as JsonRecord).parentDocumentId)).filter(Boolean));
  const parentId = str(cleanRecord(doc.data).sourceDocumentId) || [...parentIds][0];
  const order = parentId ? await getDocument(tx, doc.clientId, parentId) : null;
  if (!order || order.docType !== "sales_order" || !["Approved", "PartiallyDelivered"].includes(order.status)) throw new TradeServiceError("Goods can only be dispatched against an approved, still-open customer order.", 409);
  if (!str(cleanRecord(doc.data).evidenceRef)) throw new TradeServiceError("Record the delivery note, proof of delivery or customer acceptance reference before recognizing revenue.");
  const orderLines = await getDocumentLines(tx, doc.clientId, order.id);
  const deliveries = await postedChildren(tx, doc.clientId, "sales_delivery");
  const deliveredBySource = new Map<string, number>();
  for (const row of deliveries) if (row.line.sourceLineId) deliveredBySource.set(row.line.sourceLineId, (deliveredBySource.get(row.line.sourceLineId) || 0) + row.line.quantity);
  const postings: JournalSpec[] = [];
  for (const line of lines) {
    const orderLine = orderLines.find((candidate) => candidate.id === line.sourceLineId);
    if (!orderLine || roundQty((deliveredBySource.get(orderLine.id) || 0) + line.quantity) > orderLine.quantity + EPSILON) throw new TradeServiceError(`Dispatch quantity exceeds the approved sales order for ${line.description}.`, 409);
    let cost = 0;
    if (line.itemType === "stock") {
      const item = await getLockedStock(tx, doc.clientId, str(line.itemCode));
      const reservedRows = await tx.select().from(tradeInventoryReservations)
        .where(and(eq(tradeInventoryReservations.clientId, doc.clientId), eq(tradeInventoryReservations.itemCode, item.itemCode), eq(tradeInventoryReservations.status, "active")));
      const ownReservation = reservedRows.find((reservation) => reservation.lineId === orderLine.id);
      const reservedOther = reservedRows.filter((reservation) => reservation.lineId !== orderLine.id).reduce((sum, reservation) => sum + reservation.quantity, 0);
      const unreservedAvailable = item.quantity - reservedOther;
      if (line.quantity > unreservedAvailable + EPSILON) throw new TradeServiceError(`Dispatch would consume stock reserved for another customer order (${item.itemCode}).`, 409);
      cost = await issueStock(tx, item, { line, date: doc.date, docNo: doc.docNo });
      const updatedQty = roundQty((ownReservation?.quantity || 0) - line.quantity);
      if (ownReservation) await tx.update(tradeInventoryReservations).set({ quantity: Math.max(0, updatedQty), status: updatedQty <= EPSILON ? "released" : "active", releasedAt: updatedQty <= EPSILON ? new Date() : null }).where(eq(tradeInventoryReservations.id, ownReservation.id));
      postings.push(journalEntry("504000", cost, "debit", `Cost of sales · ${line.description} · ${doc.docNo}`, line.costCenter));
      postings.push(journalEntry(item.glAccount || line.inventoryAccount || "120000", cost, "credit", `Inventory issue at carrying value · ${line.itemCode}`, line.costCenter));
      await tx.update(tradeDocumentLines).set({ data: { ...cleanRecord(line.data), costAmount: cost, carryingUnitCost: line.quantity > 0 ? roundMoney(cost / line.quantity) : 0 } }).where(eq(tradeDocumentLines.id, line.id));
    }
    const revenue = roundMoney(line.netAmount * order.exchangeRate);
    if (revenue > 0) {
      postings.push(journalEntry("118100", revenue, "debit", `Unbilled revenue on accepted delivery · ${doc.docNo}`, line.costCenter));
      postings.push(journalEntry(line.revenueAccount || (line.itemType === "service" ? "400000" : "402000"), revenue, "credit", `Revenue recognised on transfer of control · ${line.description}`, line.costCenter));
    }
    await addDocumentLink(tx, doc.clientId, order.id, doc.id, "sales_order_delivery", user, orderLine.id, line.id, line.quantity, line.netAmount);
  }
  const journal = await postJournal(tx, {
    clientId: doc.clientId, date: doc.date, currency: doc.functionalCurrency, actor: user.username, maker: doc.createdBy,
    checker: doc.approvedBy, sourceDocNo: doc.docNo, sourceType: doc.docType, sourceId: doc.id, eventType: "sales_delivery_recognized", lines: postings,
  });
  const orderLinesTotal = orderLines.reduce((sum, line) => sum + line.quantity, 0);
  const deliveredTotal = deliveries.filter((row) => row.line.sourceLineId && orderLines.some((line) => line.id === row.line.sourceLineId)).reduce((sum, row) => sum + row.line.quantity, 0) + lines.reduce((sum, line) => sum + line.quantity, 0);
  await updateDocument(tx, doc.clientId, doc.id, { status: "Posted", postedAt: new Date(), version: doc.version + 1 });
  await updateDocument(tx, doc.clientId, order.id, { status: deliveredTotal + EPSILON >= orderLinesTotal ? "Delivered" : "PartiallyDelivered", version: order.version + 1 });
  await recordAudit(tx, doc.clientId, user, "SALES_DELIVERY_POSTED", doc.docType, doc.id, { status: doc.status }, { status: "Posted", journalNo: journal.journalNo, acceptanceEvidence: cleanRecord(doc.data).evidenceRef }, "Control-transfer revenue and carrying-cost inventory issue posted with delivery evidence.", randomUUID());
  await enqueueOutbox(tx, doc.clientId, `${doc.id}:sales-delivery-posted`, doc.docType, doc.id, { docNo: doc.docNo, orderNo: order.docNo, journalNo: journal.journalNo, evidenceRef: cleanRecord(doc.data).evidenceRef });
  return { documentId: doc.id, docNo: doc.docNo, status: "Posted", journalNo: journal.journalNo };
}

async function postSalesInvoice(tx: Tx, doc: typeof tradeDocuments.$inferSelect, user: UserAccount) {
  const lines = await getDocumentLines(tx, doc.clientId, doc.id);
  const postedInvoices = await postedChildren(tx, doc.clientId, "sales_invoice");
  const billedBySource = new Map<string, number>();
  for (const row of postedInvoices) if (row.line.sourceLineId) billedBySource.set(row.line.sourceLineId, (billedBySource.get(row.line.sourceLineId) || 0) + row.line.quantity);
  const journal: JournalSpec[] = [];
  let netFunctional = 0;
  let taxFunctional = 0;
  for (const line of lines) {
    if (line.sourceLineId) {
      const source = await getSourceLine(tx, doc.clientId, line.sourceLineId);
      if (source.document.docType !== "sales_delivery" || source.document.status !== "Posted") throw new TradeServiceError("Sales invoices can only be issued for posted deliveries.", 409);
      if (roundQty((billedBySource.get(source.line.id) || 0) + line.quantity) > source.line.quantity + EPSILON) throw new TradeServiceError(`Invoice quantity exceeds the unbilled delivery quantity for ${line.description}.`, 409);
      journal.push(journalEntry("118100", roundMoney(line.netAmount * doc.exchangeRate), "credit", `Clear unbilled contract asset · ${source.document.docNo}`, line.costCenter));
      await addDocumentLink(tx, doc.clientId, source.document.id, doc.id, "delivery_sales_invoice", user, source.line.id, line.id, line.quantity, line.netAmount);
    } else {
      const evidence = str(cleanRecord(line.data).serviceEvidence) || str(cleanRecord(doc.data).serviceEvidence);
      if (line.itemType !== "service" || !evidence) throw new TradeServiceError("Direct invoice recognition requires evidence that the service has been performed.");
      journal.push(journalEntry(line.revenueAccount || "400000", roundMoney(line.netAmount * doc.exchangeRate), "credit", `Service revenue on completion · ${line.description}`, line.costCenter));
    }
    if (line.taxAmount > 0) journal.push(journalEntry("220000", roundMoney(line.taxAmount * doc.exchangeRate), "credit", `Output tax liability · ${doc.docNo}`, line.costCenter));
    netFunctional += roundMoney(line.netAmount * doc.exchangeRate);
    taxFunctional += roundMoney(line.taxAmount * doc.exchangeRate);
  }
  journal.push(journalEntry("110000", roundMoney(doc.totalAmount * doc.exchangeRate), "debit", `Trade receivable · ${doc.partyName} · ${doc.docNo}`));
  const result = await postJournal(tx, {
    clientId: doc.clientId, date: doc.date, currency: doc.functionalCurrency, actor: user.username, maker: doc.createdBy,
    checker: doc.approvedBy, sourceDocNo: doc.docNo, sourceType: doc.docType, sourceId: doc.id, eventType: "sales_invoice_issued", lines: journal,
  });
  await updateDocument(tx, doc.clientId, doc.id, { status: "Open", postedAt: new Date(), version: doc.version + 1, netAmount: roundMoney(netFunctional / doc.exchangeRate), taxAmount: roundMoney(taxFunctional / doc.exchangeRate) });
  await recordAudit(tx, doc.clientId, user, "SALES_INVOICE_POSTED", doc.docType, doc.id, { status: doc.status }, { status: "Open", journalNo: result.journalNo, revenueNet: doc.netAmount, taxLiability: doc.taxAmount }, "Invoice issued; tax is a liability and revenue is not recognised a second time for deliveries.", randomUUID());
  await enqueueOutbox(tx, doc.clientId, `${doc.id}:sales-invoice-posted`, doc.docType, doc.id, { docNo: doc.docNo, customer: doc.partyName, journalNo: result.journalNo });
  return { documentId: doc.id, docNo: doc.docNo, status: "Open", journalNo: result.journalNo, amount: doc.totalAmount };
}

async function postNotes(tx: Tx, doc: typeof tradeDocuments.$inferSelect, user: UserAccount) {
  const lines = await getDocumentLines(tx, doc.clientId, doc.id);
  const supplier = doc.docType.startsWith("supplier_");
  const debitNote = doc.docType === "supplier_debit_note" || doc.docType === "customer_debit_note";
  const customerCredit = doc.docType === "customer_credit_note";
  const invoiceType = supplier ? "supplier_invoice" : "sales_invoice";
  const noteTypes = customerCredit ? ["customer_credit_note"] : supplier ? ["supplier_credit_note", "supplier_debit_note"] : [];
  const existingNotes = noteTypes.length ? await tx.select().from(tradeDocuments)
    .where(and(eq(tradeDocuments.clientId, doc.clientId), inArray(tradeDocuments.docType, noteTypes), eq(tradeDocuments.status, "OpenCredit"))) : [];
  const existingNoteLines = existingNotes.length ? await tx.select().from(tradeDocumentLines)
    .where(and(eq(tradeDocumentLines.clientId, doc.clientId), inArray(tradeDocumentLines.documentId, existingNotes.map((row) => row.id)))) : [];
  const priorCreditByLine = new Map<string, number>();
  const priorReturnQtyByLine = new Map<string, number>();
  for (const priorLine of existingNoteLines) {
    if (!priorLine.sourceLineId) continue;
    priorCreditByLine.set(priorLine.sourceLineId, (priorCreditByLine.get(priorLine.sourceLineId) || 0) + priorLine.totalAmount);
    if (cleanRecord(priorLine.data).priceOnly !== true) priorReturnQtyByLine.set(priorLine.sourceLineId, (priorReturnQtyByLine.get(priorLine.sourceLineId) || 0) + priorLine.quantity);
  }
  const journal: JournalSpec[] = [];
  for (const line of lines) {
    if (debitNote && !line.sourceLineId && doc.docType !== "customer_debit_note") throw new TradeServiceError("Supplier debit notes must identify the original supplier invoice line.");
    const source = line.sourceLineId ? await getSourceLine(tx, doc.clientId, line.sourceLineId) : null;
    if (source && source.document.docType !== invoiceType) throw new TradeServiceError("Credit/debit note source does not match the party ledger.");
    if (source && (customerCredit || doc.docType === "supplier_credit_note" || doc.docType === "supplier_debit_note")) {
      const priorCredit = priorCreditByLine.get(source.line.id) || 0;
      if (priorCredit + line.totalAmount > source.line.totalAmount + EPSILON) throw new TradeServiceError(`Cumulative credit exceeds the original invoice line ${source.line.lineNo}.`, 409);
      if (cleanRecord(line.data).priceOnly !== true && line.quantity > 0) {
        const returned = priorReturnQtyByLine.get(source.line.id) || 0;
        if (returned + line.quantity > source.line.quantity + EPSILON) throw new TradeServiceError(`Cumulative return quantity exceeds the original quantity on invoice line ${source.line.lineNo}.`, 409);
        priorReturnQtyByLine.set(source.line.id, returned + line.quantity);
      }
      priorCreditByLine.set(source.line.id, priorCredit + line.totalAmount);
    }
    const net = roundMoney(line.netAmount * doc.exchangeRate);
    const tax = roundMoney(line.taxAmount * doc.exchangeRate);
    if (supplier) {
      if (net + tax > 0) journal.push(journalEntry("200000", net + tax, "debit", `Supplier ${debitNote ? "debit" : "credit"} note · ${doc.docNo}`, line.costCenter));
      if (tax > 0) journal.push(journalEntry("125000", tax, "credit", `Reverse recoverable input tax · ${doc.docNo}`, line.costCenter));
      const returnType = str(cleanRecord(line.data).returnCondition, "saleable");
      if (line.itemType === "stock" && line.itemCode && line.quantity > 0) {
        const item = await getLockedStock(tx, doc.clientId, line.itemCode);
        const carried = roundMoney((item.quantity > 0 ? item.value / item.quantity : item.unitCost) * line.quantity);
        if (line.quantity > item.quantity + EPSILON) throw new TradeServiceError(`Cannot return more ${item.itemCode} than current stock on hand.`, 409);
        await setStock(tx, item, item.quantity - line.quantity, item.value - carried);
        await recordStockMovement(tx, { item, date: doc.date, type: "ReturnOut", quantity: -line.quantity, unitCost: roundMoney(carried / line.quantity), totalValue: -carried, documentNo: doc.docNo, reference: source?.document.docNo || doc.sourceRef || "", note: "Supplier return linked to source invoice" });
        journal.push(journalEntry(item.glAccount || line.inventoryAccount || "120000", carried, "credit", `Return stock to supplier · ${doc.docNo}`, line.costCenter));
        if (carried !== net) journal.push(journalEntry("520000", Math.abs(net - carried), net > carried ? "debit" : "credit", `Supplier return cost difference · ${doc.docNo}`, line.costCenter));
      } else {
        const expenseAccount = line.accountNo || "628000";
        journal.push(journalEntry(expenseAccount, net, "credit", `Supplier credit / office consumption reversal · ${doc.docNo}`, line.costCenter));
      }
    } else if (customerCredit) {
      journal.push(journalEntry(line.revenueAccount || "402000", net, "debit", `Sales return / price credit · ${doc.docNo}`, line.costCenter));
      if (tax > 0) journal.push(journalEntry("220000", tax, "debit", `Reverse output tax · ${doc.docNo}`, line.costCenter));
      journal.push(journalEntry("110000", net + tax, "credit", `Customer receivable credit · ${doc.docNo}`, line.costCenter));
      const noteData = cleanRecord(line.data);
      const originalDeliveryLineId = source?.line.sourceLineId;
      if (!noteData.priceOnly && noteData.restock === true && noteData.returnCondition === "saleable" && line.quantity > 0 && source && originalDeliveryLineId) {
        const delivery = await getSourceLine(tx, doc.clientId, originalDeliveryLineId);
        const costData = cleanRecord(delivery.line.data);
        const originalCost = roundMoney(finite(costData.carryingUnitCost) * line.quantity);
        const item = await getLockedStock(tx, doc.clientId, str(line.itemCode));
        await setStock(tx, item, item.quantity + line.quantity, item.value + originalCost);
        await tx.insert(tradeInventoryLots).values({
          id: randomUUID(), clientId: doc.clientId, itemCode: item.itemCode, sourceDocumentId: doc.id,
          sourceLineId: line.id, receiptDate: doc.date, originalQuantity: line.quantity, remainingQuantity: line.quantity,
          functionalUnitCost: line.quantity ? roundMoney(originalCost / line.quantity) : 0, currency: doc.functionalCurrency,
        });
        await recordStockMovement(tx, { item, date: doc.date, type: "ReturnIn", quantity: line.quantity, unitCost: line.quantity ? roundMoney(originalCost / line.quantity) : 0, totalValue: originalCost, documentNo: doc.docNo, reference: source.document.docNo, note: "Saleable customer return restored at original carrying cost" });
        journal.push(journalEntry(item.glAccount || line.inventoryAccount || "120000", originalCost, "debit", `Saleable returned goods · ${doc.docNo}`, line.costCenter));
        journal.push(journalEntry("504000", originalCost, "credit", `Reverse cost of returned goods · ${doc.docNo}`, line.costCenter));
      }
    } else {
      // Customer debit note: additional receivable and revenue, never a cash receipt.
      journal.push(journalEntry("110000", net + tax, "debit", `Customer debit note · ${doc.docNo}`, line.costCenter));
      journal.push(journalEntry(line.revenueAccount || "402000", net, "credit", `Additional customer revenue · ${doc.docNo}`, line.costCenter));
      if (tax > 0) journal.push(journalEntry("220000", tax, "credit", `Output tax liability · ${doc.docNo}`, line.costCenter));
    }
  }
  const result = await postJournal(tx, {
    clientId: doc.clientId, date: doc.date, currency: doc.functionalCurrency, actor: user.username, maker: doc.createdBy,
    checker: doc.approvedBy, sourceDocNo: doc.docNo, sourceType: doc.docType, sourceId: doc.id, eventType: `${doc.docType}_posted`, lines: journal,
  });
  const isCreditDocument = doc.docType === "customer_credit_note" || doc.docType === "supplier_credit_note" || doc.docType === "supplier_debit_note";
  const nextStatus = isCreditDocument ? "OpenCredit" : "Posted";
  await updateDocument(tx, doc.clientId, doc.id, { status: nextStatus, postedAt: new Date(), version: doc.version + 1 });
  if (isCreditDocument) {
    const docData = cleanRecord(doc.data);
    const sourceDocumentId = str(docData.sourceDocumentId);
    const originalRows = doc.sourceRef
      ? await tx.select().from(tradeDocuments).where(and(eq(tradeDocuments.clientId, doc.clientId), eq(tradeDocuments.docNo, doc.sourceRef))).limit(1)
      : [];
    const original = originalRows[0] || (sourceDocumentId ? await getDocument(tx, doc.clientId, sourceDocumentId) : null);
    if (original) {
      const sourceType = doc.docType === "customer_credit_note" ? "customer_credit_note" : "supplier_credit_note";
      const available = await sourceUnallocated(tx, doc.clientId, sourceType, doc.id, doc.totalAmount);
      const open = await targetOutstanding(tx, doc.clientId, original);
      const autoAllocation = roundMoney(Math.min(available, open));
      if (autoAllocation > 0) await tx.insert(tradeAllocations).values({
        id: randomUUID(), clientId: doc.clientId, sourceType, sourceId: doc.id, targetDocumentId: original.id,
        amount: autoAllocation, currency: doc.currency, allocationDate: doc.date, createdBy: user.username,
      });
      await refreshDocumentSettlementStatus(tx, doc.clientId, original.id);
    }
  }
  await recordAudit(tx, doc.clientId, user, `${doc.docType.toUpperCase()}_POSTED`, doc.docType, doc.id, { status: doc.status }, { status: nextStatus, journalNo: result.journalNo, sourceRef: doc.sourceRef }, `${doc.docType.replaceAll("_", " ")} posted as a linked correcting document; original history is retained.`, randomUUID());
  await enqueueOutbox(tx, doc.clientId, `${doc.id}:${doc.docType}:posted`, doc.docType, doc.id, { docNo: doc.docNo, sourceRef: doc.sourceRef, journalNo: result.journalNo });
  return { documentId: doc.id, docNo: doc.docNo, status: nextStatus, journalNo: result.journalNo };
}

async function postDocument(tx: Tx, clientCurrency: string, doc: typeof tradeDocuments.$inferSelect, user: UserAccount, expectedVersion: number) {
  if (doc.version !== expectedVersion) throw new TradeServiceError("This document changed before posting. Refresh it and preview the current effects.", 409);
  if (doc.status === "Posted" || doc.postedAt) throw new TradeServiceError("Posted history is immutable. Correct it with a linked credit/debit note or reversal.", 409);
  if (doc.status !== "Approved") throw new TradeServiceError("Submit and approve this document before posting. Above-limit documents require a different checker.", 409);
  if (doc.functionalCurrency !== clientCurrency) throw new TradeServiceError("The document's functional-currency snapshot no longer matches the entity setup. Review the currency before posting.", 409);
  if (doc.docType === "goods_receipt") return postGoodsReceipt(tx, doc, user);
  if (doc.docType === "supplier_invoice") return postSupplierInvoice(tx, doc, user);
  if (doc.docType === "sales_delivery") return postSalesDelivery(tx, doc, user);
  if (doc.docType === "sales_invoice") return postSalesInvoice(tx, doc, user);
  if (["customer_credit_note", "supplier_credit_note", "supplier_debit_note", "customer_debit_note"].includes(doc.docType)) return postNotes(tx, doc, user);
  if (doc.docType === "purchase_order" || doc.docType === "purchase_requisition" || doc.docType === "sales_order") {
    throw new TradeServiceError("This is an authorisation document, not a financial posting. It creates no journal until receipt, delivery, invoice or payment occurs.", 409);
  }
  throw new TradeServiceError("This document type cannot be posted.");
}

async function postPayment(tx: Tx, clientCurrency: string, user: UserAccount, body: JsonRecord) {
  const clientId = finite(body.clientId);
  const paymentType = str(body.paymentType);
  if (!["customer_receipt", "customer_advance", "supplier_payment"].includes(paymentType)) throw new TradeServiceError("Select a customer receipt, customer advance or supplier payment.");
  const partyName = str(body.partyName);
  const amount = roundMoney(finite(body.amount));
  const withheldAmount = roundMoney(finite(body.withheldAmount));
  const date = safeDate(body.date);
  const currency = str(body.currency, clientCurrency).toUpperCase();
  const exchangeRate = finite(body.exchangeRate, currency === clientCurrency ? 1 : 0);
  if (!partyName || amount <= 0) throw new TradeServiceError("Payee/party and a positive payment amount are required.");
  if (withheldAmount < 0 || withheldAmount > amount + EPSILON) throw new TradeServiceError("Withholding cannot exceed the gross settlement.");
  if (currency !== clientCurrency && exchangeRate <= 0) throw new TradeServiceError(`Enter the functional-currency exchange rate for ${currency} → ${clientCurrency}.`);
  if (exchangeRate <= 0) throw new TradeServiceError("Exchange rate must be greater than zero.");
  const functionalTotal = roundMoney(amount * exchangeRate);
  if (user.role !== "owner" && user.makerLimit > 0 && functionalTotal > user.makerLimit + EPSILON) throw new TradeServiceError("This payment exceeds your maker limit. It was not posted; submit it for independent payment approval.", 403);
  if (user.role !== "owner" && user.makerLimit <= 0) throw new TradeServiceError("Your role has no payment posting limit. Request a checker to approve this payment.", 403);
  if (paymentType === "customer_advance" && Array.isArray(body.allocations) && body.allocations.length) throw new TradeServiceError("A customer advance is held as a contract liability until a sale qualifies for recognition.");
  const bankAccountId = Math.trunc(finite(body.bankAccountId));
  const bankRows = await tx.select().from(bankAccounts).where(and(eq(bankAccounts.id, bankAccountId), eq(bankAccounts.clientId, clientId))).limit(1);
  const bank = bankRows[0];
  if (!bank) throw new TradeServiceError("Choose a bank/cash account belonging to this client workspace.", 409);
  if (bank.currency.toUpperCase() !== currency) throw new TradeServiceError(`The selected cashbook account is in ${bank.currency}; choose a ${currency} account or enter an authorised transfer.`);
  const cashAmount = roundMoney(amount - withheldAmount);
  // Treasury integration: the Banking and Payment desks read bank_accounts.balance
  // as the live treasury position, so a trade payment must move it (and may not
  // overdraw it) exactly like every other disbursement in the system.
  if (paymentType === "supplier_payment" && bank.balance + EPSILON < cashAmount) {
    throw new TradeServiceError(`Insufficient funds: ${bank.name} holds ${bank.currency} ${roundMoney(bank.balance).toFixed(2)} but ${roundMoney(cashAmount).toFixed(2)} is required. Nothing was posted.`, 409);
  }
  const allocationsInput = Array.isArray(body.allocations) ? body.allocations.filter(isRecord) : [];
  const active = await activeAllocations(tx, clientId);
  let allocatedTotal = 0;
  const allocationsToCreate: Array<{ document: typeof tradeDocuments.$inferSelect; amount: number }> = [];
  for (const [index, input] of allocationsInput.entries()) {
    const docId = str(input.documentId);
    const allocAmount = roundMoney(finite(input.amount));
    if (!docId || allocAmount <= 0) throw new TradeServiceError(`Allocation ${index + 1} needs an open invoice and a positive amount.`);
    const target = await getDocument(tx, clientId, docId);
    const expectedDocType = paymentType === "supplier_payment" ? "supplier_invoice" : "sales_invoice";
    if (target.docType !== expectedDocType || !["Open", "PartiallySettled", "Paid"].includes(target.status)) throw new TradeServiceError(`Allocation ${index + 1} must reference a posted ${expectedDocType.replaceAll("_", " ")}.`);
    if (target.currency !== currency) throw new TradeServiceError(`Payment and open item currencies differ (${currency} / ${target.currency}); settle through an authorised foreign-currency payment with an explicit exchange workflow.`);
    const open = roundMoney(Math.max(0, target.totalAmount - active.filter((row) => row.targetDocumentId === target.id).reduce((sum, row) => sum + row.amount, 0) - allocationsToCreate.filter((row) => row.document.id === target.id).reduce((sum, row) => sum + row.amount, 0)));
    if (allocAmount > open + EPSILON) throw new TradeServiceError(`Allocation exceeds the ${target.docNo} open balance of ${open.toFixed(2)} ${currency}.`, 409);
    allocationsToCreate.push({ document: target, amount: allocAmount });
    allocatedTotal += allocAmount;
  }
  allocatedTotal = roundMoney(allocatedTotal);
  if (allocatedTotal > amount + EPSILON) throw new TradeServiceError("Allocations cannot exceed available payment funds.", 409);
  if (withheldAmount > EPSILON && paymentType === "customer_receipt" && allocatedTotal + EPSILON < amount) throw new TradeServiceError("Customer withholding is only recorded against an identified invoice; do not treat it as an unallocated cash advance.");
  const docNo = await nextNumber(tx, clientId, "PMT", date);
  const id = randomUUID();
  const unallocated = roundMoney(amount - allocatedTotal);
  const journalLinesForPayment: JournalSpec[] = [];
  const bankGl = bank.glAccount || (bank.kind === "cash" ? "102000" : "100000");
  if (cashAmount > 0) journalLinesForPayment.push(journalEntry(bankGl, roundMoney(cashAmount * exchangeRate), paymentType === "supplier_payment" ? "credit" : "debit", `${paymentType === "supplier_payment" ? "Supplier payment" : "Customer receipt"} · ${partyName} · ${docNo}`));
  if (withheldAmount > 0) journalLinesForPayment.push(journalEntry(paymentType === "supplier_payment" ? "209000" : "115000", roundMoney(withheldAmount * exchangeRate), paymentType === "supplier_payment" ? "credit" : "debit", `${paymentType === "supplier_payment" ? "Supplier income tax withheld" : "Customer withholding tax receivable"} · ${docNo}`));
  for (const allocation of allocationsToCreate) {
    const functionalInvoiceAmount = roundMoney(allocation.amount * allocation.document.exchangeRate);
    journalLinesForPayment.push(journalEntry(paymentType === "supplier_payment" ? "200000" : "110000", functionalInvoiceAmount, paymentType === "supplier_payment" ? "debit" : "credit", `Open-item settlement · ${allocation.document.docNo}`));
  }
  if (unallocated > 0) journalLinesForPayment.push(journalEntry(paymentType === "supplier_payment" ? "116000" : "225000", roundMoney(unallocated * exchangeRate), paymentType === "supplier_payment" ? "debit" : "credit", `${paymentType === "supplier_payment" ? "Supplier advance" : "Customer advance / unallocated receipt"} · ${docNo}`));
  const functionalDebits = roundMoney(journalLinesForPayment.filter((line) => line.side === "debit").reduce((sum, line) => sum + line.amount, 0));
  const functionalCredits = roundMoney(journalLinesForPayment.filter((line) => line.side === "credit").reduce((sum, line) => sum + line.amount, 0));
  const fxDifference = roundMoney(functionalDebits - functionalCredits);
  if (fxDifference > EPSILON) journalLinesForPayment.push(journalEntry("491000", fxDifference, "credit", `Realised foreign exchange gain · ${docNo}`));
  if (fxDifference < -EPSILON) journalLinesForPayment.push(journalEntry("580000", -fxDifference, "debit", `Realised foreign exchange loss · ${docNo}`));
  const journal = await postJournal(tx, {
    clientId, date, currency: clientCurrency, actor: user.username, maker: user.username, checker: user.username,
    sourceDocNo: docNo, sourceType: "payment", sourceId: id, eventType: "open_item_payment", lines: journalLinesForPayment,
  });
  await tx.insert(tradePayments).values({
    id, clientId, paymentNo: docNo, paymentType, partyId: str(body.partyId) || null, partyName, date, currency,
    functionalCurrency: clientCurrency, exchangeRate, amount, functionalAmount: functionalTotal, cashAmount,
    withheldAmount, method: str(body.method, "bank_transfer"), bankAccountId, reference: str(body.reference) || null,
    status: "posted", createdBy: user.username,
  });
  for (const allocation of allocationsToCreate) {
    await tx.insert(tradeAllocations).values({
      id: randomUUID(), clientId, sourceType: "payment", sourceId: id, targetDocumentId: allocation.document.id,
      amount: allocation.amount, currency, allocationDate: date, createdBy: user.username,
    });
  }
  await tx.insert(tradeCashMovements).values({
    id: randomUUID(), clientId, bankAccountId, paymentId: id, date,
    amount: paymentType === "supplier_payment" ? -cashAmount : cashAmount,
    functionalAmount: paymentType === "supplier_payment" ? -roundMoney(cashAmount * exchangeRate) : roundMoney(cashAmount * exchangeRate),
    currency, reference: str(body.reference, docNo),
  });
  if (cashAmount > 0) {
    await tx.update(bankAccounts)
      .set({ balance: roundMoney(bank.balance + (paymentType === "supplier_payment" ? -cashAmount : cashAmount)) })
      .where(and(eq(bankAccounts.id, bank.id), eq(bankAccounts.clientId, clientId)));
  }
  for (const allocation of allocationsToCreate) await refreshDocumentSettlementStatus(tx, clientId, allocation.document.id);
  await recordAudit(tx, clientId, user, "PAYMENT_POSTED", "payment", id, null, { paymentNo: docNo, paymentType, amount, cashAmount, withheldAmount, allocated: allocatedTotal, unallocated }, "Cash movement, open-item allocation and journal posted atomically.", randomUUID());
  await enqueueOutbox(tx, clientId, `${id}:payment-posted`, "payment", id, { paymentNo: docNo, type: paymentType, partyName, amount, cashAmount, journalNo: journal.journalNo });
  return { paymentId: id, paymentNo: docNo, status: "posted", journalNo: journal.journalNo, allocated: allocatedTotal, unallocated, amount, cashAmount };
}

async function allocateExisting(tx: Tx, clientId: number, user: UserAccount, body: JsonRecord) {
  const sourceType = str(body.sourceType);
  if (!["payment", "customer_credit_note", "supplier_credit_note"].includes(sourceType)) throw new TradeServiceError("Only posted payments and credit notes can be allocated.");
  const sourceId = str(body.sourceId);
  const sourceDocumentOrPayment = sourceType === "payment" ? null : await getDocument(tx, clientId, sourceId);
  const paymentRows = sourceType === "payment" ? await tx.select().from(tradePayments).where(and(eq(tradePayments.clientId, clientId), eq(tradePayments.id, sourceId))).limit(1) : [];
  const payment = paymentRows[0];
  if (sourceType === "payment" && (!payment || payment.status !== "posted")) throw new TradeServiceError("The payment source is not available for allocation.", 409);
  if (sourceDocumentOrPayment && sourceDocumentOrPayment.status !== "OpenCredit") throw new TradeServiceError("The credit note has no available unallocated balance.", 409);
  const sourceAmount = payment?.amount ?? sourceDocumentOrPayment?.totalAmount ?? 0;
  const sourceCurrency = payment?.currency ?? sourceDocumentOrPayment?.currency ?? "";
  const available = await sourceUnallocated(tx, clientId, sourceType, sourceId, sourceAmount);
  const allocationsInput = Array.isArray(body.allocations) ? body.allocations.filter(isRecord) : [];
  if (!allocationsInput.length) throw new TradeServiceError("Select at least one open item to allocate.");
  const newRows: Array<{ target: typeof tradeDocuments.$inferSelect; amount: number }> = [];
  let sum = 0;
  const prior = await activeAllocations(tx, clientId);
  for (const [index, input] of allocationsInput.entries()) {
    const target = await getDocument(tx, clientId, str(input.documentId));
    const expected = sourceType === "supplier_credit_note" || payment?.paymentType === "supplier_payment" ? "supplier_invoice" : "sales_invoice";
    if (target.docType !== expected || !["Open", "PartiallySettled"].includes(target.status)) throw new TradeServiceError(`Allocation ${index + 1} must target an open ${expected.replaceAll("_", " ")}.`);
    if (target.currency !== sourceCurrency) throw new TradeServiceError("Allocation source and open-item currencies must match; exchange differences are recorded at payment posting.");
    const amount = roundMoney(finite(input.amount));
    if (amount <= 0) throw new TradeServiceError("Allocation amounts must be positive.");
    const already = prior.filter((row) => row.targetDocumentId === target.id).reduce((n, row) => n + row.amount, 0);
    const requested = newRows.filter((row) => row.target.id === target.id).reduce((n, row) => n + row.amount, 0);
    if (amount > target.totalAmount - already - requested + EPSILON) throw new TradeServiceError(`Allocation exceeds open balance on ${target.docNo}.`, 409);
    newRows.push({ target, amount });
    sum = roundMoney(sum + amount);
  }
  if (sum > available + EPSILON) throw new TradeServiceError(`Allocation ${sum.toFixed(2)} exceeds the available ${available.toFixed(2)} ${sourceCurrency}.`, 409);
  for (const allocation of newRows) {
    await tx.insert(tradeAllocations).values({ id: randomUUID(), clientId, sourceType, sourceId, targetDocumentId: allocation.target.id, amount: allocation.amount, currency: sourceCurrency, allocationDate: safeDate(body.date), createdBy: user.username });
    if (sourceType === "payment" && payment && (payment.paymentType === "customer_advance" || payment.paymentType === "customer_receipt" || payment.paymentType === "supplier_payment")) {
      const isSupplier = payment.paymentType === "supplier_payment";
      const invoiceFunctional = roundMoney(allocation.amount * allocation.target.exchangeRate);
      const advanceFunctional = roundMoney(allocation.amount * payment.exchangeRate);
      const entries: JournalSpec[] = [
        journalEntry(isSupplier ? "200000" : "225000", invoiceFunctional, "debit", `Release advance against ${allocation.target.docNo}`),
        journalEntry(isSupplier ? "116000" : "110000", advanceFunctional, "credit", `Apply unallocated payment ${payment.paymentNo}`),
      ];
      const delta = roundMoney(invoiceFunctional - advanceFunctional);
      if (delta > EPSILON) entries.push(journalEntry("491000", delta, "credit", `Realised FX gain on advance ${payment.paymentNo}`));
      if (delta < -EPSILON) entries.push(journalEntry("580000", -delta, "debit", `Realised FX loss on advance ${payment.paymentNo}`));
      await postJournal(tx, {
        clientId, date: safeDate(body.date), currency: payment.functionalCurrency, actor: user.username, maker: user.username, checker: user.username,
        sourceDocNo: payment.paymentNo, sourceType: "payment", sourceId: payment.id, eventType: `advance_allocated:${allocation.target.id}`,
        lines: entries,
      });
    }
    await refreshDocumentSettlementStatus(tx, clientId, allocation.target.id);
  }
  await recordAudit(tx, clientId, user, "OPEN_ITEM_ALLOCATED", sourceType, sourceId, { available }, { allocated: sum, targets: newRows.map((row) => row.target.docNo) }, str(body.reason, "Open-item allocation."), randomUUID());
  return { sourceId, allocated: sum, availableAfter: roundMoney(available - sum), allocations: newRows.map((row) => ({ documentId: row.target.id, docNo: row.target.docNo, amount: row.amount })) };
}

async function reversePayment(tx: Tx, clientId: number, user: UserAccount, body: JsonRecord) {
  const paymentId = str(body.paymentId);
  const paymentRows = await tx.select().from(tradePayments).where(and(eq(tradePayments.clientId, clientId), eq(tradePayments.id, paymentId))).limit(1);
  const payment = paymentRows[0];
  if (!payment || payment.status !== "posted") throw new TradeServiceError("Only an unreversed posted payment can be reversed.", 409);
  if (!(user.role === "owner" || user.canCheck)) throw new TradeServiceError("Payment reversals require checker authority.", 403);
  if (!str(body.reason)) throw new TradeServiceError("A reversal reason is required for the audit trail.");
  const oldLines = await tx.select().from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.docNo, payment.paymentNo)));
  // The payment voucher is the source document. Its journal is located by the reference field.
  const journalRows = await tx.select().from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.reference, payment.paymentNo)));
  const sourceLines = oldLines.length ? oldLines : journalRows;
  if (!sourceLines.length) throw new TradeServiceError("The original payment journal could not be found; no reversal was made.", 409);
  const date = safeDate(body.date);
  const reversalNo = await nextNumber(tx, clientId, "REV", date);
  const reverseSpecs = sourceLines.map((line) => line.debit > 0
    ? journalEntry(line.accountNo, line.debit, "credit", `Reversal of ${payment.paymentNo} · ${str(body.reason)}`, line.costCenter)
    : journalEntry(line.accountNo, line.credit, "debit", `Reversal of ${payment.paymentNo} · ${str(body.reason)}`, line.costCenter));
  const journal = await postJournal(tx, {
    clientId, date, currency: payment.functionalCurrency, actor: user.username, maker: payment.createdBy, checker: user.username,
    sourceDocNo: reversalNo, sourceType: "payment_reversal", sourceId: payment.id, eventType: "payment_reversed", lines: reverseSpecs,
  });
  const now = new Date();
  await tx.update(tradePayments).set({ status: "reversed", reversedAt: now }).where(eq(tradePayments.id, payment.id));
  const paymentAllocations = await tx.select().from(tradeAllocations).where(and(eq(tradeAllocations.clientId, clientId), eq(tradeAllocations.sourceType, "payment"), eq(tradeAllocations.sourceId, payment.id)));
  await tx.update(tradeAllocations).set({ reversedAt: now }).where(and(eq(tradeAllocations.clientId, clientId), eq(tradeAllocations.sourceType, "payment"), eq(tradeAllocations.sourceId, payment.id)));
  const reversalId = randomUUID();
  await tx.insert(tradePayments).values({
    id: reversalId, clientId, paymentNo: reversalNo, paymentType: "reversal", partyId: payment.partyId, partyName: payment.partyName,
    date, currency: payment.currency, functionalCurrency: payment.functionalCurrency, exchangeRate: payment.exchangeRate,
    amount: payment.amount, functionalAmount: payment.functionalAmount, cashAmount: payment.cashAmount, withheldAmount: payment.withheldAmount,
    method: payment.method, bankAccountId: payment.bankAccountId, reference: str(body.reason), status: "posted", reversalOf: payment.id, createdBy: user.username,
  });
  if (payment.bankAccountId) {
    await tx.insert(tradeCashMovements).values({
      id: randomUUID(), clientId, bankAccountId: payment.bankAccountId, paymentId: reversalId, date,
      amount: payment.paymentType === "supplier_payment" ? payment.cashAmount : -payment.cashAmount,
      functionalAmount: payment.paymentType === "supplier_payment" ? payment.cashAmount * payment.exchangeRate : -payment.cashAmount * payment.exchangeRate,
      currency: payment.currency, reference: reversalNo,
    });
    // Put the cash back (supplier payment) or take it out again (customer receipt) so
    // the treasury balance read by the Banking desk follows the reversal.
    if (payment.cashAmount > 0) {
      const bankRows = await tx.select().from(bankAccounts).where(and(eq(bankAccounts.id, payment.bankAccountId), eq(bankAccounts.clientId, clientId))).limit(1);
      if (bankRows[0]) {
        const delta = payment.paymentType === "supplier_payment" ? payment.cashAmount : -payment.cashAmount;
        if (bankRows[0].balance + delta < -EPSILON) throw new TradeServiceError(`Reversing ${payment.paymentNo} would overdraw ${bankRows[0].name}; the receipt has already been spent. Record a refund payment instead.`, 409);
        await tx.update(bankAccounts).set({ balance: roundMoney(bankRows[0].balance + delta) }).where(eq(bankAccounts.id, bankRows[0].id));
      }
    }
  }
  for (const allocation of paymentAllocations) await refreshDocumentSettlementStatus(tx, clientId, allocation.targetDocumentId);
  await recordAudit(tx, clientId, user, "PAYMENT_REVERSED", "payment", payment.id, { status: "posted", paymentNo: payment.paymentNo }, { status: "reversed", reversalNo, journalNo: journal.journalNo }, str(body.reason), randomUUID());
  await enqueueOutbox(tx, clientId, `${payment.id}:payment-reversed`, "payment", payment.id, { paymentNo: payment.paymentNo, reversalNo, journalNo: journal.journalNo });
  return { paymentId: payment.id, reversalId, reversalNo, journalNo: journal.journalNo, status: "reversed" };
}

async function importStatement(tx: Tx, clientId: number, user: UserAccount, body: JsonRecord) {
  const bankAccountId = Math.trunc(finite(body.bankAccountId));
  const bankRows = await tx.select().from(bankAccounts).where(and(eq(bankAccounts.clientId, clientId), eq(bankAccounts.id, bankAccountId))).limit(1);
  if (!bankRows[0]) throw new TradeServiceError("Choose a cashbook account belonging to the current entity.");
  const lines = Array.isArray(body.lines) ? body.lines.filter(isRecord) : [];
  if (!lines.length || lines.length > 5000) throw new TradeServiceError("Import between 1 and 5,000 valid bank statement rows.");
  const batchId = randomUUID();
  let inserted = 0;
  let duplicates = 0;
  for (const [index, input] of lines.entries()) {
    const externalRef = str(input.externalRef) || str(input.reference) || `${batchId}-${index + 1}`;
    const amount = roundMoney(finite(input.amount));
    const currency = str(input.currency, bankRows[0].currency).toUpperCase();
    if (currency !== bankRows[0].currency.toUpperCase() || amount === 0) throw new TradeServiceError(`Statement row ${index + 1}: amount and account currency must be valid.`);
    const result = await tx.insert(tradeBankStatements).values({
      id: randomUUID(), clientId, bankAccountId, statementDate: safeDate(input.date), externalRef,
      description: str(input.description, externalRef), amount, currency, importBatch: batchId,
    }).onConflictDoNothing().returning({ id: tradeBankStatements.id });
    if (result.length) inserted += 1; else duplicates += 1;
  }
  await recordAudit(tx, clientId, user, "BANK_STATEMENT_IMPORTED", "bank_account", String(bankAccountId), null, { batchId, inserted, duplicates }, "Statement lines stored; the ledger balance was not overwritten.", randomUUID());
  return { batchId, inserted, duplicates };
}

async function matchStatement(tx: Tx, clientId: number, user: UserAccount, body: JsonRecord) {
  const statementId = str(body.statementLineId);
  const movementId = str(body.cashMovementId);
  const amount = roundMoney(finite(body.amount));
  if (amount <= 0) throw new TradeServiceError("Matching amount must be positive.");
  const statementRows = await tx.select().from(tradeBankStatements).where(and(eq(tradeBankStatements.clientId, clientId), eq(tradeBankStatements.id, statementId))).limit(1);
  const movementRows = await tx.select().from(tradeCashMovements).where(and(eq(tradeCashMovements.clientId, clientId), eq(tradeCashMovements.id, movementId))).limit(1);
  const statement = statementRows[0];
  const movement = movementRows[0];
  if (!statement || !movement || statement.bankAccountId !== movement.bankAccountId || statement.currency !== movement.currency) throw new TradeServiceError("Statement and cashbook records must belong to the same account and currency.", 409);
  const existingMatches = await tx.select().from(tradeBankMatches).where(and(eq(tradeBankMatches.clientId, clientId), eq(tradeBankMatches.statementLineId, statementId)));
  const matched = existingMatches.reduce((sum, row) => sum + row.matchedAmount, 0);
  const movementMatches = await tx.select().from(tradeBankMatches).where(and(eq(tradeBankMatches.clientId, clientId), eq(tradeBankMatches.cashMovementId, movementId)));
  const movementMatched = movementMatches.reduce((sum, row) => sum + row.matchedAmount, 0);
  if (amount > Math.abs(statement.amount) - matched + EPSILON || amount > Math.abs(movement.amount) - movementMatched + EPSILON) throw new TradeServiceError("A statement or book movement cannot be matched beyond its remaining unmatched amount.", 409);
  await tx.insert(tradeBankMatches).values({ id: randomUUID(), clientId, statementLineId: statementId, cashMovementId: movementId, matchedAmount: amount, matchedBy: user.username });
  const nextMatched = roundMoney(matched + amount);
  await tx.update(tradeBankStatements).set({ matchStatus: nextMatched + EPSILON >= Math.abs(statement.amount) ? "matched" : "partial" }).where(eq(tradeBankStatements.id, statementId));
  await recordAudit(tx, clientId, user, "BANK_LINE_MATCHED", "bank_statement_line", statementId, { matched }, { matched: nextMatched, cashMovementId: movementId }, "Cashbook-to-statement match recorded; no ledger balance is overwritten.", randomUUID());
  return { statementLineId: statementId, cashMovementId: movementId, matched: nextMatched, status: nextMatched + EPSILON >= Math.abs(statement.amount) ? "matched" : "partial" };
}

export async function executeTradeCommand(body: JsonRecord, user: UserAccount) {
  const clientId = Math.trunc(finite(body.clientId));
  const action = str(body.action);
  const idempotencyKey = str(body.idempotencyKey);
  if (!action || !idempotencyKey) throw new TradeServiceError("An action and idempotency key are required for every operational command.");
  if (idempotencyKey.length > 180) throw new TradeServiceError("Idempotency key is too long.");
  const requestHash = hashRequest(body);
  const scopedKey = `${action}:${idempotencyKey}`;
  return db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(${LOCK_NAMESPACE}, ${clientId})`);
    const client = await assertClient(tx, clientId, user);
    const previous = await tx.select().from(tradePostingEvents)
      .where(and(eq(tradePostingEvents.clientId, clientId), eq(tradePostingEvents.idempotencyKey, scopedKey))).limit(1);
    if (previous[0]) {
      if (previous[0].requestHash !== requestHash) throw new TradeServiceError("This idempotency key was already used with different content. No changes were made.", 409);
      return { ...(cleanRecord(previous[0].response)), idempotent: true };
    }
    let response: JsonRecord;
    let recordType = action;
    let recordId = "";
    if (action === "create_document") {
      response = await createDocument(tx, clientId, client.currency, user, body);
      recordType = str(body.docType);
      recordId = str(response.documentId);
    } else if (action === "submit_document" || action === "approve_document") {
      const docId = str(body.documentId);
      const doc = await getDocument(tx, clientId, docId);
      const expectedVersion = Math.trunc(finite(body.expectedVersion, -1));
      response = action === "submit_document"
        ? await authorizeSubmission(tx, doc, user, expectedVersion)
        : await approveDocument(tx, doc, user, expectedVersion, str(body.reason));
      recordType = doc.docType;
      recordId = doc.id;
    } else if (action === "post_document") {
      const docId = str(body.documentId);
      const doc = await getDocument(tx, clientId, docId);
      response = await postDocument(tx, client.currency, doc, user, Math.trunc(finite(body.expectedVersion, -1)));
      recordType = doc.docType;
      recordId = doc.id;
    } else if (action === "create_payment") {
      response = await postPayment(tx, client.currency, user, body);
      recordType = "payment";
      recordId = str(response.paymentId);
    } else if (action === "allocate_source") {
      response = await allocateExisting(tx, clientId, user, body);
      recordType = str(body.sourceType);
      recordId = str(body.sourceId);
    } else if (action === "reverse_payment") {
      response = await reversePayment(tx, clientId, user, body);
      recordType = "payment";
      recordId = str(response.paymentId);
    } else if (action === "import_statement") {
      response = await importStatement(tx, clientId, user, body);
      recordType = "bank_statement_import";
      recordId = str(response.batchId);
    } else if (action === "match_statement") {
      response = await matchStatement(tx, clientId, user, body);
      recordType = "bank_statement_line";
      recordId = str(response.statementLineId);
    } else if (action === "record_inbox_event") {
      if (user.role !== "owner") throw new TradeServiceError("Only a firm owner can record an integration event through this administrative endpoint.", 403);
      const provider = str(body.provider);
      const externalEventId = str(body.externalEventId);
      if (!provider || !externalEventId) throw new TradeServiceError("Provider and external event ID are required.");
      const inserted = await tx.insert(tradeInbox).values({ id: randomUUID(), clientId, provider, externalEventId, payload: cleanRecord(body.payload) }).onConflictDoNothing().returning({ id: tradeInbox.id });
      response = { received: inserted.length > 0, duplicate: inserted.length === 0, externalEventId };
      recordType = "integration_inbox";
      recordId = externalEventId;
    } else {
      throw new TradeServiceError("Unsupported operational command.");
    }
    await tx.insert(tradePostingEvents).values({
      id: randomUUID(), clientId, idempotencyKey: scopedKey, requestHash, response, actor: user.username,
      eventType: action, recordType, recordId, createdAt: new Date(),
    });
    return { ...response, idempotent: false };
  });
}

export async function getTradeWorkspace(clientId: number, user: UserAccount) {
  const allowed = hasFirmWideScope(user) || user.clientId === clientId;
  if (!allowed) throw new TradeServiceError("This workspace is outside your tenant scope.", 403);
  const client = await db.select().from(clients).where(eq(clients.id, clientId)).limit(1);
  if (!client[0]) throw new TradeServiceError("The selected workspace does not exist.", 404);
  const [documents, payments, allocations, stock, bankRows, cash, statements, matches, lots, outbox, audit] = await Promise.all([
    db.select().from(tradeDocuments).where(eq(tradeDocuments.clientId, clientId)),
    db.select().from(tradePayments).where(eq(tradePayments.clientId, clientId)),
    db.select().from(tradeAllocations).where(eq(tradeAllocations.clientId, clientId)),
    db.select().from(stockItems).where(eq(stockItems.clientId, clientId)),
    db.select().from(bankAccounts).where(eq(bankAccounts.clientId, clientId)),
    db.select().from(tradeCashMovements).where(eq(tradeCashMovements.clientId, clientId)),
    db.select().from(tradeBankStatements).where(eq(tradeBankStatements.clientId, clientId)),
    db.select().from(tradeBankMatches).where(eq(tradeBankMatches.clientId, clientId)),
    db.select().from(tradeInventoryLots).where(eq(tradeInventoryLots.clientId, clientId)),
    db.select().from(tradeOutbox).where(eq(tradeOutbox.clientId, clientId)),
    db.select().from(tradeAuditEvents).where(eq(tradeAuditEvents.clientId, clientId)),
  ]);
  const ids = documents.map((doc) => doc.id);
  const [lines, links] = ids.length ? await Promise.all([
    db.select().from(tradeDocumentLines).where(and(eq(tradeDocumentLines.clientId, clientId), inArray(tradeDocumentLines.documentId, ids))),
    db.select().from(tradeDocumentLinks).where(and(eq(tradeDocumentLinks.clientId, clientId), inArray(tradeDocumentLinks.fromDocumentId, ids))),
  ]) : [[], []];
  const active = allocations.filter((row) => !row.reversedAt);
  const documentRows = documents.map((doc) => {
    const docLines = lines.filter((line) => line.documentId === doc.id).sort((a, b) => a.lineNo - b.lineNo);
    const settled = active.filter((row) => row.targetDocumentId === doc.id).reduce((sum, row) => sum + row.amount, 0);
    const allocatedFrom = active.filter((row) => row.sourceId === doc.id).reduce((sum, row) => sum + row.amount, 0);
    const balance = ["sales_invoice", "supplier_invoice"].includes(doc.docType) ? roundMoney(Math.max(0, doc.totalAmount - settled))
      : ["customer_credit_note", "supplier_credit_note"].includes(doc.docType) ? roundMoney(Math.max(0, doc.totalAmount - allocatedFrom)) : null;
    return { ...doc, lines: docLines, links: links.filter((link) => link.fromDocumentId === doc.id || link.toDocumentId === doc.id), openBalance: balance };
  });
  const paymentRows = payments.map((payment) => ({
    ...payment,
    allocations: active.filter((row) => row.sourceType === "payment" && row.sourceId === payment.id),
    unallocated: payment.status === "posted" ? roundMoney(Math.max(0, payment.amount - active.filter((row) => row.sourceType === "payment" && row.sourceId === payment.id).reduce((sum, row) => sum + row.amount, 0))) : 0,
  }));
  const functionalCurrency = client[0].currency;
  const cashbook = bankRows.map((bank) => {
    const movements = cash.filter((row) => row.bankAccountId === bank.id);
    return {
      bankAccountId: bank.id, name: bank.name, currency: bank.currency, glAccount: bank.glAccount,
      recordedBalance: bank.balance,
      bookMovementBalance: roundMoney(movements.reduce((sum, row) => sum + row.amount, 0)),
      functionalMovementBalance: roundMoney(movements.reduce((sum, row) => sum + row.functionalAmount, 0)),
      movementCount: movements.length,
    };
  });
  return {
    ok: true, client: { id: client[0].id, code: client[0].code, name: client[0].name, currency: functionalCurrency },
    documents: documentRows, payments: paymentRows, allocations: active, stockItems: stock, bankAccounts: bankRows,
    cashMovements: cash, cashbook, statements, bankMatches: matches, inventoryLots: lots,
    integrationOutbox: outbox, auditEvents: audit,
  };
}

export async function getTradeOutbox(clientId: number, user: UserAccount) {
  if (!hasFirmWideScope(user) && user.clientId !== clientId) throw new TradeServiceError("This outbox is outside your tenant scope.", 403);
  return db.select().from(tradeOutbox).where(eq(tradeOutbox.clientId, clientId)).orderBy(tradeOutbox.createdAt);
}

export async function markOutboxAttempt(clientId: number, id: string, user: UserAccount, error?: string) {
  if (!(user.role === "owner" || user.role === "partner" || user.role === "manager")) throw new TradeServiceError("Only a privileged integration operator can update the outbox.", 403);
  const rows = await db.select().from(tradeOutbox).where(and(eq(tradeOutbox.clientId, clientId), eq(tradeOutbox.id, id))).limit(1);
  if (!rows[0]) throw new TradeServiceError("Outbox record not found.", 404);
  const attempts = rows[0].attempts + 1;
  await db.update(tradeOutbox).set({
    attempts,
    status: error ? "pending" : "sent",
    lastError: error ? error.slice(0, 1000) : null,
    nextAttemptAt: error ? new Date(Date.now() + Math.min(60, 2 ** Math.min(attempts, 6)) * 60_000) : new Date(),
    sentAt: error ? null : new Date(),
  }).where(and(eq(tradeOutbox.clientId, clientId), eq(tradeOutbox.id, id)));
  return { id, status: error ? "pending" : "sent", attempts };
}
