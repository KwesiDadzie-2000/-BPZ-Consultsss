# BPZ Consult ERP — System Review, Remediation and Audit

## 1. Scope and preservation

| Item | Detail |
| --- | --- |
| Source reviewed | Latest upload in `KwesiDadzie-2000/-BPZ-Consultsss`: `review-and-fix-repository.zip` (commit `b079f13`, 5 Nov 2026) |
| What was used | The archive's Next.js application (`src/app`, `src/db`, `src/lib`, `src/components`, `src/utils`, `src/data`, `src/types`, `src/tests`) and the original hardened `next.config.ts` |
| Excluded | The Vite-only review harness (`main.tsx`, `index.css`, `preview/enable.ts`). `isLocalReview()` is always `false` under Next, so the local transport stays inert |
| GitHub | Cloned read-only. Nothing was pushed or changed |
| Template | The BPZ header, sidebar, palette, dashboard and module layouts are unchanged. New modules use the template's own `Card`, `Stat`, `PageHeader` and table classes, and appear as new sidebar entries |

## 2. Critique

**Strengths.** The system already has double-entry journals with immutable posting and reversal, maker-checker approval, entity scoping, period locks, scrypt password hashing, a server-side trade engine, and wide coverage across accounting modules. All 90 existing regression tests pass.

**Weaknesses found.** Calling something "IFRS-compliant" or "SOC 2" in the UI doesn't make it so. The review found:

1. **A fresh deployment could not be used.** Every seeded account got a random password that was never shown to anyone, so no one could sign in. The previous Vite preview hid this by skipping login.
2. **Mixed-case usernames could never sign in.** The login route lower-cases the identifier, but usernames were stored exactly as typed.
3. **User administration had weak guards.** It accepted any role or status string. The last owner could be demoted or suspended, which locks everyone out. A duplicate e-mail caused a 500 error. Credential changes weren't audit-logged and didn't revoke existing sessions.
4. **The IAS 16 PPE note didn't reconcile.** Every "accumulated/impairment" account (intangible amortisation, receivable allowances, right-of-use asset depreciation) was counted as PPE depreciation. Disposals were also shown at gross cost, so the IAS 16.73(e) roll-forward didn't foot.
5. **CSV/formula injection in the Notes to Accounts export.** It built CSV by joining raw strings, bypassing the shared exporter that neutralises formulas.
6. **Dates used UTC instead of local time.** The closed-period guard and default dates used the UTC calendar, so they picked the wrong month around month-end for users outside UTC.
7. **Vulnerable framework.** Next 16.2.6 had a critical advisory.
8. **A React lint error.** A ref was written during render (`react-hooks/refs`) in `useModalFocus`.
9. **Functional gaps against international practice:**
   - No supporting schedules behind the IFRS notes (roll-forwards, ECL matrix, lease liabilities, deferred tax, provisions).
   - No budgeting, forecasting or scenario planning.
   - No KPI scorecard or cash-flow forecast.
   - No data analytics or audit analytics (CAATs).

## 3. Findings and fixes

| ID | Severity | Defect | Fix | Evidence |
| --- | --- | --- | --- | --- |
| F01 | Critical | Fresh database: nobody can sign in | One-time **first-run owner activation** (`/api/auth/setup`). The owner is seeded with no credential unless `BPZ_SEED_PASSWORD_OWNER` is set. Activation uses an advisory lock, enforces the password policy, is audit-logged, closes permanently once used, and can optionally be gated by `BPZ_SETUP_TOKEN` | Smoke tests 2–8 |
| F02 | High | Mixed-case usernames locked out | Login matches with `lower()`. User admin normalises usernames and e-mails | Smoke tests 9, 13 |
| F03 | High | User admin: last-owner lock-out, unvalidated role/status, 500 on duplicate, no audit | Validates every field. Blocks demoting the last active owner and self-suspension. Duplicates return 409. Sessions are revoked on password reset or restriction. All changes go to `USER_*` audit entries | Smoke tests 11–14 |
| F04 | High | IAS 16 note didn't foot | Only PPE-group contra accounts count. Accumulated depreciation on right-of-use assets is classified with ROU assets. Disposals are shown at carrying amount | `extensions.test.ts` "IAS 16 note" |
| F05 | Medium | Notes CSV formula injection | Export now goes through the shared `downloadCsv` (formula-neutralising) | Code review |
| F06 | Medium | UTC dates in period guards | `utils/periods.ts` provides local-calendar helpers, used by the App guard and new desks | Code review |
| F07 | Critical (supply chain) | Next 16.2.6 advisory | Upgraded to Next 16.4.3. No critical advisories remain | `npm audit` |
| F08 | Low | Ref written during render | Ref is now synced inside an effect | ESLint is clean for this rule |

## 4. New capabilities

### 4.1 IFRS Schedules Desk (IFRS group → "IFRS Schedules Desk")

Every schedule shows the note number it supports (taken from the generated IFRS pack). It reconciles to the general ledger and flags differences. Where an adjustment is needed it proposes a **balanced correcting journal**, which posts through the existing journal controls: period locks, chart validation, maker limits and the approvals queue. Each proposal carries an idempotency key, so the same adjustment can't be posted twice. Schedule inputs (leases, provisions and so on) are stored on the server, versioned and audit-logged. Every schedule can be exported to CSV or printed.

| Standard | Schedule |
| --- | --- |
| IAS 16 | Cost and accumulated depreciation roll-forward by asset class, from the asset register. Reconciled to the GL; proposes a depreciation true-up |
| IAS 38 | Intangible assets roll-forward (cost, amortisation, carrying amount) |
| IFRS 16 | Lease register. PV at the incremental borrowing rate, effective-interest amortisation, straight-line ROU depreciation, current/non-current split, undiscounted maturity analysis. Proposes initial-recognition and period journals |
| IAS 2 | Lower of cost and NRV by item, stock movements, register vs GL. Proposes NRV write-downs |
| IFRS 9 | ECL provision matrix by days past due. Allowance required vs booked, with a proposed adjustment. Credit-risk concentration |
| IFRS 15 | Revenue by stream and by timing, revenue by account, contract balances, revenue recognised from opening contract liabilities |
| IAS 12 | Current tax computation (with capital allowances), deferred tax on temporary differences, tax-rate reconciliation. Proposes deferred and current tax journals |
| IAS 37 | Movement in provisions and register of contingent liabilities with disclosure logic |
| IAS 19 | Employee benefit expense and SSNIT defined-contribution cost by department; KMP compensation |
| IFRS 7 / IAS 32 | Categories of financial instruments, borrowings reconciliation, liquidity maturities, FX and interest-rate sensitivity |
| IAS 24 | Related-party transactions and balances, plus KMP |
| IAS 10 | Events after the reporting period, with checks on date and type |
| IAS 33 | Basic and diluted EPS (diluted capped so it can't exceed basic) |
| IAS 36 | Value in use (DCF plus terminal value) vs FVLCD, impairment, headroom, and sensitivity to a +1% discount rate |
| IFRS 8 | Segment results by cost centre, reconciled to entity profit |

### 4.2 Performance Management (Performance & Insights → "Budgeting, Forecast & Scenarios")

- **Budgets.** Versioned per fiscal year (`FY2026-v1`, `-v2` …). They can be seeded from prior-year actuals × growth, from a run-rate, or zero-based, then edited month by month. Workflow is draft → submitted → approved/rejected, and the reviewer must be independent of the preparer and submitter (enforced on the server). Approved budgets are locked; changes need a revision.
- **Budget vs actual.** Monthly and year-to-date figures, favourable/(adverse) variances, materiality flags, a profit bridge (waterfall chart) and CSV export.
- **Rolling forecast.** Four methods: run-rate, linear trend, seasonal and remaining budget. Shows the full-year outturn against budget.
- **Scenario planning.** Base, best and worst cases plus custom scenarios, driven by 14 drivers including price, volume, FX shock and working-capital days. Covers a 1–5 year horizon, gives a probability-weighted expected value, a sensitivity tornado chart, and break-even with margin of safety.
- **Balanced scorecard.** 20 KPIs across four perspectives, with targets saved per entity, RAG status and 6-month trend lines.
- **12-month cash-flow forecast (direct method).** Uses collection and payment lags, a minimum-cash buffer, and extra cash items. Flags months that breach the buffer.

### 4.3 Data Analytics and CAATs (Performance & Insights → "Data Analytics & CAATs")

- 24-month trends for performance and working capital.
- Regression forecast with a 95% band.
- Expense Pareto chart.
- Customer and supplier concentration (HHI).
- Benford's law test (MAD and χ², using Nigrini's thresholds).
- Journal-entry tests based on ISA 240: weekend postings, round amounts, statistical outliers, same maker and checker, manual entries to revenue or cash at period end, possible duplicates, vague descriptions.
- User activity, weekday posting profile and cost-centre profitability.

### 4.4 Server platform

- `entity_workbooks` table and `/api/workbooks`: tenant-scoped, optimistic concurrency (a stale save returns 409), 1 MB payload limit, auditors read-only, maker-checker workflow, everything audit-logged.
- `system_settings` table for activation state.
- Both tables provision themselves through the existing bootstrap DDL.

## 5. Audit evidence

| Check | Result |
| --- | --- |
| `npx next typegen` | Pass |
| `tsc --noEmit` | Pass (0 errors) |
| `npm run build` | Pass (14 routes) |
| Original suites: `sectorTransactions` / `reviewRegressions` | 47/47 and 43/43 pass |
| New suite: `src/tests/extensions.test.ts` | Lease PV and amortisation, PPE footing, the IAS 16 note fix, ECL ageing, VIU, defensive input parsing, variance signs, scenarios, RAG, analytics |
| End-to-end smoke test against the production server | 31/31 pass: activation lifecycle, case-insensitive login, user-admin guards, 409 on stale save, segregation-of-duties refusal, approved-lock, tenant isolation (403), unauthenticated (401), audit trail, security headers |

## 6. Gaps against international standards that remain (not claimed as done)

1. **MFA/TOTP and real SAML/SCIM.** The SSO desk only describes these. Recommended before client rollout (ISO 27001 A.8.5).
2. **State-sync model.** Most operational registers still sync as a browser snapshot through `/api/state`; posted journals are immutable on the server. The new modules use server-authoritative workbooks. Next step: move the remaining registers to the same per-record API.
3. **IAS 21.** There's no full translation or revaluation engine for foreign operations. Consolidation (IFRS 10) eliminations are still manual.
4. **Standards outside the current sectors.** IFRS 17, IFRS 2, IAS 41, IFRS 6 and IFRS 18 (effective 2027) presentation remapping are not implemented. Add them if a client's sector or adoption timeline needs them.
5. **XBRL / iXBRL tagging** for regulator filing is not implemented.
6. **Dependency hygiene.** The production dependency audit is clean: `npm audit --omit=dev` reports 0 vulnerabilities after Next 16.4.3 and patch-level transitive fixes. Some advisories remain in dev-only tooling (drizzle-kit/esbuild chain). They aren't shipped to production; upgrade them with the toolchain.

## 7. Operating notes

- **First run.** The sign-in screen offers "First-run activation" for the owner account. Set `BPZ_SETUP_TOKEN` on public hosts so only operators can activate. Alternatively, set `BPZ_SEED_PASSWORD_OWNER` before the first start; activation is then disabled.
- **Other users.** After activating, the owner creates the other users under **User Access & Restrictions**.
- **Corrections.** Posted journals stay immutable. Correct them with a reversal and a new entry. IFRS schedule adjustments always go through the same controls.
