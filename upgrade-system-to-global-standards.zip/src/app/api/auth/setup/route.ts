import { randomUUID, timingSafeEqual } from "node:crypto";
import { and, eq, isNull, sql } from "drizzle-orm";
import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import { auditLog, systemSettings, users } from "@/db/schema";
import { authJson, createSession, sanitizeUser, SESSION_TTL_MS } from "@/lib/auth";
import { hashPassword, newSalt, passwordPolicyError } from "@/lib/password";

export const dynamic = "force-dynamic";

/**
 * First-run owner activation.
 *
 * DEFECT FIXED: the reviewed build seeded every account with a random,
 * undisclosed password, so a fresh deployment had NO way to sign in. The seed
 * now creates the owner WITHOUT a credential (unless the operator supplied
 * `BPZ_SEED_PASSWORD_OWNER`) and records `owner_activation.pending = true`.
 *
 * This endpoint lets the first operator set the owner password exactly once:
 *  - only while the setting is pending AND the owner still has no credential;
 *  - optionally gated by `BPZ_SETUP_TOKEN` (recommended for public hosts);
 *  - password policy enforced server-side; the change is audit-logged;
 *  - runs under an advisory lock so two concurrent activations cannot race.
 */
const LOCK_KEY = 4_027_332;

async function pendingOwner() {
  const setting = (await db.select().from(systemSettings).where(eq(systemSettings.key, "owner_activation")).limit(1))[0];
  const value = (setting?.value ?? null) as { pending?: boolean; ownerUsername?: string } | null;
  if (!value?.pending || !value.ownerUsername) return null;
  const owner = (await db.select().from(users).where(and(eq(users.username, value.ownerUsername), isNull(users.passwordHash))).limit(1))[0];
  return owner ?? null;
}

function tokenMatches(expected: string, supplied: string): boolean {
  const a = Buffer.from(expected);
  const b = Buffer.from(supplied);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
    const owner = await pendingOwner();
    return authJson(req, {
      ok: true,
      activationAvailable: Boolean(owner),
      tokenRequired: Boolean(process.env.BPZ_SETUP_TOKEN),
      ownerUsername: owner?.username ?? null,
    });
  } catch (error) {
    console.error("setup status failed", error);
    return authJson(req, { ok: false, activationAvailable: false, error: "The workspace database is unavailable." }, { status: 503 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch {
    return authJson(req, { ok: false, error: "The workspace database is unavailable." }, { status: 503 });
  }
  let body: { password?: unknown; confirm?: unknown; setupToken?: unknown } | null = null;
  try {
    body = await req.json();
  } catch {
    return authJson(req, { ok: false, error: "Invalid request body." }, { status: 400 });
  }
  const password = String(body?.password ?? "");
  const confirm = String(body?.confirm ?? "");
  const requiredToken = process.env.BPZ_SETUP_TOKEN;
  if (requiredToken && !tokenMatches(requiredToken, String(body?.setupToken ?? ""))) {
    return authJson(req, { ok: false, error: "The setup token is not valid." }, { status: 403 });
  }
  const policy = passwordPolicyError(password);
  if (policy) return authJson(req, { ok: false, error: policy }, { status: 400 });
  if (password !== confirm) return authJson(req, { ok: false, error: "The two passwords do not match." }, { status: 400 });

  const salt = newSalt();
  const passwordHash = await hashPassword(password, salt);
  const activated = await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(${LOCK_KEY})`);
    const setting = (await tx.select().from(systemSettings).where(eq(systemSettings.key, "owner_activation")).limit(1))[0];
    const value = (setting?.value ?? null) as { pending?: boolean; ownerUsername?: string } | null;
    if (!value?.pending || !value.ownerUsername) return null;
    const updated = await tx
      .update(users)
      .set({ passwordHash, passwordSalt: salt, status: "active" })
      .where(and(eq(users.username, value.ownerUsername), isNull(users.passwordHash)))
      .returning();
    if (!updated[0]) return null;
    const now = new Date().toISOString();
    await tx.update(systemSettings).set({ value: { pending: false, ownerUsername: value.ownerUsername, activatedAt: now }, updatedAt: new Date() }).where(eq(systemSettings.key, "owner_activation"));
    await tx.insert(auditLog).values({ id: randomUUID(), timestamp: now, userId: updated[0].id, username: updated[0].username, action: "OWNER_ACTIVATED", target: updated[0].username, details: "First-run owner credential set", clientId: null });
    return updated[0];
  });
  if (!activated) return authJson(req, { ok: false, error: "Activation is no longer available. Sign in with the owner credentials." }, { status: 409 });

  const token = await createSession(activated.id);
  return authJson(req, { ok: true, user: sanitizeUser(activated), token, expiresInSeconds: SESSION_TTL_MS / 1000 }, { token });
}
