import { immutableJournalConflict } from '@/lib/immutableJournal';
import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import {
  approvalRequests,
  auditLog,
  bankAccounts,
  businessPartners,
  chartAccounts,
  closedPeriods,
  clients,
  companyProfiles,
  disclosureNotes,
  employees,
  journalHeaders,
  journalLines,
  postingEvents,
  payrollRecords,
  prepaymentRecords,
  prepaymentSchedules,
  purchaseOrders,
  salesInvoices,
  stockItems,
  stockMovements,
  fixedAssets,
  taxScheduleEntries,
  users,
} from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope } from "@/lib/auth";
import { validateJournalLines, validateMakerChecker, validatePostingIdentity } from "@/lib/journalValidation";
import { accountPostabilityFor, postingUserDirectory, sessionPostingRecord } from "@/lib/postingControls";
import { buildJournalHeader, buildPostingEvent } from "@/lib/journalPosting";
import { prepareBusinessPartnersForStorage } from "@/lib/businessPartnerSync";
import { eq, inArray, sql } from "drizzle-orm";
import type {
  ACDOCALine,
  AccountMaster,
  ApprovalRequest,
  BankAccount,
  BusinessPartner,
  ClientEntity,
  DisclosureNote,
  EmployeeProfile,
  MonthlyPayrollRecord,
  PrepaymentRecord,
  PrepaymentScheduleLine,
  FixedAsset,
  PurchaseOrder,
  SalesInvoice,
  StockItem,
  StockMovement,
  TaxScheduleEntry,
} from "@/types/accounting";
import type { CompanyProfile } from "@/utils/persistentStorage";

export const dynamic = "force-dynamic";

interface StatePayload {
  clients?: ClientEntity[];
  journalLines?: ACDOCALine[];
  bankAccounts?: BankAccount[];
  purchaseOrders?: PurchaseOrder[];
  salesInvoices?: SalesInvoice[];
  employees?: EmployeeProfile[];
  businessPartners?: BusinessPartner[];
  payrollRecords?: MonthlyPayrollRecord[];
  prepaymentRecords?: PrepaymentRecord[];
  prepaymentSchedules?: PrepaymentScheduleLine[];
  approvalRequests?: ApprovalRequest[];
  companyProfiles?: Record<number, CompanyProfile>;
  chartOfAccounts?: AccountMaster[];
  disclosureNotes?: DisclosureNote[];
  closedPeriods?: { clientId: number; period: string }[];
  /** Optional (older browsers may not send it); when present it is replaced tenant-scoped. */
  taxScheduleEntries?: TaxScheduleEntry[];
  /** Perpetual inventory + asset register (optional for older browsers). */
  stockItems?: StockItem[];
  stockMovements?: StockMovement[];
  fixedAssets?: FixedAsset[];
}

/**
 * Full-state sync. The server is authoritative: journal lines are validated
 * (tenant, open periods, COA existence, double entry) and the whole write is one
 * transaction. Firm-level masters (clients, COA, disclosures) are owner-writable
 * only; every operational row is tenant-filtered.
 */
export async function PUT(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    // Infrastructure fault → 503. Never 401: a 401 is what signs the user out.
    console.error("state sync: database unavailable", e);
    return authJson(req, { ok: false, error: "database-unavailable" }, { status: 503 });
  }
  try {
    return await handlePut(req);
  } catch (error) {
    const reference = crypto.randomUUID();
    const cause = error instanceof Error ? error.cause : undefined;
    const candidate = error && typeof error === "object" && "code" in error
      ? (error as { code?: unknown }).code
      : cause && typeof cause === "object" && "code" in cause
        ? (cause as { code?: unknown }).code
        : undefined;
    const code = typeof candidate === "string" ? candidate : undefined;
    console.error(`[state-sync:${reference}] ${error instanceof Error ? error.name : "UnknownError"}${code ? ` code=${code}` : ""}`);
    return Response.json({
      ok: false,
      error: `Workspace sync failed. No changes were saved. Retry the sync; if it continues, share reference ${reference}.`,
      reference,
    }, { status: 500 });
  }
}

async function handlePut(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });

  let body: StatePayload;
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }

  // Full-state sync contract: partial payloads are rejected so a sync can never
  // silently wipe datasets the caller did not include.
  const coreFields: (keyof StatePayload)[] = [
    "journalLines", "bankAccounts", "purchaseOrders", "salesInvoices", "employees",
    "businessPartners", "payrollRecords", "prepaymentRecords", "prepaymentSchedules",
    "approvalRequests", "closedPeriods", "companyProfiles",
  ];
  if (!body || typeof body !== "object" || coreFields.some((f) => body[f] === undefined)) {
    return Response.json({ ok: false, error: "Partial state sync rejected — send the full workspace state." }, { status: 400 });
  }

  if (!body || typeof body !== 'object' || Array.isArray(body)) return Response.json({ ok: false, error: 'Invalid workspace object.' }, { status: 400 });
  const arrayFields = coreFields.filter((field) => field !== 'companyProfiles');
  if (arrayFields.some((field) => !Array.isArray(body[field])) || !body.companyProfiles || typeof body.companyProfiles !== 'object' || Array.isArray(body.companyProfiles)) {
    return Response.json({ ok: false, error: 'Invalid workspace data types.' }, { status: 400 });
  }
  if (body.journalLines!.some((line) => !line || typeof line.docNo !== 'string' || !line.docNo.trim() || typeof line.id !== 'string')) return Response.json({ ok: false, error: 'Invalid journal identity.' }, { status: 400 });
  const isOwner = user.role === "owner";
  const firmWide = hasFirmWideScope(user);
  const myClientId = user.clientId ?? null;

  // Tenant filter: non-owners may only touch their own entity (or untagged legacy rows).
  const tenantOk = (clientId: number | undefined | null): boolean =>
    firmWide || (myClientId !== null && clientId === myClientId);

  const lines = body.journalLines ?? [];
  const banks = body.bankAccounts ?? [];
  const pos = body.purchaseOrders ?? [];
  const invoices = body.salesInvoices ?? [];
  const emps = body.employees ?? [];
  const partners = body.businessPartners ?? [];
  const partnerPreparation = prepareBusinessPartnersForStorage(partners, firmWide ? null : myClientId);
  if (!partnerPreparation.ok) {
    return Response.json({ ok: false, error: partnerPreparation.error }, { status: partnerPreparation.status });
  }
  const storedPartners = partnerPreparation.rows;
  const payroll = body.payrollRecords ?? [];
  const prepayments = body.prepaymentRecords ?? [];
  const prepaidSchedules = body.prepaymentSchedules ?? [];
  const approvals = body.approvalRequests ?? [];
  const closed = body.closedPeriods ?? [];
  const profiles = body.companyProfiles ?? {};
  const taxEntries = body.taxScheduleEntries;
  const stock = body.stockItems;
  const movements = body.stockMovements;
  const assets = body.fixedAssets;

  if (!firmWide) {
    const rows: (number | undefined | null)[] = [
      ...lines.map((l) => l.clientId),
      ...banks.map((b) => b.clientId),
      ...pos.map((p) => p.clientId),
      ...invoices.map((i) => i.clientId),
      ...emps.map((e) => e.clientId),
      ...partners.map((p) => p.clientId),
      ...payroll.map((r) => r.clientId),
      ...prepayments.map((p) => p.clientId),
      ...prepaidSchedules.map((s) => s.clientId),
      ...approvals.map((a) => a.clientId),
      ...closed.map((c) => c.clientId),
      ...(taxEntries ?? []).map((t) => t.clientId),
      ...(stock ?? []).map((i) => i.clientId),
      ...(movements ?? []).map((m) => m.clientId),
      ...(assets ?? []).map((a) => a.clientId),
    ];
    if (rows.some((id) => !tenantOk(id))) {
      return Response.json({ ok: false, error: "Cross-tenant write rejected." }, { status: 403 });
    }
    if (Object.keys(profiles).some((id) => Number(id) !== myClientId)) {
      return Response.json({ ok: false, error: "Cross-tenant profile write rejected." }, { status: 403 });
    }
  }

  // Journal validation (tenant, periods, COA, double entry).
  const [allClients, allCoa, allClosed, allApprovals, allUsers] = await Promise.all([
    db.select().from(clients),
    db.select().from(chartAccounts),
    db.select().from(closedPeriods),
    db.select().from(approvalRequests),
    db.select().from(users),
  ]);
  const userDirectory = postingUserDirectory(allUsers);
  const allowedClientIds = firmWide ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
  // Periods are frozen per entity — key by client so one entity's close never blocks another.
  const closedKeys = new Set(
    allClosed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`)
  );
  // COA scope: firm master plus the writable entities' custom accounts.
  const coaNos = new Set(allCoa.filter((a) => a.clientId === null || allowedClientIds.includes(a.clientId)).map((a) => a.accountNo));
  // Duplicate document check against the server copy: documents already posted
  // are re-sent unchanged by the full-state sync; a conflict (same document
  // number, different lines) is rejected.
  const serverLines = await db.select().from(journalLines);
  const existingDocs = new Set(serverLines.map((l) => `${l.clientId}:${l.docNo}`));
  const docs = new Map<string, ACDOCALine[]>();
  for (const l of lines) {
    const key = `${l.clientId}:${l.docNo}`;
    if (!docs.has(key)) docs.set(key, []);
    docs.get(key)!.push(l);
  }

  // ---------------------------------------------------------------------
  // Server-authoritative records must survive a browser-authoritative sync.
  // The P2P / O2C engine (/api/trade) posts journals, moves stock and cash on
  // the server. A browser that has not yet re-pulled that state would, with a
  // plain "replace", silently delete those postings. Anything the trade engine
  // wrote that is MISSING from the payload is carried forward here.
  // ---------------------------------------------------------------------
  const [tradeJournalRows, tradeDocRows, recentCash] = await Promise.all([
    db.execute<{ client_id: number; aggregate_id: string }>(sql`select client_id, aggregate_id from trade_outbox where aggregate_type = 'journal'`),
    db.execute<{ client_id: number; doc_no: string }>(sql`select client_id, doc_no from trade_documents`),
    db.execute<{ bank_account_id: number }>(sql`select distinct bank_account_id from trade_cash_movements where created_at > now() - interval '30 seconds'`),
  ]);
  const tradeJournalKeys = new Set(tradeJournalRows.rows.map((r) => `${r.client_id}:${r.aggregate_id}`));
  const tradeDocKeys = new Set(tradeDocRows.rows.map((r) => `${r.client_id}:${r.doc_no}`));
  const missingTradeDocs = new Set<string>();
  for (const l of serverLines) {
    const key = `${l.clientId}:${l.docNo}`;
    if (tradeJournalKeys.has(key) && !docs.has(key) && allowedClientIds.includes(l.clientId)) missingTradeDocs.add(key);
  }
  for (const l of serverLines) {
    const key = `${l.clientId}:${l.docNo}`;
    if (!missingTradeDocs.has(key)) continue;
    const carried: ACDOCALine = {
      id: l.id, docNo: l.docNo, period: l.period, date: l.date, module: l.module as ACDOCALine["module"], docType: l.docType as ACDOCALine["docType"],
      accountNo: l.accountNo, accountName: l.accountName, costCenter: l.costCenter ?? undefined, debit: l.debit, credit: l.credit,
      currency: l.currency, description: l.description, createdBy: l.createdBy, checkedBy: l.checkedBy ?? undefined,
      clientId: l.clientId, isReversed: l.isReversed ?? false, reference: l.reference ?? undefined,
    };
    lines.push(carried);
    if (!docs.has(key)) docs.set(key, []);
    docs.get(key)!.push(carried);
  }
  const preservedJournalDocs = missingTradeDocs.size;
  // Stock: a trade movement the browser has not seen means its copy of that
  // item's quantity/value is stale — the server row wins for that item.
  const staleItems = new Set<string>();
  if (movements) {
    const payloadMovementIds = new Set(movements.map((m) => m.id));
    const serverMovements = await db.select().from(stockMovements);
    for (const m of serverMovements) {
      if (payloadMovementIds.has(m.id) || !allowedClientIds.includes(m.clientId)) continue;
      if (!m.docNo || !tradeDocKeys.has(`${m.clientId}:${m.docNo}`)) continue;
      movements.push({
        id: m.id, clientId: m.clientId, date: m.date, itemCode: m.itemCode, description: m.description, type: m.type as StockMovement["type"],
        quantity: m.quantity, unitCost: m.unitCost, totalValue: m.totalValue, uom: m.uom, reference: m.reference ?? undefined,
        docNo: m.docNo ?? undefined, note: m.note ?? undefined,
      });
      staleItems.add(`${m.clientId}:${m.itemCode}`);
    }
  }
  if (stock && staleItems.size) {
    const serverItems = await db.select().from(stockItems);
    for (const key of staleItems) {
      const [cid, code] = key.split(":");
      const server = serverItems.find((i) => i.clientId === Number(cid) && i.itemCode === code);
      if (!server) continue;
      const idx = stock.findIndex((i) => i.clientId === Number(cid) && i.itemCode === code);
      const row: StockItem = {
        id: server.id, clientId: server.clientId, itemCode: server.itemCode, description: server.description, category: server.category,
        uom: server.uom, quantityOnHand: server.quantityOnHand, unitCost: server.unitCost, totalValue: server.totalValue,
        reorderLevel: server.reorderLevel ?? undefined, location: server.location ?? undefined, glAccount: server.glAccount ?? undefined,
        costMethod: (server.costMethod ?? "weighted_average") as StockItem["costMethod"], netRealisableValue: server.netRealisableValue ?? undefined,
      };
      if (idx >= 0) stock[idx] = row; else stock.push(row);
    }
  }
  // Treasury: a cash movement posted by the trade engine in the last 30 s may
  // not be in the browser copy yet — keep the server balance for that account.
  if (recentCash.rows.length) {
    const serverBanks = await db.select().from(bankAccounts);
    for (const r of recentCash.rows) {
      const server = serverBanks.find((b) => b.id === r.bank_account_id);
      const idx = banks.findIndex((b) => b.id === r.bank_account_id);
      if (server && idx >= 0) banks[idx] = { ...banks[idx], balance: server.balance };
    }
  }
  if (preservedJournalDocs) console.info(`[state-sync] carried forward ${preservedJournalDocs} server-posted trade journal document(s) missing from the browser payload.`);
  const warnings: string[] = [];
  const immutableError = immutableJournalConflict(serverLines, lines);
  if (immutableError) return Response.json({ ok: false, error: immutableError }, { status: 409 });

  // Journal validation applies to NEW documents only — re-sent documents are
  // already in the books, so closing one of their periods afterwards must not
  // block the workspace sync (which would make the period impossible to reopen).
  let freshKeys = new Set([...docs.keys()].filter((key) => !existingDocs.has(key)));
  const freshLines = lines.filter((l) => freshKeys.has(`${l.clientId}:${l.docNo}`));
  // An empty journal list is valid for the full-state sync (nothing to validate) —
  // "no lines" is only an error for single-document posting.
  // New documents arriving through the workspace sync face exactly the same
  // controls as single-document posting: identity binding (maker or named
  // checker must be the signed-in user), document integrity, and the maker's
  // own limit with an independent, authorised checker above it.
  const identityError = freshLines.length
    ? validatePostingIdentity(freshLines, { session: sessionPostingRecord(user), users: userDirectory })
    : null;
  if (identityError) return authJson(req, { ok: false, error: identityError }, { status: 403 });
  const journalError = freshLines.length
    ? validateJournalLines(freshLines, { allowedClientIds, closedPeriodKeys: closedKeys, coaAccountNos: coaNos, isAccountPostable: accountPostabilityFor(allCoa) })
    : null;
  if (journalError) return Response.json({ ok: false, error: journalError }, { status: 409 });
  const sodError = freshLines.length
    ? validateMakerChecker(freshLines, { username: user.username, makerLimit: user.makerLimit, users: userDirectory })
    : null;
  if (sodError) return Response.json({ ok: false, error: sodError }, { status: 409 });

  let transactionError: string | null = null;
  await db.transaction(async (tx) => {
    // Serialize full-state replacements so concurrent browser tabs cannot interleave deletes and inserts.
    await tx.execute(sql`select pg_advisory_xact_lock(4027332)`);
    // Operational tables: tenant-scoped replace. The owner syncs the whole
    // workspace, so their replace clears the entire table first — legacy rows
    // outside the current client list must never survive to cause key collisions.
    const writableIds = firmWide ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
    const insertInBatches = async (table: any, rows: any[]) => {
      const batchSize = 250;
      for (let start = 0; start < rows.length; start += batchSize) {
        await tx.insert(table).values(rows.slice(start, start + batchSize));
      }
    };
    const replace = async (table: any, rows: any[], mapRow: (r: any) => Record<string, unknown>) => {
      if (isOwner) {
        await tx.delete(table);
      } else if (writableIds.length) {
        await tx.delete(table).where(inArray(table.clientId, writableIds));
      }
      if (rows.length) await insertInBatches(table, rows.map(mapRow));
    }; 

    // Recheck under the same lock as /api/journal. Missing browser records are
    // retained; neither posted lines nor their headers are ever replaced.
    const [latestLines, latestCoa, latestClosed, latestUsers] = await Promise.all([
      tx.select().from(journalLines), tx.select().from(chartAccounts),
      tx.select().from(closedPeriods), tx.select().from(users),
    ]);
    transactionError = immutableJournalConflict(latestLines, lines);
    if (transactionError) return;
    const latestKeys = new Set(latestLines.map((line) => `${line.clientId}:${line.docNo}`));
    freshKeys = new Set([...docs.keys()].filter((key) => !latestKeys.has(key)));
    const newLines = lines.filter((line) => freshKeys.has(`${line.clientId}:${line.docNo}`));
    const latestDirectory = postingUserDirectory(latestUsers);
    if (newLines.length) {
      transactionError = validateJournalLines(newLines, {
        allowedClientIds, closedPeriodKeys: new Set(latestClosed.map((row) => `${row.clientId}:${row.period}`)),
        coaAccountNos: new Set(latestCoa.map((row) => row.accountNo)), isAccountPostable: accountPostabilityFor(latestCoa),
      }) || validatePostingIdentity(newLines, { session: sessionPostingRecord(user), users: latestDirectory })
        || validateMakerChecker(newLines, { username: user.username, makerLimit: user.makerLimit, users: latestDirectory });
      if (transactionError) return;
      const usedIds = new Set(latestLines.map((line) => line.id));
      if (newLines.some((line) => usedIds.has(line.id))) { transactionError = 'Journal line id already exists.'; return; }
    }
    const previousPeriods = latestClosed.filter((row) => allowedClientIds.includes(row.clientId)).map((row) => `${row.clientId}:${row.period}`).sort();
    const nextPeriods = closed.map((row) => `${row.clientId}:${row.period}`).sort();
    if (JSON.stringify(previousPeriods) !== JSON.stringify(nextPeriods) && !isOwner && user.permissions?.canClosePeriod !== true) {
      transactionError = 'You do not have permission to close or reopen accounting periods.'; return;
    }
    for (const request of approvals) {
      const old = allApprovals.find((row) => row.id === request.id);
      if (!old && request.status !== 'pending') { transactionError = 'New approval requests must be pending.'; return; }
      if (old && old.status !== request.status) {
        if (old.status !== 'pending' || !(isOwner || user.canCheck) || request.reviewedBy !== user.username || request.payload?.lines?.some((line) => line.createdBy === user.username)) {
          transactionError = 'Approval decisions require an independent authenticated checker.'; return;
        }
      }
    }
    if (newLines.length) {
      await insertInBatches(journalLines, newLines.map((line) => ({ ...line, costCenter: line.costCenter ?? null, checkedBy: line.checkedBy ?? null, reference: line.reference ?? null })));
      const newDocuments = [...freshKeys].map((key) => docs.get(key)!);
      await insertInBatches(journalHeaders, newDocuments.map((document) => buildJournalHeader(document)));
      for (const document of newDocuments) await tx.insert(postingEvents).values(buildPostingEvent(document, user.username)).onConflictDoNothing();
    }
    await replace(bankAccounts, banks, (b) => ({ 
      id: b.id, clientId: b.clientId ?? 0, code: b.code, name: b.name, bankName: b.bankName, accountNo: b.accountNo,
      currency: b.currency, balance: b.balance, kind: b.kind ?? null, glAccount: b.glAccount ?? null,
    }));
    await replace(purchaseOrders, pos, (p) => ({
      id: p.id, clientId: p.clientId ?? 0, poNo: p.poNo, vendorName: p.vendorName, itemType: p.itemType,
      itemDescription: p.itemDescription, qty: p.qty, unitPrice: p.unitPrice, vatRecoverable: p.vatRecoverable,
      totalAmount: p.totalAmount, paidAmount: p.paidAmount ?? 0, status: p.status, date: p.date,
      currency: p.currency ?? null, vatTreatment: p.vatTreatment ?? null, netAmount: p.netAmount ?? null,
      quotationRef: p.quotationRef ?? null, glAccount: p.glAccount, glAccountName: p.glAccountName,
      costCenter: p.costCenter, costCenterName: p.costCenterName,
    }));
    await replace(salesInvoices, invoices, (i) => ({
      id: i.id, clientId: i.clientId ?? 0, invNo: i.invNo, customerName: i.customerName, revenueStream: i.revenueStream,
      netRevenue: i.netRevenue, vatOutput: i.vatOutput, cstAmount: i.cstAmount ?? null,
      tourismLevyAmount: i.tourismLevyAmount ?? null, vatWithheldByCustomer: i.vatWithheldByCustomer ?? null,
      totalReceivable: i.totalReceivable, paidAmount: i.paidAmount, status: i.status, date: i.date,
    }));
    await replace(employees, emps, (e) => ({
      id: e.id, clientId: e.clientId ?? null, bpNo: e.bpNo, name: e.name, role: e.role, department: e.department,
      costCenter: e.costCenter ?? null, jurisdiction: e.jurisdiction, basicSalary: e.basicSalary, allowances: e.allowances, ssnitNumber: e.ssnitNumber,
      tin: e.tin, status: e.status, isResident: e.isResident ?? true, exemptTier1: e.exemptTier1 ?? false,
      exemptTier2: e.exemptTier2 ?? false, ssnitExempt: e.ssnitExempt ?? false,
      ssnitExemptionReason: e.ssnitExemptionReason ?? null, taxRelief: e.taxRelief ?? 0, reliefType: e.reliefType ?? null,
      deductions: e.deductions ?? null,
    }));
    await replace(businessPartners, storedPartners, (p) => ({
      id: p.id, sourceId: p.sourceId, clientId: p.clientId ?? null, code: p.code, name: p.name, type: p.type, tin: p.tin, email: p.email,
      phone: p.phone, address: p.address, currency: p.currency, isVatWithholdingAgent: p.isVatWithholdingAgent,
      vatWithholdingRate: p.vatWithholdingRate ?? null, isCstApplicable: p.isCstApplicable,
      isTourismLevyApplicable: p.isTourismLevyApplicable, isVatRegistered: p.isVatRegistered ?? null,
    }));
    await replace(payrollRecords, payroll, (r) => ({ id: r.id, clientId: r.clientId ?? 0, record: r }));
    await replace(prepaymentRecords, prepayments, (p) => ({ id: p.id, clientId: p.clientId ?? 0, record: p }));
    await replace(prepaymentSchedules, prepaidSchedules, (s) => ({ id: s.id, prepaymentId: s.prepaymentId, clientId: s.clientId ?? 0, line: s }));
    await replace(approvalRequests, approvals, (a) => ({
      id: a.id, clientId: a.clientId, clientCode: a.clientCode, clientName: a.clientName, docNo: a.docNo,
      docType: a.docType, amount: a.amount, requestedBy: a.requestedBy, requestedAt: a.requestedAt,
      description: a.description, reasonForApproval: a.reasonForApproval, status: a.status,
      reviewedBy: a.reviewedBy ?? null, reviewedAt: a.reviewedAt ?? null, rejectionReason: a.rejectionReason ?? null,
      payload: a.payload ?? null,
    }));
    await replace(closedPeriods, closed.map((c) => ({ ...c, closedAt: new Date().toISOString(), closedBy: user.username })), (c) => ({
      clientId: c.clientId, period: c.period, closedAt: c.closedAt, closedBy: c.closedBy,
    }));
    // Statutory schedule edits/additions (WHT & VAT) — only when the browser sent them.
    if (taxEntries) {
      await replace(taxScheduleEntries, taxEntries, (t) => ({
        id: t.id, clientId: t.clientId, kind: t.kind, source: t.source, sourceKey: t.sourceKey ?? null,
        period: t.period, date: t.date, docNo: t.docNo, partyName: t.partyName, partyTin: t.partyTin ?? "",
        nature: t.nature ?? "", grossAmount: t.grossAmount ?? 0, rate: t.rate ?? 0, taxAmount: t.taxAmount ?? 0,
        levyAmount: t.levyAmount ?? 0, reference: t.reference ?? "", status: t.status ?? "", note: t.note ?? null,
        createdBy: t.createdBy, updatedAt: t.updatedAt,
      }));
    }

    // Perpetual inventory: item master + movement history, tenant-scoped.
    if (stock) {
      await replace(stockItems, stock, (i) => ({
        id: i.id, clientId: i.clientId, itemCode: i.itemCode, description: i.description, category: i.category,
        uom: i.uom, quantityOnHand: i.quantityOnHand, unitCost: i.unitCost, totalValue: i.totalValue,
        reorderLevel: i.reorderLevel ?? null, location: i.location ?? null, glAccount: i.glAccount ?? null,
        costMethod: i.costMethod ?? "weighted_average", netRealisableValue: i.netRealisableValue ?? null,
      }));
    }
    if (movements) {
      await replace(stockMovements, movements, (m) => ({
        id: m.id, clientId: m.clientId, date: m.date, itemCode: m.itemCode, description: m.description,
        type: m.type, quantity: m.quantity, unitCost: m.unitCost, totalValue: m.totalValue, uom: m.uom,
        reference: m.reference ?? null, docNo: m.docNo ?? null, note: m.note ?? null,
      }));
    }
    // Fixed asset register with tax base (capital allowances / IAS 12).
    if (assets) {
      await replace(fixedAssets, assets, (a) => ({
        id: a.id, clientId: a.clientId ?? 0, assetTag: a.assetTag, name: a.name, classCode: a.classCode,
        cost: a.cost, accumDep: a.accumDep, usefulLife: a.usefulLife,
        depreciationRate: a.depreciationRate ?? null, depreciationMethod: a.depreciationMethod ?? null,
        capitalAllowanceClass: a.capitalAllowanceClass ?? null, capitalAllowanceRate: a.capitalAllowanceRate ?? null,
        accumCapitalAllowance: a.accumCapitalAllowance ?? 0, location: a.location ?? "",
        acquired: a.acquired ?? null, disposedDate: a.disposedDate ?? null, disposalProceeds: a.disposalProceeds ?? null,
      }));
    }

    // Profiles: owner writes all; non-owners only their own entity's profile.
    const profileRows = Object.values(profiles).filter((p) => firmWide || p.clientId === myClientId);
    for (const p of profileRows) {
      await tx.insert(companyProfiles).values({
        clientId: p.clientId, legalName: p.legalName, tradingName: p.tradingName, tin: p.tin, vatRegNo: p.vatRegNo,
        address: p.address, phone: p.phone, email: p.email, website: p.website, fiscalYearStart: p.fiscalYearStart,
        bankPaymentDetails: p.bankPaymentDetails,
      }).onConflictDoUpdate({
        target: companyProfiles.clientId,
        set: {
          legalName: p.legalName, tradingName: p.tradingName, tin: p.tin, vatRegNo: p.vatRegNo, address: p.address,
          phone: p.phone, email: p.email, website: p.website, fiscalYearStart: p.fiscalYearStart,
          bankPaymentDetails: p.bankPaymentDetails,
        },
      });
    }

    // Firm-level masters: owner-only.
    if (isOwner) {
      if (body.clients) {
        for (const c of body.clients) {
          await tx.insert(clients).values({
            id: c.id, code: c.code, name: c.name, sector: c.sector, currency: c.currency, jurisdiction: c.jurisdiction,
            regNumber: c.regNumber, isParent: c.isParent ?? false, assignedServices: c.assignedServices ?? null,
            adminUsername: c.adminUsername ?? null, adminEmail: c.adminEmail ?? null, loginUrl: c.loginUrl ?? null,
          }).onConflictDoUpdate({
            target: clients.id,
            set: {
              code: c.code, name: c.name, sector: c.sector, currency: c.currency, jurisdiction: c.jurisdiction,
              regNumber: c.regNumber, isParent: c.isParent ?? false, assignedServices: c.assignedServices ?? null,
              adminUsername: c.adminUsername ?? null, adminEmail: c.adminEmail ?? null, loginUrl: c.loginUrl ?? null,
            },
          });
        }
      }
      if (body.disclosureNotes) {
        await tx.delete(disclosureNotes);
        if (body.disclosureNotes.length) {
          await tx.insert(disclosureNotes).values(
            body.disclosureNotes.map((n) => ({
              key: n.key, noteNumber: n.noteNumber, title: n.title, standardRef: n.standardRef, applicable: n.applicable,
              notApplicableReason: n.notApplicableReason ?? null, body: n.body, tables: n.tables ?? null,
              editableOverride: n.editableOverride ?? null,
            }))
          );
        }
      }
    }

    // Chart of accounts: the owner maintains the whole chart (firm master plus every
    // entity's customs); non-owners maintain only their own entity's custom accounts.
    if (body.chartOfAccounts) {
      if (isOwner) {
        await tx.delete(chartAccounts);
        if (body.chartOfAccounts.length) {
          await tx.insert(chartAccounts).values(
            body.chartOfAccounts.map((a) => ({
              accountNo: a.accountNo, name: a.name, type: a.type, category: a.category,
              active: a.active, isCustom: a.isCustom ?? false, clientId: a.clientId ?? null,
            }))
          );
        }
      } else if (myClientId !== null && user.role === "manager") {
        // Server-side authority check: only the entity's owner/manager may
        // maintain its account names. Staff syncs leave the chart untouched.
        await tx.delete(chartAccounts).where(eq(chartAccounts.clientId, myClientId));
        const own = body.chartOfAccounts.filter((a) => a.clientId === myClientId);
        if (own.length) {
          await tx.insert(chartAccounts).values(
            own.map((a) => ({
              accountNo: a.accountNo, name: a.name, type: a.type, category: a.category,
              active: a.active, isCustom: a.isCustom ?? false, clientId: myClientId,
            }))
          );
        }
      }
    }

    // Audit trail: one entry per newly posted journal document.
    const now = new Date().toISOString();
    // Period freezes and reopens are audit events — the ledger can change hands
    // but the control history must be reviewable.
    const prevClosed = new Set(allClosed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`));
    const nextClosed = new Set(closed.map((c) => `${c.clientId}:${c.period}`));
    for (const key of nextClosed) {
      if (prevClosed.has(key)) continue;
      const [cid, p] = key.split(":");
      await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: "CLOSE_PERIOD", target: `${cid}:${p}`, details: `Period ${p} frozen for client ${cid}`, clientId: Number(cid) });
    }
    for (const key of prevClosed) {
      if (nextClosed.has(key)) continue;
      const [cid, p] = key.split(":");
      await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: "REOPEN_PERIOD", target: `${cid}:${p}`, details: `Period ${p} reopened for client ${cid}`, clientId: Number(cid) });
    }
    // Approval resolutions (pending → approved/rejected) are audit events too.
    const prevApprovalStatus = new Map(allApprovals.filter((a) => allowedClientIds.includes(a.clientId)).map((a) => [a.id, a.status]));
    for (const a of approvals) {
      const prev = prevApprovalStatus.get(a.id);
      if (prev && prev !== a.status) {
        await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: `APPROVAL_${a.status.toUpperCase()}`, target: a.docNo, details: `${a.clientCode} request by ${a.requestedBy} ${a.status}${a.rejectionReason ? ` — ${a.rejectionReason}` : ""}`, clientId: a.clientId });
      }
    }
    for (const key of freshKeys) {
      const docLines = docs.get(key)!;
      const dr = docLines.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
      await tx.insert(auditLog).values({
        id: crypto.randomUUID(),
        timestamp: now,
        userId: user.username,
        username: user.username,
        action: "POST_JOURNAL",
        target: key.split(":")[1],
        details: `${docLines.length} line(s), debits ${dr.toFixed(2)}`,
        clientId: Number(key.split(":")[0]),
      });
    }
  });

  if (transactionError) return Response.json({ ok: false, error: transactionError }, { status: 409 });
  return Response.json({ ok: true, warnings });
}
