import { browserStorage as localStorage } from '../utils/browserStorage';
import { useState } from 'react';
import type { ClientEntity, PracticeTimesheet, UserAccount } from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import { Plus, Save } from 'lucide-react';
import { INITIAL_TIMESHEETS } from '../data/accountingSeed';
import { uniqueId } from '../utils/ids';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
}

const persist = {
  read(): PracticeTimesheet[] {
    try { const raw = localStorage.getItem('bpz_timesheets'); return raw ? JSON.parse(raw) : []; } catch { return []; }
  },
  write(items: PracticeTimesheet[]) { try { localStorage.setItem('bpz_timesheets', JSON.stringify(items)); } catch { /* ignore */ } },
};

const RATE_CARD = [
  { role: 'Senior Partner', rate: 850 },
  { role: 'Partner', rate: 700 },
  { role: 'Manager / Senior', rate: 350 },
  { role: 'Accountant', rate: 200 },
  { role: 'Junior / Intern', rate: 100 },
];

export const AdvisorySection = ({ currentUser }: Props) => {
  // Falls back to the seeded practice timesheets so the seed data is not orphaned.
  const [timesheets, setTimesheets] = useState<PracticeTimesheet[]>(() => {
    const stored = persist.read();
    return stored.length ? stored : INITIAL_TIMESHEETS;
  });
  const [showModal, setShowModal] = useState(false);
  const [staffName, setStaffName] = useState(currentUser.name);
  const [role, setRole] = useState('Manager / Senior');
  const [engagement, setEngagement] = useState('Monthly Accounting Review');
  const [hours, setHours] = useState(8);
  const [hourlyRate, setHourlyRate] = useState(350);
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));

  const isRestricted = currentUser.status === 'restricted' || currentUser.status === 'suspended';

  const totalBillable = timesheets.reduce((s, t) => s + t.billableFee, 0);
  const totalHours = timesheets.reduce((s, t) => s + t.hours, 0);

  const handleAddTimesheet = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRestricted) return;
    if (hours <= 0 || hourlyRate < 0) return;
    const newT: PracticeTimesheet = {
      id: uniqueId('ID'),
      staffName,
      engagement: `${role} - ${engagement}`,
      hours,
      hourlyRate,
      billableFee: hours * hourlyRate,
      date,
      status: 'Draft',
    };
    const next = [...timesheets, newT];
    setTimesheets(next);
    persist.write(next);
    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      <PageHeader kicker="AD · BPZ Practice Management" title="Advisory, Timesheets &amp; Billing" desc="Practice engagements, billable hours, and fee accruals for the firm's own advisory work.">
        <button onClick={() => setShowModal(true)} disabled={isRestricted} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs disabled:opacity-40 disabled:cursor-not-allowed">
          <Plus className="h-4 w-4" /> Log Timesheet
        </button>
      </PageHeader>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Engagements logged" value={timesheets.length} sub="All clients" />
        <Stat label="Total billable hours" value={`${totalHours} hrs`} sub="Aggregated" />
        <Stat label="Accumulated fee" value={`₵${formatGHS(totalBillable)}`} tone="text-emerald-700" sub="Draft, not yet invoiced" />
        <Stat label="Average rate" value={totalHours > 0 ? `₵${formatGHS(totalBillable / totalHours)}` : '—'} sub="Per hour" />
      </div>

      <Card title="Standard rate card" sub="Reference figures. Update per engagement.">
        <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-sky-200 bg-sky-50/70">
              <th className={thCls}>Role</th>
              <th className={thCls + ' text-right'}>Standard hourly rate (₵)</th>
            </tr>
          </thead>
          <tbody>
            {RATE_CARD.map(r => <tr key={r.role} className={rowCls}><td className="px-3 py-2 font-bold text-[#082f4f]">{r.role}</td><td className={numCls}>{formatGHS(r.rate)}</td></tr>)}
          </tbody>
        </table>
        </div>
      </Card>

      <Card title={`Engagement timesheets (${timesheets.length})`} sub="New entries are saved as Draft until approved.">
        {timesheets.length === 0 ? <p className="text-center text-[#355875] py-6">No timesheets logged yet.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[700px] text-xs">
              <thead>
                <tr className="border-b border-sky-200 bg-sky-50/70">
                  <th className={thCls}>Date</th>
                  <th className={thCls}>Staff</th>
                  <th className={thCls}>Engagement</th>
                  <th className={thCls + ' text-right'}>Hours</th>
                  <th className={thCls + ' text-right'}>Rate (₵/hr)</th>
                  <th className={thCls + ' text-right'}>Fee (₵)</th>
                  <th className={thCls}>Status</th>
                </tr>
              </thead>
              <tbody>
                {timesheets.map(t => (
                  <tr key={t.id} className={rowCls}>
                    <td className="px-3 py-2 font-mono text-[#355875]">{t.date}</td>
                    <td className="px-3 py-2 font-bold text-[#082f4f]">{t.staffName}</td>
                    <td className="px-3 py-2 text-[#2d4f6d]">{t.engagement}</td>
                    <td className={numCls}>{t.hours} hrs</td>
                    <td className={numCls}>{formatGHS(t.hourlyRate)}</td>
                    <td className={numCls + ' font-bold text-emerald-700'}>{formatGHS(t.billableFee)}</td>
                    <td className="px-3 py-2">
                      <span className={`rounded px-2 py-0.5 text-[10.5px] font-bold ${t.status === 'Approved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>{t.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleAddTimesheet} className="w-full max-w-lg rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Log engagement hours</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Staff member</label>
                <input type="text" value={staffName} onChange={e => setStaffName(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-2 outline-none" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Role</label>
                <select value={role} onChange={e => { const next = e.target.value; setRole(next); const card = RATE_CARD.find(r => r.role === next); if (card) setHourlyRate(card.rate); }} className="w-full rounded border border-sky-300 px-3 py-2 outline-none">
                  {RATE_CARD.map(r => <option key={r.role} value={r.role}>{r.role}</option>)}
                </select>
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Engagement / Task</label>
                <input type="text" value={engagement} onChange={e => setEngagement(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-2 outline-none" required />
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Date</label>
                <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full rounded border border-sky-300 px-3 py-2 outline-none" required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Hours</label>
                  <input type="number" min="0.1" step="0.25" value={hours} onChange={e => setHours(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-2 outline-none" required />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Rate (₵/hr)</label>
                  <input type="number" min="0" step="0.01" value={hourlyRate} onChange={e => setHourlyRate(Number(e.target.value))} className="w-full rounded border border-sky-300 px-3 py-2 outline-none" required />
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setShowModal(false)} className="rounded px-3 py-1.5 text-xs font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 text-xs font-bold text-white flex items-center gap-1.5">
                <Save className="h-3.5 w-3.5" /> Save timesheet
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
