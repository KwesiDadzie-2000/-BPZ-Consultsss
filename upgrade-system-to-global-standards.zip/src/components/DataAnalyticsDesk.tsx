import { useMemo, useState } from 'react';
import { Activity, Download, ShieldAlert } from 'lucide-react';
import type { ACDOCALine, AccountMaster, ClientEntity, PurchaseOrder, SalesInvoice } from '@/types/accounting';
import { Card, PageHeader, Stat, cn, formatGHS, numCls, rowCls, tdCls, thCls } from '@/components/ui';
import { ComboChart, DonutChart, HBarChart, PALETTE } from '@/components/charts';
import { downloadCsv } from '@/utils/printReport';
import { buildCostCentreReport } from '@/utils/reports';
import { benford, concentration, journalAnomalies, monthlySeries, pareto, regressionForecast, userActivity, weekdayProfile } from '@/utils/analytics';
import { monthLabel, shiftMonth, lastDay } from '@/utils/planning';
import { localToday } from '@/utils/periods';

interface Props {
  currentClient: ClientEntity;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  invoices: SalesInvoice[];
  orders: PurchaseOrder[];
}

const sgn = (n: number) => (n < 0 ? `(${formatGHS(-n)})` : formatGHS(n));
const pctChange = (a: number, b: number) => (b ? ((a - b) / Math.abs(b)) * 100 : null);
const inputCls = 'rounded border border-sky-300 bg-white px-2 py-1 text-xs text-[#0a253e]';

export function DataAnalyticsDesk({ currentClient, lines, accounts, invoices, orders }: Props) {
  const today = localToday();
  const [through, setThrough] = useState(today);
  const [from, setFrom] = useState(`${shiftMonth(today.slice(0, 7), -11)}-01`);
  const [roundUnit, setRoundUnit] = useState(1000);
  const [z, setZ] = useState(3);
  const [severity, setSeverity] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  const clientId = currentClient.id;
  const cur = currentClient.currency === 'GHS' ? '₵' : `${currentClient.currency} `;
  const entity = useMemo(() => lines.filter((l) => l.clientId === clientId), [lines, clientId]);
  const valid = from <= through;

  const series = useMemo(() => monthlySeries(entity, accounts, clientId, through.slice(0, 7), 24), [entity, accounts, clientId, through]);
  const last12 = series.slice(-12);
  const prev12 = series.slice(0, 12);
  const sumK = (xs: typeof series, k: 'revenue' | 'expenses' | 'profit') => xs.reduce((s, p) => s + p[k], 0);
  const rev12 = sumK(last12, 'revenue');
  const exp12 = sumK(last12, 'expenses');
  const prof12 = sumK(last12, 'profit');
  const revGrowth = pctChange(rev12, sumK(prev12, 'revenue'));
  const fc = regressionForecast(last12.map((p) => p.revenue), 6);
  const fcLabels = [...last12.map((p) => monthLabel(p.month)), ...Array.from({ length: 6 }, (_, i) => `${monthLabel(shiftMonth(through.slice(0, 7), i + 1))}*`)];

  const exp = useMemo(() => (valid ? pareto(entity, accounts, clientId, from, through, 'Expense') : { total: 0, rows: [] }), [entity, accounts, clientId, from, through, valid]);
  const vital = exp.rows.filter((r) => r.cumPct <= 80).length + 1;
  const custConc = useMemo(() => concentration(invoices.filter((i) => (i.clientId ?? clientId) === clientId && i.status !== 'Draft' && i.date >= from && i.date <= through).map((i) => ({ name: i.customerName, amount: i.netRevenue }))), [invoices, clientId, from, through]);
  const suppConc = useMemo(() => concentration(orders.filter((o) => (o.clientId ?? clientId) === clientId && o.date >= from && o.date <= through).map((o) => ({ name: o.vendorName, amount: o.netAmount ?? o.totalAmount }))), [orders, clientId, from, through]);
  const ben = useMemo(() => benford(entity, clientId, from, through), [entity, clientId, from, through]);
  const anomalies = useMemo(() => journalAnomalies(entity, accounts, clientId, from, through, { roundUnit, zThreshold: z }), [entity, accounts, clientId, from, through, roundUnit, z]);
  const users = useMemo(() => userActivity(entity, clientId, from, through), [entity, clientId, from, through]);
  const weekdays = useMemo(() => weekdayProfile(entity, clientId, from, through), [entity, clientId, from, through]);
  const cc = useMemo(() => (valid ? buildCostCentreReport(entity, accounts, from, through) : null), [entity, accounts, from, through, valid]);
  const flags = anomalies.flags.filter((f) => severity === 'all' || f.severity === severity);
  const donut = (c: ReturnType<typeof concentration>) => [...c.rows.slice(0, 5).map((r) => ({ label: r.name, value: r.amount })), ...(c.rows.length > 5 ? [{ label: `Others (${c.rows.length - 5})`, value: c.rows.slice(5).reduce((s, r) => s + r.amount, 0), color: '#cbd5e1' }] : [])];

  return (
    <div className="space-y-5">
      <PageHeader kicker="Insights · Analytics & CAATs" title="Data Analytics" desc="Trend, composition and concentration analytics with predictive revenue forecasting, plus computer-assisted audit techniques — Benford's law and journal-entry risk testing (ISA 240) — over the posted ledger.">
        <label className="text-[11px] font-bold text-[#355875]">From <input type="date" value={from} max={through} onChange={(e) => setFrom(e.target.value)} className={inputCls} /></label>
        <label className="text-[11px] font-bold text-[#355875]">Through <input type="date" value={through} min={from} onChange={(e) => setThrough(e.target.value)} className={inputCls} /></label>
      </PageHeader>
      {!valid && <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-800">The start date must be on or before the end date.</div>}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label="Revenue (last 12 months)" value={`${cur}${formatGHS(rev12)}`} sub={revGrowth === null ? 'No prior-year comparison' : `${revGrowth >= 0 ? '▲' : '▼'} ${Math.abs(revGrowth).toFixed(1)}% vs prior 12 months`} tone={revGrowth !== null && revGrowth < 0 ? 'text-rose-700' : undefined} />
        <Stat label="Expenses (last 12 months)" value={`${cur}${formatGHS(exp12)}`} />
        <Stat label="Net result (last 12 months)" value={`${cur}${sgn(prof12)}`} sub={rev12 ? `Margin ${((prof12 / rev12) * 100).toFixed(1)}%` : ''} tone={prof12 < 0 ? 'text-rose-700' : 'text-emerald-700'} />
        <Stat label="Cash (month-end)" value={`${cur}${sgn(series[series.length - 1]?.cash ?? 0)}`} />
        <Stat label="JE exceptions" value={anomalies.flags.length} sub={`${anomalies.tested} lines · ${anomalies.documents} documents tested`} tone={anomalies.flags.some((f) => f.severity === 'high') ? 'text-rose-700' : undefined} />
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card title="24-month performance trend" sub="Revenue and expenses (bars) with net result (line)">
          <ComboChart title="Monthly revenue, expenses and result" labels={series.map((p) => monthLabel(p.month))} series={[{ name: 'Revenue', values: series.map((p) => p.revenue), color: PALETTE.navy }, { name: 'Expenses', values: series.map((p) => p.expenses), color: PALETTE.gold }, { name: 'Net result', values: series.map((p) => p.profit), type: 'line', color: PALETTE.green }]} />
        </Card>
        <Card title="Working capital & liquidity trend">
          <ComboChart title="Cash, receivables and payables" labels={series.map((p) => monthLabel(p.month))} series={[{ name: 'Cash', values: series.map((p) => p.cash), type: 'line', color: PALETTE.navy }, { name: 'Receivables', values: series.map((p) => p.receivables), type: 'line', color: PALETTE.sky }, { name: 'Payables', values: series.map((p) => p.payables), type: 'line', color: PALETTE.red, dashed: true }]} />
        </Card>
      </div>

      <Card title="Predictive revenue forecast (next 6 months)" sub={`Least-squares trend · slope ${formatGHS(fc.slope)}/month · R² ${fc.rsq} · 95% prediction band`}>
        <ComboChart title="Revenue forecast" labels={fcLabels} series={[{ name: 'Actual revenue', values: [...last12.map((p) => p.revenue), ...new Array(6).fill(NaN)], color: PALETTE.navy }, { name: 'Forecast', values: [...new Array(11).fill(NaN), last12[11]?.revenue ?? NaN, ...fc.forecast], type: 'line', color: PALETTE.gold }, { name: 'Upper band', values: [...new Array(12).fill(NaN), ...fc.upper], type: 'line', color: PALETTE.slate, dashed: true }, { name: 'Lower band', values: [...new Array(12).fill(NaN), ...fc.lower], type: 'line', color: PALETTE.slate, dashed: true }]} />
        {fc.rsq < 0.3 && <p className="mt-1 text-[11px] text-[#355875]">Low R² — revenue is not well explained by a linear trend; use the scenario and seasonal forecast tools for planning.</p>}
      </Card>

      <div className="grid gap-4 xl:grid-cols-3">
        <Card title="Expense Pareto" sub={exp.rows.length ? `${vital} of ${exp.rows.length} accounts drive 80% of spend` : 'No expenses in period'} action={<button type="button" onClick={() => downloadCsv(`${currentClient.code}_expense_pareto.csv`, [['Account', 'Name', 'Amount', '%', 'Cumulative %'], ...exp.rows.map((r) => [r.accountNo, r.name, r.amount, r.pct, r.cumPct])])} className="inline-flex items-center gap-1 rounded-md border border-sky-300 bg-white px-2 py-1 text-[11px] font-bold text-[#082f4f]"><Download className="h-3 w-3" />CSV</button>}>
          <HBarChart title="Top expense accounts" rows={exp.rows.slice(0, 10).map((r) => ({ label: r.name, value: r.amount, note: `${r.cumPct.toFixed(0)}%` }))} />
        </Card>
        <Card title="Customer concentration" sub={`HHI ${custConc.hhi} · ${custConc.level} · top-1 ${custConc.top1Pct}% · top-5 ${custConc.top5Pct}%`}>
          {custConc.rows.length ? <DonutChart title="Revenue by customer" data={donut(custConc)} /> : <p className="text-xs text-[#355875]">No invoiced revenue in the period.</p>}
        </Card>
        <Card title="Supplier concentration" sub={`HHI ${suppConc.hhi} · ${suppConc.level} · top-1 ${suppConc.top1Pct}%`}>
          {suppConc.rows.length ? <DonutChart title="Spend by supplier" data={donut(suppConc)} /> : <p className="text-xs text-[#355875]">No purchase orders in the period.</p>}
        </Card>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card title={<span className="inline-flex items-center gap-2"><Activity className="h-4 w-4 text-[#855b00]" />Benford&apos;s law — first-digit test</span>} sub={`${ben.n} amounts ≥ 10 · MAD ${ben.mad} · χ² ${ben.chi2} (critical 15.51 @ 5%) · ${ben.conformity}`}>
          <ComboChart title="Benford first digit distribution" labels={ben.digits.map((d) => String(d.digit))} format={(n) => `${n.toFixed(0)}%`} series={[{ name: 'Actual %', values: ben.digits.map((d) => d.actualPct), color: PALETTE.navy }, { name: 'Expected (Benford) %', values: ben.digits.map((d) => d.expectedPct), type: 'line', color: PALETTE.gold }]} height={200} />
          <div className="mt-2 flex flex-wrap gap-1.5 text-[10.5px]">{ben.digits.map((d) => <span key={d.digit} className={cn('rounded border px-1.5 py-0.5 font-mono', d.z > 1.96 ? 'border-rose-300 bg-rose-50 text-rose-800' : 'border-sky-100 text-[#355875]')}>{d.digit}: z={d.z}</span>)}</div>
        </Card>
        <Card title="Segment / cost-centre profitability" sub={cc ? `Residual (no cost centre): ${sgn(cc.residual)}` : ''}>
          {cc && cc.rows.length ? <HBarChart title="Result by cost centre" rows={cc.rows.slice(0, 12).map((r) => ({ label: r.code || 'Unallocated', value: r.net, color: r.net < 0 ? PALETTE.red : PALETTE.green }))} format={(n) => sgn(Math.round(n))} /> : <p className="text-xs text-[#355875]">No cost-centre tagged postings in the period.</p>}
          <div className="mt-4"><div className="mb-1 text-[11px] font-bold uppercase tracking-wider text-[#2d4f6d]">Posting activity by weekday (documents)</div><HBarChart title="Documents by weekday" rows={weekdays.map((w) => ({ label: w.label, value: w.value, color: w.label === 'Sat' || w.label === 'Sun' ? PALETTE.amber : PALETTE.sky }))} format={(n) => String(Math.round(n))} /></div>
        </Card>
      </div>

      <Card title={<span className="inline-flex items-center gap-2"><ShieldAlert className="h-4 w-4 text-rose-700" />Journal-entry testing (ISA 240 ¶32)</span>} sub={Object.entries(anomalies.summary).map(([k, v]) => `${k}: ${v}`).join(' · ') || 'No exceptions'} pad={false}
        action={<>
          <label className="text-[11px] font-bold text-[#355875]">Round unit<input type="number" min={1} value={roundUnit} onChange={(e) => setRoundUnit(Math.max(1, Number(e.target.value) || 1000))} className={cn(inputCls, 'ml-1 w-20')} /></label>
          <label className="text-[11px] font-bold text-[#355875]">z ≥<input type="number" min={1} step="0.5" value={z} onChange={(e) => setZ(Math.max(1, Number(e.target.value) || 3))} className={cn(inputCls, 'ml-1 w-14')} /></label>
          <select aria-label="Severity filter" value={severity} onChange={(e) => setSeverity(e.target.value as typeof severity)} className={inputCls}><option value="all">All severities</option><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select>
          <button type="button" onClick={() => downloadCsv(`${currentClient.code}_journal_exceptions_${from}_${through}.csv`, [['Severity', 'Test', 'Document', 'Date', 'Account', 'Name', 'Amount', 'Created by'], ...anomalies.flags.map((f) => [f.severity, f.test, f.docNo, f.date, f.accountNo, f.accountName, f.amount, f.createdBy])])} className="inline-flex items-center gap-1 rounded-md border border-sky-300 bg-white px-2 py-1 text-[11px] font-bold text-[#082f4f]"><Download className="h-3 w-3" />CSV</button>
        </>}>
        <div className="max-h-[50vh] overflow-auto">
          <table className="w-full min-w-[860px]">
            <thead className="sticky top-0"><tr><th className={thCls}>Severity</th><th className={thCls}>Test</th><th className={thCls}>Document</th><th className={thCls}>Date</th><th className={thCls}>Account</th><th className={cn(thCls, 'text-right')}>Amount</th><th className={thCls}>Created by</th></tr></thead>
            <tbody>
              {flags.length === 0 && <tr><td colSpan={7} className={cn(tdCls, 'text-center text-[#355875]')}>No exceptions for the selected filters.</td></tr>}
              {flags.slice(0, 300).map((f, i) => (
                <tr key={`${f.docNo}-${f.test}-${i}`} className={rowCls}>
                  <td className={tdCls}><span className={cn('rounded border px-1.5 py-0.5 text-[9.5px] font-black uppercase', f.severity === 'high' ? 'border-rose-300 bg-rose-50 text-rose-800' : f.severity === 'medium' ? 'border-amber-300 bg-amber-50 text-amber-800' : 'border-slate-300 bg-slate-50 text-slate-700')}>{f.severity}</span></td>
                  <td className={tdCls}>{f.test}</td><td className={cn(tdCls, 'font-mono')}>{f.docNo}</td><td className={tdCls}>{f.date}</td><td className={tdCls}>{f.accountNo} · {f.accountName}</td><td className={numCls}>{formatGHS(f.amount)}</td><td className={tdCls}>{f.createdBy}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {flags.length > 300 && <p className="px-4 py-2 text-[11px] text-[#355875]">Showing 300 of {flags.length}. Export CSV for the full list.</p>}
        </div>
      </Card>

      <Card title="User posting activity" sub="Segregation-of-duties and workload review" pad={false}>
        <table className="w-full"><thead><tr><th className={thCls}>User</th><th className={cn(thCls, 'text-right')}>Documents</th><th className={cn(thCls, 'text-right')}>Lines</th><th className={cn(thCls, 'text-right')}>Value (debits)</th></tr></thead>
          <tbody>{users.map((u) => <tr key={u.user} className={rowCls}><td className={tdCls}>{u.user}</td><td className={numCls}>{u.documents}</td><td className={numCls}>{u.lines}</td><td className={numCls}>{formatGHS(u.value)}</td></tr>)}</tbody></table>
      </Card>
      <p className="text-[10.5px] text-[#355875]">Period end for monthly analytics: {lastDay(through.slice(0, 7))}. Analytics are read-only and never modify the ledger.</p>
    </div>
  );
}
