import { useState } from 'react';
import type { ACDOCALine, AccountMaster, ClientEntity, UserAccount } from '../types/accounting';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { persistentStorage } from '../utils/persistentStorage';
import { aggregateTrialBalance, buildCashFlow, buildCostCentreReport } from '../utils/reports';
import { printReport, type PrintSection } from '../utils/printReport';
import { toPrintEntity } from '../utils/printEntity';
import { Printer } from 'lucide-react';
import { FinancialStatementsCard } from './FinancialStatementsCard';

const cell = (s: string | number) => `"${String(s).replace(/"/g, '""')}"`;
type Row = { code: string; name: string; type: AccountMaster['type']; dr: number; cr: number };

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

/** First day of the entity's fiscal year (from its company profile) within the given calendar year. */
const fiscalYearStartISO = (clientId: number, year: number): string => {
  const profiles = persistentStorage.getCompanyProfiles();
  const fy = profiles[clientId]?.fiscalYearStart || 'January';
  const idx = Math.max(0, MONTHS.indexOf(fy));
  return `${year}-${String(idx + 1).padStart(2, '0')}-01`;
};

type Tab = 'tb' | 'pnl' | 'bs' | 'cf' | 'sce' | 'cc' | 'ias';

export const FinancialReportsSection = ({ currentClient, clients, currentUser, onSelectClient, lines, accounts, onOpenNotesToAccounts }: {
  currentClient: ClientEntity;
  clients: ClientEntity[];
  currentUser: UserAccount;
  onSelectClient: (client: ClientEntity) => void;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  onOpenNotesToAccounts: () => void;
}) => {
  const [tab, setTab] = useState<Tab>('tb');
  const [through, setThrough] = useState(() => new Date().toISOString().slice(0, 10));
  // Each entity owns its own trial balance: the report entity defaults to the active
  // workspace; the owner may override it to any entity in the group.
  const [reportChoice, setReportChoice] = useState<number | null>(null);
  const reportClientId = reportChoice ?? currentClient.id;
  const reportClient = clients.find((c) => c.id === reportClientId) || currentClient;
  // Movement-from defaults to the report entity's fiscal year start; a manual pick overrides it.
  const [fromOverride, setFromOverride] = useState<string | null>(null);
  const from = fromOverride ?? fiscalYearStartISO(reportClientId, Number(through.slice(0, 4)) || new Date().getFullYear());

  const isOwner = currentUser.role === 'owner';
  const visibleClients = isOwner ? clients : clients.filter((c) => c.id === currentClient.id);

  // The trial balance is computed strictly from the selected entity's own journal lines.
  const scoped = lines.filter(l => l.clientId === reportClient.id && l.date <= through);
  const tb = aggregateTrialBalance(scoped, accounts);
  const movement = aggregateTrialBalance(scoped.filter(l => l.date >= from), accounts);
  const net = (r: Row) => (r.dr - r.cr) / 100;
  const debit = tb.reduce((n, r) => n + Math.max(0, net(r)), 0);
  const credit = tb.reduce((n, r) => n + Math.max(0, -net(r)), 0);
  const profit = movement.filter(r => ['Income', 'Expense'].includes(r.type)).reduce((n, r) => n - net(r), 0);
  const prior = aggregateTrialBalance(scoped.filter(l => l.date < from), accounts).filter(r => ['Income', 'Expense'].includes(r.type)).reduce((n, r) => n - net(r), 0);
  const assets = tb.filter(r => r.type === 'Asset').reduce((n, r) => n + net(r), 0);
  const liabilities = tb.filter(r => r.type === 'Liability').reduce((n, r) => n - net(r), 0);
  const equity = tb.filter(r => r.type === 'Equity').reduce((n, r) => n - net(r), 0);
  const residual = assets - liabilities - equity - prior - profit;
  const displayRows = (tab === 'tb' ? tb : tab === 'pnl' ? movement.filter(r => ['Income', 'Expense'].includes(r.type)) : tb.filter(r => ['Asset', 'Liability', 'Equity'].includes(r.type))).filter(r => net(r) !== 0);
  const value = (r: Row) => tab === 'tb' ? Math.max(0, net(r)) : ['Income', 'Liability', 'Equity'].includes(r.type) ? -net(r) : net(r);

  // IAS 7 statement of cash flows (indirect method) from the entity's own journal.
  const clientLines = lines.filter(l => l.clientId === reportClient.id);
  const cashFlow = buildCashFlow(clientLines, accounts, from, through);

  // P&L by cost centre for the entity's movement window.
  const costCentreReport = buildCostCentreReport(clientLines, accounts, from, through);

  // IAS 1 statement of changes in equity, derived from the entity's own journal.
  const plResult = (ls: ACDOCALine[]) => aggregateTrialBalance(ls, accounts)
    .filter(r => r.type === 'Income' || r.type === 'Expense')
    .reduce((n, r) => n - (r.dr - r.cr), 0) / 100;
  const crSum = (ls: ACDOCALine[], codes: string[]) => aggregateTrialBalance(ls, accounts)
    .filter(r => codes.includes(r.code))
    .reduce((n, r) => n + (r.cr - r.dr), 0) / 100;
  const priorRows = scoped.filter(l => l.date < from);
  const openCap = crSum(priorRows, ['300000', '301000']);
  const openRes = crSum(priorRows, ['310000', '311000', '313000']);
  const openRe = plResult(priorRows);
  const closeCap = crSum(scoped, ['300000', '301000']);
  const closeRes = crSum(scoped, ['310000', '311000', '313000']);
  const closeRe = plResult(scoped);
  const moveCap = closeCap - openCap;
  const moveRes = closeRes - openRes;
  const dividends = crSum(scoped.filter(l => l.date >= from), ['226000']);
  const sceRows: { label: string; cap: number; res: number; re: number; bold?: boolean }[] = [
    { label: 'Opening equity', cap: openCap, res: openRes, re: openRe },
    { label: 'Profit for the period', cap: 0, res: 0, re: profit },
    { label: 'Dividends declared', cap: 0, res: 0, re: -dividends },
    { label: 'Share capital issued', cap: moveCap, res: 0, re: 0 },
    { label: 'Other reserve movements', cap: 0, res: moveRes, re: 0 },
    { label: 'Closing equity', cap: closeCap, res: closeRes, re: closeRe, bold: true },
  ];

  // Every entity in scope owns a trial balance of its own; this strip proves each one balances.
  const entityTrials = visibleClients.map((c) => {
    const cl = lines.filter(l => l.clientId === c.id && l.date <= through);
    const dr = cl.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
    const cr = cl.reduce((n, l) => n + Math.round(l.credit * 100), 0) / 100;
    return { client: c, dr, cr, balanced: Math.abs(dr - cr) < 0.01 };
  });

  const download = () => {
    const rows: (string | number)[][] = [
      ['Workspace', reportClient.name], ['Entity code', reportClient.code], ['From', from], ['Through', through], ['Currency', reportClient.currency], ['Status', 'MANAGEMENT WORKING PAPER - LEDGER DERIVED'], [],
      ['Account', 'Name', 'Type', tab === 'tb' ? 'Debit' : 'Amount', ...(tab === 'tb' ? ['Credit'] : [])],
      ...displayRows.map(r => [r.code, r.name, r.type, value(r), ...(tab === 'tb' ? [Math.max(0, -net(r))] : [])]),
      ...(tab === 'tb' ? [['TOTAL', '', '', debit, credit]] : tab === 'pnl' ? [['NET RESULT', '', '', profit]] : [['PRIOR RESULT', '', '', prior], ['CURRENT RESULT', '', '', profit], ['RESIDUAL', '', '', residual]]),
    ];
    const url = URL.createObjectURL(new Blob([rows.map(r => r.map(cell).join(',')).join('\r\n')], { type: 'text/csv' }));
    const link = document.createElement('a'); link.href = url; link.download = `${reportClient.code}-${tab}-${through}.csv`; link.click(); URL.revokeObjectURL(url);
  };

  const TAB_TITLES: Record<Tab, string> = { tb: 'Trial balance', pnl: 'Statement of profit or loss', bs: 'Statement of financial position', cf: 'Statement of cash flows (IAS 7)', sce: 'Statement of changes in equity (IAS 1)', cc: 'Profit or loss by cost centre', ias: 'Complete financial statements (IAS 1 / IAS 18)' };

  /**
   * Prints ONLY the report on the active tab for the selected report entity —
   * never the surrounding workspace. Available to the owner and to clients.
   */
  const print = () => {
    const entity = toPrintEntity(reportClient, persistentStorage.getCompanyProfiles()[reportClient.id]);
    const preparedBy = `${currentUser.name} (${currentUser.username})`;
    const amountCol = { key: 'amount', label: reportClient.currency, numeric: true as const, width: '18%' };
    let sections: PrintSection[] = [];
    let stats: { label: string; value: string | number }[] | undefined;
    let periodLabel = `${from} to ${through}`;
    if (tab === 'tb') {
      periodLabel = `Through ${through}`;
      sections = [{ columns: [{ key: 'code', label: 'Account', width: '12%' }, { key: 'name', label: 'Account name' }, { key: 'type', label: 'Type', width: '11%' }, { key: 'debit', label: 'Debit', numeric: true, width: '16%' }, { key: 'credit', label: 'Credit', numeric: true, width: '16%' }],
        rows: displayRows.map(r => ({ code: r.code, name: r.name, type: r.type, debit: Math.max(0, net(r)) || '', credit: Math.max(0, -net(r)) || '' })),
        totals: { code: 'TOTAL', name: `${displayRows.length} account(s)`, type: '', debit, credit },
        note: Math.abs(debit - credit) >= 0.01 ? `Trial balance differs by ${formatGHS(debit - credit)} — investigate before use.` : 'Debits equal credits.' }];
      stats = [{ label: 'Total debits', value: debit }, { label: 'Total credits', value: credit }, { label: 'Accounts', value: String(displayRows.length) }, { label: 'Status', value: Math.abs(debit - credit) < 0.01 ? 'Balanced' : 'Out of balance' }];
    } else if (tab === 'pnl' || tab === 'bs') {
      if (tab === 'bs') periodLabel = `As at ${through}`;
      const groups: AccountMaster['type'][] = tab === 'pnl' ? ['Income', 'Expense'] : ['Asset', 'Liability', 'Equity'];
      sections = groups.map((g) => {
        const rows = displayRows.filter(r => r.type === g);
        const total = rows.reduce((n, r) => n + value(r), 0);
        return { title: g === 'Income' ? 'Revenue & other income' : g === 'Expense' ? 'Expenses' : g === 'Asset' ? 'Assets' : g === 'Liability' ? 'Liabilities' : 'Equity',
          columns: [{ key: 'code', label: 'Account', width: '12%' }, { key: 'name', label: 'Account name' }, amountCol],
          rows: rows.map(r => ({ code: r.code, name: r.name, amount: value(r) })), totals: { code: '', name: `Total ${g.toLowerCase()}`, amount: total } };
      });
      if (tab === 'pnl') {
        sections.push({ title: 'Result', columns: [{ key: 'label', label: 'Line' }, amountCol], rows: [{ label: 'Profit / (loss) for the period', amount: profit }], emphasise: () => true });
        stats = [{ label: 'Income', value: displayRows.filter(r => r.type === 'Income').reduce((n, r) => n + value(r), 0) }, { label: 'Expenses', value: displayRows.filter(r => r.type === 'Expense').reduce((n, r) => n + value(r), 0) }, { label: 'Net result', value: profit }, { label: 'Currency', value: reportClient.currency }];
      } else {
        sections.push({ title: 'Reconciliation', columns: [{ key: 'label', label: 'Line' }, amountCol], rows: [{ label: 'Retained result brought forward', amount: prior }, { label: 'Result for the current period', amount: profit }, { label: 'Total liabilities, equity & results', amount: liabilities + equity + prior + profit }, { label: 'Residual (must equal zero)', amount: residual }], emphasise: (i) => i >= 2 });
        stats = [{ label: 'Total assets', value: assets }, { label: 'Total liabilities', value: liabilities }, { label: 'Equity incl. results', value: equity + prior + profit }, { label: 'Residual', value: residual }];
      }
    } else if (tab === 'cf') {
      sections = [{ columns: [{ key: 'label', label: 'IAS 7 line' }, amountCol], rows: cfRows.map(r => ({ label: r.label, amount: r.amount })), emphasise: (i) => !!cfRows[i].bold }];
      stats = [{ label: 'Operating', value: cashFlow.operating }, { label: 'Investing', value: cashFlow.investing }, { label: 'Financing', value: cashFlow.financing }, { label: 'Closing cash', value: cashFlow.closingCash }];
    } else if (tab === 'sce') {
      sections = [{ columns: [{ key: 'label', label: 'IAS 1 movement' }, { key: 'cap', label: 'Share capital', numeric: true }, { key: 'res', label: 'Reserves', numeric: true }, { key: 're', label: 'Retained earnings', numeric: true }, { key: 'total', label: 'Total equity', numeric: true }],
        rows: sceRows.map(r => ({ label: r.label, cap: r.cap, res: r.res, re: r.re, total: r.cap + r.res + r.re })), emphasise: (i) => !!sceRows[i].bold }];
    } else {
      sections = [{ columns: [{ key: 'code', label: 'Cost centre', width: '20%' }, { key: 'income', label: 'Income', numeric: true }, { key: 'expense', label: 'Expenses', numeric: true }, { key: 'net', label: 'Net', numeric: true }],
        rows: costCentreReport.rows.map(r => ({ code: r.code, income: r.income, expense: r.expense, net: r.net })), totals: { code: 'Total', income: costCentreReport.totalIncome, expense: costCentreReport.totalExpense, net: costCentreReport.totalNet },
        note: `Residual versus entity profit: ${formatGHS(costCentreReport.residual)} (must equal zero).` }];
    }
    printReport({ kicker: 'Financial reports', title: TAB_TITLES[tab], subtitle: `${reportClient.name} (${reportClient.code}) · ledger-derived · ${reportClient.currency}`, entity, periodLabel, preparedBy, stats, sections });
  };

  const cfRows: { label: string; amount: number; bold?: boolean; section?: boolean }[] = [
    { label: 'Profit before tax (movement)', amount: cashFlow.profitBeforeTax },
    { label: 'Add back: depreciation, amortisation, depletion & impairments', amount: cashFlow.addBacks },
    { label: 'Less: gains on disposal of PPE', amount: -cashFlow.removeGains },
    { label: 'Increase in receivables & contract assets', amount: -cashFlow.deltaReceivables },
    { label: 'Increase in inventories', amount: -cashFlow.deltaInventory },
    { label: 'Increase in prepayments', amount: -cashFlow.deltaPrepaids },
    { label: 'Increase in payables & statutory liabilities', amount: cashFlow.deltaPayables },
    { label: 'Net cash from operating activities', amount: cashFlow.operating, bold: true, section: true },
    { label: 'Acquisition & disposal of non-current assets (net)', amount: cashFlow.investing, section: true },
    { label: 'Borrowings, leases, equity & dividends (net)', amount: cashFlow.financing, section: true },
    { label: 'Net increase / (decrease) in cash', amount: cashFlow.netChange, bold: true },
    { label: 'Cash & bank at start of period', amount: cashFlow.openingCash },
    { label: 'Cash & bank at end of period', amount: cashFlow.closingCash, bold: true },
    { label: 'Residual (must equal zero)', amount: cashFlow.residual, bold: true },
  ];

  return <div className="space-y-5">
    <PageHeader kicker="FINANCIAL REPORTS" title="Ledger reports" desc="Figures are calculated only from the selected entity's own posted journal held on the firm's server. Every entity owns a trial balance of its own. Print any report on its own page from the active tab." />
    <div className="flex flex-wrap items-end gap-3 rounded-xl bg-white p-4 border border-sky-200">
      {isOwner && (
        <label className="text-xs font-semibold">Report entity
          <select value={reportClientId} onChange={e => { setReportChoice(Number(e.target.value)); setFromOverride(null); }} className="block border border-sky-300 p-2 rounded mt-1 font-bold text-[#082f4f]">
            {visibleClients.map(c => <option key={c.id} value={c.id}>{c.code} · {c.name}</option>)}
          </select>
        </label>
      )}
      {!isOwner && (
        <label className="text-xs font-semibold">Report entity
          <span className="block mt-1 rounded border border-sky-200 bg-sky-50 p-2 font-bold text-[#082f4f]">{reportClient.code} · {reportClient.name}</span>
        </label>
      )}
      <label className="text-xs font-semibold">Movement from<input type="date" value={from} max={through} onChange={e => setFromOverride(e.target.value)} className="block border border-sky-300 p-2 rounded mt-1" /></label>
      <label className="text-xs font-semibold">Through<input type="date" value={through} min={from} onChange={e => setThrough(e.target.value)} className="block border border-sky-300 p-2 rounded mt-1" /></label>
      <button onClick={download} className="rounded bg-[#082f4f] text-white px-3 py-2 text-xs font-bold">Export CSV</button>
      <button onClick={print} className="flex items-center gap-1.5 rounded border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50"><Printer className="h-3.5 w-3.5" /> Print this report</button>
      <button onClick={onOpenNotesToAccounts} className="text-xs underline text-[#082f4f]">Notes to accounts</button>
    </div>
    {Math.abs(debit - credit) >= 0.01 && <div role="alert" className="rounded bg-rose-50 border border-rose-400 p-3 text-rose-900">Trial balance differs by {formatGHS(debit - credit)}. Investigate before using these reports.</div>}
    {tab === 'cf' && Math.abs(cashFlow.residual) >= 0.01 && <div role="alert" className="rounded bg-rose-50 border border-rose-400 p-3 text-rose-900">Cash flow does not reconcile to the cash ledger movement (residual {formatGHS(cashFlow.residual)}). Review account classification.</div>}
    <div className="flex flex-wrap gap-2">{(['ias', 'tb', 'pnl', 'bs', 'cf', 'sce', 'cc'] as const).map(t => <button key={t} onClick={() => setTab(t)} className={`px-3 py-2 text-xs font-bold rounded ${tab === t ? 'bg-[#082f4f] text-white' : 'bg-white border border-sky-200'}`}>{t === 'tb' ? 'Trial balance' : t === 'pnl' ? 'Profit or loss' : t === 'bs' ? 'Financial position' : t === 'cf' ? 'Cash flow (IAS 7)' : t === 'sce' ? 'Equity (IAS 1)' : t === 'ias' ? 'Full statements (IAS 1 / 18)' : 'Cost centres'}</button>)}</div>

    {isOwner && (
      <Card title="Per-entity trial balance ownership" sub="Each entity's own journal balances independently — no entity reports another entity's trial balance">
        <div className="overflow-x-auto"><table className="w-full min-w-[640px] text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Entity</th><th className={thCls}>Code</th><th className={thCls}>Currency</th><th className={thCls + ' text-right'}>Own total debits</th><th className={thCls + ' text-right'}>Own total credits</th><th className={thCls}>Trial balance status</th><th className={thCls + ' text-center'}>Open</th></tr></thead><tbody>
          {entityTrials.map(({ client: c, dr, cr, balanced }) => (
            <tr key={c.id} className={rowCls}>
              <td className="p-2 font-bold text-[#082f4f]">{c.name}</td>
              <td className="p-2 font-mono font-bold text-[#855b00]">{c.code}</td>
              <td className="p-2 font-mono">{c.currency}</td>
              <td className={numCls}>{formatGHS(dr)}</td>
              <td className={numCls}>{formatGHS(cr)}</td>
              <td className="p-2"><span className={`rounded px-2 py-0.5 text-[10.5px] font-bold ${balanced ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>{balanced ? 'Balanced (Dr = Cr)' : `Out of balance ₵${formatGHS(Math.abs(dr - cr))}`}</span></td>
              <td className="p-2 text-center">{c.id !== reportClientId && <button onClick={() => onSelectClient(c)} className="rounded border border-sky-300 bg-sky-50 px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-100">Switch workspace</button>}</td>
            </tr>
          ))}
        </tbody></table></div>
      </Card>
    )}

    {tab === 'cc' ? (
      <Card title={`Profit or loss by cost centre — ${reportClient.name} (${reportClient.code}) · ${from} to ${through}`} sub={`Derived from ${reportClient.code}'s own posted journal lines · ${reportClient.currency}`}>
        <div className="overflow-x-auto"><table className="w-full min-w-[640px] text-xs"><thead><tr><th className={thCls}>Cost centre</th><th className={thCls + ' text-right'}>Income</th><th className={thCls + ' text-right'}>Expenses</th><th className={thCls + ' text-right'}>Net</th></tr></thead><tbody>
          {costCentreReport.rows.map((r) => (
            <tr key={r.code} className={rowCls}>
              <td className="p-2 font-mono font-bold text-[#082f4f]">{r.code}</td>
              <td className={numCls}>{formatGHS(r.income)}</td>
              <td className={numCls}>{formatGHS(r.expense)}</td>
              <td className={numCls + ' font-bold'}>{formatGHS(r.net)}</td>
            </tr>
          ))}
          <tr className="bg-sky-100 font-bold"><td className="p-2">Total</td><td className={numCls}>{formatGHS(costCentreReport.totalIncome)}</td><td className={numCls}>{formatGHS(costCentreReport.totalExpense)}</td><td className={numCls}>{formatGHS(costCentreReport.totalNet)}</td></tr>
          <tr><td className="p-2 text-[#355875]">Residual vs entity profit (must equal zero)</td><td colSpan={3} className={numCls}>{formatGHS(costCentreReport.residual)}</td></tr>
        </tbody></table></div>
      </Card>
    ) : tab === 'sce' ? (
      <Card title={`Statement of changes in equity of ${reportClient.name} (${reportClient.code}) — ${from} to ${through}`} sub={`IAS 1, derived from ${reportClient.code}'s own journal · ${reportClient.currency}`}>
        <div className="overflow-x-auto"><table className="w-full min-w-[680px] text-xs"><thead><tr><th className={thCls}>IAS 1 movement</th><th className={thCls + ' text-right'}>Share capital</th><th className={thCls + ' text-right'}>Reserves</th><th className={thCls + ' text-right'}>Retained earnings</th><th className={thCls + ' text-right'}>Total equity</th></tr></thead><tbody>
          {sceRows.map((r, i) => (
            <tr key={i} className={rowCls + (r.bold ? ' bg-sky-50/60' : '')}>
              <td className={`p-2 ${r.bold ? 'font-bold text-[#082f4f]' : 'text-[#2d4f6d]'}`}>{r.label}</td>
              <td className={numCls}>{formatGHS(r.cap)}</td>
              <td className={numCls}>{formatGHS(r.res)}</td>
              <td className={numCls}>{formatGHS(r.re)}</td>
              <td className={numCls + ' font-bold'}>{formatGHS(r.cap + r.res + r.re)}</td>
            </tr>
          ))}
          <tr className="bg-sky-100 font-bold"><td className="p-2">Residual (must equal zero)</td><td colSpan={3}></td><td className={numCls}>{formatGHS((closeCap + closeRes + closeRe) - (openCap + openRes + openRe) - profit + dividends - moveCap - moveRes)}</td></tr>
        </tbody></table></div>
      </Card>
    ) : tab === 'cf' ? (
      <Card title={`Statement of cash flows of ${reportClient.name} (${reportClient.code}) — ${from} to ${through}`} sub={`IAS 7 indirect method, derived from ${reportClient.code}'s own journal · ${reportClient.currency}`}>
        <div className="overflow-x-auto"><table className="w-full min-w-[580px] text-xs"><thead><tr><th className={thCls}>IAS 7 line</th><th className={thCls + ' text-right'}>{reportClient.currency}</th></tr></thead><tbody>
          {cfRows.map((r, i) => (
            <tr key={i} className={rowCls + (r.section ? ' bg-sky-50/60' : '')}>
              <td className={`p-2 ${r.bold ? 'font-bold text-[#082f4f]' : 'text-[#2d4f6d]'}`}>{r.label}</td>
              <td className={numCls + (r.bold ? ' font-bold' : '')}>{formatGHS(r.amount)}</td>
            </tr>
          ))}
        </tbody></table></div>
      </Card>
    ) : tab === 'ias' ? (
      <FinancialStatementsCard currentClient={reportClient} lines={scoped} accounts={accounts} from={from} through={through} currentUser={currentUser} />
    ) : (
      <Card title={tab === 'tb' ? `Trial balance of ${reportClient.name} (${reportClient.code}) through ${through}` : tab === 'pnl' ? `Profit or loss of ${reportClient.name} ${from} to ${through}` : `Financial position of ${reportClient.name} at ${through}`} sub={`Ledger-derived figures owned by ${reportClient.code} · ${reportClient.currency}`}>
        <div className="overflow-x-auto"><table className="w-full min-w-[580px] text-xs"><thead><tr><th className={thCls}>Account</th><th className={thCls}>Name</th><th className={thCls}>Type</th><th className={thCls + ' text-right'}>{tab === 'tb' ? 'Debit' : 'Amount'}</th>{tab === 'tb' && <th className={thCls + ' text-right'}>Credit</th>}</tr></thead><tbody>
          {displayRows.map(r => <tr key={r.code} className={rowCls}><td className="p-2 font-mono">{r.code}</td><td className="p-2">{r.name}</td><td className="p-2">{r.type}</td><td className={numCls}>{formatGHS(value(r))}</td>{tab === 'tb' && <td className={numCls}>{formatGHS(Math.max(0, -net(r)))}</td>}</tr>)}
          {tab === 'tb' ? <tr className="bg-sky-100 font-bold"><td colSpan={3} className="p-2">Totals</td><td className={numCls}>{formatGHS(debit)}</td><td className={numCls}>{formatGHS(credit)}</td></tr> : tab === 'pnl' ? <tr className="bg-sky-100 font-bold"><td colSpan={3} className="p-2">Net result</td><td className={numCls}>{formatGHS(profit)}</td></tr> : <><tr><td colSpan={3} className="p-2">Prior result / current result</td><td className={numCls}>{formatGHS(prior)} / {formatGHS(profit)}</td></tr><tr className="bg-sky-100 font-bold"><td colSpan={3} className="p-2">Residual (must equal zero)</td><td className={numCls}>{formatGHS(residual)}</td></tr></>}
        </tbody></table></div>
      </Card>
    )}
  </div>;
};
