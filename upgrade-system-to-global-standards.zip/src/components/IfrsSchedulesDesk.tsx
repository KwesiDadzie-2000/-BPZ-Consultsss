import { useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, Download, ExternalLink, Layers, Plus, Printer, Save, Send, Trash2 } from 'lucide-react';
import type { ACDOCALine, AccountMaster, ClientEntity, FixedAsset, MonthlyPayrollRecord, PurchaseOrder, SalesInvoice, StockItem, StockMovement, UserAccount } from '@/types/accounting';
import { Card, PageHeader, Stat, cn, formatGHS, numCls, rowCls, tdCls, thCls } from '@/components/ui';
import { buildIfrsPack } from '@/utils/ifrsPack';
import { sectorCitRate } from '@/utils/reports';
import { downloadCsv } from '@/utils/printReport';
import { uniqueId } from '@/utils/ids';
import { buildIfrsSchedules, DEFAULT_IFRS_INPUTS, ECL_BUCKETS, normaliseInputs, type ContingencyInput, type EventInput, type IfrsInputs, type IfrsSchedule, type InputSection, type LeaseInput, type ProposedEntry, type TaxAdjustmentInput } from '@/utils/ifrsSchedules';
import { fiscalStartMonthIndex, fiscalYearStartFor, localToday } from '@/utils/periods';
import { STATUS_STYLE, useWorkbooks } from '@/lib/workbookClient';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  assets: FixedAsset[];
  stockItems: StockItem[];
  stockMovements: StockMovement[];
  invoices: SalesInvoice[];
  orders: PurchaseOrder[];
  payroll: MonthlyPayrollRecord[];
  fiscalYearStart?: string;
  onAddJournalLines: (lines: ACDOCALine[]) => boolean | void;
  onNavigate: (section: string) => void;
}

const STATUS_META: Record<IfrsSchedule['status'], { label: string; cls: string }> = {
  reconciled: { label: 'Reconciled', cls: 'bg-emerald-50 text-emerald-800 border-emerald-300' },
  difference: { label: 'Difference', cls: 'bg-rose-50 text-rose-800 border-rose-300' },
  'no-data': { label: 'No data', cls: 'bg-slate-50 text-slate-600 border-slate-300' },
  'input-required': { label: 'Input required', cls: 'bg-amber-50 text-amber-800 border-amber-300' },
  info: { label: 'Prepared', cls: 'bg-sky-50 text-sky-800 border-sky-300' },
};

const SOURCE_MODULE: Record<string, { section: string; label: string }> = {
  ias16: { section: 'assets', label: 'Fixed Assets Register' },
  ias2: { section: 'inventory', label: 'Inventory & Stock' },
  ifrs9: { section: 'sales', label: 'Sales & Invoicing' },
  ifrs15: { section: 'sales', label: 'Sales & Invoicing' },
  ias19: { section: 'payroll', label: 'Payroll Desk' },
  ifrs7: { section: 'loans_desk', label: 'Loan Schedules' },
  ias12: { section: 'tax_schedule', label: 'Tax & Statutory Returns' },
  ifrs8: { section: 'general_ledger', label: 'General Ledger' },
  ias38: { section: 'general_ledger', label: 'General Ledger' },
};

const fmt = (v: string | number) => (typeof v === 'number' ? (v < 0 ? `(${formatGHS(-v)})` : formatGHS(v)) : v);
const inputCls = 'w-full rounded border border-sky-200 bg-white px-2 py-1 text-xs text-[#0a253e] outline-none focus:border-[#082f4f] disabled:bg-slate-50';

type FieldSpec<T> = { key: keyof T & string; label: string; type: 'text' | 'number' | 'date' | 'select'; options?: string[] };

function ListEditor<T extends { id: string }>({ title, rows, fields, onChange, make, disabled }: { title: string; rows: T[]; fields: FieldSpec<T>[]; onChange: (rows: T[]) => void; make: () => T; disabled: boolean }) {
  const set = (i: number, f: FieldSpec<T>, raw: string) => {
    const next = rows.slice();
    next[i] = { ...next[i], [f.key]: f.type === 'number' ? (raw === '' ? 0 : Number(raw)) : raw };
    onChange(next);
  };
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h4 className="text-xs font-bold uppercase tracking-wider text-[#2d4f6d]">{title}</h4>
        <button type="button" disabled={disabled} onClick={() => onChange([...rows, make()])} className="inline-flex items-center gap-1 rounded-md border border-sky-300 bg-white px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50 disabled:opacity-50"><Plus className="h-3 w-3" />Add row</button>
      </div>
      <div className="overflow-x-auto rounded-lg border border-sky-100">
        <table className="w-full min-w-[640px]">
          <thead><tr>{fields.map((f) => <th key={f.key} className={thCls}>{f.label}</th>)}<th className={thCls}><span className="sr-only">Remove</span></th></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={fields.length + 1} className={cn(tdCls, 'text-center text-[#355875]')}>No rows yet.</td></tr>}
            {rows.map((r, i) => (
              <tr key={r.id} className={rowCls}>
                {fields.map((f) => (
                  <td key={f.key} className="px-1.5 py-1">
                    {f.type === 'select' ? (
                      <select aria-label={f.label} disabled={disabled} className={inputCls} value={String(r[f.key] ?? '')} onChange={(e) => set(i, f, e.target.value)}>{(f.options ?? []).map((o) => <option key={o} value={o}>{o}</option>)}</select>
                    ) : (
                      <input aria-label={f.label} disabled={disabled} type={f.type === 'number' ? 'number' : f.type} step="any" className={cn(inputCls, f.type === 'number' && 'text-right font-mono')} value={String(r[f.key] ?? '')} onChange={(e) => set(i, f, e.target.value)} />
                    )}
                  </td>
                ))}
                <td className="px-1.5 py-1 text-right"><button type="button" disabled={disabled} aria-label="Remove row" onClick={() => onChange(rows.filter((_, j) => j !== i))} className="rounded p-1 text-rose-700 hover:bg-rose-50 disabled:opacity-40"><Trash2 className="h-3.5 w-3.5" /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const newId = () => Math.random().toString(36).slice(2, 10);

export function IfrsSchedulesDesk(props: Props) {
  const { currentClient, currentUser, accounts, onAddJournalLines, onNavigate } = props;
  const today = localToday();
  const fyIdx = fiscalStartMonthIndex(props.fiscalYearStart);
  const [from, setFrom] = useState(`${fiscalYearStartFor(today, fyIdx)}-01`);
  const [through, setThrough] = useState(today);
  const [selected, setSelected] = useState('ias16');
  const [message, setMessage] = useState<{ tone: 'ok' | 'error'; text: string } | null>(null);
  const readOnly = currentUser.role === 'auditor' || (currentUser.status ?? 'active') !== 'active';
  const wbKey = `FY${through.slice(0, 4)}`;
  const wb = useWorkbooks<IfrsInputs>(currentClient.id, 'ifrs_inputs');
  const saved = wb.items.find((w) => w.key === wbKey);
  const [draft, setDraft] = useState<{ key: string; value: IfrsInputs } | null>(null);
  const inputs = draft?.key === wbKey ? draft.value : saved ? normaliseInputs(saved.payload) : DEFAULT_IFRS_INPUTS;
  const dirty = draft?.key === wbKey;
  const update = (patch: Partial<IfrsInputs>) => setDraft({ key: wbKey, value: { ...inputs, ...patch } });
  const periodValid = from <= through;

  const entityLines = useMemo(() => props.lines.filter((l) => l.clientId === currentClient.id), [props.lines, currentClient.id]);
  const pack = useMemo(() => (periodValid ? buildIfrsPack({ lines: entityLines, accounts, from, through, currency: currentClient.currency, entityName: currentClient.name, entityCode: currentClient.code, jurisdiction: currentClient.jurisdiction, regNumber: currentClient.regNumber, sector: currentClient.sector }) : null), [entityLines, accounts, from, through, currentClient, periodValid]);
  const schedules = useMemo(() => {
    if (!periodValid) return [];
    const noteFor = (std: string) => {
      const n = pack?.notes.find((x) => x.standard.split(/[/,]/).map((s) => s.trim()).includes(std)) ?? pack?.notes.find((x) => x.standard.includes(std));
      return n ? { number: n.number, title: n.title } : undefined;
    };
    return buildIfrsSchedules({ lines: entityLines, accounts, clientId: currentClient.id, currency: currentClient.currency, from, through, assets: props.assets, stockItems: props.stockItems, stockMovements: props.stockMovements, invoices: props.invoices, orders: props.orders, payroll: props.payroll, citRatePct: sectorCitRate(currentClient.sector).rate, inputs, noteFor });
  }, [entityLines, accounts, currentClient, from, through, props.assets, props.stockItems, props.stockMovements, props.invoices, props.orders, props.payroll, inputs, pack, periodValid]);
  const active = schedules.find((s) => s.id === selected) ?? schedules[0];
  const counts = schedules.reduce<Record<string, number>>((m, s) => ((m[s.status] = (m[s.status] ?? 0) + 1), m), {});
  const pending = schedules.flatMap((s) => s.entries).filter((e) => !e.blockedReason && !e.posted).length;

  const saveInputs = async () => {
    if (readOnly) return;
    const res = await wb.save(wbKey, `IFRS schedule inputs ${wbKey}`, inputs, saved?.version ?? 0);
    if (res.ok) {
      setDraft(null);
      setMessage({ tone: 'ok', text: `Schedule inputs saved (version ${res.workbook?.version}). Changes are audit-logged.` });
    } else setMessage({ tone: 'error', text: res.error ?? 'Save failed.' });
  };

  const post = (s: IfrsSchedule, e: ProposedEntry) => {
    if (readOnly || e.blockedReason || e.posted) return;
    const docNo = `IFRS-${s.standard.replace(/[^A-Z0-9]/gi, '')}-${Date.now().toString(36).toUpperCase()}`;
    const journal: ACDOCALine[] = e.lines.map((l) => ({ id: uniqueId('JL-IFRS'), docNo, period: e.date.slice(0, 7), date: e.date, module: 'FI', docType: 'JE', accountNo: l.accountNo, accountName: l.accountName, debit: l.debit, credit: l.credit, currency: currentClient.currency, description: `${e.title} [${e.key}]`.slice(0, 240), createdBy: currentUser.username, clientId: currentClient.id, reference: e.key }));
    const ok = onAddJournalLines(journal);
    setMessage(ok === false ? { tone: 'error', text: 'The journal controls rejected this entry (closed period, posting authority or chart validation). See the notice bar for the exact reason.' } : { tone: 'ok', text: `${docNo} submitted. Entries above your maker limit are routed to the approvals queue for an independent checker.` });
  };

  const exportCsv = (s: IfrsSchedule) => {
    const rows: (string | number)[][] = [[`${currentClient.name} (${currentClient.code})`], [`${s.standard} — ${s.title}`], [`Period ${from} to ${through}`, s.noteRef ? `Note ${s.noteRef}` : ''], []];
    for (const t of s.tables) rows.push([t.title], t.columns, ...t.rows, ...(t.totals ? [t.totals] : []), []);
    if (s.reconciliations.length) rows.push(['Reconciliation', 'Schedule', 'Ledger', 'Difference'], ...s.reconciliations.map((r) => [r.label, r.schedule, r.ledger, r.difference]));
    downloadCsv(`${currentClient.code}_${s.id}_${through}.csv`, rows);
  };

  const renderInputs = (section: InputSection) => {
    const d = readOnly;
    switch (section) {
      case 'leases':
        return <ListEditor<LeaseInput> key={section} title="Lease register (IFRS 16)" rows={inputs.leases} disabled={d} onChange={(leases) => update({ leases })} make={() => ({ id: newId(), name: '', lessor: '', commencement: from, termMonths: 36, payment: 0, frequency: 'monthly', timing: 'arrears', ratePct: 20, initialDirectCosts: 0 })} fields={[{ key: 'name', label: 'Lease', type: 'text' }, { key: 'lessor', label: 'Lessor', type: 'text' }, { key: 'commencement', label: 'Commencement', type: 'date' }, { key: 'termMonths', label: 'Term (months)', type: 'number' }, { key: 'payment', label: 'Payment', type: 'number' }, { key: 'frequency', label: 'Frequency', type: 'select', options: ['monthly', 'quarterly', 'annual'] }, { key: 'timing', label: 'Timing', type: 'select', options: ['arrears', 'advance'] }, { key: 'ratePct', label: 'IBR % p.a.', type: 'number' }, { key: 'initialDirectCosts', label: 'Initial direct costs', type: 'number' }]} />;
      case 'provisions':
        return <ListEditor key={section} title="Provisions (IAS 37.84)" rows={inputs.provisions} disabled={d} onChange={(provisions) => update({ provisions })} make={() => ({ id: newId(), name: '', category: '', opening: 0, additions: 0, utilised: 0, reversed: 0, unwinding: 0, expectedTiming: '' })} fields={[{ key: 'name', label: 'Provision', type: 'text' }, { key: 'category', label: 'Class', type: 'text' }, { key: 'opening', label: 'Opening', type: 'number' }, { key: 'additions', label: 'Additions', type: 'number' }, { key: 'utilised', label: 'Utilised', type: 'number' }, { key: 'reversed', label: 'Reversed', type: 'number' }, { key: 'unwinding', label: 'Unwinding', type: 'number' }, { key: 'expectedTiming', label: 'Expected timing', type: 'text' }]} />;
      case 'contingencies':
        return <ListEditor<ContingencyInput> key={section} title="Contingent liabilities (IAS 37.86)" rows={inputs.contingencies} disabled={d} onChange={(contingencies) => update({ contingencies })} make={() => ({ id: newId(), nature: '', estimate: 0, likelihood: 'possible', status: '' })} fields={[{ key: 'nature', label: 'Nature', type: 'text' }, { key: 'estimate', label: 'Estimate', type: 'number' }, { key: 'likelihood', label: 'Likelihood', type: 'select', options: ['remote', 'possible', 'probable'] }, { key: 'status', label: 'Status', type: 'text' }]} />;
      case 'relatedParties':
        return <ListEditor key={section} title="Related parties (IAS 24)" rows={inputs.relatedParties} disabled={d} onChange={(relatedParties) => update({ relatedParties })} make={() => ({ id: newId(), party: '', relationship: '', nature: '', transactions: 0, balance: 0 })} fields={[{ key: 'party', label: 'Party', type: 'text' }, { key: 'relationship', label: 'Relationship', type: 'text' }, { key: 'nature', label: 'Nature', type: 'text' }, { key: 'transactions', label: 'Transactions', type: 'number' }, { key: 'balance', label: 'Balance', type: 'number' }]} />;
      case 'events':
        return <ListEditor<EventInput> key={section} title="Events after the reporting period (IAS 10)" rows={inputs.events} disabled={d} onChange={(events) => update({ events })} make={() => ({ id: newId(), date: today, description: '', type: 'non-adjusting', effect: 0, treatment: '' })} fields={[{ key: 'date', label: 'Date', type: 'date' }, { key: 'description', label: 'Description', type: 'text' }, { key: 'type', label: 'Type', type: 'select', options: ['non-adjusting', 'adjusting'] }, { key: 'effect', label: 'Effect', type: 'number' }, { key: 'treatment', label: 'Treatment', type: 'text' }]} />;
      case 'impairments':
        return <ListEditor key={section} title="Impairment tests (IAS 36)" rows={inputs.impairments} disabled={d} onChange={(impairments) => update({ impairments })} make={() => ({ id: newId(), cgu: '', carryingAmount: 0, cashFlows: '0,0,0,0,0', growthPct: 3, discountPct: 18, fvlcd: 0 })} fields={[{ key: 'cgu', label: 'CGU / asset', type: 'text' }, { key: 'carryingAmount', label: 'Carrying amount', type: 'number' }, { key: 'cashFlows', label: 'Cash flows Y1–Y5 (comma-separated)', type: 'text' }, { key: 'growthPct', label: 'Terminal growth %', type: 'number' }, { key: 'discountPct', label: 'Discount rate %', type: 'number' }, { key: 'fvlcd', label: 'FV less costs of disposal', type: 'number' }]} />;
      case 'taxAdjustments':
        return <ListEditor<TaxAdjustmentInput> key={section} title="Tax computation adjustments (IAS 12)" rows={inputs.taxAdjustments} disabled={d} onChange={(taxAdjustments) => update({ taxAdjustments })} make={() => ({ id: newId(), label: '', amount: 0, kind: 'permanent_addback' })} fields={[{ key: 'label', label: 'Adjustment', type: 'text' }, { key: 'amount', label: 'Amount', type: 'number' }, { key: 'kind', label: 'Kind', type: 'select', options: ['permanent_addback', 'permanent_deduction', 'temporary_taxable', 'temporary_deductible'] }]} />;
      case 'ecl':
        return (
          <div key={section} className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#2d4f6d]">Provision matrix loss rates (IFRS 9)</h4>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-6">
              {ECL_BUCKETS.map((b, i) => (
                <label key={b} className="text-[11px] font-semibold text-[#355875]">{b}
                  <input type="number" step="any" min={0} max={100} disabled={d} className={cn(inputCls, 'mt-1 text-right font-mono')} value={inputs.ecl.rates[i]} onChange={(e) => { const rates = inputs.ecl.rates.slice(); rates[i] = Number(e.target.value); update({ ecl: { ...inputs.ecl, rates } }); }} />
                </label>
              ))}
              <label className="text-[11px] font-semibold text-[#355875]">Credit terms (days)
                <input type="number" min={0} disabled={d} className={cn(inputCls, 'mt-1 text-right font-mono')} value={inputs.ecl.creditTermsDays} onChange={(e) => update({ ecl: { ...inputs.ecl, creditTermsDays: Number(e.target.value) } })} />
              </label>
            </div>
          </div>
        );
      case 'eps':
        return (
          <div key={section} className="grid grid-cols-1 gap-2 sm:grid-cols-3">
            {([['weightedShares', 'Weighted average ordinary shares'], ['dilutiveShares', 'Dilutive potential shares'], ['preferenceDividends', 'Preference dividends']] as const).map(([k, label]) => (
              <label key={k} className="text-[11px] font-semibold text-[#355875]">{label}
                <input type="number" min={0} step="any" disabled={d} className={cn(inputCls, 'mt-1 text-right font-mono')} value={inputs.eps[k]} onChange={(e) => update({ eps: { ...inputs.eps, [k]: Number(e.target.value) } })} />
              </label>
            ))}
          </div>
        );
      case 'nrv':
        return (
          <div key={section} className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#2d4f6d]">Net realisable value per unit (IAS 2.28–33)</h4>
            <div className="max-h-64 overflow-auto rounded-lg border border-sky-100">
              <table className="w-full"><thead><tr><th className={thCls}>Item</th><th className={thCls}>Description</th><th className={cn(thCls, 'text-right')}>Unit cost</th><th className={cn(thCls, 'text-right')}>NRV / unit</th></tr></thead>
                <tbody>{props.stockItems.map((s) => (
                  <tr key={s.id} className={rowCls}><td className={tdCls}>{s.itemCode}</td><td className={tdCls}>{s.description}</td><td className={numCls}>{formatGHS(s.unitCost)}</td>
                    <td className="px-1.5 py-1"><input aria-label={`NRV for ${s.itemCode}`} type="number" min={0} step="any" disabled={d} className={cn(inputCls, 'text-right font-mono')} value={inputs.nrv[s.itemCode] ?? s.netRealisableValue ?? s.unitCost} onChange={(e) => update({ nrv: { ...inputs.nrv, [s.itemCode]: Number(e.target.value) } })} /></td></tr>
                ))}</tbody></table>
            </div>
          </div>
        );
      case 'risk':
        return (
          <div key={section} className="grid grid-cols-1 gap-2 sm:grid-cols-3">
            {([['fxShockPct', 'FX sensitivity shock %'], ['interestShockPct', 'Interest-rate shock (pp)'], ['kmpCompensation', 'KMP compensation for period']] as const).map(([k, label]) => (
              <label key={k} className="text-[11px] font-semibold text-[#355875]">{label}
                <input type="number" min={0} step="any" disabled={d} className={cn(inputCls, 'mt-1 text-right font-mono')} value={inputs[k]} onChange={(e) => update({ [k]: Number(e.target.value) } as Partial<IfrsInputs>)} />
              </label>
            ))}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader kicker="IFRS · Supporting schedules" title="IFRS Schedules Desk" desc="Supporting schedules for every standard disclosed in the notes — computed from the ledger and subsidiary registers, cross-referenced to note numbers, reconciled to the general ledger, with correcting journals routed through maker-checker posting.">
        <label className="text-[11px] font-bold text-[#355875]">From <input type="date" value={from} max={through} onChange={(e) => setFrom(e.target.value)} className="ml-1 rounded border border-sky-300 px-2 py-1 text-xs" /></label>
        <label className="text-[11px] font-bold text-[#355875]">Through <input type="date" value={through} min={from} onChange={(e) => setThrough(e.target.value)} className="ml-1 rounded border border-sky-300 px-2 py-1 text-xs" /></label>
        <button type="button" onClick={() => onNavigate('ifrs_statements')} className="inline-flex items-center gap-1 rounded-md border border-sky-300 bg-white px-2.5 py-1.5 text-xs font-bold text-[#082f4f] hover:bg-sky-50"><ExternalLink className="h-3.5 w-3.5" />Statements & notes</button>
      </PageHeader>

      {!periodValid && <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-800">The start date must be on or before the end date.</div>}
      {message && <div role="status" className={cn('rounded-lg border px-3 py-2 text-xs font-bold', message.tone === 'ok' ? 'border-emerald-300 bg-emerald-50 text-emerald-800' : 'border-rose-300 bg-rose-50 text-rose-800')}>{message.text}</div>}
      {wb.error && <div role="alert" className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-xs font-bold text-amber-900">{wb.error}</div>}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label="Schedules" value={schedules.length} sub={`${currentClient.code} · ${currentClient.currency}`} />
        <Stat label="Reconciled" value={counts.reconciled ?? 0} tone="text-emerald-700" />
        <Stat label="Differences" value={counts.difference ?? 0} tone={(counts.difference ?? 0) ? 'text-rose-700' : undefined} />
        <Stat label="Input required" value={counts['input-required'] ?? 0} tone={(counts['input-required'] ?? 0) ? 'text-amber-700' : undefined} />
        <Stat label="Adjustments ready" value={pending} sub="Proposed journals not yet posted" />
      </div>

      <div className="grid gap-4 lg:grid-cols-[17rem_1fr]">
        <Card title="Standards" sub="Select a schedule" pad={false}>
          <nav aria-label="IFRS schedules" className="max-h-[70vh] overflow-y-auto">
            {schedules.map((s) => (
              <button key={s.id} type="button" onClick={() => setSelected(s.id)} aria-current={active?.id === s.id ? 'true' : undefined} className={cn('flex w-full items-start justify-between gap-2 border-b border-sky-100 px-3 py-2 text-left hover:bg-[#f3f9ff]', active?.id === s.id && 'bg-[#eaf4ff]')}>
                <span className="min-w-0"><span className="block text-[11px] font-black text-[#855b00]">{s.standard}{s.noteRef ? ` · Note ${s.noteRef}` : ''}</span><span className="block truncate text-xs font-semibold text-[#0a253e]">{s.title}</span></span>
                <span className={cn('shrink-0 rounded border px-1.5 py-0.5 text-[9.5px] font-bold', STATUS_META[s.status].cls)}>{STATUS_META[s.status].label}</span>
              </button>
            ))}
          </nav>
        </Card>

        {active && (
          <div className="space-y-4">
            <Card title={<span className="inline-flex items-center gap-2"><Layers className="h-4 w-4 text-[#855b00]" />{active.standard} — {active.title}</span>} sub={active.noteRef ? `Supports Note ${active.noteRef}: ${active.noteTitle}` : 'Not separately disclosed in the generated notes for this period'}
              action={<>
                {SOURCE_MODULE[active.id] && <button type="button" onClick={() => onNavigate(SOURCE_MODULE[active.id].section)} className="inline-flex items-center gap-1 rounded-md border border-sky-300 bg-white px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50"><ExternalLink className="h-3 w-3" />{SOURCE_MODULE[active.id].label}</button>}
                <button type="button" onClick={() => exportCsv(active)} className="inline-flex items-center gap-1 rounded-md border border-sky-300 bg-white px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50"><Download className="h-3 w-3" />CSV</button>
                <button type="button" onClick={() => window.print()} className="inline-flex items-center gap-1 rounded-md border border-sky-300 bg-white px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50"><Printer className="h-3 w-3" />Print</button>
              </>}>
              <p className="text-xs leading-relaxed text-[#2d4f6d]">{active.summary}</p>
              <div className="mt-3 grid grid-cols-2 gap-2 md:grid-cols-4">
                {active.kpis.map((k) => (
                  <div key={k.label} className="rounded-lg border border-sky-100 bg-[#f7fbff] px-3 py-2">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-[#355875]">{k.label}</div>
                    <div className={cn('font-mono text-sm font-extrabold tabular-nums', k.tone === 'bad' ? 'text-rose-700' : k.tone === 'good' ? 'text-emerald-700' : 'text-[#0a253e]')}>{typeof k.value === 'number' && !Number.isInteger(k.value) ? fmt(k.value) : typeof k.value === 'number' && Math.abs(k.value) >= 1000 ? fmt(k.value) : k.value}</div>
                  </div>
                ))}
              </div>
            </Card>

            {active.tables.map((t) => (
              <Card key={t.title} title={t.title} pad={false}>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead><tr>{t.columns.map((c, i) => <th key={c} className={cn(thCls, i > 0 && 'text-right')}>{c}</th>)}</tr></thead>
                    <tbody>
                      {t.rows.length === 0 && <tr><td colSpan={t.columns.length} className={cn(tdCls, 'text-center text-[#355875]')}>No items for this period.</td></tr>}
                      {t.rows.map((r, i) => <tr key={i} className={rowCls}>{r.map((c, j) => <td key={j} className={j === 0 || typeof c === 'string' ? cn(tdCls, j > 0 && 'text-right') : numCls}>{fmt(c)}</td>)}</tr>)}
                    </tbody>
                    {t.totals && <tfoot><tr className="border-t-2 border-[#082f4f] bg-[#f7fbff]">{t.totals.map((c, j) => <td key={j} className={cn(j === 0 || typeof c === 'string' ? tdCls : numCls, 'font-extrabold')}>{fmt(c)}</td>)}</tr></tfoot>}
                  </table>
                </div>
              </Card>
            ))}

            {active.reconciliations.length > 0 && (
              <Card title="Reconciliation to the general ledger" pad={false}>
                <table className="w-full">
                  <thead><tr><th className={thCls}>Check</th><th className={cn(thCls, 'text-right')}>Schedule</th><th className={cn(thCls, 'text-right')}>Ledger</th><th className={cn(thCls, 'text-right')}>Difference</th><th className={thCls}>Result</th></tr></thead>
                  <tbody>{active.reconciliations.map((r) => (
                    <tr key={r.label} className={rowCls}><td className={tdCls}>{r.label}{r.note && <span className="block text-[10px] text-[#355875]">{r.note}</span>}</td><td className={numCls}>{fmt(r.schedule)}</td><td className={numCls}>{fmt(r.ledger)}</td><td className={cn(numCls, !r.ok && 'text-rose-700 font-bold')}>{fmt(r.difference)}</td>
                      <td className={tdCls}>{r.ok ? <span className="inline-flex items-center gap-1 font-bold text-emerald-700"><CheckCircle2 className="h-3.5 w-3.5" />Agreed</span> : <span className="inline-flex items-center gap-1 font-bold text-rose-700"><AlertTriangle className="h-3.5 w-3.5" />Investigate</span>}</td></tr>
                  ))}</tbody>
                </table>
              </Card>
            )}

            {active.entries.length > 0 && (
              <Card title="Proposed adjusting journals" sub="Posted through the standard journal controls: period locks, chart validation, maker limits and the approvals queue.">
                <div className="space-y-3">
                  {active.entries.map((e) => (
                    <div key={e.key} className="rounded-lg border border-sky-100 p-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div><div className="text-xs font-bold text-[#0a253e]">{e.title}</div><div className="text-[10px] text-[#355875]">Posting date {e.date} · key {e.key}</div></div>
                        {e.posted ? <span className="rounded border border-emerald-300 bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-800">Already posted</span>
                          : <button type="button" disabled={readOnly || Boolean(e.blockedReason)} onClick={() => post(active, e)} className="inline-flex items-center gap-1 rounded-md bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] disabled:opacity-50"><Send className="h-3 w-3" />Post via maker-checker</button>}
                      </div>
                      {e.blockedReason && !e.posted && <p className="mt-1 text-[11px] font-semibold text-amber-800">{e.blockedReason}</p>}
                      {e.lines.length > 0 && (
                        <table className="mt-2 w-full"><thead><tr><th className={thCls}>Account</th><th className={cn(thCls, 'text-right')}>Debit</th><th className={cn(thCls, 'text-right')}>Credit</th></tr></thead>
                          <tbody>{e.lines.map((l, i) => <tr key={i} className={rowCls}><td className={tdCls}>{l.accountNo} · {l.accountName}</td><td className={numCls}>{l.debit ? formatGHS(l.debit) : ''}</td><td className={numCls}>{l.credit ? formatGHS(l.credit) : ''}</td></tr>)}</tbody></table>
                      )}
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {active.insights.length > 0 && (
              <Card title="Review points">
                <ul className="list-disc space-y-1 pl-5 text-xs text-[#2d4f6d]">{active.insights.map((i) => <li key={i}>{i}</li>)}</ul>
              </Card>
            )}

            {active.inputs.length > 0 && (
              <Card title="Schedule inputs" sub={saved ? `Saved version ${saved.version} · last by ${saved.preparedBy ?? '—'} · ${new Date(saved.updatedAt).toLocaleString()}` : `Not yet saved for ${wbKey}`}
                action={<>
                  {saved && <span className={cn('rounded border px-2 py-0.5 text-[10px] font-bold', STATUS_STYLE[saved.status])}>{saved.status}</span>}
                  <button type="button" disabled={readOnly || !dirty} onClick={() => void saveInputs()} className="inline-flex items-center gap-1 rounded-md bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] disabled:opacity-50"><Save className="h-3 w-3" />{dirty ? 'Save inputs' : 'Saved'}</button>
                </>}>
                {readOnly && <p className="mb-2 text-[11px] font-semibold text-amber-800">Your role is read-only — inputs cannot be changed.</p>}
                <div className="space-y-4">{active.inputs.map((s) => renderInputs(s))}</div>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
