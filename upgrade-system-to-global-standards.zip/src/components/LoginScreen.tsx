import { useEffect, useState } from 'react';
import type { UserAccount } from '../types/accounting';
import { apiFetch, broadcastSessionChange, clearSessionStore, setSession } from '../utils/session';
import { Lock, User, ShieldAlert, KeyRound } from 'lucide-react';
import { isLocalReview } from '../preview/config';
import { INITIAL_USERS } from '../data/accountingSeed';

const MAX_FAILED_ATTEMPTS = 5;

interface LoginScreenProps {
  onLogin: (user: UserAccount) => void;
  /** Explains why the user was returned to sign-in (e.g. an expired session). */
  notice?: string | null;
}

const ATTEMPTS_KEY = 'bpz_failed_logins_v1';
const LOCKOUT_KEY = 'bpz_login_lockout_until';

function readAttempts(): number {
  for (const kind of ['sessionStorage', 'localStorage'] as const) {
    try {
      const s = globalThis[kind];
      const n = Number(s?.getItem(ATTEMPTS_KEY) || '0');
      if (Number.isFinite(n) && n > 0) return n;
    } catch { /* ignore */ }
  }
  return 0;
}

function readLockoutUntil(): number {
  for (const kind of ['sessionStorage', 'localStorage'] as const) {
    try {
      const s = globalThis[kind];
      const n = Number(s?.getItem(LOCKOUT_KEY) || '0');
      if (Number.isFinite(n) && n > 0) return n;
    } catch { /* ignore */ }
  }
  return 0;
}

function writeCounters(attempts: number, lockoutUntil: number): void {
  for (const kind of ['sessionStorage', 'localStorage'] as const) {
    try {
      const s = globalThis[kind];
      s?.setItem(ATTEMPTS_KEY, String(attempts));
      if (lockoutUntil > 0) s?.setItem(LOCKOUT_KEY, String(lockoutUntil));
      else s?.removeItem(LOCKOUT_KEY);
    } catch { /* ignore */ }
  }
}

/**
 * Sign-in form.
 *
 * Session *restoration* deliberately does NOT happen here any more. It used to:
 * an effect fired `GET /api/auth/session` on every mount (and on every parent
 * re-render, because `onLogin` is an inline arrow), and a late, rejected
 * response called `clearSessionStore()` — wiping the token that a successful
 * sign-in had just written. The user was therefore returned to this screen a
 * moment after signing in. `App.tsx` now restores the session once, before this
 * component is ever rendered, and this form only ever signs people IN.
 */
export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, notice }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [failedAttempts, setFailedAttempts] = useState<number>(() => readAttempts());
  // First-run owner activation (fresh database, no operator-supplied password).
  const [setup, setSetup] = useState<{ available: boolean; tokenRequired: boolean; owner: string | null } | null>(null);
  const [showSignIn, setShowSignIn] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [setupToken, setSetupToken] = useState('');

  useEffect(() => {
    if (isLocalReview()) return;
    let cancelled = false;
    apiFetch('/api/auth/setup')
      .then((r) => r.json())
      .then((b) => { if (!cancelled && b?.ok) setSetup({ available: Boolean(b.activationAvailable), tokenRequired: Boolean(b.tokenRequired), owner: b.ownerUsername ?? null }); })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);

  const activate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (newPassword !== confirmPassword) { setError('The two passwords do not match.'); return; }
    setBusy(true);
    try {
      const res = await apiFetch('/api/auth/setup', { method: 'POST', body: JSON.stringify({ password: newPassword, confirm: confirmPassword, setupToken }) });
      const body = await res.json().catch(() => null);
      if (!res.ok || !body?.ok) {
        setError(body?.error || 'Activation failed.');
        if (res.status === 409) setSetup((s) => (s ? { ...s, available: false } : s));
        return;
      }
      setSession(String(body.token || ''), body.user);
      broadcastSessionChange(true);
      onLogin(body.user as UserAccount);
    } catch {
      setError('Could not reach the activation service. Try again.');
    } finally {
      setBusy(false);
    }
  };
  const activating = Boolean(setup?.available) && !showSignIn;

  const recordFailure = () => {
    const previousLock = readLockoutUntil();
    const next = previousLock > 0 && previousLock <= Date.now() ? 1 : failedAttempts + 1;
    setFailedAttempts(next);
    writeCounters(next, next >= MAX_FAILED_ATTEMPTS ? Date.now() + 5 * 60 * 1000 : 0);
  };

  const tryLogin = async (uInput: string, pInput: string) => {
    const lockedUntil = readLockoutUntil();
    if (lockedUntil > Date.now()) {
      setError(`Too many failed attempts. Try again in ${Math.max(1, Math.ceil((lockedUntil - Date.now()) / 60000))} minute(s).`);
      return;
    }
    setError(null);
    setBusy(true);
    try {
      const res = await apiFetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ usernameOrEmail: uInput.trim(), password: pInput }),
      });
      const body = await res.json().catch(() => null);
      if (!res.ok || !body?.ok) {
        // Only a genuine credential rejection counts toward the lockout. Server
        // or database errors (5xx/503) previously counted too, so an outage
        // locked correct passwords out for 5 minutes.
        if (res.status === 401) recordFailure();
        setError(
          body?.error ||
            (res.status >= 500
              ? 'The sign-in service is temporarily unavailable. Please try again in a moment.'
              : 'Invalid username, email, or password.')
        );
        return;
      }
      const found = body.user as UserAccount;
      writeCounters(0, 0);
      setFailedAttempts(0);
      // Store the token first (mirrored in sessionStorage + localStorage), then
      // hand the user to the workspace. The server has also set an HttpOnly
      // cookie, so the session survives even if both stores are unavailable.
      setSession(String(body.token || ''), found);
      broadcastSessionChange(true);
      onLogin(found);
    } catch {
      setError('Could not reach the sign-in service. Try again.');
    } finally {
      setBusy(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void tryLogin(username, password);
  };

  return (
    <div className="min-h-screen bg-[#f0f6fc] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-6">
          <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#f5b719] font-black text-[#082f4f] text-lg shadow-md">
            BPZ
          </span>
          <h1 className="mt-3 text-xl font-black text-[#082f4f]">BPZ Consult</h1>
          <p className="text-xs text-[#355875] font-semibold mt-0.5">Sign in to your workspace</p>
        </div>

        <div className="rounded-2xl border border-sky-200 bg-white p-6 shadow-sm space-y-4">
          <div className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-[11px] font-bold text-amber-900 flex items-start gap-2">
            <ShieldAlert className="h-4 w-4 mt-0.5 text-amber-700 shrink-0" />
            <span>{isLocalReview() ? 'Local review workspace. Sample data is saved only in this browser. No production authentication or database is connected.' : 'Secure sign-in: credentials are verified on the server (scrypt-hashed, per-user salt). Enable MFA before client rollout.'}</span>
          </div>

          {notice && !error && (
            <div className="rounded-lg border border-sky-300 bg-sky-50 px-3 py-2 text-[11px] font-bold text-[#0a4a6e]">{notice}</div>
          )}

          {error && (
            <div className="rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-800">{error}</div>
          )}

          {activating && (
            <form onSubmit={activate} className="space-y-3" aria-labelledby="activation-title">
              <div className="rounded-lg border border-sky-300 bg-sky-50 px-3 py-2 text-[11px] font-semibold text-[#0a4a6e]">
                <div id="activation-title" className="flex items-center gap-1.5 font-black uppercase tracking-wider"><KeyRound className="h-3.5 w-3.5" />First-run activation</div>
                This workspace has not been activated. Set the password for the owner account <strong>{setup?.owner}</strong>. This one-time step is audit-logged and then permanently closed.
              </div>
              {setup?.tokenRequired && (
                <div>
                  <label htmlFor="setup-token" className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">Setup token</label>
                  <input id="setup-token" type="password" value={setupToken} onChange={(e) => setSetupToken(e.target.value)} required autoComplete="off" className="w-full rounded-lg border border-sky-300 bg-white px-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]" />
                </div>
              )}
              <div>
                <label htmlFor="setup-password" className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">New owner password</label>
                <input id="setup-password" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength={10} autoComplete="new-password" aria-describedby="setup-password-hint" className="w-full rounded-lg border border-sky-300 bg-white px-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]" />
                <p id="setup-password-hint" className="mt-1 text-[10.5px] text-[#355875]">At least 10 characters. Use a passphrase you do not use elsewhere.</p>
              </div>
              <div>
                <label htmlFor="setup-confirm" className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">Confirm password</label>
                <input id="setup-confirm" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required minLength={10} autoComplete="new-password" className="w-full rounded-lg border border-sky-300 bg-white px-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]" />
              </div>
              <button type="submit" disabled={busy} className="w-full rounded-lg bg-[#082f4f] py-2.5 text-sm font-bold text-white hover:bg-[#0c3f68] transition disabled:opacity-60">{busy ? 'Activating…' : 'Activate workspace & sign in'}</button>
              <button type="button" onClick={() => setShowSignIn(true)} className="w-full text-[11px] font-bold text-[#355875] underline">I already have credentials — sign in</button>
            </form>
          )}

          {activating ? null : isLocalReview() ? <button type="button" onClick={() => onLogin({ ...INITIAL_USERS[0], password: undefined })} className="w-full rounded-lg bg-[#082f4f] py-2.5 text-sm font-bold text-white hover:bg-[#0c3f68] transition">Open review workspace</button> : <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label htmlFor="login-username" className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">Username or email</label>
              <div className="relative">
                <User className="absolute left-2.5 top-2 h-4 w-4 text-sky-400" />
                <input
                  type="text"
                  id="login-username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Username or email"
                  className="w-full rounded-lg border border-sky-300 bg-white pl-8 pr-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]"
                  required
                  autoComplete="username"
                />
              </div>
            </div>

            <div>
              <label htmlFor="login-password" className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-2.5 top-2 h-4 w-4 text-sky-400" />
                <input
                  type="password"
                  id="login-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter passcode"
                  className="w-full rounded-lg border border-sky-300 bg-white pl-8 pr-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]"
                  required
                  autoComplete="current-password"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-lg bg-[#082f4f] py-2.5 text-sm font-bold text-white hover:bg-[#0c3f68] transition disabled:opacity-60"
            >
              {busy ? 'Signing in…' : 'Sign In'}
            </button>
          </form>}

          <p className="text-[10.5px] text-[#355875] text-center">
            {isLocalReview() ? 'The original BPZ template is retained. Do not enter real client information in this preview.' : 'Sessions stay active for 8 hours and renew automatically while you work. After 5 failed attempts, login is locked for 5 minutes.'}
          </p>
        </div>
      </div>
    </div>
  );
};

/** Revokes the server session, clears every local copy, and tells other tabs. */
export const clearSession = () => {
  apiFetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
  clearSessionStore();
  broadcastSessionChange(false);
};
