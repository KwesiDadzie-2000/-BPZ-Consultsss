import { isLocalReview } from '../preview/config';
import React, { useState } from 'react';
import { ClientEntity, PurchaseOrder, BusinessPartner, AccountMaster, StockItem, UserAccount } from '../types/accounting';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls, StatusBadge } from './ui';
import { ModulePrintButton } from './ModulePrintButton';
import { ModulePrintFooter } from './trade/TradeShared';
import { Plus } from 'lucide-react';
import { taxConfigStore } from '../utils/taxConfig';
import { computePoVat, type VatTreatment } from '../utils/transactionMath';
import { currentYear, nextDocNo, uniqueId } from '../utils/ids';
import { P2PDesk } from './trade/P2PDesk';

const VAT_TREATMENT_LABELS: Record<VatTreatment, string> = {
  standard: 'Standard — quotation exclusive of VAT (input VAT added)',
  inclusive: 'VAT-inclusive quotation (input VAT split out of the price)',
  none: 'No VAT — vendor not VAT-registered / bill not VAT-inclusive',
  zero_rated: 'Zero-rated supply (0% VAT)',
};

interface ProcurementSectionProps {
  currentClient: ClientEntity;
  purchaseOrders: PurchaseOrder[];
  partners?: BusinessPartner[];
  accounts?: AccountMaster[];
  /** Perpetual stock items available to receive goods against. */
  stockItems?: StockItem[];
  onAddPO: (po: PurchaseOrder) => void;
  onPostPOToJournal: (po: PurchaseOrder) => void;
  onIssueDebitNote?: (po: PurchaseOrder) => boolean;
  /** Signed-in user — drives maker/checker actions on the P2P lifecycle. */
  currentUser?: UserAccount;
  /** Re-pull the server workspace after a server-side P2P posting (ledger, stock, bank). */
  onServerMutation?: () => Promise<void>;
  onSessionLost?: () => void;
  /** Cross-desk navigation — supplier payments are raised at the Payment Desk. */
  onNavigate?: (section: string) => void;
}

export const ProcurementSection: React.FC<ProcurementSectionProps> = ({
  currentClient,
  purchaseOrders,
  partners = [],
  accounts = [],
  stockItems = [],
  onAddPO,
  onPostPOToJournal,
  onIssueDebitNote,
  currentUser,
  onServerMutation,
  onSessionLost,
  onNavigate,
}) => {
  // The full procure-to-pay lifecycle is the primary desk; the single-step
  // "quick bill" (PO received and invoiced in one posting) remains for small
  // purchases that need no receipt/invoice matching.
  const [mode, setMode] = useState<'p2p' | 'quick'>(currentUser && !isLocalReview() ? 'p2p' : 'quick');
  const [showModal, setShowModal] = useState(false);
  const [vendorName, setVendorName] = useState('');
  const [itemType, setItemType] = useState<'material' | 'service'>('material');
  const [itemDescription, setItemDescription] = useState('');
  const [glAccount, setGlAccount] = useState('');
  const [glAccountName, setGlAccountName] = useState('');
  const [costCenter, setCostCenter] = useState('CC-OPS');
  const [costCenterName, setCostCenterName] = useState('Operations Center');
  const [qty, setQty] = useState(1);
  const [unitPrice, setUnitPrice] = useState(0);
  const [currency, setCurrency] = useState(currentClient.currency || 'GHS');
  const [quotationRef, setQuotationRef] = useState('');
  const [vatTreatment, setVatTreatment] = useState<VatTreatment>('standard');
  // Trading goods: the stock item received and the inward freight capitalised
  // into its cost when the goods receipt is posted (IAS 2.11).
  const [feedback, setFeedback] = useState<string | null>(null);
  const [stockItemCode, setStockItemCode] = useState('');
  const [inwardFreight, setInwardFreight] = useState(0);

  const vatRate = taxConfigStore.rate('VAT') + taxConfigStore.rate('NHIL') + taxConfigStore.rate('GETFUND');
  const poVat = computePoVat(qty, unitPrice, vatTreatment, vatRate);
  const netTotal = poVat.net;
  const vatRecoverable = poVat.vat;
  const grossTotal = poVat.gross;
  const ccySymbol = currency === 'USD' ? '$' : currency === 'GBP' ? '£' : currency === 'EUR' ? '€' : '₵';

  const handleCreatePO = (e: React.FormEvent) => {
    e.preventDefault();
    if (!vendorName || !itemDescription || !glAccount || !costCenter || qty <= 0 || unitPrice <= 0) {
      setFeedback('Complete every required field — description, GL account, cost centre, quantity and unit price.');
      return;
    }

    const newPO: PurchaseOrder = {
      id: uniqueId('PO'),
      poNo: nextDocNo(`PO-${currentYear()}`, purchaseOrders.map((p) => p.poNo)),
      vendorName,
      itemType,
      itemDescription,
      qty,
      unitPrice,
      vatRecoverable,
      totalAmount: grossTotal,
      status: 'Open',
      date: new Date().toISOString().split('T')[0],
      currency,
      vatTreatment,
      netAmount: netTotal,
      quotationRef: quotationRef.trim() || undefined,
      itemCode: itemType === 'material' && stockItemCode ? stockItemCode : undefined,
      inwardFreight: itemType === 'material' && stockItemCode && inwardFreight > 0 ? Math.round(inwardFreight * 100) / 100 : undefined,
      glAccount,
      glAccountName,
      costCenter,
      costCenterName,
    };

    setFeedback(`Purchase order ${newPO.poNo} created for ${newPO.vendorName}.`);
    onAddPO(newPO);
    setShowModal(false);
    setVendorName('');
    setItemType('material');
    setItemDescription('');
    setGlAccount('');
    setGlAccountName('');
    setCostCenter('CC-OPS');
    setCostCenterName('Operations Center');
    setQty(1);
    setUnitPrice(0);
    setCurrency(currentClient.currency || 'GHS');
    setQuotationRef('');
    setVatTreatment('standard');
    setStockItemCode('');
    setInwardFreight(0);
  };

  const modeTabs = (
    <div className="flex rounded-lg border border-sky-300 bg-white p-0.5 text-[11px] font-bold">
      <button onClick={() => setMode('p2p')} disabled={!currentUser} className={`rounded-md px-3 py-1.5 ${mode === 'p2p' ? 'bg-[#082f4f] text-white' : 'text-[#082f4f] hover:bg-sky-50'} disabled:opacity-50`}>P2P lifecycle</button>
      <button onClick={() => setMode('quick')} className={`rounded-md px-3 py-1.5 ${mode === 'quick' ? 'bg-[#082f4f] text-white' : 'text-[#082f4f] hover:bg-sky-50'}`}>Quick bills (single-step)</button>
    </div>
  );

  if (mode === 'p2p' && currentUser) {
    return (
      <div className="space-y-6">
        <PageHeader
          kicker={`MM · Procurement & Procure-to-Pay · ${currentClient.code}`}
          title="Procurement desk"
          desc="Requisition → purchase order → goods receipt → supplier invoice (three-way match) → payment. Receipts update perpetual stock and GRNI; invoices clear GRNI into trade payables; payments settle open items with withholding tax."
        >
          <div className="flex flex-wrap items-center gap-2">
            <ModulePrintButton title={`Procurement & procure-to-pay — ${currentClient.name}`} subtitle="Purchase orders, receipts, invoices and settlements" />
            {modeTabs}
          </div>
        </PageHeader>
        <P2PDesk
          key={currentClient.id}
          currentClient={currentClient}
          currentUser={currentUser}
          partners={partners}
          accounts={accounts}
          stockItems={stockItems}
          defaultTaxRate={vatRate}
          onServerMutation={onServerMutation || (async () => undefined)}
          onSessionLost={onSessionLost || (() => undefined)}
          onNavigate={onNavigate}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`MM · Procurement · Quick bills · ${currentClient.code}`}
        title="Quick purchase bills"
        desc="Single-step purchases: the order is received and invoiced in one posting (Dr inventory / expense + input VAT, Cr trade payables). Use the P2P lifecycle for receipt and invoice matching."
      >
        <div className="flex flex-wrap items-center gap-2">
          {modeTabs}
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
          >
            <Plus className="h-4 w-4" />
            <span>New Purchase Order</span>
          </button>
        </div>
      </PageHeader>

      {feedback && (
        <div className={`flex items-start justify-between gap-3 rounded border p-3 text-xs font-bold ${feedback.startsWith('Debit note was rejected') || feedback.startsWith('Complete every required field') ? 'border-rose-300 bg-rose-50 text-rose-900' : 'border-emerald-300 bg-emerald-50 text-emerald-900'}`}>
          <span>{feedback}</span>
          <button type="button" onClick={() => setFeedback(null)} className="shrink-0 rounded border border-current px-2 py-0.5 text-[10px] uppercase">Dismiss</button>
        </div>
      )}

      <div className="grid gap-4 xl:grid-cols-3">
        <Card title="Input VAT Rule" sub="Ghana VAT Act 2013 & Standard Model">
          <p className="text-xs text-[#2d4f6d] leading-relaxed">
            All registered supplier invoices carry configured input tax credited directly to asset account <strong className="text-[#082f4f]">125000 (VAT Input Recoverable)</strong> with full credit claimed against output VAT.
          </p>
        </Card>
        <Card title="Inventory Flow" sub="Automated Account Selection">
          <p className="text-xs text-[#2d4f6d] leading-relaxed">
            Goods receipts credit GR/IR Clearing and debit <strong className="text-[#082f4f]">120000 (Raw Material / Spares)</strong> at standard moving average cost.
          </p>
        </Card>
        <Card title="Withholding Tax" sub="Settlement Linkage">
          <p className="text-xs text-[#2d4f6d] leading-relaxed">
            Supplier payments made at the Payment Desk calculate statutory resident WHT (goods 7.5%, services 5%) to credit account 209000.
          </p>
        </Card>
      </div>

      <div id="procurement-quick-orders" className="space-y-2">
      <Card title="Purchase Orders & Supplier Invoices" sub="Track commitments, receipt status, and ledger postings">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>PO Number</th>
                <th className={thCls}>Date</th>
                <th className={thCls}>Vendor</th>
                <th className={thCls}>Type</th>
                <th className={thCls}>CCY</th>
                <th className={thCls}>Description</th>
                <th className={thCls + ' text-right'}>GL Account</th>
                <th className={thCls + ' text-right'}>Cost Center</th>
                <th className={thCls + ' text-right'}>Qty</th>
                <th className={thCls + ' text-right'}>Net (₵)</th>
                <th className={thCls + ' text-right'}>Input Tax (₵)</th>
                <th className={thCls + ' text-right'}>Gross (₵)</th>
                <th className={thCls}>Status</th>
                <th className={thCls + ' text-center'}>Action</th>
              </tr>
            </thead>
            <tbody>
              {purchaseOrders.map((po) => (
                <tr key={po.id} className={rowCls}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{po.poNo}</td>
                  <td className="px-3 py-2 font-mono text-[#2d4f6d]">{po.date}</td>
                  <td className="px-3 py-2 font-bold text-[#082f4f]">{po.vendorName}</td>
                  <td className="px-3 py-2 text-[#2d4f6d]">
                    <span className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                      po.itemType === 'material' ? 'bg-emerald-100 text-emerald-800' : 'bg-sky-100 text-sky-800'
                    }`}>{po.itemType}</span>
                  </td>
                  <td className="px-3 py-2 font-mono font-bold text-[#006f98]">{po.currency || currentClient.currency}</td>
                  <td className="px-3 py-2 text-[#2d4f6d]">{po.itemDescription}</td>
                  <td className={numCls}>{po.glAccount}</td>
                  <td className={numCls}>{po.costCenter}</td>
                  <td className={numCls}>{po.qty}</td>
                  <td className={numCls}>{formatGHS(po.netAmount ?? po.qty * po.unitPrice)}</td>
                  <td className={numCls + ' text-emerald-700'}>{formatGHS(po.vatRecoverable)}</td>
                  <td className={numCls + ' font-bold text-[#082f4f]'}>{formatGHS(po.totalAmount)}</td>
                  <td className="px-3 py-2"><StatusBadge status={po.status} /></td>
                  <td className="px-3 py-2 text-center">
                    <div className="flex gap-1 justify-center">
                      {po.status === 'Open' ? (
                        <button
                          onClick={() => onPostPOToJournal(po)}
                          className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68]"
                        >
                          Receive & Post
                        </button>
                      ) : (
                        <span className="text-[11px] text-emerald-700 font-semibold">Posted to ACDOCA</span>
                      )}
                      {(po.status === 'Open' || po.status === 'Goods Received' || po.status === 'Invoiced') && onIssueDebitNote && (
                        <button
                          onClick={() => { if (!onIssueDebitNote(po)) setFeedback('Debit note was rejected. Paid or already-debited orders cannot be returned.'); }}
                          className="rounded border border-amber-400 bg-amber-50 px-2 py-1 text-[11px] font-bold text-[#855b00] hover:bg-amber-100"
                        >
                          Debit note
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      <ModulePrintFooter targetId="procurement-quick-orders" title={`Purchase orders & supplier invoices — ${currentClient.name}`} subtitle={`${currentClient.code} · printed ${new Date().toISOString().slice(0, 10)}`} />
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleCreatePO} className="w-full max-w-lg rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Create Purchase Order</h3>
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Vendor / Supplier</label>
                  {partners.filter((p) => p.type === 'Vendor').length > 0 ? (
                    <select
                      value={vendorName}
                      onChange={(e) => {
                        setVendorName(e.target.value);
                        // Default the VAT treatment from the vendor master record.
                        const p = partners.find((x) => x.name === e.target.value);
                        if (p?.isVatRegistered === false) setVatTreatment('none');
                        else if (p?.isVatRegistered === true) setVatTreatment('standard');
                      }}
                      className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]"
                      required
                    >
                      <option value="">Select supplier</option>
                      {partners.filter((p) => p.type === 'Vendor').map((v) => (
                        <option key={v.id} value={v.name}>{v.code} · {v.name}</option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type="text"
                      value={vendorName}
                      onChange={(e) => setVendorName(e.target.value)}
                      className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]"
                      required
                    />
                  )}
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Item Type</label>
                  <select
                    value={itemType}
                    onChange={(e) => setItemType(e.target.value as 'material' | 'service')}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]"
                    required
                  >
                    <option value="material">Material</option>
                    <option value="service">Service</option>
                  </select>
                </div>
              </div>
              {itemType === 'material' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 rounded border border-emerald-200 bg-emerald-50/60 p-3">
                  <div>
                    <label className="block font-bold text-[#0a253e] mb-1">Stock item received (perpetual inventory)</label>
                    <select
                      value={stockItemCode}
                      onChange={(e) => setStockItemCode(e.target.value)}
                      className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]"
                    >
                      <option value="">Not stocked — charge the selected GL account</option>
                      {stockItems.map((i) => (
                        <option key={i.id} value={i.itemCode}>{i.itemCode} · {i.description} ({i.quantityOnHand} {i.uom} on hand)</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-[#0a253e] mb-1">Inward freight to capitalise ({ccySymbol})</label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={inwardFreight || ''}
                      onChange={(e) => setInwardFreight(Number(e.target.value))}
                      disabled={!stockItemCode}
                      className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono text-[#082f4f] disabled:bg-slate-100"
                    />
                  </div>
                  <p className="sm:col-span-2 text-[10.5px] text-[#2d4f6d]">
                    A purchase order alone posts nothing. On goods receipt the inventory control account is debited with the purchase cost, and any inward freight is capitalised into the item&rsquo;s unit cost — so cost of sales later releases the full landed cost.
                  </p>
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Quotation / Tender Reference</label>
                  <input
                    type="text"
                    value={quotationRef}
                    onChange={(e) => setQuotationRef(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono text-[#082f4f]"
                    placeholder="e.g. QT-2026-0141 (competitive tender)"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Vendor VAT Treatment</label>
                  <select
                    value={vatTreatment}
                    onChange={(e) => setVatTreatment(e.target.value as VatTreatment)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]"
                    required
                  >
                    {(Object.keys(VAT_TREATMENT_LABELS) as VatTreatment[]).map((t) => (
                      <option key={t} value={t}>{VAT_TREATMENT_LABELS[t]}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Item Description</label>
                <input
                  type="text"
                  value={itemDescription}
                  onChange={(e) => setItemDescription(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-2 outline-none"
                  required
                  placeholder="e.g., Drill Bits & Consumable Rods"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">GL Account Code</label>
                  <select
                    value={glAccount}
                    onChange={(e) => {
                      setGlAccount(e.target.value);
                      const acc = accounts.find(a => a.accountNo === e.target.value);
                      if (acc) setGlAccountName(acc.name);
                    }}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]"
                    required
                  >
                    <option value="">Select GL Account</option>
                    {accounts.map((a) => (
                      <option key={a.accountNo} value={a.accountNo}>
                        {a.accountNo} · {a.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">GL Account Name</label>
                  <input
                    type="text"
                    value={glAccountName}
                    onChange={(e) => setGlAccountName(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none"
                    required
                    readOnly
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Cost Center Code</label>
                  <input
                    type="text"
                    value={costCenter}
                    onChange={(e) => setCostCenter(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono font-bold text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Cost Center Name</label>
                  <input
                    type="text"
                    value={costCenterName}
                    onChange={(e) => setCostCenterName(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none"
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Quantity</label>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={qty}
                    onChange={(e) => setQty(Number(e.target.value))}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono font-bold text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Unit Price</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={unitPrice}
                    onChange={(e) => setUnitPrice(Number(e.target.value))}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono font-bold text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Currency</label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full rounded border border-sky-300 px-2 py-2 outline-none font-bold text-[#082f4f]"
                    required
                  >
                    <option value="GHS">GHS (Ghana Cedi)</option>
                    <option value="USD">USD (US Dollar)</option>
                    <option value="GBP">GBP (British Pound)</option>
                    <option value="EUR">EUR (Euro)</option>
                  </select>
                </div>
              </div>
              <div className="rounded-lg bg-sky-50 border border-sky-200 p-3 space-y-1 text-xs">
                <div className="flex justify-between"><span>Net Total:</span><span className="font-mono font-bold">{ccySymbol}{formatGHS(netTotal)}</span></div>
                <div className="flex justify-between text-emerald-700"><span>Recoverable input VAT ({vatRate}%):</span><span className="font-mono font-bold">{ccySymbol}{formatGHS(vatRecoverable)}</span></div>
                <div className="flex justify-between border-t border-sky-200 pt-1 font-bold text-[#082f4f]"><span>Gross Payable:</span><span className="font-mono">{ccySymbol}{formatGHS(grossTotal)}</span></div>
                <div className="text-[10.5px] text-[#355875] pt-0.5">VAT treatment: {VAT_TREATMENT_LABELS[vatTreatment]}</div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setShowModal(false)} className="rounded px-3 py-1.5 text-xs font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 text-xs font-bold text-white">Create PO</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
