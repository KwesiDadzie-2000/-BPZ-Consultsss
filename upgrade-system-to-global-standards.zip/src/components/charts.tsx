/**
 * Lightweight, dependency-free SVG chart kit in the BPZ palette.
 * Every chart exposes role="img" with a textual summary for screen readers.
 */
export const PALETTE = {
  navy: '#082f4f',
  gold: '#f5b719',
  sky: '#0284c7',
  teal: '#0d9488',
  green: '#059669',
  red: '#e11d48',
  amber: '#d97706',
  violet: '#7c3aed',
  slate: '#64748b',
};
export const SERIES_COLORS = [PALETTE.navy, PALETTE.gold, PALETTE.sky, PALETTE.green, PALETTE.red, PALETTE.violet, PALETTE.teal, PALETTE.amber];

export const compact = (n: number) =>
  Number.isFinite(n) ? new Intl.NumberFormat('en-GB', { notation: 'compact', maximumFractionDigits: 1 }).format(n) : '—';

export interface ChartSeries {
  name: string;
  values: number[];
  color?: string;
  type?: 'bar' | 'line';
  dashed?: boolean;
}

function niceScale(min: number, max: number, ticks = 5) {
  if (min === max) {
    const pad = Math.abs(max) || 1;
    min -= pad;
    max += pad;
  }
  const span = max - min;
  const step0 = span / ticks;
  const mag = Math.pow(10, Math.floor(Math.log10(step0)));
  const norm = step0 / mag;
  const step = (norm >= 5 ? 10 : norm >= 2 ? 5 : norm >= 1 ? 2 : 1) * mag;
  const lo = Math.floor(min / step) * step;
  const hi = Math.ceil(max / step) * step;
  const out: number[] = [];
  for (let v = lo; v <= hi + step / 2; v += step) out.push(Math.round(v * 1e6) / 1e6);
  return { lo, hi, ticks: out };
}

export function ComboChart({
  labels,
  series,
  height = 240,
  format = compact,
  title,
}: {
  labels: string[];
  series: ChartSeries[];
  height?: number;
  format?: (n: number) => string;
  title: string;
}) {
  const W = 720;
  const H = height;
  const m = { t: 16, r: 12, b: 34, l: 56 };
  const all = series.flatMap((s) => s.values.filter((v) => Number.isFinite(v)));
  const { lo, hi, ticks } = niceScale(Math.min(0, ...(all.length ? all : [0])), Math.max(0, ...(all.length ? all : [1])));
  const iw = W - m.l - m.r;
  const ih = H - m.t - m.b;
  const n = Math.max(1, labels.length);
  const x = (i: number) => m.l + (iw * (i + 0.5)) / n;
  const y = (v: number) => m.t + ih - ((v - lo) / (hi - lo || 1)) * ih;
  const bars = series.filter((s) => (s.type ?? 'bar') === 'bar');
  const lines = series.filter((s) => s.type === 'line');
  const slot = iw / n;
  const bw = Math.max(2, Math.min(28, (slot * 0.75) / Math.max(1, bars.length)));
  const every = Math.ceil(n / 12);
  const summary = `${title}. ${series.map((s) => `${s.name}: latest ${format(s.values[s.values.length - 1] ?? 0)}`).join('; ')}.`;
  return (
    <figure className="w-full">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto" role="img" aria-label={summary}>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={m.l} x2={W - m.r} y1={y(t)} y2={y(t)} stroke={t === 0 ? '#94a3b8' : '#e2eef9'} strokeWidth={t === 0 ? 1.2 : 1} />
            <text x={m.l - 6} y={y(t) + 3} textAnchor="end" fontSize="10" fill="#355875">{format(t)}</text>
          </g>
        ))}
        {labels.map((l, i) => (i % every === 0 ? <text key={`${l}-${i}`} x={x(i)} y={H - 14} textAnchor="middle" fontSize="10" fill="#355875">{l}</text> : null))}
        {bars.map((s, si) =>
          s.values.map((v, i) => {
            if (!Number.isFinite(v)) return null;
            const bx = x(i) - (bw * bars.length) / 2 + si * bw;
            const top = Math.min(y(v), y(0));
            return (
              <rect key={`${s.name}-${i}`} x={bx} y={top} width={bw - 1} height={Math.max(1, Math.abs(y(v) - y(0)))} fill={s.color ?? SERIES_COLORS[si % SERIES_COLORS.length]} rx={1.5}>
                <title>{`${s.name} · ${labels[i]}: ${format(v)}`}</title>
              </rect>
            );
          }),
        )}
        {lines.map((s, si) => {
          const pts = s.values.map((v, i) => (Number.isFinite(v) ? `${x(i)},${y(v)}` : null)).filter(Boolean).join(' ');
          const color = s.color ?? SERIES_COLORS[(si + bars.length) % SERIES_COLORS.length];
          return (
            <g key={s.name}>
              <polyline points={pts} fill="none" stroke={color} strokeWidth={2.2} strokeDasharray={s.dashed ? '6 4' : undefined} />
              {s.values.map((v, i) => (Number.isFinite(v) ? <circle key={i} cx={x(i)} cy={y(v)} r={2.6} fill={color}><title>{`${s.name} · ${labels[i]}: ${format(v)}`}</title></circle> : null))}
            </g>
          );
        })}
      </svg>
      <figcaption className="mt-1 flex flex-wrap gap-3 text-[11px] text-[#2d4f6d]">
        {series.map((s, i) => (
          <span key={s.name} className="inline-flex items-center gap-1.5">
            <span className="inline-block h-2.5 w-2.5 rounded-sm" style={{ background: s.color ?? SERIES_COLORS[i % SERIES_COLORS.length] }} />
            {s.name}
          </span>
        ))}
      </figcaption>
    </figure>
  );
}

export function DonutChart({ data, title, format = compact }: { data: { label: string; value: number; color?: string }[]; title: string; format?: (n: number) => string }) {
  const total = data.reduce((s, d) => s + Math.max(0, d.value), 0);
  const R = 70;
  const C = 2 * Math.PI * R;
  let offset = 0;
  return (
    <figure className="flex flex-wrap items-center gap-4">
      <svg viewBox="0 0 180 180" className="h-40 w-40 shrink-0" role="img" aria-label={`${title}. ${data.map((d) => `${d.label} ${total ? ((d.value / total) * 100).toFixed(1) : 0}%`).join(', ')}`}>
        <circle cx="90" cy="90" r={R} fill="none" stroke="#e2eef9" strokeWidth="22" />
        {total > 0 &&
          data.map((d, i) => {
            const len = (Math.max(0, d.value) / total) * C;
            const el = (
              <circle key={d.label} cx="90" cy="90" r={R} fill="none" stroke={d.color ?? SERIES_COLORS[i % SERIES_COLORS.length]} strokeWidth="22" strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-offset} transform="rotate(-90 90 90)">
                <title>{`${d.label}: ${format(d.value)}`}</title>
              </circle>
            );
            offset += len;
            return el;
          })}
        <text x="90" y="86" textAnchor="middle" fontSize="11" fill="#355875">Total</text>
        <text x="90" y="104" textAnchor="middle" fontSize="15" fontWeight="800" fill="#082f4f">{format(total)}</text>
      </svg>
      <figcaption className="min-w-0 flex-1 space-y-1 text-xs">
        {data.map((d, i) => (
          <div key={d.label} className="flex items-center justify-between gap-2">
            <span className="flex min-w-0 items-center gap-1.5 truncate"><span className="inline-block h-2.5 w-2.5 shrink-0 rounded-sm" style={{ background: d.color ?? SERIES_COLORS[i % SERIES_COLORS.length] }} />{d.label}</span>
            <span className="font-mono tabular-nums text-[#0a253e]">{total ? ((d.value / total) * 100).toFixed(1) : '0.0'}%</span>
          </div>
        ))}
      </figcaption>
    </figure>
  );
}

export function HBarChart({ rows, format = compact, title }: { rows: { label: string; value: number; color?: string; note?: string }[]; format?: (n: number) => string; title: string }) {
  const max = Math.max(1, ...rows.map((r) => Math.abs(r.value)));
  return (
    <div role="img" aria-label={`${title}. ${rows.slice(0, 6).map((r) => `${r.label} ${format(r.value)}`).join(', ')}`} className="space-y-1.5">
      {rows.map((r, i) => (
        <div key={`${r.label}-${i}`} className="grid grid-cols-[minmax(0,10rem)_1fr_auto] items-center gap-2 text-xs">
          <span className="truncate text-[#0a253e]" title={r.label}>{r.label}</span>
          <span className="h-3 rounded bg-sky-50">
            <span className="block h-3 rounded" style={{ width: `${(Math.abs(r.value) / max) * 100}%`, background: r.color ?? (r.value < 0 ? PALETTE.red : PALETTE.navy) }} />
          </span>
          <span className="font-mono tabular-nums text-[#0a253e]">{format(r.value)}{r.note ? <span className="ml-1 text-[10px] text-[#355875]">{r.note}</span> : null}</span>
        </div>
      ))}
    </div>
  );
}

export function TornadoChart({ rows, base, format = compact, title }: { rows: { label: string; low: number; high: number }[]; base: number; format?: (n: number) => string; title: string }) {
  const span = Math.max(1, ...rows.flatMap((r) => [Math.abs(r.low - base), Math.abs(r.high - base)]));
  return (
    <div role="img" aria-label={`${title}. Base ${format(base)}. ${rows.map((r) => `${r.label}: ${format(r.low)} to ${format(r.high)}`).join('; ')}`} className="space-y-1.5">
      {rows.map((r) => {
        const lo = ((Math.min(r.low, r.high) - base) / span) * 50;
        const hi = ((Math.max(r.low, r.high) - base) / span) * 50;
        return (
          <div key={r.label} className="grid grid-cols-[minmax(0,9rem)_1fr] items-center gap-2 text-xs">
            <span className="truncate text-[#0a253e]" title={r.label}>{r.label}</span>
            <div className="relative h-4 rounded bg-sky-50">
              <span className="absolute top-0 h-4 w-px bg-slate-400" style={{ left: '50%' }} />
              <span className="absolute top-0.5 h-3 rounded-l" style={{ left: `${50 + Math.min(0, lo)}%`, width: `${Math.max(0, Math.min(0, hi) - Math.min(0, lo)) || Math.abs(Math.min(0, lo))}%`, background: PALETTE.red }} title={`Downside ${format(Math.min(r.low, r.high))}`} />
              <span className="absolute top-0.5 h-3 rounded-r" style={{ left: '50%', width: `${Math.max(0, hi)}%`, background: PALETTE.green }} title={`Upside ${format(Math.max(r.low, r.high))}`} />
            </div>
          </div>
        );
      })}
      <div className="text-center text-[10px] text-[#355875]">Base case {format(base)} — red: downside, green: upside</div>
    </div>
  );
}

export function WaterfallChart({ steps, format = compact, title }: { steps: { label: string; value: number; total?: boolean }[]; format?: (n: number) => string; title: string }) {
  const W = 720;
  const H = 230;
  const m = { t: 14, r: 10, b: 40, l: 56 };
  let run = 0;
  const bars = steps.map((s) => {
    const start = s.total ? 0 : run;
    const end = s.total ? s.value : run + s.value;
    run = s.total ? s.value : end;
    return { ...s, start, end };
  });
  const vals = bars.flatMap((b) => [b.start, b.end]);
  const { lo, hi, ticks } = niceScale(Math.min(0, ...vals), Math.max(0, ...vals));
  const iw = W - m.l - m.r;
  const ih = H - m.t - m.b;
  const slot = iw / Math.max(1, bars.length);
  const y = (v: number) => m.t + ih - ((v - lo) / (hi - lo || 1)) * ih;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto" role="img" aria-label={`${title}. ${steps.map((s) => `${s.label} ${format(s.value)}`).join(', ')}`}>
      {ticks.map((t) => (
        <g key={t}>
          <line x1={m.l} x2={W - m.r} y1={y(t)} y2={y(t)} stroke={t === 0 ? '#94a3b8' : '#e2eef9'} />
          <text x={m.l - 6} y={y(t) + 3} textAnchor="end" fontSize="10" fill="#355875">{format(t)}</text>
        </g>
      ))}
      {bars.map((b, i) => (
        <g key={`${b.label}-${i}`}>
          <rect x={m.l + i * slot + slot * 0.15} width={slot * 0.7} y={Math.min(y(b.start), y(b.end))} height={Math.max(1, Math.abs(y(b.start) - y(b.end)))} fill={b.total ? PALETTE.navy : b.value >= 0 ? PALETTE.green : PALETTE.red} rx={2}>
            <title>{`${b.label}: ${format(b.value)}`}</title>
          </rect>
          <text x={m.l + i * slot + slot / 2} y={H - 24} textAnchor="middle" fontSize="9.5" fill="#355875">{b.label.length > 14 ? `${b.label.slice(0, 13)}…` : b.label}</text>
          <text x={m.l + i * slot + slot / 2} y={H - 10} textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#0a253e">{format(b.value)}</text>
        </g>
      ))}
    </svg>
  );
}

export function Sparkline({ values, color = PALETTE.navy, label }: { values: number[]; color?: string; label: string }) {
  const W = 120;
  const H = 30;
  const finite = values.filter((v) => Number.isFinite(v));
  if (finite.length < 2) return <span className="text-[10px] text-[#355875]">—</span>;
  const min = Math.min(...finite);
  const max = Math.max(...finite);
  const pts = values.map((v, i) => `${(i / (values.length - 1)) * W},${H - 2 - ((v - min) / (max - min || 1)) * (H - 4)}`).join(' ');
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-7 w-28" role="img" aria-label={`${label} trend`}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.8" />
    </svg>
  );
}
