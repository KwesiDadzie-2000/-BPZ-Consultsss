/**
 * Idempotent DDL for the review extensions (performance management, IFRS
 * schedule workbooks and first-run activation). Mirrors the Drizzle
 * definitions in `src/db/schema.ts` (`entityWorkbooks`, `systemSettings`) so a
 * fresh database self-provisions exactly like the original tables do.
 */
export const EXTENSIONS_DDL: string[] = [
  `CREATE TABLE IF NOT EXISTS "entity_workbooks" (
    "id" text PRIMARY KEY NOT NULL,
    "client_id" integer NOT NULL,
    "kind" text NOT NULL,
    "key" text NOT NULL,
    "title" text DEFAULT '' NOT NULL,
    "payload" jsonb NOT NULL,
    "status" text DEFAULT 'draft' NOT NULL,
    "version" integer DEFAULT 1 NOT NULL,
    "prepared_by" text,
    "submitted_by" text,
    "approved_by" text,
    "approved_at" text,
    "review_comment" text,
    "created_at" timestamp with time zone DEFAULT now() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT now() NOT NULL
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "entity_workbooks_scope_idx" ON "entity_workbooks" USING btree ("client_id","kind","key")`,
  `CREATE TABLE IF NOT EXISTS "system_settings" (
    "key" text PRIMARY KEY NOT NULL,
    "value" jsonb NOT NULL,
    "updated_at" timestamp with time zone DEFAULT now() NOT NULL
  )`,
];
