import {
  pgTable,
  text,
  integer,
  bigint,
  boolean,
  doublePrecision,
  jsonb,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

/**
 * BPZ Consult ERP — production schema.
 * Money is stored as double-precision and validated in minor units (cents) at the
 * API boundary; every table is tenant-scoped by clientId where applicable.
 */

export const users = pgTable("users", {
  id: text("id").primaryKey(),
  username: text("username").notNull(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(), // owner | partner | manager | accountant | auditor
  makerLimit: doublePrecision("maker_limit").notNull().default(0),
  canCheck: boolean("can_check").notNull().default(false),
  clientId: integer("client_id"),
  passwordHash: text("password_hash"),
  passwordSalt: text("password_salt"),
  status: text("status").notNull().default("active"),
  restrictionReason: text("restriction_reason"),
  permissions: jsonb("permissions"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("users_username_idx").on(t.username),
  uniqueIndex("users_email_idx").on(t.email),
]);

/**
 * Session store.
 *
 * The table is named `bpz_sessions` (not the generic `sessions`) on purpose:
 * databases that were provisioned by an earlier build of this project — or by
 * any other app sharing the database — may already contain a `sessions` table
 * with an incompatible shape (`id`/`user_id integer`/`expires_at timestamp`).
 * `CREATE TABLE IF NOT EXISTS` would then silently keep that shape, every
 * session insert/lookup would fail, and signed-in users were bounced straight
 * back to the login portal. A dedicated name guarantees the shape below.
 * `lastSeenAt` powers the "active sessions" owner view and session sliding.
 */
export const sessions = pgTable("bpz_sessions", {
  token: text("token").primaryKey(),
  userId: text("user_id").notNull(),
  expiresAt: bigint("expires_at", { mode: "number" }).notNull(),
  lastSeenAt: bigint("last_seen_at", { mode: "number" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("bpz_sessions_user_idx").on(t.userId),
]);

export const clients = pgTable("clients", {
  id: integer("id").primaryKey(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  sector: text("sector").notNull(),
  currency: text("currency").notNull(),
  jurisdiction: text("jurisdiction").notNull(),
  regNumber: text("reg_number").notNull(),
  isParent: boolean("is_parent").notNull().default(false),
  assignedServices: jsonb("assigned_services"),
  adminUsername: text("admin_username"),
  adminEmail: text("admin_email"),
  loginUrl: text("login_url"),
});

export const journalLines = pgTable("journal_lines", {
  id: text("id").primaryKey(),
  docNo: text("doc_no").notNull(),
  period: text("period").notNull(),
  date: text("date").notNull(),
  module: text("module").notNull(),
  docType: text("doc_type").notNull(),
  accountNo: text("account_no").notNull(),
  accountName: text("account_name").notNull(),
  costCenter: text("cost_center"),
  debit: doublePrecision("debit").notNull().default(0),
  credit: doublePrecision("credit").notNull().default(0),
  currency: text("currency").notNull(),
  description: text("description").notNull(),
  createdBy: text("created_by").notNull(),
  checkedBy: text("checked_by"),
  isReversed: boolean("is_reversed").notNull().default(false),
  reference: text("reference"),
  clientId: integer("client_id").notNull(),
});

/** Document-level control record; totals and content hash reconcile to its lines. */
export const journalHeaders = pgTable("journal_headers", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  docNo: text("doc_no").notNull(),
  period: text("period").notNull(),
  date: text("date").notNull(),
  module: text("module").notNull(),
  docType: text("doc_type").notNull(),
  currency: text("currency").notNull(),
  description: text("description").notNull(),
  debitTotal: doublePrecision("debit_total").notNull(),
  creditTotal: doublePrecision("credit_total").notNull(),
  lineCount: integer("line_count").notNull(),
  createdBy: text("created_by").notNull(),
  checkedBy: text("checked_by"),
  reference: text("reference"),
  contentHash: text("content_hash").notNull(),
  postedAt: timestamp("posted_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("journal_headers_client_doc_idx").on(t.clientId, t.docNo)]);

/** Immutable idempotency receipt for each tenant-scoped posting request. */
export const postingEvents = pgTable("posting_events", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  idempotencyKey: text("idempotency_key").notNull(),
  requestHash: text("request_hash").notNull(),
  response: jsonb("response").notNull(),
  actor: text("actor").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("posting_events_client_key_idx").on(t.clientId, t.idempotencyKey)]);

export const bankAccounts = pgTable("bank_accounts", {
  id: integer("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  bankName: text("bank_name").notNull(),
  accountNo: text("account_no").notNull(),
  currency: text("currency").notNull(),
  balance: doublePrecision("balance").notNull().default(0),
  kind: text("kind"), // 'bank' | 'cash'
  glAccount: text("gl_account"),
});

export const purchaseOrders = pgTable("purchase_orders", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  poNo: text("po_no").notNull(),
  vendorName: text("vendor_name").notNull(),
  itemType: text("item_type").notNull(),
  itemDescription: text("item_description").notNull(),
  qty: doublePrecision("qty").notNull(),
  unitPrice: doublePrecision("unit_price").notNull(),
  vatRecoverable: doublePrecision("vat_recoverable").notNull().default(0),
  totalAmount: doublePrecision("total_amount").notNull(),
  paidAmount: doublePrecision("paid_amount").notNull().default(0),
  status: text("status").notNull(),
  date: text("date").notNull(),
  currency: text("currency"),
  vatTreatment: text("vat_treatment"),
  netAmount: doublePrecision("net_amount"),
  quotationRef: text("quotation_ref"),
  glAccount: text("gl_account").notNull(),
  glAccountName: text("gl_account_name").notNull(),
  costCenter: text("cost_center").notNull(),
  costCenterName: text("cost_center_name").notNull(),
  // Trading purchases: the stock item received and the inward freight that is
  // capitalised into the inventory cost (IAS 2.11).
  itemCode: text("item_code"),
  inwardFreight: doublePrecision("inward_freight"),
});

export const salesInvoices = pgTable("sales_invoices", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  invNo: text("inv_no").notNull(),
  customerName: text("customer_name").notNull(),
  revenueStream: text("revenue_stream").notNull(),
  netRevenue: doublePrecision("net_revenue").notNull(),
  vatOutput: doublePrecision("vat_output").notNull().default(0),
  cstAmount: doublePrecision("cst_amount"),
  tourismLevyAmount: doublePrecision("tourism_levy_amount"),
  vatWithheldByCustomer: doublePrecision("vat_withheld_by_customer"),
  totalReceivable: doublePrecision("total_receivable").notNull(),
  paidAmount: doublePrecision("paid_amount").notNull().default(0),
  status: text("status").notNull(),
  date: text("date").notNull(),
  // Exact revenue account selected on the invoice (chart of accounts), plus the
  // trading-goods fields that drive the perpetual cost-of-sales posting.
  revenueAccount: text("revenue_account"),
  revenueAccountName: text("revenue_account_name"),
  itemType: text("item_type"),
  itemCode: text("item_code"),
  quantity: doublePrecision("quantity"),
  unitSellingPrice: doublePrecision("unit_selling_price"),
  unitCost: doublePrecision("unit_cost"),
  cogsAmount: doublePrecision("cogs_amount"),
});

export const employees = pgTable("employees", {
  id: integer("id").primaryKey(),
  clientId: integer("client_id"),
  bpNo: text("bp_no").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  department: text("department").notNull(),
  costCenter: text("cost_center"),
  jurisdiction: text("jurisdiction").notNull(),
  basicSalary: doublePrecision("basic_salary").notNull(),
  allowances: doublePrecision("allowances").notNull().default(0),
  ssnitNumber: text("ssnit_number").notNull(),
  tin: text("tin").notNull(),
  status: text("status").notNull(),
  isResident: boolean("is_resident").notNull().default(true),
  exemptTier1: boolean("exempt_tier1").notNull().default(false),
  exemptTier2: boolean("exempt_tier2").notNull().default(false),
  ssnitExempt: boolean("ssnit_exempt").notNull().default(false),
  ssnitExemptionReason: text("ssnit_exemption_reason"),
  taxRelief: doublePrecision("tax_relief").notNull().default(0),
  reliefType: text("relief_type"),
  deductions: jsonb("deductions"),
});

export const companyProfiles = pgTable("company_profiles", {
  clientId: integer("client_id").primaryKey(),
  legalName: text("legal_name").notNull(),
  tradingName: text("trading_name").notNull(),
  tin: text("tin").notNull(),
  vatRegNo: text("vat_reg_no").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  website: text("website").notNull(),
  fiscalYearStart: text("fiscal_year_start").notNull(),
  bankPaymentDetails: text("bank_payment_details").notNull(),
});

export const chartAccounts = pgTable("chart_accounts", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  accountNo: text("account_no").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  category: text("category").notNull(),
  active: boolean("active").notNull().default(true),
  isCustom: boolean("is_custom").notNull().default(false),
  clientId: integer("client_id"), // null = firm master chart shared by all entities
// Unique per owning entity — the firm master chart and a client's own
// custom accounts may legitimately share an account number.
}, (t) => [uniqueIndex("chart_accounts_scope_idx").on(t.accountNo, t.clientId)]);

export const businessPartners = pgTable("business_partners", {
  // `id` is an opaque globally unique storage key. `sourceId` preserves the
  // tenant-local id used by the browser and accounting modules.
  id: text("id").primaryKey(),
  clientId: integer("client_id"),
  sourceId: text("source_id").notNull(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  tin: text("tin").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  currency: text("currency").notNull(),
  isVatWithholdingAgent: boolean("is_vat_withholding_agent").notNull().default(false),
  vatWithholdingRate: doublePrecision("vat_withholding_rate"),
  isCstApplicable: boolean("is_cst_applicable").notNull().default(false),
  isTourismLevyApplicable: boolean("is_tourism_levy_applicable").notNull().default(false),
  isVatRegistered: boolean("is_vat_registered"),
}, (t) => [
  uniqueIndex("business_partners_scope_idx").on(sql`coalesce(${t.clientId}, 0)`, t.sourceId),
]);

export const payrollRecords = pgTable("payroll_records", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  record: jsonb("record").notNull(),
});

export const prepaymentRecords = pgTable("prepayment_records", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  record: jsonb("record").notNull(),
});

export const prepaymentSchedules = pgTable("prepayment_schedules", {
  id: text("id").primaryKey(),
  prepaymentId: text("prepayment_id").notNull(),
  clientId: integer("client_id").notNull(),
  line: jsonb("line").notNull(),
});

export const approvalRequests = pgTable("approval_requests", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  clientCode: text("client_code").notNull(),
  clientName: text("client_name").notNull(),
  docNo: text("doc_no").notNull(),
  docType: text("doc_type").notNull(),
  amount: doublePrecision("amount").notNull(),
  requestedBy: text("requested_by").notNull(),
  requestedAt: text("requested_at").notNull(),
  description: text("description").notNull(),
  reasonForApproval: text("reason_for_approval").notNull(),
    status: text("status").notNull(),
    reviewedBy: text("reviewed_by"),
    reviewedAt: text("reviewed_at"),
    rejectionReason: text("rejection_reason"),
    // Proposed journal lines awaiting sign-off; posted exactly once on approval.
    payload: jsonb("payload"),
  });

export const disclosureNotes = pgTable("disclosure_notes", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  key: text("key").notNull(),
  noteNumber: integer("note_number").notNull(),
  title: text("title").notNull(),
  standardRef: text("standard_ref").notNull(),
  applicable: boolean("applicable").notNull(),
  notApplicableReason: text("not_applicable_reason"),
  body: text("body").notNull(),
  tables: jsonb("tables"),
  editableOverride: boolean("editable_override"),
});

export const closedPeriods = pgTable("closed_periods", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  clientId: integer("client_id").notNull(),
  period: text("period").notNull(), // e.g. "2026-03"
  closedAt: text("closed_at").notNull(),
  closedBy: text("closed_by").notNull(),
}, (t) => [uniqueIndex("closed_periods_client_period_idx").on(t.clientId, t.period)]);

/**
 * Statutory schedule lines (withholding tax & VAT). Journal-derived rows live in
 * the ledger; this table stores only user EDITS of derived rows (source='ledger',
 * keyed by source_key) and manually ADDED rows (source='manual'). Tenant-scoped.
 */
export const taxScheduleEntries = pgTable("tax_schedule_entries", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  kind: text("kind").notNull(), // wht | wht_credit | vat_output | vat_input
  source: text("source").notNull(), // manual | ledger
  sourceKey: text("source_key"),
  period: text("period").notNull(),
  date: text("date").notNull(),
  docNo: text("doc_no").notNull(),
  partyName: text("party_name").notNull(),
  partyTin: text("party_tin").notNull().default(""),
  nature: text("nature").notNull().default(""),
  grossAmount: doublePrecision("gross_amount").notNull().default(0),
  rate: doublePrecision("rate").notNull().default(0),
  taxAmount: doublePrecision("tax_amount").notNull().default(0),
  levyAmount: doublePrecision("levy_amount").notNull().default(0),
  reference: text("reference").notNull().default(""),
  status: text("status").notNull().default(""),
  note: text("note"),
  createdBy: text("created_by").notNull(),
  updatedAt: text("updated_at").notNull(),
});

/**
 * Perpetual inventory subsystem — item master. Quantity and value are kept
 * together so the valuation report always reconciles to the inventory control
 * account (120000). `costMethod` is fixed per item (IAS 2 consistency).
 */
export const stockItems = pgTable("stock_items", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  itemCode: text("item_code").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  uom: text("uom").notNull(),
  quantityOnHand: doublePrecision("quantity_on_hand").notNull().default(0),
  unitCost: doublePrecision("unit_cost").notNull().default(0),
  totalValue: doublePrecision("total_value").notNull().default(0),
  reorderLevel: doublePrecision("reorder_level"),
  location: text("location"),
  glAccount: text("gl_account"),
  costMethod: text("cost_method"), // weighted_average | fifo | specific
  netRealisableValue: doublePrecision("net_realisable_value"),
}, (t) => [uniqueIndex("stock_items_scope_idx").on(t.clientId, t.itemCode)]);

/** Every receipt, issue, freight capitalisation, return, write-down and count adjustment. */
export const stockMovements = pgTable("stock_movements", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  date: text("date").notNull(),
  itemCode: text("item_code").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(),
  quantity: doublePrecision("quantity").notNull().default(0),
  unitCost: doublePrecision("unit_cost").notNull().default(0),
  totalValue: doublePrecision("total_value").notNull().default(0),
  uom: text("uom").notNull(),
  reference: text("reference"),
  docNo: text("doc_no"),
  note: text("note"),
});

/**
 * Fixed asset register (IAS 16) with the tax base needed for capital allowances
 * and IAS 12 deferred tax. Previously browser-only; now part of the client books.
 */
export const fixedAssets = pgTable("fixed_assets", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  assetTag: text("asset_tag").notNull(),
  name: text("name").notNull(),
  classCode: text("class_code").notNull(),
  cost: doublePrecision("cost").notNull().default(0),
  accumDep: doublePrecision("accum_dep").notNull().default(0),
  usefulLife: text("useful_life").notNull(),
  depreciationRate: doublePrecision("depreciation_rate"),
  depreciationMethod: text("depreciation_method"),
  capitalAllowanceClass: text("capital_allowance_class"),
  capitalAllowanceRate: doublePrecision("capital_allowance_rate"),
  accumCapitalAllowance: doublePrecision("accum_capital_allowance").notNull().default(0),
  location: text("location").notNull().default(""),
  acquired: text("acquired"),
  disposedDate: text("disposed_date"),
  disposalProceeds: doublePrecision("disposal_proceeds"),
});

export const auditLog = pgTable("audit_log", {
  id: text("id").primaryKey(),
  timestamp: text("timestamp").notNull(),
  userId: text("user_id").notNull(),
  username: text("username").notNull(),
  action: text("action").notNull(),
  target: text("target").notNull(),
  details: text("details").notNull(),
  clientId: integer("client_id"),
});

/**
 * Entity workbooks — server-authoritative, versioned planning and IFRS schedule
 * documents (budgets, rolling forecasts, scenarios, KPI targets, IFRS schedule
 * inputs such as leases, provisions, ECL matrices, related parties, EPS, etc.).
 *
 * - One row per (entity, kind, key); `version` gives optimistic concurrency.
 * - `status` drives the maker-checker workflow (draft → submitted → approved);
 *   an approved workbook is locked and can only be superseded by a revision.
 * - Every mutation is also written to `audit_log`.
 */
export const entityWorkbooks = pgTable(
  "entity_workbooks",
  {
    id: text("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    kind: text("kind").notNull(),
    key: text("key").notNull(),
    title: text("title").notNull().default(""),
    payload: jsonb("payload").notNull(),
    status: text("status").notNull().default("draft"),
    version: integer("version").notNull().default(1),
    preparedBy: text("prepared_by"),
    submittedBy: text("submitted_by"),
    approvedBy: text("approved_by"),
    approvedAt: text("approved_at"),
    reviewComment: text("review_comment"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("entity_workbooks_scope_idx").on(t.clientId, t.kind, t.key)]
);

/** Key/value system settings (e.g. first-run owner activation state). */
export const systemSettings = pgTable("system_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * Event-oriented trading subledger. Each document type is a separate business
 * event (requisition, order, receipt, invoice, return, sale, delivery, etc.);
 * common headers and normalized lines keep the lifecycle linked without
 * treating a purchase order as an invoice or payment.
 */
export const tradeCounters = pgTable("trade_counters", {
  clientId: integer("client_id").notNull(),
  prefix: text("prefix").notNull(),
  lastNumber: integer("last_number").notNull().default(0),
}, (t) => [uniqueIndex("trade_counters_scope_idx").on(t.clientId, t.prefix)]);

export const tradeDocuments = pgTable("trade_documents", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  docType: text("doc_type").notNull(),
  docNo: text("doc_no").notNull(),
  status: text("status").notNull(),
  date: text("date").notNull(),
  dueDate: text("due_date"),
  partyId: text("party_id"),
  partyName: text("party_name").notNull().default(""),
  currency: text("currency").notNull(),
  functionalCurrency: text("functional_currency").notNull(),
  exchangeRate: doublePrecision("exchange_rate").notNull().default(1),
  netAmount: doublePrecision("net_amount").notNull().default(0),
  taxAmount: doublePrecision("tax_amount").notNull().default(0),
  totalAmount: doublePrecision("total_amount").notNull().default(0),
  version: integer("version").notNull().default(1),
  createdBy: text("created_by").notNull(),
  submittedBy: text("submitted_by"),
  approvedBy: text("approved_by"),
  approvedAt: timestamp("approved_at", { withTimezone: true }),
  postedAt: timestamp("posted_at", { withTimezone: true }),
  externalRef: text("external_ref"),
  sourceRef: text("source_ref"),
  reason: text("reason"),
  data: jsonb("data").notNull().default(sql`'{}'::jsonb`),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("trade_documents_scope_no_idx").on(t.clientId, t.docNo),
  uniqueIndex("trade_documents_scope_id_type_idx").on(t.clientId, t.id, t.docType),
  uniqueIndex("trade_documents_external_ref_idx").on(t.clientId, t.docType, t.partyId, t.externalRef),
]);

export const tradeDocumentLines = pgTable("trade_document_lines", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  documentId: text("document_id").notNull(),
  lineNo: integer("line_no").notNull(),
  itemCode: text("item_code"),
  description: text("description").notNull(),
  itemType: text("item_type").notNull().default("service"), // stock | office | service | asset
  uom: text("uom").notNull().default("each"),
  quantity: doublePrecision("quantity").notNull().default(1),
  unitPrice: doublePrecision("unit_price").notNull().default(0),
  discountAmount: doublePrecision("discount_amount").notNull().default(0),
  taxCode: text("tax_code").notNull().default("none"),
  taxRate: doublePrecision("tax_rate").notNull().default(0),
  taxAmount: doublePrecision("tax_amount").notNull().default(0),
  netAmount: doublePrecision("net_amount").notNull().default(0),
  totalAmount: doublePrecision("total_amount").notNull().default(0),
  accountNo: text("account_no"),
  inventoryAccount: text("inventory_account"),
  revenueAccount: text("revenue_account"),
  costCenter: text("cost_center"),
  sourceLineId: text("source_line_id"),
  data: jsonb("data").notNull().default(sql`'{}'::jsonb`),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("trade_document_lines_no_idx").on(t.clientId, t.documentId, t.lineNo),
]);

/** Cross-document and line-level traceability (one order → many receipts/invoices). */
export const tradeDocumentLinks = pgTable("trade_document_links", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  fromDocumentId: text("from_document_id").notNull(),
  fromLineId: text("from_line_id"),
  toDocumentId: text("to_document_id").notNull(),
  toLineId: text("to_line_id"),
  linkType: text("link_type").notNull(),
  quantity: doublePrecision("quantity").notNull().default(0),
  amount: doublePrecision("amount").notNull().default(0),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("trade_document_links_unique_idx").on(t.clientId, t.fromDocumentId, t.fromLineId, t.toDocumentId, t.toLineId, t.linkType),
]);

/** Cash movements are separate from open-item applications. Unapplied balances remain visible. */
export const tradePayments = pgTable("trade_payments", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  paymentNo: text("payment_no").notNull(),
  paymentType: text("payment_type").notNull(), // customer_receipt | customer_advance | supplier_payment | refund | reversal
  partyId: text("party_id"),
  partyName: text("party_name").notNull(),
  date: text("date").notNull(),
  currency: text("currency").notNull(),
  functionalCurrency: text("functional_currency").notNull(),
  exchangeRate: doublePrecision("exchange_rate").notNull().default(1),
  amount: doublePrecision("amount").notNull(),
  functionalAmount: doublePrecision("functional_amount").notNull(),
  cashAmount: doublePrecision("cash_amount").notNull(),
  withheldAmount: doublePrecision("withheld_amount").notNull().default(0),
  method: text("method").notNull(),
  bankAccountId: integer("bank_account_id"),
  reference: text("reference"),
  status: text("status").notNull().default("posted"),
  reversalOf: text("reversal_of"),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  reversedAt: timestamp("reversed_at", { withTimezone: true }),
}, (t) => [uniqueIndex("trade_payments_scope_no_idx").on(t.clientId, t.paymentNo)]);

/** Explicit allocations can settle several open items and retain cash advances/overpayments. */
export const tradeAllocations = pgTable("trade_allocations", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  sourceType: text("source_type").notNull(), // payment | customer_credit_note | supplier_credit_note | write_off | advance
  sourceId: text("source_id").notNull(),
  targetDocumentId: text("target_document_id").notNull(),
  amount: doublePrecision("amount").notNull(),
  currency: text("currency").notNull(),
  allocationDate: text("allocation_date").notNull(),
  createdBy: text("created_by").notNull(),
  reversedAt: timestamp("reversed_at", { withTimezone: true }),
}, (t) => [uniqueIndex("trade_allocations_source_target_idx").on(t.clientId, t.sourceType, t.sourceId, t.targetDocumentId)]);

/** Sales-order reservations are separate from physical stock issues. */
export const tradeInventoryReservations = pgTable("trade_inventory_reservations", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  documentId: text("document_id").notNull(),
  lineId: text("line_id").notNull(),
  itemCode: text("item_code").notNull(),
  quantity: doublePrecision("quantity").notNull(),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  releasedAt: timestamp("released_at", { withTimezone: true }),
}, (t) => [uniqueIndex("trade_inventory_reservations_line_idx").on(t.clientId, t.lineId)]);

/** Receipt cost layers support FIFO and controlled specific identification. */
export const tradeInventoryLots = pgTable("trade_inventory_lots", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  itemCode: text("item_code").notNull(),
  sourceDocumentId: text("source_document_id").notNull(),
  sourceLineId: text("source_line_id").notNull(),
  receiptDate: text("receipt_date").notNull(),
  originalQuantity: doublePrecision("original_quantity").notNull(),
  remainingQuantity: doublePrecision("remaining_quantity").notNull(),
  functionalUnitCost: doublePrecision("functional_unit_cost").notNull(),
  currency: text("currency").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("trade_inventory_lots_receipt_line_idx").on(t.clientId, t.sourceLineId),
]);

/** Ledger-derived cashbook movements; bank_accounts.balance is never changed by payments. */
export const tradeCashMovements = pgTable("trade_cash_movements", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  bankAccountId: integer("bank_account_id").notNull(),
  paymentId: text("payment_id").notNull(),
  date: text("date").notNull(),
  amount: doublePrecision("amount").notNull(),
  functionalAmount: doublePrecision("functional_amount").notNull(),
  currency: text("currency").notNull(),
  reference: text("reference"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("trade_cash_movements_payment_idx").on(t.clientId, t.paymentId)]);

/** Imported bank statement lines remain immutable; matching does not overwrite the ledger. */
export const tradeBankStatements = pgTable("trade_bank_statements", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  bankAccountId: integer("bank_account_id").notNull(),
  statementDate: text("statement_date").notNull(),
  externalRef: text("external_ref").notNull(),
  description: text("description").notNull(),
  amount: doublePrecision("amount").notNull(),
  currency: text("currency").notNull(),
  importBatch: text("import_batch").notNull(),
  matchStatus: text("match_status").notNull().default("unmatched"),
  importedAt: timestamp("imported_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("trade_bank_statements_dedupe_idx").on(t.clientId, t.bankAccountId, t.externalRef)]);

export const tradeBankMatches = pgTable("trade_bank_matches", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  statementLineId: text("statement_line_id").notNull(),
  cashMovementId: text("cash_movement_id").notNull(),
  matchedAmount: doublePrecision("matched_amount").notNull(),
  matchedBy: text("matched_by").notNull(),
  matchedAt: timestamp("matched_at", { withTimezone: true }).notNull().defaultNow(),
  signedOffBy: text("signed_off_by"),
  signedOffAt: timestamp("signed_off_at", { withTimezone: true }),
}, (t) => [uniqueIndex("trade_bank_matches_pair_idx").on(t.clientId, t.statementLineId, t.cashMovementId)]);

/** Structured, append-only evidence for all new trade events. */
export const tradeAuditEvents = pgTable("trade_audit_events", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  actor: text("actor").notNull(),
  eventType: text("event_type").notNull(),
  recordType: text("record_type").notNull(),
  recordId: text("record_id").notNull(),
  occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
  beforeState: jsonb("before_state"),
  afterState: jsonb("after_state"),
  reason: text("reason"),
  correlationId: text("correlation_id").notNull(),
  outcome: text("outcome").notNull(),
}, (t) => [uniqueIndex("trade_audit_correlation_idx").on(t.clientId, t.correlationId, t.eventType)]);

/** Tenant-scoped idempotency receipt, including event type in the key. */
export const tradePostingEvents = pgTable("trade_posting_events", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  idempotencyKey: text("idempotency_key").notNull(),
  requestHash: text("request_hash").notNull(),
  response: jsonb("response").notNull(),
  actor: text("actor").notNull(),
  eventType: text("event_type").notNull(),
  recordType: text("record_type").notNull(),
  recordId: text("record_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("trade_postings_scope_key_idx").on(t.clientId, t.idempotencyKey)]);

/** Durable outbound messages commit with the accounting event; dispatch is retriable. */
export const tradeOutbox = pgTable("trade_outbox", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  eventKey: text("event_key").notNull(),
  aggregateType: text("aggregate_type").notNull(),
  aggregateId: text("aggregate_id").notNull(),
  payload: jsonb("payload").notNull(),
  status: text("status").notNull().default("pending"),
  attempts: integer("attempts").notNull().default(0),
  nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  lastError: text("last_error"),
}, (t) => [uniqueIndex("trade_outbox_event_idx").on(t.clientId, t.eventKey)]);

/** Deduplicates provider callbacks; external delivery is effectively-once, not globally exactly-once. */
export const tradeInbox = pgTable("trade_inbox", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  provider: text("provider").notNull(),
  externalEventId: text("external_event_id").notNull(),
  payload: jsonb("payload").notNull(),
  status: text("status").notNull().default("received"),
  receivedAt: timestamp("received_at", { withTimezone: true }).notNull().defaultNow(),
  processedAt: timestamp("processed_at", { withTimezone: true }),
}, (t) => [uniqueIndex("trade_inbox_dedupe_idx").on(t.clientId, t.provider, t.externalEventId)]);

