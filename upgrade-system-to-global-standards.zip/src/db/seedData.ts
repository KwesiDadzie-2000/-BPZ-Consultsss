import { randomBytes } from 'node:crypto';
import { db } from "@/db";
import {
  users,
  clients,
  journalLines,
  bankAccounts,
  purchaseOrders,
  salesInvoices,
  employees,
  companyProfiles,
  chartAccounts,
  businessPartners,
  approvalRequests,
  disclosureNotes,
  prepaymentRecords,
  prepaymentSchedules,
  closedPeriods,
  auditLog,
  systemSettings,
} from "@/db/schema";
import {
  INITIAL_USERS,
  INITIAL_CLIENTS,
  INITIAL_ACDOCA_LINES,
  INITIAL_BANK_ACCOUNTS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_SALES_INVOICES,
  INITIAL_EMPLOYEES,
  INITIAL_CHART_OF_ACCOUNTS,
  INITIAL_BUSINESS_PARTNERS,
  INITIAL_APPROVAL_REQUESTS,
  INITIAL_DISCLOSURES,
  INITIAL_PREPAYMENTS,
  INITIAL_PREPAYMENT_SCHEDULES,
} from "@/data/accountingSeed";
import { DEFAULT_PROFILES } from "@/utils/persistentStorage";
import { businessPartnerStorageId } from "@/lib/businessPartnerSync";
import { hashPassword, newSalt } from "@/lib/password";

/**
 * Idempotent demo seed: wipes and reloads the demonstration dataset.
 * Passwords are stored hashed (scrypt + per-user salt) — never in plaintext.
 * Runs in ONE transaction: a failure part-way leaves the database untouched.
 */
export type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

export async function seedDemoData(): Promise<void> {
  await db.transaction(async (tx) => {
    await seedInto(tx);
  });
}

export async function seedInto(tx: Tx): Promise<void> {
  // Wipe in dependency-safe order.
  await tx.delete(journalLines);
  await tx.delete(bankAccounts);
  await tx.delete(purchaseOrders);
  await tx.delete(salesInvoices);
  await tx.delete(employees);
  await tx.delete(businessPartners);
  await tx.delete(approvalRequests);
  await tx.delete(prepaymentRecords);
  await tx.delete(prepaymentSchedules);
  await tx.delete(closedPeriods);
  await tx.delete(auditLog);
  await tx.delete(companyProfiles);
  await tx.delete(chartAccounts);
  await tx.delete(disclosureNotes);
  await tx.delete(clients);
  await tx.delete(users);

  // First-run activation (see /api/auth/setup): when the operator did not supply
  // the owner's password, the owner is created WITHOUT a usable credential and a
  // one-time activation is offered on the sign-in screen. Previously every seed
  // password was random and undisclosed, so nobody could ever sign in.
  await tx.delete(systemSettings);
  const ownerSeed = INITIAL_USERS.find((u) => u.role === 'owner');
  const ownerProvided = ownerSeed ? Boolean(process.env[`BPZ_SEED_PASSWORD_${ownerSeed.username.toUpperCase()}`]) : true;
  if (ownerSeed && !ownerProvided) {
    await tx.insert(systemSettings).values({ key: 'owner_activation', value: { pending: true, ownerUsername: ownerSeed.username.toLowerCase() } });
  }
  for (const u of INITIAL_USERS) {
    const salt = newSalt();
    const provided = process.env[`BPZ_SEED_PASSWORD_${u.username.toUpperCase()}`];
    const pendingOwner = !provided && ownerSeed?.username === u.username;
    const passwordHash = pendingOwner ? null : await hashPassword(provided || randomBytes(32).toString('base64url'), salt);
    await tx.insert(users).values({
      id: u.username,
      username: u.username,
      email: u.email,
      name: u.name,
      role: u.role,
      makerLimit: u.makerLimit,
      canCheck: u.canCheck,
      clientId: u.clientId ?? null,
      passwordHash,
      passwordSalt: passwordHash ? salt : null,
      status: u.status ?? "active",
      restrictionReason: u.restrictionReason ?? null,
      permissions: u.permissions ?? null,
    });
  }

  await tx.insert(clients).values(
    INITIAL_CLIENTS.map((c) => ({
      id: c.id,
      code: c.code,
      name: c.name,
      sector: c.sector,
      currency: c.currency,
      jurisdiction: c.jurisdiction,
      regNumber: c.regNumber,
      isParent: c.isParent ?? false,
      assignedServices: c.assignedServices ?? null,
      adminUsername: c.adminUsername ?? null,
      adminEmail: c.adminEmail ?? null,
      loginUrl: c.loginUrl ?? null,
    }))
  );

  await tx.insert(journalLines).values(
    INITIAL_ACDOCA_LINES.map((l) => ({
      id: l.id,
      docNo: l.docNo,
      period: l.period,
      date: l.date,
      module: l.module,
      docType: l.docType,
      accountNo: l.accountNo,
      accountName: l.accountName,
      costCenter: l.costCenter ?? null,
      debit: l.debit,
      credit: l.credit,
      currency: l.currency,
      description: l.description,
      createdBy: l.createdBy,
      checkedBy: l.checkedBy ?? null,
      isReversed: l.isReversed ?? false,
      reference: l.reference ?? null,
      clientId: l.clientId,
    }))
  );

  // Legacy demonstration rows without an explicit tag belong to the demo client
  // (CLI-001, id 2) — the same default the workspace applies to untagged rows.
  const LEGACY_CLIENT_ID = 2;
  await tx.insert(bankAccounts).values(
    INITIAL_BANK_ACCOUNTS.map((b) => ({
      id: b.id,
      clientId: b.clientId ?? LEGACY_CLIENT_ID,
      code: b.code,
      name: b.name,
      bankName: b.bankName,
      accountNo: b.accountNo,
      currency: b.currency,
      balance: b.balance,
      kind: b.kind ?? null,
      glAccount: b.glAccount ?? null,
    }))
  );

  await tx.insert(purchaseOrders).values(
    INITIAL_PURCHASE_ORDERS.map((p) => ({
      id: p.id,
      clientId: p.clientId ?? LEGACY_CLIENT_ID,
      poNo: p.poNo,
      vendorName: p.vendorName,
      itemType: p.itemType,
      itemDescription: p.itemDescription,
      qty: p.qty,
      unitPrice: p.unitPrice,
      vatRecoverable: p.vatRecoverable,
      totalAmount: p.totalAmount,
      paidAmount: p.paidAmount ?? 0,
      status: p.status,
      date: p.date,
      currency: p.currency ?? null,
      vatTreatment: p.vatTreatment ?? null,
      netAmount: p.netAmount ?? null,
      quotationRef: p.quotationRef ?? null,
      glAccount: p.glAccount,
      glAccountName: p.glAccountName,
      costCenter: p.costCenter,
      costCenterName: p.costCenterName,
    }))
  );

  await tx.insert(salesInvoices).values(
    INITIAL_SALES_INVOICES.map((i) => ({
      id: i.id,
      clientId: i.clientId ?? LEGACY_CLIENT_ID,
      invNo: i.invNo,
      customerName: i.customerName,
      revenueStream: i.revenueStream,
      netRevenue: i.netRevenue,
      vatOutput: i.vatOutput,
      cstAmount: i.cstAmount ?? null,
      tourismLevyAmount: i.tourismLevyAmount ?? null,
      vatWithheldByCustomer: i.vatWithheldByCustomer ?? null,
      totalReceivable: i.totalReceivable,
      paidAmount: i.paidAmount,
      status: i.status,
      date: i.date,
    }))
  );

  await tx.insert(employees).values(
    INITIAL_EMPLOYEES.map((e) => ({
      id: e.id,
      clientId: e.clientId ?? LEGACY_CLIENT_ID,
      bpNo: e.bpNo,
      name: e.name,
      role: e.role,
      department: e.department,
      jurisdiction: e.jurisdiction,
      basicSalary: e.basicSalary,
      allowances: e.allowances,
      ssnitNumber: e.ssnitNumber,
      tin: e.tin,
      status: e.status,
      isResident: e.isResident ?? true,
      exemptTier1: e.exemptTier1 ?? false,
      exemptTier2: e.exemptTier2 ?? false,
      ssnitExempt: e.ssnitExempt ?? false,
      ssnitExemptionReason: e.ssnitExemptionReason ?? null,
      taxRelief: e.taxRelief ?? 0,
      reliefType: e.reliefType ?? null,
      deductions: e.deductions ?? null,
    }))
  );

  await tx.insert(companyProfiles).values(
    Object.values(DEFAULT_PROFILES).map((p) => ({
      clientId: p.clientId,
      legalName: p.legalName,
      tradingName: p.tradingName,
      tin: p.tin,
      vatRegNo: p.vatRegNo,
      address: p.address,
      phone: p.phone,
      email: p.email,
      website: p.website,
      fiscalYearStart: p.fiscalYearStart,
      bankPaymentDetails: p.bankPaymentDetails,
    }))
  );

  await tx.insert(chartAccounts).values(
    INITIAL_CHART_OF_ACCOUNTS.map((a) => ({
      accountNo: a.accountNo,
      name: a.name,
      type: a.type,
      category: a.category,
      active: a.active,
      isCustom: a.isCustom ?? false,
      clientId: null,
    }))
  );

  await tx.insert(businessPartners).values(
    INITIAL_BUSINESS_PARTNERS.map((p) => ({
      id: businessPartnerStorageId(p.clientId ?? LEGACY_CLIENT_ID, p.id),
      sourceId: p.id,
      clientId: p.clientId ?? LEGACY_CLIENT_ID,
      code: p.code,
      name: p.name,
      type: p.type,
      tin: p.tin,
      email: p.email,
      phone: p.phone,
      address: p.address,
      currency: p.currency,
      isVatWithholdingAgent: p.isVatWithholdingAgent,
      vatWithholdingRate: p.vatWithholdingRate ?? null,
      isCstApplicable: p.isCstApplicable,
      isTourismLevyApplicable: p.isTourismLevyApplicable,
      isVatRegistered: p.isVatRegistered ?? null,
    }))
  );

  await tx.insert(approvalRequests).values(
    INITIAL_APPROVAL_REQUESTS.map((r) => ({
      id: r.id,
      clientId: r.clientId,
      clientCode: r.clientCode,
      clientName: r.clientName,
      docNo: r.docNo,
      docType: r.docType,
      amount: r.amount,
      requestedBy: r.requestedBy,
      requestedAt: r.requestedAt,
      description: r.description,
      reasonForApproval: r.reasonForApproval,
      status: r.status,
      reviewedBy: r.reviewedBy ?? null,
      reviewedAt: r.reviewedAt ?? null,
      rejectionReason: r.rejectionReason ?? null,
      payload: r.payload ?? null,
    }))
  );

  await tx.insert(disclosureNotes).values(
    INITIAL_DISCLOSURES.map((n) => ({
      key: n.key,
      noteNumber: n.noteNumber,
      title: n.title,
      standardRef: n.standardRef,
      applicable: n.applicable,
      notApplicableReason: n.notApplicableReason ?? null,
      body: n.body,
      tables: n.tables ?? null,
      editableOverride: (n as { editableOverride?: boolean }).editableOverride ?? null,
    }))
  );

  await tx.insert(prepaymentRecords).values(
    INITIAL_PREPAYMENTS.map((p) => ({ id: p.id, clientId: p.clientId, record: p }))
  );
  await tx.insert(prepaymentSchedules).values(
    INITIAL_PREPAYMENT_SCHEDULES.map((s) => ({ id: s.id, prepaymentId: s.prepaymentId, clientId: s.clientId, line: s }))
  );

  console.log("Seed complete: users (hashed passwords), clients, journal, treasury, orders, invoices, employees, profiles, COA, partners, approvals, disclosures, prepayments.");
}
