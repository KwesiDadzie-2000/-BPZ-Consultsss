import { sameJournalLines, type JournalLineIdentity } from './journalValidation';

export function immutableJournalConflict(
  existing: readonly JournalLineIdentity[], incoming: readonly JournalLineIdentity[],
): string | null {
  const stored = new Map<string, JournalLineIdentity[]>();
  const proposed = new Map<string, JournalLineIdentity[]>();
  for (const line of existing) {
    const key = `${line.clientId}:${line.docNo}`;
    stored.set(key, [...(stored.get(key) || []), line]);
  }
  for (const line of incoming) {
    const key = `${line.clientId}:${line.docNo}`;
    proposed.set(key, [...(proposed.get(key) || []), line]);
  }
  for (const [key, document] of proposed) {
    const previous = stored.get(key);
    if (previous && !sameJournalLines(previous, document)) {
      return `Posted document ${document[0].docNo} is immutable. Reverse it and post a correcting journal; the original has not been changed.`;
    }
  }
  return null;
}