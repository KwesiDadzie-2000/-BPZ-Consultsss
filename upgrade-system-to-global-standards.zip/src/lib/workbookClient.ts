import { useCallback, useEffect, useRef, useState } from 'react';
import { apiFetch } from '@/utils/session';

/**
 * Browser client for `/api/workbooks` — server-authoritative, versioned
 * planning & IFRS schedule documents with maker-checker workflow.
 */
export type WorkbookKind = 'budget' | 'forecast' | 'scenario' | 'kpi_targets' | 'ifrs_inputs' | 'cashflow_plan';
export type WorkbookStatus = 'draft' | 'submitted' | 'approved' | 'rejected';
export type WorkflowAction = 'submit' | 'approve' | 'reject' | 'withdraw';

export interface Workbook<T = unknown> {
  id: string;
  clientId: number;
  kind: WorkbookKind;
  key: string;
  title: string;
  payload: T;
  status: WorkbookStatus;
  version: number;
  preparedBy: string | null;
  submittedBy: string | null;
  approvedBy: string | null;
  approvedAt: string | null;
  reviewComment: string | null;
  updatedAt: string;
}

export interface WorkbookResult<T> {
  ok: boolean;
  workbook?: Workbook<T>;
  error?: string;
}

async function readJson(res: Response): Promise<Record<string, unknown> | null> {
  try {
    return (await res.json()) as Record<string, unknown>;
  } catch {
    return null;
  }
}

export function useWorkbooks<T>(clientId: number, kind: WorkbookKind) {
  const [items, setItems] = useState<Workbook<T>[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const seq = useRef(0);

  const reload = useCallback(async () => {
    const ticket = ++seq.current;
    setLoading(true);
    try {
      const res = await apiFetch(`/api/workbooks?clientId=${clientId}&kind=${kind}`);
      const body = await readJson(res);
      if (ticket !== seq.current) return;
      if (!res.ok || !body?.ok) {
        setError(String(body?.error ?? `Could not load ${kind.replace('_', ' ')} workbooks (HTTP ${res.status}).`));
        return;
      }
      setItems((body.workbooks as Workbook<T>[]) ?? []);
      setError(null);
    } catch {
      if (ticket === seq.current) setError('The planning service could not be reached. Changes are not saved until it is available.');
    } finally {
      if (ticket === seq.current) setLoading(false);
    }
  }, [clientId, kind]);

  useEffect(() => {
    void reload();
  }, [reload]);

  const upsertLocal = (wb: Workbook<T>) =>
    setItems((prev) => [...prev.filter((p) => p.key !== wb.key), wb].sort((a, b) => a.key.localeCompare(b.key)));

  const save = useCallback(
    async (key: string, title: string, payload: T, expectedVersion: number): Promise<WorkbookResult<T>> => {
      try {
        const res = await apiFetch('/api/workbooks', { method: 'PUT', body: JSON.stringify({ clientId, kind, key, title, payload, expectedVersion }) });
        const body = await readJson(res);
        if (!res.ok || !body?.ok) {
          if (body?.current) upsertLocal(body.current as Workbook<T>);
          return { ok: false, error: String(body?.error ?? `Save failed (HTTP ${res.status}).`) };
        }
        const wb = body.workbook as Workbook<T>;
        upsertLocal(wb);
        return { ok: true, workbook: wb };
      } catch {
        return { ok: false, error: 'The planning service could not be reached. Try again.' };
      }
    },
    [clientId, kind],
  );

  const act = useCallback(
    async (key: string, action: WorkflowAction, version: number, comment?: string): Promise<WorkbookResult<T>> => {
      try {
        const res = await apiFetch('/api/workbooks', { method: 'POST', body: JSON.stringify({ clientId, kind, key, action, version, comment }) });
        const body = await readJson(res);
        if (!res.ok || !body?.ok) {
          if (body?.current) upsertLocal(body.current as Workbook<T>);
          return { ok: false, error: String(body?.error ?? `Action failed (HTTP ${res.status}).`) };
        }
        const wb = body.workbook as Workbook<T>;
        upsertLocal(wb);
        return { ok: true, workbook: wb };
      } catch {
        return { ok: false, error: 'The planning service could not be reached. Try again.' };
      }
    },
    [clientId, kind],
  );

  const remove = useCallback(
    async (key: string): Promise<WorkbookResult<T>> => {
      try {
        const res = await apiFetch(`/api/workbooks?clientId=${clientId}&kind=${kind}&key=${encodeURIComponent(key)}`, { method: 'DELETE' });
        const body = await readJson(res);
        if (!res.ok || !body?.ok) return { ok: false, error: String(body?.error ?? `Delete failed (HTTP ${res.status}).`) };
        setItems((prev) => prev.filter((p) => p.key !== key));
        return { ok: true };
      } catch {
        return { ok: false, error: 'The planning service could not be reached. Try again.' };
      }
    },
    [clientId, kind],
  );

  return { items, loading, error, reload, save, act, remove };
}

export const STATUS_STYLE: Record<WorkbookStatus, string> = {
  draft: 'bg-slate-100 text-slate-700 border-slate-300',
  submitted: 'bg-amber-50 text-amber-800 border-amber-300',
  approved: 'bg-emerald-50 text-emerald-800 border-emerald-300',
  rejected: 'bg-rose-50 text-rose-800 border-rose-300',
};
