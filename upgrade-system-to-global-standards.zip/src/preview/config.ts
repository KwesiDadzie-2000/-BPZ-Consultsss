declare global {
  interface Window {
    __BPZ_LOCAL_REVIEW__?: boolean;
  }
}

// Only the Vite review entry enables this. The original Next entry stays live.
export const isLocalReview = () =>
  typeof window !== 'undefined' && window.__BPZ_LOCAL_REVIEW__ === true;