import { INITIAL_USERS } from '../data/accountingSeed';
import { persistentStorage as storage } from '../utils/persistentStorage';
import { browserStorage } from '../utils/browserStorage';
import { immutableJournalConflict } from '../lib/immutableJournal';
import { validateJournalLines, validateMakerChecker, validatePostingIdentity } from '../lib/journalValidation';
import { sessionPostingRecord } from '../lib/postingControls';
import type { ACDOCALine, UserAccount } from '../types/accounting';
import type { TradeWorkspace } from '../lib/tradeClient';

export const reviewUser: UserAccount = {
  ...INITIAL_USERS[0], password: undefined,
};

let committed: ACDOCALine[] | null = null;
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
});

function snapshot() {
  return {
    clients: storage.getClients(), journalLines: storage.getJournalLines(),
    bankAccounts: storage.getBankAccounts(), purchaseOrders: storage.getPurchaseOrders(),
    salesInvoices: storage.getSalesInvoices(), employees: storage.getEmployees(),
    businessPartners: storage.getBusinessPartners(), payrollRecords: storage.getPayrollRecords(),
    prepaymentRecords: storage.getPrepayments(), prepaymentSchedules: storage.getPrepaymentSchedules(),
    approvalRequests: storage.getApprovalRequests(), companyProfiles: storage.getCompanyProfiles(),
    chartOfAccounts: storage.getChartOfAccounts(), disclosureNotes: storage.getDisclosureNotes(),
    taxScheduleEntries: storage.getTaxScheduleEntries(), stockItems: storage.getStockItems(),
    stockMovements: storage.getStockMovements(), fixedAssets: storage.getAssets(),
    users: storage.getUserAccounts().map((user) => ({ ...user, password: undefined })),
    closedPeriods: Object.entries(storage.getClosedPeriods()).flatMap(([clientId, periods]) =>
      periods.map((period) => ({ clientId: Number(clientId), period }))),
  };
}

function validate(lines: ACDOCALine[]) {
  const accounts = storage.getChartOfAccounts();
  const directory = new Map(storage.getUserAccounts().map((user) => [user.username, sessionPostingRecord(user)]));
  return validateJournalLines(lines, {
    allowedClientIds: storage.getClients().map((client) => client.id),
    closedPeriodKeys: new Set(Object.entries(storage.getClosedPeriods()).flatMap(([id, periods]) => periods.map((period) => `${id}:${period}`))),
    coaAccountNos: new Set(accounts.map((account) => account.accountNo)),
    isAccountPostable: (number, clientId) => {
      const account = accounts.find((row) => row.accountNo === number && row.clientId === clientId)
        || accounts.find((row) => row.accountNo === number && row.clientId == null);
      return account?.active === true;
    },
  }) || validatePostingIdentity(lines, { session: sessionPostingRecord(reviewUser), users: directory })
    || validateMakerChecker(lines, { username: reviewUser.username, makerLimit: reviewUser.makerLimit, users: directory });
}

type AuditEvent = { timestamp: string; username: string; action: string; target: string; details: string; clientId: number | null };
function audit(event: Omit<AuditEvent, 'timestamp' | 'username'>) {
  const events: AuditEvent[] = JSON.parse(browserStorage.getItem('bpz_review_audit') || '[]');
  browserStorage.setItem('bpz_review_audit', JSON.stringify([
    { ...event, timestamp: new Date().toISOString(), username: reviewUser.username }, ...events,
  ].slice(0, 1000)));
}

// A deliberately separate, local-only review transport. It never creates a real session.
export async function localReviewApi(path: string, init: RequestInit = {}): Promise<Response> {
  const url = new URL(path, 'https://review.local');
  const method = init.method || 'GET';
  const body = typeof init.body === 'string' ? JSON.parse(init.body) : {};
  committed ||= structuredClone(storage.getJournalLines());
  if (url.pathname === '/api/auth/session') return json({ ok: true, user: reviewUser, localReview: true });
  if (url.pathname === '/api/auth/logout') return json({ ok: true, localReview: true });
  if (url.pathname === '/api/auth/login') return json({ ok: false, error: 'This local review does not accept production credentials.' }, 400);
  if (url.pathname === '/api/bootstrap') return json({ ok: true, state: snapshot(), localReview: true });
  if (url.pathname === '/api/state') {
    const incoming: ACDOCALine[] = body.journalLines;
    if (!Array.isArray(incoming)) return json({ ok: false, error: 'Invalid workspace state.' }, 400);
    const conflict = immutableJournalConflict(committed, incoming);
    if (conflict) return json({ ok: false, error: conflict }, 409);
    const known = new Set(committed.map((line) => `${line.clientId}:${line.docNo}`));
    const fresh = incoming.filter((line) => !known.has(`${line.clientId}:${line.docNo}`));
    const error = fresh.length ? validate(fresh) : null;
    if (error) return json({ ok: false, error }, 409);
    committed = [...committed, ...fresh];
    storage.saveJournalLines(committed);
    return json({ ok: true, localReview: true });
  }
  if (url.pathname === '/api/journal') {
    if (method !== 'POST') return json({ ok: false, error: 'Posted journals are immutable. Use Reverse, then post a correcting journal.' }, 409);
    const lines = body.lines as ACDOCALine[];
    if (!Array.isArray(lines)) return json({ ok: false, error: 'Invalid journal.' }, 400);
    const conflict = immutableJournalConflict(committed, lines);
    if (conflict) return json({ ok: false, error: conflict }, 409);
    const known = new Set(committed.map((line) => `${line.clientId}:${line.docNo}`));
    const fresh = lines.filter((line) => !known.has(`${line.clientId}:${line.docNo}`));
    if (!fresh.length) return json({ ok: true, idempotent: true, localReview: true });
    const error = validate(fresh);
    if (error) return json({ ok: false, error }, 409);
    if (fresh.some((line) => committed!.some((old) => old.id === line.id))) return json({ ok: false, error: 'Journal line id already used.' }, 409);
    committed = [...committed, ...fresh];
    storage.saveJournalLines(committed);
    for (const docNo of new Set(fresh.map((line) => line.docNo))) {
      audit({ action: 'POST_JOURNAL', target: docNo, details: 'Posted to local review data only.', clientId: fresh[0].clientId });
    }
    return json({ ok: true, lines, localReview: true });
  }
  if (url.pathname === '/api/audit') {
    if (method === 'POST') { audit(body); return json({ ok: true, localReview: true }); }
    return json({ ok: true, events: JSON.parse(browserStorage.getItem('bpz_review_audit') || '[]') });
  }
  if (url.pathname === '/api/users' && method === 'GET') return json({ ok: true, users: snapshot().users });
  if (url.pathname === '/api/trade' && method === 'GET') {
    if (url.searchParams.get('view') === 'audit') return json({ ok: true, events: [] });
    const clientId = Number(url.searchParams.get('clientId'));
    const client = storage.getClients().find((item) => item.id === clientId);
    if (!client) return json({ ok: false, error: 'Workspace not found.' }, 404);
    const state: TradeWorkspace = {
      client, documents: [], payments: [], allocations: [], auditEvents: [], cashbook: [], inventoryLots: [],
      stockItems: storage.getStockItems().filter((item) => item.clientId === clientId).map((item) => ({ ...item, glAccount: item.glAccount || null, costMethod: item.costMethod || null })),
      bankAccounts: storage.getBankAccounts().filter((bank) => (bank.clientId ?? 2) === clientId).map((bank) => ({ ...bank, kind: bank.kind || null, glAccount: bank.glAccount || null })),
    };
    return json({ ok: true, ...state, localReview: true });
  }
  return json({ ok: false, error: 'This action requires the original authenticated PostgreSQL service. No live transaction was submitted. Local journal, quick invoicing, registers and reports remain available.' }, 503);
}