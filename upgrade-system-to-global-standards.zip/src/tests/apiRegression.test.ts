import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import type { ACDOCALine } from '../types/accounting';

// This destructive fixture is deliberately restricted to a disposable local DB.
const url = process.env.BPZ_TEST_DATABASE_URL;
if (!url) throw new Error('Set BPZ_TEST_DATABASE_URL to the disposable local bpz_review_test database.');
const parsed = new URL(url);
if (!['localhost', '127.0.0.1'].includes(parsed.hostname) || parsed.pathname !== '/bpz_review_test') {
  throw new Error('Refusing to run against anything except a local bpz_review_test database.');
}
process.env.DATABASE_URL = url;
process.env.BPZ_SEED_PASSWORD_OWNER = `Review-${randomUUID()}!`;
process.env.BPZ_SEED_PASSWORD_DEMO = `Review-${randomUUID()}!`;

const { pool } = await import('../db');
await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
const login = await import('../app/api/auth/login/route');
const session = await import('../app/api/auth/session/route');
const logout = await import('../app/api/auth/logout/route');
const journal = await import('../app/api/journal/route');
const state = await import('../app/api/state/route');
const bootstrap = await import('../app/api/bootstrap/route');

type Handler = (request: Request) => Promise<Response>;
const call = (handler: Handler, method: string, body?: unknown, token?: string) => handler(new Request('http://localhost/api/test', {
  method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  ...(body === undefined ? {} : { body: JSON.stringify(body) }),
}));
let passed = 0;
let failed = 0;
async function check(title: string, action: () => Promise<void>) {
  try { await action(); passed++; console.log(`PASS ${title}`); }
  catch (error) { failed++; console.error(`FAIL ${title}`, error); }
}
const base: ACDOCALine = {
  id: '', docNo: '', period: '2026-10', date: '2026-10-29', module: 'FI', docType: 'JE',
  accountNo: '100000', accountName: 'Bank', debit: 100, credit: 0, currency: 'GHS',
  description: 'Isolated integration test', createdBy: 'owner', clientId: 2,
};
const pair = (docNo: string, overrides: Partial<ACDOCALine> = {}): ACDOCALine[] => [
  { ...base, ...overrides, docNo, id: `${docNo}-a` },
  { ...base, ...overrides, docNo, id: `${docNo}-b`, accountNo: '400000', debit: 0, credit: overrides.debit || 100 },
];
const auth = await call(login.POST, 'POST', { usernameOrEmail: 'owner', password: process.env.BPZ_SEED_PASSWORD_OWNER });
assert.equal(auth.status, 200, JSON.stringify(await auth.clone().json()));
const { token: owner } = await auth.json();
const demoResponse = await call(login.POST, 'POST', { usernameOrEmail: 'demo', password: process.env.BPZ_SEED_PASSWORD_DEMO });
const { token: demo } = await demoResponse.json();
const workspace = async (token = owner) => {
  const response = await call(bootstrap.GET, 'GET', undefined, token);
  assert.equal(response.status, 200);
  return (await response.json()).state;
};
const original = pair('INTEGRATION-001');

await check('configured server login creates a secure cookie', async () => {
  assert.match(auth.headers.get('set-cookie')!, /HttpOnly/);
  const response = await call(session.GET, 'GET', undefined, owner);
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.user.password, undefined); assert.equal(body.user.passwordHash, undefined);
});
await check('public legacy seed credentials no longer authenticate', async () => {
  assert.equal((await call(login.POST, 'POST', { usernameOrEmail: 'owner', password: 'BpzOwner2026!' })).status, 401);
});
await check('unauthenticated journal writes are rejected', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: original })).status, 401);
});
await check('balanced owner journal posts', async () => {
  const response = await call(journal.POST, 'POST', { lines: original }, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
});
await check('journal replay is idempotent', async () => {
  const response = await call(journal.POST, 'POST', { lines: original }, owner);
  assert.equal(response.status, 200); assert.equal((await response.json()).idempotent, true);
});
await check('same document with changed amounts is refused', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: original.map((line) => ({ ...line, debit: line.debit * 2, credit: line.credit * 2 })) }, owner)).status, 409);
});
await check('posting date and accounting period must agree', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: pair('INTEGRATION-DATE', { period: '2026-09' }) }, owner)).status, 409);
});
await check('maker cannot forge an authorised checker approval', async () => {
  const lines = pair('INTEGRATION-SPOOF', { createdBy: 'demo', checkedBy: 'checker_kofi', debit: 90000 });
  assert.equal((await call(journal.POST, 'POST', { lines }, demo)).status, 403);
});
await check('authenticated independent checker can post on behalf of maker', async () => {
  const lines = pair('INTEGRATION-APPROVED', { createdBy: 'demo', checkedBy: 'owner', debit: 90000 });
  const response = await call(journal.POST, 'POST', { lines }, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
});
await check('cross-tenant posting is blocked', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: pair('INTEGRATION-TENANT', { createdBy: 'demo', clientId: 3 }) }, demo)).status, 403);
});
await check('unchanged full-state sync succeeds', async () => {
  const response = await call(state.PUT, 'PUT', await workspace(), owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
});
await check('sync cannot modify posted journal amounts', async () => {
  const snapshot = await workspace();
  snapshot.journalLines = snapshot.journalLines.map((line: ACDOCALine) => line.docNo === 'INTEGRATION-001' ? { ...line, debit: line.debit * 2, credit: line.credit * 2 } : line);
  assert.equal((await call(state.PUT, 'PUT', snapshot, owner)).status, 409);
  const persisted = (await workspace()).journalLines.find((line: ACDOCALine) => line.id === original[0].id);
  assert.equal(persisted.debit, 100);
});
await check('omitting journals from sync cannot delete them', async () => {
  const snapshot = await workspace(); const count = snapshot.journalLines.length;
  snapshot.journalLines = [];
  const response = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
  assert.equal((await workspace()).journalLines.length, count);
});
await check('direct PATCH cannot rewrite accounting history', async () => {
  assert.equal((await call(journal.PATCH, 'PATCH', { clientId: 2, docNo: original[0].docNo, lines: original }, owner)).status, 409);
});
await check('direct DELETE cannot erase accounting history', async () => {
  assert.equal((await call(journal.DELETE, 'DELETE', { clientId: 2, docNo: original[0].docNo }, owner)).status, 409);
});
await check('staff cannot change period locks through state sync', async () => {
  const snapshot = await workspace(demo); snapshot.closedPeriods.push({ clientId: 2, period: '2026-11' });
  const response = await call(state.PUT, 'PUT', snapshot, demo);
  assert.ok(response.status === 403 || response.status === 409, JSON.stringify(await response.json()));
});
await check('null state payload returns a controlled 400', async () => {
  assert.equal((await call(state.PUT, 'PUT', null, owner)).status, 400);
});
await check('an authenticated reviewer can persist a rejection decision', async () => {
  const snapshot = await workspace();
  const request = snapshot.approvalRequests.find((row: { status: string }) => row.status === 'pending');
  assert.ok(request);
  request.status = 'rejected'; request.reviewedBy = 'owner'; request.rejectionReason = 'Review regression';
  const response = await call(state.PUT, 'PUT', snapshot, owner);
  assert.equal(response.status, 200, JSON.stringify(await response.json()));
  const stored = (await workspace()).approvalRequests.find((row: { id: string }) => row.id === request.id);
  assert.equal(stored.status, 'rejected'); assert.equal(stored.reviewedBy, 'owner');
});
await check('invalid journal payload returns a controlled 400', async () => {
  assert.equal((await call(journal.POST, 'POST', { lines: [null] }, owner)).status, 400);
});
await check('concurrent journal and stale state sync retain both documents', async () => {
  const snapshot = await workspace(); snapshot.journalLines.push(...pair('INTEGRATION-CONCURRENT-SYNC'));
  const responses = await Promise.all([
    call(state.PUT, 'PUT', snapshot, owner),
    call(journal.POST, 'POST', { lines: pair('INTEGRATION-CONCURRENT-POST') }, owner),
  ]);
  for (const response of responses) assert.equal(response.status, 200, JSON.stringify(await response.json()));
  const posted = (await workspace()).journalLines;
  assert.equal(posted.filter((line: ACDOCALine) => line.docNo.startsWith('INTEGRATION-CONCURRENT')).length, 4);
});
await check('withdrawn journal permission is enforced server-side', async () => {
  await pool.query('UPDATE users SET permissions = $1 WHERE username = $2', [JSON.stringify({ canPostJournals: false }), 'demo']);
  assert.equal((await call(journal.POST, 'POST', { lines: pair('INTEGRATION-RESTRICTED', { createdBy: 'demo' }) }, demo)).status, 403);
});
await check('logout revokes the server session', async () => {
  assert.equal((await call(logout.POST, 'POST', {}, owner)).status, 200);
  assert.equal((await call(session.GET, 'GET', undefined, owner)).status, 401);
});

await pool.end();
console.log(`\nAPI regressions: ${passed} passed, ${failed} failed.`);
if (failed) process.exitCode = 1;