import test from 'node:test';
import assert from 'node:assert/strict';
import type { ACDOCALine, AccountMaster, FixedAsset, SalesInvoice } from '../types/accounting';
import { buildIfrsPack } from '../utils/ifrsPack';
import { computeLease, leaseLiabilityAt, normaliseInputs, ppeRollForward, receivablesAgeing, valueInUse, DEFAULT_IFRS_INPUTS } from '../utils/ifrsSchedules';
import { budgetVsActual, fiscalMonths, linearFit, projectScenario, ragStatus, type BudgetPayload } from '../utils/planning';
import { benford, concentration } from '../utils/analytics';
import { fiscalStartMonthIndex, fiscalYearStartFor } from '../utils/periods';

const line = (p: Partial<ACDOCALine> & Pick<ACDOCALine, 'accountNo' | 'date'>): ACDOCALine => ({
  id: Math.random().toString(36), docNo: p.docNo ?? 'D1', period: p.date.slice(0, 7), module: 'FI', docType: 'JE', accountName: p.accountNo, debit: 0, credit: 0, currency: 'GHS', description: 'test entry', createdBy: 'tester', clientId: 1, ...p,
});

test('IFRS 16: arrears lease PV, amortisation runs to nil and interest = payments − liability', () => {
  const c = computeLease({ id: 'L1', name: 'Office', lessor: 'X', commencement: '2026-01-01', termMonths: 12, payment: 1000, frequency: 'monthly', timing: 'arrears', ratePct: 12, initialDirectCosts: 0 });
  assert.equal(c.initialLiability, 11255.08);
  assert.equal(c.rows.at(-1)!.closing, 0);
  const interest = Math.round(c.rows.reduce((s, r) => s + r.interest, 0) * 100) / 100;
  const paid = Math.round(c.rows.reduce((s, r) => s + r.payment, 0) * 100) / 100;
  assert.equal(Math.round((paid - interest) * 100) / 100, 11255.08);
  assert.equal(leaseLiabilityAt(c, '2025-12-31'), 0);
  assert.equal(leaseLiabilityAt(c, '2026-01-01'), 11255.08);
  assert.equal(leaseLiabilityAt(c, '2027-01-01'), 0);
});

test('IFRS 16: advance lease excludes the first payment from the liability but includes it in the ROU asset', () => {
  const c = computeLease({ id: 'L2', name: 'Car', lessor: 'Y', commencement: '2026-01-01', termMonths: 12, payment: 1000, frequency: 'monthly', timing: 'advance', ratePct: 0, initialDirectCosts: 200 });
  assert.equal(c.initialLiability, 11000);
  assert.equal(c.rouCost, 12200);
});

test('IAS 16 roll-forward foots for every class', () => {
  const assets: FixedAsset[] = [
    { id: 'a', assetTag: 'A1', name: 'Truck', classCode: 'Vehicles', cost: 1200, accumDep: 0, usefulLife: '5', depreciationRate: 20, depreciationMethod: 'straight_line', location: 'HQ', acquired: '2025-01-01' },
    { id: 'b', assetTag: 'A2', name: 'Server', classCode: 'IT', cost: 900, accumDep: 0, usefulLife: '3', depreciationRate: 33.33, depreciationMethod: 'reducing_balance', location: 'HQ', acquired: '2026-03-01', disposedDate: '2026-10-01' },
  ];
  const { rows, total } = ppeRollForward(assets, '2026-01-01', '2026-12-31');
  for (const r of [...rows, total]) {
    assert.ok(Math.abs(r.costOpen + r.additions - r.disposals - r.costClose) < 0.02);
    assert.ok(Math.abs(r.depOpen + r.charge - r.depDisposals - r.depClose) < 0.02);
    assert.ok(Math.abs(r.costClose - r.depClose - r.nbvClose) < 0.02);
  }
  const it = rows.find((r) => r.cls === 'IT')!;
  assert.equal(it.costClose, 0);
  assert.equal(it.depClose, 0);
});

test('IAS 16 note: amortisation of intangibles is no longer counted as PPE depreciation (reconciliation foots)', () => {
  const accounts: AccountMaster[] = [
    { accountNo: '100000', name: 'Cash at Bank', type: 'Asset', category: 'Cash', active: true },
    { accountNo: '150000', name: 'Plant & Machinery', type: 'Asset', category: 'Property, plant and equipment', active: true },
    { accountNo: '159000', name: 'Accumulated Depreciation - Plant & Machinery', type: 'Asset', category: 'Property, plant and equipment', active: true },
    { accountNo: '160000', name: 'Software Licence', type: 'Asset', category: 'Intangible assets', active: true },
    { accountNo: '169000', name: 'Accumulated Amortisation - Software', type: 'Asset', category: 'Intangible assets', active: true },
    { accountNo: '610000', name: 'Depreciation Expense', type: 'Expense', category: 'Depreciation', active: true },
    { accountNo: '611000', name: 'Amortisation Expense', type: 'Expense', category: 'Depreciation', active: true },
  ];
  const lines = [
    line({ docNo: 'P1', accountNo: '150000', date: '2026-01-10', debit: 1000 }), line({ docNo: 'P1', accountNo: '100000', date: '2026-01-10', credit: 1000 }),
    line({ docNo: 'P2', accountNo: '160000', date: '2026-01-10', debit: 500 }), line({ docNo: 'P2', accountNo: '100000', date: '2026-01-10', credit: 500 }),
    line({ docNo: 'P3', accountNo: '610000', date: '2026-06-30', debit: 100 }), line({ docNo: 'P3', accountNo: '159000', date: '2026-06-30', credit: 100 }),
    line({ docNo: 'P4', accountNo: '611000', date: '2026-06-30', debit: 50 }), line({ docNo: 'P4', accountNo: '169000', date: '2026-06-30', credit: 50 }),
  ];
  const pack = buildIfrsPack({ lines, accounts, from: '2026-01-01', through: '2026-12-31', currency: 'GHS', entityName: 'Test', entityCode: 'TST', jurisdiction: 'Ghana' });
  const note = pack.notes.find((n) => n.title === 'Property, plant and equipment')!;
  const v = Object.fromEntries(note.table!.rows.map((r) => [String(r[0]), Number(r[1])]));
  assert.equal(v['Depreciation charge for the period'], -100);
  assert.equal(v['Carrying amount at end of period'], 900);
  assert.equal(v['Carrying amount at start of period'] + v['Additions'] + v['Disposals'] + v['Depreciation charge for the period'], v['Carrying amount at end of period']);
});

test('IFRS 9 ageing buckets by days past due after credit terms', () => {
  const inv = (date: string, amt: number): SalesInvoice => ({ id: date, clientId: 1, invNo: date, customerName: 'C', revenueStream: 'S', netRevenue: amt, vatOutput: 0, totalReceivable: amt, paidAmount: 0, status: 'Open', date });
  const a = receivablesAgeing([inv('2026-06-20', 100), inv('2026-05-15', 200), inv('2026-01-01', 300)], 1, '2026-06-30', 30);
  assert.deepEqual(a.buckets, [100, 200, 0, 0, 300]);
  assert.equal(a.total, 600);
});

test('IAS 36 value in use with terminal value', () => {
  assert.equal(valueInUse({ id: 'x', cgu: 'A', carryingAmount: 0, cashFlows: '100,100', growthPct: 0, discountPct: 10, fvlcd: 0 }), 1000);
});

test('Schedule inputs are parsed defensively', () => {
  const n = normaliseInputs({ leases: [{ frequency: 'weird', termMonths: -5 }], ecl: { rates: [500] }, eps: 'x' });
  assert.equal(n.leases[0].frequency, 'monthly');
  assert.equal(n.leases[0].termMonths, 1);
  assert.equal(n.ecl.rates[0], 100);
  assert.equal(n.ecl.rates.length, 5);
  assert.deepEqual(normaliseInputs(null).ecl, DEFAULT_IFRS_INPUTS.ecl);
});

test('Budget vs actual: favourable/adverse sign convention', () => {
  const budget: BudgetPayload = { fiscalYear: 2026, startMonth: '2026-01', method: 'zero_based', growthPct: 0, inflationPct: 0, assumptions: '', capex: [], lines: [
    { accountNo: '4', accountName: 'Sales', type: 'Income', group: 'revenue', months: Array(12).fill(1000) },
    { accountNo: '6', accountName: 'Rent', type: 'Expense', group: 'administrative', months: Array(12).fill(1000) },
  ] };
  const actuals = new Map([['4', [1200, ...Array(11).fill(0)]], ['6', [1200, ...Array(11).fill(0)]]]);
  const r = budgetVsActual(budget, actuals, 0, { pct: 10, amount: 100 });
  assert.equal(r.rows.find((x) => x.accountNo === '4')!.favVarYtd, 200);
  assert.equal(r.rows.find((x) => x.accountNo === '6')!.favVarYtd, -200);
  assert.equal(r.profit.actual, 0);
});

test('Planning helpers: fiscal calendar, regression, scenario, RAG', () => {
  assert.deepEqual(fiscalMonths('2026-07').slice(0, 2), ['2026-07', '2026-08']);
  assert.equal(fiscalMonths('2026-07')[11], '2027-06');
  assert.equal(fiscalStartMonthIndex('April'), 3);
  assert.equal(fiscalYearStartFor('2026-02-10', 3), '2025-04');
  assert.equal(Math.round(linearFit([1, 2, 3, 4]).slope * 1000) / 1000, 1);
  const y1 = projectScenario({ revenue: 1000, cogs: 400, staff: 200, opex: 100, depreciation: 50, financeCosts: 0, borrowings: 0, cash: 0, receivables: 0, payables: 0, inventory: 0, asAt: '2026-12-31', from: '2026-01-01' }, { revenueGrowthPct: 10, priceChangePct: 0, volumeChangePct: 0, cogsChangePct: 0, opexInflationPct: 0, staffCostChangePct: 0, fxShockPct: 0, fxExposurePct: 0, interestRateChangePct: 0, capex: 0, taxRatePct: 25, dsoDays: 0, dpoDays: 0, dioDays: 0 }, 1)[0];
  assert.equal(y1.revenue, 1100);
  assert.equal(y1.cogs, 440);
  assert.equal(y1.pbt, 310);
  assert.equal(y1.netProfit, 232.5);
  assert.equal(ragStatus(60, 45, 'lower'), 'red');
  assert.equal(ragStatus(40, 45, 'lower'), 'green');
  assert.equal(ragStatus(95, 100, 'higher'), 'amber');
});

test('Analytics: Benford needs data; HHI of a monopoly is 10,000', () => {
  assert.match(benford([], 1, '2026-01-01', '2026-12-31').conformity, /Insufficient/);
  assert.equal(concentration([{ name: 'A', amount: 10 }]).hhi, 10000);
});
