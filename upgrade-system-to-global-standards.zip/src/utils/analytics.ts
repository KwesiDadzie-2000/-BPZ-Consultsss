import type { ACDOCALine, AccountMaster } from '@/types/accounting';
import { groupOf } from '@/utils/ifrsPack';
import { linearFit, shiftMonth } from '@/utils/planning';

/**
 * Data analytics & computer-assisted audit techniques (CAATs).
 * Trend analytics, composition (Pareto), concentration (HHI), Benford's law
 * first-digit test (Nigrini MAD thresholds), journal-entry risk tests
 * (ISA 240 ¶32 / ISA 330) and simple regression forecasting.
 */

const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const minor = (n: number) => Math.round((Number(n) || 0) * 100);

export interface MonthPoint { month: string; revenue: number; expenses: number; profit: number; cash: number; receivables: number; payables: number }

export function monthlySeries(lines: readonly ACDOCALine[], accounts: AccountMaster[], clientId: number, endMonth: string, count: number): MonthPoint[] {
  const months = Array.from({ length: count }, (_, i) => shiftMonth(endMonth, i - count + 1));
  const idx = new Map(months.map((m, i) => [m, i]));
  const byCode = new Map(accounts.map((a) => [a.accountNo, a]));
  const flows = months.map(() => ({ revenue: 0, expenses: 0, cash: 0, receivables: 0, payables: 0 }));
  const opening = { cash: 0, receivables: 0, payables: 0 };
  for (const l of lines) {
    if (l.clientId !== clientId) continue;
    const ym = l.date.slice(0, 7);
    if (ym > endMonth) continue;
    const a = byCode.get(l.accountNo);
    const g = groupOf(a, l.accountNo);
    const dr = minor(l.debit) - minor(l.credit);
    const i = idx.get(ym);
    const bucket = i === undefined ? null : flows[i];
    if (a?.type === 'Income' && bucket) bucket.revenue -= dr;
    else if (a?.type === 'Expense' && bucket) bucket.expenses += dr;
    const target = bucket ?? (ym < months[0] ? opening : null);
    if (!target) continue;
    if (g === 'cash') target.cash += dr;
    else if (g === 'receivables') target.receivables += dr;
    else if (g === 'payables') target.payables -= dr;
  }
  let cash = opening.cash;
  let rec = opening.receivables;
  let pay = opening.payables;
  return months.map((m, i) => {
    cash += flows[i].cash;
    rec += flows[i].receivables;
    pay += flows[i].payables;
    const revenue = r2(flows[i].revenue / 100);
    const expenses = r2(flows[i].expenses / 100);
    return { month: m, revenue, expenses, profit: r2(revenue - expenses), cash: r2(cash / 100), receivables: r2(rec / 100), payables: r2(pay / 100) };
  });
}

export function pareto(lines: readonly ACDOCALine[], accounts: AccountMaster[], clientId: number, from: string, through: string, type: 'Expense' | 'Income') {
  const byCode = new Map(accounts.map((a) => [a.accountNo, a]));
  const totals = new Map<string, number>();
  for (const l of lines) {
    if (l.clientId !== clientId || l.date < from || l.date > through) continue;
    const a = byCode.get(l.accountNo);
    if (a?.type !== type) continue;
    const v = type === 'Expense' ? minor(l.debit) - minor(l.credit) : minor(l.credit) - minor(l.debit);
    totals.set(l.accountNo, (totals.get(l.accountNo) ?? 0) + v);
  }
  const rows = [...totals.entries()].map(([k, v]) => ({ accountNo: k, name: byCode.get(k)?.name ?? k, amount: r2(v / 100) })).filter((r) => r.amount > 0).sort((a, b) => b.amount - a.amount);
  const total = rows.reduce((s, r) => s + r.amount, 0);
  let cum = 0;
  return { total: r2(total), rows: rows.map((r) => { cum += r.amount; return { ...r, pct: total ? r2((r.amount / total) * 100) : 0, cumPct: total ? r2((cum / total) * 100) : 0 }; }) };
}

export function concentration(entries: { name: string; amount: number }[]) {
  const map = new Map<string, number>();
  for (const e of entries) if (e.amount > 0) map.set(e.name || 'Unknown', (map.get(e.name || 'Unknown') ?? 0) + e.amount);
  const rows = [...map.entries()].map(([name, amount]) => ({ name, amount: r2(amount) })).sort((a, b) => b.amount - a.amount);
  const total = rows.reduce((s, r) => s + r.amount, 0);
  const shares = rows.map((r) => (total ? r.amount / total : 0));
  const hhi = Math.round(shares.reduce((s, x) => s + (x * 100) ** 2, 0));
  return { total: r2(total), rows: rows.map((r, i) => ({ ...r, pct: r2(shares[i] * 100) })), hhi, level: hhi > 2500 ? 'Highly concentrated' : hhi > 1500 ? 'Moderately concentrated' : 'Diversified', top1Pct: r2((shares[0] ?? 0) * 100), top5Pct: r2(shares.slice(0, 5).reduce((s, x) => s + x, 0) * 100) };
}

export function benford(lines: readonly ACDOCALine[], clientId: number, from: string, through: string) {
  const counts = new Array(10).fill(0);
  let n = 0;
  for (const l of lines) {
    if (l.clientId !== clientId || l.date < from || l.date > through) continue;
    const amt = Math.max(Number(l.debit) || 0, Number(l.credit) || 0);
    if (amt < 10) continue;
    const d = Number(String(Math.floor(amt)).replace(/^0+/, '')[0]);
    if (d >= 1 && d <= 9) { counts[d]++; n++; }
  }
  const digits = Array.from({ length: 9 }, (_, i) => {
    const d = i + 1;
    const expected = Math.log10(1 + 1 / d);
    const actual = n ? counts[d] / n : 0;
    return { digit: d, count: counts[d], actualPct: r2(actual * 100), expectedPct: r2(expected * 100), z: n ? r2((Math.abs(actual - expected) - 1 / (2 * n)) / Math.sqrt((expected * (1 - expected)) / n)) : 0 };
  });
  const mad = n ? digits.reduce((s, x) => s + Math.abs(x.actualPct - x.expectedPct) / 100, 0) / 9 : 0;
  const chi2 = n ? digits.reduce((s, x) => { const e = (x.expectedPct / 100) * n; return s + (x.count - e) ** 2 / e; }, 0) : 0;
  const conformity = n < 100 ? 'Insufficient data (<100 entries)' : mad < 0.006 ? 'Close conformity' : mad < 0.012 ? 'Acceptable conformity' : mad < 0.015 ? 'Marginal conformity' : 'Nonconformity';
  return { digits, n, mad: Math.round(mad * 10000) / 10000, chi2: r2(chi2), conformity, critical: 15.51 };
}

export interface JournalFlag { docNo: string; date: string; accountNo: string; accountName: string; amount: number; createdBy: string; test: string; severity: 'high' | 'medium' | 'low' }

export function journalAnomalies(lines: readonly ACDOCALine[], accounts: AccountMaster[], clientId: number, from: string, through: string, opts: { roundUnit: number; zThreshold: number }) {
  const byCode = new Map(accounts.map((a) => [a.accountNo, a]));
  const scoped = lines.filter((l) => l.clientId === clientId && l.date >= from && l.date <= through);
  const flags: JournalFlag[] = [];
  const seen = new Set<string>();
  const flag = (l: ACDOCALine, test: string, severity: JournalFlag['severity']) => {
    const key = `${l.docNo}|${test}`;
    if (seen.has(key)) return;
    seen.add(key);
    flags.push({ docNo: l.docNo, date: l.date, accountNo: l.accountNo, accountName: byCode.get(l.accountNo)?.name ?? l.accountName, amount: r2(Math.max(l.debit, l.credit)), createdBy: l.createdBy, test, severity });
  };
  const byAccount = new Map<string, number[]>();
  for (const l of scoped) {
    const amt = Math.max(l.debit, l.credit);
    const list = byAccount.get(l.accountNo) ?? [];
    list.push(amt);
    byAccount.set(l.accountNo, list);
  }
  const stats = new Map([...byAccount.entries()].map(([k, xs]) => {
    const mean = xs.reduce((s, x) => s + x, 0) / xs.length;
    const sd = Math.sqrt(xs.reduce((s, x) => s + (x - mean) ** 2, 0) / Math.max(1, xs.length - 1));
    return [k, { mean, sd, n: xs.length }];
  }));
  const dupKey = new Map<string, Set<string>>();
  for (const l of scoped) {
    const amt = Math.max(l.debit, l.credit);
    const dow = new Date(`${l.date}T00:00:00Z`).getUTCDay();
    const manual = l.docType === 'JE' || l.module === 'FI';
    const g = groupOf(byCode.get(l.accountNo), l.accountNo);
    if (dow === 0 || dow === 6) flag(l, 'Posted on a weekend', 'low');
    if (manual && amt >= opts.roundUnit && amt % opts.roundUnit === 0) flag(l, `Round amount (multiple of ${opts.roundUnit.toLocaleString()})`, 'medium');
    const st = stats.get(l.accountNo);
    if (st && st.n >= 8 && st.sd > 0 && (amt - st.mean) / st.sd > opts.zThreshold) flag(l, `Statistical outlier (z > ${opts.zThreshold})`, 'high');
    if (l.checkedBy && l.checkedBy === l.createdBy && manual && l.docType === 'JE') flag(l, 'Maker and checker are the same user', 'high');
    const day = Number(l.date.slice(8, 10));
    const monthEnd = new Date(Date.UTC(Number(l.date.slice(0, 4)), Number(l.date.slice(5, 7)), 0)).getUTCDate();
    if (manual && l.docType === 'JE' && (g === 'revenue' || g === 'cash') && day >= monthEnd - 2) flag(l, 'Manual entry to revenue/cash at period end', 'high');
    if (!l.description || l.description.trim().length < 6) flag(l, 'Missing or vague description', 'low');
    const dk = `${l.accountNo}|${amt}|${l.date}|${(l.description || '').trim().toLowerCase()}`;
    const docs = dupKey.get(dk) ?? new Set<string>();
    docs.add(l.docNo);
    dupKey.set(dk, docs);
  }
  for (const [k, docs] of dupKey) {
    if (docs.size < 2) continue;
    const [acct] = k.split('|');
    for (const doc of docs) {
      const l = scoped.find((x) => x.docNo === doc && x.accountNo === acct);
      if (l) flag(l, 'Possible duplicate posting', 'high');
    }
  }
  const summary = flags.reduce<Record<string, number>>((s, f) => ((s[f.test] = (s[f.test] ?? 0) + 1), s), {});
  const order = { high: 0, medium: 1, low: 2 };
  flags.sort((a, b) => order[a.severity] - order[b.severity] || b.amount - a.amount);
  return { flags, summary, tested: scoped.length, documents: new Set(scoped.map((l) => l.docNo)).size };
}

export function regressionForecast(values: number[], ahead: number) {
  const fit = linearFit(values);
  const n = values.length;
  const forecast = Array.from({ length: ahead }, (_, k) => r2(fit.intercept + fit.slope * (n + k)));
  const band = Array.from({ length: ahead }, (_, k) => r2(1.96 * fit.se * Math.sqrt(1 + 1 / Math.max(1, n) + (k + 1) / Math.max(1, n))));
  return { forecast, lower: forecast.map((f, i) => r2(f - band[i])), upper: forecast.map((f, i) => r2(f + band[i])), slope: r2(fit.slope), rsq: Math.round(fit.rsq * 1000) / 1000 };
}

export function userActivity(lines: readonly ACDOCALine[], clientId: number, from: string, through: string) {
  const map = new Map<string, { docs: Set<string>; lines: number; value: number }>();
  for (const l of lines) {
    if (l.clientId !== clientId || l.date < from || l.date > through) continue;
    const u = map.get(l.createdBy || 'unknown') ?? { docs: new Set<string>(), lines: 0, value: 0 };
    u.docs.add(l.docNo);
    u.lines += 1;
    u.value += Number(l.debit) || 0;
    map.set(l.createdBy || 'unknown', u);
  }
  return [...map.entries()].map(([user, v]) => ({ user, documents: v.docs.size, lines: v.lines, value: r2(v.value) })).sort((a, b) => b.value - a.value);
}

export function weekdayProfile(lines: readonly ACDOCALine[], clientId: number, from: string, through: string) {
  const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const counts = new Array(7).fill(0);
  const docs = new Set<string>();
  for (const l of lines) {
    if (l.clientId !== clientId || l.date < from || l.date > through) continue;
    const key = `${l.docNo}`;
    if (docs.has(key)) continue;
    docs.add(key);
    counts[new Date(`${l.date}T00:00:00Z`).getUTCDay()]++;
  }
  return names.map((n, i) => ({ label: n, value: counts[i] }));
}
