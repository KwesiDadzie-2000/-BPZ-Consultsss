import { isLocalReview } from '../preview/config';

const memory = new Map<string, string>();
const reported = new Set<string>();
const quarantined = new Set<string>();
const arrayKey = /^bpz_(clients|journal_lines|bank_accounts|purchase_orders|sales_invoices|employees|disclosure_notes|chart_of_accounts|business_partners|payroll_records|user_accounts|approval_requests|prepayments|prepayment_schedules|tax_schedule_entries|stock_items|stock_movements|fixed_assets|review_audit)(_v\d+)?$/;

function warn(message: string) {
  if (reported.has(message)) return;
  reported.add(message);
  if (typeof window !== 'undefined') {
    setTimeout(() => window.dispatchEvent(new CustomEvent('bpz-storage-warning', { detail: message })), 0);
  }
}

function keyFor(key: string) {
  return isLocalReview() ? `bpz_review:${key}` : key;
}

export const browserStorage = {
  getItem(key: string): string | null {
    const scoped = keyFor(key);
    let value: string | null;
    try {
      value = memory.get(scoped) ?? globalThis.localStorage.getItem(scoped);
    } catch {
      value = memory.get(scoped) ?? null;
    }
    if (value && (arrayKey.test(key) || /company_profiles|closed_periods|period_closed|tax_settings/.test(key))) {
      try {
        const parsed: unknown = JSON.parse(value);
        const objectKey = /company_profiles|closed_periods|tax_config|tax_settings/.test(key);
        const booleanKey = key.includes('period_closed');
        if (booleanKey ? typeof parsed !== 'boolean' : objectKey
          ? parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)
          : !Array.isArray(parsed)) throw new Error('Invalid saved data');
        if (arrayKey.test(key) && (parsed as unknown[]).some((row) => !row || typeof row !== 'object' || Array.isArray(row))) throw new Error('Invalid saved row');
      } catch {
        try {
          globalThis.localStorage.setItem(`${scoped}:quarantined`, value);
        } catch { quarantined.add(scoped); }
        warn('Some saved browser data could not be read. The damaged copy has been retained for recovery. Restore a verified backup or reconnect to the server before posting.');
        return null;
      }
    }
    return value;
  },
  setItem(key: string, value: string) {
    const scoped = keyFor(key);
    if (quarantined.has(scoped)) return;
    memory.set(scoped, value);
    try {
      globalThis.localStorage.setItem(scoped, value);
      memory.delete(scoped);
    } catch {
      warn('Browser storage is unavailable or full. Changes are held in memory only and will be lost on refresh. Export a backup now.');
    }
  },
  removeItem(key: string) {
    const scoped = keyFor(key);
    quarantined.delete(scoped);
    memory.delete(scoped);
    try { globalThis.localStorage.removeItem(scoped); } catch { /* Memory is already cleared. */ }
  },
  writeBatch(entries: [string, string][]): boolean {
    const previous = new Map<string, string | null>();
    try {
      for (const [key] of entries) previous.set(keyFor(key), globalThis.localStorage.getItem(keyFor(key)));
      for (const [key, value] of entries) globalThis.localStorage.setItem(keyFor(key), value);
      for (const [key] of entries) { memory.delete(keyFor(key)); quarantined.delete(keyFor(key)); }
      return true;
    } catch {
      // A quota failure must not silently leave half of a restored set of books.
      try {
        for (const [key] of previous) globalThis.localStorage.removeItem(key);
        for (const [key, value] of previous) if (value !== null) globalThis.localStorage.setItem(key, value);
      } catch {
        warn('The backup restore and rollback could not be saved. Stop posting and recover from your last verified backup.');
      }
      return false;
    }
  },
};