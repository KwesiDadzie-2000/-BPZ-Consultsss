import type { ACDOCALine, ClientEntity } from '../types/accounting';

export function dashboardModel(lines: readonly ACDOCALine[], client: ClientEntity) {
  const entityLines = lines.filter((line) => line.clientId === client.id);
  // Untranslated transaction currencies must never be added to functional money.
  const currencyLines = entityLines.filter((line) => line.currency === client.currency);
  const sum = (predicate: (line: ACDOCALine) => boolean, creditNormal = false) =>
    currencyLines.filter(predicate).reduce((total, line) => total +
      (creditNormal ? -1 : 1) * (Math.round(line.debit * 100) - Math.round(line.credit * 100)), 0) / 100;
  const currencyBalances = new Map<string, number>();
  for (const line of entityLines) {
    currencyBalances.set(line.currency, (currencyBalances.get(line.currency) || 0) + Math.round(line.debit * 100) - Math.round(line.credit * 100));
  }
  const revenue = sum((line) => line.accountNo.startsWith('4'), true);
  const expenses = sum((line) => /^[567]/.test(line.accountNo));
  return {
    entityLines,
    excludedLines: entityLines.length - currencyLines.length,
    isBalanced: [...currencyBalances.values()].every((value) => value === 0),
    cashBank: sum((line) => line.accountNo.startsWith('10')),
    bankBalance: sum((line) => ['100000', '101000'].includes(line.accountNo)),
    cashOnHand: sum((line) => ['102000', '103000', '104000'].includes(line.accountNo)),
    receivables: sum((line) => line.accountNo === '110000'),
    payables: sum((line) => ['200000', '201000'].includes(line.accountNo), true),
    revenue, expenses, netIncome: revenue - expenses,
    vat: sum((line) => ['220000', '125000'].includes(line.accountNo), true),
    recent: entityLines.map((line, index) => ({ line, index }))
      .sort((a, b) => b.line.date.localeCompare(a.line.date) || b.index - a.index)
      .slice(0, 7).map(({ line }) => line),
  };
}