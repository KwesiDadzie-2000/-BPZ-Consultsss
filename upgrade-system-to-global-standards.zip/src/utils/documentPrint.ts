/**
 * Purpose-built print documents for the Sales, Procurement and Payment desks.
 *
 * `printReport()` renders an isolated A4 document in a hidden iframe, so what
 * comes out of the printer is the document itself — tax invoice, purchase
 * order, goods received note, payment voucher — and never the application
 * shell. Every builder here produces a statutory-quality sheet: entity
 * letterhead with TIN and VAT registration, a GRA-compliant tax breakdown,
 * the value of the document in words, and prepared / reviewed / approved
 * signature blocks.
 */

import { printReport, type PrintReportSpec, type PrintSection, type PrintEntity } from '@/utils/printReport';
import type { TradeDocument, TradeLine, TradePayment } from '@/lib/tradeClient';
import { computeTaxBreakdown, normaliseTaxRegime, TAX_ACCOUNTS, type TaxComponent, type TaxRegime } from '@/lib/taxEngine';

/* ------------------------------------------------------------------ *
 * Money in words — required on Ghanaian tax invoices and payment
 * vouchers, and expected by any auditor receiving the printed copy.
 * ------------------------------------------------------------------ */

const ONES = ['', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'TEN', 'ELEVEN', 'TWELVE', 'THIRTEEN', 'FOURTEEN', 'FIFTEEN', 'SIXTEEN', 'SEVENTEEN', 'EIGHTEEN', 'NINETEEN'];
const TENS = ['', '', 'TWENTY', 'THIRTY', 'FORTY', 'FIFTY', 'SIXTY', 'SEVENTY', 'EIGHTY', 'NINETY'];

function underThousand(n: number): string {
  if (n === 0) return '';
  if (n < 20) return ONES[n];
  if (n < 100) return `${TENS[Math.floor(n / 10)]}${n % 10 ? `-${ONES[n % 10]}` : ''}`;
  return `${ONES[Math.floor(n / 100)]} HUNDRED${n % 100 ? ` AND ${underThousand(n % 100)}` : ''}`;
}

export function amountInWords(value: number, currency = 'GHS'): string {
  const negative = value < 0;
  const abs = Math.abs(Math.round(value * 100) / 100);
  const whole = Math.floor(abs);
  const cents = Math.round((abs - whole) * 100);
  const major = currency === 'GHS' ? 'GHANA CEDIS' : currency === 'USD' ? 'US DOLLARS' : currency === 'GBP' ? 'POUNDS STERLING' : currency === 'EUR' ? 'EURO' : `${currency} UNITS`;
  const minor = currency === 'GHS' ? 'PESEWAS' : 'CENTS';
  const chunks: string[] = [];
  const scales: Array<[number, string]> = [[1_000_000_000, 'BILLION'], [1_000_000, 'MILLION'], [1_000, 'THOUSAND']];
  let rest = whole;
  for (const [size, label] of scales) {
    const part = Math.floor(rest / size);
    if (part > 0) { chunks.push(`${underThousand(part)} ${label}`); rest -= part * size; }
  }
  if (rest > 0 || chunks.length === 0) chunks.push(underThousand(rest) || 'ZERO');
  const words = `${chunks.join(' ')} ${major}${cents ? ` AND ${underThousand(cents)} ${minor}` : ''}`;
  return `${negative ? 'MINUS ' : ''}${words} ONLY`;
}

/* ------------------------------------------------------------------ *
 * Shared helpers
 * ------------------------------------------------------------------ */

const money = (n: number) => n.toLocaleString('en-GH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const DOC_TITLES: Record<string, string> = {
  purchase_requisition: 'Purchase Requisition',
  purchase_order: 'Purchase Order',
  goods_receipt: 'Goods Received Note',
  supplier_invoice: 'Supplier Invoice — Purchase Day Book',
  supplier_credit_note: 'Supplier Credit Note',
  supplier_debit_note: 'Supplier Debit Note',
  sales_order: 'Sales Order Confirmation',
  sales_delivery: 'Delivery Note',
  sales_invoice: 'Tax Invoice',
  customer_credit_note: 'Customer Credit Note',
  customer_debit_note: 'Customer Debit Note',
};

const DOC_LABELS: Record<string, string> = {
  purchase_requisition: 'Requisition',
  purchase_order: 'Order',
  goods_receipt: 'Receipt',
  supplier_invoice: 'Invoice',
  supplier_credit_note: 'Credit note',
  supplier_debit_note: 'Debit note',
  sales_order: 'Order',
  sales_delivery: 'Delivery',
  sales_invoice: 'Invoice',
  customer_credit_note: 'Credit note',
  customer_debit_note: 'Debit note',
};

/** Sales documents are revenue-side; procurement documents are cost-side. */
export const isSalesDoc = (docType: string) => docType.startsWith('sales') || docType.startsWith('customer');
export const isProcurementDoc = (docType: string) => docType.startsWith('purchase') || docType.startsWith('goods') || docType.startsWith('supplier');

export function documentTitle(docType: string): string {
  return DOC_TITLES[docType] ?? 'Trading Document';
}

/**
 * The tax regime actually applied to a stored document. Documents raised before
 * the regime was introduced carry no breakdown and are recomputed from the
 * classic single-rate tax, so old documents still print with a full analysis.
 */
export function regimeForDocument(doc: TradeDocument, side: 'sales' | 'purchase'): TaxRegime {
  const stored = doc.data?.tax;
  const regime = normaliseTaxRegime(stored, side);
  if (!stored) {
    // Legacy document: back out the single rate that produced taxAmount.
    const rate = doc.netAmount > 0 ? Math.round((doc.taxAmount / doc.netAmount) * 10000) / 100 : 0;
    return { ...regime, vatRate: rate, nhilRate: 0, getfundRate: 0, cstRate: 0, tourismRate: 0, covidRate: 0 };
  }
  return regime;
}

export function taxComponentsForDocument(doc: TradeDocument, side: 'sales' | 'purchase'): TaxComponent[] {
  return computeTaxBreakdown(doc.netAmount, regimeForDocument(doc, side), side).components;
}

/* ------------------------------------------------------------------ *
 * Document print specs
 * ------------------------------------------------------------------ */

function lineSection(doc: TradeDocument, _side: 'sales' | 'purchase'): PrintSection {
  const currency = doc.currency;
  const rows = doc.lines.map((l: TradeLine) => ({
    no: l.lineNo,
    code: l.itemCode || '—',
    description: l.description,
    qty: l.quantity,
    uom: l.uom,
    price: l.unitPrice,
    disc: l.discountAmount,
    net: l.netAmount,
    tax: l.taxAmount,
    total: l.totalAmount,
  }));
  return {
    title: `${DOC_LABELS[doc.docType] ?? 'Document'} lines`,
    subtitle: `All values in ${currency}. Tax is analysed below in accordance with the Value Added Tax Act, 2025 (Act 1151).`,
    columns: [
      { key: 'no', label: '#', width: '4%' },
      { key: 'code', label: 'Item', width: '10%' },
      { key: 'description', label: 'Description', width: '28%' },
      { key: 'qty', label: 'Qty', numeric: true, width: '7%' },
      { key: 'uom', label: 'UOM', width: '6%' },
      { key: 'price', label: 'Unit price', numeric: true, width: '10%' },
      { key: 'disc', label: 'Discount', numeric: true, width: '9%' },
      { key: 'net', label: 'Net', numeric: true, width: '11%' },
      { key: 'tax', label: 'Tax', numeric: true, width: '8%' },
      { key: 'total', label: 'Total', numeric: true, width: '11%' },
    ],
    rows,
    totals: { no: '', code: '', description: `Total — ${doc.docNo}`, qty: '', uom: '', price: '', disc: doc.lines.reduce((s, l) => s + l.discountAmount, 0), net: doc.netAmount, tax: doc.taxAmount, total: doc.totalAmount },
    note: doc.data?.notes ? `Notes: ${String(doc.data.notes)}` : undefined,
  };
}

function taxSection(doc: TradeDocument, side: 'sales' | 'purchase'): PrintSection {
  const regime = regimeForDocument(doc, side);
  const breakdown = computeTaxBreakdown(doc.netAmount, regime, side);
  const rows = breakdown.components.map((c) => ({
    component: c.label,
    basis: c.base === 'charge_plus_cst' ? `Taxable value incl. CST (${money(breakdown.taxableValue)})` : `Value of supply (${money(breakdown.net)})`,
    rate: `${c.rate}%`,
    amount: c.amount,
    gl: c.accountNo,
  }));
  if (breakdown.vatWithheld > 0) {
    rows.push({
      component: `Less: VAT withheld at source by appointed agent (${regime.vatWithholdingRate}%)`,
      basis: `Taxable value (${money(breakdown.taxableValue)})`,
      rate: `${regime.vatWithholdingRate}%`,
      amount: -breakdown.vatWithheld,
      gl: TAX_ACCOUNTS.vatWithholdingReceivable,
    });
  }
  return {
    title: 'Analysis of tax charged (GRA)',
    columns: [
      { key: 'component', label: 'Component', width: '34%' },
      { key: 'basis', label: 'Basis of charge', width: '32%' },
      { key: 'rate', label: 'Rate', numeric: true, width: '8%' },
      { key: 'amount', label: `Amount (${doc.currency})`, numeric: true, width: '16%' },
      { key: 'gl', label: 'GL account', width: '10%' },
    ],
    rows,
    totals: {
      component: 'Total tax charged',
      basis: breakdown.vatWithheld > 0 ? 'Net amount payable by the customer' : 'Payable to GRA',
      rate: `${breakdown.effectiveRate}%`,
      amount: breakdown.vatWithheld > 0 ? breakdown.totalTax - breakdown.vatWithheld : breakdown.totalTax,
      gl: '',
    },
    note: 'VAT is charged at 15% with NHIL 2.5% and the GETFund Levy 2.5% on the same taxable value (Act 1151). Communication Service Tax, where charged, is added to the cost to form the taxable value before VAT (Act 1151 s.15.3). The Tourism Development Levy is charged separately and is excluded from the VAT taxable value (Tourism Act 817).',
  };
}

function summarySection(doc: TradeDocument): PrintSection {
  return {
    columns: [
      { key: 'label', label: 'Summary', width: '70%' },
      { key: 'value', label: `${doc.currency}`, numeric: true, width: '30%' },
    ],
    rows: [
      { label: 'Tax-exclusive value of supply', value: doc.netAmount },
      { label: 'Total tax charged', value: doc.taxAmount },
    ],
    totals: { label: `Total value of this ${DOC_LABELS[doc.docType] ?? 'document'} (amount in words below)`, value: doc.totalAmount },
    note: doc.currency !== doc.functionalCurrency
      ? `Document currency ${doc.currency}; functional currency ${doc.functionalCurrency} at an exchange rate of ${doc.exchangeRate}. Functional equivalent: ${money(doc.totalAmount * doc.exchangeRate)} ${doc.functionalCurrency}.`
      : undefined,
  };
}

export function buildDocumentPrintSpec(
  doc: TradeDocument,
  entity: PrintEntity,
  preparedBy: string,
  options: { extraParagraphs?: string[] } = {},
): PrintReportSpec {
  const side: 'sales' | 'purchase' = isSalesDoc(doc.docType) ? 'sales' : 'purchase';
  const sections: PrintSection[] = [lineSection(doc, side)];
  if (doc.taxAmount > 0 || side === 'sales') sections.push(taxSection(doc, side));
  sections.push(summarySection(doc));

  const paragraphs = [
    `Amount in words: ${amountInWords(doc.totalAmount, doc.currency)}.`,
    doc.dueDate ? `Payment due on or before ${doc.dueDate}.` : '',
    doc.externalRef ? `${side === 'sales' ? 'Customer' : 'Supplier'} reference: ${doc.externalRef}.` : '',
    doc.status === 'Posted' || doc.postedAt
      ? `This document has been posted to the general ledger. It may not be altered; corrections are made by credit or debit note.`
      : `This document has not yet been posted to the general ledger.`,
    ...(options.extraParagraphs ?? []),
  ].filter(Boolean);

  return {
    title: `${documentTitle(doc.docType)} ${doc.docNo}`,
    kicker: side === 'sales' ? 'Sales desk · order to cash' : 'Procurement desk · procure to pay',
    subtitle: `${doc.partyName ? `Issued to ${doc.partyName}` : ''}${doc.status ? ` · Status ${doc.status}` : ''}`,
    entity,
    periodLabel: `${doc.date}${doc.dueDate ? ` → ${doc.dueDate}` : ''}`,
    preparedBy,
    sections,
    stats: [
      { label: 'Document', value: doc.docNo },
      { label: 'Status', value: doc.status },
      { label: 'Tax exclusive', value: doc.netAmount },
      { label: 'Total payable', value: doc.totalAmount },
    ],
    paragraphs,
    footerNote: 'Retain this document for a minimum of six years in accordance with the Revenue Administration Act, 2016 (Act 915).',
    orientation: 'landscape',
  };
}

/* ------------------------------------------------------------------ *
 * Payment voucher / customer receipt
 * ------------------------------------------------------------------ */

const PAYMENT_TITLES: Record<string, string> = {
  customer_receipt: 'Customer Receipt — Official Receipt',
  customer_advance: 'Customer Advance Receipt',
  supplier_payment: 'Payment Voucher',
  reversal: 'Payment Reversal Note',
};

export function buildPaymentPrintSpec(
  payment: TradePayment,
  entity: PrintEntity,
  preparedBy: string,
  options: { bankName?: string; allocations?: Array<{ docNo: string; amount: number; partyName?: string }> } = {},
): PrintReportSpec {
  const title = PAYMENT_TITLES[payment.paymentType] ?? 'Payment Voucher';
  const isReceipt = payment.paymentType !== 'supplier_payment';
  const sections: PrintSection[] = [
    {
      title: 'Payment detail',
      columns: [
        { key: 'label', label: 'Particulars', width: '46%' },
        { key: 'value', label: 'Detail', width: '34%' },
        { key: 'amount', label: `${payment.currency}`, numeric: true, width: '20%' },
      ],
      rows: [
        { label: 'Received from / paid to', value: payment.partyName, amount: '' },
        { label: 'Date of payment', value: payment.date, amount: '' },
        { label: 'Method', value: String(payment.method || '—').replace(/_/g, ' '), amount: '' },
        { label: 'Bank / treasury account', value: options.bankName || `Account #${payment.bankAccountId ?? '—'}`, amount: '' },
        { label: 'Payment reference', value: payment.reference || '—', amount: '' },
        { label: 'Gross amount', value: '', amount: payment.amount },
        { label: 'Cash movement', value: '', amount: payment.cashAmount },
        { label: 'Withheld at source', value: payment.withheldAmount > 0 ? 'Withholding tax deducted — payable to GRA' : 'None', amount: payment.withheldAmount },
      ],
      totals: { label: `Net ${isReceipt ? 'banked' : 'disbursed'}`, value: '', amount: payment.cashAmount },
      note: `Amount in words: ${amountInWords(payment.cashAmount, payment.currency)}.`,
    },
  ];

  const allocations = options.allocations ?? [];
  if (allocations.length) {
    sections.push({
      title: 'Settlement of open items',
      columns: [
        { key: 'docNo', label: 'Document settled', width: '32%' },
        { key: 'partyName', label: 'Account', width: '40%' },
        { key: 'amount', label: `${payment.currency}`, numeric: true, width: '28%' },
      ],
      rows: allocations.map((a) => ({ docNo: a.docNo, partyName: a.partyName ?? payment.partyName, amount: a.amount })),
      totals: { docNo: 'Total allocated', partyName: '', amount: allocations.reduce((s, a) => s + a.amount, 0) },
    });
  }

  return {
    title: `${title} ${payment.paymentNo}`,
    kicker: isReceipt ? 'Payment desk · customer receipts' : 'Payment desk · disbursements',
    subtitle: payment.partyName,
    entity,
    periodLabel: payment.date,
    preparedBy,
    sections,
    stats: [
      { label: 'Voucher', value: payment.paymentNo },
      { label: 'Type', value: title },
      { label: 'Gross', value: payment.amount },
      { label: 'Cash', value: payment.cashAmount },
    ],
    paragraphs: [
      `Amount in words: ${amountInWords(payment.cashAmount, payment.currency)}.`,
      payment.status === 'posted'
        ? 'This receipt/payment has been posted to the general ledger and the treasury ledger on the date shown.'
        : 'This document has not yet been posted to the general ledger.',
    ],
    footerNote: 'This voucher is not valid unless signed by both the maker and an authorised checker.',
  };
}

/* ------------------------------------------------------------------ *
 * One-click printing
 * ------------------------------------------------------------------ */

export function printTradeDocument(doc: TradeDocument, entity: PrintEntity, preparedBy: string, extraParagraphs?: string[]): void {
  printReport(buildDocumentPrintSpec(doc, entity, preparedBy, { extraParagraphs }));
}

export function printPaymentDocument(payment: TradePayment, entity: PrintEntity, preparedBy: string, options?: { bankName?: string; allocations?: Array<{ docNo: string; amount: number; partyName?: string }> }): void {
  printReport(buildPaymentPrintSpec(payment, entity, preparedBy, options));
}
