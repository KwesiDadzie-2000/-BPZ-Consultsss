/**
 * Local-calendar period helpers.
 *
 * DEFECT FIXED: several desks derived "today"/"current period" from
 * `new Date().toISOString()`, which is the UTC date. For users east or west of
 * UTC that is the wrong day for several hours around midnight and the wrong
 * month at month-end, so closed-period guards and default posting dates were
 * evaluated against the wrong period.
 */
export function localToday(): string {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60_000).toISOString().slice(0, 10);
}

export function localPeriod(): string {
  return localToday().slice(0, 7);
}

const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];

/** Parses a profile fiscal-year start ("January", "2026-04-01", "04") into a 0-based month index. */
export function fiscalStartMonthIndex(fiscalYearStart?: string | null): number {
  if (!fiscalYearStart) return 0;
  const s = fiscalYearStart.trim().toLowerCase();
  const byName = MONTHS.findIndex((m) => s.startsWith(m.slice(0, 3)));
  if (byName >= 0) return byName;
  const iso = /^\d{4}-(\d{2})/.exec(s);
  if (iso) return Math.min(11, Math.max(0, Number(iso[1]) - 1));
  const mm = /^(\d{1,2})/.exec(s);
  if (mm) return Math.min(11, Math.max(0, Number(mm[1]) - 1));
  return 0;
}

/** First month (YYYY-MM) of the fiscal year containing `date`. */
export function fiscalYearStartFor(date: string, startIdx: number): string {
  const y = Number(date.slice(0, 4));
  const m = Number(date.slice(5, 7)) - 1;
  const startYear = m >= startIdx ? y : y - 1;
  return `${startYear}-${String(startIdx + 1).padStart(2, '0')}`;
}
