import type { ACDOCALine, AccountMaster, SalesInvoice } from '@/types/accounting';
import { groupOf, type Group } from '@/utils/ifrsPack';

/**
 * Performance management engine: budgeting, budget-vs-actual variance
 * analysis, rolling forecasts, driver-based scenario planning, sensitivity,
 * break-even, balanced-scorecard KPIs and a 12-month cash-flow forecast.
 * Pure functions — everything is derived from the posted ledger plus the
 * persisted planning workbooks.
 */

export const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const minor = (n: number) => Math.round((Number(n) || 0) * 100);
const sum = (xs: number[]) => xs.reduce((s, x) => s + (Number.isFinite(x) ? x : 0), 0);

export const shiftMonth = (ym: string, k: number) => {
  const [y, m] = ym.split('-').map(Number);
  const d = new Date(Date.UTC(y, m - 1 + k, 1));
  return d.toISOString().slice(0, 7);
};
export const fiscalMonths = (startMonth: string) => Array.from({ length: 12 }, (_, i) => shiftMonth(startMonth, i));
export const monthLabel = (ym: string) => {
  const [y, m] = ym.split('-').map(Number);
  return `${['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][m - 1]} ${String(y).slice(2)}`;
};
const lastDay = (ym: string) => {
  const [y, m] = ym.split('-').map(Number);
  return new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
};

/* ------------------------------------------------------------------ */
/* Budget                                                              */
/* ------------------------------------------------------------------ */

export interface BudgetLine { accountNo: string; accountName: string; type: 'Income' | 'Expense'; group: string; months: number[] }
export interface CapexLine { id: string; description: string; month: number; amount: number }
export type SeedMethod = 'prior_year' | 'run_rate' | 'zero_based';
export interface BudgetPayload { fiscalYear: number; startMonth: string; method: SeedMethod; growthPct: number; inflationPct: number; assumptions: string; lines: BudgetLine[]; capex: CapexLine[] }

const isPl = (a: AccountMaster | undefined) => a?.type === 'Income' || a?.type === 'Expense';

/** Natural-sign monthly actuals per P&L account: income = credit−debit, expense = debit−credit. */
export function actualsMatrix(lines: readonly ACDOCALine[], accounts: AccountMaster[], clientId: number, months: string[]): Map<string, number[]> {
  const byCode = new Map(accounts.map((a) => [a.accountNo, a]));
  const idx = new Map(months.map((m, i) => [m, i]));
  const out = new Map<string, number[]>();
  for (const l of lines) {
    if (l.clientId !== clientId) continue;
    const i = idx.get(l.date.slice(0, 7));
    if (i === undefined) continue;
    const a = byCode.get(l.accountNo);
    if (!isPl(a)) continue;
    const row = out.get(l.accountNo) ?? new Array(months.length).fill(0);
    row[i] += a!.type === 'Income' ? minor(l.credit) - minor(l.debit) : minor(l.debit) - minor(l.credit);
    out.set(l.accountNo, row);
  }
  for (const [k, v] of out) out.set(k, v.map((x) => r2(x / 100)));
  return out;
}

export function seedBudget(lines: readonly ACDOCALine[], accounts: AccountMaster[], clientId: number, startMonth: string, method: SeedMethod, growthPct: number, inflationPct: number): BudgetLine[] {
  const months = fiscalMonths(startMonth);
  const prior = actualsMatrix(lines, accounts, clientId, months.map((m) => shiftMonth(m, -12)));
  const byCode = new Map(accounts.map((a) => [a.accountNo, a]));
  const factor = (a: AccountMaster) => 1 + (a.type === 'Income' ? growthPct : inflationPct) / 100;
  const used = new Set(prior.keys());
  let candidates = accounts.filter((a) => isPl(a) && a.active !== false && (used.has(a.accountNo) || method === 'zero_based'));
  if (!candidates.length) candidates = accounts.filter((a) => isPl(a) && a.active !== false).slice(0, 40);
  return candidates
    .filter((a) => method !== 'zero_based' || used.has(a.accountNo) || candidates.length <= 40)
    .map((a) => {
      const p = prior.get(a.accountNo) ?? new Array(12).fill(0);
      const avg = sum(p) / 12;
      const values = method === 'zero_based' ? new Array(12).fill(0) : method === 'run_rate' ? new Array(12).fill(r2(avg * factor(a))) : p.map((v) => r2(v * factor(a)));
      return { accountNo: a.accountNo, accountName: byCode.get(a.accountNo)?.name ?? a.name, type: a.type as 'Income' | 'Expense', group: groupOf(a, a.accountNo), months: values };
    })
    .sort((x, y) => (x.type === y.type ? x.accountNo.localeCompare(y.accountNo) : x.type === 'Income' ? -1 : 1));
}

export function budgetTotals(lines: BudgetLine[]) {
  const months = Array.from({ length: 12 }, (_, i) => i);
  const revenue = months.map((i) => r2(sum(lines.filter((l) => l.type === 'Income').map((l) => l.months[i] ?? 0))));
  const expenses = months.map((i) => r2(sum(lines.filter((l) => l.type === 'Expense').map((l) => l.months[i] ?? 0))));
  return { revenue, expenses, profit: months.map((i) => r2(revenue[i] - expenses[i])) };
}

/* ------------------------------------------------------------------ */
/* Budget vs actual                                                    */
/* ------------------------------------------------------------------ */

export interface VarianceRow { accountNo: string; accountName: string; type: 'Income' | 'Expense'; budgetMonth: number; actualMonth: number; budgetYtd: number; actualYtd: number; favVarYtd: number; varPct: number; budgetFy: number; favourable: boolean; material: boolean }

export function budgetVsActual(budget: BudgetPayload, actuals: Map<string, number[]>, monthIdx: number, threshold: { pct: number; amount: number }) {
  const keys = new Set([...budget.lines.map((l) => l.accountNo), ...actuals.keys()]);
  const rows: VarianceRow[] = [];
  for (const k of keys) {
    const b = budget.lines.find((l) => l.accountNo === k);
    const a = actuals.get(k) ?? new Array(12).fill(0);
    const type = b?.type ?? 'Expense';
    if (!b && sum(a) === 0) continue;
    const bm = b?.months ?? new Array(12).fill(0);
    const budgetYtd = r2(sum(bm.slice(0, monthIdx + 1)));
    const actualYtd = r2(sum(a.slice(0, monthIdx + 1)));
    const favVarYtd = r2(type === 'Income' ? actualYtd - budgetYtd : budgetYtd - actualYtd);
    const varPct = budgetYtd ? r2((favVarYtd / Math.abs(budgetYtd)) * 100) : actualYtd ? (favVarYtd >= 0 ? 100 : -100) : 0;
    rows.push({ accountNo: k, accountName: b?.accountName ?? k, type, budgetMonth: r2(bm[monthIdx] ?? 0), actualMonth: r2(a[monthIdx] ?? 0), budgetYtd, actualYtd, favVarYtd, varPct, budgetFy: r2(sum(bm)), favourable: favVarYtd >= 0, material: Math.abs(varPct) >= threshold.pct && Math.abs(favVarYtd) >= threshold.amount });
  }
  rows.sort((x, y) => (x.type === y.type ? Math.abs(y.favVarYtd) - Math.abs(x.favVarYtd) : x.type === 'Income' ? -1 : 1));
  const t = (type: 'Income' | 'Expense', f: (r: VarianceRow) => number) => r2(sum(rows.filter((r) => r.type === type).map(f)));
  const revenue = { budget: t('Income', (r) => r.budgetYtd), actual: t('Income', (r) => r.actualYtd) };
  const expenses = { budget: t('Expense', (r) => r.budgetYtd), actual: t('Expense', (r) => r.actualYtd) };
  return { rows, revenue, expenses, profit: { budget: r2(revenue.budget - expenses.budget), actual: r2(revenue.actual - expenses.actual) } };
}

/* ------------------------------------------------------------------ */
/* Rolling forecast                                                    */
/* ------------------------------------------------------------------ */

export type ForecastMethod = 'budget' | 'run_rate' | 'trend' | 'seasonal';
export interface ForecastRow { accountNo: string; accountName: string; type: 'Income' | 'Expense'; months: number[]; fy: number; budgetFy: number; favVar: number }

export function linearFit(values: number[]) {
  const n = values.length;
  if (n < 2) return { slope: 0, intercept: values[0] ?? 0, rsq: 0, se: 0 };
  const xs = values.map((_, i) => i);
  const mx = sum(xs) / n;
  const my = sum(values) / n;
  const sxx = sum(xs.map((x) => (x - mx) ** 2));
  const sxy = sum(xs.map((x, i) => (x - mx) * (values[i] - my)));
  const slope = sxx ? sxy / sxx : 0;
  const intercept = my - slope * mx;
  const ssTot = sum(values.map((v) => (v - my) ** 2));
  const ssRes = sum(values.map((v, i) => (v - (intercept + slope * i)) ** 2));
  return { slope, intercept, rsq: ssTot ? 1 - ssRes / ssTot : 0, se: n > 2 ? Math.sqrt(ssRes / (n - 2)) : 0 };
}

export function rollingForecast(budget: BudgetPayload, actuals: Map<string, number[]>, priorYear: Map<string, number[]>, closedIdx: number, method: ForecastMethod): ForecastRow[] {
  const keys = new Set([...budget.lines.map((l) => l.accountNo), ...actuals.keys()]);
  const rows: ForecastRow[] = [];
  for (const k of keys) {
    const b = budget.lines.find((l) => l.accountNo === k);
    const a = actuals.get(k) ?? new Array(12).fill(0);
    const bm = b?.months ?? new Array(12).fill(0);
    const type = b?.type ?? 'Expense';
    const known = a.slice(0, closedIdx + 1);
    const recent = known.slice(-3);
    const runRate = recent.length ? sum(recent) / recent.length : 0;
    const fit = linearFit(known);
    const py = priorYear.get(k) ?? new Array(12).fill(0);
    const pyYtd = sum(py.slice(0, closedIdx + 1));
    const ratio = pyYtd ? sum(known) / pyYtd : 1;
    const months = bm.map((bv, i) => {
      if (i <= closedIdx) return r2(a[i] ?? 0);
      if (method === 'budget') return r2(bv);
      if (method === 'run_rate') return r2(known.length ? runRate : bv);
      if (method === 'trend') return r2(known.length >= 3 ? Math.max(0, fit.intercept + fit.slope * i) : known.length ? runRate : bv);
      return r2(pyYtd ? (py[i] ?? 0) * ratio : bv);
    });
    const fy = r2(sum(months));
    const budgetFy = r2(sum(bm));
    if (!b && fy === 0) continue;
    rows.push({ accountNo: k, accountName: b?.accountName ?? k, type, months, fy, budgetFy, favVar: r2(type === 'Income' ? fy - budgetFy : budgetFy - fy) });
  }
  return rows.sort((x, y) => (x.type === y.type ? x.accountNo.localeCompare(y.accountNo) : x.type === 'Income' ? -1 : 1));
}

/* ------------------------------------------------------------------ */
/* Scenario planning                                                   */
/* ------------------------------------------------------------------ */

export interface ScenarioDrivers { revenueGrowthPct: number; priceChangePct: number; volumeChangePct: number; cogsChangePct: number; opexInflationPct: number; staffCostChangePct: number; fxShockPct: number; fxExposurePct: number; interestRateChangePct: number; capex: number; taxRatePct: number; dsoDays: number; dpoDays: number; dioDays: number }
export interface ScenarioPayload { name: string; description: string; horizonYears: number; probabilityPct: number; drivers: ScenarioDrivers }
export interface BaseFinancials { revenue: number; cogs: number; staff: number; opex: number; depreciation: number; financeCosts: number; borrowings: number; cash: number; receivables: number; payables: number; inventory: number; asAt: string; from: string }

export const DRIVER_META: { key: keyof ScenarioDrivers; label: string; unit: '%' | 'days' | 'amount' }[] = [
  { key: 'revenueGrowthPct', label: 'Revenue growth', unit: '%' },
  { key: 'priceChangePct', label: 'Price change', unit: '%' },
  { key: 'volumeChangePct', label: 'Volume change', unit: '%' },
  { key: 'cogsChangePct', label: 'Unit cost (COGS) change', unit: '%' },
  { key: 'opexInflationPct', label: 'Overhead inflation', unit: '%' },
  { key: 'staffCostChangePct', label: 'Staff cost change', unit: '%' },
  { key: 'fxShockPct', label: 'FX depreciation shock', unit: '%' },
  { key: 'fxExposurePct', label: 'Costs exposed to FX', unit: '%' },
  { key: 'interestRateChangePct', label: 'Interest rate change (pp)', unit: '%' },
  { key: 'capex', label: 'Annual capex', unit: 'amount' },
  { key: 'taxRatePct', label: 'Tax rate', unit: '%' },
  { key: 'dsoDays', label: 'Debtor days (DSO)', unit: 'days' },
  { key: 'dpoDays', label: 'Creditor days (DPO)', unit: 'days' },
  { key: 'dioDays', label: 'Inventory days (DIO)', unit: 'days' },
];

export function defaultDrivers(kind: 'base' | 'best' | 'worst', taxRatePct: number, base?: BaseFinancials): ScenarioDrivers {
  const dso = base && base.revenue ? Math.round((base.receivables / base.revenue) * 365) : 45;
  const dpo = base && base.cogs + base.opex ? Math.round((base.payables / (base.cogs + base.opex)) * 365) : 45;
  const dio = base && base.cogs ? Math.round((base.inventory / base.cogs) * 365) : 30;
  const common = { taxRatePct, dsoDays: Math.min(365, Math.max(0, dso)), dpoDays: Math.min(365, Math.max(0, dpo)), dioDays: Math.min(365, Math.max(0, dio)), capex: 0, fxExposurePct: 30 };
  if (kind === 'best') return { ...common, revenueGrowthPct: 15, priceChangePct: 3, volumeChangePct: 5, cogsChangePct: -2, opexInflationPct: 8, staffCostChangePct: 8, fxShockPct: 0, interestRateChangePct: -1 };
  if (kind === 'worst') return { ...common, revenueGrowthPct: -10, priceChangePct: 0, volumeChangePct: -5, cogsChangePct: 6, opexInflationPct: 20, staffCostChangePct: 15, fxShockPct: 25, interestRateChangePct: 3, dsoDays: common.dsoDays + 20 };
  return { ...common, revenueGrowthPct: 8, priceChangePct: 0, volumeChangePct: 0, cogsChangePct: 0, opexInflationPct: 12, staffCostChangePct: 10, fxShockPct: 10, interestRateChangePct: 0 };
}

/** Trailing-twelve-month base financials from the ledger. */
export function baseFromLedger(lines: readonly ACDOCALine[], accounts: AccountMaster[], clientId: number, asAt: string): BaseFinancials {
  const from = `${shiftMonth(asAt.slice(0, 7), -11)}-01`;
  const byCode = new Map(accounts.map((a) => [a.accountNo, a]));
  const g = (code: string): Group => groupOf(byCode.get(code), code);
  const acc: Record<string, number> = {};
  const add = (k: string, v: number) => (acc[k] = (acc[k] ?? 0) + v);
  for (const l of lines) {
    if (l.clientId !== clientId || l.date > asAt) continue;
    const a = byCode.get(l.accountNo);
    const grp = g(l.accountNo);
    const dr = minor(l.debit) - minor(l.credit);
    if (l.date >= from && isPl(a)) {
      if (a!.type === 'Income') add(grp === 'revenue' ? 'revenue' : 'otherIncome', -dr);
      else if (grp === 'costOfSales') add('cogs', dr);
      else if (grp === 'staffCosts') add('staff', dr);
      else if (grp === 'depreciation') add('depreciation', dr);
      else if (grp === 'financeCosts') add('financeCosts', dr);
      else if (grp !== 'taxExpense') add('opex', dr);
    }
    if (!isPl(a)) {
      if (grp === 'cash') add('cash', dr);
      else if (grp === 'receivables') add('receivables', dr);
      else if (grp === 'inventories') add('inventory', dr);
      else if (grp === 'payables') add('payables', -dr);
      else if (grp === 'borrowings' || grp === 'leaseLiability') add('borrowings', -dr);
    }
  }
  const v = (k: string) => r2((acc[k] ?? 0) / 100);
  return { revenue: r2(v('revenue') + v('otherIncome')), cogs: v('cogs'), staff: v('staff'), opex: v('opex'), depreciation: v('depreciation'), financeCosts: v('financeCosts'), borrowings: v('borrowings'), cash: v('cash'), receivables: v('receivables'), payables: v('payables'), inventory: v('inventory'), asAt, from };
}

export interface ProjectionYear { year: number; revenue: number; cogs: number; grossProfit: number; staff: number; opex: number; ebitda: number; depreciation: number; ebit: number; financeCosts: number; pbt: number; tax: number; netProfit: number; grossMarginPct: number; netMarginPct: number; workingCapital: number; deltaWc: number; operatingCashFlow: number; capex: number; freeCashFlow: number; closingCash: number }

export function projectScenario(base: BaseFinancials, d: ScenarioDrivers, years: number): ProjectionYear[] {
  const out: ProjectionYear[] = [];
  const cogsRatio = base.revenue ? base.cogs / base.revenue : 0;
  const fx = 1 + ((d.fxShockPct / 100) * d.fxExposurePct) / 100;
  let revenue = base.revenue;
  let staff = base.staff;
  let opex = base.opex;
  let cash = base.cash;
  let prevWc = base.receivables + base.inventory - base.payables;
  let cumCapex = 0;
  for (let y = 1; y <= Math.max(1, Math.min(5, years)); y++) {
    revenue = revenue * (1 + d.revenueGrowthPct / 100) * (1 + d.priceChangePct / 100) * (1 + d.volumeChangePct / 100);
    const cogs = revenue * cogsRatio * (1 + d.cogsChangePct / 100) * fx / (1 + d.priceChangePct / 100);
    staff = staff * (1 + d.staffCostChangePct / 100);
    opex = opex * (1 + d.opexInflationPct / 100) * (y === 1 ? fx : 1);
    cumCapex += d.capex;
    const depreciation = base.depreciation + cumCapex / 5;
    const grossProfit = revenue - cogs;
    const ebitda = grossProfit - staff - opex;
    const ebit = ebitda - depreciation;
    const financeCosts = Math.max(0, base.financeCosts + (base.borrowings * d.interestRateChangePct) / 100);
    const pbt = ebit - financeCosts;
    const tax = Math.max(0, pbt) * (d.taxRatePct / 100);
    const netProfit = pbt - tax;
    const wc = (revenue * d.dsoDays) / 365 + (cogs * d.dioDays) / 365 - ((cogs + opex) * d.dpoDays) / 365;
    const deltaWc = wc - prevWc;
    prevWc = wc;
    const ocf = netProfit + depreciation - deltaWc;
    const fcf = ocf - d.capex;
    cash += fcf;
    out.push({ year: y, revenue: r2(revenue), cogs: r2(cogs), grossProfit: r2(grossProfit), staff: r2(staff), opex: r2(opex), ebitda: r2(ebitda), depreciation: r2(depreciation), ebit: r2(ebit), financeCosts: r2(financeCosts), pbt: r2(pbt), tax: r2(tax), netProfit: r2(netProfit), grossMarginPct: revenue ? r2((grossProfit / revenue) * 100) : 0, netMarginPct: revenue ? r2((netProfit / revenue) * 100) : 0, workingCapital: r2(wc), deltaWc: r2(deltaWc), operatingCashFlow: r2(ocf), capex: r2(d.capex), freeCashFlow: r2(fcf), closingCash: r2(cash) });
  }
  return out;
}

export function sensitivity(base: BaseFinancials, d: ScenarioDrivers, deltaPct: number) {
  const baseProfit = projectScenario(base, d, 1)[0]?.netProfit ?? 0;
  const keys: (keyof ScenarioDrivers)[] = ['revenueGrowthPct', 'priceChangePct', 'cogsChangePct', 'opexInflationPct', 'staffCostChangePct', 'fxShockPct', 'interestRateChangePct'];
  const rows = keys.map((k) => {
    const lo = projectScenario(base, { ...d, [k]: d[k] - deltaPct }, 1)[0]?.netProfit ?? 0;
    const hi = projectScenario(base, { ...d, [k]: d[k] + deltaPct }, 1)[0]?.netProfit ?? 0;
    return { label: DRIVER_META.find((m) => m.key === k)?.label ?? k, low: r2(Math.min(lo, hi)), high: r2(Math.max(lo, hi)) };
  });
  return { baseProfit, rows: rows.sort((a, b) => b.high - b.low - (a.high - a.low)) };
}

export function breakEven(y: ProjectionYear | undefined) {
  if (!y || !y.revenue) return { breakEvenRevenue: 0, marginOfSafetyPct: 0, cmRatioPct: 0, fixedCosts: 0 };
  const fixedCosts = y.staff + y.opex + y.depreciation + y.financeCosts;
  const cm = (y.revenue - y.cogs) / y.revenue;
  const be = cm > 0 ? fixedCosts / cm : 0;
  return { breakEvenRevenue: r2(be), marginOfSafetyPct: cm > 0 ? r2(((y.revenue - be) / y.revenue) * 100) : 0, cmRatioPct: r2(cm * 100), fixedCosts: r2(fixedCosts) };
}

/* ------------------------------------------------------------------ */
/* KPI scorecard                                                       */
/* ------------------------------------------------------------------ */

export type Perspective = 'Financial' | 'Customer' | 'Internal process' | 'Learning & growth';
export interface KpiDef { id: string; label: string; unit: '%' | 'x' | 'days' | 'amount' | 'months'; direction: 'higher' | 'lower'; perspective: Perspective; target: number; formula: string }
export const KPI_DEFS: KpiDef[] = [
  { id: 'revenueGrowth', label: 'Revenue growth vs prior period', unit: '%', direction: 'higher', perspective: 'Financial', target: 10, formula: '(Revenue − prior revenue) ÷ prior revenue' },
  { id: 'grossMargin', label: 'Gross margin', unit: '%', direction: 'higher', perspective: 'Financial', target: 35, formula: 'Gross profit ÷ revenue' },
  { id: 'ebitdaMargin', label: 'EBITDA margin', unit: '%', direction: 'higher', perspective: 'Financial', target: 20, formula: 'EBITDA ÷ revenue' },
  { id: 'netMargin', label: 'Net profit margin', unit: '%', direction: 'higher', perspective: 'Financial', target: 10, formula: 'Profit for the period ÷ revenue' },
  { id: 'roe', label: 'Return on equity (annualised)', unit: '%', direction: 'higher', perspective: 'Financial', target: 15, formula: 'Annualised profit ÷ closing equity' },
  { id: 'roa', label: 'Return on assets (annualised)', unit: '%', direction: 'higher', perspective: 'Financial', target: 8, formula: 'Annualised profit ÷ total assets' },
  { id: 'currentRatio', label: 'Current ratio', unit: 'x', direction: 'higher', perspective: 'Financial', target: 1.5, formula: 'Current assets ÷ current liabilities' },
  { id: 'quickRatio', label: 'Quick ratio', unit: 'x', direction: 'higher', perspective: 'Financial', target: 1, formula: '(Current assets − inventory) ÷ current liabilities' },
  { id: 'debtToEquity', label: 'Debt to equity', unit: 'x', direction: 'lower', perspective: 'Financial', target: 1, formula: 'Borrowings & leases ÷ equity' },
  { id: 'interestCover', label: 'Interest cover', unit: 'x', direction: 'higher', perspective: 'Financial', target: 3, formula: 'EBIT ÷ finance costs' },
  { id: 'cashRunway', label: 'Cash runway', unit: 'months', direction: 'higher', perspective: 'Financial', target: 6, formula: 'Cash ÷ average monthly operating outflow' },
  { id: 'budgetAttainment', label: 'Revenue budget attainment (YTD)', unit: '%', direction: 'higher', perspective: 'Customer', target: 100, formula: 'YTD actual revenue ÷ YTD budget' },
  { id: 'dso', label: 'Debtor days (DSO)', unit: 'days', direction: 'lower', perspective: 'Customer', target: 45, formula: 'Receivables ÷ revenue × days' },
  { id: 'overdueShare', label: 'Overdue receivables share', unit: '%', direction: 'lower', perspective: 'Customer', target: 15, formula: 'Overdue open invoices ÷ open invoices' },
  { id: 'dpo', label: 'Creditor days (DPO)', unit: 'days', direction: 'higher', perspective: 'Internal process', target: 45, formula: 'Payables ÷ (COGS + overheads) × days' },
  { id: 'dio', label: 'Inventory days (DIO)', unit: 'days', direction: 'lower', perspective: 'Internal process', target: 60, formula: 'Inventory ÷ COGS × days' },
  { id: 'ccc', label: 'Cash conversion cycle', unit: 'days', direction: 'lower', perspective: 'Internal process', target: 60, formula: 'DSO + DIO − DPO' },
  { id: 'opexRatio', label: 'Overhead ratio', unit: '%', direction: 'lower', perspective: 'Internal process', target: 30, formula: 'Overheads ÷ revenue' },
  { id: 'staffCostRatio', label: 'Staff cost ratio', unit: '%', direction: 'lower', perspective: 'Learning & growth', target: 25, formula: 'Staff costs ÷ revenue' },
  { id: 'revenuePerEmployee', label: 'Revenue per employee (annualised)', unit: 'amount', direction: 'higher', perspective: 'Learning & growth', target: 0, formula: 'Annualised revenue ÷ active employees' },
];

export function computeKpis(lines: readonly ACDOCALine[], accounts: AccountMaster[], clientId: number, from: string, through: string, extras: { invoices: SalesInvoice[]; employees: number; budgetRevenueYtd?: number; termsDays?: number }): Record<string, number | null> {
  const byCode = new Map(accounts.map((a) => [a.accountNo, a]));
  const days = Math.max(1, Math.round((Date.parse(through) - Date.parse(from)) / 86_400_000) + 1);
  const priorFrom = new Date(Date.parse(from) - days * 86_400_000).toISOString().slice(0, 10);
  const priorThrough = new Date(Date.parse(from) - 86_400_000).toISOString().slice(0, 10);
  const m: Record<string, number> = {};
  const add = (k: string, v: number) => (m[k] = (m[k] ?? 0) + v);
  for (const l of lines) {
    if (l.clientId !== clientId || l.date > through) continue;
    const a = byCode.get(l.accountNo);
    const g = groupOf(a, l.accountNo);
    const dr = (minor(l.debit) - minor(l.credit)) / 100;
    if (isPl(a)) {
      const inP = l.date >= from;
      const inPrior = l.date >= priorFrom && l.date <= priorThrough;
      if (a!.type === 'Income' && g === 'revenue') { if (inP) add('revenue', -dr); if (inPrior) add('priorRevenue', -dr); }
      if (!inP) continue;
      if (a!.type === 'Income') add('income', -dr);
      else {
        add('expense', dr);
        if (g === 'costOfSales') add('cogs', dr);
        else if (g === 'staffCosts') add('staff', dr);
        else if (g === 'depreciation') add('dep', dr);
        else if (g === 'financeCosts') add('fin', dr);
        else if (g === 'taxExpense') add('tax', dr);
        else add('opex', dr);
      }
    } else {
      const type = a?.type;
      if (type === 'Asset') add('assets', dr);
      if (type === 'Liability') add('liabilities', -dr);
      if (['cash', 'receivables', 'inventories', 'prepayments', 'taxAsset', 'contractAssets'].includes(g)) add('currentAssets', dr);
      if (['payables', 'taxPayable', 'contractLiabilities', 'dividends', 'provisions'].includes(g)) add('currentLiabilities', -dr);
      if (g === 'borrowings' || g === 'leaseLiability') add('debt', -dr);
      if (g === 'cash') add('cash', dr);
      if (g === 'receivables') add('receivables', dr);
      if (g === 'inventories') add('inventory', dr);
      if (g === 'payables') add('payables', -dr);
    }
  }
  const v = (k: string) => m[k] ?? 0;
  const revenue = v('revenue');
  const profit = v('income') - v('expense');
  const equity = v('assets') - v('liabilities');
  const ann = 365 / days;
  const ebit = profit + v('tax') + v('fin');
  const opOut = (v('expense') - v('dep') - v('tax')) / Math.max(1, days / 30.4);
  const safe = (n: number, d: number) => (d ? n / d : null);
  const open = extras.invoices.filter((i) => (i.clientId ?? clientId) === clientId && (i.status === 'Open' || i.status === 'Partial'));
  const outstanding = open.reduce((s, i) => s + Math.max(0, i.totalReceivable - (i.paidAmount || 0)), 0);
  const overdue = open.filter((i) => Date.parse(through) - Date.parse(i.date) > (extras.termsDays ?? 30) * 86_400_000).reduce((s, i) => s + Math.max(0, i.totalReceivable - (i.paidAmount || 0)), 0);
  const dso = safe(v('receivables') * days, revenue);
  const dpo = safe(v('payables') * days, v('cogs') + v('opex'));
  const dio = safe(v('inventory') * days, v('cogs'));
  const pct = (x: number | null) => (x === null ? null : r2(x * 100));
  const rnd = (x: number | null, dp = 2) => (x === null || !Number.isFinite(x) ? null : Math.round(x * 10 ** dp) / 10 ** dp);
  return {
    revenue: r2(revenue),
    profit: r2(profit),
    revenueGrowth: pct(v('priorRevenue') ? (revenue - v('priorRevenue')) / Math.abs(v('priorRevenue')) : null),
    grossMargin: pct(safe(revenue - v('cogs'), revenue)),
    ebitdaMargin: pct(safe(ebit + v('dep'), revenue)),
    netMargin: pct(safe(profit, revenue)),
    roe: pct(equity > 0 ? (profit * ann) / equity : null),
    roa: pct(safe(profit * ann, v('assets'))),
    currentRatio: rnd(safe(v('currentAssets'), v('currentLiabilities'))),
    quickRatio: rnd(safe(v('currentAssets') - v('inventory'), v('currentLiabilities'))),
    debtToEquity: rnd(equity > 0 ? v('debt') / equity : null),
    interestCover: rnd(safe(ebit, v('fin'))),
    cashRunway: rnd(opOut > 0 ? v('cash') / opOut : null, 1),
    budgetAttainment: pct(extras.budgetRevenueYtd ? revenue / extras.budgetRevenueYtd : null),
    dso: rnd(dso, 0),
    overdueShare: pct(outstanding ? overdue / outstanding : null),
    dpo: rnd(dpo, 0),
    dio: rnd(dio, 0),
    ccc: dso !== null && dpo !== null ? rnd((dso ?? 0) + (dio ?? 0) - (dpo ?? 0), 0) : null,
    opexRatio: pct(safe(v('opex'), revenue)),
    staffCostRatio: pct(safe(v('staff'), revenue)),
    revenuePerEmployee: rnd(extras.employees ? (revenue * ann) / extras.employees : null, 0),
  };
}

export type Rag = 'green' | 'amber' | 'red' | 'na';
export function ragStatus(value: number | null, target: number, direction: 'higher' | 'lower'): Rag {
  if (value === null || !Number.isFinite(value) || !target) return 'na';
  const ratio = direction === 'higher' ? value / target : target / (value || 1e-9);
  if (direction === 'lower' && value <= target) return 'green';
  if (ratio >= 1) return 'green';
  return ratio >= 0.9 ? 'amber' : 'red';
}

/* ------------------------------------------------------------------ */
/* 12-month cash-flow forecast                                         */
/* ------------------------------------------------------------------ */

export interface CashPlanItem { id: string; label: string; month: number; amount: number }
export interface CashPlanPayload { collectionLagMonths: number; paymentLagMonths: number; minimumCash: number; items: CashPlanItem[] }

export function cashForecast(months: string[], revenue: number[], expenses: number[], nonCash: number[], openingCash: number, openingReceivables: number, openingPayables: number, plan: CashPlanPayload) {
  const cl = Math.max(0, Math.min(3, Math.round(plan.collectionLagMonths)));
  const pl = Math.max(0, Math.min(3, Math.round(plan.paymentLagMonths)));
  let cash = openingCash;
  return months.map((m, i) => {
    const receipts = i - cl >= 0 ? revenue[i - cl] : cl ? openingReceivables / cl : 0;
    const payments = i - pl >= 0 ? expenses[i - pl] - nonCash[i - pl] : pl ? openingPayables / pl : 0;
    const other = sum(plan.items.filter((it) => it.month === i).map((it) => it.amount));
    const net = receipts - payments + other;
    const opening = cash;
    cash += net;
    return { month: m, opening: r2(opening), receipts: r2(receipts), payments: r2(payments), other: r2(other), net: r2(net), closing: r2(cash), belowMinimum: cash < plan.minimumCash };
  });
}

export { lastDay };
